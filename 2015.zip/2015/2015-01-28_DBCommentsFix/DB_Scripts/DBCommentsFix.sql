update xntcomments set ccmt = 'The property on this loan is in the name of Mrs. Yuyama''s Sister and Mrs. Yuyama''s Son. They will be putting the home into The Masaji Mark Yuyama and Eleanor Kikuyo Yuyama Revocable Living Trust in escrow. Please have the title company prepare a Grant Deed from the Sister and Son to the Trust once escrow is opened. The note on the first is held by a longtime family friend and they do not have to make payments on it.  When and if the home is ever sold the First Mortgage will be paid off through the sale of the home.  A letter of explanation will be enclosed with this loan file.'
where nappId = '104262' and
cuserid = 'conriqj01' and
cType = 'General'
GO
