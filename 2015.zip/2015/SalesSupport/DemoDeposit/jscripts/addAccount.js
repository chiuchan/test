﻿    addEvent(window, "load", Init);

    function Init()
    {
		startTimer();
        getObj("content").style.display = "";
    }

    function openAccountType() {
        window.open("../Demo_DAO/pdf/ProductPage.pdf");
    }