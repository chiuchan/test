﻿
        addEvent(window, "load", Init);

        function Init()
        {
			startTimer();
			getObj("content").style.display = "";
			formatAmount();
        }

        function showMultiple(payMethod) {
            if (payMethod == "3") {
                //document.getElementById("paypalImg").style.display = "inline";
                //document.getElementById("authorizeNetImg").style.display = "inline";
                accountsCount = new Number(document.getElementById("AccountsCount").value);
                for (i = 0; i < accountsCount; i++) {
                    objId = "account_" + i + "c1";
                    if (obj = document.getElementById(objId)) {
                        obj.style.display = "inline";
                    }
                    objId = "account_" + i + "c2";
                    if (obj = document.getElementById(objId)) {
                        obj.style.display = "inline";
                    }
                }
                /*
                document.getElementById("paypalSubmitBut").style.display = "inline";
                document.getElementById("authorizeSubmitBut").style.display = "inline";
                document.getElementById("singleSubmitBut").style.display = "none";
                */
            }
            else {
                //document.getElementById("paypalImg").style.display = "none";
                //document.getElementById("authorizeNetImg").style.display = "none";
                accountsCount = new Number(document.getElementById("AccountsCount").value);
                for (i = 0; i < accountsCount; i++) {
                    objId = "account_" + i + "c1";
                    if (obj = document.getElementById(objId)) {
                        obj.style.display = "none";
                    }
                    objId = "account_" + i + "c2";
                    if (obj = document.getElementById(objId)) {
                        obj.style.display = "none";
                    }
                }
                /*
                document.getElementById("paypalSubmitBut").style.display = "none";
                document.getElementById("authorizeSubmitBut").style.display = "none";
                document.getElementById("singleSubmitBut").style.display = "inline";
                */
            }
        }


        function formatAmount() {
            var accountsCount = new Number(document.getElementById("AccountsCount").value);
            for (i = 0; i < accountsCount; i++) {
                objId = "amount_" + i;
                if (obj = document.getElementById(objId)) {
                    obj.value = new Number(obj.value).toFixed(2);
                }
            }
        }

        function changeAMT() {
            var totalAmtObj = document.getElementById("totalAmt");
            var AMT = document.getElementById("AMT");
            var AMTs = document.getElementById("AMTs");
            var AMTsString = "";

            accountsCount = new Number(document.getElementById("AccountsCount").value);
            totalAmtValue = new Number(0);
            for (i = 0; i < accountsCount; i++) {
                objId = "amount_" + i;
                if (obj = document.getElementById(objId)) {
                    totalAmtValue += new Number(obj.value);
                    AMTsString += (obj.value + ",");
                }
            }
            //totalAmtValue = new Number(document.getElementById("amount_0").value) + new Number(document.getElementById("amount_1").value) + new Number(document.getElementById("amount_2").value);
            totalAmtObj.innerHTML = "$" + addCommas(totalAmtValue.toFixed(2));
            AMT.value = totalAmtValue.toFixed(2);
            AMTs.value = AMTsString;
            formatAmount();
        }

        function DisableButtons()
        {
            hide("Continue");
            show("ContinueDisabled");
            if (document.getElementById("paymentMethod2").checked == true) {
                alert("ACI has no control over information at any site hyperlinked to or from this Site. " +
                "ACI makes no representation concerning and is not responsible for the quality, content, nature, or reliability " +
                "of any hyperlinked site and is providing this hyperlink to you only as a convenience. " +
                "The inclusion of any hyperlink does not imply any endorsement, investigation, verification or monitoring by ACI " +
                "of any information in any hyperlinked site. In no event shall ACI be responsible for your use of a hyperlinked site")
            }
            //alert("Please be patient while your accounts are being funded.");
        }

        function addCommas(nStr)
        {
            nStr += '';
            x = nStr.split('.');
            x1 = x[0];
            x2 = x.length > 1 ? '.' + x[1] : '';
            var rgx = /(\d+)(\d{3})/;
            while (rgx.test(x1))
            {
                x1 = x1.replace(rgx, '$1' + ',' + '$2');
            }
            return x1 + x2;
        }