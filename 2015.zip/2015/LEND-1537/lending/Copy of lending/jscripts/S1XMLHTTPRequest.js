function S1XMLHTTPRequest()
{
	var self = this;	// reference pointer for IE scope issues
	this.returnMethod = null;
	this.xmlhttp=null;
	
	// define xmlhttp
	try
	{
		// Firefox, Opera 8.0+, Safari
		this.xmlhttp = new XMLHttpRequest();
	}
	catch (e)
	{
		// Internet Explorer
		try
		{
			this.xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
		}
		catch (e)
		{
			this.xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
	}

	this.xmlhttpChange = function ()
	{
    	if (self.xmlhttp.readyState == 4) 
		{
	        // only if "OK"		
        	if (self.xmlhttp.status == 200) 
			{
				if (self.returnMethod)
				{
					self.returnMethod(self.xmlhttp.responseText);
				}
        	}
			else 
			{
	           // alert("There was a problem retrieving the XML  data:\n" + self.xmlhttp.statusText);
        	}
    	}
	}
	
	this.xmlhttpGet = function (url, callbackFunction)
	{
		if (self.xmlhttp)
		{
			self.returnMethod = callbackFunction;
			self.xmlhttp.onreadystatechange = self.xmlhttpChange;
			self.xmlhttp.open("GET", url, true);
			self.xmlhttp.send(null);
		}
	}
	
	this.xmlhttpPost = function (url, data, callbackFunction)
	{
		if (self.xmlhttp)
		{
			self.returnMethod = callbackFunction;
			self.xmlhttp.onreadystatechange = self.xmlhttpChange;
			self.xmlhttp.open("POST", url , true);
			self.xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
			self.xmlhttp.send(data);
		}
	}
}

function addURLParam(sURL, sParamName, sParamValue)
{
	sURL += (sURL.indexOf("?") == -1 ? "?" : "&");
	sURL += encodeURIComponent(sParamName) + "=" + encodeURIComponent(sParamValue);
	return sURL;	
}

var needToConfirm = true;

function confirmExit()
{
    if(needToConfirm)
    {
        var myXMLHTTPRequeset = new S1XMLHTTPRequest();
        var url = "~/pageClose.aspx";
        myXMLHTTPRequeset.xmlhttpGet(url);
    }
}