
        addEvent(window, "load", Init);

        function Init()
        {
            hide("pnlSpacer1");
            
            if(getObj("pnlWait").style.display == "")
            {
                setTimeout("swapProc()", parseInt(getObj("swapProcTimeOutLbl").innerHTML));
            }
            
            /*
            var appStatusTable = getObj("statusTable");
            for (rowNum = 0; rowNum < appStatusTable.rows.length - 1; rowNum++)
            {
                addEvent("statusDDL_" + rowNum, "change", toggleWait);
                addEvent("statusDDL_" + rowNum, "keyup", toggleWait);
            }
            */
        }
        
        function swapProc()
        {
	        toggle(new Array("pnlWait", "pnlBooking"));
        }
        
        function toggleWait(e)
        {
            var el = returnActiveElement(e);
            if(el.options[el.selectedIndex].text == "Book Loan")
                show("pnlWait");
        }

        window.onbeforeunload = confirmExit;
        var needToConfirm = true;
        function confirmExit()
        {
            if(needToConfirm)
            {
                var myXMLHTTPRequeset = new S1XMLHTTPRequest();
                myXMLHTTPRequeset.xmlhttpGet("pageClose.aspx");
            }
        }