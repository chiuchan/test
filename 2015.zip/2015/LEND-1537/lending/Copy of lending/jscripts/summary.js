addEvent(window, "load", Init);

        function Init()
        {
            if(getObj("showHMDAReminderLbl").innerHTML == "true")
                alert("Reminder! Please remember to enter any HMDA information for the newly added Co-Applicant by editing the Loan Information page.");
                
            if(getObj("showSurveyLbL").innerHTML == "true")
                show("pnlSurvey");
            else
                hide("pnlSurvey");
                
            //page nav
            addEvent("cboCheckAccept", 	"change", 	togglePageNav);
	        addEvent("cboCheckAccept", 	"keyup", 	togglePageNav);
        }

        window.onbeforeunload = confirmExit;
        var needToConfirm = true;
        function confirmExit()
        {
            if(needToConfirm)
            {
                var myXMLHTTPRequeset = new S1XMLHTTPRequest();
                myXMLHTTPRequeset.xmlhttpGet("pageClose.aspx");
            }
        }

        function SendToProcessing()
        {
            getObj("pnlError").innerHTML = "";
            hide("pnlError");
            var goToProcessing = true;
            
            if(getObj("showSurveyLbL").innerHTML == "true")
            {
                if (getObj("anSurvey").options[getObj("anSurvey").selectedIndex].value == "")
                {
                    getObj("pnlError").innerHTML = "<font size='3'>Missing \\ Incomplete Required Fields</font><br/><br/>How satisfied are you with your online loan application process?";
                    show("pnlError");   
                    
                    goToProcessing = false;
                    getObj("logo").focus();
                }
            }
            
            if(goToProcessing)
            {
                getObj("Continue").disabled = true;
                needToConfirm = false;
                window.location.href = "processing.aspx";
            }
        }

        function togglePageNav()
        {
            var el = getObj("cboCheckAccept");
            
            if (el.options.selectedIndex == 0)
            {
                getObj("pnlError").innerHTML = "";
                hide(new Array("pnlError",
                    "pnlPageNav"));
            }
            else if (el.options.selectedIndex == 1)
            {
                //hide the panel and clear the field
                getObj("pnlError").innerHTML = "";
                hide("pnlError");
                show("pnlPageNav");
            }
            else if (el.options.selectedIndex == 2)
            {
                getObj("pnlError").innerHTML = "Please review the application prior to submitting.";
                show("pnlError");                
                hide("pnlPageNav");
                getObj("pnlError").focus();
            }
        }