addEvent(window, "load", Init);
        
        function Init() 
        {
	        addEvent("anGETTransType", "change", checkLoanType);
	        addEvent("anGETTransType", "keyup", checkLoanType);
    	
	        addEvent("radForSale1", "click", function() { show("ListedPanel");  });
	        addEvent("radForSale2", "click", function() { hide("ListedPanel"); 	});
	        
	        addEvent("radListed1", "click", sendToContactPage);
        }
        
        window.onbeforeunload = confirmExit;
        var needToConfirm = true;
        function confirmExit()
        {
            if(needToConfirm)
            {
                var myXMLHTTPRequeset = new S1XMLHTTPRequest();
                myXMLHTTPRequeset.xmlhttpGet("pageClose.aspx");
            }
        }

        function checkLoanType() 
        {
	        if (getObj("anGETTransType").options[getObj("anGETTransType").selectedIndex].value == "Refinance")
		        show("pnlRefiInfo");
	        else 
		        hide("pnlRefiInfo");
        }
        
        function sendToContactPage()
        {
            window.location.href = "contact.aspx";
        }