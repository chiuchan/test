addEvent(window, "load", Init);

        function Init()
        {
            setTimeout("swapProc()", 10000);
        }
        
        function swapProc()
        {
	        toggle(new Array("pnlProc", "pnlButton"));
        }

        window.onbeforeunload = confirmExit;
        var needToConfirm = true;
        function confirmExit()
        {
            if(needToConfirm)
            {
                var myXMLHTTPRequeset = new S1XMLHTTPRequest();
                myXMLHTTPRequeset.xmlhttpGet("pageClose.aspx");
            }
        }