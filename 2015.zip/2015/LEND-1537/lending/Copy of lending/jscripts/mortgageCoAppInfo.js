addEvent(window, "load", Init);
        
        function Init()
        {
            togglePrevAddr();
            toggleForeignAddressFields();
            toggleAddressFields();
            toggleMailAddr();
            toggleEmploymentStatus();
            toggleAdditionalFields();
            checkPersonalDetails();
            checkYearsEmployed();
            
            toggleAlimony();
            toggleCoMaker();
            toggleDeclaredBankruptcy();
            toggleProperyForeclosed();
            toggleDelinquent();
            toggleDownPaymentBorrowed();
            toggleLawSuit();
            toggleLoanObligation();
            toggleOutstandingJudgements();
            toggleOwnershipInterest();
            checkIncomeSource();
            
            addEvent("coAppTimeEmpYr", "change", checkYearsEmployed);
	        addEvent("coAppTimeEmpYr", "keyup", checkYearsEmployed);
        
	        addEvent("coAppSelOccupation", "change", checkEmploymentStatus);
	        addEvent("coAppSelOccupation", "keyup", checkEmploymentStatus);	
        	
	        addEvent("hmCoAppPersonalDetails", "click", checkPersonalDetails);

	        addEvent("coAppOthIncAvail1", "click", function() { show("coAppAddIncomePanel"); });
	        addEvent("coAppOthIncAvail2", "click", function() { hide("coAppAddIncomePanel"); });
	        
	        addEvent("coAppAlimony", "change", toggleAlimony);
            addEvent("coAppAlimony", "keyup", toggleAlimony);
            
            addEvent("coAppComaker", "change", toggleCoMaker);
            addEvent("coAppComaker", "keyup", toggleCoMaker);
            
            addEvent("coAppDeclaredBankruptcy", "change", toggleDeclaredBankruptcy);
            addEvent("coAppDeclaredBankruptcy", "keyup", toggleDeclaredBankruptcy);
            
            addEvent("coAppProperyForeclosed", "change", toggleProperyForeclosed);
            addEvent("coAppProperyForeclosed", "keyup", toggleProperyForeclosed);
            
            addEvent("coAppDelinquent", "change", toggleDelinquent);
            addEvent("coAppDelinquent", "keyup", toggleDelinquent);
            
            addEvent("coAppDownPaymentBorrowed", "change", toggleDownPaymentBorrowed);
            addEvent("coAppDownPaymentBorrowed", "keyup", toggleDownPaymentBorrowed);
            
            addEvent("coAppLawSuit", "change", toggleLawSuit);
            addEvent("coAppLawSuit", "keyup", toggleLawSuit);
            
            addEvent("coAppLoanObligation", "change", toggleLoanObligation);
            addEvent("coAppLoanObligation", "keyup", toggleLoanObligation);
            
            addEvent("coAppOutstandingJudgements", "change", toggleOutstandingJudgements);
            addEvent("coAppOutstandingJudgements", "keyup", toggleOutstandingJudgements);
            
            addEvent("coAppOwnershipInterest", "change", toggleOwnershipInterest);
            addEvent("coAppOwnershipInterest", "keyup", toggleOwnershipInterest);
            
            addEvent("coAppTimeAddrYr", "change", togglePrevAddr);
		    addEvent("coAppTimeAddrYr", "keyup", togglePrevAddr);
            addEvent("coAppTimeAddrMo", "change", togglePrevAddr);
		    addEvent("coAppTimeAddrMo", "keyup", togglePrevAddr);
		    
		    //address type
            addEvent("coAppAddrType", "change", toggleAddressFields);
		    addEvent("coAppAddrType", "keyup", toggleAddressFields);
	        
	        //foreign address
            addEvent("coAppFrgnAddr", "change", toggleForeignAddressFields);
		    addEvent("coAppFrgnAddr", "keyup", toggleForeignAddressFields);

            //previous foreign address
            addEvent("coAppPrevFrgnAddr", "change", togglePrevForeignAddressFields);
		    addEvent("coAppPrevFrgnAddr", "keyup", togglePrevForeignAddressFields);

            //mailing foreign address
            addEvent("coAppMailFrgnAddr", "change", toggleMailForeignAddressFields);
		    addEvent("coAppMailFrgnAddr", "keyup", toggleMailForeignAddressFields);
		    
		    //previous address fields
            addEvent("coAppPrevAddrType", "change", togglePrevAddressFields);
		    addEvent("coAppPrevAddrType", "keyup", togglePrevAddressFields);
	        
	        //mailing address
            addEvent("coAppMailAddrDif", "change", toggleMailAddr);
		    addEvent("coAppMailAddrDif", "keyup", toggleMailAddr);
	        
	        addEvent("coAppOthIncSrc1", "change", checkIncomeSource);
		    addEvent("coAppOthIncSrc1", "keyup", checkIncomeSource);
	        
	        if(getObj("showSaveSuccessLbl").innerHTML == "true")
	            showSaveSuccessAlert();
	            
	        if(getObj("pageFocusLbl").innerHTML.length > 0)
	            getObj(getObj("pageFocusLbl").innerHTML).focus();
	            
	        if(getObj("reqEmailLbl").innerHTML == "true")
            {
                changeLabel("pnlCoAppEmail", "Email Address:<span class=\"required\"> *</span>");
                toggleVerifyAttribute("coAppEmail", true);
                getObj("coAppEmail").isRequired = true;
            }
            else
            {
                changeLabel("pnlCoAppEmail", "Email Address:");
                toggleVerifyAttribute("coAppEmail", false);
                getObj("coAppEmail").isRequired = false;
            }

            if(getObj("showEmailVerifyLbl").innerHTML == "true")
                show("pnlCoAppEmailVerify");
            else
                hide("pnlCoAppEmailVerify");
                
            if(getObj("showMothersMaidenNameLbl").innerHTML == "true")
                show("pnlCoAppMothersMaidenName");
            else
                hide("pnlCoAppMothersMaidenName");
                
            if(getObj("showBestContactLbl").innerHTML == "true")
                show("pnlCoAppPhBestContact");
            else
                hide("pnlCoAppPhBestContact");
                
            if(getObj("showMonthlyHousingPaymentLbl").innerHTML == "true")
                show("pnlCoAppCrdtrHousePmt");
            else
                hide("pnlCoAppCrdtrHousePmt");
                
            if(getObj("showPersonalReferencesLbl").innerHTML == "true")
                show("pnlCoAppPersonalRef");
            else
                hide("pnlCoAppPersonalRef");
	        
        }
        
        window.onbeforeunload = confirmExit;
        var needToConfirm = true;
        function confirmExit()
        {
            if(needToConfirm)
            {
                var myXMLHTTPRequeset = new S1XMLHTTPRequest();
                myXMLHTTPRequeset.xmlhttpGet("pageClose.aspx");
            }
        }
        
        function toggleEmploymentStatus()
        {
            var emp = getObj("coAppSelOccupation").options[getObj("coAppSelOccupation").selectedIndex].value;
            if(emp == "Primary Job" || emp == "Self-Employed")
            {
                show("CoAppEmploymentFieldsPanel");
                if(emp == "Self-Employed")
                    show(new Array("CoAppEmploymentFieldsPanel", 
		                "pnlCoAppPctOnr"));
            }
            else if(emp == "Retired")
            {
                show("coAppAddIncomePanel");
                hide(new Array("CoAppEmploymentFieldsPanel", 
	                "pnlCoAppPctOnr", 
	                "coAppAddIncomePanel"));
            }
            else
                hide(new Array("CoAppEmploymentFieldsPanel", 
	                "pnlCoAppPctOnr", 
	                "coAppAddIncomePanel"));
        }
        
        function toggleAdditionalFields()
        {
            if(getObj("coAppOthIncAvail1").checked)
                show("coAppAddIncomePanel");
        }
        
        function checkEmploymentStatus() 
        {
	        var emp = getObj("coAppSelOccupation").options[getObj("coAppSelOccupation").selectedIndex].value;
        	
	        // reset
	        hide(new Array("CoAppEmploymentFieldsPanel", 
	            "pnlCoAppPctOnr", 
	            "coAppAddIncomePanel"));
	        getObj("coAppOthIncAvail2").checked = true;
		    getObj("coAppOthIncAvail1").checked = false;
	        
	        if (emp == "Primary Job")
		        show("CoAppEmploymentFieldsPanel");
	        else if (emp == "Self-Employed")
		        show(new Array("CoAppEmploymentFieldsPanel", 
		            "pnlCoAppPctOnr"));	
	        else if (emp == "Retired") 
	        {		
		        show("coAppAddIncomePanel");
		        getObj("coAppOthIncAvail2").checked = false;
		        getObj("coAppOthIncAvail1").checked = true;
		        getObj("coAppOthInc1").focus();
	        }
        }

        function checkYearsEmployed() 
        {
            if(getObj("coAppTimeEmpYr").selectedIndex > 0)
            {
                var emp = getObj("coAppSelOccupation").options[getObj("coAppSelOccupation").selectedIndex].value;
                if(emp == "Primary Job" || emp == "Self-Employed")
                {
	                if (parseInt(getObj("coAppTimeEmpYr").value) < 2)
		                show("pnlCoAppFormerEmploymentInfo");
	                else
		                hide("pnlCoAppFormerEmploymentInfo");
		        }
		        else
                    hide("pnlCoAppFormerEmploymentInfo");
            }
            else
                hide("pnlCoAppFormerEmploymentInfo");
        }


        function checkPersonalDetails() 
        {
	        var el = getObj("hmCoAppPersonalDetails");
	        if (!el) 
	            return;

	        if (el.checked)
		        hide("pnlCoAppPersonalDetails");
	        else
		        show("pnlCoAppPersonalDetails");
        }

        function checkIncomeSource(e) 
        {
	        // If it's a part-time or second job, show additional fields
	        var el = getObj("coAppOthIncSrc1");
	        if (el.options[el.selectedIndex].value == "P/T OR SECOND JOB")
		        show("coAppOthInc1ExtraFields");		
	        else 
		        hide("coAppOthInc1ExtraFields");
        }

        function checkFullTime() 
        {
	        var el = getObj("radCoAppFullTime1");
	        if (el.checked) 
	        {
		        show(new Array("pnlCoAppAddressInfo",
		            "pnlCoAppCitStatus",
		            "pnlCoAppSchoolYear",
		            "pnlCoAppSchoolName",
		            "pnlPageNav"));
		            
		        hide("pnlError");
	        }
	        else 
	        {
		        hide(new Array("pnlCoAppAddressInfo", 
		            "pnlCoAppCitStatus", 
		            "pnlCoAppSchoolYear", 
		            "pnlCoAppSchoolName", 
		            "pnlCoAppHomeAddress", 
		            "pnlCoAppSchoolAddress", 
		            "pnlPageNav"));
		            
		        setError("You must be a full-time student to apply for a Student VISA.");
	        }
        }

        function checkAddressType() 
        {
	        var el = getObj("radCoAppAddressType1");
	        if (el.checked) 
	        {
		        getObj("radCoAppHaveSchool1").checked = false;
		        getObj("radCoAppHaveSchool2").checked = false;		
		        show("pnlCoAppHaveSchoolAddress");
		        hide(new Array("pnlCoAppHomeAddress", 
		            "pnlCoAppHaveHomeAddress"));	
	        }
	        else 
	        {
		        getObj("radCoAppHaveHome1").checked = false;
		        getObj("radCoAppHaveHome2").checked = false;	
		        show(new Array("pnlCoAppHomeAddress", 
		            "pnlCoAppHaveHomeAddress"));
		            
		        hide(new Array("pnlCoAppHomeAddress", 
		            "pnlCoAppHaveSchoolAddress", 
		            "pnlCoAppSchoolAddress"));
	        }
        }
        
        function toggleAlimony()
        {
            var el = getObj("coAppAlimony");
            if (el.options[el.selectedIndex].value == "Yes")
                show("pnlCoAppAlimonyExp")
            else
            {
                getObj("coAppAlimonyExp").value = "";
                hide("pnlCoAppAlimonyExp")
            }
        }
        
        function toggleCoMaker()
        {
            var el = getObj("coAppComaker");
            if (el.options[el.selectedIndex].value == "Yes")
                show("pnlCoAppCoMakerExp")
            else
            {
                getObj("coAppCoMakerExp").value = "";
                hide("pnlCoAppCoMakerExp")
            }
        }
        
        function toggleDeclaredBankruptcy()
        {
            var el = getObj("coAppDeclaredBankruptcy");
            if (el.options[el.selectedIndex].value == "Yes")
                show("pnlCoAppDeclaredBankruptcyExp")
            else
            {
                getObj("coAppDeclaredBankruptcyExp").value = "";
                hide("pnlCoAppDeclaredBankruptcyExp")
            }
        }
        
        function toggleDelinquent()
        {
            var el = getObj("coAppDelinquent");
            if (el.options[el.selectedIndex].value == "Yes")
                show("pnlCoAppDelinquentExp")
            else
            {
                getObj("coAppDelinquentExp").value = "";
                hide("pnlCoAppDelinquentExp")
            }
        }
        
        function toggleDownPaymentBorrowed()
        {
            var el = getObj("coAppDownPaymentBorrowed");
            if (el.options[el.selectedIndex].value == "Yes")
                show("pnlCoAppDownPaymentBorrowedExp")
            else
            {
                getObj("coAppDownPaymentBorrowedExp").value = "";
                hide("pnlCoAppDownPaymentBorrowedExp")
            }
        }
        
        function toggleLawSuit()
        {
            var el = getObj("coAppLawSuit");
            if (el.options[el.selectedIndex].value == "Yes")
                show("pnlCoAppLawSuitExp")
            else
            {
                getObj("coAppLawSuitExp").value = "";
                hide("pnlCoAppLawSuitExp")
            }
        }
        
        function toggleLoanObligation()
        {
            var el = getObj("coAppLoanObligation");
            if (el.options[el.selectedIndex].value == "Yes")
                show("pnlCoAppLoanObligationExp")
            else
            {
                getObj("coAppLoanObligationExp").value = "";
                hide("pnlCoAppLoanObligationExp")
            }
        }
        
        function toggleOutstandingJudgements()
        {
            var el = getObj("coAppOutstandingJudgements");
            if (el.options[el.selectedIndex].value == "Yes")
                show("pnlCoAppOutstandingJudgementsExp")
            else
            {
                getObj("coAppOutstandingJudgementsExp").value = "";
                hide("pnlCoAppOutstandingJudgementsExp")
            }
        }
        
        function toggleProperyForeclosed()
        {
            var el = getObj("coAppProperyForeclosed");
            if (el.options[el.selectedIndex].value == "Yes")
                show("pnlCoAppProperyForeclosedExp")
            else
            {
                getObj("coAppProperyForeclosedExp").value = "";
                hide("pnlCoAppProperyForeclosedExp")
            }
        }
        
        function toggleOwnershipInterest()
        {
            var el = getObj("coAppOwnershipInterest");
            if (el.options[el.selectedIndex].value == "Yes")
                show("pnlCoAppOwnershipInterestPropType")
            else
            {
                getObj("coAppOwnershipInterestPropType").selectedIndex = 0;
                getObj("coAppTitleHeld").selectedIndex = 0;
                hide("pnlCoAppOwnershipInterestPropType")
            }
        }
        
        function togglePrevAddr() 
        {
            if(getObj("showPrevAddrLbl").innerHTML == "true" && getObj("coAppTimeAddrYr").options.selectedIndex > 0)
            {
                var months = parseInt(getObj("coAppTimeAddrYr").options[getObj("coAppTimeAddrYr").options.selectedIndex].value * 12);
                months += parseInt(getObj("coAppTimeAddrMo").options[getObj("coAppTimeAddrMo").options.selectedIndex].value);

                if(months < parseInt(getObj("showPrevAddrMonthsLbl").innerHTML))
                {
                    show("pnlCoAppPrevAddr");
                    togglePrevAddressFields();
                    togglePrevForeignAddressFields();
                }
                else
                    hide("pnlCoAppPrevAddr");
            }
            else
                hide("pnlCoAppPrevAddr");
        }
        
        function toggleAddressFields()
        {
            var el = getObj("coAppAddrType");
            if(el.options.selectedIndex == 0) 
            {
                if(getObj("useSingleAddrLineLbl").innerHTML == "true")
                {
                    hide("pnlCoAppStandardAddr");
                    show("pnlCoAppStandardSingleLineAddr");
                }
                else
                {
                    show("pnlCoAppStandardAddr");
                    hide("pnlCoAppStandardSingleLineAddr");
                }
                
                hide(new Array("pnlCoAppRuralAddr",
                    "pnlCoAppPOBoxAddr"));
            }
            else if(el.options.selectedIndex == 1) 
            {
                show("pnlCoAppRuralAddr");
                hide(new Array("pnlCoAppStandardAddr",
                    "pnlCoAppStandardSingleLineAddr",
                    "pnlCoAppPOBoxAddr"));
            }   
            else if(el.options.selectedIndex == 2) 
            {
                show("pnlCoAppPOBoxAddr");
                hide(new Array("pnlCoAppStandardAddr",
                    "pnlCoAppStandardSingleLineAddr",
                    "pnlCoAppRuralAddr"));
                    
               if(getObj("toggleMailingAddrFieldsLbl").innerHTML == "true")
                {
                    getObj("coAppMailAddrDif").options.selectedIndex = 1;
                    toggleMailAddr();
                }
            }
            
            toggleForeignPhoneFields();
        }
        
        function toggleForeignPhoneFields()
        {
            if(getObj("showForeignPhoneFields").innerHTML == "true")
            {
                if(getObj("coAppAddrType").options.selectedIndex == 1 || getObj("coAppFrgnAddr").options.selectedIndex == 0)
                {
                    hide(new Array("pnlCoAppPh",
                        "pnlCoAppCellPh"));
                        
                    show(new Array("pnlCoAppForeignPh",
                        "pnlCoAppForeignCellPh"));
                }
                else
                {
                    hide(new Array("pnlCoAppForeignPh",
                        "pnlCoAppForeignCellPh"));
                        
                    show(new Array("pnlCoAppPh",
                        "pnlCoAppCellPh"));
                }
            }
        }
        
        function toggleForeignAddressFields() 
        {
            var el = getObj("coAppFrgnAddr");
            if(el.options.selectedIndex == 0)
            {
                hide(new Array("pnlCoAppState",
                    "pnlCoAppZip"));

                show(new Array("pnlCoAppProv",
                    "pnlCoAppCntry",
                    "pnlCoAppPstlCd"));
            }
            else
            {
                hide(new Array("pnlCoAppProv",
                    "pnlCoAppCntry",
                    "pnlCoAppPstlCd",
                    "pnlCoAppForeignPh",
                    "pnlCoAppForeignCellPh"));
                
                show(new Array("pnlCoAppState",
                    "pnlCoAppZip",
                    "pnlCoAppPh",
                    "pnlCoAppCellPh"));
            }

            toggleForeignPhoneFields();
        }
        
        function togglePrevForeignAddressFields() 
        {
            if (getObj("pnlCoAppFrgnAddr").style.display == "")
            {
                show("pnlCoAppPrevFrgnAddr");
                var el = getObj("coAppPrevFrgnAddr");
                if(el.options.selectedIndex == 0)
                {
                    hide(new Array("pnlCoAppPrevState",
                        "pnlCoAppPrevZip"));

                    show(new Array("pnlCoAppPrevProv",
                        "pnlCoAppPrevCntry",
                        "pnlCoAppPrevPstlCd"));
                }
                else
                {
                    hide(new Array("pnlCoAppPrevProv",
                        "pnlCoAppPrevCntry",
                        "pnlCoAppPrevPstlCd"));
                    
                    show(new Array("pnlCoAppPrevState",
                        "pnlCoAppPrevZip"));
                }
            }
            else
                hide("pnlCoAppPrevFrgnAddr");
        }
        
        function toggleMailForeignAddressFields() 
        {
            if (getObj("pnlCoAppFrgnAddr").style.display == "")
            {
                show("pnlCoAppMailFrgnAddr");
                var el = getObj("coAppMailFrgnAddr");
                if(el.options.selectedIndex == 0)
                {
                    hide(new Array("pnlCoAppMailState",
                        "pnlCoAppMailZip"));

                    show(new Array("pnlCoAppMailProv",
                        "pnlCoAppMailCntry",
                        "pnlCoAppMailPstlCd"));
                }
                else
                {
                    hide(new Array("pnlCoAppMailProv",
                        "pnlCoAppMailCntry",
                        "pnlCoAppMailPstlCd"));
                    
                    show(new Array("pnlCoAppMailState",
                        "pnlCoAppMailZip"));
                }
            }
            else
                hide("pnlCoAppMailFrgnAddr");
        }
        
        function togglePrevAddressFields()
        {
            var el = getObj("coAppPrevAddrType");
            if(el.options.selectedIndex == 0) 
            {
                if(getObj("useSingleAddrLineLbl").innerHTML == "true")
                {
                    hide("pnlCoAppPrevStandardAddr");
                    show("pnlCoAppPrevStandardSingleLineAddr");
                }
                else
                {
                    show("pnlCoAppPrevStandardAddr");
                    hide("pnlCoAppPrevStandardSingleLineAddr");
                }
                
                hide(new Array("pnlCoAppPrevRuralAddr",
                    "pnlCoAppPrevPOBoxAddr"));
            }
            else if(el.options.selectedIndex == 1) 
            {
                show("pnlCoAppPrevRuralAddr");
                hide(new Array("pnlCoAppPrevStandardAddr",
                    "pnlCoAppPrevStandardSingleLineAddr",
                    "pnlCoAppPrevPOBoxAddr"));
            }   
            else if(el.options.selectedIndex == 2) 
            {
                show("pnlCoAppPrevPOBoxAddr");
                hide(new Array("pnlCoAppPrevStandardAddr",
                    "pnlCoAppPrevStandardSingleLineAddr",
                    "pnlCoAppPrevRuralAddr"));
            }
        }
        
        function toggleMailAddr() 
        {
            if(getObj("hideMailAddrDifLbl").innerHTML == "true")
                hide(new Array("pnlCoAppMailAddrDif",
                    "pnlCoAppMailAddr"));
            else
            {
                var el = getObj("coAppMailAddrDif");
                
                if (el.options.selectedIndex == 1)
                {
	                show("pnlCoAppMailAddr");
                    toggleMailForeignAddressFields();
                }
                else
                    hide("pnlCoAppMailAddr");
            }
        }