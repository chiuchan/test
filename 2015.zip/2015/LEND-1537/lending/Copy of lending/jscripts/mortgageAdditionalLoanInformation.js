addEvent(window, "load", Init);
        
            function Init()
            {
                if(getObj("showSaveSuccessLbl").innerHTML == "true")
	                showSaveSuccessAlert();
            }
            
            window.onbeforeunload = confirmExit;
            var needToConfirm = true;
            function confirmExit(el)
            {
                if(el == "true" || needToConfirm)
                {
                    var myXMLHTTPRequeset = new S1XMLHTTPRequest();
                    myXMLHTTPRequeset.xmlhttpGet("pageClose.aspx");
                }
            }
            
            function setNeedToConfirm()
            {
                needToConfirm = false;
            }
            
            function selectColumn(columnNum)
            {
                if(columnNum == "1")
                {
                    getObj("anWithOrWithOutClosingCosts2").checked = false;
                    getObj("anWithOrWithOutClosingCosts1").checked = true;
                }
                else
                {
                    getObj("anWithOrWithOutClosingCosts1").checked = false;
                    getObj("anWithOrWithOutClosingCosts2").checked = true;
                }            
            }