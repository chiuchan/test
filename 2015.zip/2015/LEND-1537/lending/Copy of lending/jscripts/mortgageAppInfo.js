addEvent(window, "load", Init);
        
        function Init()
        {
            togglePrevAddr();
            toggleForeignAddressFields();
            toggleAddressFields();
            toggleMailAddr();
            toggleEmploymentStatus();
            toggleAdditionalFields();
            checkPersonalDetails();
            checkYearsEmployed();
            checkAppType();
            
            toggleAlimony();
            toggleCoMaker();
            toggleDeclaredBankruptcy();
            toggleProperyForeclosed();
            toggleDelinquent();
            toggleDownPaymentBorrowed();
            toggleLawSuit();
            toggleLoanObligation();
            toggleOutstandingJudgements();
            toggleOwnershipInterest();
            checkIncomeSource();

            addEvent("atTimeEmpYr", "change", checkYearsEmployed);
	        addEvent("atTimeEmpYr", "keyup", checkYearsEmployed);
        
	        addEvent("selOccupation", "change", checkEmploymentStatus);
	        addEvent("selOccupation", "keyup", checkEmploymentStatus);	
        	
	        addEvent("anRegbType", "change", checkAppType);
	        addEvent("anRegbType", "keyup", checkAppType);
	        
	        addEvent("hmPersonalDetails", "click", checkPersonalDetails);

	        addEvent("atOthIncAvail1", "click", function() { show("AddIncomePanel"); });
	        addEvent("atOthIncAvail2", "click", function() { hide("AddIncomePanel"); });
	        
	        addEvent("atAlimony", "change", toggleAlimony);
            addEvent("atAlimony", "keyup", toggleAlimony);
            
            addEvent("atComaker", "change", toggleCoMaker);
            addEvent("atComaker", "keyup", toggleCoMaker);
            
            addEvent("atDeclaredBankruptcy", "change", toggleDeclaredBankruptcy);
            addEvent("atDeclaredBankruptcy", "keyup", toggleDeclaredBankruptcy);
            
            addEvent("atProperyForeclosed", "change", toggleProperyForeclosed);
            addEvent("atProperyForeclosed", "keyup", toggleProperyForeclosed);
            
            addEvent("atDelinquent", "change", toggleDelinquent);
            addEvent("atDelinquent", "keyup", toggleDelinquent);
            
            addEvent("atDownPaymentBorrowed", "change", toggleDownPaymentBorrowed);
            addEvent("atDownPaymentBorrowed", "keyup", toggleDownPaymentBorrowed);
            
            addEvent("atLawSuit", "change", toggleLawSuit);
            addEvent("atLawSuit", "keyup", toggleLawSuit);
            
            addEvent("atLoanObligation", "change", toggleLoanObligation);
            addEvent("atLoanObligation", "keyup", toggleLoanObligation);
            
            addEvent("atOutstandingJudgements", "change", toggleOutstandingJudgements);
            addEvent("atOutstandingJudgements", "keyup", toggleOutstandingJudgements);
            
            addEvent("atOwnershipInterest", "change", toggleOwnershipInterest);
            addEvent("atOwnershipInterest", "keyup", toggleOwnershipInterest);
            
            addEvent("atTimeAddrYr", "change", togglePrevAddr);
		    addEvent("atTimeAddrYr", "keyup", togglePrevAddr);
            addEvent("atTimeAddrMo", "change", togglePrevAddr);
		    addEvent("atTimeAddrMo", "keyup", togglePrevAddr);
		    
		    addEvent("atOthIncSrc1", "change", checkIncomeSource);
		    addEvent("atOthIncSrc1", "keyup", checkIncomeSource);
		    
		    //address type
            addEvent("atAddrType", "change", toggleAddressFields);
		    addEvent("atAddrType", "keyup", toggleAddressFields);
	        
	        //foreign address
            addEvent("atFrgnAddr", "change", toggleForeignAddressFields);
		    addEvent("atFrgnAddr", "keyup", toggleForeignAddressFields);

            //previous foreign address
            addEvent("atPrevFrgnAddr", "change", togglePrevForeignAddressFields);
		    addEvent("atPrevFrgnAddr", "keyup", togglePrevForeignAddressFields);

            //mailing foreign address
            addEvent("mailFrgnAddr", "change", toggleMailForeignAddressFields);
		    addEvent("mailFrgnAddr", "keyup", toggleMailForeignAddressFields);
		    
		    //previous address fields
            addEvent("atPrevAddrType", "change", togglePrevAddressFields);
		    addEvent("atPrevAddrType", "keyup", togglePrevAddressFields);
	        
	        //mailing address
            addEvent("mailAddrDif", "change", toggleMailAddr);
		    addEvent("mailAddrDif", "keyup", toggleMailAddr);
	        
	        if(getObj("showSaveSuccessLbl").innerHTML == "true")
	            showSaveSuccessAlert();
	            
	        if(getObj("pageFocusLbl").innerHTML.length > 0)
	            getObj(getObj("pageFocusLbl").innerHTML).focus();
	            
	        if(getObj("reqEmailLbl").innerHTML == "true")
            {
                changeLabel("pnlAtEmail", "Email Address:<span class=\"required\"> *</span>");
                toggleVerifyAttribute("atEmail", true);
                getObj("atEmail").isRequired = true;
            }
            else
            {
                changeLabel("pnlAtEmail", "Email Address:");
                toggleVerifyAttribute("atEmail", false);
                getObj("atEmail").isRequired = false;
            }
            
            if(getObj("showEmailVerifyLbl").innerHTML == "true")
                show("pnlAtEmailVerify");
            else
                hide("pnlAtEmailVerify");
                
            if(getObj("showMothersMaidenNameLbl").innerHTML == "true")
                show("pnlAtMothersMaidenName");
            else
                hide("pnlAtMothersMaidenName");
                
            if(getObj("showBestContactLbl").innerHTML == "true")
                show("pnlAtPhBestContact");
            else
                hide("pnlAtPhBestContact");
            
            if(getObj("showMonthlyHousingPaymentLbl").innerHTML == "true")
                show("pnlAtCrdtrHousePmt");
            else
                hide("pnlAtCrdtrHousePmt");
                
            if(getObj("showPersonalReferencesLbl").innerHTML == "true")
                show("pnlPersonalRef");
            else
                hide("pnlPersonalRef");
        }
        
        window.onbeforeunload = confirmExit;
        var needToConfirm = true;
        function confirmExit()
        {
            if(needToConfirm)
            {
                var myXMLHTTPRequeset = new S1XMLHTTPRequest();
                myXMLHTTPRequeset.xmlhttpGet("pageClose.aspx");
            }
        }
        
        function toggleEmploymentStatus()
        {
            var emp = getObj("selOccupation").options[getObj("selOccupation").selectedIndex].value;
            if(emp == "Primary Job" || emp == "Self-Employed")
            {
                show("EmploymentFieldsPanel");
                if(emp == "Self-Employed")
                    show(new Array("EmploymentFieldsPanel", 
		                "pnlAtPctOnr"));
            }
            else if(emp == "Retired")
            {
                show("AddIncomePanel");
                hide(new Array("EmploymentFieldsPanel", 
	                "pnlAtPctOnr", 
	                "AddIncomePanel"));
            }
            else
                hide(new Array("EmploymentFieldsPanel", 
	                "pnlAtPctOnr", 
	                "AddIncomePanel"));
        }
        
        function toggleAdditionalFields()
        {
            if(getObj("atOthIncAvail1").checked)
                show("AddIncomePanel");
        }
        
        function checkEmploymentStatus() 
        {
	        var emp = getObj("selOccupation").options[getObj("selOccupation").selectedIndex].value;
        	
	        // reset
	        hide(new Array("EmploymentFieldsPanel", 
	            "pnlAtPctOnr", 
	            "AddIncomePanel"));
            getObj("atOthIncAvail2").checked = true;
	        getObj("atOthIncAvail1").checked = false;
	        
	        if (emp == "Primary Job")
		        show("EmploymentFieldsPanel");
	        else if (emp == "Self-Employed")
		        show(new Array("EmploymentFieldsPanel", 
		            "pnlAtPctOnr"));	
	        else if (emp == "Retired") 
	        {		
		        show("AddIncomePanel");
		        getObj("atOthIncAvail2").checked = false;
		        getObj("atOthIncAvail1").checked = true;
		        getObj("atOthInc1").focus();
	        }
        }

        function checkYearsEmployed() 
        {
            if(getObj("atTimeEmpYr").selectedIndex > 0)
            {
                var emp = getObj("selOccupation").options[getObj("selOccupation").selectedIndex].value;
                if(emp == "Primary Job" || emp == "Self-Employed")
                {
	                if (parseInt(getObj("atTimeEmpYr").value) < 2)
		                show("pnlFormerEmploymentInfo");
	                else
		                hide("pnlFormerEmploymentInfo");
		        }
		        else
                    hide("pnlFormerEmploymentInfo");
		    }
		    else
                hide("pnlFormerEmploymentInfo");
        }


        function checkPersonalDetails() 
        {
	        var el = getObj("hmPersonalDetails");
	        if (!el) 
	            return;

	        if (el.checked)
		        hide("pnlPersonalDetails");
	        else
		        show("pnlPersonalDetails");
        }

        function checkIncomeSource()
        {
	        // If it's a part-time or second job, show additional fields
	        var el = getObj("atOthIncSrc1");
	        if (el.options[el.selectedIndex].value == "P/T OR SECOND JOB")
		        show("atOthInc1ExtraFields");		
	        else 
		        hide("atOthInc1ExtraFields");
        }

        function checkAppType() 
        {
	        if (getObj("anRegbType").options.selectedIndex > 1)
		        show("pnlSpouse");
	        else
	        {
	            getObj("atSpouse").options.selectedIndex = 0;
	            getObj("atJointAssetsAndLiabilities").options.selectedIndex = 0;
	            
		        hide("pnlSpouse");
		    }
        }

        function checkFullTime() 
        {
	        var el = getObj("radFullTime1");
	        if (el.checked) 
	        {
		        show(new Array("pnlAddressInfo",
		            "pnlCitStatus",
		            "pnlSchoolYear",
		            "pnlSchoolName",
		            "pnlPageNav"));
		            
		        hide("pnlError");
	        }
	        else 
	        {
		        hide(new Array("pnlAddressInfo", 
		            "pnlCitStatus", 
		            "pnlSchoolYear", 
		            "pnlSchoolName", 
		            "pnlHomeAddress", 
		            "pnlSchoolAddress", 
		            "pnlPageNav"));
		            
		        setError("You must be a full-time student to apply for a Student VISA.");
	        }
        }

        function checkAddressType() 
        {
	        var el = getObj("radAddressType1");
	        if (el.checked) 
	        {
		        getObj("radHaveSchool1").checked = false;
		        getObj("radHaveSchool2").checked = false;		
		        show("pnlHaveSchoolAddress");
		        hide(new Array("pnlHomeAddress", 
		            "pnlHaveHomeAddress"));	
	        }
	        else 
	        {
		        getObj("radHaveHome1").checked = false;
		        getObj("radHaveHome2").checked = false;	
		        show(new Array("pnlHomeAddress", 
		            "pnlHaveHomeAddress"));
		            
		        hide(new Array("pnlHomeAddress", 
		            "pnlHaveSchoolAddress", 
		            "pnlSchoolAddress"));
	        }
        }
        
        function toggleAlimony()
        {
            var el = getObj("atAlimony");
            if(el.options[el.selectedIndex].value == "Yes")
                show("pnlAlimonyExp")
            else
            {
                getObj("atAlimonyExp").value = "";
                hide("pnlAlimonyExp")
            }
        }
        
        function toggleCoMaker()
        {
            var el = getObj("atComaker");
            if(el.options[el.selectedIndex].value == "Yes")
                show("pnlCoMakerExp")
            else
            {
                getObj("atCoMakerExp").value = "";
                hide("pnlCoMakerExp")
            }
        }
        
        function toggleDeclaredBankruptcy()
        {
            var el = getObj("atDeclaredBankruptcy");
            if(el.options[el.selectedIndex].value == "Yes")
                show("pnlDeclaredBankruptcyExp")
            else
            {
                getObj("atDeclaredBankruptcyExp").value = "";
                hide("pnlDeclaredBankruptcyExp")
            }
        }
        
        function toggleDelinquent()
        {
            var el = getObj("atDelinquent");
            if(el.options[el.selectedIndex].value == "Yes")
                show("pnlDelinquentExp")
            else
            {
                getObj("atDelinquentExp").value = "";
                hide("pnlDelinquentExp")
            }
        }
        
        function toggleDownPaymentBorrowed()
        {
            var el = getObj("atDownPaymentBorrowed");
            if(el.options[el.selectedIndex].value == "Yes")
                show("pnlDownPaymentBorrowedExp")
            else
            {
                getObj("atDownPaymentBorrowedExp").value = "";
                hide("pnlDownPaymentBorrowedExp")
            }
        }
        
        function toggleLawSuit()
        {
            var el = getObj("atLawSuit");
            if(el.options[el.selectedIndex].value == "Yes")
                show("pnlLawSuitExp")
            else
            {
                getObj("atLawSuitExp").value = "";
                hide("pnlLawSuitExp")
            }
        }
        
        function toggleLoanObligation()
        {
            var el = getObj("atLoanObligation");
            if(el.options[el.selectedIndex].value == "Yes")
                show("pnlLoanObligationExp")
            else
            {
                getObj("atLoanObligationExp").value = "";
                hide("pnlLoanObligationExp")
            }
        }
        
        function toggleOutstandingJudgements()
        {
            var el = getObj("atOutstandingJudgements");
            if(el.options[el.selectedIndex].value == "Yes")
                show("pnlOutstandingJudgementsExp")
            else
            {
                getObj("atOutstandingJudgementsExp").value = "";
                hide("pnlOutstandingJudgementsExp")
            }
        }
        
        function toggleProperyForeclosed()
        {
            var el = getObj("atProperyForeclosed");
            if(el.options[el.selectedIndex].value == "Yes")
                show("pnlProperyForeclosedExp")
            else
            {
                getObj("atProperyForeclosedExp").value = "";
                hide("pnlProperyForeclosedExp")
            }
        }
        
        function toggleOwnershipInterest()
        {
            var el = getObj("atOwnershipInterest");
            if(el.options[el.selectedIndex].value == "Yes")
                show("pnlOwnershipInterestPropType")
            else
            {
                getObj("atOwnershipInterestPropType").selectedIndex = 0;
                getObj("atTitleHeld").selectedIndex = 0;
                hide("pnlOwnershipInterestPropType")
            }
        }
        
        function togglePrevAddr() 
        {
            if(getObj("showPrevAddrLbl").innerHTML == "true" && getObj("atTimeAddrYr").options.selectedIndex > 0)
            {
                var months = parseInt(getObj("atTimeAddrYr").options[getObj("atTimeAddrYr").options.selectedIndex].value * 12);
                months += parseInt(getObj("atTimeAddrMo").options[getObj("atTimeAddrMo").options.selectedIndex].value);

                if(months < parseInt(getObj("showPrevAddrMonthsLbl").innerHTML))
                {
                    show("pnlPrevAddr");
                    togglePrevAddressFields();
                    togglePrevForeignAddressFields();
                }
                else
                    hide("pnlPrevAddr");
            }
            else
                hide("pnlPrevAddr");
        }
        
        function togglePrevAddressFields()
        {
            var el = getObj("atPrevAddrType");
            if(el.options.selectedIndex == 0) 
            {
                if(getObj("useSingleAddrLineLbl").innerHTML == "true")
                {
                    hide("pnlPrevStandardAddr");
                    show("pnlPrevStandardSingleLineAddr");
                }
                else
                {
                    show("pnlPrevStandardAddr");
                    hide("pnlPrevStandardSingleLineAddr");
                }
                
                hide(new Array("pnlPrevRuralAddr",
                    "pnlPrevPOBoxAddr"));
            }
            else if(el.options.selectedIndex == 1) 
            {
                show("pnlPrevRuralAddr");
                hide(new Array("pnlPrevStandardAddr",
                    "pnlPrevStandardSingleLineAddr",
                    "pnlPrevPOBoxAddr"));
            }   
            else if(el.options.selectedIndex == 2) 
            {
                show("pnlPrevPOBoxAddr");
                hide(new Array("pnlPrevStandardAddr",
                    "pnlPrevStandardSingleLineAddr",
                    "pnlPrevRuralAddr"));
            }
        }
        
        function toggleMailAddr() 
        {
            if(getObj("hideMailAddrDifLbl").innerHTML == "true")
                hide(new Array("pnlMailAddrDif",
                    "pnlMailAddr"));
            else
            {
                var el = getObj("mailAddrDif");
                
                if (el.options.selectedIndex == 1)
                {
	                show("pnlMailAddr");
                    toggleMailForeignAddressFields();
                }
                else
                    hide("pnlMailAddr");
            }
        }
        
        function togglePrevForeignAddressFields() 
        {
            if (getObj("pnlAtFrgnAddr").style.display == "")
            {
                show("pnlAtPrevFrgnAddr");
                var el = getObj("atPrevFrgnAddr");
                if(el.options.selectedIndex == 0)
                {
                    hide(new Array("pnlAtPrevState",
                        "pnlAtPrevZip"));

                    show(new Array("pnlAtPrevProv",
                        "pnlAtPrevCntry",
                        "pnlAtPrevPstlCd"));
                }
                else
                {
                    hide(new Array("pnlAtPrevProv",
                        "pnlAtPrevCntry",
                        "pnlAtPrevPstlCd"));
                    
                    show(new Array("pnlAtPrevState",
                        "pnlAtPrevZip"));
                }
            }
            else
                hide("pnlAtPrevFrgnAddr");
        }

        function toggleMailForeignAddressFields() 
        {
            if (getObj("pnlAtFrgnAddr").style.display == "")
            {
                show("pnlMailFrgnAddr");
                var el = getObj("mailFrgnAddr");
                if(el.options.selectedIndex == 0)
                {
                    hide(new Array("pnlMailState",
                        "pnlMailZip"));

                    show(new Array("pnlMailProv",
                        "pnlMailCntry",
                        "pnlMailPstlCd"));
                }
                else
                {
                    hide(new Array("pnlMailProv",
                        "pnlMailCntry",
                        "pnlMailPstlCd"));
                    
                    show(new Array("pnlMailState",
                        "pnlMailZip"));
                }
            }
            else
                hide("pnlMailFrgnAddr");
        }
        
        function toggleForeignAddressFields() 
        {
            var el = getObj("atFrgnAddr");
            if(el.options.selectedIndex == 0)
            {
                hide(new Array("pnlAtState",
                    "pnlAtZip"));

                show(new Array("pnlAtProv",
                    "pnlAtCntry",
                    "pnlAtPstlCd"));
            }
            else
            {
                hide(new Array("pnlAtProv",
                    "pnlAtCntry",
                    "pnlAtPstlCd",
                    "pnlAtForeignPh",
                    "pnlAtForeignCellPh"));
                
                show(new Array("pnlAtState",
                    "pnlAtZip",
                    "pnlAtPh",
                    "pnlAtCellPh"));
            }

            toggleForeignPhoneFields();
        }
        
        function toggleForeignPhoneFields()
        {
            if(getObj("showForeignPhoneFields").innerHTML == "true")
            {
                if(getObj("atAddrType").options.selectedIndex == 1 || getObj("atFrgnAddr").options.selectedIndex == 0)
                {
                    hide(new Array("pnlAtPh",
                        "pnlAtCellPh"));
                        
                    show(new Array("pnlAtForeignPh",
                        "pnlAtForeignCellPh"));
                }
                else
                {
                    hide(new Array("pnlAtForeignPh",
                        "pnlAtForeignCellPh"));
                        
                    show(new Array("pnlAtPh",
                        "pnlAtCellPh"));
                }
            }
        }
        
        function toggleAddressFields()
        {
            var el = getObj("atAddrType");
            if(el.options.selectedIndex == 0) 
            {
                if(getObj("useSingleAddrLineLbl").innerHTML == "true")
                {
                    hide("pnlStandardAddr");
                    show("pnlStandardSingleLineAddr");
                }
                else
                {
                    show("pnlStandardAddr");
                    hide("pnlStandardSingleLineAddr");
                }
                
                hide(new Array("pnlRuralAddr",
                    "pnlPOBoxAddr"));
            }
            else if(el.options.selectedIndex == 1) 
            {
                show("pnlRuralAddr");
                hide(new Array("pnlStandardAddr",
                    "pnlStandardSingleLineAddr",
                    "pnlPOBoxAddr"));
            }   
            else if(el.options.selectedIndex == 2) 
            {
                show("pnlPOBoxAddr");
                hide(new Array("pnlStandardAddr",
                    "pnlStandardSingleLineAddr",
                    "pnlRuralAddr"));
                    
               if(getObj("toggleMailingAddrFieldsLbl").innerHTML == "true")
                {
                    getObj("mailAddrDif").options.selectedIndex = 1;
                    toggleMailAddr();
                }
            }
            
            toggleForeignPhoneFields();
        }