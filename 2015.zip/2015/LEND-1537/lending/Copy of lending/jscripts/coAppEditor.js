window.onbeforeunload = confirmExit;
        var needToConfirm = true;
        function confirmExit()
        {
            if(needToConfirm)
            {
                var myXMLHTTPRequeset = new S1XMLHTTPRequest();
                myXMLHTTPRequeset.xmlhttpGet("pageClose.aspx");
            }
        }
    
        addEvent(window, "load", Init);
        function Init()
        {
            toggleJointCredit();
            hide("pnlSpacer1");
            
            //join credit
		    addEvent("coAppJointCredit", "change", toggleJointCredit);
		    addEvent("coAppJointCredit", "keyup", toggleJointCredit);
        }    
        
        function toggleJointCredit()
        {
            if(getObj("showJointCreditLbl").innerHTML == "true")
                show("pnlCoAppJointCredit");
            else
                hide("pnlCoAppJointCredit");
        }