addEvent(window, "load", Init);
        
        function Init()
        {
            checkLoanType();
            
            //applicant
            togglePrevAddr();
            toggleForeignAddressFields();
            toggleAddressFields();
            toggleMailAddr();
            toggleEmploymentStatus();
            toggleAdditionalFields();
            checkYearsEmployed();
            checkAppType();
            
            //coApp
            toggleCoAppPrevAddr();
            toggleCoAppForeignAddressFields();
            toggleCoAppAddressFields();
            toggleCoAppMailAddr();
            toggleCoAppEmploymentStatus();
            toggleCoAppAdditionalFields();
            checkCoAppYearsEmployed();
            
            //property type
            toggleOwnRealEstate();
            toggleNumberUnits();
            toggleTransTypeFields();
            togglePropertyFinanced();
            toggleTaxAndInsFields();
            toggleEscrowTaxAndInsFields();
            
            //Declarations
            toggleAlimony();
            toggleCoMaker();
            toggleDeclaredBankruptcy();
            toggleProperyForeclosed();
            toggleDelinquent();
            toggleDownPaymentBorrowed();
            toggleLawSuit();
            toggleLoanObligation();
            toggleOutstandingJudgements();
            toggleOwnershipInterest();
            
            toggleCoAppAlimony();
            toggleCoAppCoMaker();
            toggleCoAppDeclaredBankruptcy();
            toggleCoAppProperyForeclosed();
            toggleCoAppDelinquent();
            toggleCoAppDownPaymentBorrowed();
            toggleCoAppLawSuit();
            toggleCoAppLoanObligation();
            toggleCoAppOutstandingJudgements();
            toggleCoAppOwnershipInterest();
            
            if(getObj("showSaveSuccessLbl").innerHTML == "true")
	            showSaveSuccessAlert();
        }
        
        window.onbeforeunload = confirmExit;
        var needToConfirm = true;
        function confirmExit()
        {
            if(needToConfirm)
            {
                var myXMLHTTPRequeset = new S1XMLHTTPRequest();
                myXMLHTTPRequeset.xmlhttpGet("pageClose.aspx");
            }
        }
        
        function checkAccept()
        {
            if(getObj("acceptDDL").selectedIndex == 1)
            {
                hide("Continue");
                show("ContinueDisabled");
                
                return true;
            }
            else
            {
                getObj("pnlError").innerHTML = "You must agree to continue.";
                show("pnlError");
                scroll(0,0);
                
                return false;
            }
        }
        
        function checkLoanType() 
        {
	        if (getObj("anGETTransTypeHid").options[getObj("anGETTransTypeHid").selectedIndex].value == "Refinance")
		        show("pnlRefiInfo");
	        else 
		        hide("pnlRefiInfo");
		    
		    if(getObj("radForSale").innerHTML == "Yes")
		        show("ListedPanel");
		    else
		        hide("ListedPanel");
        }
        
        function togglePrevAddr() 
        {
            if(getObj("showPrevAddrLbl").innerHTML == "true" && getObj("atTimeAddrYrHid").options.selectedIndex > 0)
            {
                var months = parseInt(getObj("atTimeAddrYrHid").options[getObj("atTimeAddrYrHid").options.selectedIndex].value * 12);
                months += parseInt(getObj("atTimeAddrMoHid").options[getObj("atTimeAddrMoHid").options.selectedIndex].value);

                if(months < parseInt(getObj("showPrevAddrMonthsLbl").innerHTML))
                {
                    show("pnlPrevAddr");
                    togglePrevAddressFields();
                    togglePrevForeignAddressFields();
                }
                else
                    hide("pnlPrevAddr");
            }
            else
                hide("pnlPrevAddr");
        }
        
        function togglePrevAddressFields()
        {
            var el = getObj("atPrevAddrTypeHid");
            if(el.options.selectedIndex == 0) 
            {
                if(getObj("useSingleAddrLineLbl").innerHTML == "true")
                {
                    hide("pnlPrevStandardAddr");
                    show("pnlPrevStandardSingleLineAddr");
                }
                else
                {
                    show("pnlPrevStandardAddr");
                    hide("pnlPrevStandardSingleLineAddr");
                }
                
                hide(new Array("pnlPrevRuralAddr",
                    "pnlPrevPOBoxAddr"));
            }
            else if(el.options.selectedIndex == 1) 
            {
                show("pnlPrevRuralAddr");
                hide(new Array("pnlPrevStandardAddr",
                    "pnlPrevPOBoxAddr"));
            }   
            else if(el.options.selectedIndex == 2) 
            {
                show("pnlPrevPOBoxAddr");
                hide(new Array("pnlPrevStandardAddr",
                    "pnlPrevRuralAddr"));
            }
        }
        
        function togglePrevForeignAddressFields() 
        {
            if (getObj("pnlAtFrgnAddr").style.display == "")
            {
                show("pnlAtPrevFrgnAddr");
                var el = getObj("atPrevFrgnAddrHid");
                if(el.options.selectedIndex == 0)
                {
                    hide(new Array("pnlAtPrevState",
                        "pnlAtPrevZip"));

                    show(new Array("pnlAtPrevProv",
                        "pnlAtPrevCntry",
                        "pnlAtPrevPstlCd"));
                }
                else
                {
                    hide(new Array("pnlAtPrevProv",
                        "pnlAtPrevCntry",
                        "pnlAtPrevPstlCd"));
                    
                    show(new Array("pnlAtPrevState",
                        "pnlAtPrevZip"));
                }
            }
            else
                hide("pnlAtPrevFrgnAddr");
        }
        
        function toggleForeignAddressFields() 
        {
            var el = getObj("atFrgnAddrHid");
            if(el.options.selectedIndex == 0)
            {
                hide(new Array("pnlAtState",
                    "pnlAtZip"));

                show(new Array("pnlAtProv",
                    "pnlAtCntry",
                    "pnlAtPstlCd"));
            }
            else
            {
                hide(new Array("pnlAtProv",
                    "pnlAtCntry",
                    "pnlAtPstlCd",
                    "pnlAtForeignPh",
                    "pnlAtForeignCellPh"));
                
                show(new Array("pnlAtState",
                    "pnlAtZip",
                    "pnlAtPh",
                    "pnlAtCellPh"));
            }

            toggleForeignPhoneFields();
        }
        
        function toggleAddressFields()
        {
            var el = getObj("atAddrTypeHid");
            if(el.options.selectedIndex == 0) 
            {
                if(getObj("useSingleAddrLineLbl").innerHTML == "true")
                {
                    hide("pnlStandardAddr");
                    show("pnlStandardSingleLineAddr");
                }
                else
                {
                    show("pnlStandardAddr");
                    hide("pnlStandardSingleLineAddr");
                }
                hide(new Array("pnlRuralAddr",
                    "pnlPOBoxAddr"));
            }
            else if(el.options.selectedIndex == 1) 
            {
                show("pnlRuralAddr");
                hide(new Array("pnlStandardAddr",
                    "pnlPOBoxAddr"));
            }   
            else if(el.options.selectedIndex == 2) 
            {
                show("pnlPOBoxAddr");
                hide(new Array("pnlStandardAddr",
                    "pnlRuralAddr"));
                    
               if(getObj("toggleMailingAddrFieldsLbl").innerHTML == "true")
                {
                    getObj("mailAddrDifHid").options.selectedIndex = 1;
                    toggleMailAddr();
                }
            }
            
            toggleForeignPhoneFields();
        }
        
        function toggleForeignPhoneFields()
        {
            if(getObj("showForeignPhoneFields").innerHTML == "true")
            {
                if(getObj("atAddrTypeHid").options.selectedIndex == 1 || getObj("atFrgnAddrHid").options.selectedIndex == 0)
                {
                    hide(new Array("pnlAtPh",
                        "pnlAtCellPh"));
                        
                    show(new Array("pnlAtForeignPh",
                        "pnlAtForeignCellPh"));
                }
                else
                {
                    hide(new Array("pnlAtForeignPh",
                        "pnlAtForeignCellPh"));
                        
                    show(new Array("pnlAtPh",
                        "pnlAtCellPh"));
                }
            }
        }
        
        function toggleMailAddr() 
        {
            if(getObj("hideMailAddrDifLbl").innerHTML == "true")
                hide(new Array("pnlMailAddrDif",
                    "pnlMailAddr"));
            else
            {
                var el = getObj("mailAddrDifHid");
                
                if (el.options.selectedIndex == 1)
                {
	                show("pnlMailAddr");
                    toggleMailForeignAddressFields();
                }
                else
                    hide("pnlMailAddr");
            }
        }
        
        function toggleMailForeignAddressFields() 
        {
            if (getObj("pnlAtFrgnAddr").style.display == "")
            {
                show("pnlMailFrgnAddr");
                var el = getObj("mailFrgnAddrHid");
                if(el.options.selectedIndex == 0)
                {
                    hide(new Array("pnlMailState",
                        "pnlMailZip"));

                    show(new Array("pnlMailProv",
                        "pnlMailCntry",
                        "pnlMailPstlCd"));
                }
                else
                {
                    hide(new Array("pnlMailProv",
                        "pnlMailCntry",
                        "pnlMailPstlCd"));
                    
                    show(new Array("pnlMailState",
                        "pnlMailZip"));
                }
            }
            else
                hide("pnlMailFrgnAddr");
        }
        
        function toggleEmploymentStatus()
        {
            var emp = getObj("selOccupation").innerHTML;
            if(emp == "Primary Job" || emp == "Self-Employed")
            {
                show("EmploymentFieldsPanel");
                if(emp == "Self-Employed")
                    show(new Array("EmploymentFieldsPanel", 
		                "pnlAtPctOnr"));
            }
            else if(emp == "Retired")
            {
                show("AddIncomePanel");
                hide(new Array("EmploymentFieldsPanel", 
	                "pnlAtPctOnr", 
	                "AddIncomePanel"));
            }
            else
                hide(new Array("EmploymentFieldsPanel", 
	                "pnlAtPctOnr", 
	                "AddIncomePanel"));
        }
        
        function toggleAdditionalFields()
        {
            if(getObj("atOthIncAvail").innerHTML == "Yes")
                show("AddIncomePanel");
        }
        
        function checkYearsEmployed() 
        {
            if(getObj("atTimeEmpYrHid").selectedIndex > 0)
            {
	            if (parseInt(getObj("atTimeEmpYrHid").value) < 2)
		            show("pnlFormerEmploymentInfo");
	            else
		            hide("pnlFormerEmploymentInfo");
		   }
		   else
		        hide("pnlFormerEmploymentInfo");
        }
        
        function checkAppType() 
        {
	        if (getObj("anRegbType").innerHTML != "Individual")
		        show("pnlSpouse");
        }
        
        function toggleCoAppPrevAddr() 
        {
            if(getObj("showPrevAddrLbl").innerHTML == "true" && getObj("coAppTimeAddrYrHid").options.selectedIndex > 0)
            {
                var months = parseInt(getObj("coAppTimeAddrYrHid").options[getObj("coAppTimeAddrYrHid").options.selectedIndex].value * 12);
                months += parseInt(getObj("coAppTimeAddrMoHid").options[getObj("coAppTimeAddrMoHid").options.selectedIndex].value);

                if(months < parseInt(getObj("showPrevAddrMonthsLbl").innerHTML))
                {
                    show("pnlCoAppPrevAddr");
                    toggleCoAppPrevAddressFields();
                    toggleCoAppPrevForeignAddressFields();
                }
                else
                    hide("pnlCoAppPrevAddr");
            }
            else
                hide("pnlCoAppPrevAddr");
        }
        
        function toggleCoAppPrevAddressFields()
        {
            var el = getObj("coAppPrevAddrTypeHid");
            if(el.options.selectedIndex == 0) 
            {
                if(getObj("useSingleAddrLineLbl").innerHTML == "true")
                {
                    hide("pnlCoAppPrevStandardAddr");
                    show("pnlCoAppPrevStandardSingleLineAddr");
                }
                else
                {
                    show("pnlCoAppPrevStandardAddr");
                    hide("pnlCoAppPrevStandardSingleLineAddr");
                }
                
                hide(new Array("pnlCoAppPrevRuralAddr",
                    "pnlCoAppPrevPOBoxAddr"));
            }
            else if(el.options.selectedIndex == 1) 
            {
                show("pnlCoAppPrevRuralAddr");
                hide(new Array("pnlCoAppPrevStandardAddr",
                    "pnlCoAppPrevPOBoxAddr"));
            }   
            else if(el.options.selectedIndex == 2) 
            {
                show("pnlCoAppPrevPOBoxAddr");
                hide(new Array("pnlCoAppPrevStandardAddr",
                    "pnlCoAppPrevRuralAddr"));
            }
        }
        
        function toggleCoAppPrevForeignAddressFields() 
        {
            if (getObj("pnlCoAppFrgnAddr").style.display == "")
            {
                show("pnlCoAppPrevFrgnAddr");
                var el = getObj("coAppPrevFrgnAddrHid");
                if(el.options.selectedIndex == 0)
                {
                    hide(new Array("pnlCoAppPrevState",
                        "pnlCoAppPrevZip"));

                    show(new Array("pnlCoAppPrevProv",
                        "pnlCoAppPrevCntry",
                        "pnlCoAppPrevPstlCd"));
                }
                else
                {
                    hide(new Array("pnlCoAppPrevProv",
                        "pnlCoAppPrevCntry",
                        "pnlCoAppPrevPstlCd"));
                    
                    show(new Array("pnlCoAppPrevState",
                        "pnlCoAppPrevZip"));
                }
            }
            else
                hide("pnlCoAppPrevFrgnAddr");
        }
        
        function toggleCoAppForeignAddressFields() 
        {
            var el = getObj("coAppFrgnAddrHid");
            if(el.options.selectedIndex == 0)
            {
                hide(new Array("pnlCoAppState",
                    "pnlCoAppZip"));

                show(new Array("pnlCoAppProv",
                    "pnlCoAppCntry",
                    "pnlCoAppPstlCd"));
            }
            else
            {
                hide(new Array("pnlCoAppProv",
                    "pnlCoAppCntry",
                    "pnlCoAppPstlCd",
                    "pnlCoAppForeignPh",
                    "pnlCoAppForeignCellPh"));
                
                show(new Array("pnlCoAppState",
                    "pnlCoAppZip",
                    "pnlCoAppPh",
                    "pnlCoAppCellPh"));
            }

            toggleCoAppForeignPhoneFields();
        }
        
        function toggleCoAppForeignPhoneFields()
        {
            if(getObj("showForeignPhoneFields").innerHTML == "true")
            {
                if(getObj("coAppAddrTypeHid").options.selectedIndex == 1 || getObj("coAppFrgnAddrHid").options.selectedIndex == 0)
                {
                    hide(new Array("pnlCoAppPh",
                        "pnlCoAppCellPh"));
                        
                    show(new Array("pnlCoAppForeignPh",
                        "pnlCoAppForeignCellPh"));
                }
                else
                {
                    hide(new Array("pnlCoAppForeignPh",
                        "pnlCoAppForeignCellPh"));
                        
                    show(new Array("pnlCoAppPh",
                        "pnlCoAppCellPh"));
                }
            }
        }
        
        function toggleCoAppAddressFields()
        {
            var el = getObj("coAppAddrTypeHid");
            if(el.options.selectedIndex == 0) 
            {
                if(getObj("useSingleAddrLineLbl").innerHTML == "true")
                {
                    hide("pnlCoAppStandardAddr");
                    show("pnlCoAppStandardSingleLineAddr");
                }
                else
                {
                    show("pnlCoAppStandardAddr");
                    hide("pnlCoAppStandardSingleLineAddr");
                }
                
                hide(new Array("pnlCoAppRuralAddr",
                    "pnlCoAppPOBoxAddr"));
            }
            else if(el.options.selectedIndex == 1) 
            {
                show("pnlCoAppRuralAddr");
                hide(new Array("pnlCoAppStandardAddr",
                    "pnlCoAppPOBoxAddr"));
            }   
            else if(el.options.selectedIndex == 2) 
            {
                show("pnlCoAppPOBoxAddr");
                hide(new Array("pnlCoAppStandardAddr",
                    "pnlCoAppRuralAddr"));
                    
               if(getObj("toggleMailingAddrFieldsLbl").innerHTML == "true")
                {
                    getObj("coAppMailAddrDif").options.selectedIndex = 1;
                    toggleCoAppMailAddr();
                }
            }
            
            toggleCoAppForeignPhoneFields();
        }
        
        function toggleCoAppMailAddr() 
        {
            if(getObj("hideMailAddrDifLbl").innerHTML == "true")
                hide(new Array("pnlCoAppMailAddrDif",
                    "pnlCoAppMailAddr"));
            else
            {
                var el = getObj("coAppMailAddrDif");
                
                if (el.options.selectedIndex == 1)
                {
	                show("pnlCoAppMailAddr");
                    toggleCoAppMailForeignAddressFields();
                }
                else
                    hide("pnlCoAppMailAddr");
            }
        }
        
        function toggleCoAppMailForeignAddressFields() 
        {
            if (getObj("pnlCoAppFrgnAddr").style.display == "")
            {
                show("pnlCoAppMailFrgnAddr");
                var el = getObj("coAppMailFrgnAddrHid");
                if(el.options.selectedIndex == 0)
                {
                    hide(new Array("pnlCoAppMailState",
                        "pnlCoAppMailZip"));

                    show(new Array("pnlCoAppMailProv",
                        "pnlCoAppMailCntry",
                        "pnlCoAppMailPstlCd"));
                }
                else
                {
                    hide(new Array("pnlCoAppMailProv",
                        "pnlCoAppMailCntry",
                        "pnlCoAppMailPstlCd"));
                    
                    show(new Array("pnlCoAppMailState",
                        "pnlCoAppMailZip"));
                }
            }
            else
                hide("pnlCoAppMailFrgnAddr");
        }
        
        function toggleCoAppEmploymentStatus()
        {
            var emp = getObj("coAppSelOccupationHid").options[getObj("coAppSelOccupationHid").selectedIndex].value;
            if(emp == "Primary Job" || emp == "Self-Employed")
            {
                show("CoAppEmploymentFieldsPanel");
                if(emp == "Self-Employed")
                    show(new Array("CoAppEmploymentFieldsPanel", 
	                    "pnlCoAppPctOnr"));
            }
            else if(emp == "Retired")
            {
                show("coAppAddIncomePanel");
                hide(new Array("CoAppEmploymentFieldsPanel", 
                    "pnlCoAppPctOnr", 
                    "coAppAddIncomePanel"));
            }
            else
                hide(new Array("CoAppEmploymentFieldsPanel", 
                    "pnlCoAppPctOnr", 
                    "coAppAddIncomePanel"));
        }
        
        function toggleCoAppAdditionalFields()
        {
            if(getObj("coAppOthIncAvail").innerHTML == "Yes")
                show("coAppAddIncomePanel");
        }
        
        function checkCoAppYearsEmployed() 
        {
            if(getObj("coAppTimeEmpYrHid").selectedIndex > 0)
            {
	            if (parseInt(getObj("coAppTimeEmpYrHid").value) < 2)
		            show("pnlCoAppFormerEmploymentInfo");
	            else
		            hide("pnlCoAppFormerEmploymentInfo");
            }
            else
                hide("pnlCoAppFormerEmploymentInfo");
        }
        
        function toggleOwnRealEstate()
        {
            var el = getObj("anOwnRealEstatePropHid");
            if (el.options[el.selectedIndex].value == "Yes")
                show("pnlOwnRealEstate");
            else
                hide("pnlOwnRealEstate");
        }
        
        function toggleNumberUnits()
        {
            var el = getObj("anNumberUnitsHid");
	        if (el.options[el.selectedIndex].value != "" && el.options[el.selectedIndex].value != "1")
		        show("RentalIncomePanel");
	        else
		        hide("RentalIncomePanel");
        }
        
        function toggleTransTypeFields()
        {
            if(getObj("transTypeLbl").innerHTML == "Refinance")
            {
                hide(new Array("pnlAnPurchasePrice",
                    "pnlAnDownPayment",
                    "pnlAnClosingCostPaidBySeller",
                    "pnlAnAddrOfProperty",
                    "pnlAddress",
                    "FinanceSymAddPanel"));
            }
            else if(getObj("transTypeLbl").innerHTML == "Purchase")
            {
                hide(new Array("pnlAnAddrOfProperty",
                    "pnlAnPropFinanced",
                    "pnlAnRefinanceAmount",
                    "pnlAnSpecificUseOfProceeds",
                    "pnlAnPropertyValue",
                    "pnlAnMortgageBalance",
                    "pnlPhyPrchYr",
                    "pnlPhyPropDisposition",
                    "pnlPhyRefiCounty",
                    "pnlPhyFinanced",
                    "pnlPhyRefiPropType"));
                show("pnlAddress");
            }
            else if(getObj("transTypeLbl").innerHTML == "PreApproval")
            {
                hide(new Array("pnlAnAddrOfProperty",
                    "pnlAddress",
                    "pnlAnPropFinanced",
                    "pnlAnRefinanceAmount",
                    "pnlAnSpecificUseOfProceeds",
                    "pnlAnPropertyValue",
                    "pnlAnMortgageBalance",
                    "pnlPhyPrchYr",
                    "pnlPhyRefiCounty",
                    "pnlPhyFinanced",
                    "pnlPhyPropDisposition",
                    "pnlPhyRefiPropType"));
            }
        }
        
        function togglePropertyFinanced()
        {
            if(getObj("phyFinanced").innerHTML == "Yes")
                show("PropertyFinancedPanel");
            else
                hide("PropertyFinancedPanel");
        }
        
        function toggleTaxAndInsFields()
        {
            if(getObj("anKnowTaxAndIns").innerHTML == "Yes")
            {
                show("pnlTaxAndIns");
                hide("taxAndInsText");
            }
            else if(getObj("anKnowTaxAndIns").innerHTML == "No")
            {
                show("taxAndInsText");
                hide("pnlTaxAndIns");
            }
            else
            {
                hide(new Array("pnlTaxAndIns",
                    "taxAndInsText"));
            }
        }
        
        function toggleEscrowTaxAndInsFields()
        {
            if(getObj("anEscrowInsAndTaxes").innerHTML == "No")
                show("anEscrowInsAndTaxesText");
            else
                hide("anEscrowInsAndTaxesText");
        }
        
        function toggleAlimony()
        {
            var el = getObj("atAlimony");
            if(el.innerHTML == "Yes")
                show("pnlAlimonyExp")
            else
                hide("pnlAlimonyExp")
        }
        
        function toggleCoMaker()
        {
            var el = getObj("atComaker");
            if(el.innerHTML == "Yes")
                show("pnlCoMakerExp")
            else
                hide("pnlCoMakerExp")
        }
        
        function toggleDeclaredBankruptcy()
        {
            var el = getObj("atDeclaredBankruptcy");
            if(el.innerHTML == "Yes")
                show("pnlDeclaredBankruptcyExp")
            else
                hide("pnlDeclaredBankruptcyExp")
        }
        
        function toggleDelinquent()
        {
            var el = getObj("atDelinquent");
            if(el.innerHTML == "Yes")
                show("pnlDelinquentExp")
            else
                hide("pnlDelinquentExp")
        }
        
        function toggleDownPaymentBorrowed()
        {
            var el = getObj("atDownPaymentBorrowed");
            if(el.innerHTML == "Yes")
                show("pnlDownPaymentBorrowedExp")
            else
                hide("pnlDownPaymentBorrowedExp")
        }
        
        function toggleLawSuit()
        {
            var el = getObj("atLawSuit");
            if(el.innerHTML == "Yes")
                show("pnlLawSuitExp")
            else
                hide("pnlLawSuitExp")
        }
        
        function toggleLoanObligation()
        {
            var el = getObj("atLoanObligation");
            if(el.innerHTML == "Yes")
                show("pnlLoanObligationExp")
            else
                hide("pnlLoanObligationExp")
        }
        
        function toggleOutstandingJudgements()
        {
            var el = getObj("atOutstandingJudgements");
            if(el.innerHTML == "Yes")
                show("pnlOutstandingJudgementsExp")
            else
                hide("pnlOutstandingJudgementsExp")
        }
        
        function toggleProperyForeclosed()
        {
            var el = getObj("atProperyForeclosed");
            if(el.innerHTML == "Yes")
                show("pnlProperyForeclosedExp")
            else
                hide("pnlProperyForeclosedExp")
        }
        
        function toggleOwnershipInterest()
        {
            var el = getObj("atOwnershipInterest");
            if(el.innerHTML == "Yes")
                show("pnlOwnershipInterestPropType")
            else
                hide("pnlOwnershipInterestPropType")
        }
        
        //
        function toggleCoAppAlimony()
        {
            var el = getObj("coAppAlimony");
            if(el.innerHTML == "Yes")
                show("pnlCoAppAlimonyExp")
            else
                hide("pnlCoAppAlimonyExp")
        }
        
        function toggleCoAppCoMaker()
        {
            var el = getObj("coAppComaker");
            if(el.innerHTML == "Yes")
                show("pnlCoAppCoMakerExp")
            else
                hide("pnlCoAppCoMakerExp")
        }
        
        function toggleCoAppDeclaredBankruptcy()
        {
            var el = getObj("coAppDeclaredBankruptcy");
            if(el.innerHTML == "Yes")
                show("pnlCoAppDeclaredBankruptcyExp")
            else
                hide("pnlCoAppDeclaredBankruptcyExp")
        }
        
        function toggleCoAppDelinquent()
        {
            var el = getObj("coAppDelinquent");
            if(el.innerHTML == "Yes")
                show("pnlCoAppDelinquentExp")
            else
                hide("pnlCoAppDelinquentExp")
        }
        
        function toggleCoAppDownPaymentBorrowed()
        {
            var el = getObj("coAppDownPaymentBorrowed");
            if(el.innerHTML == "Yes")
                show("pnlCoAppDownPaymentBorrowedExp")
            else
                hide("pnlCoAppDownPaymentBorrowedExp")
        }
        
        function toggleCoAppLawSuit()
        {
            var el = getObj("coAppLawSuit");
            if(el.innerHTML == "Yes")
                show("pnlCoAppLawSuitExp")
            else
                hide("pnlCoAppLawSuitExp")
        }
        
        function toggleCoAppLoanObligation()
        {
            var el = getObj("coAppLoanObligation");
            if(el.innerHTML == "Yes")
                show("pnlCoAppLoanObligationExp")
            else
                hide("pnlCoAppLoanObligationExp")
        }
        
        function toggleCoAppOutstandingJudgements()
        {
            var el = getObj("coAppOutstandingJudgements");
            if(el.innerHTML == "Yes")
                show("pnlCoAppOutstandingJudgementsExp")
            else
                hide("pnlCoAppOutstandingJudgementsExp")
        }
        
        function toggleCoAppProperyForeclosed()
        {
            var el = getObj("coAppProperyForeclosed");
            if(el.innerHTML == "Yes")
                show("pnlCoAppProperyForeclosedExp")
            else
                hide("pnlCoAppProperyForeclosedExp")
        }
        
        function toggleCoAppOwnershipInterest()
        {
            var el = getObj("coAppOwnershipInterest");
            if(el.innerHTML == "Yes")
                show("pnlCoAppOwnershipInterestPropType")
            else
                hide("pnlCoAppOwnershipInterestPropType")
        }