addEvent(window, "load", Init);

        function Init()
        {
            var theScen = getObj("sceneLbl").innerHTML;
            var isEdit = getObj("isEditLbl").innerHTML;
            var isDemo = getObj("isDemoLbl").innerHTML;
            var isBack = getObj("isBackLbl").innerHTML;
            var trueStr = "True";
            
            if(getObj("editCollateralLbl").innerHTML == "true")
            {
                getObj("additionalCollateral2").checked = false;
                getObj("additionalCollateral1").checked = true;
            }

	        switch(theScen) 
	        {
                case "vehicle":
                case "usedVehicle":
                case "secured":
                case "unSecured":
                            if(theScen == "unSecured")
                            {
                            
                                hide(new Array("pnlDisplayCollateralFields",
                                    "pnlClIdTable",
                                    "pnlCollateralTable",
                                    "pnlClNwUsed"));

                                //do not require these fields
                                changeLabel("pnlAnReqIntRate", "Requested Interest Rate:");
                                toggleVerifyAttribute("anReqIntRate", false);
                                changeLabel("pnlAnPmtPrd", "Payment Frequency:");
                                toggleVerifyAttribute("anPmtPrd", false);

                                if(getObj("requireTermForUnsecured").innerHTML != "true")
                                {
                                    changeLabel("pnlAnTerm", "Term:");
                                    toggleVerifyAttribute("anTerm", false);
                                }

                                if(getObj("readToApplicantLbl").innerHTML == "true")
                                {
                                    show("pnlReadToApplicantVehicleCollateral");
                                    if(getObj("readToApplicantDebtConsolidationLbl").innerHTML == "true")
                                        show("readToAppDebtConsolidation");
                                    else if(getObj("readToApplicantPersonalLoanLbl").innerHTML == "true")
                                        show("readToAppPersonalLoan");
                                    else if(getObj("readToApplicantEducationLbl").innerHTML == "true")
                                        show("readToAppEducation");
                                }
                            }
                            
                            if(theScen != "unSecured")
                            {
                                if(theScen == "vehicle")
                                    togglePreApprovalField();
                                    
                                if(getObj("showNADALookupLbl").innerHTML == "true")
                                    show("pnlNADALookup");
                            }

                            if(getObj("showAutoDebitRateLbl").innerHTML == "true")
                                show("pnlAnAutoDebitRate");
                            else
                                hide("pnlAnAutoDebitRate");

                            getObj("clTrim").options[8] = null;
                            hide(new Array("pnlUsedDetails",
                                "pnlHomeText3",
                                "pnlHomePurpose",
                                "pnlLimit",
                                "pnlMax",
                                "pnlAmount_Visa",
                                "pnlPayments",
                                "pnlSellerName",
                                "pnlVisaPurpose",
                                "pnlAdvance",
                                "pnlPropertyDetails1",
                                "pnlPropertyDetails2",
                                "pnlPropertyDetails3",
                                "pnlSpacer1",
                                "pnlSpacer2"));
                            
                            

                            if(isEdit == trueStr || isDemo == trueStr || isBack == trueStr)
                            {
                                cboToggle("clXstgLien", "pnlPayments", 1);
                            }
                            break;

                case "credit":
                
                            hide(new Array("pnlAnAutoDebitRate",
                                "pnlClIdTable",
                                "pnlCollateralTable",
                                "pnlClNwUsed",
                                "pnlAnPmtType",
                                "pnlAnPmtPrd",
                                "pnlAnTerm",
                                "pnlNumOfSections",
                                "pnlStyle",
                                "pnlWidth",
                                "pnlLength",
                                "AddCollateral",
                                "pnlHomeText3",
                                "pnlHomePurpose",
                                "pnlPayments",
                                "pnlAmount",
                                "pnlSellerName",
                                "pnlHaveTrade",
                                "pnlVisaPurpose",
                                "pnlAdvance",
                                "pnlDisplayCollateralFields",
                                "pnlUsedDetails",
                                "pnlPropertyDetails1",
                                "pnlPropertyDetails2",
                                "pnlPropertyDetails3",
                                "pnlSpacer1",
                                "pnlSpacer2"));

                            if(getObj("showLienFieldForHELOCLbl").innerHTML == "true")
                            {
                                show(new Array("pnlHomePurpose",
                                    "pnlPropertyDetails3",
                                    "pnlHeloctext"));
                                hide(new Array("pnlGfx5",
                                    "pnlGfx3",
                                    "pnlGfx4",
                                    "deedTxtLbl",
                                    "pnlSelEstateNames",
                                    "pnlEstateNames",
                                    "pnlGfx6",
                                    "pnlSelTaxes",
                                    "pnlPhyTtlHeld",
                                    "pnlAppNameOnDeed",
                                    "pnlCoAppNameOnDeed",
                                    "pnlCorrectAppNameOnDeed",
                                    "pnlCorrectCoAppNameOnDeed",
                                    "deedTxtLbl",
                                    "pnlLienHolders"));

                                cboToggle("selLienHolders", "pnlLienHolders", 1);
                            }
                            
                            if(getObj("showCollateralForHELOCLbl").innerHTML == "true")
                            {
                                if(getObj("hidePropertyDetailsLbl").innerHTML == "true")
                                    hide("pnlPropertyDetails3");
                                else
                                {
                                    show(new Array("pnlPropertyDetails1",
                                        "pnlPropertyDetails2",
                                        "pnlPropertyDetails3",
                                        "pnlGfx3",
                                        "pnlGfx4"));
                                        
                                    if(getObj("hidePropertyDetails3Lbl").innerHTML == "true")
                                        hide("pnlPropertyDetails3");
                                        
                                    if(getObj("hidePurchasePriceAndYearLbl").innerHTML == "true")
                                    {
                                        hide(new Array("pnlPhyPrchYr",
                                            "pnlPhyPrchPrice"));
                                    }
                                    
                                    if(getObj("showPopulateAddrFieldsLbl").innerHTML == "true")
                                    {
                                        show("pnlPopulateAddrFields");
                                    }
                                    
                                    if(getObj("showTownDDLLbl").innerHTML == "true")
                                        show("pnlPhyTown");
                                    else
                                        hide("pnlPhyTown");

                                    if(getObj("showCountyDDLLbl").innerHTML == "true")
                                    {
                                        show("pnlPhyCntyDDL");
                                        hide("pnlPhyCnty");
                                    }
                                    else
                                    {
                                        hide("pnlPhyCntyDDL");
                                        show("pnlPhyCnty");
                                    }

                                    if(getObj("hidePhyEstValSrcLbl").innerHTML == "true")
                                        hide("pnlPhyEstValSrc");
                                    else
                                        show("pnlPhyEstValSrc");
                                            
                                    hide(new Array("pnlGfx5",
                                        "pnlSelEstateNames",
                                        "pnlGfx3",
                                        "pnlGfx6",
                                        "pnlSelTaxes",
                                        "pnlPhyTtlHeld",
                                        "pnlCorrectAppNameOnDeed",
                                        "pnlCorrectCoAppNameOnDeed",
                                        "pnlAppNameOnDeed",
                                        "pnlCoAppNameOnDeed",
                                        "deedTxtLbl",
                                        "pnlEstateNames"));
                                        
                                    toggleHMDA();
                                    toggleCoAppHMDA();
                                    cboToggle("selLienHolders", "pnlLienHolders", 1);

                                    if(isEdit == trueStr || isDemo == trueStr || isBack == trueStr)
                                    {
                                        cboToggle("selEstateNames", "pnlEstateNames", 1);
                                    }
                                }
                            }

                            if(getObj("readToApplicantLbl").innerHTML == "true")
                            {
                                show("pnlReadToApplicantVehicleCollateral");
                                if(getObj("readToApplicantCashReserveLbl").innerHTML == "true")
                                    show("readToAppCashReserve");
                                else if(getObj("readToApplicantVisaLbl").innerHTML == "true")
                                    show("readToAppVisa");
                                else if(getObj("readToApplicantHELOCLbl").innerHTML == "true")
                                {
                                    hide("pnlReadToApplicantVehicleCollateral");
                                    show("readToAppHELOC");
                                }
                            }
                            
                            break;
                            
                case "homeeq":
                                if(getObj("hidePurchasePriceAndYearLbl").innerHTML == "true")
                                {
                                    hide(new Array("pnlPhyPrchYr",
                                        "pnlPhyPrchPrice"));
                                }

                                if(getObj("showPopulateAddrFieldsLbl").innerHTML == "true")
                                {
                                    show("pnlPopulateAddrFields");
                                }

                                if(getObj("showTownDDLLbl").innerHTML == "true")
                                    show("pnlPhyTown");
                                else
                                    hide("pnlPhyTown");

                                if(getObj("showCountyDDLLbl").innerHTML == "true")
                                {
                                    show("pnlPhyCntyDDL");
                                    hide("pnlPhyCnty");
                                }
                                else
                                {
                                    hide("pnlPhyCntyDDL");
                                    show("pnlPhyCnty");
                                }

                                if(getObj("hidePhyEstValSrcLbl").innerHTML == "true")
                                    hide("pnlPhyEstValSrc");
                                else
                                    show("pnlPhyEstValSrc");

                                hide(new Array("pnlAnAutoDebitRate",
                                    "pnlClIdTable",
                                    "pnlCollateralTable",
                                    "pnlClNwUsed",
                                    "pnlNumOfSections",
                                    "pnlStyle",
                                    "pnlWidth",
                                    "pnlLength",
                                    "AddCollateral",
                                    "pnlHomeText3",
                                    "pnlMainDetails",
                                    "pnlHomePurpose",
                                    "pnlAdvance",
                                    "pnlDisplayCollateralFields",
                                    "pnlUsedDetails",
                                    "pnlLienHolders",
                                    "pnlAdditionalOwners",
                                    "pnlEstateNames",
                                    "pnlSpacer1",
                                    "pnlSpacer2"));

                                if(getObj("hidePropertyDetailsLbl").innerHTML == "true")
                                    hide("pnlPropertyDetails3");
                                else
                                {
                                    show(new Array("pnlAdditionalOwners",
                                        "pnlHeText"));
                                    
                                    hide(new Array("pnlGfx5",
                                        "pnlSelEstateNames",
                                        "pnlGfx3",
                                        "pnlGfx6",
                                        "pnlSelTaxes",
                                        "pnlPhyTtlHeld",
                                        "pnlCorrectAppNameOnDeed",
                                        "pnlCorrectCoAppNameOnDeed",
                                        "pnlAppNameOnDeed",
                                        "deedTxtLbl",
                                        "pnlCoAppNameOnDeed"));
                                }

                                if(getObj("readToApplicantLbl").innerHTML == "true")
                                {
                                    show("pnlReadToApplicantHECollateral");
                                    if(getObj("readToApplicantHomeImprovLbl").innerHTML == "true")
                                        show("readtToAppHomeImprov");
                                    else
                                        show("readToAppHE");
                                }

                                cboToggle("selLienHolders", "pnlLienHolders", 1);
                                if(isEdit == trueStr || isDemo == trueStr || isBack == trueStr)
                                {
                                    cboToggle("selEstateNames", "pnlEstateNames", 1);
                                }

                                break;
                case "homeeq2":
                
                                hide(new Array("pnlAnAutoDebitRate",
                                    "pnlClIdTable",
                                    "pnlCollateralTable",
                                    "pnlClNwUsed",
                                    "pnlHomeText3", 
                                    "pnlAdvance",
                                    "pnlNumOfSections",
                                    "pnlStyle",
                                    "pnlWidth",
                                    "pnlLength",
                                    "AddCollateral",
                                    "pnlLimit",
                                    "pnlMax",
                                    "pnlAmount_Visa",
                                    "pnlPayments",
                                    "pnlSellerName",
                                    "pnlHaveTrade",
                                    "pnlVisaPurpose",
                                    "pnlDisplayCollateralFields",
                                    "pnlUsedDetails",
                                    "pnlPropertyDetails1",
                                    "pnlPropertyDetails2",
                                    "pnlPropertyDetails3",
                                    "pnlSpacer1",
                                    "pnlAnLoanDesc"));

                                if(getObj("disableCoAppHMDA").innerHTML == "true")
                                    getObj("coAppPersonalDetails").disabled = true;
                                else
                                    getObj("coAppPersonalDetails").disabled = false;

                                toggleHMDA();
                                toggleCoAppHMDA();
                                show("anPmtPrd");

                                break;

                        
                case "busVisa":
                case "busUnSecured":
                                if(theScen == "busUnSecured")
                                {
                                    //do not require these fields
                                    changeLabel("pnlAnReqIntRate", "Requested Interest Rate:");
                                    toggleVerifyAttribute("anReqIntRate", false);
                                    changeLabel("pnlAnPmtPrd", "Payment Frequency:");
                                    toggleVerifyAttribute("anPmtPrd", false);
                                    
                                    if(getObj("requireTermForUnsecured").innerHTML != "true")
                                    {
                                        changeLabel("pnlAnTerm", "Term:");
                                        toggleVerifyAttribute("anTerm", false);
                                    }
                                }

                                hide(new Array("pnlAnAutoDebitRate",
                                    "pnlClNwUsed",
                                    "pnlAnPmtType",
                                    "pnlAnPmtPrd",
                                    "pnlVisaPurpose",
                                    "pnlAnTerm",
                                    "pnlClIdTable",
                                    "pnlCollateralTable",
                                    "pnlNumOfSections",
                                    "pnlStyle",
                                    "pnlWidth",
                                    "pnlLength",
                                    "AddCollateral",
                                    "pnlHomeText3",
                                    "pnlHomePurpose",
                                    "pnlPayments",
                                    "pnlAmount",
                                    "pnlSellerName",
                                    "pnlHaveTrade",
                                    "pnlVisaPurpose",
                                    "pnlAdvance",
                                    "pnlDisplayCollateralFields",
                                    "pnlUsedDetails",
                                    "pnlPropertyDetails1",
                                    "pnlPropertyDetails2",
                                    "pnlPropertyDetails3",
                                    "pnlSpacer1",
                                    "pnlSpacer2"));
                                break;

                case "busVehicle":
                case "equipment":
                case "busSecured":
                                if(theScen == "equipment")
                                {   
                                    getObj("pnlVehicleHeader").innerHTML = getObj("clId").options[getObj("clId").selectedIndex].text + " Details";
                                    changeLabel("pnlValue", "Value of Equipment:");
                                    changeLabel("pnlVin", "Serial Number:");
                                    hide(new Array("pnlMileage", "pnlVehicleMake", "pnlModel", "pnlBody"));
                                }
                                else
                                {
                                    getObj("clTrim").options[7] = null;
                                    hide(new Array("pnlHoursUsed", "pnlEquipmentDesc"));
                                }

                                if(theScen == "busUnSecured")
                                {
                                
                                    hide(new Array("pnlDisplayCollateralFields",
                                        "pnlClIdTable",
                                        "pnlCollateralTable",
                                        "pnlClNwUsed"));
                                }

                                hide(new Array("pnlUsedDetails",
                                    "pnlAnAutoDebitRate",
                                    "pnlNumOfSections",
                                    "pnlStyle",
                                    "pnlWidth",
                                    "pnlLength",
                                    "pnlHomeText3",
                                    "pnlHomePurpose",
                                    "pnlLimit",
                                    "pnlMax",
                                    "pnlAmount_Visa",
                                    "pnlPayments",
                                    "pnlSellerName",
                                    "pnlVisaPurpose",
                                    "pnlAdvance",
                                    "pnlPropertyDetails1",
                                    "pnlPropertyDetails2",
                                    "pnlPropertyDetails3",
                                    "pnlSpacer1",
                                    "pnlSpacer2"));

                                if(isEdit == trueStr || isDemo == trueStr || isBack == trueStr)
                                {
                                    cboToggle("clXstgLien", "pnlPayments", 1);
                                }

                                break;
  	        }
  	        
  	        if(getObj("showGeneralQuestionsLbl").innerHTML == "true")
                show("pnlGenQuestion");
            else
                hide("pnlGenQuestion");
                
            if(getObj("showPromoCodeDDLLbl").innerHTML == "true")
                show("pnlPromoCodeDDL");
            else
                hide("pnlPromoCodeDDL");

            toggleRequestTypeFields();
            
            if(getObj("showAnReqTypeSimple").innerHTML == "true")
                show("pnlAnReqTypeSimple");
            else
                hide("pnlAnReqTypeSimple");

            if(getObj("hideIntRateLbl").innerHTML == "true")
                hide("pnlAnReqIntRate");

            if(getObj("hidePmtFieldsLbl").innerHTML == "true")
            {
                hide(new Array("pnlAnPmtType",
                    "pnlAnPmtPrd"));
            }
            
            if(getObj("changeCollateralAddressQuestionLbl").innerHTML == "true")
            {
                changeLabel("pnlPopulateAddrFields", "is the applicant's mailing address the same as the collateral address?");
            }
            
            if(getObj("showChannelCodeLbl").innerHTML == "true")
                show("pnlAnChannelCode");
            else
                hide("pnlAnChannelCode");
                
            if(getObj("showAutoPaymentLbl").innerHTML == "true")
            {
                show("pnlAnAutoPmt");
                hide("pnlAnDepAcct");
            }
            else
            {
                hide(new Array("pnlAnAutoPmt",
                    "pnlAnDepAcct"));
            }
            
            if(getObj("showSignDocsLbl").innerHTML == "true")
                show("pnlAnSignDocs");
            else
                hide("pnlAnSignDocs");
            
            if(getObj("showMarginLbl").innerHTML == "true")
            {
                if(getObj("renameMarginLbl").innerHTML.length > 0)
                    changeLabel("pnlAnMargin", getObj("renameMarginLbl").innerHTML);
                    
                show("pnlAnMargin");
            }
            else
                hide("pnlAnMargin");
                
            if(getObj("hideLoanPurLbl").innerHTML == "true")
                hide("pnlAnLoanDesc");
                
            if (getObj("showClosingFirstMortgageLbl").innerHTML == "true")
                show("pnlAnClosingMortgage");
            else
                hide("pnlAnClosingMortgage");
                
            toggleCashReserveFields();
            
            if (getObj("showCollateralCodeLbl").innerHTML == "true")
                show("pnlClCollateralCode");
            else
                hide("pnlClCollateralCode");

            if (getObj("hideCreditAmountLbl").innerHTML == "true")
                hide("pnlAmount_Visa");
                
            if (getObj("showInsCoverageTypeLbl").innerHTML == "true")
                show(new Array("pnlAnCredLifeInsSelection",
                    "pnlAnCredDisabInsSelection"));
            else
                hide(new Array("pnlAnCredLifeInsSelection",
                    "pnlAnCredDisabInsSelection"));
                    
            toggleCoOwnerFields();
            toggleLoanPurposeFields();
            toggleHELoanPurposeFields();
            toggleMemberGuard();
            
            if (getObj("hideCollateralFieldsForHomeImprovement").innerHTML == "true")
                hideCollateralFieldsForHomeImprovement();
                
            if (getObj("showFundsIssuedByMailLbl").innerHTML == "true")
                show("pnlFundsIssuedByMail");
            else
                hide("pnlFundsIssuedByMail");
                
            if (getObj("showCharitableOrgLbl").innerHTML == "true")
                show("pnlCharitableOrg");
            else
                hide("pnlCharitableOrg");
                
            if(getObj("changeTermTextLbl").innerHTML.length > 0)
            {
                changeLabel("pnlAnTerm", getObj("changeTermTextLbl").innerHTML);
                changeLabel("pnlAnTerm", getObj("changeTermTextLbl").innerHTML);
            }
            
            if(getObj("changeCreditLifeInsLbl").innerHTML.length > 0)
            {
                changeLabel("pnlAnCredLifeIns", getObj("changeCreditLifeInsLbl").innerHTML);
            }
            
            if(getObj("changeCreditDisbInsLbl").innerHTML.length > 0)
            {
                changeLabel("pnlAnCredDisabIns", getObj("changeCreditDisbInsLbl").innerHTML);
            }
            
            if(getObj("doNotRequireIntRateLbl").innerHTML == "true")
            {
                changeLabel("pnlAnReqIntRate", "Requested Interest Rate:");
                toggleVerifyAttribute("anReqIntRate", false);
            }
            
            if(collateralTable.rows.length < 2)
                hide("pnlCollateralTable");
            else
                show("pnlCollateralTable");
            
            cboToggle("anAutoPmt", "pnlAnDepAcct", 1);
            
            toggleUsedDetails();

            if(getObj("hideAddCollateralRadioLbl").innerHTML == "true")
            {
                hide(new Array("addCollateralRadio",
                    "collateralHelpTxt"));
            }
            else
            {
                show(new Array("addCollateralRadio",
                    "collateralHelpTxt"));
            }
            
            addEvent("clId", 	"change", 	toggleCollateralFields);
	        addEvent("clId", 	"keyup", 	toggleCollateralFields);
            
            //have trade
            addEvent("clXstgLien", 	"change", 	function() { cboToggle("clXstgLien", "pnlPayments", 1) });
	        addEvent("clXstgLien", 	"keyup", 	function() { cboToggle("clXstgLien", "pnlPayments", 1) });

            //advance
            addEvent("selAdvance", 	"change",   function() { cboToggle("selAdvance", "pnlAdvance2", 1) });
            addEvent("selAdvance", 	"keyup", 	function() { cboToggle("selAdvance", "pnlAdvance2", 1) });

            //lien holders
            addEvent("selLienHolders", 	"change",   function() { cboToggle("selLienHolders", "pnlLienHolders", 1) });
            addEvent("selLienHolders", 	"keyup", 	function() { cboToggle("selLienHolders", "pnlLienHolders", 1) });

            //estate names
            addEvent("selEstateNames", 	"change",   function() { cboToggle("selEstateNames", "pnlEstateNames", 1) });
            addEvent("selEstateNames", 	"keyup", 	function() { cboToggle("selEstateNames", "pnlEstateNames", 1) });

            //trust
            addEvent("phyTtlHeld", 	"change", checkTrust);
	        addEvent("phyTtlHeld", 	"keyup",  checkTrust);

            //HMDA
            addEvent("hmPersonalDetails", "click", toggleHMDA);
            addEvent("coAppPersonalDetails", "click", toggleCoAppHMDA);

            //correct names on deed
            addEvent("correctAppNameOnDeed", 	"change",   toggleAppNameOnDeed);
            addEvent("correctAppNameOnDeed", 	"keyup", 	toggleAppNameOnDeed);
            addEvent("correctCoAppNameOnDeed", 	"change",   toggleCoAppNameOnDeed);
            addEvent("correctCoAppNameOnDeed", 	"keyup", 	toggleCoAppNameOnDeed);

            //payments
            addEvent("anAutoPmt", 	"change",   function() { cboToggle("anAutoPmt", "pnlAnDepAcct", 1) });
            addEvent("anAutoPmt", 	"keyup", 	function() { cboToggle("anAutoPmt", "pnlAnDepAcct", 1) });

            //amount of line increase
            addEvent("anReqType", 	"change",   toggleRequestTypeFields);
            addEvent("anReqType", 	"keyup", 	toggleRequestTypeFields);
            
            //payee details
            addEvent("anLoanDesc", 	"change",   toggleLoanPurposeFields);
            addEvent("anLoanDesc", 	"keyup", 	toggleLoanPurposeFields);
            
            addEvent("anLoanPur", 	"change",   toggleHELoanPurposeFields);
            addEvent("anLoanPur", 	"keyup", 	toggleHELoanPurposeFields);
            
            //pre approval request
            addEvent("anPreApv", 	"change",   togglePreApprovalField);
            addEvent("anPreApv", 	"keyup", 	togglePreApprovalField);
            
            //coOwner
            addEvent("anCoOwnerInc", 	"change",   toggleCoOwnerFields);
            addEvent("anCoOwnerInc", 	"keyup", 	toggleCoOwnerFields);
            
            //member guard
            addEvent("anMemberGuard", 	"change",   toggleMemberGuard);
            addEvent("anMemberGuard", "keyup", toggleMemberGuard);

        }

        window.onbeforeunload = confirmExit;
        var needToConfirm = true;
        function confirmExit()
        {
            if(needToConfirm)
            {
                var myXMLHTTPRequeset = new S1XMLHTTPRequest();
                myXMLHTTPRequeset.xmlhttpGet("pageClose.aspx");
            }
        }

        function toggleHMDA(e) 
        {
            var el = getObj("hmPersonalDetails");

            if (el.checked)
            {
	            getObj("hmAtEth1").disabled = true;
                getObj("hmAtEth2").disabled = true;
                getObj("hmAtEth3").disabled = true;
                getObj("hmAtEth4").disabled = true;

                getObj("hmAtRc1").disabled = true;
                getObj("hmAtRc2").disabled = true;
                getObj("hmAtRc3").disabled = true;
                getObj("hmAtRc4").disabled = true;
                getObj("hmAtRc5").disabled = true;
                getObj("hmAtRc6").disabled = true;
                getObj("hmAtRc7").disabled = true;

                getObj("atGdr1").disabled = true;
                getObj("atGdr2").disabled = true;
                getObj("atGdr3").disabled = true;
                getObj("atGdr4").disabled = true;
            }
            else
            {
	            getObj("hmAtEth1").disabled = false;
                getObj("hmAtEth2").disabled = false;
                getObj("hmAtEth3").disabled = false;
                getObj("hmAtEth4").disabled = false;

                getObj("hmAtRc1").disabled = false;
                getObj("hmAtRc2").disabled = false;
                getObj("hmAtRc3").disabled = false;
                getObj("hmAtRc4").disabled = false;
                getObj("hmAtRc5").disabled = false;
                getObj("hmAtRc6").disabled = false;
                getObj("hmAtRc7").disabled = false;

                getObj("atGdr1").disabled = false;
                getObj("atGdr2").disabled = false;
                getObj("atGdr3").disabled = false;
                getObj("atGdr4").disabled = false;
            }
        }

        function toggleCoAppHMDA(e) 
        {
            var el = getObj("coAppPersonalDetails");

            if (el.checked)
            {
                getObj("coAppAtEth1").disabled = true;
                getObj("coAppAtEth2").disabled = true;
                getObj("coAppAtEth3").disabled = true;
                getObj("coAppAtEth4").disabled = true;

                getObj("coAppAtRc1").disabled = true;
                getObj("coAppAtRc2").disabled = true;
                getObj("coAppAtRc3").disabled = true;
                getObj("coAppAtRc4").disabled = true;
                getObj("coAppAtRc5").disabled = true;
                getObj("coAppAtRc6").disabled = true;
                getObj("coAppAtRc7").disabled = true;

                getObj("coAppGdr1").disabled = true;
                getObj("coAppGdr2").disabled = true;
                getObj("coAppGdr3").disabled = true;
                getObj("coAppGdr4").disabled = true;
            }
            else
            {
                getObj("coAppAtEth1").disabled = false;
                getObj("coAppAtEth2").disabled = false;
                getObj("coAppAtEth3").disabled = false;
                getObj("coAppAtEth4").disabled = false;

                getObj("coAppAtRc1").disabled = false;
                getObj("coAppAtRc2").disabled = false;
                getObj("coAppAtRc3").disabled = false;
                getObj("coAppAtRc4").disabled = false;
                getObj("coAppAtRc5").disabled = false;
                getObj("coAppAtRc6").disabled = false;
                getObj("coAppAtRc7").disabled = false;

                getObj("coAppGdr1").disabled = false;
                getObj("coAppGdr2").disabled = false;
                getObj("coAppGdr3").disabled = false;
                getObj("coAppGdr4").disabled = false;
            }
        }

        function checkTrust()
        {
            if (getObj("phyTtlHeld").options.selectedIndex == 1)
            {
                getObj("pnlError").innerHTML = "Properties located within in a " +
                    "trust can not be used as collateral. If it is located within a trust, " +
                    "please exit the application.";
                show("pnlError");
                scroll(0, 0);
            }
            else
            {
                getObj("pnlError").innerHTML = "";
                hide("pnlError");
            }
        }
        
        function toggleCashReserveFields()
        {
            if (getObj("showCashReserveAccountsLbl").innerHTML == "true")
            {
                show(new Array("pnlAnCashReserveAcctNum",
                    "pnlAnTotalLineLimitRequested"));
            }
            else
            {
                if(getObj("toggleRateTableForHELOCLbl").innerHTML == "true")
                    hide("pnlAnCashReserveAcctNum");
                else        
                    hide(new Array("pnlAnCashReserveAcctNum",
                        "pnlAnTotalLineLimitRequested"));
            }
        }
        
        function toggleRequestTypeFields()
        {
            if(getObj("showAnReqTypeLbl").innerHTML == "true")
                show("pnlAnReqType");
            else
                hide("pnlAnReqType");
            
            if(getObj("toggleRateTableForHELOCLbl").innerHTML == "true")
            {
                if (getObj("anReqType").options[getObj("anReqType").selectedIndex].value == "New Line")
                {
                    getObj("anReqTypeAmount").value = "";
                    getObj("anNewMargin").value = "";
                    getObj("anIncreaseAcctNum").selectedIndex = 0;
                    hide(new Array("pnlAnReqTypeAmount",
                        "pnlAnNewMargin",
                        "pnlAnIncreaseAcctNum"));
                    show(new Array("pnlPromoCodeDDL",
                        "pnlAnTotalLineLimitRequested"));
                }
                else if (getObj("anReqType").options[getObj("anReqType").selectedIndex].value == "Increase credit limit")
                {
                    hide(new Array("pnlAnNewMargin"));
                    
                    show(new Array("pnlAnReqTypeAmount",
                        "pnlPromoCodeDDL",
                        "pnlAnTotalLineLimitRequested",
                        "pnlAnIncreaseAcctNum"));
                }
                else
                {
                    getObj("promotionCodeDDL").selectedIndex = 0;
                    getObj("anReqTypeAmount").value = "";
                    getObj("anTotalLineLimitRequested").value = "";
                    getObj("anNewMargin").value = "";
                    getObj("anIncreaseAcctNum").selectedIndex = 0;
                    hide(new Array("pnlAnReqTypeAmount",
                        "pnlPromoCodeDDL",
                        "pnlAnTotalLineLimitRequested",
                        "pnlAnNewMargin",
                        "pnlAnIncreaseAcctNum"));
                }
            }
            else
            {
                if (getObj("anReqType").options[getObj("anReqType").selectedIndex].value == "Increase credit limit")
                {
                    show("pnlAnReqTypeAmount");
                    if(getObj("hideAccountIncreaseLbl").innerHTML == "true")
                        hide("pnlAnIncreaseAcctNum");
                    else
                        show("pnlAnIncreaseAcctNum");
                        
                    hide(new Array("pnlAnNewMargin"));
                }
                else
                {
                    getObj("anReqTypeAmount").value = "";
                    getObj("anNewMargin").value = "";
                    getObj("anIncreaseAcctNum").selectedIndex = 0;
                    
                    hide("pnlAnReqTypeAmount");
                        
                    hide(new Array("pnlAnNewMargin",
                        "pnlAnIncreaseAcctNum"));
                }
            }
        }

        function toggleCollateralFields()
        {
            var collateralType = getObj("clId").value;

            if (collateralType.length > 0)
            {
                collateralType = collateralType.substring(collateralType.indexOf("_") + 1,
                    getObj("clId").value.length);
            }
            else
                collateralType = "";

            getObj("pnlVehicleHeader").innerHTML = getObj("clId").options[getObj("clId").selectedIndex].text + " Details";

            if (collateralType == "Boat" || collateralType == "Trailer" ||
                collateralType == "Boat Trailer" || collateralType == "Boat Motor")
            {
                if(getObj("showExtraBoatFieldsLbl").innerHTML == "true")
                {
                    show(new Array("pnlMotorConfig",
                        "pnlFuelType",
                        "pnlTotalHP"));
                }
                else
                {
                    hide(new Array("pnlMotorConfig",
                        "pnlFuelType",
                        "pnlTotalHP"));
                }

                if(getObj("reqFieldBasedOnPreApprovalLbl").innerHTML == "true" || 
                    getObj("showCollateralFieldsLbl").innerHTML == "true")
                {
                    hide(new Array("pnlBody",
                        "pnlNumOfSections",
                        "pnlStyle",
                        "pnlWidth",
                        "pnlLength",
                        "pnlVehicleMake",
                        "pnlMileage",
                        "pnlHoursUsed",
                        "pnlEquipmentDesc",
                        "pnlClAccountNum",
                        "pnlClIssuer",
                        "pnlClOpenDt",
                        "pnlClAccrlRate",
                        "pnlClFaceAmt"));

                    show(new Array("pnlVin",
                        "pnlHaveTrade",
                        "pnlBoatMake",
                        "pnlMotorMake",
                        "pnlMotorType",
                        "pnlClBoatLength"));
                }
                else
                {
                    hide(new Array("pnlBody",
                        "pnlNumOfSections",
                        "pnlStyle",
                        "pnlWidth",
                        "pnlLength",
                        "pnlVehicleMake",
                        "pnlMileage",
                        "pnlHoursUsed",
                        "pnlEquipmentDesc",
                        "pnlVin",
                        "pnlHaveTrade",
                        "pnlMotorType",
                        "pnlClBoatLength",
                        "pnlClPrchPrice",
                        "pnlClDownPmt",
                        "pnlValue",
                        "pnlClAccountNum",
                        "pnlClIssuer",
                        "pnlClOpenDt",
                        "pnlClAccrlRate",
                        "pnlClFaceAmt"));

                    if (collateralType == "Trailer" || collateralType == "Boat Trailer")
                    {
                        hide(new Array("pnlModel",
                            "pnlMotorMake",
                            "pnlMotorType"));

                        show(new Array("pnlClYr",
                            "pnlBoatMake",
                            "pnlValue",
                            "pnlVin",
                            "pnlClBoatLength"));
                    }
                    else
                    {
                        show(new Array("pnlClYr",
                            "pnlBoatMake",
                            "pnlMotorMake",
                            "pnlMotorType"));
                    }
                }
            }
            else if (collateralType == "Machinery and Equipment" || 
                     collateralType == "Construction Equipment")
            {

                if(getObj("reqFieldBasedOnPreApprovalLbl").innerHTML == "true" || 
                    getObj("showCollateralFieldsLbl").innerHTML == "true")
                {
                    hide(new Array("pnlClBoatLength",
                        "pnlNumOfSections",
                        "pnlStyle",
                        "pnlWidth",
                        "pnlLength",
                        "pnlVehicleMake",
                        "pnlBody",
                        "pnlMileage",
                        "pnlMotorMake",
                        "pnlMotorType",
                        "pnlMotorConfig",
                        "pnlFuelType",
                        "pnlTotalHP",
                        "pnlClAccountNum",
                        "pnlClIssuer",
                        "pnlClOpenDt",
                        "pnlClAccrlRate",
                        "pnlClFaceAmt"));

                    show(new Array("pnlHoursUsed",
                        "pnlVin",
                        "pnlHaveTrade",
                        "pnlEquipmentDesc",
                        "pnlBoatMake"));
                }
                else
                {
                    hide(new Array("pnlClBoatLength",
                        "pnlNumOfSections",
                        "pnlStyle",
                        "pnlWidth",
                        "pnlLength",
                        "pnlVehicleMake",
                        "pnlBody",
                        "pnlMileage",
                        "pnlMotorMake",
                        "pnlMotorType",
                        "pnlMotorConfig",
                        "pnlFuelType",
                        "pnlTotalHP",
                        "pnlHoursUsed",
                        "pnlVin",
                        "pnlHaveTrade",
                        "pnlEquipmentDesc",
                        "pnlClPrchPrice",
                        "pnlClDownPmt",
                        "pnlValue",
                        "pnlClAccountNum",
                        "pnlClIssuer",
                        "pnlClOpenDt",
                        "pnlClAccrlRate",
                        "pnlClFaceAmt"));

                    show(new Array("pnlClYr",
                        "pnlBoatMake"));
                }
            }
            else if (collateralType == "Mobile Home")
            {
                if(getObj("reqFieldBasedOnPreApprovalLbl").innerHTML == "true" || 
                    getObj("showCollateralFieldsLbl").innerHTML == "true")
                {
                    hide(new Array("pnlClBoatLength",
                        "pnlHaveTrade",
                        "pnlVehicleMake",
                        "pnlBody",
                        "pnlHoursUsed",
                        "pnlEquipmentDesc",
                        "pnlMileage",
                        "pnlMotorMake",
                        "pnlMotorType",
                        "pnlMotorConfig",
                        "pnlFuelType",
                        "pnlTotalHP",
                        "pnlClAccountNum",
                        "pnlClIssuer",
                        "pnlClOpenDt",
                        "pnlClAccrlRate",
                        "pnlClFaceAmt"));

                    show(new Array("pnlStyle",
                        "pnlNumOfSections",
                        "pnlWidth",
                        "pnlLength",
                        "pnlBoatMake"));
                }
                else
                {
                    hide(new Array("pnlClBoatLength",
                        "pnlHaveTrade",
                        "pnlVehicleMake",
                        "pnlBody",
                        "pnlHoursUsed",
                        "pnlEquipmentDesc",
                        "pnlMileage",
                        "pnlMotorMake",
                        "pnlMotorType",
                        "pnlMotorConfig",
                        "pnlFuelType",
                        "pnlTotalHP",
                        "pnlStyle",
                        "pnlNumOfSections",
                        "pnlWidth",
                        "pnlLength",
                        "pnlClPrchPrice",
                        "pnlClDownPmt",
                        "pnlValue",
                        "pnlVin",
                        "pnlClAccountNum",
                        "pnlClIssuer",
                        "pnlClOpenDt",
                        "pnlClAccrlRate",
                        "pnlClFaceAmt"));

                    show(new Array("pnlClYr",
                        "pnlBoatMake"));
                }
            }
            else if (collateralType == "Generic")
            {
                hide(new Array("pnlClBoatLength",
                    "pnlVehicleMake",
                    "pnlBody",
                    "pnlHoursUsed",
                    "pnlEquipmentDesc",
                    "pnlMileage",
                    "pnlStyle",
                    "pnlNumOfSections",
                    "pnlWidth",
                    "pnlLength",
                    "pnlBoatMake",
                    "pnlClYr",
                    "pnlModel",
                    "pnlMotorMake",
                    "pnlMotorType",
                    "pnlMotorConfig",
                    "pnlFuelType",
                    "pnlTotalHP",
                    "pnlClAccountNum",
                    "pnlClIssuer",
                    "pnlClOpenDt",
                    "pnlClAccrlRate",
                    "pnlClFaceAmt"));

                show(new Array("pnlHaveTrade",
                    "pnlEquipmentDesc",
                    "pnlVin",
                    "pnlValue"));
            }
            else if(collateralType == "Certificate of Deposit")
            {
                hide(new Array("pnlClBoatLength",
                    "pnlNumOfSections",
                    "pnlStyle",
                    "pnlWidth",
                    "pnlLength",
                    "pnlHoursUsed",
                    "pnlEquipmentDesc",
                    "pnlMotorMake",
                    "pnlMotorType",
                    "pnlMotorConfig",
                    "pnlFuelType",
                    "pnlTotalHP",
                    "pnlHaveTrade",
                    "pnlVin",
                    "pnlMileage",
                    "pnlClPrchPrice",
                    "pnlClDownPmt",
                    "pnlValue",
                    "pnlClYr",
                    "pnlVehicleMake",
                    "pnlModel",
                    "pnlBody",
                    "pnlBoatMake",
                    "pnlClNwUsed"));

                if(getObj("hideSavingsAndCDFields").innerHTML == "true")
                {
                        show(new Array("pnlClFaceAmt"));
                        
                        hide(new Array("pnlClIssuer",
                            "pnlClAccountNum",
                            "pnlClOpenDt",
                            "pnlClAccrlRate",
                            "pnlValue"));
                }
                else
                {
                    hide(new Array("pnlClAccountNum"));
                    
                    show(new Array("pnlClIssuer",
                        "pnlClOpenDt",
                        "pnlClAccrlRate",
                        "pnlClFaceAmt",
                        "pnlValue"));
                }

                if(getObj("hideOpenDateAccuralRateLbl").innerHTML == "true")
                    hide(new Array("pnlClOpenDt",
                        "pnlClAccrlRate"));
            }
            else if(collateralType == "Savings")
            {
                hide(new Array("pnlClBoatLength",
                    "pnlNumOfSections",
                    "pnlStyle",
                    "pnlWidth",
                    "pnlLength",
                    "pnlHoursUsed",
                    "pnlEquipmentDesc",
                    "pnlMotorMake",
                    "pnlMotorType",
                    "pnlMotorConfig",
                    "pnlFuelType",
                    "pnlTotalHP",
                    "pnlHaveTrade",
                    "pnlVin",
                    "pnlMileage",
                    "pnlClPrchPrice",
                    "pnlClDownPmt",
                    "pnlValue",
                    "pnlClYr",
                    "pnlVehicleMake",
                    "pnlModel",
                    "pnlClFaceAmt",
                    "pnlBody",
                    "pnlBoatMake",
                    "pnlClNwUsed"));

                if(getObj("hideSavingsAndCDFields").innerHTML == "true")
                {
                    hide(new Array("pnlClIssuer",
                        "pnlClOpenDt",
                        "pnlClAccrlRate",
                        "pnlValue"));
                }
                else
                {
                    show(new Array("pnlClIssuer",
                        "pnlClOpenDt",
                        "pnlClAccrlRate",
                        "pnlValue"));
                }
                
                if(getObj("showAccountNumLbl").innerHTML == "true")
                    show("pnlClAccountNum");
                else
                    hide("pnlClAccountNum");
            }
            else
            {
                // Automobile, Motorcycle, Recreational Vehicle
                if(collateralType == "Motorcycle" || collateralType == "Recreational Vehicle")
                {
                    hide(new Array("pnlVehicleMake",
                        "pnlBody"));
                    show("pnlBoatMake");
                }
                else
                {
                    if(getObj("reqFieldBasedOnPreApprovalLbl").innerHTML == "true" || 
                        getObj("showCollateralFieldsLbl").innerHTML == "true")
                    {
                        show(new Array("pnlVehicleMake",
                            "pnlBody"));
                        hide("pnlBoatMake");
                    }
                    else
                    {
                        show("pnlVehicleMake");
                        hide(new Array("pnlBoatMake",
                            "pnlBody"));
                    }
                }

                if(getObj("reqFieldBasedOnPreApprovalLbl").innerHTML == "true" || 
                    getObj("showCollateralFieldsLbl").innerHTML == "true")
                {
                    hide(new Array("pnlClBoatLength",
                        "pnlNumOfSections",
                        "pnlStyle",
                        "pnlWidth",
                        "pnlLength",
                        "pnlHoursUsed",
                        "pnlEquipmentDesc",
                        "pnlMotorMake",
                        "pnlMotorType",
                        "pnlMotorConfig",
                        "pnlFuelType",
                        "pnlTotalHP",
                        "pnlClAccountNum",
                        "pnlClIssuer",
                        "pnlClOpenDt",
                        "pnlClAccrlRate",
                        "pnlClFaceAmt"));

                    show(new Array("pnlHaveTrade",
                        "pnlVin",
                        "pnlMileage"));
                }
                else
                {
                    hide(new Array("pnlClBoatLength",
                        "pnlNumOfSections",
                        "pnlStyle",
                        "pnlWidth",
                        "pnlLength",
                        "pnlHoursUsed",
                        "pnlEquipmentDesc",
                        "pnlMotorMake",
                        "pnlMotorType",
                        "pnlMotorConfig",
                        "pnlFuelType",
                        "pnlTotalHP",
                        "pnlHaveTrade",
                        "pnlVin",
                        "pnlMileage",
                        "pnlClPrchPrice",
                        "pnlClDownPmt",
                        "pnlValue",
                        "pnlClAccountNum",
                        "pnlClIssuer",
                        "pnlClOpenDt",
                        "pnlClAccrlRate",
                        "pnlClFaceAmt"));

                    show(new Array("pnlClYr"));
                    
                    if(getObj("showValueLbl").innerHTML == "true")
                        show(new Array("pnlValue"));
                }
            }

            if(getObj("reqFieldBasedOnPreApprovalLbl").innerHTML == "true")
            {
                // set the label text
                if (collateralType == "Mobile Home")
                {
                    if (getObj("collatReq").value == "Yes")
                    {
                        changeLabel("pnlBoatMake", "Manufacturer:<span class=\"required\"> *</span>");
                        toggleVerifyAttribute("clBoatMake", true);
                        changeLabel("pnlModel", "Model:<span class=\"required\"> *</span>");
                        toggleVerifyAttribute("clModel", true);
                        getObj("clModel").errorText = "Model";
                        changeLabel("pnlVin", "Serial Number / VIN:<span class='required'> *</span>");
                        getObj("clVin").errorText = "Serial Number / VIN";
                        toggleVerifyAttribute("clVin", true);
                        changeLabel("pnlValue", "Value:<span class='required'> *</span>");
                        toggleVerifyAttribute("clVal", true);
                        getObj("clVal").errorText = "Value";
                    }
                    else
                    {
                        changeLabel("pnlBoatMake", "Manufacturer:");
                        toggleVerifyAttribute("clBoatMake", false);
                        changeLabel("pnlModel", "Model:");
                        toggleVerifyAttribute("clModel", false);
                        getObj("clModel").errorText = "Model";
                        changeLabel("pnlVin", "Serial Number / VIN:");
                        getObj("clVin").errorText = "Serial Number / VIN";
                        toggleVerifyAttribute("clVin", false);
                        changeLabel("pnlValue", "Value:");
                        toggleVerifyAttribute("clVal", false);
                        getObj("clVal").errorText = "Value";
                    }
                }
                else if (collateralType == "Boat" || collateralType == "Trailer" ||
                         collateralType == "Boat Trailer" || collateralType == "Boat Motor")
                {
                    if (getObj("collatReq").value == "Yes")
                    {
                        changeLabel("pnlBoatMake", "Boat Manufacturer:<span class=\"required\"> *</span>");
                        toggleVerifyAttribute("clBoatMake", true);
                        changeLabel("pnlModel", "Boat Model:<span class=\"required\"> *</span>");
                        toggleVerifyAttribute("clModel", true);
                        getObj("clModel").errorText = "Boat Model";
                        changeLabel("pnlMotorMake", "Motor Manufacturer:<span class=\"required\"> *</span>");
                        toggleVerifyAttribute("clMotorMake", true);
                        changeLabel("pnlMotorType", "Motor Type:<span class=\"required\"> *</span>");
                        toggleVerifyAttribute("clMotorType", true);
                        changeLabel("pnlVin", "Serial Number:<span class='required'> *</span>");
                        getObj("clVin").errorText = "Serial Number";
                        toggleVerifyAttribute("clVin", true);
                        changeLabel("pnlValue", "Value:<span class='required'> *</span>");
                        toggleVerifyAttribute("clVal", true);
                        getObj("clVal").errorText = "Value";

                        if(getObj("showExtraBoatFieldsLbl").innerHTML == "true")
                        {
                            changeLabel("pnlMotorConfig", "Motor Configuration:<span class=\"required\"> *</span>");
                            toggleVerifyAttribute("clMotorConfig", true);
                            changeLabel("pnlFuelType", "Fuel Type:<span class=\"required\"> *</span>");
                            toggleVerifyAttribute("clFuelType", true);
                            changeLabel("pnlTotalHP", "Total Horsepower:<span class=\"required\"> *</span>");
                            toggleVerifyAttribute("clTotalHP", true);
                        }
                            
                    }
                    else
                    {
                        changeLabel("pnlBoatMake", "Boat Manufacturer:");
                        toggleVerifyAttribute("clBoatMake", false);
                        changeLabel("pnlModel", "Boat Model:");
                        toggleVerifyAttribute("clModel", false);
                        getObj("clModel").errorText = "Boat Model";
                        changeLabel("pnlMotorMake", "Motor Manufacturer:");
                        toggleVerifyAttribute("clMotorMake", false);
                        changeLabel("pnlMotorType", "Motor Type:");
                        toggleVerifyAttribute("clMotorType", false);
                        changeLabel("pnlVin", "Serial Number:");
                        getObj("clVin").errorText = "Serial Number";
                        toggleVerifyAttribute("clVin", false);
                        changeLabel("pnlValue", "Value:");
                        toggleVerifyAttribute("clVal", false);
                        getObj("clVal").errorText = "Value";

                        if(getObj("showExtraBoatFieldsLbl").innerHTML == "true")
                        {
                            changeLabel("pnlMotorConfig", "Motor Configuration:");
                            toggleVerifyAttribute("clMotorConfig", false);
                            changeLabel("pnlFuelType", "Fuel Type:");
                            toggleVerifyAttribute("clFuelType", false);
                            changeLabel("pnlTotalHP", "Total Horsepower:");
                            toggleVerifyAttribute("clTotalHP", false);
                        }
                    }
                }
                else if(collateralType == "Generic")
                {
                    if (getObj("collatReq").value == "Yes")
                    {
                        changeLabel("pnlEquipmentDesc", "Description:<span class='required'> *</span>");
                        toggleVerifyAttribute("clDesc", true);
                        getObj("clDesc").errorText = "Description";
                        changeLabel("pnlVin", "Serial Number:<span class='required'> *</span>");
                        getObj("clVin").errorText = "Serial Number";
                        toggleVerifyAttribute("clVin", true);
                        changeLabel("pnlValue", "Value:<span class='required'> *</span>");
                        toggleVerifyAttribute("clVal", true);
                        getObj("clVal").errorText = "Value";
                    }
                    else
                    {
                        changeLabel("pnlEquipmentDesc", "Description:");
                        toggleVerifyAttribute("clDesc", false);
                        getObj("clDesc").errorText = "Description";
                        changeLabel("pnlVin", "Serial Number:");
                        toggleVerifyAttribute("clVin", false);
                        changeLabel("pnlValue", "Value:");
                        toggleVerifyAttribute("clVal", false);
                        getObj("clVal").errorText = "Value";
                    }
                }
                else
                {
                    if(getObj("collatReq").value == "Yes")
                    {
                        if(collateralType == "Motorcycle" || collateralType == "Recreational Vehicle")
                        {
                            changeLabel("pnlBoatMake", "Make:<span class=\"required\"> *</span>");
                            toggleVerifyAttribute("clBoatMake", true);
                        }
                        else
                        {
                            changeLabel("pnlModel", "Vehicle Model:<span class=\"required\"> *</span>");
                            toggleVerifyAttribute("clModel", true);
                            getObj("clModel").errorText = "Vehicle Model";
                        }

                        changeLabel("pnlVin", "VIN:<span class='required'> *</span>");
                        getObj("clVin").errorText = "VIN";
                        toggleVerifyAttribute("clVin", true);
                        changeLabel("pnlValue", "Vehicle Value:<span class='required'> *</span>");
                        toggleVerifyAttribute("clVal", true);
                        getObj("clVal").errorText = "Vehicle Value";
                    }
                    else
                    {
                        if(collateralType == "Motorcycle" || collateralType == "Recreational Vehicle")
                        {
                            changeLabel("pnlBoatMake", "Make:");
                            toggleVerifyAttribute("clBoatMake", false);
                            getObj("clBoatMake").errorText = "Vehicle Make";
                        }
                        else
                        {
                            changeLabel("pnlModel", "Vehicle Model:");
                            toggleVerifyAttribute("clModel", false);
                            getObj("clModel").errorText = "Vehicle Model";
                        }

                        changeLabel("pnlVin", "VIN:");
                        getObj("clVin").errorText = "VIN";
                        toggleVerifyAttribute("clVin", false);
                        changeLabel("pnlValue", "Vehicle Value:");
                        toggleVerifyAttribute("clVal", false);
                        getObj("clVal").errorText = "Vehicle Value";
                    }
                }

                var theScen = getObj("sceneLbl").innerHTML;
                if (theScen == "secured" || theScen == "busSecured")
                {
                    if(collateralType != "Certificate of Deposit" && 
                        collateralType != "Savings")
                    {
                        if(getObj("reqFieldBasedOnPreApprovalLbl").innerHTML == "true" || 
                            getObj("showCollateralFieldsLbl").innerHTML == "true")
                        {
                            show("pnlEquipmentDesc");
                            if (getObj("collatReq").value == "Yes")
                            {
                                changeLabel("pnlEquipmentDesc", "Description:<span class='required'> *</span>");
                                toggleVerifyAttribute("clDesc", true);
                            }
                            else
                            {
                                changeLabel("pnlEquipmentDesc", "Description:");
                                toggleVerifyAttribute("clDesc", false);
                            }
                        }
                    }
                }

                if (getObj("collatReq").value == "Yes")
                {
                    if (getObj("pnlHaveTrade").style.display == "")
                    {
                        toggleVerifyAttribute("clXstgLien", true);
                        changeLabel("pnlHaveTrade", "Is there a Trade-in?<span class=\"required\"> *</span>");
                    }

                    toggleVerifyAttribute("clPrchPrice", true);
                    changeLabel("pnlClPrchPrice", "Purchase Price:<span class=\"required\"> *</span>");

                    toggleVerifyAttribute("clDownPmt", true);
                    changeLabel("pnlClDownPmt", "Down Payment:<span class=\"required\"> *</span>");

                    if (getObj("pnlClYr").style.display == "")
                    {
                        toggleVerifyAttribute("clYr", true);
                        changeLabel("pnlClYr", "Year:<span class=\"required\"> *</span>");
                    }

                    if (getObj("pnlVehicleMake").style.display == "")
                    {
                        toggleVerifyAttribute("clMake", true);
                        changeLabel("pnlVehicleMake", "Vehicle Make:<span class=\"required\"> *</span>");
                    }

                    if (getObj("pnlBody").style.display == "")
                    {
                        toggleVerifyAttribute("clTrim", true);
                        changeLabel("pnlBody", "Body Style:<span class=\"required\"> *</span>");
                    }

                    if (getObj("pnlStyle").style.display == "")
                    {
                        toggleVerifyAttribute("clStyle", true);
                        changeLabel("pnlStyle", "Style:<span class=\"required\"> *</span>");
                    }

                    if (getObj("pnlLength").style.display == "")
                    {
                        toggleVerifyAttribute("clLength", true);
                        changeLabel("pnlLength", "Length:<span class=\"required\"> *</span>");
                    }

                    if (getObj("pnlWidth").style.display == "")
                    {
                        toggleVerifyAttribute("clWidth", true);
                        changeLabel("pnlWidth", "Width:<span class=\"required\"> *</span>");
                    }

                    if (getObj("pnlNumOfSections").style.display == "")
                    {
                        toggleVerifyAttribute("clNumOfSections", true);
                        changeLabel("pnlNumOfSections", "Number of Sections:<span class=\"required\"> *</span>");
                    }

                    if (getObj("pnlMileage").style.display == "")
                    {
                        toggleVerifyAttribute("clMi", true);
                        changeLabel("pnlMileage", "Mileage:<span class=\"required\"> *</span>");
                    }

                    if (getObj("pnlHoursUsed").style.display == "")
                    {
                        toggleVerifyAttribute("clHrs", true);
                        changeLabel("pnlHoursUsed", "Hours Used:<span class=\"required\"> *</span>");
                    }

                    if (getObj("pnlClBoatLength").style.display == "")
                    {
                        toggleVerifyAttribute("clBoatFeet", true);
                        changeLabel("pnlClBoatLength", "Length:<span class=\"required\"> *</span>");
                    }

                    if (getObj("pnlClCollIns") != null && getObj("pnlClCollIns").style.display == "")
                    {
                        toggleVerifyAttribute("clCollIns", true);
                        changeLabel("pnlClCollIns", "Collateral Insured By:<span class=\"required\"> *</span>");
                    }
                
                    if (getObj("pnlEvalBasis").style.display == "")
                    {
                        toggleVerifyAttribute("clEvalBasis", true);
                        changeLabel("pnlEvalBasis", "Basis of Evaluation:<span class=\"required\"> *</span>");
                    }
                }
                else
                {
                    if (getObj("pnlHaveTrade").style.display == "")
                    {
                        toggleVerifyAttribute("clXstgLien", false);
                        changeLabel("pnlHaveTrade", "Is there a Trade-in?");
                    }

                    toggleVerifyAttribute("clPrchPrice", false);
                    changeLabel("pnlClPrchPrice", "Purchase Price:");

                    toggleVerifyAttribute("clDownPmt", false);
                    changeLabel("pnlClDownPmt", "Down Payment:");

                    if (getObj("pnlClYr").style.display == "")
                    {
                        toggleVerifyAttribute("clYr", false);
                        changeLabel("pnlClYr", "Year:");
                    }

                    if (getObj("pnlVehicleMake").style.display == "")
                    {
                        toggleVerifyAttribute("clMake", false);
                        changeLabel("pnlVehicleMake", "Vehicle Make:");
                    }

                    if (getObj("pnlBody").style.display == "")
                    {
                        toggleVerifyAttribute("clTrim", false);
                        changeLabel("pnlBody", "Body Style:");
                    }

                    if (getObj("pnlStyle").style.display == "")
                    {
                        toggleVerifyAttribute("clStyle", false);
                        changeLabel("pnlStyle", "Style:");
                    }

                    if (getObj("pnlLength").style.display == "")
                    {
                        toggleVerifyAttribute("clLength", false);
                        changeLabel("pnlLength", "Length:");
                    }

                    if (getObj("pnlWidth").style.display == "")
                    {
                        toggleVerifyAttribute("clWidth", false);
                        changeLabel("pnlWidth", "Width:");
                    }

                    if (getObj("pnlNumOfSections").style.display == "")
                    {
                        toggleVerifyAttribute("clNumOfSections", false);
                        changeLabel("pnlNumOfSections", "Number of Sections:");
                    }

                    if (getObj("pnlMileage").style.display == "")
                    {
                        toggleVerifyAttribute("clMi", false);
                        changeLabel("pnlMileage", "Mileage:");
                    }

                    if (getObj("pnlHoursUsed").style.display == "")
                    {
                        toggleVerifyAttribute("clHrs", false);
                        changeLabel("pnlHoursUsed", "Hours Used:");
                    }

                    if (getObj("pnlClBoatLength").style.display == "")
                    {
                        toggleVerifyAttribute("clBoatFeet", false);
                        changeLabel("pnlClBoatLength", "Length:");
                    }

                    if (getObj("pnlClCollIns") != null && getObj("pnlClCollIns").style.display == "")
                    {
                        toggleVerifyAttribute("clCollIns", false);
                        changeLabel("pnlClCollIns", "Collateral Insured By:");
                    }

                    if (getObj("pnlEvalBasis").style.display == "")
                    {
                        toggleVerifyAttribute("clEvalBasis", false);
                        changeLabel("pnlEvalBasis", "Basis of Evaluation:");
                    }
                }
            }
            else
            {
                // set the label text
                if (collateralType == "Mobile Home")
                {
                    if(getObj("requireMakeLbl").innerHTML == "true")
                        changeLabel("pnlBoatMake", "Manufacturer:<span class=\"required\"> *</span>");
                    else
                    {
                        changeLabel("pnlBoatMake", "Manufacturer:");
                        toggleVerifyAttribute("clBoatMake", false);
                    }

                    if(getObj("requireModelLbl").innerHTML == "true")
                        changeLabel("pnlModel", "Model:<span class=\"required\"> *</span>");
                    else
                    {
                        changeLabel("pnlModel", "Model:");
                        toggleVerifyAttribute("clModel", false);
                    }

                    getObj("clModel").errorText = "Model";


                    changeLabel("pnlVin", "Serial Number / VIN:");
                    getObj("clVin").errorText = "Serial Number / VIN";
                    toggleVerifyAttribute("clVin", false);
                    changeLabel("pnlValue", "Value:");
                    toggleVerifyAttribute("clVal", false);
                    getObj("clVal").errorText = "Value";
                }
                else if (collateralType == "Boat" || collateralType == "Trailer" ||
                         collateralType == "Boat Trailer" || collateralType == "Boat Motor")
                {
                    if(getObj("requireMakeLbl").innerHTML == "true")
                    {
                        if(collateralType == "Trailer" || collateralType == "Boat Trailer")
                            changeLabel("pnlBoatMake", "Trailer Manufacturer:<span class=\"required\"> *</span>");
                        else
                        {
                            changeLabel("pnlBoatMake", "Boat Manufacturer:<span class=\"required\"> *</span>");
                            changeLabel("pnlMotorMake", "Motor Manufacturer:<span class=\"required\"> *</span>");
                        }
                    }
                    else
                    {
                        if(collateralType == "Trailer" || collateralType == "Boat Trailer")
                        {
                            changeLabel("pnlBoatMake", "Boat Trailer:");
                            toggleVerifyAttribute("clBoatMake", false);
                        }
                        else
                        {
                            changeLabel("pnlBoatMake", "Boat Manufacturer:");
                            toggleVerifyAttribute("clBoatMake", false);
                            changeLabel("pnlMotorMake", "Motor Manufacturer:");
                            toggleVerifyAttribute("clMotorMake", false);
                        }
                    }

                    if(getObj("requireModelLbl").innerHTML == "true")
                    {
                        changeLabel("pnlModel", "Boat Model:<span class=\"required\"> *</span>");
                        changeLabel("pnlMotorType", "Motor Type:<span class=\"required\"> *</span>");
                    }
                    else
                    {
                        changeLabel("pnlModel", "Boat Model:");
                        toggleVerifyAttribute("clModel", false);
                        changeLabel("pnlMotorType", "Motor Type:");
                        toggleVerifyAttribute("clMotorType", false);
                    }

                    getObj("clModel").errorText = "Boat Model";
                    changeLabel("pnlVin", "Serial Number:");
                    getObj("clVin").errorText = "Serial Number";
                    toggleVerifyAttribute("clVin", false);
                    changeLabel("pnlValue", "Value:");
                    toggleVerifyAttribute("clVal", false);
                    getObj("clVal").errorText = "Value";
                }
                else if(collateralType == "Generic")
                {
                    changeLabel("pnlEquipmentDesc", "Description:");
                    getObj("clDesc").errorText = "Description";
                    toggleVerifyAttribute("clDesc", false);
                    changeLabel("pnlVin", "Serial Number:");
                    toggleVerifyAttribute("clVin", false);
                    changeLabel("pnlValue", "Value:");
                    toggleVerifyAttribute("clVal", false);
                    getObj("clVal").errorText = "Value";
                }
                else if (collateralType == "Certificate of Deposit")
                {
                    if(getObj("requireIssuerLbl").innerHTML == "true")
                    {
                        changeLabel("pnlClIssuer", "Issuer:<span class=\"required\"> *</span>");
                        toggleVerifyAttribute("clIssuer", true);
                    }
                    else
                    {
                        changeLabel("pnlClIssuer", "Issuer:");
                        toggleVerifyAttribute("clIssuer", false);
                    }

                    if(getObj("requireValueLbl").innerHTML == "true")
                    {
                        changeLabel("pnlValue", "Value:<span class='required'> *</span>");
                        toggleVerifyAttribute("clVal", true);
                    }
                    else
                    {
                        changeLabel("pnlValue", "Value:");
                        toggleVerifyAttribute("clVal", false);
                    }
                    
                    hide("pnlClNwUsed");
                }
                else if (collateralType == "Savings")
                {
                    changeLabel("pnlValue", "Value:");
                    toggleVerifyAttribute("clVal", false);
                }
                else
                {
                    if(collateralType == "Motorcycle" || collateralType == "Recreational Vehicle")
                    {
                        if(getObj("requireMakeLbl").innerHTML == "true")
                            changeLabel("pnlBoatMake", "Vehicle Make:<span class=\"required\"> *</span>");
                        else
                        {
                            changeLabel("pnlBoatMake", "Vehicle Make:");
                            toggleVerifyAttribute("clBoatMake", false);
                        }

                        getObj("clBoatMake").errorText = "Vehicle Make";
                    }
                    
                    if(getObj("requireModelLbl").innerHTML == "true")
                        changeLabel("pnlModel", "Vehicle Model:<span class=\"required\"> *</span>");
                    else
                    {
                        changeLabel("pnlModel", "Vehicle Model:");
                        toggleVerifyAttribute("clModel", false);
                    }
                    getObj("clModel").errorText = "Vehicle Model";
                    
                    changeLabel("pnlVin", "VIN:");
                    getObj("clVin").errorText = "VIN";
                    toggleVerifyAttribute("clVin", false);
                    changeLabel("pnlValue", "Vehicle Value:");
                    toggleVerifyAttribute("clVal", false);
                    getObj("clVal").errorText = "Vehicle Value";
                }

                var theScen = getObj("sceneLbl").innerHTML;
                if (theScen == "secured" || theScen == "busSecured")
                {
                    if(collateralType != "Certificate of Deposit" && 
                        collateralType != "Savings")
                    {
                        if(getObj("reqFieldBasedOnPreApprovalLbl").innerHTML == "true" || 
                            getObj("showCollateralFieldsLbl").innerHTML == "true")
                        {
                            show("pnlEquipmentDesc");
                            changeLabel("pnlEquipmentDesc", "Description:");
                            toggleVerifyAttribute("clDesc", false);
                        }
                    }
                }

                if (getObj("pnlHaveTrade").style.display == "")
                {
                    changeLabel("pnlHaveTrade", "Is there a Trade-in?");
                    toggleVerifyAttribute("clXstgLien", false);
                }

                changeLabel("pnlClPrchPrice", "Purchase Price:");
                toggleVerifyAttribute("clPrchPrice", false);

                changeLabel("pnlClDownPmt", "Down Payment:");
                toggleVerifyAttribute("clDownPmt", false);

                if (getObj("pnlClYr").style.display == "")
                    changeLabel("pnlClYr", "Year:<span class=\"required\"> *</span>");

                if (getObj("pnlVehicleMake").style.display == "")
                {
                    if(getObj("requireMakeLbl").innerHTML == "true")
                        changeLabel("pnlVehicleMake", "Vehicle Make:<span class=\"required\"> *</span>");
                    else
                    {
                        changeLabel("pnlVehicleMake", "Vehicle Make:");
                        toggleVerifyAttribute("clMake", false);
                    }
                }

                if (getObj("pnlBody").style.display == "")
                {
                    changeLabel("pnlBody", "Body Style:");
                    toggleVerifyAttribute("clTrim", false);
                }

                if (getObj("pnlStyle").style.display == "")
                {
                    changeLabel("pnlStyle", "Style:");
                    toggleVerifyAttribute("clStyle", false);
                }

                if (getObj("pnlLength").style.display == "")
                {
                    changeLabel("pnlLength", "Length:");
                    toggleVerifyAttribute("clLength", false);
                }

                if (getObj("pnlWidth").style.display == "")
                {
                    changeLabel("pnlWidth", "Width:");
                    toggleVerifyAttribute("clWidth", false);
                }

                if (getObj("pnlNumOfSections").style.display == "")
                {
                    changeLabel("pnlNumOfSections", "Number of Sections:");
                    toggleVerifyAttribute("clNumOfSections", false);
                }

                if (getObj("pnlMileage").style.display == "")
                {
                    changeLabel("pnlMileage", "Mileage:");
                    toggleVerifyAttribute("clMi", false);
                }

                if (getObj("pnlHoursUsed").style.display == "")
                {
                    changeLabel("pnlHoursUsed", "Hours Used:");
                    toggleVerifyAttribute("clHrs", false);
                }

                if (getObj("pnlClBoatLength").style.display == "")
                {
                    changeLabel("pnlClBoatLength", "Length:");
                    toggleVerifyAttribute("clBoatFeet", false);
                }

                if (getObj("pnlClCollIns") != null && getObj("pnlClCollIns").style.display == "")
                {
                    changeLabel("pnlClCollIns", "Collateral Insured By:");
                    toggleVerifyAttribute("clCollIns", false);
                }

                if (getObj("pnlEvalBasis").style.display == "")
                    changeLabel("pnlEvalBasis", "Basis of Evaluation:");
            }

            //show or hide the evalBasis
            if(getObj("hidShowEvalBasis").innerHTML == "true")
            {
                if(getObj("reqFieldBasedOnPreApprovalLbl").innerHTML == "true" || 
                    getObj("showCollateralFieldsLbl").innerHTML == "true" ||
                    (collateralType == "Trailer" || collateralType == "Boat Trailer"))
                {
                    show("pnlEvalBasis");
                    if(getObj("reqFieldBasedOnPreApprovalLbl").innerHTML == "false")
                    {
                        toggleVerifyAttribute("clEvalBasis", false);
                    }
                }
                else
                    hide("pnlEvalBasis");
            }
            else
                hide("pnlEvalBasis");

            //show or hide insurance questions
            if (collateralType == "Boat" || collateralType == "Trailer" ||
                collateralType == "Boat Trailer" || collateralType == "Boat Motor" ||
                collateralType == "Machinery and Equipment" || collateralType == "Construction Equipment" ||
                collateralType == "Mobile Home" || collateralType == "Motorcycle" || 
                collateralType == "Recreational Vehicle" || collateralType == "Automobile")
            {
                if(getObj("showMechRepairLbl").innerHTML == "true")
                    show("pnlMechRepair");
                else
                    hide("pnlMechRepair");

                if(getObj("showGapInsLbl").innerHTML == "true")
                    show("pnlGapProtection");
                else
                    hide("pnlGapProtection");
            }
            else
            {
                hide(new Array("pnlMechRepair",
                    "pnlGapProtection"));
            }

            //show or hide the year text
            if(getObj("pnlClYr").style.display == "" && getObj("showCVlYrTxtLbl").innerHTML == "true")
                show("pnlClYrTxt");
            else
                hide("pnlClYrTxt");
                
            //unrequire the year
            if(getObj("requireYearLbl").innerHTML == "false")
            {
                toggleVerifyAttribute("clYr", false);
                
                if(getObj("showYearHelpLbl").innerHTML.length > 0)    
                    changeLabel("pnlClYr", getObj("showYearHelpLbl").innerHTML);
                else
                    changeLabel("pnlClYr", "Year:");
            }
            
            //show or hide  new / used
            if (collateralType == "Boat" || collateralType == "Trailer" ||
                collateralType == "Boat Trailer" || collateralType == "Boat Motor" ||
                collateralType == "Machinery and Equipment" || collateralType == "Construction Equipment" ||
                collateralType == "Mobile Home" || collateralType == "Generic" ||
                collateralType == "Motorcycle" || collateralType == "Recreational Vehicle" ||
                collateralType == "Automobile")
            {
                show("pnlClNwUsed");
                if (getObj("pnlUsedDetails").style.display == "")
                {
                    if (getObj("requireNewUsedLbl").innerHTML == "false")
                    {
                        changeLabel("pnlClNwUsed", getObj("newUsedLbl").innerHTML);
                        toggleVerifyAttribute("clNwUsed", false);
                    }
                    else
                        changeLabel("pnlClNwUsed", getObj("newUsedLbl").innerHTML + "<span class=\"required\"> *</span>");

                    if (getObj("showCollateralCodeLbl").innerHTML == "true")
                    {
                        changeLabel("pnlClCollateralCode", "Collateral Code: <span class=\"required\">*</span>");
                        toggleVerifyAttribute("clCollateralCode", true);
                    }
                    else
                    {
                        changeLabel("pnlClCollateralCode", "Collateral Code:");
                        toggleVerifyAttribute("clCollateralCode", false);
                    }
                }
            }
            else
            {
                hide("pnlClNwUsed");

                if (getObj("showCollateralCodeLbl").innerHTML == "true")
                    show("pnlClCollateralCode");
                else
                    hide("pnlClCollateralCode");
            }

            if(getObj("hideNewUsedLbl").innerHTML == "true")
                hide("pnlClNwUsed");
                
            //always hide this
            if(getObj("reqFieldBasedOnPreApprovalLbl").innerHTML == "true")
                hide("pnlValue");

            //read to applicant text    
            if(getObj("readToApplicantLbl").innerHTML == "true")
            {
                show("pnlReadToApplicantVehicleCollateral");
                hide(new Array("readToAppVehicle",
                    "readToAppBoat",
                    "readToAppMotorcycle",
                    "readToAppRecVehicle",
                    "readToAppDebtConsolidationLbl",
                    "readToAppPersonalLoan",
                    "readToAppEducation",
                    "readToAppCashReserve",
                    "readToAppVisa"));

                if (collateralType == "Automobile")
                {
                    show("readToAppVehicle");
                }
                else if (collateralType == "Boat" || collateralType == "Trailer" ||
                    collateralType == "Boat Trailer" || collateralType == "Boat Motor")
                {
                    show("readToAppBoat");
                }
                else if (collateralType == "Motorcycle")
                {
                    show("readToAppMotorcycle");
                }
                else if (collateralType == "Recreational Vehicle")
                {
                    show("readToAppRecVehicle");
                }
            }
            else
                hide("pnlReadToApplicantVehicleCollateral");
               
            if(getObj("hideDownPaymentLbl").innerHTML == "true")
                hide("pnlClDownPmt");
                
            if(getObj("hidePurchasePriceLbl").innerHTML == "true")
                hide("pnlClPrchPrice");
                
            if (getObj("requireValueFieldLbl").innerHTML == "true")
            {
                if (getObj("requireValueLbl").innerHTML == "true")
                {
                    getObj("clValLbl").innerHTML += "<span class=\"required\"> *</span>";
                    toggleVerifyAttribute("clVal", true);
                }
            
                if (getObj("requireBasisOfEvalLbl").innerHTML == "true")
                {
                    getObj("clEvalBasisLbl").innerHTML += "<span class=\"required\"> *</span>";
                    toggleVerifyAttribute("clEvalBasis", true);
                }
                else
                {
                    toggleVerifyAttribute("clEvalBasis", false);
                }
            }
            
            if(getObj("showPurchasePriceLbl").innerHTML == "true")
            {
                show("pnlClPrchPrice");
                changeLabel("pnlClPrchPrice", "Purchase Price:<span class=\"required\"> *</span>");
            }
            
            if(getObj("showSellerNameLbl").innerHTML == "true")
                show("pnlClSellerName");
            else
                hide("pnlClSellerName");
                
            if(getObj("requireIssuerOpenDateAccuralRateLbl").innerHTML == "false")
            {
                changeLabel("pnlClIssuer", "Issuer:");
                toggleVerifyAttribute("clIssuer", false);
                changeLabel("pnlClOpenDt", "Open Date:");
                toggleVerifyAttribute("clOpenDt", false);
                changeLabel("pnlClAccrlRate", "Accrual Rate:");
                toggleVerifyAttribute("clAccrlRate", false);
            }
            
            if(getObj("requireVinLbl").innerHTML == "true")
            {
                getObj("clVinLbl").innerHTML += "<span class=\"required\"> *</span>";
                toggleVerifyAttribute("clVin", true);
            }
            else
            {
                toggleVerifyAttribute("clVin", false);
                if(getObj("clVinLbl").innerHTML.indexOf("Serial Number") == -1)
                    getObj("clVinLbl").innerHTML = "VIN:";
                else
                    getObj("clVinLbl").innerHTML = "Serial Number:";
            }
        }

        function enableContinueButtons()
        {
            getObj("Continue").disabled = false;
            getObj("Continue_Top").disabled = false;
            getObj("AddCollateral").disabled = false;
        }

        function toggleAppNameOnDeed()
        {
            var el = getObj("correctAppNameOnDeed").options.selectedIndex;

            if(el == 0 || el == 1)
            {
                hide("pnlAppNameOnDeed");
                getObj("appNameOnDeed").value = "";
            }
            else if (el == 2)
                show("pnlAppNameOnDeed");
        }

        function toggleCoAppNameOnDeed()
        {
            if(getObj("correctCoAppNameOnDeedLbl").innerHTML.length > 0)
            {
                var el = getObj("correctCoAppNameOnDeed").options.selectedIndex;

                if(el == 0 || el == 1)
                {
                    hide("pnlCoAppNameOnDeed");
                    getObj("coAppNameOnDeed").value = "";
                }
                else if (el == 2)
                    show("pnlCoAppNameOnDeed");
            }
            else
                hide("pnlCorrectCoAppNameOnDeed");
        }
        
        function toggleLoanPurposeFields()
        {
            if (getObj("showPayeeDetailsLbl").innerHTML == "true")
            {
                if(getObj("anLoanDesc").options[getObj("anLoanDesc").selectedIndex].value == "AUFI" ||
                   getObj("anLoanDesc").options[getObj("anLoanDesc").selectedIndex].value == "AUFO")
                {
                    show("pnlPayeeDetails");
                }
                else
                    clearAndHidePayeeDetails();
            }
            else
                clearAndHidePayeeDetails();
                
           if (getObj("showSpecificUseOfProceedsESLLbl").innerHTML == "true")
           {
                if(getObj("anLoanDesc").options[getObj("anLoanDesc").selectedIndex].value == "PRUD" ||
                   getObj("anLoanDesc").options[getObj("anLoanDesc").selectedIndex].value == "BUSI")
                {
                    show("pnlAnSpecificUseOfProceeds");
                }
                else
                {
                    getObj("anSpecificUseOfProceeds").value = "";
                    hide("pnlAnSpecificUseOfProceeds");
                }
           }
           else
           {
                if(getObj("showSpecificUseOfProceedsLbl").innerHTML == "true")
                {
                    getObj("anSpecificUseOfProceeds").errorText = "Specific Use of Proceeds";
                    show("pnlAnSpecificUseOfProceeds");
                    if(getObj("unRequireSpecificUseOfProceedsLbl").innerHTML == "true")
                    {
                        toggleVerifyAttribute("anSpecificUseOfProceeds", false);
                    }
                }
                else
                {
                    getObj("anSpecificUseOfProceeds").value = "";
                    hide("pnlAnSpecificUseOfProceeds");
                }
           }
        }
        
        function toggleHELoanPurposeFields()
        {
           if (getObj("showHESpecificUseOfProceedsLbl").innerHTML == "true")
                show("pnlAnHESpecificUseOfProceeds");
           else
           {
                getObj("anHESpecificUseOfProceeds").value = "";
                hide("pnlAnHESpecificUseOfProceeds");
           }
           
        }
        
        function toggleMemberGuard()
        {
            if(getObj("anMemberGuard").options[getObj("anMemberGuard").selectedIndex].value == "Single" || 
               getObj("anMemberGuard").options[getObj("anMemberGuard").selectedIndex].value == "Joint")
            {
                show("pnlAnMemberGuardPlan");
            }
            else
            {
                getObj("anMemberGuardPlan").selectedIndex = 0;
                hide("pnlAnMemberGuardPlan");           
            }
        }
        
        function toggleCoOwnerFields()
        {
            if (getObj("showCoOwnerLbl").innerHTML == "true")
            {
                show("pnlAnCoOwnerInc");
                if(getObj("anCoOwnerInc").options[getObj("anCoOwnerInc").selectedIndex].value == "Yes")
                    show("pnlAnCoOwner");
                else
                {
                    getObj("anCoOwner1").value = "";
                    getObj("anCoOwner2").value = "";
                    hide("pnlAnCoOwner");
                }
            }
            else
            {
                getObj("anCoOwner1").value = "";
                getObj("anCoOwner2").value = "";
                hide(new Array("pnlAnCoOwnerInc",
                    "pnlAnCoOwner"));
            }
        }
        
        function clearAndHidePayeeDetails()
        {
            getObj("payeeAcctNum").value = "";
            getObj("payeeFName").value = "";
            getObj("payeeLName").value = "";
            getObj("payeeAddr").value = "";
            getObj("payeeAddrTwo").value = "";
            getObj("payeeCity").value = "";
            getObj("payeeState").selectedIndex = 0;
            getObj("payeeZip").value = "";
            
            getObj("payeeZipPlus").value = "";
            getObj("payeePh1").value = "";
            getObj("payeePh2").value = "";
            getObj("payeePh3").value = "";
            
            hide("pnlPayeeDetails");
        }
        
        function togglePreApprovalField()
        {
            if (getObj("showPreApprovalLbl").innerHTML == "true")
            {
                show("pnlAnPreApv");
                getObj("requireValueFieldLbl").innerHTML = "true";
                if(getObj("anPreApv").options[getObj("anPreApv").selectedIndex].value == "Yes")
                {
                    getObj("requireMakeLbl").innerHTML = "false";
                    getObj("requireModelLbl").innerHTML = "false";
                    getObj("requireValueLbl").innerHTML = "false";
                    getObj("requireVinLbl").innerHTML = "false";
                }
                else
                {
                    getObj("requireMakeLbl").innerHTML = "true";
                    getObj("requireModelLbl").innerHTML = "true";
                    getObj("requireValueLbl").innerHTML = "true";
                    getObj("requireVinLbl").innerHTML = "true";
                }
            }
            else
                hide("pnlAnPreApv");
                
            toggleCollateralFields();
        }
        
        function hideCollateralFieldsForHomeImprovement()
        {
            hide(new Array("pnlPhyCntyDDL",
                "pnlPhyOccType",
                "pnlPhyValEst",
                "pnlSelLienHolders",
                "pnlAnSignDocs",
                "pnlGfx4"));
        }
        
        function toggleUsedDetails()
        {

            if(getObj("additionalCollateral1").checked)
            {
                show("pnlUsedDetails");
                toggleCollateralFields();
            }
            else
            {
                toggleCollateralFields();
                hide("pnlUsedDetails");
            }
        }
        
        function displayCollateral()
        {
            getObj("additionalCollateral2").checked = false;
            getObj("additionalCollateral1").checked = true;
            toggleUsedDetails();
        }