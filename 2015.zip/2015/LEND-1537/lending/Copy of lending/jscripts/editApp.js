addEvent(window, "load", Init);

        function Init()
        {
        }

        function disableButton()
        {
            getObj("Continue").style.display = "none";
        }

        window.onbeforeunload = confirmExit;
        var needToConfirm = true;
        function confirmExit()
        {
            if(needToConfirm)
            {
                var myXMLHTTPRequeset = new S1XMLHTTPRequest();
                myXMLHTTPRequeset.xmlhttpGet("pageClose.aspx");
            }
        }

        //this is used to send the update request while the continue button is hidden 
        //from the user so that it can not be pressed twice.  This script will run everytime 
        //the page is loaded\refreshed.  The Page_Load event will set an attribute on the button
        //if the page is being posted back.
        <%
            if(GetHideButton())
                SendDsbUpdate();
        %>;