addEvent(window, "load", Init);
        
            function Init() 
            {
                if(getObj("consultantTypeLbl").innerHTML == "Refinance")
                {
                    hide("pnlPurchase");
                    getObj("phyPrchPrice").value = "";
                    getObj("anDownPayment").value = "";
                    getObj("anClosingCostPaidBySeller").value = "";
                    
                    show("pnlRefinance");
                }
                else
                {
                    hide("pnlRefinance");
                    getObj("phyValEst").value = "";
                    getObj("anRefinanceAmount").value = "";
                    getObj("anMortgageBalance").value = "";
                    
                    show("pnlPurchase");
                }
                
                hide("pnlSpacer1");
            }