addEvent(window, "load", Init);

        function Init()
        {
            hide(new Array("tradeDebtBalTemp",
                "tradeDebtPayoffTemp"));
            var sigLoanTable = getObj("debtTable");
            for (rowNum = 0; rowNum < sigLoanTable.rows.length - 1; rowNum++)
            {
                addEvent("payoff_" + rowNum, 	"click", SetTradeDebts);
                addEvent("balance_" + rowNum, 	"blur", SetTradeDebts);
            }
            
        }

        window.onbeforeunload = confirmExit;
        var needToConfirm = true;
        function confirmExit()
        {
            if(needToConfirm)
            {
                var myXMLHTTPRequeset = new S1XMLHTTPRequest();
                myXMLHTTPRequeset.xmlhttpGet("pageClose.aspx");
            }
        }

        function SetTradeDebts()
        {
            var sigLoanTable = getObj("debtTable");
            var useComma = false;
            for (rowNum = 0; rowNum < sigLoanTable.rows.length - 1; rowNum++)
            {
                //round UP to the nearest integer... leave commented out per CKD
                //getObj("balance_" + rowNum).value = Math.ceil(getObj("balance_" + rowNum).value).toFixed(2);
                if(useComma)
                {
                    getObj("tradeDebtBalTemp").value += "," + rowNum + "_" + getObj("balance_" + rowNum).value;
                    if(getObj("payoff_" + rowNum).checked)
                        getObj("tradeDebtPayoffTemp").value += "," + rowNum + "_" + "true";
                    else
                        getObj("tradeDebtPayoffTemp").value += "," + rowNum + "_" + "false";
                }
                else
                {
                    getObj("tradeDebtBalTemp").value = rowNum + "_" + getObj("balance_" + rowNum).value;
                    if(getObj("payoff_" + rowNum).checked)
                        getObj("tradeDebtPayoffTemp").value = rowNum + "_" + "true";
                    else
                        getObj("tradeDebtPayoffTemp").value = rowNum + "_" + "false";
                    useComma = true;
                }
            }
        }