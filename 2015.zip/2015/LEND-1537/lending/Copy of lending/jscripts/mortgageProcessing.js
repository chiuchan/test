addEvent(window, "load", Init);

            function Init() 
            {
                setTimeout("swapProc()", 2000);
            }

            function swapProc() 
            {
	            toggle(new Array("pnlProc", "pnlButton"));
            }