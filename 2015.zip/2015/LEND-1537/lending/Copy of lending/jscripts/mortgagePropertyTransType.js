addEvent(window, "load", Init);

function Init() 
        {	
            initOwnRealEstate();
            toggleOwnRealEstate();
            toggleNumberUnits();
            toggleAssetPropertyFinanced();
            togglePropertyFinanced();
            toggleTransTypeFields();
            toggleTaxAndInsFields();
            toggleEscrowTaxAndInsFields();
            toggleAdditioanlTaxAndInsFields();
            
            hide("pnlSpacer1");
            
	        addEvent("radAdditionalProp1", "click", toggleAdditionalProperty);
	        addEvent("radAdditionalProp2", "click", toggleAdditionalProperty);

	        addEvent("assetFinanced1", "click", toggleAndClearAssetPropertyFinanced);
	        addEvent("assetFinanced2", "click", toggleAndClearAssetPropertyFinanced);	
	        
	        addEvent("phyFinanced1", "click", toggleAndClearPropertyFinanced);
	        addEvent("phyFinanced2", "click", toggleAndClearPropertyFinanced);
	        
	        addEvent("anOwnRealEstateProp", "change", toggleOwnRealEstate);
	        addEvent("anOwnRealEstateProp", "keyup", toggleOwnRealEstate);
        	
	        addEvent("anNumberUnits", "change", toggleAndClearNumberUnits);
	        addEvent("anNumberUnits", "keyup", toggleAndClearNumberUnits);
        	
	        addEvent("anPropFinanced", "change", checkProperty);
	        addEvent("anPropFinanced", "keyup", checkProperty);
	        
	        addEvent("anAddrOfProperty1", "click", toggleAndClearPropertyAddrFields);
	        addEvent("anAddrOfProperty2", "click", toggleAndClearPropertyAddrFields);	
	        
	        addEvent("anKnowTaxAndIns", "change", toggleAndClearTaxAndInsFields);
	        addEvent("anKnowTaxAndIns", "keyup", toggleAndClearTaxAndInsFields);
	        
	        addEvent("anEscrowInsAndTaxes", "change", toggleEscrowTaxAndInsFields);
	        addEvent("anEscrowInsAndTaxes", "keyup", toggleEscrowTaxAndInsFields);
	        
	        addEvent("assetKnowTaxAndIns", "change", toggleAndClearAdditioanlTaxAndInsFields);
	        addEvent("assetKnowTaxAndIns", "keyup", toggleAndClearAdditioanlTaxAndInsFields);
	        
	        if(getObj("showSaveSuccessLbl").innerHTML == "true")
	            showSaveSuccessAlert();
        }
        
        window.onbeforeunload = confirmExit;
        var needToConfirm = true;
        function confirmExit(el)
        {
            if(el == "true" || needToConfirm)
            {
                var myXMLHTTPRequeset = new S1XMLHTTPRequest();
                myXMLHTTPRequeset.xmlhttpGet("pageClose.aspx");
            }
        }
        
        function initOwnRealEstate()
        {
            if(getObj("transTypeLbl").innerHTML == "Refinance")
            {
                getObj("anOwnRealEstateProp").selectedIndex = "1";
                show("refiText");
            }
            else
                hide("refiText");
        }
        
        function toggleOwnRealEstate()
        {
            var el = getObj("anOwnRealEstateProp");
            if (el.options[el.selectedIndex].value == "Yes")
            {
                var reAssetTable = getObj("assetPropertyTable");
                if(reAssetTable.rows.length < 2)
                {
                    hide("pnlRadAdditionalProp");
                    show("AddRealEstatePanel");
                    
                    if(getObj("showPropertyOwnerLbl").innerHTML == "true")
                        show("pnlAtAssetPropertyOwner");
                    else
                        hide("pnlAtAssetPropertyOwner");
                }
                else
                {
                    show("pnlRadAdditionalProp");
                    toggleAdditionalProperty();
                }
                    
                show("pnlOwnRealEstate");
            }
            else
                hide("pnlOwnRealEstate");
        }
        
        function toggleNumberUnits()
        {
            var el = getObj("anNumberUnits");
	        if (el.options[el.selectedIndex].value != "" && el.options[el.selectedIndex].value != "1")
		        show("RentalIncomePanel");
	        else
		        hide("RentalIncomePanel");
        }
        
        function toggleAndClearNumberUnits()
        {
            var el = getObj("anNumberUnits");
	        if (el.options[el.selectedIndex].value != "" && el.options[el.selectedIndex].value != "1")
		        show("RentalIncomePanel");
	        else
	        {
	            getObj("anEstimatedGrossRentalIncome").value = "";
		        hide("RentalIncomePanel");
		    }
        }

        function checkProperty()
        {
	        var el = getObj("anPropFinanced");

	        if (el.options[el.selectedIndex].value == "sym")
		        show("FinanceSymAddPanel");
	        else
		        hide("FinanceSymAddPanel");
		        
		    toggleAndClearTaxAndInsFields();
        }
        
        function toggleAssetPropertyFinanced()
        {
            if(getObj("assetFinanced1").checked)
                show("AssetPropertyFinancedPanel");
            else
                hide("AssetPropertyFinancedPanel");
        }
        
        function toggleAndClearAssetPropertyFinanced()
        {
            if(getObj("assetFinanced1").checked)
                show("AssetPropertyFinancedPanel");
            else
            {
                getObj("assetMortgageLienAmount").value = "";
                getObj("assetMortgagePayments").value = "";
                getObj("assetEscrowTaxes1").checked = false;
                getObj("assetEscrowTaxes2").checked = true;
                getObj("assetMortgageInsurance").value = "";
                
                hide("AssetPropertyFinancedPanel");
            }
        }
        
        function togglePropertyFinanced()
        {
            if(getObj("phyFinanced1").checked)
                show("PropertyFinancedPanel");
            else
                hide("PropertyFinancedPanel");
        }
        
        function toggleAndClearPropertyFinanced()
        {
            if(getObj("phyFinanced1").checked)
                show("PropertyFinancedPanel");
            else
            {
                getObj("mortgageLienAmount").value = "";
                getObj("mortgagePayments").value = "";
                getObj("escrowTaxes1").checked = false;
                getObj("escrowTaxes2").checked = true;
                getObj("mortgageInsurance").value = "";
                
                hide("PropertyFinancedPanel");
            }
        }
        
        function toggleAdditionalProperty()
        {
            if(getObj("radAdditionalProp1").checked)
            {
                show("AddRealEstatePanel");
                
                if(getObj("showPropertyOwnerLbl").innerHTML == "true")
                    show("pnlAtAssetPropertyOwner");
                else
                    hide("pnlAtAssetPropertyOwner");
            }
            else
                hide("AddRealEstatePanel");
        }
        
        function toggleTransTypeFields()
        {
            if(getObj("transTypeLbl").innerHTML == "Refinance")
            {
                hide(new Array("pnlAnPurchasePrice",
                    "pnlAnDownPayment",
                    "pnlAnClosingCostPaidBySeller",
                    "pnlAnAddrOfProperty",
                    "pnlAddress",
                    "FinanceSymAddPanel"));
            }
            else if(getObj("transTypeLbl").innerHTML == "Purchase")
            {
                hide(new Array("pnlAnAddrOfProperty",
                    "pnlAnPropFinanced",
                    "pnlAnRefinanceAmount",
                    "pnlAnSpecificUseOfProceeds",
                    "pnlAnPropertyValue",
                    "pnlAnMortgageBalance",
                    "pnlPhyPrchYr",
                    "pnlPhyPropDisposition",
                    "pnlPhyRefiCounty",
                    "pnlPhyFinanced",
                    "pnlPhyRefiPropType"));
                show("pnlAddress");
                
                
                changeLabel("pnlAnOwnRealEstateProp", "Do you own any other real estate properties? <span class='required'>*</span>");
                getObj("anOwnRealEstateProp").errorText = "Do you own any other real estate properties?";
            }
            else if(getObj("transTypeLbl").innerHTML == "PreApproval")
            {
                hide(new Array("pnlAnAddrOfProperty",
                    "pnlAddress",
                    "pnlAnPropFinanced",
                    "pnlAnRefinanceAmount",
                    "pnlAnSpecificUseOfProceeds",
                    "pnlAnPropertyValue",
                    "pnlAnMortgageBalance",
                    "pnlPhyPrchYr",
                    "pnlPhyRefiCounty",
                    "pnlPhyFinanced",
                    "pnlPhyPropDisposition",
                    "pnlPhyRefiPropType"));
            }
        }
        
        function toggleAndClearPropertyAddrFields()
        {
            if(getObj("anAddrOfProperty1").checked)
                show("pnlAddress");
            else
            {
                getObj("phyAddr").value = "";
                getObj("phyAddrTwo").value = "";
                getObj("phyCity").value = "";
                //skip the state becuase it is also set on a previous page
                getObj("phyZip").value = "";
                getObj("phyZipPlus").value = "";
                getObj("phyCounty").value = "";
                hide("pnlAddress");
            }
        }
        
        function toggleTaxAndInsFields()
        {
            if(getObj("anKnowTaxAndIns").options[getObj("anKnowTaxAndIns").selectedIndex].value == "Yes")
            {
                show("pnlTaxAndIns");
                hide("taxAndInsText");
            }
            else if(getObj("anKnowTaxAndIns").options[getObj("anKnowTaxAndIns").selectedIndex].value == "No")
            {
                show("taxAndInsText");
                hide("pnlTaxAndIns");
            }
            else
                hide(new Array("taxAndInsText",
                    "pnlTaxAndIns"));
        }
        
        function toggleAndClearTaxAndInsFields()
        {
            if(getObj("anKnowTaxAndIns").options[getObj("anKnowTaxAndIns").selectedIndex].value == "Yes")
            {
                show("pnlTaxAndIns");
                hide("taxAndInsText");
            }
            else
            {
                getObj("anHazardInsurance").value = "";
                getObj("anReSchoolTaxes").value = "";
                getObj("anRePropTaxes").value = "";
                getObj("anHomeOwnerAssocDues").value = "";
                
                if(getObj("anKnowTaxAndIns").options[getObj("anKnowTaxAndIns").selectedIndex].value == "No")
                {
                    hide("pnlTaxAndIns");
                    show("taxAndInsText");
                }
                else
                {
                    hide(new Array("pnlTaxAndIns",
                        "taxAndInsText"));    
                }
            }
        }
        
        function toggleEscrowTaxAndInsFields()
        {
            if(getObj("anEscrowInsAndTaxes").options[getObj("anEscrowInsAndTaxes").selectedIndex].value == "No")
                show("anEscrowInsAndTaxesText");
            else
                hide("anEscrowInsAndTaxesText");
        }
        
        function toggleAdditioanlTaxAndInsFields()
        {
            if(getObj("assetKnowTaxAndIns").options[getObj("assetKnowTaxAndIns").selectedIndex].value == "Yes")
            {
                show("pnlAssetTaxAndIns");
                hide("assetTaxAndInsText");
            }
            else if(getObj("assetKnowTaxAndIns").options[getObj("assetKnowTaxAndIns").selectedIndex].value == "No")
            {
                hide("pnlAssetTaxAndIns");
                show("assetTaxAndInsText");
            }
            else
            {
                hide(new Array("pnlAssetTaxAndIns",
                    "assetTaxAndInsText"));
            }
        }
        
        function toggleAndClearAdditioanlTaxAndInsFields()
        {
            if(getObj("assetKnowTaxAndIns").options[getObj("assetKnowTaxAndIns").selectedIndex].value == "Yes")
            {
                show("pnlAssetTaxAndIns");
                hide("assetTaxAndInsText");
            }
            else
            {
                getObj("haxardInsurance").value = "";
                getObj("reSchoolTaxes").value = "";
                getObj("rePropTaxes").value = "";
                getObj("assetHomeOwnerDues").value = "";
                
                if(getObj("assetKnowTaxAndIns").options[getObj("assetKnowTaxAndIns").selectedIndex].value == "No")
                {
                    hide("pnlAssetTaxAndIns");
                    show("assetTaxAndInsText");
                }
                else
                {
                    hide(new Array("pnlAssetTaxAndIns",
                        "assetTaxAndInsText"));
                }
            }
        }
        
        function displayCreditPullAlert()
        {
            hide(new Array("Continue",
                "Continue_Top"));
            show(new Array("ContinueDisabled",
                "Continue_Top_Disabled"));
                
            getObj("continueButtonLbl").innerHTML = "ContinueDisabled";
            getObj("continueTopButtonLbl").innerHTML = "Continue_Top_Disabled";
            
            alert("Please stand by while your application is being processed.");
        }