addEvent(window, "load", Init);

        function Init()
        {
            // trust
            addEvent("dsbType", 	"change", toggleDsbFields);
	        addEvent("dsbType", 	"keyup",  toggleDsbFields);

            toggleDsbFields("false");
            calcDsbTotals();
            
            if(getObj("showInsQuestionsLbl").innerHTML == "true")
                show(new Array("pnlAnCredLifeIns",
                    "pnlAnCredDisabIns"));
            else
                hide(new Array("pnlAnCredLifeIns",
                    "pnlAnCredDisabIns"));
        }

        window.onbeforeunload = confirmExit;
        var needToConfirm = true;
        function confirmExit()
        {
            if(needToConfirm)
            {
                var myXMLHTTPRequeset = new S1XMLHTTPRequest();
                myXMLHTTPRequeset.xmlhttpGet("pageClose.aspx");
            }
        }

        function toggleDsbFields(clearFields)
        {
            if(clearFields != "false")
            {
                getObj("dsbName").value = "";
                getObj("dsbCheckNum").value = "";
                getObj("dsbPayoffType").selectedIndex = 0;
                getObj("dsbLoanNum").value = "";
                getObj("dsbAcctNum").value = "";
                getObj("dsbLoanDate").value = "";
                getObj("dsbLoanOrigPur").value = "";
                getObj("dsbLoanOrigBal").value = "";
                getObj("dsbLoanLateFees").value = "";
                getObj("dsbLoanIntDue").value = "";
                getObj("dsbLoanIntDueDate").value = "";
                getObj("dsbAcctType").value = "";
                getObj("dsbDesc").value = "";
            }
            
            hide(new Array("pnlDsbName",
                "pnlDsbCheckNum",
                "pnlDsbPayoffType",
                "pnlDsbLoanNum",
                "pnlDsbAcctNum",
                "pnlDsbLoanDate",
                "pnlDsbLoanOrigPur",
                "pnlDsbLoanOrigBal",
                "pnlDsbLoanLateFees",
                "pnlDsbLoanIntDue",
                "pnlDsbLoanIntDueDate",
                "pnlDsbAcctType",
                "pnlDsbDesc"));
                
            var el = getObj("dsbType");
            if(el.options[el.selectedIndex].value == "0")
            {
                show("pnlDsbAcctNum");                
            }
            else if(el.options[el.selectedIndex].value == "1")
            {
                show("pnlDsbCheckNum");
            }
            else if(el.options[el.selectedIndex].value == "2")
            {
                show(new Array("pnlDsbAcctNum",
                    "pnlDsbPayoffType"));
            }
            else if(el.options[el.selectedIndex].value == "3")
            {
                show(new Array("pnlDsbAcctNum",
                    "pnlDsbName"));
            }
            else if(el.options[el.selectedIndex].value == "5")
            {
                show(new Array("pnlDsbAcctNum"));          
            }
            else if(el.options[el.selectedIndex].value == "31")
            {
                show(new Array("pnlDsbAcctNum",
                    "pnlDsbDesc"));
            }
            else if(el.options[el.selectedIndex].value == "26")
            {
                show(new Array("pnlDsbType",
                    "pnlDsbCheckNum"));
            }
            else if(el.options[el.selectedIndex].value == "27")
            {
                show(new Array("pnlDsbCheckNum",
                    "pnlDsbPayoffType",
                    "pnlDsbLoanNum"));
            }
            else if(el.options[el.selectedIndex].value == "28")
            {
                show(new Array("pnlDsbType",
                    "pnlDsbName",
                    "pnlDsbCheckNum",
                    "pnlDsbLoanNum"));
            }
            else if(el.options[el.selectedIndex].value == "29")
            {
                show(new Array("pnlDsbType",
                    "pnlDsbName",
                    "pnlDsbCheckNum",
                    "pnlDsbName"));
            }
            
            //set up required fields.. turn off by default
            getObj("dsbNameSpan").innerHTML = "";
            getObj("dsbName").verify = false;
            getObj("dsbAcctNumSpan").innerHTML = "";
            getObj("dsbAcctNum").verify = false;
            
            if(el.options[el.selectedIndex].value == "3")
            {
                if(getObj("requireNameLbl").innerHTML == "true")
                {
                    getObj("dsbNameSpan").innerHTML = "*";
                    getObj("dsbName").verify = true;
                }
            }
            
            if(el.options[el.selectedIndex].value == "5")
            {
                if(getObj("requireAccountNumLbl").innerHTML == "true")
                {
                    getObj("dsbAcctNumSpan").innerHTML = "*";
                    getObj("dsbAcctNum").verify = true;
                }
            }
        }

        function calcDsbTotals()
        {
            if(getObj("dsbAmount").value.length > 0)
            {
                var dsbAmount = parseFloat(getObj("dsbAmount").value);
                var dsbLeft = parseFloat(getObj("dsbRemainingTemp").innerHTML);
                
                var amount;
                if(dsbAmount > dsbLeft)
                {
                    amount = dsbAmount - dsbLeft;
                    alert("The disbursement amount must be less than or equal to the loan amount. " + 
                        "Please remove $" + amount.toFixed(2) + " from the disbursement amount");
                    getObj("dsbAmount").focus();
                }
                else
                {
                    amount = dsbLeft - dsbAmount;
                    if(amount == 0)
                    {
                        getObj("dsbRemaining").value = amount.toFixed(2);
                        getObj("dsbTotal").value = getObj("loanTotal").value;
                    }
                    else
                    {
                        getObj("dsbRemaining").value = amount.toFixed(2);
                        getObj("dsbTotal").value = (getObj("loanTotal").value - amount).toFixed(2);
                   }

                    //enable the correct buttons
                    var dsbTotalVal = parseFloat(getObj("dsbTotal").value);
                    var loanTotalVal = parseFloat(getObj("loanTotal").value);
                    var dsbRemainingVal = parseFloat(getObj("dsbRemaining").value);

                    if(dsbLeft == dsbRemainingVal && loanTotalVal == dsbTotalVal)
                    {
                        hide("AddDsb");
                        getObj("Continue").disabled = false;
                        getObj("Continue_Top").disabled = false;
                    }
                    else
                    {
                        if(dsbAmount == 0)
                            hide("AddDsb");
                        else
                            show("AddDsb");

                        getObj("Continue").disabled = true;
                        getObj("Continue_Top").disabled = true;
                    }
                }
            }
        }