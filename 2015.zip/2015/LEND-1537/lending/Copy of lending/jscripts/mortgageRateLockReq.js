addEvent(window, "load", Init);
        
            function Init()
            {
                toggleRateTable();
                
                addEvent("lockRateOption", 	"change",   checkRateTable);
                addEvent("lockRateOption", 	"keyup", 	checkRateTable);
                
                //create events for clickable items within the table
                var rateTable = getObj("rateTable");
                if(rateTable != null && rateTable.rows.length > 0)
                {
                    for (rowNum = 0; rowNum < rateTable.rows.length - 1; rowNum++)
                    {
                        addEvent("rateDDL_" + rowNum, "change", setFieldsForRate);
                        addEvent("rateDDL_" + rowNum, "keyup", setFieldsForRate);
                        addEvent("pointDDL_" + rowNum, "change", setFieldForPoint);
                        addEvent("pointDDL_" + rowNum, "keyup", setFieldForPoint);
                        addEvent("radioBtn_" + rowNum, "click", setTableFields);
                    }
                }
                
                setTableFields();
            }
            
            window.onbeforeunload = confirmExit;
            var needToConfirm = true;
            function confirmExit(el)
            {
                if(el == "true" || needToConfirm)
                {
                    var myXMLHTTPRequeset = new S1XMLHTTPRequest();
                    myXMLHTTPRequeset.xmlhttpGet("pageClose.aspx");
                }
            }
            
            function setNeedToConfirm()
            {
                needToConfirm = false;
            }
            
            function setFieldsForRate()
            {
                //this is called then a rate drop down list is toggled becuase all other fields need to be set to the value
                //for that rate
                var prodTable = getObj("rateTable");
                if(prodTable != null && prodTable.rows.length > 0)
                {
                    for (rowNum = 0; rowNum < prodTable.rows.length - 1; rowNum++)
                    {
                        getObj("pointDDL_" + rowNum).selectedIndex = getObj("rateDDL_" + rowNum).selectedIndex;
                        
                        getObj("closingCostsDDL_" + rowNum).selectedIndex = getObj("rateDDL_" + rowNum).selectedIndex;
                        getObj("closingCostsLC_" + rowNum).innerHTML = "$" + getObj("closingCostsDDL_" + rowNum).value;
                        getObj("mmPIDDL_" + rowNum).selectedIndex = getObj("rateDDL_" + rowNum).selectedIndex;
                        getObj("mmPILC_" + rowNum).innerHTML = "$" + getObj("mmPIDDL_" + rowNum).value;
                        getObj("aprDDL_" + rowNum).selectedIndex = getObj("rateDDL_" + rowNum).selectedIndex;
                        getObj("aprLC_" + rowNum).innerHTML = getObj("aprDDL_" + rowNum).value + "%";
                    }
                }
                
                setTableFields();
            }
            
            function setFieldForPoint()
            {
                //this is called then a point drop down list is toggled becuase all other fields need to be set to the value
                //for that point
                var prodTable = getObj("rateTable");
                if(prodTable != null && prodTable.rows.length > 0)
                {
                    for (rowNum = 0; rowNum < prodTable.rows.length - 1; rowNum++)
                    {
                        getObj("rateDDL_" + rowNum).selectedIndex = getObj("pointDDL_" + rowNum).selectedIndex;
                        
                        getObj("closingCostsDDL_" + rowNum).selectedIndex = getObj("pointDDL_" + rowNum).selectedIndex;
                        getObj("closingCostsLC_" + rowNum).innerHTML = "$" + getObj("closingCostsDDL_" + rowNum).value;
                        getObj("mmPIDDL_" + rowNum).selectedIndex = getObj("pointDDL_" + rowNum).selectedIndex;
                        getObj("mmPILC_" + rowNum).innerHTML = "$" + getObj("mmPIDDL_" + rowNum).value;
                        getObj("aprDDL_" + rowNum).selectedIndex = getObj("pointDDL_" + rowNum).selectedIndex;
                        getObj("aprLC_" + rowNum).innerHTML = getObj("aprDDL_" + rowNum).value + "%";
                    }
                }
                
                setTableFields();
            }
            
            function setTableFields()
            {
                getObj("tableFieldsLbl").value = "";
                
                //find the selected row
                var rateTable = getObj("rateTable");
                var rowFound = false;
                if(rateTable != null && rateTable.rows.length > 0)
                {
                    for (rowNum = 0; rowNum < rateTable.rows.length - 1 && !rowFound; rowNum++)
                    {
                        if(getObj("radioBtn_" + rowNum).checked)
                        {
                            getObj("tableFieldsLbl").value = getObj("radioBtn_" + rowNum).value + "," +
                                getObj("rateDDL_" + rowNum).value + "," + 
                                getObj("pointDDL_" + rowNum).value + "," +
                                getObj("closingCostsDDL_" + rowNum).value + "," +
                                getObj("mmPIDDL_" + rowNum).value + "," +
                                getObj("aprDDL_" + rowNum).value;
                                
                            rowFound = true;
                        }
                    }
                    
                }
            }
            
            function toggleRateTable()
            {
                if(getObj("displayRateLockDDL").innerHTML == "true")
                {
                    show("pnlLockRateOption");
                    hide("pnlRateTable");
                }
                else
                {
                    getObj("lockRateOption").selectedIndex = 1;      
                    hide("pnlLockRateOption");
                    show("pnlRateTable");
                }
            }
            
            function checkRateTable()
            {
                if (getObj("lockRateOption").options[getObj("lockRateOption").selectedIndex].value == "Yes")
                    show("pnlRateTable");
                else
                    hide("pnlRateTable");
            }