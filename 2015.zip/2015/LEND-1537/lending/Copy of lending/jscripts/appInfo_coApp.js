
	addEvent(window, "load", Init);

	function Init() {
	var theScen = getObj("sceneLbl").innerHTML;

	switch(theScen) {	
        case "vehicle":
        case "usedVehicle":
        case "secured":
        case "unSecured":
        case "credit":
        case "busVehicle":
        case "busVisa":
        case "equipment":
        case "busSecured":
        case "busUnSecured":
                        hide(new Array("pnlHmda",
                            "pnlCoAppMailAddr",
                            "pnlCoAppPrevEmp", 
                            "pnlCoAppPrevAddr",
                            "pnlCoAppPrevEmp",
                            "pnlCoAppMarital", 
                            "pnlOtherEmployerName",
                            "pnlSpacer1"));
                        
                    break;
        
        case "homeeq":
			            hide(new Array("pnlCoAppPrevAddr",
                            "pnlCoAppMailAddr",
                            "pnlCoAppPrevEmp",
                            "pnlCoAppPrevEmp",
                            "pnlOtherEmployerName", 
                            "pnlSpacer1"));

                        toggleHousingDisclosure();

                    break;
	}
	
	if(getObj("changeTitlePosLbl").innerHTML.length > 0)
    {
        changeLabel("pnlCoAppPos", getObj("changeTitlePosLbl").innerHTML + ": <span class='required'>*</span>");
        getObj("coAppPos").errorText = getObj("changeTitlePosLbl").innerHTML;
        toggleVerifyAttribute("coAppPos", true);
        
        changeLabel("pnlCoAppPrevPos", "Previous " + getObj("changeTitlePosLbl").innerHTML + ": <span class='required'>*</span>");
        getObj("coAppPrevPos").errorText = "Previous " + getObj("changeTitlePosLbl").innerHTML;
        toggleVerifyAttribute("coAppPrevPos", true);
        
        changeLabel("coAppEmpDiv", "Employer/ Military Branch: <span class='required'>*</span>");
        getObj("coAppEmp").errorText = "Employer/ Military Branch";
        
        changeLabel("coAppPrevEmpDiv", "Previous Employer/ Military Branch: <span class='required'>*</span>");
        getObj("coAppPrevEmp").errorText = "Previous Employer/ Military Branch";
    }
    else
    {
	    if(getObj("reqTitlePosLbl").innerHTML == "true")
        {
            changeLabel("pnlCoAppPos", "Title / Position: <span class='required'>*</span>");
            toggleVerifyAttribute("coAppPos", true);
            
            changeLabel("pnlCoAppPrevPos", "Previous Title / Position: <span class='required'>*</span>");
            toggleVerifyAttribute("coAppPrevPos", true);
        }
        else
        {
            changeLabel("pnlCoAppPos", "Title / Position:");
            toggleVerifyAttribute("coAppPos", false);
            
            changeLabel("pnlCoAppPrevPos", "Previous Title / Position:");
            toggleVerifyAttribute("coAppPrevPos", false);
        }
    }

    toggleOtherIncomeSourceEmployer();
    checkResStat();
    toggleEmployment();
    togglePrevEmp();
    togglePrevEmpFields();
    togglePrevAddr();
    toggleMailAddr();
    toggleForeignAddressFields();
    toggleForeignPhoneFields();

    toggleAddressFields();
    toggleRequiredFields();

    //set the scroll position
    if(getObj("pnlError").innerHTML.length > 0)
        scroll(0, 0);

    if(getObj("showBankingQuestionsLbl").innerHTML == "false")
        hide("pnlCoAppQuestions");
    else if(getObj("showAllBankingQuestionsLbl").innerHTML == "false")
        hide(new Array("pnlCoAppBkcy",
                "pnlCoAppJdmt",
                "pnlCoAppFcls",
                "pnlCoAppAlimObj"));
                
    if(getObj("hideFieldsForSVLbl").innerHTML == "true")
        hide(new Array("pnlCoAppSavings",
                "pnlCoAppBkcy",
                "pnlCoAppJdmt",
                "pnlCoAppFcls"));

    if(getObj("reqMaritalStatLbl").innerHTML == "true")
    {
        show("pnlCoAppMarital");
        changeLabel("pnlCoAppMarital", "Marital Status:<span class=\"required\"> *</span>");
        toggleVerifyAttribute("coAppMarital", true);
        getObj("coAppMarital").isRequired = true;
        getObj("coAppMarital").setAttribute('isRequired', true);
    }
    else
    {
        toggleVerifyAttribute("coAppMarital", false);
        getObj("coAppMarital").isRequired = false;
        getObj("coAppMarital").setAttribute('isRequired', false);
    }

    if(getObj("reqEmailLbl").innerHTML == "true")
    {
        changeLabel("pnlCoAppEmail", "Email Address:<span class=\"required\"> *</span>");
        toggleVerifyAttribute("coAppEmail", true);
        getObj("coAppEmail").isRequired = true;
    }
    else
    {
        changeLabel("pnlCoAppEmail", "Email Address:");
        toggleVerifyAttribute("coAppEmail", false);
        getObj("coAppEmail").isRequired = false;
    }
    
    if(getObj("showEmailVerifyLbl").innerHTML == "true")
        show("pnlCoAppEmailVerify");
    else
        hide("pnlCoAppEmailVerify");

    if(getObj("showBestContactLbl").innerHTML == "true")
    {
        show("pnlCoAppPhBestContact");
    }
    else
    {
        hide("pnlCoAppPhBestContact");
    }

    if(getObj("requireEmpStatusLbl").innerHTML == "true")
    {
        toggleVerifyAttribute("coAppOccupation", true);
        changeLabel("pnlCoAppOccupation", "Employment Status: <span class='required'>*</span>");
    }
    else
    {
        toggleVerifyAttribute("coAppOccupation", false);
        changeLabel("pnlCoAppOccupation", "Employment Status:");
    }

    if(getObj("hideCitizenshipLbl").innerHTML == "true")
        hide("pnlCoAppCitizen");
    else
        show("pnlCoAppCitizen");

    if(getObj("hideMaritalStatLbl").innerHTML == "true")
        hide("pnlCoAppMarital");
    else
        show("pnlCoAppMarital");
        
    if(getObj("changeMonthlyHousingLbl").innerHTML.length > 0)    
    {
        changeLabel("pnlCoAppHousePayments", getObj("changeMonthlyHousingLbl").innerHTML);
        getObj("coAppCrdtrHousePmt").errorText = getObj("changeMonthlyHousingLbl").innerHTML;
    }
    
    if(getObj("changeMailAddrLbl").innerHTML.length > 0)    
    {
        changeLabel("pnlCoAppMailAddrDif", getObj("changeMailAddrLbl").innerHTML);
        getObj("pnlCoAppMailAddrDif").errorText = getObj("changeMailAddrLbl").innerHTML;
    }
    
    if(getObj("showCoSignerLbl").innerHTML == "true")
        show("pnlCoSigner");
    else
        hide("pnlCoSigner");
        
    if(getObj("showCBPINLbl").innerHTML == "true")
        show("pnlCoAppCBPIN");
    else
        hide("pnlCoAppCBPIN");
        
    if(getObj("showMothersMaidenNameLbl").innerHTML == "true")
        show("pnlCoAppMothersMaidenName");
    else
        hide("pnlCoAppMothersMaidenName");
        
    if(getObj("hideSpouseLbl").innerHTML == "true")
        hide("pnlSpouse");
    else
        show("pnlSpouse");
        
    if(getObj("hideMiddleNameLbl").innerHTML == "true")
        hide("pnlCoAppMName");
    else
        show("pnlCoAppMName");
        
    if(getObj("hideOvertimeLbl").innerHTML == "true")
        hide("pnlCoAppOtBonus");
        
    if(getObj("showPersonalReferencesLbl").innerHTML == "true")
        show("pnlCoAppPersonalRef");
    else
        hide("pnlCoAppPersonalRef");
        
    //address type
    addEvent("coAppAddrType", "change", toggleAddressFields);
    addEvent("coAppAddrType", "keyup", toggleAddressFields);
	
	//other income source
    addEvent("coAppOthIncSrc1", "change", toggleOtherIncomeSourceEmployer);
    addEvent("coAppOthIncSrc1", "keyup", toggleOtherIncomeSourceEmployer);
    addEvent("coAppOthIncSrc2", "change", toggleOtherIncomeSourceEmployer);
    addEvent("coAppOthIncSrc2", "keyup", toggleOtherIncomeSourceEmployer);
    addEvent("coAppOthIncSrc3", "change", toggleOtherIncomeSourceEmployer);
    addEvent("coAppOthIncSrc3", "keyup", toggleOtherIncomeSourceEmployer);

    //housing disclosure
    addEvent("coAppState", "change", toggleHousingDisclosure);
    addEvent("coAppState", "keyup", toggleHousingDisclosure);

    //residential status
    addEvent("coAppResStat", "change", checkResStat);
    addEvent("coAppResStat", "keyup", checkResStat);

    //property taxes
    addEvent("coAppPropTaxesInc", "change", togglePropertyTaxes);
    addEvent("coAppPropTaxesInc", "keyup", togglePropertyTaxes);

    //employment
    addEvent("coAppOccupation", "change", toggleEmployment);
    addEvent("coAppOccupation", "keyup", toggleEmployment);
    addEvent("coAppPrevOccupation", "change", togglePrevEmpFields);
    addEvent("coAppPrevOccupation", "keyup", togglePrevEmpFields);

    //previous employment
    addEvent("coAppTimeEmpYr", "change", togglePrevEmp);
    addEvent("coAppTimeEmpYr", "keyup", togglePrevEmp);
    addEvent("coAppTimeEmpMo", "change", togglePrevEmp);
    addEvent("coAppTimeEmpMo", "keyup", togglePrevEmp);

    //previous address
    addEvent("coAppTimeAddrYr", "change", togglePrevAddr);
    addEvent("coAppTimeAddrYr", "keyup", togglePrevAddr);
    addEvent("coAppTimeAddrMo", "change", togglePrevAddr);
    addEvent("coAppTimeAddrMo", "keyup", togglePrevAddr);

    //previous address fields
    addEvent("coAppPrevAddrType", "change", togglePrevAddressFields);
    addEvent("coAppPrevAddrType", "keyup", togglePrevAddressFields);

    //mailing address
    addEvent("coAppMailAddrDif", "change", toggleMailAddr);
    addEvent("coAppMailAddrDif", "keyup", toggleMailAddr);

    //foreign address
    addEvent("coAppFrgnAddr", "change", toggleForeignAddressFields);
    addEvent("coAppFrgnAddr", "keyup", toggleForeignAddressFields);

    //previous foreign address
    addEvent("coAppPrevFrgnAddr", "change", togglePrevForeignAddressFields);
    addEvent("coAppPrevFrgnAddr", "keyup", togglePrevForeignAddressFields);

    //mailing foreign address
    addEvent("coAppMailFrgnAddr", "change", toggleMailForeignAddressFields);
    addEvent("coAppMailFrgnAddr", "keyup", toggleMailForeignAddressFields);

    //employer name
    addEvent("coAppEmpDDL", "change", toggleEmployerName);
    addEvent("coAppEmpDDL", "keyup", toggleEmployerName);

    //previous employer name
    addEvent("coAppPrevEmpDDL", "change", togglePrevEmployerName);
    addEvent("coAppPrevEmpDDL", "keyup", togglePrevEmployerName);
    
    //area code digits
    addEvent("coAppPhAreaCodeDigits", "change", toggleForeignPhoneFields);
    addEvent("coAppPhAreaCodeDigits", "keyup", toggleForeignPhoneFields);

}
    window.onbeforeunload = confirmExit;
    var needToConfirm = true;
    function confirmExit()
    {
        if(needToConfirm)
        {
            var myXMLHTTPRequeset = new S1XMLHTTPRequest();
            myXMLHTTPRequeset.xmlhttpGet("pageClose.aspx");
        }
    }

    function togglePrevEmp() 
    {
        if(getObj("showPrevEmpLbl").innerHTML == "true" && getObj("coAppTimeEmpYr").options.selectedIndex > 0)
        {
            var months = parseInt(getObj("coAppTimeEmpYr").options[getObj("coAppTimeEmpYr").options.selectedIndex].value * 12);
            months += parseInt(getObj("coAppTimeEmpMo").options[getObj("coAppTimeEmpMo").options.selectedIndex].value);

            if(months < parseInt(getObj("showPrevEmpMonthsLbl").innerHTML))
            {
                show("pnlCoAppPrevEmp");

                if(getObj("requireEmpStatusLbl").innerHTML == "true")
                {
                    toggleVerifyAttribute("coAppPrevOccupation", true);
                    changeLabel("pnlCoAppPrevOccupation", "Previous Employment Status: <span class='required'>*</span>");
                }
                else
                {
                    toggleVerifyAttribute("coAppPrevOccupation", false);
                    changeLabel("pnlCoAppPrevOccupation", "Previous Employment Status:");
                }

                if(getObj("useEmployerNameDDLLbl").innerHTML == "true")
                {
                    show("pnlCoAppPrevEmpDDL");
                    togglePrevEmployerName();
                    hide("coAppPrevEmpDiv");
                }
                else
                {
                    hide(new Array("pnlCoAppPrevEmpDDL",
                        "pnlCoAppPrevEmpName"));
                    show("coAppPrevEmpDiv");
                }
            }
            else
                hide("pnlCoAppPrevEmp");
        }
        else
            hide("pnlCoAppPrevEmp");
    }

    function togglePrevAddr() {
        if(getObj("showPrevAddrLbl").innerHTML == "true" && getObj("coAppTimeAddrYr").options.selectedIndex > 0)
        {
            var months = parseInt(getObj("coAppTimeAddrYr").options[getObj("coAppTimeAddrYr").options.selectedIndex].value * 12);
            months += parseInt(getObj("coAppTimeAddrMo").options[getObj("coAppTimeAddrMo").options.selectedIndex].value);

            if(months < parseInt(getObj("showPrevAddrMonthsLbl").innerHTML))
            {
                show("pnlCoAppPrevAddr");
                togglePrevAddressFields();
                togglePrevForeignAddressFields();
            }
            else
                hide("pnlCoAppPrevAddr");
        }
        else
            hide("pnlCoAppPrevAddr");
    }

    function toggleMailAddr() 
    {
        if(getObj("hideMailAddrDifLbl").innerHTML == "true")
            hide("pnlCoAppMailAddrDif");
        else
        {
            var el = getObj("coAppMailAddrDif");
            
            if (el.options.selectedIndex == 1)
            {
                show("pnlCoAppMailAddr");
                toggleMailForeignAddressFields();
            }
            else
                hide("pnlCoAppMailAddr");
        }
    }

    function toggleForeignAddressFields() 
    {
        var el = getObj("coAppFrgnAddr");
        if(el.options.selectedIndex == 0)
        {
            hide(new Array("pnlCoAppState",
                "pnlCoAppZip"));

            show(new Array("pnlCoAppProv",
                "pnlCoAppCntry",
                "pnlCoAppPstlCd"));
        }
        else
        {
            hide(new Array("pnlCoAppProv",
                "pnlCoAppCntry",
                "pnlCoAppPstlCd"));
            
            show(new Array("pnlCoAppState",
                "pnlCoAppZip",
                "pnlCoAppPh",
                "pnlCoAppCellPhone"));
        }
    }
    
    function toggleForeignPhoneFields()
    {
        if(getObj("coAppPhAreaCodeDigits").options[getObj("coAppPhAreaCodeDigits").selectedIndex].value == "Yes")
        {
            hide(new Array("pnlCoAppForeignPh",
                    "pnlCoAppForeignCellPhone"));
                    
            show(new Array("pnlCoAppPh",
                "pnlCoAppCellPhone"));
        }
        else
        {
            hide(new Array("pnlCoAppPh",
                    "pnlCoAppCellPhone"));
                    
            show(new Array("pnlCoAppForeignPh",
                "pnlCoAppForeignCellPhone"));
        }
    }

    function togglePrevForeignAddressFields() 
    {
        if (getObj("pnlCoAppFrgnAddr").style.display == "")
        {
            show("pnlCoAppPrevFrgnAddr");
            var el = getObj("coAppPrevFrgnAddr");
            if(el.options.selectedIndex == 0)
            {
                hide(new Array("pnlCoAppPrevState",
                    "pnlCoAppPrevZip"));

                show(new Array("pnlCoAppPrevProv",
                    "pnlCoAppPrevCntry",
                    "pnlCoAppPrevPstlCd"));
            }
            else
            {
                hide(new Array("pnlCoAppPrevProv",
                    "pnlCoAppPrevCntry",
                    "pnlCoAppPrevPstlCd"));
                
                show(new Array("pnlCoAppPrevState",
                    "pnlCoAppPrevZip"));
            }
        }
        else
            hide("pnlAtPrevFrgnAddr");
    }

    function toggleMailForeignAddressFields() 
    {
        if (getObj("pnlCoAppFrgnAddr").style.display == "")
        {
            show("pnlCoAppMailFrgnAddr");
            var el = getObj("coAppMailFrgnAddr");
            if (el.options.selectedIndex == 0)
            {
                hide(new Array("pnlCoAppMailState",
                    "pnlCoAppMailZip"));

                show(new Array("pnlCoAppMailProv",
                    "pnlCoAppMailCntry",
                    "pnlCoAppMailPstlCd"));
            }
            else
            {
                hide(new Array("pnlCoAppMailProv",
                    "pnlCoAppMailCntry",
                    "pnlCoAppMailPstlCd"));

                show(new Array("pnlCoAppMailState",
                    "pnlCoAppMailZip"));
            }
        }
        else
        {
            hide("pnlCoAppMailFrgnAddr");
            hide(new Array("pnlCoAppMailProv",
                "pnlCoAppMailCntry",
                "pnlCoAppMailPstlCd"));
        }
    }

    function toggleAddressFields()
    {
        var el = getObj("coAppAddrType");
        if(el.options.selectedIndex == 0) 
        {
            if(getObj("useSingleAddrLineLbl").innerHTML == "true")
            {
                hide("pnlCoAppStandardAddr");
                show("pnlCoAppStandardSingleLineAddr");
            }
            else
            {
                show("pnlCoAppStandardAddr");
                hide("pnlCoAppStandardSingleLineAddr");
            }
            
            hide(new Array("pnlCoAppRuralAddr",
                "pnlCoAppPOBoxAddr"));
        }
        else if(el.options.selectedIndex == 1) 
        {
            show("pnlCoAppRuralAddr");
            hide(new Array("pnlCoAppStandardAddr",
                "pnlCoAppStandardSingleLineAddr",
                "pnlCoAppPOBoxAddr"));
        }   
        else if(el.options.selectedIndex == 2) 
        {
            show("pnlCoAppPOBoxAddr");
            hide(new Array("pnlCoAppStandardAddr",
                "pnlCoAppStandardSingleLineAddr",
                "pnlCoAppRuralAddr"));
                
            if(getObj("toggleMailingAddrFieldsLbl").innerHTML == "true")
            {
                getObj("coAppMailAddrDif").options.selectedIndex = 1;
                toggleMailAddr();
            }
        }
    }

    function togglePrevAddressFields()
    {
        var el = getObj("coAppPrevAddrType");
        if(el.options.selectedIndex == 0) 
        {
            if(getObj("useSingleAddrLineLbl").innerHTML == "true")
            {
                hide("pnlCoAppPrevStandardAddr");
                show("pnlCoAppPrevStandardSingleLineAddr");
            }
            else
            {
                show("pnlCoAppPrevStandardAddr");
                hide("pnlCoAppPrevStandardSingleLineAddr");
            }
            
            hide(new Array("pnlCoAppPrevRuralAddr",
                "pnlCoAppPrevPOBoxAddr"));
        }
        else if(el.options.selectedIndex == 1) 
        {
            show("pnlCoAppPrevRuralAddr");
            hide(new Array("pnlCoAppPrevStandardAddr",
                "pnlCoAppPrevStandardSingleLineAddr",
                "pnlCoAppPrevPOBoxAddr"));
        }   
        else if(el.options.selectedIndex == 2) 
        {
            show("pnlCoAppPrevPOBoxAddr");
            hide(new Array("pnlCoAppPrevStandardAddr",
                "pnlCoAppPrevStandardSingleLineAddr",
                "pnlCoAppPrevRuralAddr"));
        }
    }

    function toggleOtherIncomeSourceEmployer()
    {
        if (getObj("coAppOthIncSrc1").options[getObj("coAppOthIncSrc1").selectedIndex].value == "P/T OR SECOND JOB" || getObj("coAppOthIncSrc1").options[getObj("coAppOthIncSrc1").selectedIndex].value == "SPOUSAL INCOME")
            getObj("coAppOthEmp1").disabled = false;
        else
        {
            getObj("coAppOthEmp1").value = "";
            getObj("coAppOthEmp1").disabled = true;
        }
        
        if (getObj("coAppOthIncSrc2").options[getObj("coAppOthIncSrc2").selectedIndex].value == "P/T OR SECOND JOB" || getObj("coAppOthIncSrc2").options[getObj("coAppOthIncSrc2").selectedIndex].value == "SPOUSAL INCOME")
            getObj("coAppOthEmp2").disabled = false;
        else
        {
            getObj("coAppOthEmp2").value = "";
            getObj("coAppOthEmp2").disabled = true;
        }
        
        if (getObj("coAppOthIncSrc3").options[getObj("coAppOthIncSrc3").selectedIndex].value == "P/T OR SECOND JOB" || getObj("coAppOthIncSrc3").options[getObj("coAppOthIncSrc3").selectedIndex].value == "SPOUSAL INCOME")
            getObj("coAppOthEmp3").disabled = false;
        else
        {
            getObj("coAppOthEmp3").value = "";
            getObj("coAppOthEmp3").disabled = true;
        }
    }

    function checkResStat(target)
    {
        var el = getObj("coAppResStat");
        hide("defaultRentText");
        if(getObj("prevCoAppResStatVal").innerHTML == "Lives w/ relative" && getObj("defaultRentLbl").innerHTML != "")
           getObj("coAppCrdtrHousePmt").value = "";
           
        if(getObj("showMonthlyHousingPaymentLbl").innerHTML == "false")
        {
            if(el.options[el.selectedIndex].value == "Own - mtg")
            {
                getObj("coAppCrdtrHousePmt").value = "";
                hide(new Array("pnlCoAppHousePayments"));
            }
            else if(el.options[el.selectedIndex].value == "Own - clear" || el.options[el.selectedIndex].value == "Barracks")
            {
                getObj("coAppCrdtrHousePmt").value = "";
                hide(new Array("pnlCoAppHousePayments"));
            }
            else
            {
                hide("pnlCoAppHousePayments");
            }
        }
        else
        {
            if(el.options[el.selectedIndex].value == "Own - mtg")
            {
                show(new Array("pnlCoAppHousePayments"));
            }
            else if(el.options[el.selectedIndex].value == "Own - clear" || el.options[el.selectedIndex].value == "Barracks")
            {
                getObj("coAppCrdtrHousePmt").value = "";
                hide(new Array("pnlCoAppHousePayments"));
            }
            else
            {
                show(new Array("pnlCoAppHousePayments"));
            }
        }
        
        if((el.options[el.selectedIndex].value == "Rents" || el.options[el.selectedIndex].value == "Lives w/ relative") && 
            getObj("defaultRentLbl").innerHTML != "")
        {
            if(el.options[el.selectedIndex].value == "Lives w/ relative")
                getObj("coAppCrdtrHousePmt").value = getObj("defaultRentLbl").innerHTML;
                
            show("defaultRentText");
        }
        
        if(getObj("showMonthlyHousingPaymentForRentAndLivesLbl").innerHTML == "true")
        {
            if((el.options[el.selectedIndex].value == "Rents" || el.options[el.selectedIndex].value == "Lives w/ relative"))
                show(new Array("pnlCoAppHousePayments"));
            else
                hide(new Array("pnlCoAppHousePayments"));
        }
        
        getObj("prevCoAppResStatVal").innerHTML = el.options[el.selectedIndex].value;
        togglePropertyTaxes();
    }

    function togglePropertyTaxes()
    {
        var resStat = getObj("coAppResStat");
        if(resStat.options[resStat.selectedIndex].value == "Own - mtg")
        {
            hide("pnlCoAppPropTax");
            if(getObj("showPropertyTaxLbl").innerHTML == "true")
            {
                show("pnlCoAppPropTaxesInc");
                var el = getObj("coAppPropTaxesInc");
                if(el.options.selectedIndex == 2)
                    show("pnlCoAppPropTax");
                else
                {
                    hide("pnlCoAppPropTax");
                    getObj("coAppPropTax").value = "";
                }
            }
            else
            {
                hide(new Array("pnlCoAppPropTaxesInc",
                    "pnlCoAppPropTax"));
                getObj("coAppPropTaxesInc").selectedIndex = 0;
                getObj("coAppPropTax").value = "";
            }
        }
        else if(resStat.options[resStat.selectedIndex].value == "Own - clear" || 
                resStat.options[resStat.selectedIndex].value == "Own - private - mtg")
        {
            hide("pnlCoAppPropTaxesInc");
            getObj("coAppPropTaxesInc").selectedIndex = 0;
            
            if(getObj("showPropertyTaxLbl").innerHTML == "true")
                show("pnlCoAppPropTax");
            else
            {
                hide("pnlCoAppPropTax");
                getObj("coAppPropTax").value = "";
            }
        }
        else
        {
            hide(new Array("pnlCoAppPropTax",
                "pnlCoAppPropTaxesInc"));

            getObj("coAppPropTax").value = "";
            getObj("coAppPropTaxesInc").selectedIndex = 0;
        }
    }


    function toggleEmployment()
    {
        var el = getObj("coAppOccupation");
        if(el.options[el.selectedIndex].value == "Homemaker" || el.options[el.selectedIndex].value == "Student" ||
           el.options[el.selectedIndex].value == "Unemployed w/ Income" || el.options[el.selectedIndex].value == "Unemployed w/out Income" ||
           el.options[el.selectedIndex].value == "N/A" || el.options[el.selectedIndex].value == "Retired" || 
           el.options[el.selectedIndex].value == "Disability" || el.options[el.selectedIndex].value == "Rental")
        {
            if(getObj("useEmployerNameDDLLbl").innerHTML == "true")
            {
                getObj("coAppEmpDDL").options.selectedIndex = 0;
                toggleEmployerName();
            }
            else
                getObj("coAppEmp").value = "";

            getObj("coAppEmpPh1").value = "";
            getObj("coAppEmpPh2").value = "";
            getObj("coAppEmpPh3").value = "";
            getObj("coAppSalary").value = "";
            getObj("coAppPos").value = "";
            getObj("coAppTimeEmpYr").options.selectedIndex = 0;
            getObj("coAppTimeEmpMo").options.selectedIndex = 0;

            //previous emp
            getObj("coAppPrevOccupation").options.selectedIndex = 0;
            if(getObj("useEmployerNameDDLLbl").innerHTML == "true")
            {
                getObj("coAppPrevEmpDDL").options.selectedIndex = 0;
                togglePrevEmployerName();
            }
            else
                getObj("coAppPrevEmp").value = "";

            getObj("coAppPrevEmpPh1").value = "";
            getObj("coAppPrevEmpPh2").value = "";
            getObj("coAppPrevEmpPh3").value = "";
            getObj("coAppPrevPos").value = "";
            getObj("coAppPrevTimeEmpYr").options.selectedIndex = 0;
            getObj("coAppPrevTimeEmpMo").options.selectedIndex = 0;

            hide("pnlCoAppPrevEmp");

            if (getObj("showHoursPerWeekLbl").innerHTML == "true")
                show("pnlCoAppHoursPerWeek");
            else
                hide("pnlCoAppHoursPerWeek");

            if(el.options[el.selectedIndex].value == "Disability" && getObj("showDisabilityTypeLbl").innerHTML == "true")
            {
                hide(new Array("pnlCoAppPos",
                    "coAppEmpDiv",
                    "pnlCoAppEmpDDL",
                    "pnlCoAppEmpName",
                    "coAppEmpPhDiv",
                    "pnlCoAppSalary",
                    "pnlCoAppOtBonus",
                    "pnlCoAppTimeEmployed"));
                    
                show("pnlCoAppDisabType");
            }
            else
            {
                getObj("coAppDisabType").options.selectedIndex = 0;
                hide("pnlCoAppEmp");
            }
        }
        else
        {
            show(new Array("pnlCoAppEmp",
                "pnlCoAppPos",
                "coAppEmpDiv",
                "pnlCoAppEmpDDL",
                "pnlCoAppEmpName",
                "coAppEmpPhDiv",
                "pnlCoAppSalary",
                "pnlCoAppOtBonus",
                "pnlCoAppTimeEmployed"));

            if(getObj("useEmployerNameDDLLbl").innerHTML == "true")
            {
                show("pnlCoAppEmpDDL");
                hide("coAppEmpDiv");
                toggleEmployerName();
            }
            else
            {
                hide(new Array("pnlCoAppEmpDDL",
                    "pnlCoAppEmpName"));
                show("coAppEmpDiv");
            }

            hide("pnlCoAppDisabType");
            if(getObj("useEmployerNameDDLLbl").innerHTML == "true")
            {
                toggleVerifyAttribute("coAppEmpDDL", true);
                changeLabel("pnlCoAppEmpDDL", "Employer Name: <span class='required'>*</span>");
                changeLabel("pnlCoAppEmpName", "Enter Employer Name: <span class='required'>*</span>");
            }
            else
            {
                toggleVerifyAttribute("coAppEmp", true);
                changeLabel("coAppEmpDiv", "Employer Name: <span class='required'>*</span>");
            }
            
            toggleVerifyAttribute("coAppEmpPh1", true);
            toggleVerifyAttribute("coAppEmpPh2", true);
            toggleVerifyAttribute("coAppEmpPh3", true);
            changeLabel("coAppEmpPhDiv", "Business Phone: <span class='required'>*</span>");

            toggleVerifyAttribute("coAppSalary", true);
            if(getObj("useBaseWagesLbl").innerHTML == "true")
            {
                changeLabel("pnlCoAppSalary", "Base Wages: <span class='required'>*</span>");
                getObj("coAppSalary").errorText = "Base Wages";
            }
            else
            {
                if(getObj("changeSalaryLbl").innerHTML != "false")
                {
                    changeLabel("pnlCoAppSalary", "Salary: <span class='required'>*</span>");
                    getObj("coAppSalary").errorText = "Salary";
                }
            }
            
            toggleVerifyAttribute("coAppTimeEmpYr", true);
            toggleVerifyAttribute("coAppTimeEmpMo", true);
            changeLabel("pnlCoAppTimeEmployed", "Time with Present Employer: <span class='required'>*</span>");

            if(getObj("changeTitlePosLbl").innerHTML.length > 0)
            {
                changeLabel("pnlCoAppPos", getObj("changeTitlePosLbl").innerHTML + ": <span class='required'>*</span>");
                getObj("coAppPos").errorText = getObj("changeTitlePosLbl").innerHTML;
                toggleVerifyAttribute("coAppPos", true);
                
                changeLabel("pnlCoAppPrevPos", "Previous " + getObj("changeTitlePosLbl").innerHTML + ": <span class='required'>*</span>");
                getObj("coAppPrevPos").errorText = "Previous " + getObj("changeTitlePosLbl").innerHTML;
                toggleVerifyAttribute("coAppPrevPos", true);
                
                changeLabel("coAppEmpDiv", "Employer/ Military Branch: <span class='required'>*</span>");
                getObj("coAppEmp").errorText = "Employer/ Military Branch";
                
                changeLabel("coAppPrevEmpDiv", "Previous Employer/ Military Branch: <span class='required'>*</span>");
                getObj("coAppPrevEmp").errorText = "Previous Employer/ Military Branch";
            }
            else
            {
                if(getObj("reqTitlePosLbl").innerHTML == "true")
                {
                    changeLabel("pnlCoAppPos", "Title / Position: <span class='required'>*</span>");
                    toggleVerifyAttribute("coAppPos", true);
                }
                else
                {
                    changeLabel("pnlCoAppPos", "Title / Position:");
                    toggleVerifyAttribute("coAppPos", false);
                }
            }

            if(getObj("showHoursPerWeekLbl").innerHTML == "true")
                show("pnlCoAppHoursPerWeek");
            else
                hide("pnlCoAppHoursPerWeek");
                
            if(getObj("hideOvertimeLbl").innerHTML == "true")
                hide("pnlCoAppOtBonus");
        }
        
        if(getObj("unRequireEmpPhLbl").innerHTML == "true")
        {
            toggleVerifyAttribute("coAppEmpPh1", false);
            toggleVerifyAttribute("coAppEmpPh2", false);
            toggleVerifyAttribute("coAppEmpPh3", false);
            changeLabel("coAppEmpPhDiv", "Business Phone:");
       }
       
       if(getObj("requireOtherIncLbl").innerHTML == "true")
        {
           if(el.options[el.selectedIndex].value == "Homemaker" || el.options[el.selectedIndex].value == "Student" ||
              el.options[el.selectedIndex].value == "Retired" || el.options[el.selectedIndex].value == "Disability")
           {
                changeLabel("pnlOthIncText", "Other Income for Co-Applicant (annual gross): <span class='required'>*</span>");
           }
           else
                changeLabel("pnlOthIncText", "Other Income for Co-Applicant (annual gross):");
       }
    }

    function togglePrevEmpFields()
    {
        var el = getObj("coAppPrevOccupation");
        if(el.options[el.selectedIndex].value == "Homemaker" || el.options[el.selectedIndex].value == "Student" ||
           el.options[el.selectedIndex].value == "Unemployed w/ Income" || el.options[el.selectedIndex].value == "Unemployed w/out Income" ||
           el.options[el.selectedIndex].value == "N/A" || el.options[el.selectedIndex].value == "Retired" || 
           el.options[el.selectedIndex].value == "Disability" || el.options[el.selectedIndex].value == "Rental")
        {
            if(getObj("useEmployerNameDDLLbl").innerHTML == "true")
            {
                getObj("coAppPrevEmpDDL").options.selectedIndex = 0;
                togglePrevEmployerName();
            }
            else
                getObj("coAppPrevEmp").value = "";

            getObj("coAppPrevEmpPh1").value = "";
            getObj("coAppPrevEmpPh2").value = "";
            getObj("coAppPrevEmpPh3").value = "";
            getObj("coAppPrevPos").value = "";
            getObj("coAppPrevTimeEmpYr").options.selectedIndex = 0;
            getObj("coAppPrevTimeEmpMo").options.selectedIndex = 0;

            if(el.options[el.selectedIndex].value == "Disability" && getObj("showDisabilityTypeLbl").innerHTML == "true")
            {
                show(new Array("pnlCoAppPrevDisabType",
                    "pnlCoAppPrevEmpFields"));
                    
                hide(new Array("pnlCoAppPrevPos",
                    "coAppPrevEmpDiv",
                    "pnlCoAppPrevEmpDDL",
                    "pnlCoAppPrevEmpName",
                    "coAppPrevEmpPhDiv",
                    "pnlCoAppPrevTimeEmployed"));
            }
            else
            {
                getObj("coAppPrevDisabType").options.selectedIndex = 0;
                hide("pnlCoAppPrevEmpFields");
            }
        }
        else
        {
            if (getObj("pnlCoAppPrevEmp").style.display == "")
            {
                show(new Array("pnlCoAppPrevEmpFields",
                    "pnlCoAppPrevPos",
                    "coAppPrevEmpDiv",
                    "pnlCoAppPrevEmpDDL",
                    "pnlCoAppPrevEmpName",
                    "coAppPrevEmpPhDiv",
                    "pnlCoAppPrevTimeEmployed"));
        
                if(getObj("useEmployerNameDDLLbl").innerHTML == "true")
                {
                    show("pnlCoAppPrevEmpDDL");
                    togglePrevEmployerName();
                    hide("coAppPrevEmpDiv");
                }
                else
                {
                    hide(new Array("pnlCoAppPrevEmpDDL",
                        "pnlCoAppPrevEmpName"));
                    show("coAppPrevEmpDiv");
                }
                
                hide("pnlCoAppPrevDisabType");
                if(getObj("useEmployerNameDDLLbl").innerHTML == "true")
                {
                    toggleVerifyAttribute("coAppPrevEmpDDL", true);
                    changeLabel("pnlCoAppPrevEmpDDL", "Previous Employer Name: <span class='required'>*</span>");
                    changeLabel("pnlCoAppPrevEmpName", "Enter Previous Employer Name: <span class='required'>*</span>");
                }
                else
                {
                    toggleVerifyAttribute("coAppPrevEmp", true);
                    changeLabel("coAppPrevEmpDiv", "Previous Employer Name: <span class='required'>*</span>");
                }

                toggleVerifyAttribute("coAppPrevEmpPh1", true);
                toggleVerifyAttribute("coAppPrevEmpPh2", true);
                toggleVerifyAttribute("coAppPrevEmpPh3", true);
                changeLabel("coAppPrevEmpPhDiv", "Previous Business Phone: <span class='required'>*</span>");
                toggleVerifyAttribute("coAppPrevTimeEmpYr", true);
                toggleVerifyAttribute("coAppPrevTimeEmpMo", true);
                changeLabel("pnlCoAppPrevTimeEmployed", "Time with Previous Employer: <span class='required'>*</span>");
                
                if(getObj("changeTitlePosLbl").innerHTML.length > 0)
                {
                    changeLabel("pnlCoAppPos", getObj("changeTitlePosLbl").innerHTML + ": <span class='required'>*</span>");
                    getObj("coAppPos").errorText = getObj("changeTitlePosLbl").innerHTML;
                    toggleVerifyAttribute("coAppPos", true);
                    
                    changeLabel("pnlCoAppPrevPos", "Previous " + getObj("changeTitlePosLbl").innerHTML + ": <span class='required'>*</span>");
                    getObj("coAppPrevPos").errorText = "Previous " + getObj("changeTitlePosLbl").innerHTML;
                    toggleVerifyAttribute("coAppPrevPos", true);
                    
                    changeLabel("coAppEmpDiv", "Employer/ Military Branch: <span class='required'>*</span>");
                    getObj("coAppEmp").errorText = "Employer/ Military Branch";
                    
                    changeLabel("coAppPrevEmpDiv", "Previous Employer/ Military Branch: <span class='required'>*</span>");
                    getObj("coAppPrevEmp").errorText = "Previous Employer/ Military Branch";
                }
                else
                {
                    if(getObj("reqTitlePosLbl").innerHTML == "true")
                    {
                        changeLabel("pnlCoAppPrevPos", "Previous Title / Position: <span class='required'>*</span>");
                        toggleVerifyAttribute("coAppPrevPos", true);
                        
                    }
                    else
                    {
                        changeLabel("pnlCoAppPrevPos", "Previous Title / Position:");
                        toggleVerifyAttribute("coAppPrevPos", false);
                    }
                }
            }
        }
        
        if(getObj("unRequireEmpPhLbl").innerHTML == "true")
        {
            toggleVerifyAttribute("coAppPrevEmpPh1", false);
            toggleVerifyAttribute("coAppPrevEmpPh2", false);
            toggleVerifyAttribute("coAppPrevEmpPh3", false);
            changeLabel("coAppPrevEmpPhDiv", "Previous Business Phone:");
       }
    }

    function toggleRequiredFields()
    {
        if(getObj("custName").innerHTML == "SANDIA")
        {
            toggleVerifyAttribute("coAppChecking", false);
            changeLabel("pnlCoAppChecking", "Do you have a checking account?");
            toggleVerifyAttribute("coAppSavings", false);
            changeLabel("pnlCoAppSavings", "Do you have a savings account?");
        }
    }

    function toggleHousingDisclosure()
    {
        if(getObj("showhousingDisclosureLbl").innerHTML == "true")
        {
            var isEdit = getObj("isEditLbl").innerHTML;
            var isDemo = getObj("isDemoLbl").innerHTML;
            var isBack = getObj("isBackLbl").innerHTML;
            var trueStr = "True";
            
            if(isEdit == trueStr || isDemo == trueStr || isBack == trueStr)
            {
                enableContinueButtons();
                show("pnlDisclosure");
            }
            else
            {
                var el = getObj("coAppState");
                if (el.options.value == "CA")
                {
                    show("pnlDisclosure");
                    getObj("Continue").disabled = true;
                    getObj("Continue_Top").disabled = true;
                }
                else
                {
                    hide("pnlDisclosure");
                    enableContinueButtons();
                }
            }
        }
    }

    function toggleEmployerName()
    {
        if(getObj("useEmployerNameDDLLbl").innerHTML == "true")
        {
            var el = getObj("coAppEmpDDL");
            if(el.options[el.selectedIndex].value == "Other")
                show("pnlCoAppEmpName");
            else
            {
                hide("pnlCoAppEmpName");
                getObj("coAppEmpName").value = "";
            }
        }
    }

    function togglePrevEmployerName()
    {
        if(getObj("useEmployerNameDDLLbl").innerHTML == "true")
        {
            var el = getObj("coAppPrevEmpDDL");
            if(el.options[el.selectedIndex].value == "Other")
                show("pnlCoAppPrevEmpName");
            else
            {
                hide("pnlCoAppPrevEmpName");
                getObj("coAppPrevEmpName").value = "";
            }
        }
    }

    function enableContinueButtons()
    {
        getObj("Continue").disabled = false;
        getObj("Continue_Top").disabled = false;
    }