addEvent(window, "load", Init);
        
            function Init()
            {
                hide("ContinueDisbaled");
                show("Continue");
                //addEvent("anPrintOpt1", "click", toggleTerms);
		        //addEvent("anPrintOpt2", "click", toggleTerms);    
		        
		        var TL1 = new TrackedLinks("agreements");
		        
		        if(getObj("showSaveSuccessLbl").innerHTML == "true")
	                showSaveSuccessAlert();
            }
            
            window.onbeforeunload = confirmExit;
            var needToConfirm = true;
            function confirmExit()
            {
                if(needToConfirm)
                {
                    var myXMLHTTPRequeset = new S1XMLHTTPRequest();
                    myXMLHTTPRequeset.xmlhttpGet("pageClose.aspx");
                }
            }
            
            function toggleTerms()
            {
                if(getObj("anPrintOpt1").checked)
                    show("TermsPanel");
                else
                    hide("TermsPanel");
            }
            
            function verifyViewAndAgree()
            {
                getObj("pnlError").innerHTML = "";
                hide("pnlError");
                
                if(getObj("anPrintOpt1").checked)
                {
                    if(!getObj("checkAgree").checked)
                    {
                        getObj("pnlError").innerHTML = "Please select how you want to receive your loan documents.";
                        show("pnlError");
                        scroll(0,0);
                        
                        return false;
                    }
                    else
                    {
                        var TL1 = new TrackedLinks("agreements");
                        if(!TL1.OnSubmit())
                        {
                            getObj("pnlError").innerHTML = "You must view and agree to the Terms and Conditions below.";
                            show("pnlError");
                            scroll(0,0);
                            
                            return false;
                        }
                        else
                        {
                            hide("Continue");
                            show("ContinueDisbaled");
                            return true;
                        }
                    }
                }
                else
                {
                    hide("Continue");
                    show("ContinueDisbaled");
                    return true;
                }
            }