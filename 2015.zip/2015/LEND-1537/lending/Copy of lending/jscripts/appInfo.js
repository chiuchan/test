
        addEvent(window, "load", Init);

        function Init()
        {
            var theScen = getObj("sceneLbl").innerHTML;
            
            switch(theScen) {
                case "vehicle":
                case "usedVehicle":
                case "secured":
                case "unSecured":
                case "credit":
                                hide(new Array("pnlMailAddr",
                                    "pnlPrevEmp",
                                    "pnlPrevAddr",
                                    "pnlBusAddress",
                                    "pnlMaritalStatus",
                                    "pnlAddressType",
                                    "pnlSchoolAddress",
                                    "pnlHomeAddress",
                                    "pnlLawsuits",
                                    "pnlHome",
                                    "pnlSpouse",                                    
                                    "pnlSpacer1"));

                            break;
        			
                case "homeeq":
                                hide(new Array("pnlMailAddr",
                                    "pnlPrevEmp",
                                    "pnlPrevAddr",
                                    "pnlBusAddress",
                                    "pnlAddressType",
                                    "pnlSchoolAddress",
                                    "pnlHomeAddress",
                                    "pnlLawsuits",
                                    "pnlSpouse",
                                    "pnlSpacer1"));

                                toggleHousingDisclosure();

                            break;

                case "busVehicle":
	            case "equipment":
	            case "busVisa":
                case "busSecured":
                case "busUnSecured":
                                changeLabel("pnlSalary", "Salary for Business: <span class='required'>*</span>");
		                        changeLabel("pnlTimeEmployed", "Time with Business: <span class='required'>*</span>");
                                getObj("atTimeEmpYr").remove(1);
                                hide(new Array("pnlMailAddr",
                                    "pnlPrevEmp",
                                    "pnlPrevAddr",
                                    "pnlMaritalStatus",
                                    "pnlAddressType",
                                    "pnlSchoolAddress",
                                    "pnlHomeAddress",
                                    "pnlHome",
                                    "pnlSpouse",
                                    "pnlSpacer1"));

                            break;
            }
            
            if(getObj("changeTitlePosLbl").innerHTML.length > 0)
            {
                changeLabel("pnlAtPos", getObj("changeTitlePosLbl").innerHTML + ": <span class='required'>*</span>");
                getObj("atPos").errorText = getObj("changeTitlePosLbl").innerHTML;
                toggleVerifyAttribute("atPos", true);
                
                changeLabel("pnlAtPrevPos", "Previous " + getObj("changeTitlePosLbl").innerHTML + ": <span class='required'>*</span>");
                getObj("atPrevPos").errorText = "Previous " + getObj("changeTitlePosLbl").innerHTML;
                toggleVerifyAttribute("atPrevPos", true);
                
                changeLabel("atEmpDiv", "Employer/ Military Branch: <span class='required'>*</span>");
                getObj("atEmp").errorText = "Employer/ Military Branch";
                
                changeLabel("atPrevEmpDiv", "Previous Employer/ Military Branch: <span class='required'>*</span>");
                getObj("atPrevEmp").errorText = "Previous Employer/ Military Branch";
            }
            else
            {
                if(getObj("reqTitlePosLbl").innerHTML == "true")
                {
                    changeLabel("pnlAtPos", "Title / Position: <span class='required'>*</span>");
                    toggleVerifyAttribute("atPos", true);
                    
                    changeLabel("pnlAtPrevPos", "Previous Title / Position: <span class='required'>*</span>");
                    toggleVerifyAttribute("atPrevPos", true);
                    
                }
                else
                {
                    changeLabel("pnlAtPos", "Title / Position:");
                    toggleVerifyAttribute("atPos", false);
                    
                    changeLabel("pnlAtPrevPos", "Previous Title / Position:");
                    toggleVerifyAttribute("atPrevPos", false);
                }
            }
            
            toggleOtherIncomeSourceEmployer();
            checkResStat();
            toggleEmployment();
            togglePrevEmp();
            togglePrevEmpFields();
            togglePrevAddr();
            toggleMailAddr();
            toggleForeignAddressFields();
            toggleForeignPhoneFields();

            toggleAddressFields();
            toggleRequiredFields();
            toggleDisclosure();

            //set the scroll position
            if(getObj("pnlError").innerHTML.length > 0)
                scroll(0, 0);

            if(theScen == "busVehicle" || theScen == "equipment" || theScen == "busVisa" ||
                theScen == "busSecured" || theScen == "busUnSecured")
            {
                toggleBusAddressFields();
            }

            if(getObj("showBankingQuestionsLbl").innerHTML == "false")
                hide("pnlQuestions");
            else if(getObj("showAllBankingQuestionsLbl").innerHTML == "false")
                hide(new Array("pnlAtBkcy",
                        "pnlAtJdmt",
                        "pnlAtFcls",
                        "pnlAtAlimOblig"));
            
            if(getObj("hideFieldsForSVLbl").innerHTML == "true")
                hide(new Array("pnlSavings",
                        "pnlAtBkcy",
                        "pnlAtJdmt",
                        "pnlAtFcls"));

            if(getObj("reqMaritalStatLbl").innerHTML == "true")
            {
                show("pnlMaritalStatus");
                changeLabel("pnlMaritalStatus", "Marital Status:<span class=\"required\"> *</span>");
                toggleVerifyAttribute("atMarital", true);
                getObj("atMarital").isRequired = true;
                getObj("atMarital").setAttribute('isRequired', true);
            }
            else
            {
                toggleVerifyAttribute("atMarital", false);
                getObj("atMarital").isRequired = false;
                getObj("atMarital").setAttribute('isRequired', false);
            }

            if(getObj("reqEmailLbl").innerHTML == "true")
            {
                changeLabel("pnlAtEmail", "Email Address:<span class=\"required\"> *</span>");
                toggleVerifyAttribute("atEmail", true);
                getObj("atEmail").isRequired = true;
            }
            else
            {
                changeLabel("pnlAtEmail", "Email Address:");
                toggleVerifyAttribute("atEmail", false);
                getObj("atEmail").isRequired = false;
            }
            
            if(getObj("showEmailVerifyLbl").innerHTML == "true")
                show("pnlAtEmailVerify");
            else
                hide("pnlAtEmailVerify");

            if(getObj("showSchoolNameLbl").innerHTML == "true")
                show(new Array("pnlAtSchoolName",
                    "pnlSchoolNameText"));
            else
                hide("pnlAtSchoolName");

            if(getObj("showBestContactLbl").innerHTML == "true")
            {
                show("pnlAtPhBestContact");
            }
            else
            {
                hide("pnlAtPhBestContact");
            }

            if(getObj("requireEmpStatusLbl").innerHTML == "true")
            {
                toggleVerifyAttribute("selOccupation", true);
                changeLabel("pnlSelOccupation", "Employment Status: <span class='required'>*</span>");
            }
            else
            {
                toggleVerifyAttribute("selOccupation", false);
                changeLabel("pnlSelOccupation", "Employment Status:");
            }

            if(getObj("hideCitizenshipLbl").innerHTML == "true")
                hide("pnlAtCitizen");
            else
                show("pnlAtCitizen");

            if(getObj("hideMaritalStatLbl").innerHTML == "true")
                hide("pnlMaritalStatus");
            else
                show("pnlMaritalStatus");
                
            if(getObj("showCBPINLbl").innerHTML == "true")
                show("pnlAtCBPIN");
            else
                hide("pnlAtCBPIN");
                
            if(getObj("showMothersMaidenNameLbl").innerHTML == "true")
                show("pnlAtMothersMaidenName");
            else
                hide("pnlAtMothersMaidenName");
                
            if(getObj("changeMonthlyHousingLbl").innerHTML.length > 0)    
            {
                changeLabel("pnlHousePayments", getObj("changeMonthlyHousingLbl").innerHTML);
                getObj("atCrdtrHousePmt").errorText = getObj("changeMonthlyHousingLbl").innerHTML;
            }
            
            if(getObj("changeMailAddrLbl").innerHTML.length > 0)    
            {
                changeLabel("pnlMailAddrDif", getObj("changeMailAddrLbl").innerHTML);
                getObj("pnlMailAddrDif").errorText = getObj("changeMailAddrLbl").innerHTML;
            }
            
            if(getObj("hideMiddleNameLbl").innerHTML == "true")
                hide("pnlMName");
            else
                show("pnlMName");
                
            if(getObj("hideOvertimeLbl").innerHTML == "true")
                hide("pnlAtOtBonus");
                
            if(getObj("showPersonalReferencesLbl").innerHTML == "true")
                show("pnlPersonalRef");
            else
                hide("pnlPersonalRef");
                
            if(getObj("showForeignPhoneFields").innerHTML == "true")
                show("");
            else
                hide("");
                
            //always run this
            toggleJointCredit();

            //previous employment
            addEvent("atTimeEmpYr", "change", togglePrevEmp);
		    addEvent("atTimeEmpYr", "keyup", togglePrevEmp);
            addEvent("atTimeEmpMo", "change", togglePrevEmp);
		    addEvent("atTimeEmpMo", "keyup", togglePrevEmp);

            //address type
            addEvent("atAddrType", "change", toggleAddressFields);
		    addEvent("atAddrType", "keyup", toggleAddressFields);

            //business address type
            addEvent("beAddrType", "change", toggleBusAddressFields);
		    addEvent("beAddrType", "keyup", toggleBusAddressFields);

            //previous address
            addEvent("atTimeAddrYr", "change", togglePrevAddr);
		    addEvent("atTimeAddrYr", "keyup", togglePrevAddr);
            addEvent("atTimeAddrMo", "change", togglePrevAddr);
		    addEvent("atTimeAddrMo", "keyup", togglePrevAddr);

            //previous address fields
            addEvent("atPrevAddrType", "change", togglePrevAddressFields);
		    addEvent("atPrevAddrType", "keyup", togglePrevAddressFields);

            //mailing address
            addEvent("mailAddrDif", "change", toggleMailAddr);
		    addEvent("mailAddrDif", "keyup", toggleMailAddr);

            //foreign address
            addEvent("atFrgnAddr", "change", toggleForeignAddressFields);
		    addEvent("atFrgnAddr", "keyup", toggleForeignAddressFields);

            //previous foreign address
            addEvent("atPrevFrgnAddr", "change", togglePrevForeignAddressFields);
		    addEvent("atPrevFrgnAddr", "keyup", togglePrevForeignAddressFields);

            //mailing foreign address
            addEvent("mailFrgnAddr", "change", toggleMailForeignAddressFields);
		    addEvent("mailFrgnAddr", "keyup", toggleMailForeignAddressFields);

            //residential status
            addEvent("atResStat", "change", checkResStat);
		    addEvent("atResStat", "keyup", checkResStat);

            //property taxes
            addEvent("atPropTaxesInc", "change", togglePropertyTaxes);
		    addEvent("atPropTaxesInc", "keyup", togglePropertyTaxes);

            //employment
            addEvent("selOccupation", "change", toggleEmployment);
		    addEvent("selOccupation", "keyup", toggleEmployment);
            addEvent("selPrevOccupation", "change", togglePrevEmpFields);
		    addEvent("selPrevOccupation", "keyup", togglePrevEmpFields);
            

            //other income source
            addEvent("atOthIncSrc1", "change", toggleOtherIncomeSourceEmployer);
		    addEvent("atOthIncSrc1", "keyup", toggleOtherIncomeSourceEmployer);
		    addEvent("atOthIncSrc2", "change", toggleOtherIncomeSourceEmployer);
		    addEvent("atOthIncSrc2", "keyup", toggleOtherIncomeSourceEmployer);
		    addEvent("atOthIncSrc3", "change", toggleOtherIncomeSourceEmployer);
		    addEvent("atOthIncSrc3", "keyup", toggleOtherIncomeSourceEmployer);

            //housing disclosure
            addEvent("atState", "change", toggleHousingDisclosure);
		    addEvent("atState", "keyup", toggleHousingDisclosure);

            //employer name
            addEvent("atEmpDDL", "change", toggleEmployerName);
		    addEvent("atEmpDDL", "keyup", toggleEmployerName);

            //previous employer name
            addEvent("atPrevEmpDDL", "change", togglePrevEmployerName);
		    addEvent("atPrevEmpDDL", "keyup", togglePrevEmployerName);
		    
		    //join credit
		    addEvent("atJointCredit", "change", toggleJointCredit);
		    addEvent("atJointCredit", "keyup", toggleJointCredit);
		    
		    //area code digits
		    addEvent("atPhAreaCodeDigits", "change", toggleForeignPhoneFields);
		    addEvent("atPhAreaCodeDigits", "keyup", toggleForeignPhoneFields);
        }

        window.onbeforeunload = confirmExit;
        var needToConfirm = true;
        function confirmExit()
        {
            if(needToConfirm)
            {
                var myXMLHTTPRequeset = new S1XMLHTTPRequest();
                myXMLHTTPRequeset.xmlhttpGet("pageClose.aspx");
            }
        }

        function toggleOtherIncomeSourceEmployer()
        {
            if (getObj("atOthIncSrc1").options[getObj("atOthIncSrc1").selectedIndex].value == "P/T OR SECOND JOB" || getObj("atOthIncSrc1").options[getObj("atOthIncSrc1").selectedIndex].value == "SPOUSAL INCOME")
                getObj("atOthIncEmp1").disabled = false;
	        else
            {
                getObj("atOthIncEmp1").value = "";
                getObj("atOthIncEmp1").disabled = true;
            }

            if (getObj("atOthIncSrc2").options[getObj("atOthIncSrc2").selectedIndex].value == "P/T OR SECOND JOB" || getObj("atOthIncSrc2").options[getObj("atOthIncSrc2").selectedIndex].value == "SPOUSAL INCOME")
                getObj("atOthIncEmp2").disabled = false;
	        else
            {
                getObj("atOthIncEmp2").value = "";
                getObj("atOthIncEmp2").disabled = true;
            }

            if (getObj("atOthIncSrc3").options[getObj("atOthIncSrc3").selectedIndex].value == "P/T OR SECOND JOB" || getObj("atOthIncSrc3").options[getObj("atOthIncSrc3").selectedIndex].value == "SPOUSAL INCOME")
                getObj("atOthIncEmp3").disabled = false;
	        else
            {
                getObj("atOthIncEmp3").value = "";
                getObj("atOthIncEmp3").disabled = true;
            }
        }

        function checkResStat()
        {
            var el = getObj("atResStat");
            hide("defaultRentText");
            if(getObj("prevAtResStatVal").innerHTML == "Lives w/ relative" && getObj("defaultRentLbl").innerHTML != "")
               getObj("atCrdtrHousePmt").value = "";
                
            if(getObj("showMonthlyHousingPaymentLbl").innerHTML == "false")
            {
                if(el.options[el.selectedIndex].value == "Own - mtg")
                {
                    getObj("atCrdtrHousePmt").value = "";
                    hide(new Array("pnlHousePayments"));
                }
                else if(el.options[el.selectedIndex].value == "Own - clear" || el.options[el.selectedIndex].value == "Barracks")
                {
                    getObj("atCrdtrHousePmt").value = "";
                    hide(new Array("pnlHousePayments"));
                }
                else
                {
                    hide("pnlHousePayments");
                }
            }
            else
            {
                if(el.options[el.selectedIndex].value == "Own - mtg")
                {
                    show(new Array("pnlHousePayments"));
                }
                else if(el.options[el.selectedIndex].value == "Own - clear" || el.options[el.selectedIndex].value == "Barracks")
                {
                    getObj("atCrdtrHousePmt").value = "";
                    hide(new Array("pnlHousePayments"));
                }
                else
                {
                    show(new Array("pnlHousePayments"));
                }
            }
            
            if((el.options[el.selectedIndex].value == "Rents" || el.options[el.selectedIndex].value == "Lives w/ relative") && 
                getObj("defaultRentLbl").innerHTML != "")
            {
                if(el.options[el.selectedIndex].value == "Lives w/ relative")
                    getObj("atCrdtrHousePmt").value = getObj("defaultRentLbl").innerHTML;
                    
                show("defaultRentText");
            }
            
            if(getObj("showMonthlyHousingPaymentForRentAndLivesLbl").innerHTML == "true")
            {
                if((el.options[el.selectedIndex].value == "Rents" || el.options[el.selectedIndex].value == "Lives w/ relative"))
                    show(new Array("pnlHousePayments"));
                else
                    hide(new Array("pnlHousePayments"));
            }
            
            getObj("prevAtResStatVal").innerHTML = el.options[el.selectedIndex].value;
            togglePropertyTaxes();
        }

        function togglePropertyTaxes()
        {
            var resStat = getObj("atResStat");
            if(resStat.options[resStat.selectedIndex].value == "Own - mtg")
            {
                hide("pnlAtPropTax");
                if(getObj("showPropertyTaxLbl").innerHTML == "true")
                {
                    show("pnlAtPropTaxesInc");
                    var el = getObj("atPropTaxesInc");
                    if(el.options.selectedIndex == 2)
                        show("pnlAtPropTax");
                    else
                    {
                        hide("pnlAtPropTax");
                        getObj("atPropTax").value = "";
                    }
                }
                else
                {
                    hide(new Array("pnlAtPropTaxesInc",
                        "pnlAtPropTax"));
                    getObj("atPropTaxesInc").selectedIndex = 0;
                    getObj("atPropTax").value = "";
                }
            }
            else if(resStat.options[resStat.selectedIndex].value == "Own - clear" || 
                    resStat.options[resStat.selectedIndex].value == "Own - private - mtg")
            {
                hide("pnlAtPropTaxesInc");
                getObj("atPropTaxesInc").selectedIndex = 0;
                
                if(getObj("showPropertyTaxLbl").innerHTML == "true")
                    show("pnlAtPropTax");
                else
                {
                    hide("pnlAtPropTax");
                    getObj("atPropTax").value = "";
                }
            }
            else
            {
                hide(new Array("pnlAtPropTax",
                    "pnlAtPropTaxesInc"));

                getObj("atPropTax").value = "";
                getObj("atPropTaxesInc").selectedIndex = 0;
            }
        }

        function toggleEmployment()
        {
            var el = getObj("selOccupation");
            if(el.options[el.selectedIndex].value == "Homemaker" || el.options[el.selectedIndex].value == "Student" ||
                el.options[el.selectedIndex].value == "Unemployed w/ Income" || el.options[el.selectedIndex].value == "Unemployed w/out Income" ||
                el.options[el.selectedIndex].value == "N/A" || el.options[el.selectedIndex].value == "Retired" || 
                el.options[el.selectedIndex].value == "Disability" || el.options[el.selectedIndex].value == "Rental")
            {
                if(getObj("useEmployerNameDDLLbl").innerHTML == "true")
                {
                    getObj("atEmpDDL").options.selectedIndex = 0;
                    toggleEmployerName();
                }
                else
                    getObj("atEmp").value = "";

                getObj("atEmpPh1").value = "";
                getObj("atEmpPh2").value = "";
                getObj("atEmpPh3").value = "";
                getObj("atSalary").value = "";
                getObj("atPos").value = "";
                getObj("atTimeEmpYr").options.selectedIndex = 0;
                getObj("atTimeEmpMo").options.selectedIndex = 0;

                //previous emp
                getObj("selPrevOccupation").options.selectedIndex = 0;
                if(getObj("useEmployerNameDDLLbl").innerHTML == "true")
                {
                    getObj("atPrevEmpDDL").options.selectedIndex = 0;
                    togglePrevEmployerName();
                }
                else
                    getObj("atPrevEmp").value = "";
                
                getObj("atPrevEmpPh1").value = "";
                getObj("atPrevEmpPh2").value = "";
                getObj("atPrevEmpPh3").value = "";
                getObj("atPrevPos").value = "";
                getObj("atPrevTimeEmpYr").options.selectedIndex = 0;
                getObj("atPrevTimeEmpMo").options.selectedIndex = 0;

                hide("pnlPrevEmp");

                if (getObj("showHoursPerWeekLbl").innerHTML == "true")
                    show("pnlAtHoursPerWeek");
                else
                    hide("pnlAtHoursPerWeek");
                
                if(el.options[el.selectedIndex].value == "Disability" && getObj("showDisabilityTypeLbl").innerHTML == "true")
                {
                    hide(new Array("pnlAtPos",
                        "atEmpDiv",
                        "pnlAtEmpDDL",
                        "pnlAtEmpName",
                        "atEmpPhDiv",
                        "pnlSalary",
                        "pnlAtOtBonus",
                        "pnlTimeEmployed"));
                        
                    show("pnlAtDisabType");
                }
                else
                {
                    getObj("atDisabType").options.selectedIndex = 0;
                    hide("pnlEmp");
                }
            }
            else
            {
                show(new Array("pnlEmp",
                    "pnlAtPos",
                    "atEmpDiv",
                    "pnlAtEmpDDL",
                    "pnlAtEmpName",
                    "atEmpPhDiv",
                    "pnlSalary",
                    "pnlAtOtBonus",
                    "pnlTimeEmployed"));

                if(getObj("useEmployerNameDDLLbl").innerHTML == "true")
                {
                    show("pnlAtEmpDDL");
                    hide("atEmpDiv");
                    toggleEmployerName();
                }
                else
                {
                    hide(new Array("pnlAtEmpDDL",
                        "pnlAtEmpName"));
                    show("atEmpDiv");
                }
                
                hide("pnlAtDisabType");
                if(getObj("useEmployerNameDDLLbl").innerHTML == "true")
                {
                    toggleVerifyAttribute("atEmpDDL", true);
                    changeLabel("pnlAtEmpDDL", "Employer Name: <span class='required'>*</span>");
                    changeLabel("pnlAtEmpName", "Enter Employer Name: <span class='required'>*</span>");
                }
                else
                {
                    toggleVerifyAttribute("atEmp", true);
                    changeLabel("atEmpDiv", "Employer Name: <span class='required'>*</span>");
                }

                toggleVerifyAttribute("atEmpPh1", true);
                toggleVerifyAttribute("atEmpPh2", true);
                toggleVerifyAttribute("atEmpPh3", true);
                changeLabel("atEmpPhDiv", "Business Phone: <span class='required'>*</span>");

                toggleVerifyAttribute("atSalary", true);
                if(getObj("useBaseWagesLbl").innerHTML == "true")
                {
                    changeLabel("pnlSalary", "Base Wages: <span class='required'>*</span>");
                    getObj("atSalary").errorText = "Base Wages";
                }
                else
                {
                    if(getObj("changeSalaryLbl").innerHTML != "false")
                    {    
                        changeLabel("pnlSalary", "Salary: <span class='required'>*</span>");
                        getObj("atSalary").errorText = "Salary";
                    }
                }

                toggleVerifyAttribute("atTimeEmpYr", true);
                toggleVerifyAttribute("atTimeEmpMo", true);
                changeLabel("pnlTimeEmployed", "Time with Present Employer: <span class='required'>*</span>");
                
                if(getObj("changeTitlePosLbl").innerHTML.length > 0)
                {
                    changeLabel("pnlAtPos", getObj("changeTitlePosLbl").innerHTML + ": <span class='required'>*</span>");
                    getObj("atPos").errorText = getObj("changeTitlePosLbl").innerHTML;
                    toggleVerifyAttribute("atPos", true);
                    
                    changeLabel("pnlAtPrevPos", "Previous " + getObj("changeTitlePosLbl").innerHTML + ": <span class='required'>*</span>");
                    getObj("atPrevPos").errorText = "Previous " + getObj("changeTitlePosLbl").innerHTML;
                    toggleVerifyAttribute("atPrevPos", true);
                    
                    changeLabel("atEmpDiv", "Employer/ Military Branch: <span class='required'>*</span>");
                    getObj("atEmp").errorText = "Employer/ Military Branch";
                    
                    changeLabel("atPrevEmpDiv", "Previous Employer/ Military Branch: <span class='required'>*</span>");
                    getObj("atPrevEmp").errorText = "Previous Employer/ Military Branch";
                }
                else
                {
                    if(getObj("reqTitlePosLbl").innerHTML == "true")
                    {
                        changeLabel("pnlAtPos", "Title / Position: <span class='required'>*</span>");
                        toggleVerifyAttribute("atPos", true);
                    }
                    else
                    {
                        changeLabel("pnlAtPos", "Title / Position:");
                        toggleVerifyAttribute("atPos", false);
                    }
                }

                if(getObj("showHoursPerWeekLbl").innerHTML == "true")
                    show("pnlAtHoursPerWeek");
                else
                    hide("pnlAtHoursPerWeek");
                    
                if(getObj("hideOvertimeLbl").innerHTML == "true")
                    hide("pnlAtOtBonus");
            }
            
            if(getObj("unRequireEmpPhLbl").innerHTML == "true")
            {
                toggleVerifyAttribute("atEmpPh1", false);
                toggleVerifyAttribute("atEmpPh2", false);
                toggleVerifyAttribute("atEmpPh3", false);
                changeLabel("atEmpPhDiv", "Business Phone:");
            }
           
            if(getObj("requireOtherIncLbl").innerHTML == "true")
            {
               if(el.options[el.selectedIndex].value == "Homemaker" || el.options[el.selectedIndex].value == "Student" ||
                  el.options[el.selectedIndex].value == "Retired" || el.options[el.selectedIndex].value == "Disability")
               {
                    changeLabel("pnlTblIncome", "Other Income for Applicant: <span class='required'>*</span>");
               }
               else
                    changeLabel("pnlTblIncome", "Other Income for Applicant:");
            }
        }

        function togglePrevEmpFields()
        {
            var el = getObj("selPrevOccupation");
            if(el.options[el.selectedIndex].value == "Homemaker" || el.options[el.selectedIndex].value == "Student" ||
                el.options[el.selectedIndex].value == "Unemployed w/ Income" || el.options[el.selectedIndex].value == "Unemployed w/out Income" ||
                el.options[el.selectedIndex].value == "N/A" || el.options[el.selectedIndex].value == "Retired" || 
                el.options[el.selectedIndex].value == "Disability" || el.options[el.selectedIndex].value == "Rental")
            {
                if(getObj("useEmployerNameDDLLbl").innerHTML == "true")
                {
                    getObj("atPrevEmpDDL").options.selectedIndex = 0;
                    togglePrevEmployerName();
                }
                else
                    getObj("atPrevEmp").value = "";

                getObj("atPrevEmpPh1").value = "";
                getObj("atPrevEmpPh2").value = "";
                getObj("atPrevEmpPh3").value = "";
                getObj("atPrevPos").value = "";
                getObj("atPrevTimeEmpYr").options.selectedIndex = 0;
                getObj("atPrevTimeEmpMo").options.selectedIndex = 0;
                
                if(el.options[el.selectedIndex].value == "Disability" && getObj("showDisabilityTypeLbl").innerHTML == "true")
                {
                    show(new Array("pnlAtPrevDisabType",
                        "pnlPrevEmpFields"));
                        
                    hide(new Array("pnlAtPrevPos",
                        "atPrevEmpDiv",
                        "pnlAtPrevEmpDDL",
                        "pnlAtPrevEmpName",
                        "atPrevEmpPhDiv",
                        "pnlPrevTimeEmployed"));
                }
                else
                {
                    getObj("atPrevDisabType").options.selectedIndex = 0;
                    hide("pnlPrevEmpFields");
                }
            }
            else
            {
                if (getObj("pnlPrevEmp").style.display == "")
                {
                    show(new Array("pnlPrevEmpFields",
                        "pnlAtPrevPos",
                        "atPrevEmpDiv",
                        "pnlAtPrevEmpDDL",
                        "pnlAtPrevEmpName",
                        "atPrevEmpPhDiv",
                        "pnlPrevTimeEmployed"));

                    if(getObj("useEmployerNameDDLLbl").innerHTML == "true")
                    {
                        show("pnlAtPrevEmpDDL");
                        togglePrevEmployerName();
                        hide("atPrevEmpDiv");
                    }
                    else
                    {
                        hide(new Array("pnlAtPrevEmpDDL",
                            "pnlAtPrevEmpName"));
                        show("atPrevEmpDiv");
                    }
                    
                    hide("pnlAtPrevDisabType");
                    if(getObj("useEmployerNameDDLLbl").innerHTML == "true")
                    {
                        toggleVerifyAttribute("atPrevEmpDDL", true);
                        changeLabel("pnlAtPrevEmpDDL", "Previous Employer Name: <span class='required'>*</span>");
                        changeLabel("pnlAtPrevEmpName", "Enter Previous Employer Name: <span class='required'>*</span>");
                    }
                    else
                    {
                        toggleVerifyAttribute("atPrevEmp", true);
                        changeLabel("atPrevEmpDiv", "Previous Employer Name: <span class='required'>*</span>");
                    }
                    
                    toggleVerifyAttribute("atPrevEmpPh1", true);
                    toggleVerifyAttribute("atPrevEmpPh2", true);
                    toggleVerifyAttribute("atPrevEmpPh3", true);
                    changeLabel("atPrevEmpPhDiv", "Previous Business Phone: <span class='required'>*</span>");
                    toggleVerifyAttribute("atPrevTimeEmpYr", true);
                    toggleVerifyAttribute("atPrevTimeEmpMo", true);
                    changeLabel("pnlPrevTimeEmployed", "Time with Previous Employer: <span class='required'>*</span>");
                    
                    if(getObj("changeTitlePosLbl").innerHTML.length > 0)
                    {
                        changeLabel("pnlAtPos", getObj("changeTitlePosLbl").innerHTML + ": <span class='required'>*</span>");
                        getObj("atPos").errorText = getObj("changeTitlePosLbl").innerHTML;
                        toggleVerifyAttribute("atPos", true);
                        
                        changeLabel("pnlAtPrevPos", "Previous " + getObj("changeTitlePosLbl").innerHTML + ": <span class='required'>*</span>");
                        getObj("atPrevPos").errorText = "Previous " + getObj("changeTitlePosLbl").innerHTML;
                        toggleVerifyAttribute("atPrevPos", true);
                        
                        changeLabel("atEmpDiv", "Employer/ Military Branch: <span class='required'>*</span>");
                        getObj("atEmp").errorText = "Employer/ Military Branch";
                        
                        changeLabel("atPrevEmpDiv", "Previous Employer/ Military Branch: <span class='required'>*</span>");
                        getObj("atPrevEmp").errorText = "Previous Employer/ Military Branch";
                    }
                    else
                    {
                        if(getObj("reqTitlePosLbl").innerHTML == "true")
                        {
                            changeLabel("pnlAtPrevPos", "Previous Title / Position: <span class='required'>*</span>");
                            toggleVerifyAttribute("atPrevPos", true);
                            
                        }
                        else
                        {
                            changeLabel("pnlAtPrevPos", "Previous Title / Position:");
                            toggleVerifyAttribute("atPrevPos", false);
                        }
                    }
                }
            }
            
            if(getObj("unRequireEmpPhLbl").innerHTML == "true")
            {
                toggleVerifyAttribute("atPrevEmpPh1", false);
                toggleVerifyAttribute("atPrevEmpPh2", false);
                toggleVerifyAttribute("atPrevEmpPh3", false);
                changeLabel("atPrevEmpPhDiv", "Previous Business Phone:");
           }
        }

        function toggleAddressFields()
        {
            var el = getObj("atAddrType");
            if(el.options.selectedIndex == 0) 
            {
                if(getObj("useSingleAddrLineLbl").innerHTML == "true")
                {
                    hide("pnlStandardAddr");
                    show("pnlStandardSingleLineAddr");
                }
                else
                {
                    show("pnlStandardAddr");
                    hide("pnlStandardSingleLineAddr");
                }
                
                hide(new Array("pnlRuralAddr",
                    "pnlPOBoxAddr"));
            }
            else if(el.options.selectedIndex == 1) 
            {
                show("pnlRuralAddr");
                hide(new Array("pnlStandardAddr",
                    "pnlStandardSingleLineAddr",
                    "pnlPOBoxAddr"));
            }   
            else if(el.options.selectedIndex == 2) 
            {
                show("pnlPOBoxAddr");
                hide(new Array("pnlStandardAddr",
                    "pnlStandardSingleLineAddr",
                    "pnlRuralAddr"));
                    
               if(getObj("toggleMailingAddrFieldsLbl").innerHTML == "true")
                {
                    getObj("mailAddrDif").options.selectedIndex = 1;
                    toggleMailAddr();
                }
            }
        }

        function toggleBusAddressFields()
        {
            var el = getObj("beAddrType");
            if(el.options.selectedIndex == 0) 
            {
                show("pnlBusStandardAddr");
                hide(new Array("pnlBusRuralAddr",
                    "pnlBusPOBoxAddr"));
            }
            else if(el.options.selectedIndex == 1) 
            {
                show("pnlBusRuralAddr");
                hide(new Array("pnlBusStandardAddr",
                    "pnlBusPOBoxAddr"));
            }   
            else if(el.options.selectedIndex == 2) 
            {
                show("pnlBusPOBoxAddr");
                hide(new Array("pnlBusStandardAddr",
                    "pnlBusRuralAddr"));
            }
        }

        function togglePrevAddressFields()
        {
            var el = getObj("atPrevAddrType");
            if(el.options.selectedIndex == 0) 
            {
                if(getObj("useSingleAddrLineLbl").innerHTML == "true")
                {
                    hide("pnlPrevStandardAddr");
                    show("pnlPrevStandardSingleLineAddr");
                }
                else
                {
                    show("pnlPrevStandardAddr");
                    hide("pnlPrevStandardSingleLineAddr");
                }

                hide(new Array("pnlPrevRuralAddr",
                    "pnlPrevPOBoxAddr"));
            }
            else if(el.options.selectedIndex == 1) 
            {
                show("pnlPrevRuralAddr");
                hide(new Array("pnlPrevStandardAddr",
                    "pnlPrevStandardSingleLineAddr",
                    "pnlPrevPOBoxAddr"));
            }   
            else if(el.options.selectedIndex == 2) 
            {
                show("pnlPrevPOBoxAddr");
                hide(new Array("pnlPrevStandardAddr",
                    "pnlPrevStandardSingleLineAddr",
                    "pnlPrevRuralAddr"));
            }
        }

        function togglePrevEmp() 
        {
            if(getObj("showPrevEmpLbl").innerHTML == "true" && getObj("atTimeEmpYr").options.selectedIndex > 0)
            {
                var months = parseInt(getObj("atTimeEmpYr").options[getObj("atTimeEmpYr").options.selectedIndex].value * 12);
                months += parseInt(getObj("atTimeEmpMo").options[getObj("atTimeEmpMo").options.selectedIndex].value);

                if(months < parseInt(getObj("showPrevEmpMonthsLbl").innerHTML))
                {
                    show("pnlPrevEmp");

                    if(getObj("requireEmpStatusLbl").innerHTML == "true")
                    {
                        toggleVerifyAttribute("selPrevOccupation", true);
                        changeLabel("pnlSelPrevOccupation", "Previous Employment Status: <span class='required'>*</span>");
                    }
                    else
                    {
                        toggleVerifyAttribute("selPrevOccupation", false);
                        changeLabel("pnlSelPrevOccupation", "Previous Employment Status:");
                    }

                    if(getObj("useEmployerNameDDLLbl").innerHTML == "true")
                    {
                        show("pnlAtPrevEmpDDL");
                        togglePrevEmployerName();
                        hide("atPrevEmpDiv");
                    }
                    else
                    {
                        hide(new Array("pnlAtPrevEmpDDL",
                            "pnlAtPrevEmpName"));
                        show("atPrevEmpDiv");
                    }
                }
                else
                    hide("pnlPrevEmp");
            }
            else
                hide("pnlPrevEmp");
        }

        function togglePrevAddr() 
        {
            if(getObj("showPrevAddrLbl").innerHTML == "true" && getObj("atTimeAddrYr").options.selectedIndex > 0)
            {
                var months = parseInt(getObj("atTimeAddrYr").options[getObj("atTimeAddrYr").options.selectedIndex].value * 12);
                months += parseInt(getObj("atTimeAddrMo").options[getObj("atTimeAddrMo").options.selectedIndex].value);

                if(months < parseInt(getObj("showPrevAddrMonthsLbl").innerHTML))
                {
                    show("pnlPrevAddr");
                    togglePrevAddressFields();
                    togglePrevForeignAddressFields();
                }
                else
                    hide("pnlPrevAddr");
            }
            else
                hide("pnlPrevAddr");
        }

        function toggleMailAddr() 
        {
            if(getObj("hideMailAddrDifLbl").innerHTML == "true")
                hide("pnlMailAddrDif");
            else
            {
                var el = getObj("mailAddrDif");
                
                if (el.options.selectedIndex == 1)
                {
	                show("pnlMailAddr");
                    toggleMailForeignAddressFields();
                }
                else
                    hide("pnlMailAddr");
            }
        }

        function toggleForeignAddressFields() 
        {
            var el = getObj("atFrgnAddr");
            if(el.options.selectedIndex == 0)
            {
                hide(new Array("pnlAtState",
                    "pnlAtZip"));

                show(new Array("pnlAtProv",
                    "pnlAtCntry",
                    "pnlAtPstlCd"));
            }
            else
            {
                hide(new Array("pnlAtProv",
                    "pnlAtCntry",
                    "pnlAtPstlCd"));
                
                show(new Array("pnlAtState",
                    "pnlAtZip",
                    "pnlAtPh",
                    "pnlAtCellPh"));
            }
        }
        
        function toggleForeignPhoneFields()
        {
            if(getObj("atPhAreaCodeDigits").options[getObj("atPhAreaCodeDigits").selectedIndex].value == "Yes")
            {
                hide(new Array("pnlAtForeignPh",
                        "pnlAtForeignCellPh"));
                        
                show(new Array("pnlAtPh",
                    "pnlAtCellPh"));
            }
            else
            {
                hide(new Array("pnlAtPh",
                        "pnlAtCellPh"));
                        
                show(new Array("pnlAtForeignPh",
                    "pnlAtForeignCellPh"));
            }
        }

        function togglePrevForeignAddressFields() 
        {
            if (getObj("pnlAtFrgnAddr").style.display == "")
            {
                show("pnlAtPrevFrgnAddr");
                var el = getObj("atPrevFrgnAddr");
                if(el.options.selectedIndex == 0)
                {
                    hide(new Array("pnlAtPrevState",
                        "pnlAtPrevZip"));

                    show(new Array("pnlAtPrevProv",
                        "pnlAtPrevCntry",
                        "pnlAtPrevPstlCd"));
                }
                else
                {
                    hide(new Array("pnlAtPrevProv",
                        "pnlAtPrevCntry",
                        "pnlAtPrevPstlCd"));
                    
                    show(new Array("pnlAtPrevState",
                        "pnlAtPrevZip"));
                }
            }
            else
                hide("pnlAtPrevFrgnAddr");
        }

        function toggleMailForeignAddressFields()
        {
            if (getObj("pnlAtFrgnAddr").style.display == "")
            {
                show("pnlMailFrgnAddr");
                var el = getObj("mailFrgnAddr");
                if (el.options.selectedIndex == 0)
                {
                    hide(new Array("pnlMailState",
                        "pnlMailZip"));

                    show(new Array("pnlMailProv",
                        "pnlMailCntry",
                        "pnlMailPstlCd"));
                }
                else
                {
                    hide(new Array("pnlMailProv",
                        "pnlMailCntry",
                        "pnlMailPstlCd"));

                    show(new Array("pnlMailState",
                        "pnlMailZip"));
                }
            }
            else
            {
                hide("pnlMailFrgnAddr");
                hide(new Array("pnlMailProv",
                    "pnlMailCntry",
                    "pnlMailPstlCd"));
            }
        }

        function toggleRequiredFields()
        {
            if(getObj("custName").innerHTML == "SANDIA")
            {
                toggleVerifyAttribute("atChecking", false);
                changeLabel("pnlChecking", "Do you have a checking account?");
                toggleVerifyAttribute("atSavings", false);
                changeLabel("pnlSavings", "Do you have a savings account?");
            }
        }

        function toggleHousingDisclosure()
        {
            if(getObj("showhousingDisclosureLbl").innerHTML == "true")
            {
                var el = getObj("atState");
                if (el.options.value == "CA")
                {
                    show("pnlDisclosure");
                    if(getObj("allowContinueLbl").innerHTML == "true")
                        enableContinueButtons();
                    else
                    {
                        getObj("Continue").disabled = true;
                        getObj("Continue_Top").disabled = true;
                    }
                }
                else
                {
                    hide("pnlDisclosure");
                    enableContinueButtons();
                }
            }
        }
        
        function toggleDisclosure()
        {
            if(getObj("showDisclosureLbl").innerHTML == "true")
            {
                show("pnlDisclosure");
                if(getObj("allowContinueLbl").innerHTML == "true")
                    enableContinueButtons();
                else
                {
                    getObj("Continue").disabled = true;
                    getObj("Continue_Top").disabled = true;
                }
            }
        }

        function toggleEmployerName()
        {
            if(getObj("useEmployerNameDDLLbl").innerHTML == "true")
            {
                var el = getObj("atEmpDDL");
                if(el.options[el.selectedIndex].value == "Other")
                    show("pnlAtEmpName");
                else
                {
                    hide("pnlAtEmpName");
                    getObj("atEmpName").value = "";
                }
            }
        }

        function togglePrevEmployerName()
        {
            if(getObj("useEmployerNameDDLLbl").innerHTML == "true")
            {
                var el = getObj("atPrevEmpDDL");
                if(el.options[el.selectedIndex].value == "Other")
                    show("pnlAtPrevEmpName");
                else
                {
                    hide("pnlAtPrevEmpName");
                    getObj("atPrevEmpName").value = "";
                }
            }
        }
        
        function toggleJointCredit()
        {
            if(getObj("showJointCreditLbl").innerHTML == "true")
            {
                hide(new Array("pnlAppType",
                    "pnlAltJointDDL"));
                show("pnlAtJointCredit");
                if(getObj("doNotRequireJointCreditLbl").innerHTML == "true")
                {
                    changeLabel("pnlAtJointCredit", "Is it your intent to apply for joint credit?");
                    toggleVerifyAttribute("atJointCredit", false);
                }
                
                if(getObj("atJointCredit").options[getObj("atJointCredit").selectedIndex].value == "Yes")
                {
                    show("pnlCoAppJointCredit");
                    if(getObj("doNotRequireCoAppJointCreditLbl").innerHTML == "true")
                    {
                        changeLabel("pnlCoAppJointCredit", "Is it the next borrower's intent to apply for joint credit?");
                        toggleVerifyAttribute("coAppJointCredit", false);
                    }
                }
                else
                    hide("pnlCoAppJointCredit");
            }
            else if(getObj("showAltJointDDLLbl").innerHTML == "true")
            {
                show("pnlAltJointDDL");
                hide(new Array("pnlAppType",
                    "pnlAtJointCredit",
                    "pnlCoAppJointCredit"));
            }
            else
            {
                show("pnlAppType");
                hide(new Array("pnlAltJointDDL",
                    "pnlAtJointCredit",
                    "pnlCoAppJointCredit"));
            }
        }

        function enableContinueButtons()
        {
            getObj("Continue").disabled = false;
            getObj("Continue_Top").disabled = false;
        }