addEvent(window, "load", Init);

        function Init()
        {
            if(getObj("showDealerNameLbl").innerHTML == "true")
            {
                show(new Array("dealerNameRow",
                    "dealerName"));
            }
            else
            {
                hide(new Array("dealerNameRow",
                    "dealerName"));
            }
        }