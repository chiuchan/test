addEvent(window, "load", Init);

        function Init()
        {
            var str1 = QString("scen");

            setTimeout("swapProc()", 10000);
        }

        function swapProc()
        {
	        toggle(new Array("pnlProc", "pnlButton"));
        }