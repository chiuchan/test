addEvent(window, "load", Init);
function Init()
        {
            toggleAddLiability();
            toggleAssetRequiredFields();
            
            addEvent("radAdditionalLiability1", "click", function() { show('pnlAdditionalLiability') });
	        addEvent("radAdditionalLiability2", "click", function() { hide('pnlAdditionalLiability') });
	        
	        addEvent("liabilityType", "change", toggleAssetRequiredFields);
	        addEvent("liabilityType", "keyup", toggleAssetRequiredFields);
	        
	        addEvent("liabilityAccosiatedProp", "change", togglePurchaseProp);
	        addEvent("liabilityAccosiatedProp", "keyup", togglePurchaseProp);
	        
	        if(getObj("showSaveSuccessLbl").innerHTML == "true")
	            showSaveSuccessAlert();
	            
	        if(getObj("pageFocusLbl").innerHTML.length > 0)
	        {
	            getObj(getObj("pageFocusLbl").innerHTML).focus();
	            getObj("AddLiabilityButton").value = "Update Liability";
	        }
        }
        
        window.onbeforeunload = confirmExit;
        var needToConfirm = true;
        function confirmExit(el)
        {
            if(el == "true" || needToConfirm)
            {
                var myXMLHTTPRequeset = new S1XMLHTTPRequest();
                myXMLHTTPRequeset.xmlhttpGet("pageClose.aspx");
            }
        }
        
        function toggleAddLiability()
        {
            if(getObj("radAdditionalLiability1").checked)
                show('pnlAdditionalLiability');
            else
                hide('pnlAdditionalLiability');
        }
        
        function toggleAssetRequiredFields()
        {
            var el = getObj("liabilityType");
            if (el.options[el.selectedIndex].value == "Mortgage")
            {
                show(new Array("pnlLiabilityLienPosition",
                    "pnlLiabilityAccosiatedProp"));
            }
            else
            {
                hide(new Array("pnlLiabilityLienPosition",
                    "pnlLiabilityAccosiatedProp"));
            }
            
            if (el.options[el.selectedIndex].value == "Alimony" || 
                el.options[el.selectedIndex].value == "Child Support")
            {
                changeLabel("pnlLiabilityBalance", "Balance:");
                changeLabel("pnlLiabilityAccountNum", "Account Number:");
                changeLabel("pnlLiabilityFinancialInstitution", "Financial Institution:");
            }
            else
            {
                changeLabel("pnlLiabilityBalance", "Balance: <span class='required'>*</span>");
                changeLabel("pnlLiabilityAccountNum", "Account Number: <span class='required'>*</span>");
                changeLabel("pnlLiabilityFinancialInstitution", "Financial Institution: <span class='required'>*</span>");
            }
            
            togglePurchaseProp();
        }
        
        function togglePurchaseProp()
        {
            var liabType = getObj("liabilityType");
            var propFound = "false";
            var trueStr = "true";
            var falseStr = "false";
            var colonStr = ":";
            
            if (liabType.options[liabType.selectedIndex].value == "Mortgage")
            {
                var assocProp = getObj("liabilityAccosiatedProp").options[getObj("liabilityAccosiatedProp").selectedIndex].value;
                if(assocProp.length > 0)
                {
                    var propArray = getObj("propertyLbl").innerHTML.split(",");
                    if(propArray.length > 0)
                    {
                        var addrArray;
                        for(var index = 0; index < propArray.length && propFound == falseStr; index++)
                        {
                            addrArray = propArray[index].split(colonStr);
                            if(addrArray.length == 2)
                            {
                                if(addrArray[0] == assocProp && addrArray[1] == trueStr)
                                {
                                    show("pnlLiabilityAccountForPurchaseProperty");
                                    propFound = trueStr;
                                }
                            }
                        }
                    }
                }
            }
            
            if(propFound == "false")
                hide("pnlLiabilityAccountForPurchaseProperty");
        }
        /*
        function Init()
        {
            toggleAddLiability();
            
            addEvent("radAdditionalLiability1", "click", function() { show('pnlAdditionalLiability') });
	        addEvent("radAdditionalLiability2", "click", function() { hide('pnlAdditionalLiability') });        
	        
	        if(getObj("showSaveSuccessLbl").innerHTML == "true")
	            showSaveSuccessAlert();
        }
        
        window.onbeforeunload = confirmExit;
        var needToConfirm = true;
        function confirmExit()
        {
            if(needToConfirm)
            {
                var myXMLHTTPRequeset = new S1XMLHTTPRequest();
                myXMLHTTPRequeset.xmlhttpGet("pageClose.aspx");
            }
        }
        
        function toggleAddLiability()
        {
            if(getObj("radAdditionalLiability1").checked)
                show('pnlAdditionalLiability');
            else
                hide('pnlAdditionalLiability');
        }
        */