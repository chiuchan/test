addEvent(window, "load", Init);

        function Init()
        {
            setTimeout("redirectPage()", 3000);

            if(getObj("loginTypeLbl").innerHTML == "Intranet")
            {
                hide("pnlDealerLogin");
                show("pnlUserName");
            }
            else
            {
                hide("pnlUserName");
                show("pnlDealerLogin");
            }
            
            if(getObj("showPasswordLbl").innerHTML == "true")
                show(new Array("pnlUserPass",
                        "pnlPasswordLinks"));
            else
                hide(new Array("pnlUserPass",
                        "pnlPasswordLinks"));

            if (getObj("pnlLoginSuccess").style.display == "" ||
                getObj("pnlWelcome").style.display == "")
            {
                hide(new Array("pnlUserName",
                        "pnlDealerLogin",
                        "pnlPageNav"));
            }
        }

        function redirectPage()
        {
            if (getObj("pnlLoginSuccess").style.display == "" ||
                getObj("pnlWelcome").style.display == "")
            {
	            location.href = "appHistory.aspx";
	        }
        }