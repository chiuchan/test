addEvent(window, "load", Init);

        function Init()
        {
            var answer = confirm("Are you sure you want to logout?")
	        if (answer)
		        window.location.href = "logout.aspx?logout=true";
	        else
		        window.location.href = "appHistory.aspx";
        }