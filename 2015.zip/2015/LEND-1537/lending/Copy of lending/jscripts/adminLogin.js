	addEvent(window, "load", Init);

        function Init()
        {
            setTimeout("redirectPage()", 3000);
        }

        function redirectPage()
        {
            if (getObj("pnlLoginSuccess").style.display == "")
            {
	            location.href = "editConfigSettings.aspx";
	        }
        }