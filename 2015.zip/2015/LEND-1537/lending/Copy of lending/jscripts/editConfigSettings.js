function fnGetContent(id)
		{
		     varHTML = getObj(id);
		     var popUP = prompt("Change Text", varHTML.innerHTML);
		     var revised = getObj("rateTxt");
		     var lbl = getObj("rateLbl");
		     alert("Text Changed");
			    varHTML.innerHTML = popUP;
			    revised.value = lbl.innerHTML;
		}