addEvent(window, "load", Init);

        function Init()
        {
            toggleProdFields();
            
            addEvent("systemType", "change", toggleProdFields);
		    addEvent("systemType", "keyup", toggleProdFields);
        }

        window.onbeforeunload = confirmExit;
        var needToConfirm = true;
        function confirmExit()
        {
            if(needToConfirm)
            {
                var myXMLHTTPRequeset = new S1XMLHTTPRequest();
                myXMLHTTPRequeset.xmlhttpGet("pageClose.aspx");
            }
        }
        
        function toggleProdFields()
        {
            if (getObj("systemType").options[getObj("systemType").selectedIndex].value == "Consumer")
            {
                getObj("mortgageProd").selectedIndex = 0;
                if(getObj("pnlMortgage").style.display == "")
                {
                    hide(new Array("pnlMortgage",
                        "pnlRateThreshold",
                        "pnlAtEmail",
                        "pnlPageNav"));
                }
                else
                    hide("pnlMortgage");
                    
                show("pnlConsumer");
                
                if(getObj("prodType").selectedIndex == 0)
                    hide("pnlProdDesc");
            }
            else if (getObj("systemType").options[getObj("systemType").selectedIndex].value == "Mortgage")
            {
                getObj("prodType").selectedIndex = 0;
                if(getObj("pnlConsumer").style.display == "")
                {
                    hide(new Array("pnlConsumer",
                        "pnlRateThreshold",
                        "pnlAtEmail",
                        "pnlPageNav"));
                }
                else
                    hide("pnlConsumer");
                
                show("pnlMortgage");
                if(getObj("mortgageProd").selectedIndex == 0)
                    hide("mortgageProgram");
            }
            else
                hide(new Array("pnlConsumer",
                    "pnlMortgage",
                    "pnlRateThreshold",
                    "pnlAtEmail",
                    "pnlPageNav"));
        }