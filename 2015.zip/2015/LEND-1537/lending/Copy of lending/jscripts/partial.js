function isString(a) { return typeof a == 'string';}
function isArray(a) { return isObject(a) && a.constructor == Array; }
function isObject(a) { return (a && typeof a == 'object') || isFunction(a);}

// Disable the [Backspace] and [Enter] keys
//
if (typeof window.event != 'undefined')
    document.onkeydown = function()
    {
        if (event.srcElement.tagName.toUpperCase() != 'INPUT' && 
            event.srcElement.tagName.toUpperCase() != 'TEXTAREA' )
        {
            return (event.keyCode != 8 && event.keyCode != 13);
        }
        else
            return (event.keyCode != 8 || event.keyCode != 13);
    }
else
    document.onkeypress = function(e)
    {
        if (e.target.nodeName.toUpperCase() != 'INPUT' && 
            e.target.nodeName.toUpperCase() != 'TEXTAREA' )
        {
            return (e.keyCode != 8 && e.keyCode != 13);
        }
        else
            return (e.keyCode != 8 || e.keyCode != 13);
   }

function getObj(name) 
{     
  if (document.getElementById)  
  {
    if (document.getElementById(name))
  	    return document.getElementById(name);
  }
  else if (document.all)  {
	if (document.all[name])
	    return document.all[name];
  }
  else if (document.layers)  
  {
    if (document.layers[name]) 
    {
        this.style = document.layers[name];
   	    return document.layers[name]; 
   	}
  }
}

/*
    Add click, blur etc events
    usage: addEvent(object, event type [no 'on'], function, use Capture)
*/    
function addEvent(obj, evType, fn, useCapture)
{
  if (isString(obj)) obj = getObj(obj);
  
  if (obj.addEventListener)
  {
    obj.addEventListener(evType, fn, useCapture);
    return true;
  } 
  else if (obj.attachEvent) {
    var r = obj.attachEvent("on" + evType, fn);
    return r;
  } 
  else 
  {
    alert("Handler could not be attached");
  }
}

function checkAll()
{
    var pa = document.body;
    var A = null;
    var L = null;
    var quoteStr = "";
    var genericError = " is a required field<br/>";
    var errorFound = false;
    var errorStr = "";
    var brStr = "<br/>";
    var browser = navigator.appName;

    for (var x = 0; x <= 1; x++)
    {
        if (x == 0)
        {
            A = pa.getElementsByTagName('input');
            L = A.length;
        }
        else
        {
            A = pa.getElementsByTagName('select');
            L = A.length;
        }

        //loop through all of the elements
        for (var i = 0; i < L; i++)
        {
            if (browser == "Microsoft Internet Explorer")
            {
                if (A[i].verify && A[i].isRequired == "true" && 
                    A[i].value.length == 0)
                {
                    errorFound = true;
                    if (A[i].errorText != null && A[i].errorText.length > 0)
                        errorStr += A[i].errorText + brStr;
                    else
                        errorStr += A[i].id + genericError;
                }
            }
            else
            {
                if (A[i].getAttribute('verify') == "true" && A[i].getAttribute('isRequired') == "true" && 
                    A[i].value.length == 0)
                {
                    errorFound = true;
                    if (A[i].getAttribute('errorText') != null && A[i].getAttribute('errorText').length > 0)
                        errorStr += A[i].getAttribute('errorText') + brStr;
                    else
                        errorStr += A[i].id + genericError;
                }
            }
        }
    }

    if (errorFound)
    {
        errorStr = "<font size='3'>Missing \\ Incomplete Required Fields</font><br/><br/>" + errorStr;
        getObj("pnlError").innerHTML = errorStr;
        show("pnlError");
        scroll(0,0);
    }
    else
        hide("pnlError");
    
    return !errorFound;
}

function show(target) 
{
	if (isString(target))
    {
        targetStr = target;
        target = getObj(target);
    }
	
    var t;
	if (isArray(target)) 
	{
		var tarLen = target.length;
		for (var i = 0; i < tarLen; i++ ) {
			show(target[i]);
		}
	} 
	else {
	    if (t = target) {   	    		
    		t.style.display = "";
            enableDisableRequiredFields(targetStr, true);
		    return true;    
		}
		else {
		    return false; 
		}
	}
}

function hide(target) 
{
	if (isString(target)) 
    {
        targetStr = target;
        target = getObj(target);
    }

    var t;
	if (isArray(target)) 
	{
		var tarLen = target.length;
		for (var i = 0; i < tarLen; i++ ) {
			hide(target[i]);
		}
	} 
	else {
        if (t = target) 
        {                
			t.style.display = "none";
            enableDisableRequiredFields(targetStr, false);
		    return true; 
		}
		else {
		    return false;	
		}
	}
}

//disables input and select fields within the given panel\div element
//
function enableDisableRequiredFields(pa, enableRF)
{
    var pa = document.getElementById(pa);

    if (!pa)
        pa = document.body;

    var A = null;
    var L = null;

    for (var x = 0; x <= 1; x++)
    {
        if (x == 0)
        {
            A = pa.getElementsByTagName('input');
            L = A.length;
        }
        else
        {
            A = pa.getElementsByTagName('select');
            L = A.length;
        }

        // loop through all of the elements
        for (var i = 0; i < L; i++)
        {
            if (A[i].isRequired || A[i].getAttribute('isRequired') == "true")
            {
                if (enableRF)
                    doEnable(A[i].id);
                else
                    doDisable(A[i].id);
            }
        }
    }
}

function doEnable(target) 
{
	if (isString(target)) 
        target = getObj(target);
	
    var t;
    var browser = navigator.appName;
	if (isArray(target)) 
	{
		var tarLen = target.length;
		for (var i = 0; i < tarLen; i++ ) {
			doEnable(target[i]);
		}
	} 
    else {
	    if (t = target) 
	    {
            if (browser == "Microsoft Internet Explorer")
                t.verify = true;
            else
        		t.setAttribute('verify', true);
            
		    return true;    
        }
		else {
		    return false; 
		}
	}
}

function doDisable(target) 
{
	if (isString(target)) 
        target = getObj(target);

    var t;
    var browser = navigator.appName;
	if (isArray(target)) 
    {
		var tarLen = target.length;
		for (var i = 0; i < tarLen; i++ ) {
			doDisable(target[i]);
		}
	} 
    else {
        if (t = target) 
        {
            if (browser == "Microsoft Internet Explorer")
                t.verify = false;
            else
			    t.setAttribute('verify', false);
		    return true; 
        }
		else {
		    return false;	
		}
	}
}