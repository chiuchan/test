/**
 * Title:        CS Utils
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      X/Net Associates
 * @author Len Doerich
 * @version 1.0
 */

package com.xnai.credisphere.util;

public class CSFieldNames
{

  private CSFieldNames()
  {
  }

  public static final String FN_AMORT_TYPE = "anAmortTypD";

  // settlement information
  public static final String FN_STLMT_D = "anStlmtNameD";

  public static final String FN_STLMT_ADDR = "anStlmtAddr";
  public static final String FN_STLMT_ADDR_TWO = "anStlmtAddrTwo";
  public static final String FN_STLMT_CITY = "anStlmtCity";
  public static final String FN_STLMT_ST = "anStlmtStD";
  public static final String FN_STLMT_ZIP = "anStlmtZip";
  public static final String FN_STLMT_ZIP_PLUS = "anStlmtZipPlus";
  public static final String FN_STLMT_CONTACT = "anStlmtCnt";
  public static final String FN_STLMT_EMAIL = "anStlmtEmail";
  public static final String FN_STLMT_PHONE = "anStlmtPh";
  public static final String FN_STLMT_FAX = "anStlmtFax";

  public static final String LABEL_NAME_IDENTIFIER = "L_";
  public static final String LABEL_FIELD_IDENTIFIER = "LF";

  public static final String FN_APP_ID = "anAppId";
  public static final String FN_LINK_APP_ID = "anLinkAppId";
  public static final String FN_APP_ID_HID = "anIdHid";
  public static final String FN_APP_REF_ID = "anRefId";
  public static final String FN_APP_ID_FILTER = "afAppT";
  public static final String FN_APP_PRIORITY = "anPriorD";

  public static final String FN_LOAN_NUMBER = "anLoanNum";
  public static final String FN_LOAN_SUFFIX = "anLoanSfx";

  public static final String FN_APP_DT = "anAppDt";
  public static final String FN_APP_TIME = "anAppH";
  public static final String FN_APP_RCVD_DT = "anRcvDt";

  public static final String FN_EDIT_MODE = "_anModeHid";
  public static final String FN_RETURN_FORM = "_anFormHid";
  public static final String FN_POS_HID = "_POSHid";

  public static final String FN_BRANCH_ID = "anAppBrD";
  public static final String FN_PRODUCT_ID = "anProdTypeD";
  public static final String FN_PROGRAM_ID = "anProgTypeD";
  public static final String FN_PRODUCT_TYPE = "anProdType";
  public static final String FN_LOAN_TYPE = "anLoanType";
  public static final String FN_PURPOSE_GEN = "anGenPurM";
  public static final String FN_PURPOSE_GEN_D = "anGenPurD";
  public static final String FN_APP_PROCESSOR = "anProcessor";
  public static final String FN_DATA_ENTRY = "anDataEntry";
  public static final String FN_VERIFIER = "anVerifier";
  public static final String FN_UNDERWRITER = "anUnder";
  public static final String FN_FIN_REVIEWER = "anFnlRvw";
  public static final String FN_AUDITOR = "anAuditor";
  public static final String FN_LOAN_OFFICER = "anLnOff";
  public static final String FN_CB = "anCBD";
  public static final String FN_REG_B = "anRegBTypD";
  public static final String FN_DEALER_ID = "anSlrD";
  public static final String FN_PRE_APPROVED = "anPreApvC";
  public static final String FN_REG_O_LOAN = "anRegOC";
  public static final String FN_EMP_LOAN = "anEmpC";
  public static final String FN_AUTO_PMTS = "anAutoPmtC";
  public static final String FN_CF_INT_CP_DBT = "anCFIntCPDbt";
  public static final String FN_CF_CVG = "anCFCvg";
  public static final String FN_CF_OP_TTL = "anCFOPTtl";
  public static final String FN_CF_OP_DEBT_TTL = "anCFOPDbtTtl";
  public static final String FN_CF_CP_DEBT = "anCFCPDbt";
  public static final String FN_CF_CP_NEW_REQ = "anCFCPNwRq";
  public static final String FN_CF_CP_OTHER_REQ = "anCFCPOthRq";
  public static final String FN_CF_BUS_TTL = "anCFBusTtl";
  public static final String FN_CF_BUS_DEBT_TTL = "anCFBusDbtTtl";
  public static final String FN_CF_INT_CP_NW_RQ = "anCFIntCPNwRq";
  public static final String FN_CF_ANN_CP_NW_RQ = "anCFAnnCPNwRq";
  public static final String FN_CF_INT_CVG = "anCFIntCvg";
  public static final String FN_CF_ANN_CVG = "anCFAnnCvg";
  public static final String FN_CF_ANN_CP_DBT = "anCFAnnCPDbt";
  public static final String FN_CF_TTL = "anCFTtl";
  public static final String FN_CF_DBT_TTL = "anCFDbtTtl";
  public static final String FN_CF_DI = "anCFDI";
  public static final String FN_CF_XS = "anCFXs";
  public static final String FN_CF_TTL_CVG = "anCFTtlCvg";
  public static final String FN_SRC_REPMTD = "anSrcRepmtD";
  public static final String FN_SRCD = "anSrcD";
  public static final String FN_PRM_APP_IND_D = "anPrmAppIndD";
  public static final String FN_PRP_1ST_MTG_BAL = "anPrp1stMtgBal";
  public static final String FN_PRP_1ST_MTG_AMT = "anPrp1stMtgAmt";
  public static final String FN_GR_TYPE = "anGrTypD";
  // 9-17-09, ccl
  //
  public static final String FN_APP_ORIGINATOR = "anOriginator";
  public static final String FN_APP_CLOSER = "anCloser";
  public static final String FN_APP_POST_CLOSER = "anPostCloser";

  // Dynamic Data Entry
  //
  public static final String FN_NXT_ACT = "anNxtActD";

  public static final String FN_USE_FIN_C = "_UseFinC";
  public static final String FN_UPDATE_CF_FIELDS_C = "_updateCFFieldsC";

  // Application: - payment fields
  //
  public static final String FN_PMT_TYPE = "anPmtTypD";
  public static final String FN_PMT_TYPE_RADIO = "anPmtTypR";
  public static final String FN_PMT_BLN_RADIO = "anBlnCalcR";

  public static final String FN_PMT_AMT = "anPmtAmt";
  public static final String FN_EST_PMT_AMT = "anEstPmtAmt";
  public static final String FN_FINAL_PMT_AMT = "anBalloonPmt";
  public static final String FN_MAX_INT_PMT = "anMaxIntPmt";
  public static final String FN_MIN_INT_PMT = "anMinIntPmt";
  public static final String FN_TTL_PMT = "anTtlPmt";
  public static final String FN_TTL_INT = "anTtlInt";
  public static final String FN_PMT_AMT_QUAL = "anPmtAmtQual";

  public static final String FN_AMORT_CALC = "anAmortC";
  public static final String FN_AMORT_SCHEDULE = "anAmortL";
  public static final String FN_NUM_PMT = "anNumPmt";
  public static final String FN_PMT_PRD = "anPmtPrdD";
  public static final String FN_PRN_INT_PMT_TYPE = "anPmtCalcTypR";
  public static final String FN_PMT_SOLVE_FOR = "anPmtSolveR";
  public static final String FN_PMT_TERM_PMT = "anTermRegPmt";
  public static final String FN_PRN_INT_PMT = "anPrinPmt";
  public static final String FN_INT_PMT_PRD = "anIntPmtPrdD";
  public static final String FN_NUM_INT_PMT = "anIntNumPmt";
  public static final String FN_INT_ACCRUAL = "anIntAccD";
  public static final String FN_AMORT_PRD = "anAmortPrd";
  public static final String FN_IS_PREPAID_INT = "anPrePaidIntC";
  public static final String FN_ODD_DAYS = "anOddDays";
  public static final String FN_PREPAID_INT = "anInterimInt";
  public static final String FN_1ST_INT_ACCRUAL = "an1stIntAccD";
  public static final String FN_IS_INT_ONLY = "anIntOnlyC";
  public static final String FN_INT_ONLY_NUM_PMT = "anIntOnlyNumPmt";
  public static final String FN_INT_ONLY_END_DT = "anIntPmtEndDt";
  public static final String FN_INT_ONLY_PMT = "anIntPmt";
  public static final String FN_TRD_NAME = "anTrdName";
  public static final String FN_TRD_PMT = "anTrdPmt";
  public static final String FN_TRD_SEL = "anTrdSel";

  public static final String FN_CNST_1ST_PMT_DT = "anCnst1stPmtDt";
  public static final String FN_CNST_END_DT = "anCnstEndDt";
  public static final String FN_CNST_MAX_PMT = "anCnstMaxPmt";
  public static final String FN_CNST_MIN_PMT = "anCnstMinPmt";
  public static final String FN_PRM_CLCD_D = "anPrmClCdD";
  public static final String FN_RT_TYPE = "anRtTypD";
  public static final String FN_IDX = "anIdxD";
  public static final String FN_INDEX_NAME = "anIndexName";
  public static final String FN_OVER_DLR_RSV = "anOverDlrRsvC";
  public static final String FN_DLR_RSV_PTS = "anDlrRsvPts";
  public static final String FN_DLR_RSV = "anDlrRsv";
  public static final String FN_DLR_GRS_RSV = "anDlrGrRsv";
  public static final String FN_DLR_NET_RSV = "anDlrNetRsv";
  public static final String FN_DLR_RSV_PCT = "anDlrRsvPct";
  public static final String FN_DLR_RSV_FIN_AMT = "anDlrRsvFinAmt";
  public static final String FN_DLR_RSV_BASIS = "anDlrRsvBasis";
  public static final String FN_DLR_RSV_R = "anDlrRsvR";
  public static final String FN_DLR_FLAT_FEE = "anDlrFlatFee";
  public static final String FN_DLR_BUY_DOWN_C = "anDlrBuyDownC";
  public static final String FN_DLR_BUY_DOWN = "anDlrBuyDown";
  public static final String FN_DLR_RSV_ADJ = "anDlrRsvAdj";
  public static final String FN_DLR_REL_BONUS = "anDlrRelBonus";
  public static final String FN_DLR_TTL = "anDlrTtl";
  public static final String FN_DAILY_INT_INT = "anDailyIntInt";
  public static final String FN_BNK_NET_RSV = "anBnkNetRsv";
  public static final String FN_FIN_CI_PRM = "anFinCIPrm";
  public static final String FN_RPT_AMT = "anRptAmt";
  public static final String FN_TRD_BAL = "anTrdBal";
  public static final String FN_AAN_DT = "anAANdt";
  public static final String FN_NW_REQ = "anNwReq";
  public static final String FN_IS_1ST_TIME_HID = "anIs1stTimeHid";
  public static final String FN_BWR_SMY_L = "anBorrowerSmyL";
  public static final String FN_X_SELL_D = "anXSellD";
  public static final String FN_CL_TYPE_HID = "anClTypHid";
  public static final String FN_CL_HID = "anClHid";
  public static final String FN_CL_SMY_L = "anClSmyL";

  public static final String FN_AVG_DLY_BAL_PMT_PCT = "adbPmtPct";
  public static final String FN_AVG_DLY_BAL_PMT = "adbPmtAmt";
  public static final String FN_AVG_DLY_BAL_NUM_PMT = "adbNumPmt";
  public static final String FN_AVG_DLY_BAL_MIN_PMT = "adbMinPmt";
  public static final String FN_AVG_DLY_BAL_TABLE = "adbT";

  public static final String FN_PMT_END = "anPmtEndC";
  public static final String FN_PMT_IS_END = "anPmtIsEndC";
  public static final String FN_INT_PMT_END = "anIntPmtEndC";
  public static final String FN_INT_PMT_IS_END = "anIntPmtIsEndC";

  public static final String FN_CALC_DIS = "anDiscount";
  public static final String FN_INDEX_RATE = "anIndexRate";
  public static final String FN_RCSN_C = "anRcsnC";

  // loan amount fields
  //
  public static final String FN_AMT_REQ = "anAmtReq";
  public static final String FN_AMT_APPROVED = "anAmtApv";
  public static final String FN_AMT_MAXIMUM = "anAmtMax";
  public static final String FN_AMT_MINIMUM = "anAmtMin";
  public static final String FN_LOAN_AMT = "anLoanAmt";
  public static final String FN_TTL_FIN_AMT = "anTtlFinAmt";
  public static final String FN_DR_RQ_AMT = "drRqAmt";
  public static final String FN_AMT_OLD_REQ = "anOldReq";
  public static final String FN_FUND_REQ_TYPE = "anReqD";
  public static final String FN_FIN_CLOSING_COSTS_CHECK = "anFinCCC";
  public static final String FN_FIN_CLOSING_COSTS = "anFinCC";

  // indirect loan amount fields
  //
  public static final String FN_IND_CLIFE = "anIndCLife";
  public static final String FN_IND_WARR = "anIndWarr";
  public static final String FN_IND_OTHER = "anIndOth";

  public static final String FN_DOWN_PAYMENT = "anDwnPmt";
  public static final String FN_MULT_PURCHASE = "anClMultPurchC";

  // interest rate fields
  //
  public static final String FN_INT_RATE = "anIntRate";
  public static final String FN_BUY_RATE = "anBuyRate";
  public static final String FN_INT_RATE_MAX = "anIntRateMax";
  public static final String FN_INT_RATE_REQ = "anIntRateReq";
  public static final String FN_INT_RATE_R = "anIntRtR";
  public static final String FN_INT_RATE_D = "anIntRtD";
  public static final String FN_INT_RATE_LOCK_PRD = "anIntLockPrdD";
  public static final String FN_MARGIN = "anMargin";
  public static final String FN_SYS_BAL_XFER_RATE = "!balXferRt";

      // mortgage
  public static final String FN_INT_RATE_BASE = "anIntRateBase";
  public static final String FN_MARGIN_RT = "anMarginRt";
  public static final String FN_INT_RATE_QUAL = "anIntRateQual";

  // term fields
  //
  public static final String FN_TERM_APV = "anTermApv";
  public static final String FN_TERM_MAX = "anTermMax";
  public static final String FN_TERM_REQ = "anTermReq";

  // dates
  //
  public static final String FN_DISBURSE_DATE = "anDisbDt";
  public static final String FN_LOAN_DT = "anLoanDt";
  public static final String FN_DUE_DT = "anDueDt";
  public static final String FN_1ST_INT_PMT_DT = "anInt1stPmtDt";
  public static final String FN_1ST_PMT_DT = "an1stPmtDt";
  public static final String FN_RECISSION_DT = "anRcsnDt";
  public static final String FN_INTERIM_END_DT = "anInterimEndDt";
  public static final String FN_INT_LOCK_DT = "anIntLockDt";
  public static final String FN_INT_LOCK_DT_RE = "reIntLockDt"; // used on Real Estate Vista

  // 7-24-09, ccl
  //
  public static final String FN_INT_LOCK_TM = "anIntLockTm";
  public static final String FN_INT_LOCK_EXP_DT = "anIntLockExpDt";
  //public static final String FN_INT_RT_R = "anIntRtR";
  public static final String FN_INT_LOCK_USER = "anIntLockUser";

  // 12-16-09, ccl
  //
  public static final String FN_INT_LOCK_AT_DT = "anIntLockAtDt";
  public static final String FN_INT_LOCK_AT_TM = "anIntLockAtTm";

  // Irregular Payments
  //
  public static final String FN_IRR_NUM_PMT = "irrNumPmt";
  public static final String FN_IRR_PMT_PERIOD = "irrPmtPrdD";
  public static final String FN_IRR_PMT_DT = "irr1stPmtDt";
  public static final String FN_IRR_PMT = "irrPmt";
  public static final String FN_IRR_PMT_TYPE = "irrPrnIntD";
  public static final String FN_IRR_REMAIN_BAL = "anRemainBal";
  public static final String FN_IRR_PMT_SMY = "anIrrPmtSmyL";

  // Application: -Cross Sell Product
  //
  public static final String FN_XSELL_PROD_TT = "xsPrdT";
  public static final String FN_XSELL_DCSN_PTY = "xsDcsnParty";

  // payment : credit insurance fields
  //
  public static final String FN_CINS_WARNINGS = "anCInsWarnM";
  public static final String FN_CINS_CASH = "anInsPrmPdCshC";
  public static final String FN_CINS_D = "anCLifeInsD";
  public static final String FN_CINS_TYPE = "anCLifeInsTypD";
  public static final String FN_CINS_LIFE_PREMIUM = "anCLifeInsPrm";
  public static final String FN_CINS_AGE = "anCLifeAge";
  public static final String FN_CINS_CVRD_ONE = "anBwrCvrdD";
  public static final String FN_CINS_CVRD_TWO = "anCoCvrdD";
  public static final String FN_CINS_SPLIT = "anInsSplitC";

  // Accident & Health.
  //
  public static final String FN_CINS_AH_D = "anAHInsD";
  public static final String FN_CINS_AH_TYPE = "anAHInsTypD";
  public static final String FN_CINS_AH_PREMIUM = "anAHInsPrm";

  // Decreasing Credit Life Insurance
  //
  public static final String FN_CINS_D_END_DT = "anCLifeInsDEndDt";
  public static final String FN_CINS_D_PRM = "anCLifeInsDPrm";
  public static final String FN_CINS_D_RT = "anCLifeInsDRt";
  public static final String FN_CINS_D_TERM = "anCLifeInsDTrm";
  public static final String FN_CINS_D_COST = "anCLifeInsDCst";
  public static final String FN_CINS_D_PMT = "anCLifeInsDPmt";
  public static final String FN_CINS_D_AMT = "anCLifeInsDAmt";

  // Level Credit Life Insurance.
  //
  public static final String FN_CINS_L_END_DT = "anCLifeInsLEndDt";
  public static final String FN_CINS_L_PRM = "anCLifeInsLPrm";
  public static final String FN_CINS_L_RT = "anCLifeInsLRt";
  public static final String FN_CINS_L_TERM = "anCLifeInsLTrm";
  public static final String FN_CINS_L_COST = "anCLifeInsLCst";
  public static final String FN_CINS_L_PMT = "anCLifeInsLPmt";
  public static final String FN_CINS_L_AMT = "anCLifeInsLAmt";

  // Accident & Health.
  //
  public static final String FN_CINS_AH_END_DT = "anAHInsEndDt";
  public static final String FN_CINS_AH_PRM = "anAHInsPrm";
  public static final String FN_CINS_AH_RT = "anAHInsRt";
  public static final String FN_CINS_AH_TERM = "anAHInsTrm";
  public static final String FN_CINS_AH_PMT = "anAHInsPmt";
  public static final String FN_CINS_AH_COST = "anAHInsCst";
  public static final String FN_CINS_AH_AMT = "anAHInsAmt";

  // Gap Insurance
  //
  public static final String FN_GI_SELECT_RADIO = "anGIR";
  public static final String FN_GI_COLL_LIST = "anGICollD";
  public static final String FN_GI_PREMIUM = "anGIAmt";
  public static final String FN_GI_FINANCED = "anGIFinC";

  // Warranty Insurance
  //
  public static final String FN_WR_SELECT_RADIO = "wrReqR";
  public static final String FN_WR_COLL_LIST = "wrCollD";
  public static final String FN_WR_PREMIUM = "wrCvgPrmTtl";
  public static final String FN_WR_FINANCED = "wrFinC";
  public static final String FN_WR_ELIG_PLAN = "wrCvgElgPlan";

  public static final String FN_PMI_FIN_PREMIUM = "anFinPMIFee";
  public static final String FN_PMI_TTL_PREMIUM = "!ttlMIPrm";
  public static final String FN_PMI_MAX_PREMIUM = "!maxMIPrm";
  public static final String FN_PMI_MIN_PREMIUM = "!minMIPrm";
  public static final String FN_PMI_WARN_DT = "anPMIWarnDt";
  public static final String FN_PMI_STOP_DT = "anPMIStopDt";

  public static final String FN_PMI_WORST_CASE_WARN_DT = "anPMIWCWarnDt";
  public static final String FN_PMI_WORST_CASE_STOP_DT = "anPMIWCStopDt";


  // Borrower fields
  //
  public static final String FN_BWR_POS_HID = "_bwrPOSHid";
  public static final String FN_SSN = "atSSN";
  public static final String FN_NAME_SALUTE = "atSalD";
  public static final String FN_BIRTH_DT = "atBirthDt";
  public static final String FN_AGE = "atAge";
  public static final String FN_F_NAME = "atFName";
  public static final String FN_M_INIT = "atMInitial";
  public static final String FN_M_NAME = "atMName";
  public static final String FN_L_NAME = "atLName";
  public static final String FN_NAME_SFX = "atSuffixD";
  public static final String FN_CUST_ID = "atCustId";
  public static final String FN_PRIM_CUST_ID = "anPrimCustId";
  public static final String FN_SPOUSE = "atSpouseC";
  public static final String FN_BWR_TYPE = "atBwrTypD";
  public static final String FN_OUR_EMP = "atOurEmpD";
  public static final String FN_RES_STATUS = "atResStatD";
  public static final String FN_CRDTR_HOUSE = "atCrdtrHouse";
  public static final String FN_CRDTR_HOUSE_PMT = "atCrdtrHousePmt";
  public static final String FN_CRDTR_HOUSE_BAL = "atCrdtrHouseBal";
  public static final String FN_PRV_ADDR_INFO = "atPrvAddrVsC";  // 10-10-08, ccl
  public static final String FN_PRV_EMP_INFO = "atPrvEmpVsC";
  public static final String FN_BWR_ADDR_TYPE = "atAddrTypR";
  public static final String FN_BWR_STR_NUM = "atStrNum";
  public static final String FN_BWR_STR_PRE_DIR = "atStrPreDirD";
  public static final String FN_BWR_STR_NAME = "atStrName";
  public static final String FN_BWR_STR_POST_DIR = "atStrPostDirD";
  public static final String FN_BWR_STR_SFX = "atStrSuffixD";
  public static final String FN_BWR_SEC_ADDR_TYPE = "atSecAddrTypeD";
  public static final String FN_BWR_SEC_ADDR_RGE = "atSecAddrRge";
  public static final String FN_BWR_RT_TYPE = "atRtType";
  public static final String FN_BWR_RT_NUM = "atRtNum";
  public static final String FN_BWR_BOX_NUM = "atBxNum";
  public static final String FN_BWR_PO_BOX = "atPOBox";
  public static final String FN_BWR_ADDR_TWO = "atAddrTwo";
  public static final String FN_BWR_CITY = "atCity";
  public static final String FN_BWR_STATE = "atStD";
  public static final String FN_BWR_ZIP = "atZip";
  public static final String FN_BWR_ZIP_PLUS = "atZipPlus";
  public static final String FN_BWR_FRGN_ADDR = "atFrgnAddrC";
  public static final String FN_BWR_PROVINCE = "atProv";
  public static final String FN_BWR_COUNTRY = "atCntry";
  public static final String FN_BWR_POSTAL_CODE = "atPstlCd";
  public static final String FN_BWR_COUNTY = "atCntyD";
  public static final String FN_BWR_PCT_ONR = "atPctOnr";
  public static final String FN_BWR_OP_REL = "atOPRelD";
  public static final String FN_BWR_DR_OTH_SEC = "atDROthSec";
  public static final String FN_BWR_OP_REL_TYPE = "atOPRelTypD";
  public static final String FN_BWR_DR_RE_SEC = "atDRRESec";
  public static final String FN_BWR_DR_CASH_SEC = "atDRCashSec";
  public static final String FN_BWR_DR_UNSEC = "atDRUnSec";
  public static final String FN_BWR_RSK_SCORE = "atRskScore";
  public static final String FN_BWR_BNK_SCORE = "atBnkScore";
  public static final String FN_BWR_LNAME_INIT = "atLNameInit";
  public static final String FN_BWR_TTL_AST = "atTtlAst";
  public static final String FN_BWR_TTL_LI = "atTtlLi";
  public static final String FN_BWR_NT_WRTH = "atNtWrth";
  public static final String FN_BWR_AST_PLG = "atAstPlg";
  public static final String FN_BWR_AST_UNPLG = "atAstUnplg";
  public static final String FN_BWR_LI_SEC = "atLiSec";
  public static final String FN_BWR_LI_UNSEC = "atLiUnsec";
  public static final String FN_BWR_SALARY = "atSalary";
  public static final String FN_BWR_SALARY_PRD = "atSalaryPrdD";
  public static final String FN_BWR_OT_BONUS = "atOTBonus";
  public static final String FN_BWR_OT_BONUS_PRD = "atOTBonusPrdD";
  public static final String FN_BWR_BONUS = "atBonus";
  public static final String FN_BWR_BONUS_PRD = "atBonusPrdD";
  public static final String FN_BWR_OVR_TM = "atOvrTm";
  public static final String FN_BWR_OVR_TM_PRD = "atOvrTmPrdD";
  public static final String FN_BWR_COMM = "atComm";
  public static final String FN_BWR_COMM_PRD = "atCommPrdD";
  public static final String FN_BWR_OTH_INC = "atOthInc";
  public static final String FN_BWR_OTH_INC_PRD = "atOthIncPrdD";
  public static final String FN_BWR_OTH_2_INC = "atOth2Inc";
  public static final String FN_BWR_OTH_2_INC_PRD = "atOth2IncPrdD";
  public static final String FN_BWR_OTH_3_INC = "atOth3Inc";
  public static final String FN_BWR_OTH_3_INC_PRD = "atOth3IncPrdD";
  public static final String FN_BWR_OTH_4_INC = "atOth4Inc";
  public static final String FN_BWR_OTH_4_INC_PRD = "atOth4IncPrdD";
  public static final String FN_BWR_DIV_INT = "atDivInt";
  public static final String FN_BWR_DIV_INT_PRD = "atDivIntPrdD";
  public static final String FN_BWR_NT_RNTL_INC = "atNtRntlInc";
  public static final String FN_BWR_NT_RNTL_INC_PRD = "atNtRntlIncPrdD";
  public static final String FN_BWR_SUB_PROP_INC = "atSubPropCash";
  public static final String FN_BWR_SUB_PROP_INC_PRD = "atSubPropCashPrdD";
  public static final String FN_BWR_CRDTR_TYPE = "atCrdtrType";
  public static final String FN_BWR_GUAR_C = "atGuarC";
  public static final String FN_BWR_RISK_TIER = "!riskTier";

  public static final String FN_BWR_SAME_AS_MAIL = "atMailSameAsAddrC";
  public static final String FN_BWR_MAIL_ADDR = "atMailAddr";
  public static final String FN_BWR_MAIL_ADDR_TWO = "atMailAddrTwo";
  public static final String FN_BWR_MAIL_CITY = "atMailCity";
  public static final String FN_BWR_MAIL_STATE = "atMailStD";
  public static final String FN_BWR_MAIL_ZIP = "atMailZip";
  public static final String FN_BWR_MAIL_ZIP_PLUS = "atMailZipPlus";
  public static final String FN_BWR_MAIL_FRGN_ADDR = "atMailFrgnAddrC";
  public static final String FN_BWR_MAIL_PROVINCE = "atMailProv";
  public static final String FN_BWR_MAIL_COUNTRY = "atMailCntry";
  public static final String FN_BWR_MAIL_POSTAL_CODE = "atMailPstlCd";

  public static final String FN_BWR_HAS_CHECKING = "atCheckC";
  public static final String FN_BWR_HAS_OUR_CHECK = "atOurCheckC";
  public static final String FN_BWR_CHECK_INST_ACCT = "atCheckInstName";
  public static final String FN_CRDTR_NAME = "atCrdtrName";
  public static final String FN_CRDTR_PMT = "atCrdtrPmt";
  public static final String FN_CRDTR_BAL = "atCrdtrBal";
  public static final String FN_CRDTR_SEL = "atCrdtrSel";
  public static final String FN_CRDTR_PAYOFF = "atCrdtrPayOff";
  public static final String FN_BWR_CIF = "_atCIF";
  public static final String FN_BWR_NT_WRTH_T = "atNtWrthT";
  public static final String FN_JOINT_BWR_NT_WRTH_D = "atNtWrthJtD";

  // 5-29-09, ccl
  // total income
  //
  public static final String FN_BWR_TTL_SALARY = "atSalaryTtl";
  public static final String FN_BWR_TTL_BONUS = "atBonusTtl";
  public static final String FN_BWR_TTL_DIV_INT = "atDivIntTtl";
  public static final String FN_BWR_TTL_RENT_INC = "atNtRntlIncTtl";
  public static final String FN_BWR_TTL_OVER_TIME = "atOvrTmTtl";
  public static final String FN_BWR_TTL_COMM = "atCommTtl";
  public static final String FN_BWR_TTL_OTHER_INCOME = "atOthIncTtl";
  public static final String FN_BWR_TTL_INCOME = "atIncTtl";
  public static final String FN_BWR_TTL_ADD_INCOME = "atAddIncTtl";  // dummy field

  // 9-8-09, ccl
  // HMDA_borrower_information
  //
  public static final String FN_BWR_HMDA_GENDER = "atGdrD";
  public static final String FN_BWR_HMDA_ETHNICITY = "atEthD";
  public static final String FN_BWR_HMDA_RACE = "atRcD";
  public static final String FN_BWR_HMDA_RACE2 = "atRc2D";
  public static final String FN_BWR_HMDA_RACE3 = "atRc3D";
  public static final String FN_BWR_HMDA_RACE4 = "atRc4D";
  public static final String FN_BWR_HMDA_RACE5 = "atRc5D";
  //public static final String FN_BWR_HMDA_C = "atDoesNoHMDAC";    // 5-6-2010, ccl typo
  public static final String FN_BWR_HMDA_C = "atDoesNotHMDAC";

  // collateral
  //
  public static final String FN_COLLATERAL_ID = "clId";
  public static final String FN_COLLATERAL_DESC = "clDesc";
  public static final String FN_COLLATERAL_SECURED = "clsecC";
  public static final String FN_SFX_BOOK_ENTRY = "BookC";
  public static final String FN_SFX_PAY_DEATH = "PODC";
  public static final String FN_SFX_MINOR = "MinorC";
  public static final String FN_SFX_MULT_SIGN = "AddlSigntrC";
  public static final String FN_SFX_HOLDER_RADIO = "HeldR";
  public static final String FN_CD_MATURITY = "clCDLMatureDt";
  public static final String FN_CD_IRA = "clCDiraC";
  public static final String FN_LIFE_INS_IRA = "clLIIRAC";
  public static final String FN_ANN_QUAL_RADIO = "clAnQualR";
  public static final String FN_LOAN_PUR_SELECTION = "anLoanPurCdD";
  public static final String FN_AUTO_EVAL_TYPE = "clVhEvalTypR";
  public static final String FN_AUTO_EVAL_TYPE_D = "clVhEvalTypD";
  public static final String FN_AUTO_MAN_VAL = "clVhVal";
  public static final String FN_AUTO_KBB_VAL = "clVhTtlVal";
  public static final String FN_AUTO_PURCH = "clVhPrchMnyC";
  public static final String FN_DEBT_RECAP_APPLIC = "drApplcbR";
  public static final String FN_SALES_TAX = "clPDTxRt";
  public static final String FN_PD_DOWN_PAYMENT = "clPDDnPmt";
  public static final String FN_COLLATERAL_LOC_ST = "clLocStD";
  public static final String FN_COLLATERAL_LOC_CNTY = "clLocCntyD";
  public static final String FN_CL_CK_ACCRL_RATE = "clCkAccrlRate";
  public static final String FN_CL_SV_ACCRL_RATE = "clSvAccrlRate";
  public static final String FN_CL_CDL_ACCRL_RATE = "clCDLAccrlRate";
  public static final String FN_CL_MHSL_PRC = "clMHSlPrc";
  public static final String FN_CL_MH_VAL = "clMHVal";

  public static final String FN_PHY_STRNAME = "phyStrName";
  public static final String FN_PHY_ADDR_TWO = "phyAddrTwo";
  public static final String FN_PHY_CITY = "phyCity";
  public static final String FN_PHY_STATE = "phyStD";
  public static final String FN_PHY_ZIP = "phyZip";
  public static final String FN_PHY_ZIP_PLUS = "phyZipPlus";
  public static final String FN_PHY_STRNUM = "phyStrNum";
  public static final String FN_PHY_RES_STAT = "phyResStatD";
  public static final String FN_PHY_FRGN_ADDR = "phyFrgnAddrC";
  public static final String FN_PHY_PROVINCE = "phyProv";
  public static final String FN_PHY_COUNTRY = "phyCntry";
  public static final String FN_PHY_POSTAL_CODE = "phyPstlCd";
  public static final String FN_PHY_COUNTY = "phyCntyD";
  public static final String FN_PHY_MSA = "phyMSA";
  public static final String FN_PHY_CENSUS = "phyCensusTr";
  public static final String FN_PHY_FIPS_CNTY = "phyFIPSCntyCd";
  public static final String FN_PHY_FIPS_STATE = "phyFIPSStCd";
  public static final String FN_PHY_STR_PRE_DIR = "phyStrPreDirD";
  public static final String FN_PHY_STR_POST_DIR = "phyStrPostDirD";
  public static final String FN_PHY_STR_SUFFIX = "phyStrSuffixD";
  public static final String FN_PHY_SEC_ADD_RANGE = "phySecAddrRge";
  public static final String FN_PHY_SEC_ADD_TYPE = "phySecAddrTypeD";
  public static final String FN_PHY_ADDR = "phyAddr";
  public static final String FN_PHY_PRP_TYPE = "phyPrpTypD";
  public static final String FN_PHY_APRSL_VAL = "phyAprslVal";
  public static final String FN_PHY_EST_VAL = "phyEstVal";
  public static final String FN_PHY_PRCH_PRC = "phyPrchPrc";

  public static final String FN_COLLATERAL_SMY = "anClSmyL";

  // ISSUE # 596 - First change(10-1) Now add(10-3)
  // public static final String FN_DC_COLLATERAL_SMY = "dcClSmyL";
  //
  public static final String FN_DC_COLLATERAL_SMY = "dcClSmyL";
  public static final String FN_DC_COLLATERAL_SMY_TBL = "dcClSmyT";

  public static final String FN_COLLATERAL_TYPE = "clsTypD";
  public static final String FN_NEW_USED = "clNwUsdD";
  public static final String FN_COLLATERAL_HIDE = "anClSmyVisC";

  // application:collateral.0:Automobile.0:clVhYrD = 2007
  // application:collateral.0:Automobile.0:clVhMkD = Honda
  // application:collateral.0:Automobile.0:clVhMdlD = Accord
  // application:collateral.0:Automobile.0:clVhVIN = 1234123asdw12312
  // application:collateral.0:Automobile.0:clVhTrimD = Sport
  // application:collateral.0:Automobile.0:clVhTtlVal = 0
  // application:collateral.0:Automobile.0:clVhMi = 0
  //
  public static final String FN_CL_VH_MODEL_YR = "clVhYrD";
  public static final String FN_CL_VH_MAKE = "clVhMkD";
  public static final String FN_CL_VH_MODEL = "clVhMdlD";
  public static final String FN_CL_VH_VIN = "clVhVIN";
  public static final String FN_CL_VH_TRIM_PKG = "clVhTrimD";
  public static final String FN_CL_VH_TTL_VAL = "clVhTtlVal";
  public static final String FN_CL_VH_MILEAGE = "clVhMi";
  public static final String FN_CL_OCCUP_TYPE = "phyOccTypD";


  // owners
  //
  public static final String FN_OWNER_TYPE = "OnrIsR";
  public static final String FN_ONR_F_NAME = "OnrFName";
  public static final String FN_ONR_M_NAME = "OnrMName";
  public static final String FN_ONR_L_NAME = "OnrLName";
  public static final String FN_ONR_ADDR = "OnrAddr";
  public static final String FN_ONR_ADDR_TWO = "OnrAddrTwo";
  public static final String FN_ONR_CITY = "OnrCity";
  public static final String FN_ONR_STATE = "OnrStateD";
  public static final String FN_ONR_ZIP = "OnrZip";
  public static final String FN_ONR_ZIP_PLUS = "OnrZipPlus";
  public static final String FN_ONR_FRGN_ADDR = "OnrFrgnAddrC";
  public static final String FN_ONR_PROVINCE = "OnrProv";
  public static final String FN_ONR_COUNTRY = "OnrCntry";
  public static final String FN_ONR_POSTAL_CODE = "OnrPstlCd";
  public static final String FN_ONR_SMY_L = "OnrSmyL";
  public static final String FN_ONR_BWR_POS_HID = "_onrBwrPOSHid";
  public static final String FN_ONR_IS_R = "OnrIsR";
  public static final String FN_ONR_BWR_R = "OnrBwrL";
  public static final String FN_ONR_SSN = "OnrSSN";
  public static final String FN_ONR_SUFFIX_D = "OnrSuffixD";
  public static final String FN_ONR_ENT_TYPE_D = "OnrEntTypD";
  public static final String FN_ONR_CIF = "OnrCIF";

  public static final String FN_ONR_MAIL_FRGN_ADDR = "OnrMailFrgnAddrC";
  public static final String FN_ONR_MAIL_PROVINCE = "OnrMailProv";
  public static final String FN_ONR_MAIL_COUNTRY = "OnrMailCntry";
  public static final String FN_ONR_MAIL_POSTAL_CODE = "OnrMailPstlCd";
  public static final String FN_ONR_OVER_C = "OnrOverC";
  public static final String FN_ONR_BIRTH_DT = "OnrBirthDt";

  // liens
  //
  public static final String FN_LIEN_DEF_PROP = "!lnDefPrp";
  public static final String FN_LIEN_BALANCE = "lnBal";
  public static final String FN_LIEN_ORIG_DT = "lnOrigDt";
  public static final String FN_LIEN_REFINANCING = "lnRefiR";
  public static final String FN_LIEN_REFI_TYPE = "lnRefiTypR";
  public static final String FN_LIEN_ORIG_PURPOSE = "lnOrigPurR";
  public static final String FN_LIEN_NOT_HI_PURCH_AMT = "lnNotHIPrchAmt";
  public static final String FN_LIEN_POSITION = "lnPosD";
  public static final String FN_LIEN_HOLDER = "lnPrior";
  public static final String FN_LIEN_PAYMENT = "lnPmt";
  public static final String FN_LIEN_ORIG_AMT = "lnOrigAmt";
  public static final String FN_LIEN_TOTAL_AMT = "lnTtlAmt";
  public static final String FN_LIEN_TYPE = "lnTypD";
  public static final String FN_LIEN_PAYMENT_PRD = "lnPmtPrdD";
  public static final String FN_LIEN_ADDRESS = "lnAddr";
  public static final String FN_LIEN_CITY = "lnCity";
  public static final String FN_LIEN_ST = "lnStD";
  public static final String FN_LIEN_ZIP = "lnZip";
  public static final String FN_LIEN_SMY_L = "lnSmyL";
  public static final String FN_LIEN_COUNT = "_lienCount";
  public static final String FN_LIEN_ACCT_NO = "lnAcctNo";

  // disbursements
  //
  public static final String FN_DSB_FEE_TIE = "_dsbFeeTie";
  public static final String FN_DSB_AMT = "dsbAmt";
  public static final String FN_DSB_RN_DT = "dsbLnRNDt";
  public static final String FN_DSB_TTL = "andsbTtl";
  public static final String FN_DSB_NON_LOAN = "andsbNoLn";
  public static final String FN_DSB_REMAIN = "andsbRmn";
  public static final String FN_DSB_TYPE = "dsbType";
  public static final String FN_DSB_TYPE_RADIO = "dsbTypR";
  public static final String FN_DSB_TYPE_DDL = "dsbTypD";
  public static final String FN_DSB_PYOFF_TYPE = "dsbPyOffTypD";
  public static final String FN_DSB_SUBCODE_DDL = "dsbSubCdD";
  public static final String FN_DSB_DESC = "dsbDesc";
  public static final String FN_DSB_NAME = "dsbName";
  public static final String FN_DSB_DELIVERY_DT = "dsbDlDt";
  public static final String FN_DSB_DELIVERY_TIME = "dsbDlH";
  public static final String FN_DSB_DELIVERY_DATETIME = "dsbDlP";
  public static final String FN_DSB_UNSEC = "andsbRefAmt";

  // fees
  //
  public static final String FN_FEE_APR = "anFeeAPRC";
  public static final String FN_FEE_HOEPA = "anFeeHOEPAC";
  public static final String FN_FEE_PREPAID = "anFeePrepaidC";
  public static final String FN_FEE_PCT = "anFeePct";
  public static final String FN_FEE_FIN = "anFeeFinC";
  public static final String FN_FEE_TYPE = "anFeeType";
  public static final String FN_FEE_AMT = "anFeeAct";
  public static final String FN_FEE_DESC = "anFeeDesc";
  public static final String FN_FEE_CODE = "anFeeCode";
  public static final String FN_FEE_BENE = "anFeeBene";
  public static final String FN_FEE_BENE_D = "anFeeBeneD";
  public static final String FN_FEE_FILE = "anFeeFileC";
  public static final String FN_APR = "anAPR";
  public static final String FN_FEE_FIN_TTL = "anFeeTtlFin";
  public static final String FN_FEE_POC_TTL = "anFeeTtlPOC";
  public static final String FN_MTG_PREPAID_FEE_ITEMS = "anFeePrepaidItems";
  public static final String FN_FINANCE_CHARGE = "anFinChg";
  public static final String FN_UGI_TERM = "anUGITrm";
  public static final String FN_FEE_OVERRIDE = "anFeeOverC";
  public static final String FN_FEE_AMT_ORIG = "anFeeAmtOrig";
  public static final String FN_FEE_STATE = "anFeeSt";
  public static final String FN_FEE_COUNTY = "anFeeCnty";
  public static final String FN_FEE_ID = "anFeeId";
  public static final String FN_FEE_ACT_BASIS = "anFeeActBasisR";
  public static final String FN_FEE_TBL_ID = "anFeeTblD";
  public static final String FN_FEE_BASIS = "anFeeBasisR";
  public static final String FN_FEE_PCT_TYPE = "anFeePctTypD";
  public static final String FN_FEE_MIN_PCT_PMT = "anFeePctTypMin";
  public static final String FN_FEE_PCT_OFFSET = "anFeePctTypOffset";
  public static final String FN_FEE_CALC_TYPE = "anFeeCalcTypD";
  public static final String FN_FEE_CAT = "anFeeCat";
  public static final String FN_FEE_PMT_MTH = "anFeePmtMthD";
  public static final String FN_FEE_LOC_BASIS = "anFeeLocBasisR";
  public static final String FN_FEE_LOC_ID = "anFeeLocId";
  public static final String FN_FEE_SUB_CODE = "anFeeSubCode";
  public static final String FN_FEE_INC = "anFeeInc";
  public static final String FN_FEE_XREF = "anFeeXRef";
  public static final String FN_FEE_FASBC = "anFeeFASBC";
  public static final String FN_FEE_PAID_BY = "anFeePaidByD";
  public static final String FN_FEE_CREATE_DT = "anFeeDtCreated";
  public static final String FN_FEE_MODIFIED_DT = "anFeeDtModified";
  public static final String FN_FEE_MODIFIED_BY = "anFeeModifiedBy";
  public static final String FN_FEE_REF = "anFeeRefC";
  public static final String FN_FEE_EST = "anFeeEst";
  public static final String FN_FEE_LOW_EST = "anFeeLowEst";
  public static final String FN_FEE_HIGH_EST = "anFeeHighEst";
  public static final String FN_FEE_EST_BASIS = "anFeeEstBasisR";
  public static final String FN_FEE_SMYL = "feeSmyL";
  public static final String FN_FEE_SUB_ADV = "anFeeSubAdv";
  public static final String FN_FEE_SUB_ADV_LENDER = "anFeeSubAdvL";
  public static final String FN_FEE_SUB_ADV_BUYER = "anFeeSubAdvB";
  public static final String FN_FEE_SUB_ADV_SELLER = "anFeeSubAdvS";
  public static final String FN_FEE_AMT_LENDER = "anFeeLndrAmt";
  public static final String FN_FEE_AMT_SELLER = "anFeeSlrAmt";
  public static final String FN_FEE_AMT_BORROWER = "anFeeBwrAmt";
  public static final String FN_FEE_PCT_LENDER = "anFeeLndrPct";
  public static final String FN_FEE_PCT_SELLER = "anFeeSlrPct";
  public static final String FN_FEE_PCT_BORROWER = "anFeeBwrPct";
  public static final String FN_FEE_TOTAL_LENDER = "anFeeLndrTtl";
  public static final String FN_FEE_TOTAL_SELLER = "anFeeSlrTtl";
  public static final String FN_FEE_TOTAL_BUYER = "anFeeBwrTtl";
  public static final String FN_FEE_SPLIT_TYPE = "anFeeSplitR";
  public static final String FN_FEE_SPLIT_AMT = "anFeeSplitAmt";
  public static final String FN_FEE_SPLIT_PCT = "anFeeSplitPct";
  public static final String FN_FEES_UNALLOCATED = "anFeeUnallocTtl";
  public static final String FN_FEE_CASH_TTL = "anFeeTtlCash";
  //+HOEPA and HPML test
  public static final String FN_FEE_APR_TTL		= "anTotalApr";
  public static final String FN_FEE_HOEPA_TTL	= "anTotalHOEPA";
  public static final String FN_FEE_QUALM		= "feeQualMortC";
  public static final String FN_AN_FEE_QUALM	= "anFeeQualMortC";
  public static final String FN_FEE_QUALM_TTL	= "anTotalQMFee";
  //-HOEPA and HPML test

  public static final String FN_FEES_PAID_BY_BORROWER = "anFeePaidByBwr";

  // trade fieldNames
  public static final String FN_TRADE_ACT_NO = "trActNo";
  public static final String FN_TRADE_IS_LIAB = "trLiabC";
  public static final String FN_TRADE_PURPOSE = "trPur";
  public static final String FN_TRADE_BALANCE = "trBal";
  public static final String FN_TRADE_SEC_TYPE = "trCollTyp";



  // CRA fieldNames
  //
  public static final String FN_CRA_OVERRIDE = "craOverC";
  public static final String FN_CRA_LOAN_AMT = "craLnAmt";
  public static final String FN_CRA_INCOME = "craInc";
  public static final String FN_CRA_APPLIC = "craAppC";
  public static final String FN_CRA_ACT_TKN = "craActTknD";
  public static final String FN_CRA_ACT_TKN_DT = "craActDt";

  // HMDA fieldNames
  //
  public static final String FN_HMDA_OVERRIDE = "hmOverC";
  public static final String FN_HMDA_LOAN_AMT = "hmRqAmt";
  public static final String FN_HMDA_INCOME = "hmAnnInc";
  public static final String FN_HMDA_ACT_TKN = "hmActTknD";
  public static final String FN_HMDA_ACT_TKN_DT = "hmActDt";
  public static final String FN_HMDA_APPLIC = "hmAppC";
  public static final String FN_HMDA_RCVD_DT = "hmAnRvDt";
  public static final String FN_HMDA_CO_GENDER = "hmCoatGdrD";
  public static final String FN_HMDA_CO_RACE = "hmCoatRcD";
  public static final String FN_HMDA_CO_ETHNICITY = "hmCoatEthD";
  public static final String FN_HMDA_RATE_SPREAD = "hmRtSprd";
  public static final String FN_HMDA_LIEN_STAT = "hmLienStatD";
  public static final String FN_HMDA_OCCUPANCY = "hmOwnOccD";
  public static final String FN_HMDA_HOEPA = "hmHOEPAD";
  public static final String FN_HMDA_REPORT_YEAR = "hmRptYr";
  public static final String FN_HMDA_GENDER = "hmAtGdrD";
  public static final String FN_HMDA_RACE = "hmAtRcD";
  public static final String FN_HMDA_ETHNICITY = "hmAtEthD";
  // 5-24-2010, ccl
  public static final String FN_HMDA_FURNISH_INFO_C = "hmAtC";
  public static final String FN_HMDA_CO_FURNISH_INFO_C = "hmCoatC";
  //+HOEPA and HPML test
  public static final String FN_COM_TR_APR			= "anComTrApr";
  public static final String FN_COM_TR_DATE			= "anComTrDt";
  public static final String FN_LIEN_POS			= "reLienPos";
  public static final String FN_AN_LIEN_POS			= "anLienPosD";
  public static final String FN_HOEPA_RATE_THRESH	= "anHOEPARateThreshold";
  public static final String FN_HOEPA_FEE_THRESH	= "anHOEPAFeeThreshold";
  public static final String FN_HOEPA_RATE_EXC		= "anHOEPARateExcessD";
  public static final String FN_HOEPA_FEE_EXC		= "anHOEPAFeeExcessD";
  public static final String FN_HPML_RATE_THRESH	= "anHPMLRateThreshold";
  public static final String FN_LOAN_SIZE_DETER		= "anLoanSizeDeterD";
  public static final String FN_LOAN_SIZE_CON_LMT	= "anLoanSizeConLmt";
  public static final String FN_HPML_RATE_EXC		= "anHPMLRateExcessD";
  public static final String FN_HMDA_RATE_THRESH	= "anHMDARateThreshold";
  public static final String FN_HMDA_RATE_EXC		= "anHMDARateExcessD";
  public static final String FN_REC_OVER			= "anRecOverC";
  public static final String FN_OVER_HPML_USER		= "anOverHPMLUser";
  public static final String FN_NONBONAFIDE_DISC	= "anNonBonafideDiscount";
  public static final String FN_QM_LOAN_AMT			= "anQMLoanAmt";
  public static final String FN_QM_PTS_FEES_CAP		= "anQMPtsFeesCap";
  public static final String FN_QM_PTS_FEES_TOT		= "anQMPtsFeesTot";
  public static final String FN_QM_PTS_FEES_EXC		= "anQMPtsFeesExcessD";
  public static final String FN_QM_PTS_FEES_T		= "retQMPtsFeesT";
  public static final String FN_MAN_VAL				= "anManValC";
  public static final String FN_MAN_VAL_USER		= "anManValUser";
  //-HOEPA and HPML test


  // standard
  //
  public static final String TRUE_STRING = "true";
  public static final String FALSE_STRING = "false";

  // system
  //
  public static final String SYS_CUSTOMER = "Customer";
  public static final String SYS_CALCULATION = "Calculation";
  public static final String SYS_CALC_CUNA_DAY_DUE = "CUNADueDay";
  public static final String SYS_DEF_PMT_DAYS = "default_payment_days";
  public static final String SYS_INCLUDE_MI = "include_MI";
  public static final String SYS_DATA_MEMBER_HOST_ACCT_TYPES = "bkHostAcctTypes";
  public static final String SYS_DATA_MEMBER_HOST_SUB_ACCT_TYPES = "bkHostSubAcctTypes";

  // credit bureau
  //
  // cbCCC	        Has credit card
  // cbOurCCC	        Has credit card with our institution
  // cbMtgC		Has mortgage
  // cbOurMtgC	        Has mortgage with our institution
  //
  public static final String FN_CB_TR_BAL = "cbTrBal";
  public static final String FN_CBC_REV_BRDN = "cbc_rev_bals_total_inc_eq";
  public static final String FN_CB_HAS_CC = "cbCCC";
  public static final String FN_CB_HAS_OUR_CC = "cbOurCCC";
  public static final String FN_CB_HAS_MORG = "cbMtgC";
  public static final String FN_CB_HAS_OUR_MORG = "cbOurMtgC";
  public static final String FN_CB_TR_ACT_TYPE = "cbTrActTyp";
  public static final String FN_CB_TR_PMT = "cbTrPmt";
  public static final String FN_CB_WRN_L = "cbWrnL";
  public static final String FN_CB_PULL_DT = "cbPullDt";
  public static final String FN_CB_RPT_DT = "cbRptDt";
  public static final String FN_CB_AB_RPT_C = "cbAbRptC";
  public static final String FN_CB_NO_REC_FD_C = "cbNoRecFdC";
  public static final String FN_CB_BUREAU_USED = "cb_bureau_used";
  public static final String FN_CB_AT_REPORT_L = "cbAtReportL";
  public static final String FN_CB_TR_CRDT = "cbTrCrdt";
  public static final String FN_CB_TR_PAYOFF = "cbTrPayoff";
  public static final String FN_CB_TR_ACT_NO = "cbTrActNo";
  public static final String FN_CB_TR_LST_ACT_DT = "cbTrLstActDt";
  public static final String FN_CB_TR_CRD_LIM = "cbTrCrLim";
  public static final String FN_CB_TR_IND_IND = "cbTrIndInd";
  public static final String FN_CB_TR_EST_PMT_C = "cbTrPmtEstC";
  public static final String FN_CB_TR_XSELL_OFFER_ID = "!xsellID";
  public static final String FN_CB_AT_SCORE_L = "cbAtScoreL";

  public static final String FN_CBC_NO_INQ = "cbcNoInq";
  public static final String FN_CBC_NO_INQ_X7D = "cbcNoInqX7d";
  public static final String FN_CBC_NO_RV_WBAL = "cbcNoRvWBal";
  public static final String FN_CBC_TL_CRD_AVL_RV_RT = "cbcTlCrdAvlRvRt";
  public static final String FN_CBC_NT_DSP_DBT_RT = "cbcNtDspDbtRt";
  public static final String FN_CBC_NT_DSP_INC = "cbcNtDspInc";
  public static final String FN_CBC_PCT_CRD_AVL_RV = "cbcPctCrdAvlRv";
  public static final String FN_CBC_TL_CRD_AVL_RV = "cbcTlCrdAvlRv";

  public static final String FN_BWR_SCORE_SUMMARY = "anScSmyT";
  public static final String FN_BWR_DEBT_SUMMARY = "anDISmyT";

  public static final String FN_VF_SMYL = "vfSmyL";

  // SMALL BUSINESS FIELDS
  //
  // application information
  //
  public static final String FN_SBPRODUCT_ID = "anSBProdTypeD";
  public static final String FN_PRN_CB = "anPrnCBD";
  public static final String FN_BUS_CB = "anBusCBD";

  // business infomtion
  //
  public static final String FN_BUS_ADDR_TYPE = "beAddrTypR";
  public static final String FN_BUS_STR_NUM = "beStrNum";
  public static final String FN_BUS_STR_PRE_DIR = "beStrPreDirD";
  public static final String FN_BUS_STR_NAME = "beStrName";
  public static final String FN_BUS_STR_POST_DIR = "beStrPostDirD";
  public static final String FN_BUS_STR_SFX = "beStrSuffixD";
  public static final String FN_BUS_SEC_ADDR_TYPE = "beSecAddrTypeD";
  public static final String FN_BUS_SEC_ADDR_RGE = "beSecAddrRge";
  public static final String FN_BUS_RT_TYPE = "beRtType";
  public static final String FN_BUS_RT_NUM = "beRtNum";
  public static final String FN_BUS_BOX_NUM = "beBxNum";
  public static final String FN_BUS_PO_BOX = "bePOBox";
  public static final String FN_BUS_ADDR_TWO = "beAddrTwo";
  public static final String FN_BUS_CITY = "beCity";
  public static final String FN_BUS_STATE = "beStD";
  public static final String FN_BUS_ZIP = "beZip";
  public static final String FN_BUS_ZIP_PLUS = "beZipPlus";
  public static final String FN_BUS_FRGN_ADDR = "beFrgnAddrC";
  public static final String FN_BUS_PROVINCE = "beProv";
  public static final String FN_BUS_COUNTRY = "beCntry";
  public static final String FN_BUS_POSTAL_CODE = "bePstlCd";
  public static final String FN_BUS_COUNTY = "beCntyD";

  public static final String FN_BUS_SAME_AS_MAIL = "beMailSameAsAddrC";
  public static final String FN_BUS_MAIL_ADDR = "beMailAddr";
  public static final String FN_BUS_MAIL_ADDR_TWO = "beMailAddrTwo";
  public static final String FN_BUS_MAIL_CITY = "beMailCity";
  public static final String FN_BUS_MAIL_STATE = "beMailStD";
  public static final String FN_BUS_MAIL_ZIP = "beMailZip";
  public static final String FN_BUS_MAIL_ZIP_PLUS = "beMailZipPlus";
  public static final String FN_BUS_MAIL_FRGN_ADDR = "beMailFrgnAddrC";
  public static final String FN_BUS_MAIL_PROVINCE = "beMailProv";
  public static final String FN_BUS_MAIL_COUNTRY = "beMailCntry";
  public static final String FN_BUS_MAIL_POSTAL_CODE = "beMailPstlCd";
  public static final String FN_BUS_TAX_ID = "beTxIDNum";
  public static final String FN_BUS_NAME = "beNmBus";
  public static final String FN_TIN = "beTxIDNum";
  public static final String FN_BUS_SSN_C = "beSSNC";
  public static final String FN_BUS_SSN = "beSSN";
  public static final String FN_SICD = "beSICD";
  public static final String FN_NAICSD = "beNAICSD";
  public static final String FN_BUS_CF_ADJ = "beCFAdj";
  public static final String FN_BUS_NT_INC = "beNtInc";
  public static final String FN_BUS_GAR = "beGAR";
  public static final String FN_BUS_CF_SALES = "beCFSales";
  public static final String FN_BUS_CF_NET_SALES = "beCFNtInc";
  public static final String FN_BUS_CF_DEPR = "beCFDepr";
  public static final String FN_BUS_CF_TTL = "beCFTtl";
  public static final String FN_BUS_CF_INT_ADJ = "beCFIntAdj";
  public static final String FN_BUS_CF_INT_PRD = "beCFIntPrd";
  public static final String FN_BUS_CF_INT_SALES = "beCFIntSales";
  public static final String FN_BUS_CF_INT_NET_INC = "beCFIntNtInc";
  public static final String FN_BUS_CF_INT_DEPR = "beCFIntDepr";
  public static final String FN_BUS_CF_INT_TTL = "beCFIntTtl";
  public static final String FN_BUS_CF_ANN_SALES = "beCFAnnSales";
  public static final String FN_BUS_CF_ANN_NET_SALES = "beCFAnnNtInc";
  public static final String FN_BUS_CF_ANN_DEPR = "beCFAnnDepr";
  public static final String FN_BUS_CF_ANN_ADJ = "beCFAnnAdj";
  public static final String FN_BUS_OBLG = "beOblgL";
  public static final String FN_BUS_DP_ACCT = "beDpAcctL";
  public static final String FN_BUS_DR_OTH_SEC = "beDROthSec";
  public static final String FN_BUS_DR_RE_SEC = "beDRRESec";
  public static final String FN_BUS_DR_CASH_SEC = "beDRCashSec";
  public static final String FN_BUS_DR_UNSEC = "beDRUnSec";
  public static final String FN_BUS_RT_TYPE_D = "beRtTypeD";
  public static final String FN_BUS_CF_ANN_TTL = "beCFAnnTtl";
  public static final String FN_BUS_ACTVTY = "beActvty";

  // Balance Sheet
  //
  public static final String FN_BUS_BAL_SH_ACT = "bfBSActD";
  public static final String FN_BUS_BAL_SH_PRD = "bfBSPrdDtD";
  public static final String FN_BUS_FISC_YR = "bfFiscalYr";
  public static final String FN_BUS_FIN_TERM = "bfTerm";
  public static final String FN_BUS_EX_DEPRC = "bfExDeprc";
  public static final String FN_BUS_NET_INC = "bfNtInc";
  public static final String FN_BUS_RV_GR_SALES = "bfRvGrSales";
  public static final String FN_BUS_LI_CUR_MTLTD = "bfLiCurMtLTD";
  public static final String FN_BUS_BAL_SH_T = "beBalShT";
  // 3-4-2010, ccl
  //
  public static final String FN_BUS_BAL_SH_BGN_DT = "bfBeginDt";
  public static final String FN_BUS_BAL_SH_END_DT = "bfEndDt";

  public static final String FN_PER_FISC_YR = "pfFiscalYr";

  // business node fields
  //
  public static final String FN_BUS_TIME_ONR_YR = "beTimeOnrYr";
  public static final String FN_BUS_TIME_ONR_MO = "beTimeOnrMo";
  public static final String FN_BUS_TTL_NUM_EMP = "beTlNumEmp";
  public static final String FN_BUS_ENTITY = "beEntyTypD";
  public static final String FN_BUS_ANNUAL_SLS = "beAnSales";

  // 8-10-04, ccl
  // field name is changed
  //public static final String FN_BUS_YR_ESTB        = "beStrtDt";
  public static final String FN_BUS_YR_ESTB = "beYrEst";
  public static final String FN_BUS_REPNUM_XPB = "beRepNum.XPB";
  public static final String FN_BUS_REPNUM_DNB = "beRepNum.DnB";
  public static final String FN_BUS_FISC_YR_END = "beFYE";

  // added by mrl for the miser interface 7-3-03, 12-22-03
  //
  public static final String FN_CUST_NUM = "atCIF";
  public static final String FN_EMP_PH = "atEmpPh";
  public static final String FN_EMP_PH_EXT = "atEmpPhExt";
  public static final String FN_HOME_PH = "atPh";
  public static final String FN_MARITAL_STATUS = "atMaritalD";
  public static final String FN_EMAIL = "atEmail";
  public static final String FN_HOUSEHOLD_NUM = "atNumHousehold";
  public static final String FN_MAIDEN_NAME = "atMthrMdnNm";
  public static final String FN_DRVR_LIC_NUM = "atLicNum";
  public static final String FN_DRVR_LIC_ST = "atLicStD";
  public static final String FN_DC_DCSN = "dcDcsn";
  public static final String FN_FULL_NAME = "atFullName";

  // 03-15-04
  //
  public static final String FN_LOAN_PURPOSE = "anLoanPur";
  public static final String FN_COLL_OFF = "anColOffD";
  public static final String FN_GEN_CMNTS = "anGenCmtsA";
  public static final String FN_MEM_CMNTS = "anMemCmtsA";
  public static final String FN_REV_CMNTS = "anReviewCmtsA";
  public static final String FN_CUST_CMNTS = "anCustCmtsA";
  public static final String FN_DCLR_CMNTS = "anDclrCmtsA";
  public static final String FN_CMNT_TYPE = "cmtTypD";
  public static final String FN_CMNT = "cmtA";
  public static final String FN_PROOF_INC = "atVPrIncC";
  public static final String FN_ID_TYPE = "atIdTypD";
  public static final String FN_ID_NUM = "atIdNum";
  public static final String FN_ID_ISSUED_BY = "atIdIssByD";
  public static final String FN_PHY_EST_VAL_SRC = "phyEstValSrcD";
  public static final String FN_COLLATERAL_EVAL = "clEvalD";
  public static final String FN_BWR_MAIL_ADDR_SAME = "atMailSameAsAddrC";

  // contract node
  //
  public static final String FN_CT_RATE = "ctIntRate";
  public static final String FN_CT_FIN_CHG = "ctFinChg";
  public static final String FN_CT_CONTRACT_DT = "ctContractDt";
  public static final String FN_CT_TTL_FIN_AMT = "ctTtlFinAmt";
  public static final String FN_CT_IND_OTH = "ctIndOth";
  public static final String FN_CT_1ST_PMT_DT = "ct1stPmtDt";
  public static final String FN_CT_TERM = "ctTerm";
  public static final String FN_CT_AMORT_PRD = "ctAmortPrd";

  // 6-19-07, ccl
  //
  public static final String FN_CT_PMT_END = "ctPmtEndC";
  public static final String FN_CT_PMT_IS_END = "ctPmtIsEndC";

  // system data
  //
  public static final String FN_APP_TOTAL_INC = "!appTtlInc";
  public static final String FN_APP_STAT = "!stat";
  public static final String FN_APP_ORIG = "!orig";
  public static final String FN_APP_TYPE = "!type";
  public static final String FN_HMDA_INT_LOOKUP_DT = "!lockIntDt";
  public static final String FN_INCOMPLETE_NODE = "!inc";
  public static final String FN_TERM_IN_MONTHS = "!term";
  public static final String FN_RESP_PARTY = "!respUserId";
  public static final String FN_POINTS = "!points";
  public static final String FN_APR_LOAN_AMT = "!aprLoanAmt";
  public static final String FN_APR_POC = "!feesAPRPOC";
  public static final String FN_NON_APR_POC = "!feesNonAPRPOC";
  public static final String FN_APR_FIN = "!feesAPRFin";
  public static final String FN_APR_FIN_LENDER = "!feesAPRFinL";
  public static final String FN_APR_FIN_BUYER = "!feesAPRFinB";
  public static final String FN_APR_FIN_SELLER = "!feesAPRFinS";

  public static final String FN_NON_APR_FIN = "!feesNonAPRFin";
  public static final String FN_NON_APR_FIN_LENDER = "!feesNonAPRFinL";
  public static final String FN_NON_APR_FIN_BUYER = "!feesNonAPRFinB";
  public static final String FN_NON_APR_FIN_SELLER = "!feesNonAPRFinS";

  public static final String FN_FILE_TTL = "!feesFile";
  public static final String FN_FILE_TTL_LENDER = "!feesFileL";
  public static final String FN_FILE_TTL_BUYER = "!feesFileB";
  public static final String FN_FILE_TTL_SELLER = "!feesFileS";

  public static final String FN_HOEPA_FEE_TTL = "!feesHOEPA";
  public static final String FN_HOEPA_FEE_TTL_LENDER = "!feesHOEPAL";
  public static final String FN_HOEPA_FEE_TTL_BUYER = "!feesHOEPAB";
  public static final String FN_HOEPA_FEE_TTL_SELLER = "!feesHOEPAS";

  public static final String FN_NON_HOEPA_FIN_FEE = "!feesNonHOEPAFin";
  public static final String FN_NON_HOEPA_FIN_FEE_LENDER = "!feesNonHOEPAFinL";
  public static final String FN_NON_HOEPA_FIN_FEE_BUYER = "!feesNonHOEPAFinB";
  public static final String FN_NON_HOEPA_FIN_FEE_SELLER = "!feesNonHOEPAFinS";

  public static final String FN_BWR_GRS_MON_INCOME = "!grsMonInc";
  public static final String FN_BWR_GRS_ANN_INCOME = "!grsAnnInc";
  public static final String FN_BWR_NET_MON_INCOME = "!atNetMonInc";
  public static final String FN_BWR_NET_ANN_INCOME = "!atNetAnnInc";
  public static final String FN_BWR_GRS_MON_SALARY = "!grsMonSal";
  public static final String FN_BWR_CB_SCORE = "!rskScore";
  public static final String FN_SELECTED_TRADE = "!isSel";
  public static final String FN_MODIFIED_TRADE = "!isMod";
  public static final String FN_DEBT_RATIO = "!debtRatio";
  public static final String FN_BKCY_SCORE = "!bnkScore";
  public static final String FN_APP_SCORE = "!appScore";
  public static final String FN_FORM_TITLE_DESC = "!formTitle";
  public static final String FN_CASH_CHARGES = "!feesCash";
  public static final String FN_CASH_APR_CHARGES = "!feesAPRCash";
  public static final String FN_CASH_APR_CHARGES_LENDER = "!feesAPRCashL";
  public static final String FN_CASH_APR_CHARGES_BUYER = "!feesAPRCashB";
  public static final String FN_CASH_APR_CHARGES_SELLER = "!feesAPRCashS";

  public static final String FN_POC_CHARGES = "!feesOutClose";
  public static final String FN_POC_APR_CHARGES = "!feesAPROutClose";
  public static final String FN_POC_APR_CHARGES_LENDER = "!feesAPROutCloseL";
  public static final String FN_POC_APR_CHARGES_BUYER = "!feesAPROutCloseB";
  public static final String FN_POC_APR_CHARGES_SELLER = "!feesAPROutCloseS";

  public static final String FN_CASH_NON_APR_CHARGES = "!feesNonAPRCash";
  public static final String FN_CASH_NON_APR_CHARGES_LENDER = "!feesNonAPRCashL";
  public static final String FN_CASH_NON_APR_CHARGES_BUYER = "!feesNonAPRCashB";
  public static final String FN_CASH_NON_APR_CHARGES_SELLER = "!feesNonAPRCashS";
  public static final String FN_POC_NON_APR_CHARGES = "!feesNonAPROutClose";
  public static final String FN_POC_NON_APR_CHARGES_LENDER = "!feesNonAPROutCloseL";
  public static final String FN_POC_NON_APR_CHARGES_BUYER = "!feesNonAPROutCloseB";
  public static final String FN_POC_NON_APR_CHARGES_SELLER = "!feesNonAPROutCloseS";
  public static final String FN_BWR_AUTH_SET_VERIFY = "!bwrAuthSetVerify";
  public static final String FN_SYS_RPT_USED = "!rptUsed";
  public static final String FN_SYS_RSK_SCORE = "!rskScore";
  public static final String FN_SYS_SC_DEC = "!scDec";
  public static final String FN_SYS_SC_ACT = "!scAct";
  public static final String FN_SYS_MR_ACT = "!mrAct";
  public static final String FN_SYS_PRM_RISK = "!prmRisk";
  public static final String FN_SYS_PRM_BANK = "!prmBank";
  public static final String FN_SYS_SUB_ID = "!subId";
  public static final String FN_SYS_LC_FINAL = "!lcFinal";
  public static final String FN_SYS_LC_FINAL_SCORE = "!lcFinalScore";
  public static final String FN_SYS_RPT_TM = "!rptTm";
  public static final String FN_SYS_SC_FINAL = "!scFinal";
  public static final String FN_SYS_SC_FINAL_SCORE = "!scFinalScore";
  public static final String FN_SYS_DEC_PARTY = "!decParty";
  public static final String FN_SYS_MR_AA = "!mrAA";
  public static final String FN_SYS_MR_DEC = "!mrDec";
  public static final String FN_SYS_DEC_IDX = "!decIdx";
  public static final String FN_SYS_PRD_ARB_SCORE = "!prdARBScore";
  public static final String FN_SYS_PRD_ARA_SCORE = "!prdARAScore";
  public static final String FN_SYS_RPT = "!rpt";
  public static final String FN_SYS_DCSN = "!dcsn";
  public static final String FN_SYS_REVIEW = "!review";
  public static final String FN_SYS_CRD_BWR = "!crdBwr";
  public static final String FN_SYS_MERGED = "!merged";
  public static final String FN_SYS_CONTAINER = "!container";
  public static final String FN_SYS_NT_WRTH = "!ntWrth";
  public static final String FN_SYS_MONTHLY_DEBT = "!ttlMonDebt";
  public static final String FN_SYS_MONTHLY_RE_DEBT = "!ttlMonREDebt";   // 9-18-09, ccl
  public static final String FN_SYS_PRP_MONTHLY_RE_DEBT = "!prpMonREDebt";   // 9-23-09, ccl
  public static final String FN_SYS_TTL_AST = "!ttlAst";
  public static final String FN_SYS_TTL_PLG = "!ttlPlg";
  public static final String FN_SYS_TTL_UN_PLG = "!ttlUnplg";
  public static final String FN_SYS_TTL_LI = "!ttlLi";
  public static final String FN_SYS_TTL_SEC = "!ttlSec";
  public static final String FN_SYS_TTL_UNSEC = "!ttlUnsec";
  public static final String FN_SYS_PRE_DEBT_RATIO = "!prDebtRatio";
  public static final String FN_SYS_REV_DEBT_RATIO = "!revDebtRatio";
  public static final String FN_SYS_HS_DEBT_RATIO = "!hsDebtRatio";
  public static final String FN_SYS_TTL_STD_ADV = "!ttlStdAdv";
  public static final String FN_SYS_TTL_ADJ_STD_ADV = "!ttlAdjStdAdv";
  public static final String FN_SYS_TTL_STD_PCT = "!ttlStdPct";
  public static final String FN_SYS_STD_ADV_VAL = "!StdAdvVal";
  public static final String FN_SYS_STD_ADV = "!StdAdv";
  public static final String FN_SYS_TTL_LIENS = "!ttlLiens";
  public static final String FN_SYS_TTL_COLL = "!ttlColl";
  public static final String FN_SYS_TTL_COLL_AMT = "!ttlCollAmt";
  public static final String FN_SYS_TTL_LTV_PCT = "!ttlLTVPct";
  public static final String FN_SYS_TTL_DN_PMT = "!ttlDnPmt";
  public static final String FN_SYS_TTL_PRICE = "!ttlPDSlPrc";
  public static final String FN_SYS_NT_RNTL_MON_INC = "!ntRntlMonInc";
  public static final String FN_SYS_DIV_INT_MON_INC = "!divIntMonInc";
  public static final String FN_SYS_OTH_MON_INC = "!othMonInc";
  public static final String FN_SYS_OTH2_MON_INC = "!oth2MonInc";
  public static final String FN_SYS_OTH3_MON_INC = "!oth3MonInc";
  public static final String FN_SYS_OTH4_MON_INC = "!oth4MonInc";
  public static final String FN_SYS_TTL_OTH_MON_INC = "!ttlOthMonInc";
  public static final String FN_SYS_COMM_MON_INC = "!commMonInc";
  public static final String FN_SYS_BON_MON_OT = "!bonMonOT";
  public static final String FN_SYS_BON_MON_SAL = "!bonMonSal";
  public static final String FN_SYS_CMB_INC = "!cmbInc";
  public static final String FN_SYS_NET_MON_INC = "!netMonInc";
  public static final String FN_SYS_CMB_ANN_INC = "!cmbAnnInc"; // 9-17-09, ccl
  public static final String FN_SYS_NET_ANN_INC = "!netAnnInc"; // 9-17-09, ccl
  public static final String FN_SYS_RES_INC_ADJ = "!resIncAdj";
  public static final String FN_SYS_NET_RES_INC = "!netResInc";
  public static final String FN_SYS_LN_LTV = "!lnLTV";
  public static final String FN_SYS_TTL_MON_EXP_AN = "!ttlMonExpAn";
  public static final String FN_SYS_PE_SV_CD_MARGIN = "!peSvCDMargin";
  public static final String FN_SYS_MARGIN_RT = "!marginRt";
  public static final String FN_SYS_PE_INDEX_RATE = "!peIndexRate";
  public static final String FN_SYS_PE_INDEX_NAME = "!peIndexName";
  public static final String FN_SYS_PE_MIN_CAP = "!peMinCap";
  public static final String FN_SYS_PE_MAX_CAP = "!peMaxCap";
  public static final String FN_SYS_STIP_LIST = "!stipList";
  public static final String FN_SYS_STIP_CMTS = "!stipCmts";
  public static final String FN_SYS_PMT_VEC   = "!pmtVec";
  public static final String FN_SYS_TTL_XPLG_BAL = "!ttlXPlgBal";
  public static final String FN_SYS_CALC_DIS = "!peDiscount";
  public static final String FN_SYS_TBL_ID = "!peTblId";
  public static final String FN_SYS_AUTH = "!auth";

  //Decision fields
  public static final String FN_DCSN = "dcDcsn";
  public static final String FN_DCSN_PARTY = "dcDcsnPty";
  public static final String FN_DCSN_DATE = "dcDcsnDt";
  public static final String FN_DCSN_PRODUCT = "dcProdType";
  public static final String FN_DCSN_RISK_CD_TXT = "dcRiskCdTxt";
  public static final String FN_DCSN_RISK_CD_D = "dcRiskCdD";
  public static final String FN_DCSN_DOC_SYS_TXT = "dcDocSysTxt";
  public static final String FN_DCSN_DOC_SYS_D = "dcDocSysD";
  public static final String FN_DCSN_PRVDCSN = "dcPrvDcsn";
  public static final String FN_DCSN_PRV_UNDERWRITER = "dcPrvUW";
  public static final String FN_DCSN_PRVDCSN_DATE = "dcPrvDcsnDt";
  public static final String FN_DCSN_STATUS = "dcStatus";
  public static final String FN_DCSN_DECLINE_T = "_dcDeclineT";
  public static final String FN_DCSN_BASE_T = "_dcBaseT";
  public static final String FN_AN_DCSN = "an_decision";
  public static final String FN_AN_DCSN_PARTY = "an_decision_party";
  public static final String FN_DC_BASIS = "dcBasis";
  public static final String FN_DC_TTL_HS = "dcTtlHs";
  public static final String FN_DC_ADV_RQ_AMT = "dcAdvRqAmt";
  public static final String FN_DC_BASE_CBC = "dcBaseCBC";
  public static final String FN_DC_BASE_AFFC = "dcBaseAffC";
  public static final String FN_DC_CL_VAL_AMT = "dcClValAmt";
  public static final String FN_DC_CL_AMT = "dcClAmt";
  public static final String FN_DC_VAL_CVG = "dcValCvg";
  public static final String FN_DC_VAL_MGN = "dcValMgn";
  public static final String FN_DC_ADV_PCT = "dcAdvPct";
  public static final String FN_DC_ADV_CVG = "dcAdvCvg";
  public static final String FN_DC_ADV_MGN = "dcAdvMgn";
  public static final String FN_DC_TR_SMYT = "dcTrSmyT";
  public static final String FN_DC_DBT_RT = "dcDbtRt";
  public static final String FN_DC_RV_DBT_RT = "dcRvDbtRt";
  public static final String FN_DC_PRJ_DBT_RT = "dcPrjDbtRt";
  public static final String FN_DC_TTL_HS_UW = "dcTtlHsUW";
  public static final String FN_DC_TTL_DBT = "dcTtlDbt";
  public static final String FN_DC_NTFY_C = "dcNtfyC";
  public static final String FN_DC_DEC_PRTY_D = "dcDecPrtyD";
  public static final String FN_DC_JUST_M = "dcJustM";
  public static final String FN_DC_EXCPT_M = "dcExcptM";
  public static final String FN_DC_XPLG_BAL = "dcXPlgBal";

  //System Setting fields
  public static final String FN_X_LOC_D = "xLocD";
  public static final String FN_X_YIELD_T = "xYieldT";

  // BUSINESS_CONFIGURATION -STAUST_MONITOR_SETUP
  public static final String FN_X_STAT_PRD_D = "xStatPrdD";
  public static final String FN_X_CUR_STAT_D = "xCurStatD";
  public static final String FN_X_CHG_STAT_D = "xChgStatD";
  public static final String FN_X_STAT_PRD = "xStatPrd";
  public static final String FN_X_STAT_T = "xStatT";

  // DUPLICATE
  //
  public static final String FN_X_DUP_CHK_R = "xDupChkR";
  public static final String FN_X_DUP_PRD_R = "xDupPrdR";
  public static final String FN_X_DUP_TYPE_R = "xDupTypR";
  public static final String FN_X_DUP_ALL_C = "xDupAllC";
  public static final String FN_X_DUP_LVL_D = "xDupLvlD";
  public static final String FN_X_DUP_DAY_C = "xDupDayC";
  public static final String FN_X_DUP_DAY = "xDupDay";
  public static final String FN_X_DUP_DEC_D = "xDupDecD";
  public static final String FN_X_DUP_APP_M = "xDupAppM";
  public static final String FN_X_DUP_COL_M = "xDupColM";
  public static final String FN_X_DUP_FLD_D = "xDupFldD";
  public static final String FN_X_DUP_APP_CHOSEN = "xDupAppChosen";
  public static final String FN_X_DUP_FLDS = "xDupFlds";
  public static final String FN_X_DUP_COLS = "xDupCols";

  //FRAUD
  //
  public static final String FN_X_FRD_CHK_R = "xFrdChkR";
  public static final String FN_X_FRD_AAN_C = "xFrdAANC";
  public static final String FN_X_FRD_DEC_D = "xFrdDecD";
  public static final String FN_X_FRD_FULL_NM = "xFrdFullNmC";
  public static final String FN_X_FRD_FULL_NM_D = "xFrdFullNmD";
  public static final String FN_X_FRD_PH = "xFrdPhC";
  public static final String FN_X_FRD_EMP_C = "xFrdEmpC";
  // 8-22-07, ccl
  // duplicate definition,  don't use it in the future. Please use FN_X_FRD_EMP_C
  public static final String FN_X_FRD_EMP = "xFrdEmpC";  // duplicate definition,  ccl, 8-21-07
  public static final String FN_X_FRD_NM_SSN = "xFrdNmSSNC";
  public static final String FN_X_FRD_ADDR = "xFrdAddrC";
  public static final String FN_X_FRD_BS_PH_C = "xFrdBsPhC";
  public static final String FN_X_FRD_SSN = "xFrdSSNC";
  public static final String FN_X_FRD_EMAIL_C = "xFrdEmailC";
  public static final String FN_X_FRD_IP_C = "xFrdIPC";
  public static final String FN_X_FRD_FULL_EMP_D = "xFrdFullEmpD";

  //SB DUPLICATE
  //
  public static final String FN_X_SB_DUP_CHK_R = "xSBDupChkR";
  public static final String FN_X_SB_DUP_PRD_R = "xSBDupPrdR";
  public static final String FN_X_SB_DUP_BS_TYPE_R = "xSBDupBsTypR";
  public static final String FN_X_SB_DUP_TYPE_R = "xSBDupTypR";
  public static final String FN_X_SB_DUP_ALL_C = "xSBDupAllC";
  public static final String FN_X_SB_DUP_LVL_D = "xSBDupLvlD";
  public static final String FN_X_SB_DUP_DAY_C = "xSBDupDayC";
  public static final String FN_X_SB_DUP_DAY = "xSBDupDay";
  public static final String FN_X_SB_DUP_DEC_D = "xSBDupDecD";
  public static final String FN_X_SB_DUP_APP_M = "xSBDupAppM";
  public static final String FN_X_SB_DUP_COL_M = "xSBDupColM";
  public static final String FN_X_SB_DUP_FLD_D = "xSBDupFldD";
  public static final String FN_X_SB_DUP_APP_CHOSEN = "xSBDupAppChosen";
  public static final String FN_X_SB_DUP_FLDS = "xSBDupFlds";
  public static final String FN_X_SB_DUP_COLS = "xSBDupCols";

  //SB FRAUD
  public static final String FN_X_SB_FRD_CHK_R = "xSBFrdChkR";
  public static final String FN_X_SB_FRD_AAN_C = "xSBFrdAANC";
  public static final String FN_X_SB_FRD_DEC_D = "xSBFrdDecD";
  public static final String FN_X_SB_FRD_BS_NM = "xSBFrdBsNmC";
  public static final String FN_X_SB_FRD_TIN = "xSBFrdTINC";
  public static final String FN_X_SB_FRD_BS_ADDR = "xSBFrdBsAddrC";
  public static final String FN_X_SB_NM_TIN = "xSBNmTINC";
  public static final String FN_X_SB_FRD_BS_PH_C = "xSBFrdBsPhC";
  public static final String FN_X_SB_FRD_BS_EMAIL_C = "xSBFrdBsEmailC";
  public static final String FN_X_SB_FRD_FULL_NM = "xSBFrdFullNmC";
  public static final String FN_X_SB_FRD_FULL_NM_D = "xSBFrdFullNmD";
  public static final String FN_X_SB_FRD_SSN = "xSBFrdSSNC";
  public static final String FN_X_SB_FRD_ADDR = "xSBFrdAddrC";
  public static final String FN_X_SB_FRD_NM_SSN = "xSBFrdNmSSNC";
  public static final String FN_X_SB_FRD_PH = "xSBFrdPhC";
  //public static final String FN_X_SB_FRD_EMAIL = "xSBFrdEmailC";  // 2-8-07, ccl
  public static final String FN_X_SB_FRD_EMAIL_C = "xSBFrdEmailC";
  public static final String FN_X_SB_FRD_IP_C = "xSBFrdIPC";
  public static final String FN_X_SB_FRD_FULL_EMP_D = "xSBFrdFullEmpD";

  // MORTGAGE DUPLICATE
  //
  public static final String FN_X_MG_DUP_CHK_R = "xMGDupChkR";
  public static final String FN_X_MG_DUP_PRD_R = "xMGDupPrdR";
  public static final String FN_X_MG_DUP_TYPE_R = "xMGDupTypR";
  public static final String FN_X_MG_DUP_ALL_C = "xMGDupAllC";
  public static final String FN_X_MG_DUP_LVL_D = "xMGDupLvlD";
  public static final String FN_X_MG_DUP_DAY_C = "xMGDupDayC";
  public static final String FN_X_MG_DUP_DAY = "xMGDupDay";
  public static final String FN_X_MG_DUP_DEC_D = "xMGDupDecD";
  public static final String FN_X_MG_DUP_APP_M = "xMGDupAppM";
  public static final String FN_X_MG_DUP_COL_M = "xMGDupColM";
  public static final String FN_X_MG_DUP_BS_TYPE_R = "xMGDupBsTypR";
  public static final String FN_X_MG_DUP_FLD_D = "xMGDupFldD";

  public static final String FN_X_MG_DUP_APP_CHOSEN = "xMGDupAppChosen";
  public static final String FN_X_MG_DUP_FLDS = "xMGDupFlds";
  public static final String FN_X_MG_DUP_COLS = "xMGDupCols";

  // MORTGAGE FRAUD
  //
  public static final String FN_X_MG_FRD_CHK_R = "xMGFrdChkR";
  public static final String FN_X_MG_FRD_AAN_C = "xMGFrdAANC";
  public static final String FN_X_MG_FRD_DEC_D = "xMGFrdDecD";
  public static final String FN_X_MG_FRD_FULL_NM = "xMGFrdFullNmC";
  public static final String FN_X_MG_FRD_FULL_NM_D = "xMGFrdFullNmD";
  public static final String FN_X_MG_FRD_PH = "xMGFrdPhC";
  public static final String FN_X_MG_FRD_EMP_C = "xMGFrdEmpC";
  public static final String FN_X_MG_FRD_NM_SSN = "xMGFrdNmSSNC";
  public static final String FN_X_MG_FRD_ADDR = "xMGFrdAddrC";
  public static final String FN_X_MG_FRD_BS_PH_C = "xMGFrdBsPhC";
  public static final String FN_X_MG_FRD_SSN = "xMGFrdSSNC";
  public static final String FN_X_MG_FRD_EMAIL_C = "xMGFrdEmailC";
  public static final String FN_X_MG_FRD_IP_C = "xMGFrdIPC";
  public static final String FN_X_MG_FRD_FULL_EMP_D = "xMGFrdFullEmpD";

  // DEPOSIT DUPLICATE
  //
  public static final String FN_X_DA_DUP_CHK_R = "xDADupChkR";
  public static final String FN_X_DA_DUP_PRD_R = "xDADupPrdR";
  public static final String FN_X_DA_DUP_TYPE_R = "xDADupTypR";
  public static final String FN_X_DA_DUP_ALL_C = "xDADupAllC";
  public static final String FN_X_DA_DUP_LVL_D = "xDADupLvlD";
  public static final String FN_X_DA_DUP_DAY_C = "xDADupDayC";
  public static final String FN_X_DA_DUP_DAY = "xDADupDay";
  public static final String FN_X_DA_DUP_DEC_D = "xDADupDecD";
  public static final String FN_X_DA_DUP_APP_M = "xDADupAppM";
  public static final String FN_X_DA_DUP_COL_M = "xDADupColM";
  public static final String FN_X_DA_DUP_BS_TYPE_R = "xDADupBsTypR";
  public static final String FN_X_DA_DUP_FLD_D = "xDADupFldD";

  public static final String FN_X_DA_DUP_APP_CHOSEN = "xDADupAppChosen";
  public static final String FN_X_DA_DUP_FLDS = "xDADupFlds";
  public static final String FN_X_DA_DUP_COLS = "xDADupCols";

  // DEPOSIT FRAUD
  //
  public static final String FN_X_DA_FRD_CHK_R = "xDAFrdChkR";
  public static final String FN_X_DA_FRD_AAN_C = "xDAFrdAANC";
  public static final String FN_X_DA_FRD_DEC_D = "xDAFrdDecD";
  public static final String FN_X_DA_FRD_FULL_NM = "xDAFrdFullNmC";
  public static final String FN_X_DA_FRD_FULL_NM_D = "xDAFrdFullNmD";
  public static final String FN_X_DA_FRD_PH = "xDAFrdPhC";
  public static final String FN_X_DA_FRD_EMP_C = "xDAFrdEmpC";
  public static final String FN_X_DA_FRD_NM_SSN = "xDAFrdNmSSNC";
  public static final String FN_X_DA_FRD_ADDR = "xDAFrdAddrC";
  public static final String FN_X_DA_FRD_BS_PH_C = "xDAFrdBsPhC";
  public static final String FN_X_DA_FRD_SSN = "xDAFrdSSNC";
  public static final String FN_X_DA_FRD_EMAIL_C = "xDAFrdEmailC";
  public static final String FN_X_DA_FRD_IP_C = "xDAFrdIPC";
  public static final String FN_X_DA_FRD_FULL_EMP_D = "xDAFrdFullEmpD";

  //CALCULATION
  public static final String FN_X_CALC_ADB_RATE = "xCalcADBRate";
  public static final String FN_X_CALC_ADB_MIN_PMT = "xCalcADBMinPmt";
  public static final String FN_X_CALC_HZD_RATE = "xCalcHzdRate";
  public static final String FN_X_CALC_ESC_MTHS = "xCalcEscMths";


  //Real Estate Compliance Setup
  //
  public static final String FN_X_HOEPA_MAR_LN_SZ           = "xHOEPAMarLoanSize";
  public static final String FN_X_HOEPA_MAR_LN_SZ_EFF_DT    = "xHOEPAMarLoanSizeEffDt";
  public static final String FN_X_HOEPA_MAR_HISTORY         = "bc_hoepamar_history";
  public static final String FN_X_HOEPA_MAR_LOW_LN          = "xHOEPAMarLowLoan";
  public static final String FN_X_HOEPA_MAR_HIGH_LN         = "xHOEPAMarHighLoan";
  public static final String FN_X_HOEPA_MAR_SEC_LN          = "xHOEPAMarSecLoan";
  public static final String FN_X_HOEPA_FEE_LN_SZ           = "xHOEPAFeeLoanSize";
  public static final String FN_X_HOEPA_FEE_LN_SZ_EFF_DT    = "xHOEPAFeeLoanSizeEffDt";
  public static final String FN_X_HOEPA_FEE_HISTORY         = "bc_hoepafee_history";
  public static final String FN_X_HOEPA_FEE_LOW             = "xHOEPAFeeLow";
  public static final String FN_X_HOEPA_FEE_LOW_PCT         = "xHOEPAFeeLowPct";
  public static final String FN_X_HOEPA_FEE_HIGH_PCT        = "xHOEPAFeeHighPct";
  public static final String FN_X_HPML_3FAC_TABLE           = "xHPML3FacTableC";
  public static final String FN_X_HPML_DROPDOWN             = "xHPMLD";
  public static final String FN_X_HPML_1_UNIT               = "xHPML1Unit";
  public static final String FN_X_HPML_2_UNIT               = "xHPML2Unit";
  public static final String FN_X_HPML_3_UNIT               = "xHPML3Unit";
  public static final String FN_X_HPML_4_UNIT               = "xHPML4Unit";
  public static final String FN_X_HPML_FST_LIEN_CON_MGN     = "xHPMLFstLienConMgn";
  public static final String FN_X_HPML_SEC_LIEN_CON_MGN     = "xHPMLSecLienConMgn";
  public static final String FN_X_HPML_FST_LIEN_NON_CON_MGN = "xHPMLFstLienNonConMgn";
  public static final String FN_X_HPML_SEC_LIEN_NON_CON_MGN = "xHPMLSecLienNonConMgn";
  public static final String FN_X_HMDA_FIRST_LIEN           = "xHMDAFirstLien";
  public static final String FN_X_HMDA_SECOND_LIEN          = "xHMDASecondLien";

  //Comparable Treasury Rate
  public static final String FN_X_HOEPA_T = "xHOEPAT";
  public static final String FN_X_YIELD_AU_C = "xYieldAUC";
  public static final String FN_X_YIELD_URL = "xYieldURL";
  public static final String FN_X_YIELD_DT = "xYieldTDt";

  //PRINT TEMPLATES
  public static final String FN_X_AT_TPL_D = "xATTplD";
  public static final String FN_X_CS_TPL_D = "xCSTplD";

  //ARCHIVING
  // BUSINESS CONFIGURATION - Offline_Data_Migration_Setup
  // consumer
  //
  public static final String FN_X_DM_R = "xDMR";
  public static final String FN_X_DM_LOG_NUM = "xDMLogNum";
  public static final String FN_X_DM_DB = "xDMDB";
  public static final String FN_X_DM_DB_D = "xDMDBD";
  public static final String FN_X_DM_PRD_D = "xDMPrdD";
  public static final String FN_X_DM_PRD_DAYS = "xDMPrdDays";
  public static final String FN_X_DM_T = "xDMT";
  public static final String FN_X_DM_LOG_D = "xDMLogD";

  // BUSINESS CONFIGURATION - vista starts with System_Settings
  //
  // consummer
  public static final String FN_X_DEF_DEC_RSN_D = "xDefDecRsnD";
  public static final String FN_X_MR_RSN_C = "xMRRsnC";
  public static final String FN_X_DEF_DEC_RSN_C = "xDefDecRsnC";
  public static final String FN_X_SP_SAME_LTR_C = "xSpSameLtrC";
  public static final String FN_X_SGL_APV_LTR_C = "xSglApvLtrC";
  public static final String FN_X_CB_AGE = "xCBAge";
  public static final String FN_X_UM_DC_D = "xUWDcD";
  public static final String FN_X_T = "xT";

  // business
  public static final String FN_X_SB_DEF_DEC_RSN_D = "xSBDefDecRsnD";
  public static final String FN_X_SB_MR_RSN_C = "xSBMRRsnC";
  public static final String FN_X_SB_DEF_DEC_RSN_C = "xSBDefDecRsnC";
  public static final String FN_X_SB_CB_AGE = "xSBCBAge";
  public static final String FN_X_SB_UW_DC_D = "xSBUWDcD";
  public static final String FN_X_SB_AT_TPL_D = "xSBATTplD";
  public static final String FN_X_SB_CS_TPL_D = "xSBCSTplD";

  // mortgage
  public static final String FN_X_MG_DEF_DEC_RSN_D = "xMGDefDecRsnD";
  public static final String FN_X_MG_MR_RSN_C = "xMGMRRsnC";
  public static final String FN_X_MG_DEF_DEC_RSN_C = "xMGDefDecRsnC";
  public static final String FN_X_MG_SP_SAME_LTR_C = "xMGSpSameLtrC";
  public static final String FN_X_MG_SGL_APV_LTR_C = "xMGSglApvLtrC";
   public static final String FN_X_MG_CB_AGE = "xMGCBAge";
  public static final String FN_X_MG_UW_DC_D = "xMGUWDcD";
  public static final String FN_X_MG_CALC_HZD_RATE = "xMGCalcHzdRate";
  public static final String FN_X_MG_CALC_ESC_MTHS = "xMGCalcEscMths";
  public static final String FN_X_MG_AT_TPL_D = "xMGATTplD";
  public static final String FN_X_MG_CS_TPL_D = "xMGCSTplD";

  // deposit
  public static final String FN_X_DA_DEF_DEC_RSN_D = "xDADefDecRsnD";
  public static final String FN_X_DA_MR_RSN_C = "xDAMRRsnC";
  public static final String FN_X_DA_DEF_DEC_RSN_C = "xDADefDecRsnC";
  public static final String FN_X_DA_SP_SAME_LTR_C = "xDASpSameLtrC";
  public static final String FN_X_DA_SGL_APV_LTR_C = "xDASglApvLtrC";
  public static final String FN_X_DA_CB_AGE = "xDACBAge";
  public static final String FN_X_DA_UW_DC_D = "xDAUWDcD";

  public static final String FN_XS_ERR_L = "xsErrL";

  //Liquid Credit
  public static final String FN_LC_TL_MO_PMT = "lcTlMoPmt";
  public static final String FN_LC_PRJ_DBT_RT = "lcPrjDbtRt";
  public static final String FN_LC_NO_INQ = "lcNoInq";
  public static final String FN_LC_NO_INQ_X7D = "lcNoInqX7d";
  public static final String FN_LC_OTH_EXP = "lcOthExp";
  public static final String FN_LC_APP_LN_PMT = "lcAppLnPmt";
  public static final String FN_LC_TL_MO_ADJ = "lcTlMoAdj";
  public static final String FN_LC_DBT_RT = "lcDbtRt";
  public static final String FN_LC_TL_RV_CL_RT = "lcTlRvCLRt";
  public static final String FN_LC_NT_DSP_DBT_RT = "lcNtDspDbtRt";
  public static final String FN_LC_NT_DSP_INC = "lcNtDspInc";
  public static final String FN_LC_PRJ_DBT_RT_UW = "lcPrjDbtRtUW";
  public static final String FN_LC_OTH_EXP_UW = "lcOthExpUW";
  public static final String FN_LC_APP_LN_PMT_UW = "lcAppLnPmtUW";
  public static final String FN_LC_TL_MO_ADJ_UW = "lcTlMoAdjUW";

  public static final String FN_PE_CUTOFF = "pe_cutoff";
  public static final String FN_AUTH_SMYL = "auSmyL";

  public static final String FN_DR_OVR_DFT = "drOvrDft";
  public static final String FN_DR_INS_DBT = "drInsDbt";
  public static final String FN_DR_CCLO_CAMT = "drCCLoCAmt";
  public static final String FN_DR_LESS_CD_SCRD = "drLessCDScrd";
  public static final String FN_DR_LESS_FAB_LN_SCRD_RES = "drLessFABLnScrdRes";
  public static final String FN_DR_FAB_GUAR_DBT = "drFABGuarDbt";

  public static final String FN_DR_FIELD_MAP = "!drPurTtls";

  public static final String FN_CRD_NAME = "crdName";
  public static final String FN_CRD_HLDR_C = "crdHldrC";

  public static final String FN_NT_WRTH_TYPE = "_NtWrthTypD";
  public static final String FN_NT_WRTH_SUB_TYPE = "_NtWrthSubTypD";
  public static final String FN_NT_WRTH_T = "_NtWrthT";
  public static final String FN_NW_ITEM_POS_HID = "_nwItemPOSHid";
  public static final String FN_BUS_POS_HID = "_busPOSHid";
  public static final String FN_BWR_INC_PRD_D = "_atIncPrdD";
  public static final String FN_FS_ID = "_fsID";

  public static final String FN_RV_FEE_C = "rvFeeC";
  public static final String FN_RV_FEE_BELOW_C = "rvFeeBelowC";
  public static final String FN_RV_FEE_OR_RSV_C = "rvFeeOrRsvC";
  public static final String FN_RV_FEE_R = "rvFeeR";
  public static final String FN_RV_FEE = "rvFee";
  public static final String FN_RV_FEE_PCT = "rvFeePct";
  public static final String FN_RV_FEE_PCT_MAX = "rvFeeMax";
  public static final String FN_RV_FEE_PCT_MIN = "rvFeeMin";
  public static final String FN_RV_FEE_TBL_D = "rvFeeTblD";
  public static final String FN_RV_PTS_TBL_D = "rvPtsTblD";
  public static final String FN_RV_PAY_TYPE_R = "rvPayTypR";
  public static final String FN_RV_PCT = "rvPct";
  public static final String FN_RV_BUYDOWN_C = "rvBuyDownC";

  //App Filter
  public static final String FN_AF_LOC = "afLocD";
  public static final String FN_AF_RG = "afRgD";
  public static final String FN_AF_APP_ID = "afAppId";
  public static final String FN_AF_DC_FROM_DT = "afDcFromDt";
  public static final String FN_AF_DC_TO_DT = "afDcToDt";
  public static final String FN_AF_LOAN_NUM = "afLoanNum";
  public static final String FN_AF_ACCT_NUM = "afAcctNum";
  public static final String FN_AF_LNAME = "afLName";
  public static final String FN_AF_SSN = "afSSN";
  public static final String FN_AF_CIF = "afCIF";
  public static final String FN_AF_PROD_TYPE = "afProdTypeD";
  public static final String FN_AF_DCSN = "afDcsnD";
  public static final String FN_AF_NM_BUS = "afNmBus";
  public static final String FN_AF_TX_ID_NUM = "afTxIDNum";
  public static final String FN_AF_BE_ID = "afBEId";
  public static final String FN_AF_AANT = "afAANT";
  public static final String FN_AF_BR = "afBrD";
  public static final String FN_AF_PROD = "afProdD";
  public static final String FN_AF_SHOW_ALL = "afShowAllC";
  public static final String FN_AF_DLR = "afDlr";
  public static final String FN_AF_DLR_D = "afDlrD";
  public static final String FN_AF_STATUS = "afStatusD";
  public static final String FN_AF_PRV_DAYS = "afPrvDays";
  public static final String FN_AF_EXC_ARC = "afExcArcC";
  public static final String FN_AF_ASGN_D = "afAsgnD";
  public static final String FN_AF_APP_FROM_DT = "afAppFromDt";
  public static final String FN_AF_APP_TO_DT = "afAppToDt";
  public static final String FN_AF_TIME_ZONE_D = "afTimeZoneD";
  public static final String FN_AF_REP_NUM = "afRepNum";
  public static final String FN_AF_MULTC = "_afMultC";
  public static final String FN_AF_IS_SBC = "_isSBC";
  public static final String FN_AF_DM_DB = "afDmDb";
  public static final String FN_AF_NTFY_C = "afNtfyC";
  public static final String FN_AF_NO_SEARCH = "afNoSearch";
  public static final String ALL_PRODUCTS_STR = "All Products";
  public static final String ALL_CONSUMER_PRODUCTS_STR =
      "All Consumer Products";
  public static final String ALL_BUSINESS_PRODUCTS_STR =
      "All Business Products";
  public static final String ALL_MORTGAGE_PRODUCTS_STR =
      "All Mortgage Products";
  public static final String ALL_DEPOSIT_PRODUCTS_STR =
      "All Deposit Products";

  //Stipulations
  public static final String FN_STPD = "stpD";
  public static final String FN_STP_RESD = "stpResD";
  public static final String FN_STPA = "stpA";
  public static final String FN_STPL = "_stpL";
  public static final String FN_STP_MODE_C = "_stpModeC";
  public static final String FN_STP_POS_HID = "_stpPOSHid";
  public static final String FN_STP_USR = "stpUsr";
  public static final String FN_STP_DT = "stpDt";

  public static final String FN_PMT_CALC_ERR = "pmtCalcErr";
  public static final String FN_INS_WARNINGS = "anInsWarnL";

  public static final String FORM = "Form";
  public static final String FIELDS = "Fields";
  public static final String INSTRUCTIONS = "Instructions";

  //Business Signers
  //
  public static final String FN_BUS_SGN_SMYL = "bsSmyL";

  //Mortgage Commitment
  public static final String COM_ID = "comId";
  public static final String COM_NAME = "comName";
  public static final String COM_DESC_A = "comDescA";
  public static final String COM_EFF_DT = "comEffDt";
  public static final String COM_EXP_DT = "comExpDt";
  public static final String COM_TYP_D = "comTypD";
  public static final String COM_AMT = "comAmt";
  public static final String COM_INT_MIN = "comIntMin";
  public static final String COM_INT_MAX = "comIntMax";
  public static final String COM_GUIDE_D = "comGuideD";
  public static final String COM_DOC_RQ_L = "comDocRqL";
  public static final String COM_FEE = "comFee";
  public static final String COM_SV_TYP_D = "comSvTypD";
  public static final String COM_LOC_D = "comLocD";
  public static final String COM_INV_NAME = "comInvName";
  public static final String COM_INV_ADDR = "comInvAddr";
  public static final String COM_INV_ADDR_TWO = "comInvAddrTwo";
  public static final String COM_INV_CITY = "comInvCity";
  public static final String COM_INV_ST_D = "comInvStD";
  public static final String COM_INV_ZIP = "comInvZip";
  public static final String COM_INV_ZIP_PLUS = "comInvZipPlus";
  public static final String COM_T = "comT";
  public static final String COM_POOL_T = "comPoolT";
  public static final String COM_TTL_AMT = "comTtlAmt";
  public static final String COM_SF_AMT = "comSFAmt";
  public static final String COM_AVE_LN_SZ = "comAveLnSz";
  public static final String COM_AVE_FICO = "comAveFICO";
  public static final String COM_AVE_LTV = "comAveLTV";
  public static final String COM_FUND_PCT = "comFundPct";

  // mortgage loan terms summary
  public static final String FN_EST_CLOSING_COSTS = "anEstCloseCost";
  public static final String FN_EST_CLOSING_COSTS_LENDER = "anEstCloseCostL";
  public static final String FN_EST_CLOSING_COSTS_BUYER = "anEstCloseCostB";
  public static final String FN_EST_CLOSING_COSTS_SELLER = "anEstCloseCostS";
  public static final String FN_SELLER_CONCESSIONS = "anSlrConAmt";

  public static final String FN_EST_PREPAID = "anEstPPAmt";
  public static final String FN_DISC_AMT = "anDiscAmt";
  public static final String FN_LOAN_LEVEL_AMT = "anLoanLevelAmt";
  public static final String FN_DISC_AMT_LENDER = "anDiscAmtL";
  public static final String FN_DISC_AMT_BUYER = "anDiscAmtB";
  public static final String FN_DISC_AMT_SELLER = "anDiscAmtS";

  public static final String FN_ESCROW_TOTAL = "!escTotal";
  public static final String FN_POINT_ADJ = "anPtAdj";
  public static final String FN_DISC_POINT_ADJ = "anDiscPtAdj";

  public static final String FN_GI_SHOW = "anGIVisC";
  public static final String FN_UDF_SHOW = "anUDFVisC";

  public static final String FN_DOWN_PAYMENT_R = "anDwnPmtR";
  public static final String FN_DOWN_PAYMENT_PCT = "anDwnPmtPct";
  //+HOEPA and HPML test
  public static final String FN_PAR_RATE		= "anParRate";
  public static final String FN_PAR_APOR_RATE	= "anParRateAporRate";
  //-HOEPA and HPML test

  // mortgage escrow
  //
  // escrow details
  public static final String FN_ESCROW_DIS_FRQ = "escPmtPrdD";
  public static final String FN_ESCROW_1ST_DIS_DT = "escDt";
  public static final String FN_ESCROW_PAYEE = "escPayee";
  public static final String FN_ESCROW_ACCT_NUM = "escAcctNum";
  public static final String FN_ESCROW_DUE_AMT = "escDueAmt";
  //public static final String FN_ESCROW_ANN_AMT = "escAnnAmt";
  public static final String FN_ESCROW_DIS_MTHS = "escMths";
  public static final String FN_ESCROW_NUM_RES_MTHS = "escNoRsvMths";
  public static final String FN_ESCROW_OVERRIDE_C = "escOverC";
  public static final String FN_ESCROW_MON_AMT = "escMonPmt";  // not real field
  //public static final String FN_ESCROW_AGG_ADJ = "escAgAdj";

  // escrow summary
  public static final String FN_ESCROW_SMY_T = "_escT";
  public static final String FN_ESCROW_ANN_TTL = "escAnnTtl";
  public static final String FN_ESCROW_MTH_TTL = "escMthTtl";
  public static final String FN_ESCROW_DUE_TTL = "escDueTtl";
  public static final String FN_ESCROW_AGG_ADJ = "escAgAdj";
  public static final String FN_ESCROW_COUNT = "_escCount";
  public static final String FN_ESCROW_MODE_C = "_escModeC";
  public static final String FN_ESCROW_POS_HID = "_escPOSHid";

  // escrow payee type
  public static final String FN_ESCROW_PYEE_TYPE = "escTypD";
  public static final String FN_ESCROW_DIS_AMT = "escAmt";
  public static final String FN_ESCROW_C = "escC";
  public static final String FN_ESCROW_1ST_PMT_DT = "esc1stPmtDt";

  // 8-6-09, ccl
  // private mortgage insurance
  public static final String FN_ESCROW_MI_PMT_PLANS_D = "escMIPmtPlansD";
  public static final String FN_ESCROW_MI_CAN_OPT_D = "escCancelOptD";
  public static final String FN_ESCROW_MI_INT_RATE = "escInitRt";
  public static final String FN_ESCROW_MI_CVG_PCT = "escCvgPct";
  public static final String FN_ESCROW_MI_1ST_RG = "esc1StRg";
  public static final String FN_ESCROW_MI_1END_RG = "esc1EndRg";
  public static final String FN_ESCROW_MI_2ST_RG = "esc2StRg";
  public static final String FN_ESCROW_MI_2END_RG = "esc2EndRg";
  public static final String FN_ESCROW_MI_3ST_RG = "esc3StRg";
  public static final String FN_ESCROW_MI_3END_RG = "esc3EndRg";
  // 4-1-2010, ccl
  //
  public static final String FN_ESCROW_MI_NUM_MTHS_CLSNG = "escNumMoClsng";
  public static final String FN_ESCROW_MI_FIN_C = "escFinC";

  // mortgage trans type
  public static final String FN_MTG_TRANS_TYPE = "anGETransTypD";
  public static final String FN_SUB_FIN_AMT = "anSubFinAmt";



  // ARM fields
  public static final String FN_PG_ROUND_METHOD = "anPgRdD";
  public static final String FN_PG_ROUND = "anPgRd";
  public static final String FN_RATE_CHG_DT = "anRtChgDt";
  public static final String FN_PMT_CHG_DT = "anPmtChgDt";
  public static final String FN_NEXT_PMT_CHG_DT = "anNextPmtChgDt";
  public static final String FN_PG_INITIAL_CAP = "anPgInitCap";
  public static final String FN_PG_INTERVAL_CAP = "anPgInvCap";
  public static final String FN_PG_LIFE_CAP = "anPgLifeCap";
  public static final String FN_PG_ADJ_INTERVAL = "anPgAdjInt";
  public static final String FN_PG_INIT_INTERVAL = "anPgInitInt";

  public static final String FN_ARM_WORST_CASE_1ST_PMT = "anARMWC1stPmt";
  public static final String FN_ARM_WORST_CASE_MAX_PMT = "anARMWCMaxPmt";
  public static final String FN_ARM_5_MAX_PMT = "anARMWC5MaxPmt";
  public static final String FN_ARM_WORST_CASE_1ST_PMT_DT = "anARMWC1stPmtDt";
  public static final String FN_ARM_WORST_CASE_MAX_PMT_DT = "anARMWCMaxPmtDt";
  public static final String FN_ARM_5_MAX_PMT_DT = "anARMWC5MaxPmtDt";
  public static final String FN_ARM_WORST_CASE_1ST_RATE = "anARMWC1stRt";
  public static final String FN_ARM_WORST_CASE_MAX_RATE = "anARMWCMaxRt";
  public static final String FN_ARM_5_MAX_RATE = "anARMWC5MaxRt";
  public static final String FN_ARM_WORST_CASE_1ST_PMT_RT_DT = "anARMWC1stRtDt";
  public static final String FN_ARM_WORST_CASE_MAX_PMT_RT_DT = "anARMWCMaxRtDt";
  public static final String FN_ARM_5_MAX_PMT_RT_DT = "anARMWC5MaxRtDt";
  public static final String FN_ARM_WORST_CASE_1ST_PMT_NO_MI = "anARMWC1stPmtNoMI";
  public static final String FN_ARM_WORST_CASE_MAX_PMT_NO_MI = "anARMWCMaxPmtNoMI";
  public static final String FN_ARM_5_MAX_PMT_NO_MI = "anARMWC5MaxPmtNoMI";
  public static final String FN_ARM_WORST_CASE_1ST_PMT_DT_NO_MI = "anARMWC1stPmtDtNoMI";
  public static final String FN_ARM_WORST_CASE_MAX_PMT_DT_NO_MI = "anARMWCMaxPmtDtNoMI";
  public static final String FN_ARM_5_MAX_PMT_DT_NO_MI = "anARMWC5MaxPmtDtNoMI";
  public static final String FN_ARM_WC_AMORT = "anWCAmortL";
  public static final String FN_ARM_WC_AMORT_NO_MI = "anWCAmortMIL";
  // Asset fields
  public static final String FN_ASSET_SUB_PROP = "astSubPropC";
  public static final String FN_ASSET_CURR_RES = "astCurrResC";

  // 3-10-2010, ccl
  //
  // Seller Summary
  //
  public static final String FN_SELLER_SMY_T = "_slrT";
  public static final String FN_SELLER_MODE_C = "_slrModeC";

  // Seller Information
  //
  public static final String FN_SELLER_ADDR = "slrAddr";
  public static final String FN_SELLER_ADDR_TWO = "slrAddrTwo";
  public static final String FN_SELLER_CITY = "slrCity";
  public static final String FN_SELLER_STATE = "slrStD";
  public static final String FN_SELLER_ZIP = "slrZip";
  public static final String FN_SELLER_ZIP_PLUS = "slrZipPlus";

  // 4-12-2010, ccl
  // PreApproval offer
  //
  public static final String FN_PAO_TT = "paoT";
  public static final String FN_PAO_HIDE_C = "paoHideC";

  public static final String FN_RQ_TYPE = "rqTypD";
  public static final String FN_RQ_D = "rqD";
  public static final String FN_RQ_CMT = "rqA";
  public static final String FN_RQ_STAT = "rqStatD";

  // IP address fields
  //main storage is in appnode system data, other references are temporary
  public static final String FN_IP_ADDRESS = "!IP";
  public static final String FN_BWR_IP_ADDRESS = "atIP";
  public static final String FN_BUS_IP_ADDRESS = "beIP";

  // Deposit Accounts
  //
  public static final String FN_DEP_PROD_ID = "daProdTypeD";
  public static final String FN_DEP_ACCT_OPEN_DT = "daAcctOpenDt";
  public static final String FN_DEP_OPEN_AMT = "daOpenAmt";
  public static final String FN_DEP_INT_RATE = "daIntRate";
  public static final String FN_DEP_ACCT_NUM = "daAcctNum";
  public static final String FN_DEP_FUNDING_TYPE = "daFundTypD";
  public static final String FN_DEP_FUNDING_AMT = "daFundAmt";
  public static final String FN_DEP_FUNDING_TOTAL = "daFundTtl";
  public static final String FN_DEP_FUNDING_TBL = "_daFundT";
  public static final String FN_DEP_FUNDING_SOURCE = "daFundSource";
  public static final String FN_DEP_FUNDING_DATE = "daFundDt";
  public static final String FN_DEP_FUNDING_TRANSID = "daFundTransId";
  public static final String FN_DEP_FUNDING_TRANSTYPE = "daFundTransType";
  public static final String FN_DEP_POD_TBL = "_daPODT";
  public static final String FN_DEP_POD_BENE_TITLE = "podBeneTitleD";
  public static final String FN_DEP_POD_BENE_SUFFIX = "podBeneSufD";
  public static final String FN_DEP_POD_BENE_DIR = "podBeneDirD";
  public static final String FN_DEP_POD_BENE_DIR2 = "podBeneDir2D";
  public static final String FN_DEP_POD_BENE_TYPE = "podBeneTypeD";
  public static final String FN_DEP_POD_BENE_TYPE2 = "podBeneType2D";
  public static final String FN_DEP_POD_BENE_STATE = "podBeneStateD";
  public static final String FN_DEP_POD_BENE_FIRST = "podBeneFirst";
  public static final String FN_DEP_POD_BENE_MID = "podBeneMid";
  public static final String FN_DEP_POD_BENE_LAST = "podBeneLast";
  public static final String FN_DEP_POD_BENE_DOB = "podBeneDOB";
  public static final String FN_DEP_POD_BENE_SSN = "podBeneSSN";
  public static final String FN_DEP_POD_BENE_SHARE = "podBeneShare";
  public static final String FN_DEP_OVERDRAFT_ASSOC_ACCT = "_daAssocAcctD";
  public static final String FN_DEP_OVERDRAFT_ASSOC_ACCT_TBL = "_daAssocAcctT";
  public static final String FN_SYS_DEP_CUR_DA_PTR = "!curDAPtr";
  public static final String FN_SYS_DEP_PRD_GRP_ID = "!prdGrpId";
  public static final String FN_SYS_DEP_PRD_GRP_NAME = "!prdGrpName";
  public static final String FN_SYS_DEP_ADD_ACCT_HLDRS = "!aah";
  public static final String FN_SYS_DEP_TITLE_MAP = "!titleMap";
  public static final String FN_SYS_DEP_INCOMPLETE_FLAG = "!incomplete";
  public static final String FN_SYS_DEP_ACCT_INDEX = "!daIndex";
  public static final String FN_SYS_DEP_ISFUNDED_FLAG = "!isFunded";

  public static final String FN_QUALIFILE_ACCEPTANCE = "qf_ai_acceptance";
  public static final String FN_SYS_QUALIFILE_SCORE = "!qfScore";
  public static final String FN_DEP_IRA_TBL = "iraBeneficiaryT";
  public static final String FN_DEP_IRA_BENE_TITLE = "iraBeneTitleD";
  public static final String FN_DEP_IRA_BENE_SUFFIX = "iraBeneSufD";
  public static final String FN_DEP_IRA_BENE_DIR = "iraBeneDirD";
  public static final String FN_DEP_IRA_BENE_DIR2 = "iraBeneDir2D";
  public static final String FN_DEP_IRA_BENE_TYPE = "iraBeneTypeD";
  public static final String FN_DEP_IRA_BENE_TYPE2 = "iraBeneType2D";
  public static final String FN_DEP_IRA_BENE_STATE = "iraBeneStateD";
  public static final String FN_DEP_IRA_BENE_FIRST = "iraBeneFir";
  public static final String FN_DEP_IRA_BENE_MID = "iraBeneMid";
  public static final String FN_DEP_IRA_BENE_LAST = "iraBeneLast";
  public static final String FN_DEP_IRA_BENE_DOB = "iraBeneDOB";
  public static final String FN_DEP_IRA_BENE_SSN = "iraBeneSSN";
  public static final String FN_DEP_IRA_BENE_DESIGNATION = "iraBeneDesigD";
  public static final String FN_DEP_IRA_BENE_SHARE = "iraBeneShare";

  //oana +
  public static final String FN_FEE_SHOPPABLE = "anFeeShopC";
  public static final String FN_FEE_FREQ = "anFeeFreqD";
  public static final String EMPTY_STRING = "";
  //oana -

  //Product editor
  //
  public static final String FN_PRD_HOEPA_C     = "prdHOEPAC";
  public static final String FN_PRD_HPML_C      = "prdHPMLC";
  public static final String FN_PRD_HOEPA_USAGE = "prdHOEPAUsage";
  public static final String FN_PRD_HOEPA_APOR  = "prdHOEPAApor";
  public static final String FN_PRD_QUALM_C     = "prdQMC";
  
  //Temporary
  public static final String SELECTED_BWR_POSITION = "selPrnPosTemp";
  public static final String FN_READONLY_ADDITIONAL_EMPLOYMENT = "readOnlyAdditionalEmplyment";
  public static final String FN_ADDITIONAL_EMPLOYMENT_CHECKBOX = "atAddEmpC";
  // Discounts and Premiums
  public static final String FN_DISC_PRE_TBL		= "anDisPreT";
  public static final String FN_DISC_PRE_RTTBLID	= "rtTblId";
  public static final String FN_DISC_PRE_OVERC		= "anDisPreOverrideC";
  public static final String FN_DISC_PRE_OVER_USER	= "anDisPreOverrideUser";
  public static final String FN_DISC_PRE_RTFRTBL	= "anRateFromTable";
  public static final String FN_DISC_PRE_FNL_RATE	= "anIntRateFinal";
  public static final String FN_DISC_PRE_DESC		= "anDiscountDesc";
  public static final String FN_DISC_PRE_AMT		= "anDiscountAmt";
  public static final String FN_DISC_PRE_STATC		= "anDiscountStatC";
  public static final String FN_DISC_PRE_EXCL		= "anDiscountExcl";
  public static final String FN_DISC_PRE_POS		= "_anDiscountPosHid";

  // Days To First Payment
  public final static String FN_ENABLE_DAYSTOFIRSTPMT			= "prdEnableDaystoFirstPmtC";
  public final static String FN_MIN_DAYSTOFIRSTPMT				= "prdMinDaystoFirstPmt";
  public final static String FN_MAX_DAYSTOFIRSTPMT				= "prdMaxDaystoFirstPmt";
  public final static String FN_EFCT_DT_DAYSTOFIRSTPMT_DT		= "prdEfctDtDaystoFirstPmtDt";
  public final static String FN_EFCT_DT_DAYSTOFIRSTPMT_TIME		= "prdEfctDtDaystoFirstPmtTime";
  public final static String FN_EFCT_DT_DAYSTOFIRSTPMT_HIST_TBL	= "prdEfctDaystoFirstPmtHistT";
  public final static String FN_DAYSTOFIRSTPMT_DEFAULT_R		= "prdDaystoFirstPmtDefaultR";
  public final static String FN_DAY_OF_MONTH_DAYSTOFIRSTPMT		= "prdDayofMonthDaystoFirstPmt";
  public final static String FN_DEFAULT_NUM_DAYS_DAYSTOFIRSTPMT = "prdDefaultNumDaysDaystoFirstPmt";
  public final static String FN_USER_DAYSTOFIRSTPMT				= "an1stPmtDtOvrUser";
  public final static String FN_OVER_DAYSTOFIRSTPMT				= "an1stPmtDtOvrC";
  public final static String FN_OVER_DAYSTOFIRSTPMT_INST		= "an1stPmtDtOvrInstCHid";
  public final static String FN_OVER_DAYSTOFIRSTPMT_INST_TERM	= "an1stPmtDtOvrInstTermCHid";
  public final static String FN_OVER_DAYSTOFIRSTPMT_BALLOON		= "an1stPmtDtOvrBallonCHid";
  public final static String FN_OVER_DAYSTOFIRSTPMT_PRININT		= "an1stPmtDtOvrPrinIntCHid";
  public final static String FN_OVER_DAYSTOFIRSTPMT_FNMABIWEEK	= "an1stPmtDtOvrFNMABiweekCHid";
  public final static String FN_SYS_DAYSTOFIRSTPMT				= "anDaystoFirstPmt";
  public final static String FN_SYS_MIN_DAYSTOFIRSTPMT			= "anMinDaystoFirstPmt";
  public final static String FN_SYS_MAX_DAYSTOFIRSTPMT			= "anMaxDaystoFirstPmt";
  public final static String FN_SYS_DAYSTOFIRSTPMT_DEFAULT		= "anSysDaystoFirstPmtDefault";
  public final static String FN_SYS_DAYSTOFIRSTPMT_DEFAULT_NR	= "anSysDaystoFirstPmtDefaultNr";

  // Miser Lookup Successful
  public final static String FN_MISER_LOOKUP_SUCC = "atCoreImportSucC";
} // public class CSFieldNames
