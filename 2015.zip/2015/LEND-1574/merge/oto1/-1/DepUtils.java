/**
 * <p>Title: Credisphere</p>
 *
 * <p>Description: This class contains utility methods used for the Deposit Module</p>
 *
 * <p>Copyright: Copyright (c) 2012</p>
 *
 * <p>Company: S1 Corporation</p>
 *
 * @author Len Doerich
 * @version 1.0
 */

package com.xnai.credisphere.deposits;


import com.xnai.credisphere.calcs.FeeCalcs;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import com.xnai.credisphere.cbUtils.CBUtils;
import com.xnai.credisphere.creditBureauAccount.CreditBureauAccount;
import com.xnai.credisphere.dataCache.CSDataCache;
import com.xnai.credisphere.db.DBLogger;
import com.xnai.credisphere.depProduct.DepProduct;
import com.xnai.credisphere.locations.Location;
import com.xnai.credisphere.ruleEditor.RuleSet;
import com.xnai.credisphere.rules.RuleSetEvaluator;
import com.xnai.credisphere.rules.RuleSetResult;
import com.xnai.credisphere.util.CSFieldNames;
import com.xnai.credisphere.util.CSFieldValues;
import com.xnai.credisphere.util.DataCollection;
import com.xnai.credisphere.util.DataEntrySupport;
import com.xnai.credisphere.util.NodeUtils;
import com.xnai.credisphere.vistaPop.VistaPopulator;
import com.xnai.mulder.application.ApplicationHouse;
import com.xnai.mulder.application.ListCodes;
import com.xnai.mulder.dbInterface.DBConnPool;
import com.xnai.mulder.dbInterface.DBErrorLogger;
import com.xnai.mulder.systemCore.AdminGUIManager;
import com.xnai.mulder.systemObject.DataNode;
import com.xnai.mulder.systemObject.SystemDataObject;
import com.xnai.mulder.user.User;
import com.xnai.mulder.user.UserSession;
import com.xnai.mulder.util.ClientUtils;
import com.xnai.mulder.util.DateUtility;
import com.xnai.mulder.util.ExceptionLogger;
import com.xnai.mulder.util.HashtableX;
import com.xnai.mulder.util.StringSupport;
import com.xnai.mulder.util.VectorX;
import com.xnai.mulder.visual.Form;
import com.xnai.mulder.visual.TableRecord;
import com.xnai.mulder.visual.TableTransaction;
//import com.xnai.mulder.util.GeneralToolkit;


public class DepUtils
{
  public static final String PRD_GRP_SESSION_KEY = "PRD_GRP_EDIT";
  public static final String FUNDING_NODES = "FUNDING_LIST";
  public static final String FEE_NODES = "FEE_LIST";
  public static final String POD_NODES = "POD_LIST";
  public static final String IRA_NODES = "IRA_LIST";
  public static final String ADDL_ACCT_HLDR_LIST_KEY = "AAH_LIST";
  public static final String ADDL_ACCT_HLDR_REL_KEY = "AAH_REL_MAP";
  public static final String OVERDRAFT_ASSOC_ACCT_KEY = "OD_ASSOC_ACCT_LIST";

  //private static final GeneralToolkit general = new GeneralToolkit();


  public DepUtils()
  {
  }


  /*
   * populateMainForm
   */
  public static void populateMainForm(String username, Form theForm, SystemDataObject sdo,
                                      HashtableX outFieldsHash, boolean isDefault)
  throws Exception
  {
    List<String> vistaNames = theForm.getVistas();

    populateSpecificVistas(username, vistaNames, sdo, outFieldsHash);

  } // populateMainForm



  /*
   * populateAccountForm
   */
  public static void populateAccountForm(String username, Form theForm, SystemDataObject sdo, DepProduct product,
                                         HashtableX outFieldsHash)
  throws Exception
  {
    String depositType = product.getLoanType();

    VectorX depositVistas = CSDataCache.getDepVistaListManager().getVistaList(depositType);
    if (depositVistas != null)
    {
      VectorX currentVistas = theForm.getVistas();
      depositVistas.addAll(currentVistas);
      theForm.setVistas(depositVistas);
    }

    List<String> vistaNames = theForm.getVistas();

    populateSpecificVistas(username, vistaNames, sdo, outFieldsHash);

  } // populateAccountForm


  public static void populateSpecificVistas(String username, List<String> vistaNames, SystemDataObject sdo,
                                            HashtableX outFieldsHash)
  throws Exception
  {
    User user = User.getUser(username);

    DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);

    for (String vistaName : vistaNames)
    {
      try
      {
        VistaPopulator vp = VistaPopulator.createVistaPopulator(vistaName, username, appNode);
        if (vp != null)
        {
          vp.markDefault();
          vp.populate(outFieldsHash);
        }
      }
      catch (Exception e)
      {
        ExceptionLogger.logException(e);
        throw new Exception("Error populating fields for vista '" + vistaName + "': " + e);
      }

      try
      {
        ClientUtils.populateVistaLists(user.getBaseLocationID(), vistaName, outFieldsHash);
      }
      catch (Exception e)
      {
        ExceptionLogger.logException(e);
        throw new Exception("Error populating vista lists for '" + vistaName + "': " + e);
      }
    }
  }


  public static Map getEffectiveProductOfferGroupIdMap(int locationID, boolean addDelimiter)
  throws SQLException
  {
    String today = DateUtility.getTodaySlashDate();

    List allParentIDs = Location.getVisibleParentLocations(locationID);

    StringBuffer sql = new StringBuffer();
    sql.append("SELECT cDesc, nId FROM xntGroups ");

    if (allParentIDs != null)
    {
      sql.append(Location.create_SQL_WHERE_Clause(allParentIDs));
      sql.append("AND ");
    }
    else
    {
      sql.append("WHERE ");
    }

    sql.append(" cType='DepOffer' AND ");
    sql.append("(dtEffective IS NOT NULL AND dtEffective <= '" + today +
               "') AND ");
    sql.append("(dtExpire IS NULL OR dtExpire >= '" + today + "')");
    sql.append(" ORDER BY nId");

    Statement stmt = null;
    Map map = new LinkedHashMap();

    try
    {
      Connection con = DBConnPool.getConnection();
      stmt = con.createStatement();
      ResultSet rs = stmt.executeQuery(sql.toString());

      String id = null, desc = null;

      while (rs.next())
      {
        id = rs.getString("nId");
        desc = rs.getString("cDesc");

        map.put(addDelimiter ? "pg:" + id : id, desc == null ? id : desc);
      }
    }
    catch (SQLException e)
    {
      DBErrorLogger.log("Executing " + sql + ": " + e);
      //throw e;
    }
    finally
    {
      DBConnPool.closeConnection(stmt);
    }

    return map;
  }


  public static Map<String, String[]> getProductGroupDetails(String groupID)
  throws SQLException
  {
    StringBuilder sql = new StringBuilder();
    sql.append("SELECT xntProductGroups.nProdId, xntGroups.cDesc, xntProducts.cTitle ").
        append("FROM xntProductGroups, xntGroups, xntProducts ").
        append("WHERE xntProductGroups.cType = 'DepOffer' AND xntProductGroups.nId = ").
        append(groupID).append(" AND xntProductGroups.nId = xntGroups.nId ").
        append(" AND xntProductGroups.nProdId = xntProducts.nProdId ORDER BY xntProducts.nProdId");

    Statement stmt = null;
    Map<String, String[]> details = new LinkedHashMap<String, String[]>();

    try
    {
      Connection con = DBConnPool.getConnection();
      stmt = con.createStatement();
      ResultSet rs = stmt.executeQuery(sql.toString());

      // The group description will be the same for all records returned.
      //
      String prodID, groupDesc, prodTitle;

      while (rs.next())
      {
        prodID = rs.getString("nProdID");
        groupDesc = rs.getString("cDesc");
        prodTitle = rs.getString("cTitle");

        details.put(prodID, new String[]{ prodTitle, groupDesc });
      }
    }
    catch (SQLException e)
    {
      DBLogger.log("While executing: " + sql.toString() + ": " + e);
      throw e;
    }
    finally
    {
      DBConnPool.closeConnection(stmt);
    }

    return details;
  }


  public static void saveApplicationData(String username, SystemDataObject sdo, HashtableX inFields)
  {
    //general.errLog( "START saveApplicationData(String username, SystemDataObject sdo, HashtableX inFields)", "DepUtil.log" );
    DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);
    HashtableX appData = appNode.getFieldData(username);

    HashtableX appFields = NodeUtils.extractDataHash(NodeUtils.APP_DN_TYPE, inFields);
    DataCollection.concatenateAppReceivedDateTime(appFields);

    appData.putAll(appFields);

    appNode.setFieldData(username, appData);
    appNode.setSystemData(username, CSFieldNames.FN_APP_TYPE, "d");

    // add/edit new bank secrecy node, should only be one node
    //
    try
    {
      //general.errLog( "inFields: "+inFields, "DepUtil.log" );
      saveBankSecrecyData( username, sdo, inFields, appNode );
    }
    catch( Exception bs )
    {
      ExceptionLogger.logException( bs );
    }

    //general.errLog( "END saveApplicationData(String username, SystemDataObject sdo, HashtableX inFields)", "DepUtil.log" );
  }


  public static void saveBankSecrecyData( String username, SystemDataObject sdo, HashtableX inFields, DataNode appNode ) throws Exception
  {
    //general.errLog( "START saveBankSecrecyData( String username, SystemDataObject sdo, HashtableX inFields, DataNode appNode )", "DepUtil.log" );

    HashtableX bankSecrecyFields = NodeUtils.extractDataHash( NodeUtils.DEP_BANK_SECRECY_DN_TYPE, inFields );
    //general.errLog( "bankSecrecyFields: " + bankSecrecyFields, "DepUtil.log" );
    if( bankSecrecyFields != null && !bankSecrecyFields.isEmpty() )
    {
      DataNode bankSecNode = appNode.getFirstReference( NodeUtils.DEP_BANK_SECRECY_DN_TYPE );
      //general.errLog( "bankSecNode: " + bankSecNode, "DepUtil.log" );
      if( bankSecNode != null )
      {
        bankSecNode.setFieldData( username, bankSecrecyFields );
      }
      else
      {
        bankSecNode = sdo.createDataNode( username, NodeUtils.DEP_BANK_SECRECY_DN_TYPE );
        bankSecNode.setFieldData( username, bankSecrecyFields );
        appNode.addReference( bankSecNode );
      }
    }

    //general.errLog( "END saveBankSecrecyData( String username, SystemDataObject sdo, HashtableX inFields, DataNode appNode )", "DepUtil.log" );
  }


  public static void saveApplicantData(String username, int applicantIndex, SystemDataObject sdo,
                                       HashtableX inFields)
  throws Exception
  {
    saveApplicantData(username, applicantIndex, sdo, inFields, true);
  }

  public static void saveApplicantData(String username, int applicantIndex, SystemDataObject sdo,
                                       HashtableX inFields, boolean replace)
  throws Exception
  {
    DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);

    HashtableX applicantFields = NodeUtils.extractDataHash(NodeUtils.BWR_DN_TYPE, inFields);

    DataCollection.addBorrowersAgeToHash(applicantFields);
    DataCollection.addBorrowersMiddleInitial(applicantFields);
    DataCollection.copyBorrowerMailingAddress(applicantFields);

    DataNode applicant;
    if (applicantIndex == -1)
    {
      applicant = sdo.createDataNode(username, NodeUtils.BWR_DN_TYPE);
      appNode.addReference(applicant);
    }
    else
    {
      applicant = appNode.getReference(NodeUtils.BWR_DN_TYPE, applicantIndex);
      if (applicant == null)
      {
        throw new Exception("Unable to locate applicant data node at index '" + applicantIndex + "'");
      }

      if (!replace)
      {
        HashtableX bwrFields = applicant.getFieldData(username);
        bwrFields.putAll(applicantFields);
        applicantFields = bwrFields;
      }
    }

    List list = appNode.getEffectiveReferences(NodeUtils.BWR_DN_TYPE);
    applicantFields.put(CSFieldNames.FN_BWR_TYPE, (list.size() == 1 || applicantIndex == 0) ?
                        CSFieldValues.FV_APPLICANT : CSFieldValues.FV_COAPPLICANT);

    applicant.setFieldData(username, applicantFields);
  }


  public static void saveProductRequestData(String username, int depAccountIndex, SystemDataObject sdo, HashtableX inFields)
  throws Exception
  {
    //general.errLog( "START saveProductRequestData(String username, int depAccountIndex, SystemDataObject sdo, HashtableX inFields)", "DepAcctPrdSave.log" );
    //general.errLog( "inFields: " + inFields, "DepAcctPrdSave.log" );

    DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);

    HashtableX depAcctFields = NodeUtils.extractDataHash(NodeUtils.DEP_ACCOUNT_DN_TYPE, inFields);
    //general.errLog( "depAcctFields: "+depAcctFields, "DepAcctPrdSave.log" );

    boolean isProductGroupSave = false;
    boolean isNewProduct = false;

    DataNode depAccountNode;
    if (depAccountIndex == -1)
    {
      depAccountNode = sdo.createDataNode(username, NodeUtils.DEP_ACCOUNT_DN_TYPE);
      appNode.addReference(depAccountNode);

      isNewProduct = true;
    }
    else
    {
      // Check and see if we are saving a product group.  If we are, then we would be updating
      // the temporary depAccount node that is stored in the list within the user session.  I'm
      // using the _bwrPOSHid to store a code that tells me if we are saving a product from a group.
      //
      String bwrPosHid = (String)inFields.get(CSFieldNames.FN_BWR_POS_HID);
      if (bwrPosHid != null && bwrPosHid.equals("pg"))
      {
        List<DataNode> individualProducts = (List<DataNode>)inFields.remove(DepUtils.PRD_GRP_SESSION_KEY);
        depAccountNode = individualProducts.get(depAccountIndex);
        if (depAccountNode == null)
        {
          throw new Exception("Unable to locate temp deposit account data node at index '" + depAccountIndex + "'");
        }

        isProductGroupSave = true;
      }
      else
      {
        depAccountNode = appNode.getReference(NodeUtils.DEP_ACCOUNT_DN_TYPE, depAccountIndex);
        if (depAccountNode == null)
        {
          throw new Exception("Unable to locate deposit account data node at index '" + depAccountIndex + "'");
        }
      }
    }

    // LEND-134 for steve and chui added 8-20-12
    // wfeAdd - need to avoid calling into the is product group save if called from the WFE
    //
    boolean wfeAdd = false;
    String wfeProductKey = ( String ) depAcctFields.get( "daWfePrdKey" );
    if( wfeProductKey != null && wfeProductKey.trim().length() > 0 )
    {
      depAccountNode.setSystemData( username, "!wfePrdKey", wfeProductKey );
      wfeAdd = true;

      // Store the additional account holder list and title map in the deposit account data node.
      //
      VectorX addlAcctHolders = ( VectorX ) depAcctFields.get( "daWfePartiesM" );
      //general.errLog( "addlAcctHolders: " + addlAcctHolders, "DepAcctPrdSave.log" );
      if( addlAcctHolders != null )
      {
        depAccountNode.setSystemData( username, CSFieldNames.FN_SYS_DEP_ADD_ACCT_HLDRS, addlAcctHolders );
      }
      else
      {
        depAccountNode.removeSystemData( CSFieldNames.FN_SYS_DEP_ADD_ACCT_HLDRS );
      }

      HashtableX wfeTitleMap = ( HashtableX ) depAcctFields.get( "daWfeTitleMap" );
      //general.errLog( "wfeTitleMap: " + wfeTitleMap, "DepAcctPrdSave.log" );
      if( wfeTitleMap != null )
      {
        depAccountNode.setSystemData( CSFieldNames.FN_SYS_DEP_TITLE_MAP, wfeTitleMap );
      }
      else
      {
        depAccountNode.removeSystemData( CSFieldNames.FN_SYS_DEP_TITLE_MAP );
      }

      // process overdraft product. Add the depODLinkAcct node to the depAcctNode
      //
      // ht.put( "daOvrDrftWfePrdList", overdraftWfePrdKeyList );
      //
      List<String> daOvrDrftWfePrdList = ( List<String> )depAcctFields.get("daOvrDrftWfePrdList");
      //general.errLog( "daOvrDrftWfePrdList: " + daOvrDrftWfePrdList, "DepAcctPrdSave.log" );
      if( daOvrDrftWfePrdList != null )
      {
        for( String ovrDrftPrdKey : daOvrDrftWfePrdList )
        {
          // check for existing dep accounts that should be in the sdo and tie the existing
          // accounts into this overdraft product account
          //
          List<DataNode> depAcctList = appNode.getEffectiveReferences( NodeUtils.DEP_ACCOUNT_DN_TYPE );
          for( DataNode depAcctNode: depAcctList )
          {
            //general.errLog( "ovrDrftPrdKey: " + ovrDrftPrdKey, "DepAcctPrdSave.log" );

            String wfePrdKey = (String)depAcctNode.getSystemData( "!wfePrdKey" );
            //general.errLog( "wfePrdKey: " + wfePrdKey, "DepAcctPrdSave.log" );

            if( wfePrdKey != null && wfePrdKey.trim().equals( ovrDrftPrdKey ) )
            {
              int index = depAcctNode.getIndex();
              //general.errLog( "index: " + index, "DepAcctPrdSave.log" );

              DataNode actualAssocAcctNode = sdo.createDataNode( username, NodeUtils.DEP_OD_LINK_DN_TYPE );
              actualAssocAcctNode.setSystemData( "!daIndex", String.valueOf( index ) );
              depAccountNode.addReference( actualAssocAcctNode );
            }
          }
        }
      }
      //general.errLog( "PAST daOvrDrftWfePrdList: " + daOvrDrftWfePrdList, "DepAcctPrdSave.log" );

    }

    // Check for term fields (indicates we are saving a CD product).  If the term is in years, we'll convert it
    // to months.  Either way, we'll create a system field for the term value in months.
    //
    if (depAcctFields.containsKey("daTerm") && depAcctFields.containsKey("daTermPrdD"))
    {
      String termPeriod = (String)depAcctFields.get("daTermPrdD");
      String term = (String)depAcctFields.get("daTerm");

      int termInMonths = 0;
      if (termPeriod.equals("y"))
      {
        termInMonths = 12 * Integer.parseInt(term);
      }
      else if (termPeriod.equals("m"))
      {
        termInMonths = Integer.parseInt(term);
      }

      depAccountNode.setSystemData(username, CSFieldNames.FN_TERM_IN_MONTHS, String.valueOf(termInMonths));
    }

    //general.errLog( "depAccountNode.setFieldData(username, depAcctFields): " + depAcctFields, "DepAcctPrdSave.log" );
    depAccountNode.setFieldData(username, depAcctFields);
    depAccountNode.setSystemData(username, "!completed", "true");

    // If we are saving a product from a product grouping, don't formalize the temporary funding
    // data nodes yet.  We will do this when the whole group is saved (SavePG opcode).
    // This also applies to the additional account holder/relationship information.
    //
    if (! isProductGroupSave && ! wfeAdd )
    {
      User user = User.getUser(username);
      UserSession session = user.getUserSession();

      // Store the temporary funding data nodes that were collected during the data entry process.
      //
      String productID = (String)inFields.get(CSFieldNames.FN_DEP_PROD_ID);
      List<DataNode> fundingNodes = (List<DataNode>)session.getAttribute(FUNDING_NODES + ":" + productID);
      if (fundingNodes != null)
      {
        // Clear any funding nodes that currently exist in the deposit account node.
        //
        List<DataNode> fundingList = depAccountNode.getEffectiveReferences(NodeUtils.DEP_FUNDING_DN_TYPE);
        for (DataNode fundingNode : fundingList)
        {
          fundingNode.delete();
        }

        // Now create the real data nodes for the funding methods collected.
        //
        for (DataNode fundingNode : fundingNodes)
        {
          DataNode actualFundingNode = sdo.createDataNode(username, NodeUtils.DEP_FUNDING_DN_TYPE);

          actualFundingNode.setFieldData(username, fundingNode.getFieldData(""));
          actualFundingNode.setSystemData(fundingNode.getSystemData());

          depAccountNode.addReference(actualFundingNode);
        }

        session.removeAttribute(FUNDING_NODES + ":" + productID);
      }

      // Store the temporary fee data nodes that were collected during the data entry process.
      //
      List<DataNode> feeNodes = (List<DataNode>)session.getAttribute(FEE_NODES + ":" + productID);
      if (feeNodes != null)
      {
        // Clear any fee nodes that currently exist in the deposit account node.
        //
        List<DataNode> feeList = depAccountNode.getEffectiveReferences(NodeUtils.FEE_DN_TYPE);
        for (DataNode feeNode : feeList)
        {
          feeNode.delete();
        }

        // Now create the real data nodes for the funding methods collected.
        //
        for (DataNode feeNode : feeNodes)
        {
          DataNode actualFeeNode = sdo.createDataNode(username, NodeUtils.FEE_DN_TYPE);

          actualFeeNode.setFieldData(username, feeNode.getFieldData(""));
          actualFeeNode.setSystemData(feeNode.getSystemData());

          depAccountNode.addReference(actualFeeNode);
        }

        session.removeAttribute(FEE_NODES + ":" + productID);
      }


      // Store the temporary payable on death data nodes that were collected during the data entry process.
      //
      List<DataNode> podNodes = (List<DataNode>)session.getAttribute(POD_NODES + ":" + productID);
      if (podNodes != null)
      {
        // Clear any payable on death nodes that currently exist in the deposit account node.
        //
        List<DataNode> podList = depAccountNode.getEffectiveReferences(NodeUtils.DEP_POD_DN_TYPE);
        for (DataNode podNode : podList)
        {
          podNode.delete();
        }

        // Now create the real data nodes for the payable on death methods collected.
        //
        for (DataNode podNode : podNodes)
        {
          DataNode actualPODNode = sdo.createDataNode(username, NodeUtils.DEP_POD_DN_TYPE);

          actualPODNode.setFieldData(username, podNode.getFieldData(""));
          actualPODNode.setSystemData(podNode.getSystemData());

          depAccountNode.addReference(actualPODNode);
        }

        session.removeAttribute(POD_NODES + ":" + productID);
      }

      List<DataNode> iraNodes = (List<DataNode>)session.getAttribute(IRA_NODES + ":" + productID);
      if (iraNodes != null)
      {
        // Clear any payable on death nodes that currently exist in the deposit account node.
        //
        List<DataNode> iraList = depAccountNode.getEffectiveReferences(NodeUtils.DEP_IRA_DN_TYPE);
        for (DataNode iraNode : iraList)
        {
          iraNode.delete();
        }

        // Now create the real data nodes for the payable on death methods collected.
        //
        for (DataNode iraNode : iraNodes)
        {
          DataNode actualIRANode = sdo.createDataNode(username, NodeUtils.DEP_IRA_DN_TYPE);

          actualIRANode.setFieldData(username, iraNode.getFieldData(""));
          actualIRANode.setSystemData(iraNode.getSystemData());

          depAccountNode.addReference(actualIRANode);
        }

        session.removeAttribute(IRA_NODES + ":" + productID);
      }
      // Store the temporary associated accounts that were collected during data entry.  Associated
      // accounts are applicable only for overdraft products.
      //
      List<DataNode> associatedAccounts = (List<DataNode>)session.getAttribute(OVERDRAFT_ASSOC_ACCT_KEY + ":" + productID);
      if (associatedAccounts != null)
      {
        // Clear any associated account nodes that currently exist in the overdraft deposit account node.
        //
        List<DataNode> assocAcctList = depAccountNode.getEffectiveReferences(NodeUtils.DEP_OD_LINK_DN_TYPE);
        for (DataNode assocAcct : assocAcctList)
        {
          assocAcct.delete();
        }

        // Now create the real data nodes for the associated accounts.
        //
        for (DataNode assocAcct : associatedAccounts)
        {
          DataNode actualAssocAcctNode = sdo.createDataNode(username, NodeUtils.DEP_OD_LINK_DN_TYPE);

          actualAssocAcctNode.setFieldData(username, assocAcct.getFieldData(""));
          actualAssocAcctNode.setSystemData(assocAcct.getSystemData());

          depAccountNode.addReference(actualAssocAcctNode);
        }

        session.removeAttribute(OVERDRAFT_ASSOC_ACCT_KEY + ":" + productID);
      }

      // Store the additional account holder list and title map in the deposit account data node.
      // If no data is in the session, then remove the fields (user may have deleted all account
      // holders on the product).
      //
      List<String> aahList = (List<String>)session.getAttribute(ADDL_ACCT_HLDR_LIST_KEY + ":" + productID);
      if (aahList != null)
      {
        depAccountNode.setSystemData(CSFieldNames.FN_SYS_DEP_ADD_ACCT_HLDRS, aahList);
      }
      else
      {
        depAccountNode.removeSystemData(CSFieldNames.FN_SYS_DEP_ADD_ACCT_HLDRS);
      }

      Map<String, String> aahTitleMap = (Map<String, String>)session.getAttribute(ADDL_ACCT_HLDR_REL_KEY +
                                                                                  ":" + productID);
      if (aahTitleMap != null)
      {
        depAccountNode.setSystemData(CSFieldNames.FN_SYS_DEP_TITLE_MAP, aahTitleMap);
      }
      else
      {
        depAccountNode.removeSystemData(CSFieldNames.FN_SYS_DEP_TITLE_MAP);
      }

      session.removeAttribute(ADDL_ACCT_HLDR_LIST_KEY + ":" + productID);
      session.removeAttribute(ADDL_ACCT_HLDR_REL_KEY + ":" + productID);
    }

    // If we are saving a new product, then create the default fees now.
    //
    if (isNewProduct)
    {
      DataEntrySupport.createDefaultFeeNodes(sdo, depAccountNode, username);
    }

    // Update fees if there are any on this product.
    //
    appNode.setSystemData(CSFieldNames.FN_SYS_DEP_CUR_DA_PTR, String.valueOf(depAccountNode.getIndex()));
    try
    {
      FeeCalcs.recalculateFees(appNode, null);
    }
    catch (Exception e)
    {
      ExceptionLogger.logException(e);
    }
    appNode.removeSystemData(CSFieldNames.FN_SYS_DEP_CUR_DA_PTR);

    //general.errLog( "END saveProductRequestData(String username, int depAccountIndex, SystemDataObject sdo, HashtableX inFields)", "DepAcctPrdSave.log" );
  }


  public static TableTransaction generateProductRequestTable(DataNode appNode)
  {
    VectorX cols = new VectorX();
    cols.add("");
    cols.add("ID   ");
    cols.add("Product Name              ");
    cols.add("Group        ");
    cols.add("Amount    ");
    cols.add("Interest Rate");
    cols.add("Term");

    VectorX keys = new VectorX();
    keys.add("true");
    keys.add("true");
    keys.add("false");
    keys.add("false");
    keys.add("false");
    keys.add("false");
    keys.add("false");

    TableTransaction tt = new TableTransaction();
    tt.setFields(cols);
    tt.setKeyFlags(keys);

    VectorX records = new VectorX();

    DecimalFormat currencyFormat = new DecimalFormat("$#.00");
    DecimalFormat rateFormat = new DecimalFormat("#.00");

    List<DataNode> depAccounts = appNode.getEffectiveReferences(NodeUtils.DEP_ACCOUNT_DN_TYPE);
    for (DataNode depAccount : depAccounts)
    {
      TableRecord tr = new TableRecord();
      tr.addColumnData(String.valueOf(depAccount.getIndex()));

      String productID = (String)depAccount.getFieldData("", CSFieldNames.FN_DEP_PROD_ID);
      tr.addColumnData(productID);

      DepProduct product = CSDataCache.getDepProductManager().getProduct(productID);
      tr.addColumnData(product != null ? product.getName() : "?");

      String groupName = (String)depAccount.getSystemData("!prdGrpName");
      tr.addColumnData(groupName != null ? groupName : "");

      String amount = (String)depAccount.getFieldData("", CSFieldNames.FN_DEP_OPEN_AMT);
      tr.addColumnData(currencyFormat.format(StringSupport.strToDouble(amount)));

      String intRate = (String)depAccount.getFieldData("", CSFieldNames.FN_DEP_INT_RATE);
      tr.addColumnData(intRate != null ? rateFormat.format(Double.parseDouble(intRate)) + "%" : "");

      String term = (String)depAccount.getFieldData("", "daTerm");
      String termPrd = (String)depAccount.getFieldData("", "daTermPrdD");
      tr.addColumnData(term != null ? (term + termPrd) : "");

      /*
      String completion = (String)depAccount.getSystemData("!completed");
      tr.addColumnData(completion != null && completion.equals("true") ? "Collected" : "Needed");

      tr.setRowColor(completion != null && completion.equals("true") ? "0000FF00" : "0000FFFF");
      */

      records.add(tr);
    }

    tt.setRecords(records);

    return tt;
  }


  public static TableTransaction generateProductGroupRequestTable(List<DataNode> productList)
  {
    VectorX cols = new VectorX();
    cols.add("");
    cols.add("ID   ");
    cols.add("Product Name                        ");
    cols.add("Information");

    VectorX keys = new VectorX();
    keys.add("true");
    keys.add("true");
    keys.add("false");
    keys.add("false");

    TableTransaction tt = new TableTransaction();
    tt.setFields(cols);
    tt.setKeyFlags(keys);

    VectorX records = new VectorX();

    DataNode productNode;
    for (int i = 0, c = productList.size(); i < c; ++i)
    {
      productNode = productList.get(i);

      TableRecord tr = new TableRecord();
      tr.addColumnData(String.valueOf(i));

      String productID = (String)productNode.getFieldData("", CSFieldNames.FN_DEP_PROD_ID);
      tr.addColumnData(productID);

      DepProduct product = CSDataCache.getDepProductManager().getProduct(productID);
      tr.addColumnData(product != null ? product.getName() : "?");

      String completion = (String)productNode.getSystemData("!completed");
      tr.addColumnData(completion != null && completion.equals("true") ? "Collected" : "Needed");

      tr.setRowColor(completion != null && completion.equals("true") ? "0000FF00" : "0000FFFF");

      records.add(tr);
    }

    tt.setRecords(records);

    return tt;
  }


  public static String findHighestPriorityAccount(String username, List<DataNode> depAccounts)
  throws Exception
  {
    DataNode highestPriorityAccount = null;
    int highestPriority = -1;

    for (DataNode depAccount : depAccounts)
    {
      String productID = (String)depAccount.getFieldData(username, CSFieldNames.FN_DEP_PROD_ID);
      DepProduct product = CSDataCache.getDepProductManager().getProduct(productID);
      if (product == null)
      {
        throw new Exception("Unable to load product for ID: " + productID + " [depAccount: " + depAccount.getIndex() + "]");
      }

      if (highestPriorityAccount == null)
      {
        highestPriorityAccount = depAccount;
        highestPriority = product.getPriority();
      }
      else
      {
        // Higher priority = lower number.
        //
        if (product.getPriority() < highestPriority)
        {
          highestPriorityAccount = depAccount;
          highestPriority = product.getPriority();
        }
      }
    }

    // Return the product ID of the highest priority product.  This becomes our "alpha" product.
    //
    return (String)highestPriorityAccount.getFieldData(username, CSFieldNames.FN_DEP_PROD_ID);
  }


  public static List<DepProduct> sortProductsByPriority(String username, List<DataNode> depAccounts)
  throws Exception
  {
    List<DepProduct> products = new ArrayList<DepProduct>();

    for (DataNode depAccount : depAccounts)
    {
      String productID = (String)depAccount.getFieldData(username, CSFieldNames.FN_DEP_PROD_ID);
      DepProduct product = CSDataCache.getDepProductManager().getProduct(productID);
      if (product == null)
      {
        throw new Exception("Unable to load product for ID: " + productID + " [depAccount: " + depAccount.getIndex() + "]");
      }

      if (products.isEmpty())
      {
        products.add(product);
      }
      else
      {
        int position = 0;

        for (DepProduct depProduct : products)
        {
          if (depProduct.getPriority() < product.getPriority()) position++;
        }

        products.add(position,product);
      }
    }

    return products;
  }


  public static VectorX getCreditBureauProductListing(String username, List<DataNode> depAccounts, int branchId)
  throws Exception
  {
    VectorX creditBureauProductListing = new VectorX();

    List<DepProduct> products = sortProductsByPriority(username, depAccounts);

    Set<String> cbSet = new HashSet<String>();

    Set cbAccountTypes = null;
    Iterator it = null;
    String bureauType = null;
    CreditBureauAccount cbAccount = null;

    for (DepProduct depProduct : products)
    {
      cbAccountTypes = depProduct.getCBAccountTypes();

      if (cbAccountTypes != null && !cbAccountTypes.isEmpty())
      {
        it = cbAccountTypes.iterator();

        while (it.hasNext())
        {
          bureauType = (String)it.next();

          if (!cbSet.contains(bureauType))
          {
            try
            {
              cbAccount = CBUtils.loadCBAccount(CBUtils.translateBureau(bureauType), depProduct, branchId);

              if(cbAccount != null)
              {
                cbSet.add(bureauType);
                creditBureauProductListing.add(String.valueOf(depProduct.getID())+ ':' + bureauType +
                                                              ClientUtils.TOKEN + bureauType);
              }

            }
            catch (Exception e)
            {
              e.printStackTrace();
              // this is a collection of valid accounts, so if it fails, do nothing.
            }
          }
        }
      }
    }

    return creditBureauProductListing;
  }


  public static TableTransaction generateFundingTable(List<DataNode> fundings, Map<String, String> fundingTable)
  {
    TableTransaction tt = new TableTransaction();

    tt.getFields().add("");
    tt.getFields().add("Funding Method             ");
    tt.getFields().add("Date                ");
    tt.getFields().add("Amount       ");

    tt.getKeyFlags().add("true");
    tt.getKeyFlags().add("false");
    tt.getKeyFlags().add("false");
    tt.getKeyFlags().add("false");

    if (fundings != null)
    {
      int indexInList = 0;

      for (DataNode fundingNode : fundings)
      {
        TableRecord tr = new TableRecord();
        tr.addColumnData(String.valueOf(indexInList++));

        String fundType = (String)fundingNode.getFieldData("", CSFieldNames.FN_DEP_FUNDING_TYPE);
        String fundDesc = fundingTable.get(fundType);
        if (fundDesc == null) fundDesc = "";
        tr.addColumnData(fundDesc);

        String fundDt = (String)fundingNode.getFieldData("", CSFieldNames.FN_DEP_FUNDING_DATE);
        if (fundDt == null) fundDt = "";
        tr.addColumnData(fundDt);

        String fundAmt = (String)fundingNode.getFieldData("", CSFieldNames.FN_DEP_FUNDING_AMT);
        DecimalFormat df = new DecimalFormat("$#.00");
        tr.addColumnData(df.format(Double.parseDouble(fundAmt)));

        tt.getRecords().add(tr);
      }
    }

    return tt;
  }

  //oana +

  public static TableTransaction generateFeeTable(List<DataNode> fees, String username)//oana add username ok????
  {
	  TableTransaction tt = new TableTransaction();
	  tt.getFields().add("");
	  tt.getFields().add("Code   ");
	  tt.getFields().add("Fee Description               ");
	  tt.getFields().add("Amount  ");
	  tt.getFields().add("Frequency");

	  tt.getKeyFlags().add("true");//oana getKeyFlags() instead of getKeys()
	  tt.getKeyFlags().add("false");
	  tt.getKeyFlags().add("false");
	  tt.getKeyFlags().add("false");
	  tt.getKeyFlags().add("false");

	  if (fees != null)
	  {
	    String field;
	    TableRecord tr;
	    double totalFees = 0.0;
	    DecimalFormat df = new DecimalFormat("##0.00");
	    int indexInList = 0;

	    for (DataNode fee : fees)
	    {
	      tr = new TableRecord();

	      // Fee Index (key)
	      //
        tr.addColumnData(String.valueOf(indexInList++));

	      // Fee Code
	      //
	      field = (String)fee.getFieldData(username, CSFieldNames.FN_FEE_CODE);
	      tr.addColumnData(field != null ? field : "");

	      // Fee Description
	      //
	      field = (String)fee.getFieldData(username, CSFieldNames.FN_FEE_DESC);
	      tr.addColumnData(field != null ? field : "");

	      // Fee Amount
	      //
	      field = (String)fee.getFieldData(username, CSFieldNames.FN_FEE_AMT);//oana FN_FEE_AMT instead of FN_FEE_ACT ???
	      double feeAmt = StringSupport.strToDouble(field);
	      tr.addColumnData(df.format(feeAmt));
	      totalFees += feeAmt;

	      // Frequency
	      //
	      field = (String)fee.getFieldData(username, CSFieldNames.FN_FEE_FREQ);
	      tr.addColumnData(field != null ? field : "");

	      tt.getRecords().add(tr);
	      tr = null;
	    }

	    // Add the row for the total fees.
	    //
	    tr = new TableRecord();
	    tr.addColumnData(CSFieldNames.EMPTY_STRING);
	    tr.addColumnData(CSFieldNames.EMPTY_STRING);
	    tr.addColumnData("Totals");
	    tr.addColumnData(df.format(totalFees));
	    tr.addColumnData(CSFieldNames.EMPTY_STRING);
	    tt.getRecords().add(tr);
	  }

	  return tt;

  }

  //oana -

  public static Map<String, String> getFundingTypes(String productType)
  {
    Map<String, String> fundingTypes = new LinkedHashMap<String, String>();
    if (productType != null && productType.equals("OD"))
    {
      fundingTypes.put(CSFieldValues.FV_DEP_FUND_TYPE_OVERDRAFT, "Overdraft");
    }
    else
    {
      fundingTypes.put(CSFieldValues.FV_DEP_FUND_TYPE_CASH_CHECKS, "Cash and Checks");
//      fundingTypes.put(CSFieldValues.FV_DEP_FUND_TYPE_ONLINE, "Online");
    }

    return fundingTypes;
  }

  public static TableTransaction generatePODTable(List<DataNode> pods)
  {
    TableTransaction tt = new TableTransaction();

    tt.getFields().add("");
    tt.getFields().add("Last Name              ");
    tt.getFields().add("First Name             ");
    tt.getFields().add("Percentage");

    tt.getKeyFlags().add("true");
    tt.getKeyFlags().add("false");
    tt.getKeyFlags().add("false");
    tt.getKeyFlags().add("false");

    if (pods != null)
    {
      int indexInList = 0;

      for (DataNode podNode : pods)
      {
        TableRecord tr = new TableRecord();
        tr.addColumnData(String.valueOf(indexInList++));

        String podFirstName = (String)podNode.getFieldData("", CSFieldNames.FN_DEP_POD_BENE_FIRST);
        if (podFirstName == null) podFirstName = "";
        tr.addColumnData(podFirstName);

        String podLastName = (String)podNode.getFieldData("", CSFieldNames.FN_DEP_POD_BENE_LAST);
        if (podLastName == null) podLastName = "";
        tr.addColumnData(podLastName);

        String podShare = (String)podNode.getFieldData("", CSFieldNames.FN_DEP_POD_BENE_SHARE);
        if (podShare == null) podShare = "";
        tr.addColumnData(podShare);

        tt.getRecords().add(tr);
      }
    }

    return tt;
  }

  public static TableTransaction generateIRATable(List<DataNode> iras)
  {
    TableTransaction tt = new TableTransaction();

    tt.getFields().add("");
    tt.getFields().add("Last Name              ");
    tt.getFields().add("First Name             ");
    tt.getFields().add("Type        ");
    tt.getFields().add("Percentage");

    tt.getKeyFlags().add("true");
    tt.getKeyFlags().add("false");
    tt.getKeyFlags().add("false");
    tt.getKeyFlags().add("false");
    tt.getKeyFlags().add("false");

    if (iras != null)
    {
      int indexInList = 0;

      for (DataNode iraNode : iras)
      {
        TableRecord tr = new TableRecord();
        tr.addColumnData(String.valueOf(indexInList++));

        String iraLastName = (String)iraNode.getFieldData("", CSFieldNames.FN_DEP_IRA_BENE_LAST);
        if (iraLastName == null) iraLastName = "";
        tr.addColumnData(iraLastName);

        String iraFirstName = (String)iraNode.getFieldData("", CSFieldNames.FN_DEP_IRA_BENE_FIRST);
        if (iraFirstName == null) iraFirstName = "";
        tr.addColumnData(iraFirstName);

        String iraDesignation = (String)iraNode.getFieldData("", CSFieldNames.FN_DEP_IRA_BENE_DESIGNATION);
        if (iraDesignation == null) iraDesignation = "";
        tr.addColumnData(iraDesignation);

        String iraShare = (String)iraNode.getFieldData("", CSFieldNames.FN_DEP_IRA_BENE_SHARE);
        if (iraShare == null) iraShare = "0%";
        tr.addColumnData(iraShare);

        tt.getRecords().add(tr);
      }
    }

    return tt;
  }

  public static void populateCreditReportScoreTable (DataNode reportNode, Map fields)
  {
    TableTransaction tt = new TableTransaction();

    tt.getFields().add("");
    tt.getFields().add("Model                      ");
    tt.getFields().add("Score");

    tt.getKeyFlags().add(CSFieldValues.TRUE_STRING);
    tt.getKeyFlags().add(CSFieldValues.FALSE_STRING);
    tt.getKeyFlags().add(CSFieldValues.FALSE_STRING);

    if (reportNode != null)
    {
      List<DataNode> scoreNodes = reportNode.getReferences(NodeUtils.SCR_DN_TYPE);

      if (scoreNodes != null)
      {
        TableRecord tr;
        String str;

        for (DataNode scoreNode : scoreNodes)
        {
          tr = new TableRecord();

          tr.addColumnData(String.valueOf(reportNode.getIndex()) + ':' + scoreNode.getIndex());
          str = (String)scoreNode.getFieldData(CSFieldValues.EMPTY_STRING, "cb_online_score_used");
          tr.addColumnData(str == null ? CSFieldValues.EMPTY_STRING : str);
          str = (String)scoreNode.getFieldData(CSFieldValues.EMPTY_STRING, "cb_online_score");
          tr.addColumnData(str == null ? CSFieldValues.EMPTY_STRING : str);
          tt.getRecords().add(tr);
        }
      }
    }

    fields.put("cbAtScoreT", tt);
  }


  /**
   * This method determines what applicants (indicated by node index) are eligible based on
   * the execution of an eligibility rule set.  This is used to determine conditional execution
   * of services (e.g. ChexSystems, Credit Bureau pull) on an applicant basis.
   *
   * @param ruleSet
   * @param evaluator
   * @return
   */
  public static List<DataNode> determineEligibleApplicantsFromRuleEvaluation(DataNode appNode, RuleSet ruleSet,
                                                                             RuleSetEvaluator evaluator)
  {
    List<DataNode> eligibleApplicants = new ArrayList<DataNode>();

    // Each rule defined in the RuleSet will return a list of tripped applicants.
    // In order to determine if an applicant is eligible we need 2 different algorithms, one
    // if the rule set is setup for eligible if Any of the rule items are tripped, and another
    // if the set is setup for eligible if All of the rule items are tripped.
    //

    // This block is just for printing output.
    //
    List<RuleSetResult> trippedResults = evaluator.getTrippedResults();
    for (RuleSetResult result : trippedResults)
    {
      AdminGUIManager.displayE("Code: " + result.getCode());
      List<String> tripList = result.getTripList();
      AdminGUIManager.displayE("TripList: " + tripList);
    }
    // End just for print

    List<DataNode> applicants = appNode.getEffectiveReferences(NodeUtils.BWR_DN_TYPE);

    if (ruleSet.isEvaluateAny())
    {
      Set<String> applicantSet = new TreeSet<String>();

      for (RuleSetResult result : trippedResults)
      {
        List<String> tripList = result.getTripList();

        applicantSet.addAll(tripList);
      }

      // Get the indexes out of the set, and retrieve the applicant from the app node and
      // place into the eligible applicants list.
      //
      Iterator<String> it = applicantSet.iterator();

      while (it.hasNext())
      {
        int index = Integer.parseInt(it.next());
        DataNode applicantNode = appNode.getReference(NodeUtils.BWR_DN_TYPE, index);
        eligibleApplicants.add(applicantNode);
      }
    }
    else
    {
      // If the rule set is setup to consider true if All rules are tripped, then we need to
      // examine each rule item, and see what borrowers tripped that rule item.  For the
      // applicant to be considered eligible, the applicant must appear in the trip list for
      // all rule items that were executed.
      //
      // Get the list of applicants on the app, and check each rule result and make sure
      // the applicant appears in the trip list.
      //
      for (DataNode applicant : applicants)
      {
        String applicantIndex = String.valueOf(applicant.getIndex());
        boolean eligible = true;

        for (RuleSetResult result : trippedResults)
        {
          List<String> tripList = result.getTripList();

          if (! tripList.contains(applicantIndex))
          {
            // If the trip list does not contain the index of the applicant, then
            // the applicant is ruled out from being eligible.
            //
            eligible = false;
            break;
          }
        }

        if (eligible)
        {
          eligibleApplicants.add(applicant);
        }
      }

    }

    return eligibleApplicants;
  }

  public static String findHighestPriorityAccountNodeIndex( String username, List<DataNode> depAccounts )
    throws Exception
  {
    DataNode highestPriorityAccount = null;
    int highestPriority = -1;

    for( DataNode depAccount: depAccounts )
    {
      String productID = ( String ) depAccount.getFieldData( username, CSFieldNames.FN_DEP_PROD_ID );
      DepProduct product = CSDataCache.getDepProductManager().getProduct( productID );
      if( product == null )
      {
        throw new Exception( "Unable to load product for ID: " + productID + " [depAccount: " + depAccount.getIndex() + "]" );
      }

      if( highestPriorityAccount == null )
      {
        highestPriorityAccount = depAccount;
        highestPriority = product.getPriority();
      }
      else
      {
        // Higher priority = lower number.
        //
        if( product.getPriority() < highestPriority )
        {
          highestPriorityAccount = depAccount;
          highestPriority = product.getPriority();
        }
      }
    }


    // Return the product ID of the highest priority product.  This becomes our "alpha" product.
    //
    return  String.valueOf( highestPriorityAccount.getIndex() );
  }


  public static TableTransaction generateAdditionalAccountHolderTable(List<String> aahList, Map<String,String> titleMapping,
                                                                      DataNode appNode)
  {
    TableTransaction tt = new TableTransaction();

    tt.getFields().add("");
    tt.getFields().add("Account Holder                    ");
    tt.getFields().add("Title                       ");

    tt.getKeyFlags().add("true");
    tt.getKeyFlags().add("false");
    tt.getKeyFlags().add("false");

    if (aahList != null)
    {
      ListCodes cache = ApplicationHouse.getListCodesCache();

      TableRecord tr;
      for (String applicantIndex : aahList)
      {
        tr = new TableRecord();
        tr.addColumnData(applicantIndex);

        DataNode applicant = appNode.getReference(NodeUtils.BWR_DN_TYPE, Integer.parseInt(applicantIndex));
        tr.addColumnData(applicant == null ? "Applicant Not Found" : applicant.getDescription());

        String titleCode = titleMapping.get(applicantIndex);
        if (titleCode != null)
        {
          String description = cache.getListCodeLabel("Deposit Account Titling", titleCode);
          tr.addColumnData(description != null ? description : "<Desc Not Found>");
        }
        else
        {
          tr.addColumnData("<Title Code Not Found>");
        }

        tt.getRecords().add(tr);
      }
    }

    return tt;
  }


  public static TableTransaction generateODAssociatedAccountTable(List<DataNode> associatedAccounts, DataNode appNode,
                                                                  List<DataNode> groupAccounts)
  {
    TableTransaction tt = new TableTransaction();

    tt.getFields().add("");
    tt.getFields().add("Product Index");
    tt.getFields().add("Product                       ");
    tt.getFields().add("Opening Amount");

    tt.getKeyFlags().add("true");
    tt.getKeyFlags().add("false");
    tt.getKeyFlags().add("false");
    tt.getKeyFlags().add("false");

    if (associatedAccounts != null)
    {
      Map<String, String> productDescTable = CSDataCache.getDepProductManager().getProductDescMap();

      TableRecord tr = null;
      int assocAcctIndex = -1;
      for (DataNode assocAccount : associatedAccounts)
      {
        ++assocAcctIndex;

        String daIndex = (String)assocAccount.getSystemData(CSFieldNames.FN_SYS_DEP_ACCT_INDEX);
        if (daIndex != null)
        {
          tr = new TableRecord();
          tr.addColumnData(String.valueOf(assocAcctIndex));
          tr.addColumnData(daIndex);

          String openingAmt = null;
          String productDesc = null;
          DataNode depAccount = groupAccounts != null ? groupAccounts.get(Integer.parseInt(daIndex)) :
                                appNode.getReference(NodeUtils.DEP_ACCOUNT_DN_TYPE, Integer.parseInt(daIndex));
          if (depAccount != null)
          {
            openingAmt = (String)depAccount.getFieldData(CSFieldValues.EMPTY_STRING, CSFieldNames.FN_DEP_OPEN_AMT);
            String daProductID = (String)depAccount.getFieldData(CSFieldValues.EMPTY_STRING, CSFieldNames.FN_DEP_PROD_ID);
            productDesc = productDescTable.get(daProductID);
          }
          tr.addColumnData(productDesc != null ? productDesc : "<Unknown Product>");

          tr.addColumnData(openingAmt != null ? openingAmt : "");

          tt.getRecords().add(tr);
        }
      }
    }

    return tt;
  }

  public static void enableTheseButtonsWhenAppIsLocked(Map instructionHash)
  {
    // Main App Buttons
    //
    instructionHash.put("getBranchInfoB", ClientUtils.enabledElement());
    instructionHash.put("EditBwr3B", ClientUtils.enabledElement());
    instructionHash.put("EditPRB.DA", ClientUtils.enabledElement());
    instructionHash.put("ViewDIB", ClientUtils.enabledElement());
    instructionHash.put("GetStatHistB", ClientUtils.enabledElement());

    // Edit Applicant Buttons
    //
    instructionHash.put("DetailsRptB.DA", ClientUtils.enabledElement());
    instructionHash.put("DetailsScoresB.DA", ClientUtils.enabledElement());

    // Underwriting Buttons
    instructionHash.put("ViewDecision.DA", ClientUtils.enabledElement());
    instructionHash.put("ViewVFReportB", ClientUtils.enabledElement());
  }


  public static boolean isProductEligibleForOverdraft(String productID)
  throws Exception
  {
    DepProduct product = CSDataCache.getDepProductManager().getProduct(productID);
    if (product == null)
    {
      throw new Exception("Unable to load product '" + productID + "'");
    }

    String productType = product.getProductType();
    return productType != null && productType.equals("CK") || productType.equals("MM");
  }


  public static boolean isOverdraftProduct(String productID)
  throws Exception
  {
    DepProduct product = CSDataCache.getDepProductManager().getProduct(productID);
    if (product == null)
    {
      throw new Exception("Unable to load product '" + productID + "'");
    }

    String productType = product.getProductType();
    return productType != null && productType.equals("OD");
  }


  public static boolean isOverdraftProduct(DataNode depAccount)
  throws Exception
  {
    String productID = (String)depAccount.getFieldData(CSFieldValues.EMPTY_STRING, CSFieldNames.FN_DEP_PROD_ID);
    if (productID == null)
    {
      throw new Exception("Unable to find product ID in the deposit account data node.");
    }

    return isOverdraftProduct(productID);
  }


  public static boolean isApplicationFunded(DataNode appNode)
  {
    boolean isFunded = true;

    List<DataNode> accounts = appNode.getEffectiveReferences(NodeUtils.DEP_ACCOUNT_DN_TYPE);
    for (DataNode account : accounts)
    {
      List<DataNode> fundings = account.getEffectiveReferences(NodeUtils.DEP_FUNDING_DN_TYPE);
      if (fundings.isEmpty())
      {
        isFunded = false;

        break;
      }
    }

    return isFunded;
  }

  private static final DecimalFormat formatter = createNumberFormatter();

  private static DecimalFormat createNumberFormatter() {
	return new DecimalFormat("#.###");
  }

  public static String calculateTotalPercentInFieldForBeneficiariesWithIraDesignation(
			List<DataNode> beneNodes, String field, String beneDesig) {
		BigDecimal totalShare = new BigDecimal(0);
		for (DataNode beneNode : beneNodes) {
			String iraDesignation = (String) beneNode.getFieldData("",
					CSFieldNames.FN_DEP_IRA_BENE_DESIGNATION);
			if (beneDesig.equals(iraDesignation)) {
				String beneShare = (String) beneNode.getFieldData("",
						field);
				if (beneShare == null)
					beneShare = "0.0";
				totalShare = totalShare.add(new BigDecimal(beneShare));
			}
		}
		return formatter.format(totalShare.doubleValue());
	}

  public static String calculateTotalPercentInFieldForBeneficiaries(
			List<DataNode> beneNodes, String field) {
		BigDecimal totalShare = new BigDecimal(0);
		for (DataNode beneNode : beneNodes) {
			String beneShare = (String) beneNode.getFieldData("",
					field);
			if (beneShare == null)
				beneShare = "0.0";
			totalShare = totalShare.add(new BigDecimal(beneShare));
		}
		return formatter.format(totalShare.doubleValue());
	}

  public static int countBeneficiariesWithDesignation(List<DataNode> iraNodes, String beneDesig) {
	  int counter = 0;
	  for (DataNode iraNode : iraNodes) {
		  String iraDesignation = (String)iraNode.getFieldData("", CSFieldNames.FN_DEP_IRA_BENE_DESIGNATION);
	      if (beneDesig.equals(iraDesignation)) {
	    	  counter++;
	      }
	  }
	  return counter;
  }


public static boolean isFullyFunded(DataNode appNode) {
	return true;
}
}
