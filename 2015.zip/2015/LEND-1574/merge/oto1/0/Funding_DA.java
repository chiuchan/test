/**
 * <p>Title: Funding_DA</p>
 *
 * <p>Description: This class populates the Funding.DA vista on the
 *                 Account_Details.DA form.</p>
 *
 * <p>Copyright: Copyright (c) 2012</p>
 *
 * <p>Company: ACI Corporation</p>
 *
 * @author Len Doerich
 * @version 1.0
 */

package vistaPopulator;

import com.xnai.credisphere.dataCache.CSDataCache;
import com.xnai.credisphere.depProduct.DepProduct;
import com.xnai.credisphere.deposits.DepUtils;
import com.xnai.credisphere.util.CSFieldNames;
import com.xnai.credisphere.util.CSFieldValues;
import com.xnai.credisphere.vistaPop.VistaPopulator;
import com.xnai.mulder.systemCore.AdminGUIManager;
import com.xnai.mulder.systemObject.DataNode;


import com.xnai.mulder.user.User;
import com.xnai.mulder.user.UserSession;
import com.xnai.mulder.util.ClientUtils;


import com.xnai.mulder.util.StringSupport;
import com.xnai.mulder.util.VectorX;


import com.xnai.mulder.visual.TableRecord;
import com.xnai.mulder.visual.TableTransaction;


import java.text.DecimalFormat;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;


public class Funding_DA extends VistaPopulator
{
  public Funding_DA(String username, DataNode appNode)
  {
    super(username, appNode);
  }


  @Override
  public void populate(Map fields)
  throws Exception
  {
    String productID = (String)fields.get("_anProdTypeD");

    DepProduct product = CSDataCache.getDepProductManager().getProduct(productID);
    if (product == null)
    {
      throw new Exception("Unable to load product '" + productID + "'");
    }

    String productType = product.getProductType();

    Map<String, String> fundingTypes = DepUtils.getFundingTypes(productType);

    VectorX fundingList = ClientUtils.createValLabelList(fundingTypes);

    String fundType = (String)fields.get(CSFieldNames.FN_DEP_FUNDING_TYPE);
    if (fundType != null) ClientUtils.markListSelection(fundType, fundingList);

    fields.put(CSFieldNames.FN_DEP_FUNDING_TYPE, fundingList);

    // Now create the table transaction of funding methods on the account.
    //
    User user = super.getUser();
    UserSession session = user.getUserSession();

    List<DataNode> fundingNodes = (List<DataNode>)session.getAttribute(DepUtils.FUNDING_NODES + ":" + productID);

    TableTransaction tt = DepUtils.generateFundingTable(fundingNodes, fundingTypes);

    fields.put(CSFieldNames.FN_DEP_FUNDING_TBL, tt);
    
    // Calculate the total (daFundTtl) 
    double totalAmt = 0.0;
    for (DataNode fundingNode : fundingNodes)
    {
      String str = (String)fundingNode.getFieldData("", CSFieldNames.FN_DEP_FUNDING_AMT);
      totalAmt += StringSupport.strToDouble(str);
    }

    fields.put(CSFieldNames.FN_DEP_FUNDING_TOTAL, String.valueOf(totalAmt));
    
  }
}
