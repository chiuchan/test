/*******************************************
 ****                                    ****
 ****              CSUtil                ****
 ****                                    ****
 ****   (c) 2000 X/Net Associates Inc.   ****
 ****         All Rights Reserved        ****
 ****                                    ****
 *******************************************/
package com.xnai.credisphere.util;

import java.io.File;
import java.io.StringWriter;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.FileWriter;
import java.lang.reflect.Method;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import com.xnai.net.xResponse;
import com.xnai.credisphere.appImport.AppImportUtils;
import com.xnai.credisphere.SBProductEditor.SBProduct;
import com.xnai.credisphere.calcs.AppCalcs;
import com.xnai.credisphere.calcs.FinCalcs;
import com.xnai.credisphere.dataCache.CSDataCache;
import com.xnai.credisphere.db.DBLogger;
import com.xnai.credisphere.db.DBQueries;
import com.xnai.credisphere.db.DBUtils;
import com.xnai.credisphere.mgtRuleEditor.ManagementRuleSet;
import com.xnai.credisphere.mgtRuleEditor.VerificationRuleSet;
import com.xnai.credisphere.pricingEditor.PricingTable;
import com.xnai.credisphere.productEditor.GenericProduct;
import com.xnai.credisphere.productEditor.Product;
import com.xnai.credisphere.program.Program;
import com.xnai.credisphere.productEditor.ProductPricing;
import com.xnai.credisphere.mtgProduct.MtgProduct;
import com.xnai.credisphere.mgtRuleEditor.MtgMgmtRuleSet;
import com.xnai.credisphere.mgtRuleEditor.GenericMgmtRuleSet;
import com.xnai.credisphere.util.CSFieldNames;
import com.xnai.credisphere.util.CSFieldValues;
import com.xnai.credisphere.rules.RuleSetEvaluator;
import com.xnai.credisphere.ruleEditor.RuleSet;
import com.xnai.credisphere.rules.RuleSetResult;
import com.xnai.credisphere.liquidCredit.LiquidCreditUtils;
import com.xnai.credisphere.cbUtils.CBUtils;
import com.xnai.credisphere.SBMgmtRuleEditor.SBMgmtRuleSet;
import com.xnai.credisphere.rules.RuleDefinition;
import com.xnai.credisphere.mgtRuleRepository.MgtRuleRepository;
import com.xnai.credisphere.depProduct.DepProduct;
import com.xnai.mulder.application.ApplicationHouse;
import com.xnai.mulder.systemObject.Milestone;
import com.xnai.mulder.dbInterface.DbElements;
import com.xnai.mulder.dbInterface.DbHelper;
import com.xnai.mulder.dbInterface.DBErrorLogger;
import com.xnai.mulder.dbInterface.DBConnPool;
import com.xnai.mulder.systemCore.AdminGUIManager;
import com.xnai.mulder.systemCore.SystemHouse;
import com.xnai.mulder.systemObject.DataNode;
import com.xnai.mulder.systemObject.SDOConstants;
import com.xnai.mulder.systemObject.SystemDataObject;
import com.xnai.mulder.user.NotifyUser;
import com.xnai.mulder.user.User;
import com.xnai.mulder.util.ClientUtils;
import com.xnai.mulder.util.DateUtility;
import com.xnai.mulder.util.ExceptionLogger;
import com.xnai.mulder.util.FormLoader;
import com.xnai.mulder.util.GeneralToolkit;
import com.xnai.mulder.util.HashtableX;
import com.xnai.mulder.util.S1Log;
import com.xnai.mulder.util.StringChanger;
import com.xnai.mulder.util.StringSupport;
import com.xnai.mulder.util.VectorX;
import com.xnai.mulder.visual.ClientGOHT;
import com.xnai.mulder.visual.ElementInstruction;
import com.xnai.mulder.visual.Form;
import com.xnai.mulder.visual.TableRecord;
import com.xnai.mulder.visual.TableTransaction;
import com.xnai.mulder.visual.VistaInstruction;
import com.xnai.mulder.systemCore.SystemProperties;
import com.xnai.mulder.mail.MailAlertMessage;
import com.xnai.mulder.util.Configuration;

public class CSUtil extends S1Log
{
  public static final int DELAY_DAYS = 30;

  public static final int UGI_SECURED_MAX_TERM = 180;
  public static final int UGI_UNSECURED_MAX_TERM = 60;

  public static final double LARGE_LINE_LIMIT = 750000.0;
  public static final double UGI_FACTOR = 0.0005;
  public static final double HE_ALLOWED_EQUITY = 80.0;

  public static final String CD_NODE_PREFIX = "CD";
  public static final String SV_NODE_PREFIX = "Sv";
  public static final String CK_NODE_PREFIX = "Ck";
  public static final String CL_NODE_PREFIX = "cl";
  public static final String USER_ALL = "All";
  public static final String USER_REGION = "Region";
  public static final String USER_BRANCH = "Branch";
  public static final String USER_NONE = "None";

  //
  //  Added for archive app viewing
  //
  private static final String COND_APPROVE = "Conditionally Approve";
  private static final String SAVE_AND_EXIT = "Save Changes and Exit";
  private static final String REDECISION = "Re-decision Application using Selected Report";
  private static final String RESCORE = "Re-score using Selected Report";
  private static final String APPROVE = "Approve";
  private static final String DECLINE = "Decline";
  private static final String USE_ALTERNATE = "Select Alternate Credit Report";
  private static final String VERIFY = "Send To Verification";
  private static final String REVIEW = "Send To Final Review";
  private static final String PULL_NEW_REPORT = "Pull New Credit Report & Re-decision";
  private static final String REEVALUATE = "Re-evaluate Decision";
  private static final String RECALCULATE = "Apply Changes and Recalculate";
  private static final String CHG_PROD = "Change Product";

  private static VectorX nextActionList = new VectorX();
  private static ElementInstruction readOnlyElement = new ElementInstruction();
  private static Map NEXT_ACTION_MAP = null;
  private static final String FAIR_ISAAC_TOTAL = "3";
  private static VistaInstruction readOnlyVista = new VistaInstruction();

  //
  // end of archive app viewing
  //
  public static final VectorX STATES = new VectorX();
  private static CSUtil CSUtil = null;
  private static GeneralToolkit general = new GeneralToolkit();

  static
  {
    STATES.addElement("TX");
    STATES.addElement("OK");
    STATES.addElement("NM");

    // start underwiriting andarchive app
    readOnlyVista.setReadOnly(true);
    readOnlyElement.setReadOnly(true);

    nextActionList.add(APPROVE);
    nextActionList.add(DECLINE);
    nextActionList.add(COND_APPROVE);
    nextActionList.add(VERIFY);
    nextActionList.add(REVIEW);
    nextActionList.add(PULL_NEW_REPORT);
    nextActionList.add(USE_ALTERNATE);
    nextActionList.add(REDECISION);
    nextActionList.add(REEVALUATE);
    nextActionList.add(RECALCULATE);
    nextActionList.add(SAVE_AND_EXIT);
    nextActionList.add(CHG_PROD);

    // end underwiriting andarchive app
    CSUtil = new CSUtil();
  }

  private CSUtil()
  {
  }

  public static CSUtil getInstance()
  {
    return CSUtil;
  }

  public Calendar getApplicationPricingDateTime(DataNode appNode) throws
      Exception
  {
    String lookupDate = null;
    String lookupTime = null;
    Calendar lookupDateCal = null;

    boolean isConsumer = isConsumerApplication(appNode);
    boolean isMortgage = isMortgageApplication(appNode);

    String productID = (isConsumer || isMortgage)?
        (String) appNode.getFieldData(CSFieldValues.EMPTY_STRING, CSFieldNames.FN_PRODUCT_ID) :
        (String) appNode.getFieldData(CSFieldValues.EMPTY_STRING, CSFieldNames.FN_SBPRODUCT_ID);

    if (productID == null)
    {
      throw new Exception("Product ID not found.");
    }

    Product product = null;
    SBProduct sbProduct = null;
    MtgProduct mgProduct = null;

    if (isConsumer)
    {
      product = CSDataCache.getProductManager().getProduct(productID);
      if (product == null)
      {
        throw new Exception("Product not found in data cache.");
      }
    }
    else if (isMortgage)
    {
      mgProduct = CSDataCache.getMtgProductManager().getProduct(productID);
      if (mgProduct == null)
      {
        throw new Exception("Product not found in data cache.");
      }
    }
    else
    {
      sbProduct = CSDataCache.getSBProductManager().getProduct(productID);
      if (sbProduct == null)
      {
        throw new Exception("Product not found in data cache.");
      }
    }

    // String prdPTDtD = isConsumer ? product.getPrdPTDtD() :sbProduct.getPrdPTDtD();
    //
    String prdPTDtD = isConsumer ? product.getPrdPTDtD() : isMortgage ? SBProduct.PRICING_LOOKUP_CURRENT : sbProduct.getPrdPTDtD();

    String current = SBProduct.PRICING_LOOKUP_CURRENT;
    String rcvDate = SBProduct.PRICING_LOOKUP_APP_RCV;

    log(" Determining the prcing type " + prdPTDtD + " current " + current + " rcvDate " + rcvDate);

    int status = Integer.parseInt( (String) appNode.getSystemData(CSFieldNames.FN_APP_STAT));
    int minStatus = Integer.parseInt(CSStatusCodes.SC_CLOSING);

    //if current and small business and the status code is >= 8000 (closing code)
    //if (prdPTDtD.equals(current) && !isConsumer && status >= minStatus)
    //if (prdPTDtD.equals(current) && !isConsumer && !isMortgage && status >= minStatus)  // 2-19-09, ccl
    if (prdPTDtD.equals(current) && status >= minStatus)
    {
      //use anLoanDt
      lookupDate = (String) appNode.getFieldData(CSFieldValues.EMPTY_STRING, CSFieldNames.FN_LOAN_DT);
      if (lookupDate == null)
      {
        throw new Exception("Loan date not found.");
      }

      //use 12:00 PM as the loan time
      lookupDateCal = createCalendarForDateTime(lookupDate, "12:00 PM");
    }
    else if (prdPTDtD.equals(current))
    {
      lookupDateCal = Calendar.getInstance();
      log("Current Date " + new SimpleDateFormat("MM/dd/yy").format(lookupDateCal.getTime()));
    }
    else
    {
      if (prdPTDtD.equals(rcvDate) || prdPTDtD.length() == 0)
      {
        lookupDate = (String) appNode.getFieldData(CSFieldValues.EMPTY_STRING, CSFieldNames.FN_APP_DT);

        if (lookupDate == null)
        {
          throw new Exception("Application date not found.");
        }

        lookupTime = (String) appNode.getFieldData(CSFieldValues.EMPTY_STRING, CSFieldNames.FN_APP_TIME);

        if (lookupTime == null)
        {
          throw new Exception("Application time not found.");
        }
        lookupDateCal = createCalendarForDateTime(lookupDate, lookupTime);
        if (lookupDateCal != null)
        {
          log("Calendar object  created by date and time " + lookupDateCal);
        }
      }
      else
      {
        throw new Exception("Unable to determine pricing table lookup method.");
      }
    }

    return lookupDateCal;
  }

  public Calendar createCalendarForDateTime(String dateStr,
                                            String timeStr)
  {
    Calendar cal = null;
    log("CCSUTIL - createCalendarForDateTime " + dateStr + " TimeStr " +
        timeStr);
    if (dateStr != null && timeStr != null)
    {
      dateStr = (DateUtility.slashDateToIndexDate(dateStr)).trim();

      log(
          "CSUTIL - createCalendarForDateTime - afterSlashDateToIndexDate called  " +
          dateStr + " TimeStr " + timeStr + " total length " + dateStr);

      String yearS = dateStr.substring(0, 4);
      String monthS = null;
      String dayS = null;
      int start = 0;

      if (!Character.isLetterOrDigit(dateStr.charAt(4)))
      {
        monthS = dateStr.substring(5, 7);
        start = 7;
      }
      else
      {
        monthS = dateStr.substring(4, 6);
        start = 6;
      }

      if (!Character.isLetterOrDigit(dateStr.charAt(start)))
      {
        dayS = dateStr.substring(start + 1);
      }
      else
      {
        dayS = dateStr.substring(start);
      }

      timeStr = timeStr.trim();

      log("Year " + yearS + " month " + monthS + " day " + dayS);
      int indexOfColon = timeStr.indexOf(':');

      if (indexOfColon != -1)
      {
        String hourS = timeStr.substring(0, indexOfColon);
        String minS = timeStr.substring(indexOfColon + 1, indexOfColon + 3);

        // Change all fields to ints.
        //
        try
        {
          int year = Integer.parseInt(yearS);
          int month = Integer.parseInt(monthS);
          int day = Integer.parseInt(dayS);
          int hour = Integer.parseInt(hourS);
          int min = Integer.parseInt(minS);

          if (timeStr.endsWith("AM") && hour == 12)
          {
            hour = 0;
          }
          if (timeStr.endsWith("PM") && hour != 12)
          {
            hour += 12;
          }

          cal = Calendar.getInstance();
          cal.clear();
          cal.set(year, month - 1, day, hour, min);
        }
        catch (NumberFormatException e)
        {
          e.printStackTrace();
        }
      }
    }

    return cal;

  }

  public static boolean isUsingScorecard(String username, SystemDataObject sdo)
  {
    String cbcTotalScore = sdo.getData(username, "cbc_total_score");

    boolean usingScorecard = true;

    if (cbcTotalScore == null || cbcTotalScore.equals("0"))
    {
      usingScorecard = false;
    }

    return usingScorecard;
  }

  public static String getApplicationSecuredType(DataNode appDN)
  {

    String securedType = CSFieldValues.FV_SEC_UNDETERMINED;
    if (appDN != null)
    {
      boolean isConsumer = isConsumerApplication(appDN);
      boolean isMortgage = isMortgageApplication(appDN);

      String productID = (isConsumer || isMortgage)?
          (String) appDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                      CSFieldNames.FN_PRODUCT_ID) :
          (String) appDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                      CSFieldNames.FN_SBPRODUCT_ID);

      if (productID != null)
      {
        String prdSecType = null;

        try
        {
          if (isConsumer)
          {
            Product product = CSDataCache.getProductManager().getProduct(
                productID);
            if (product != null)
            {
              prdSecType = product.getClsPrSecTypD();
            }
          }
          else if (isMortgage)
          {
            MtgProduct mgProduct = CSDataCache.getMtgProductManager().getProduct(
                productID);
            if (mgProduct != null)
            {
              prdSecType = mgProduct.getClsPrSecTypD();
            }
          }
          else
          {
            SBProduct sbProduct = CSDataCache.getSBProductManager().getProduct(
                productID);
            if (sbProduct != null)
            {
              prdSecType = sbProduct.getClsPrSecTypD();
            }
          }
        }
        catch (Exception e)
        {
          e.printStackTrace();
        }

        if (prdSecType != null)
        {
          securedType = prdSecType;
        }
      }
    }

    return securedType;
  }

  public static boolean isApplicationSecured(DataNode appDN)
  {
    boolean secured = false;

    DataNode colDN = appDN.getReference(NodeUtils.COLL_DN_TYPE, 0);

    // if no collateral at all then return Unsecured.
    if (colDN != null && !colDN.isDeleted())
    {
      VectorX colTypes = colDN.getReferenceDataTypes();

      if (colTypes != null && !colTypes.isEmpty())
      {
        String curType = null,
            isSecuredVal = null;
        DataNode curDN = null;
        VectorX curTypeDNVec = new VectorX();
        for (int i = 0; i < colTypes.size() && !secured; i++)
        {
          curType = (String) colTypes.elementAt(i);
          curTypeDNVec = colDN.getReferences(curType);
          if (curTypeDNVec != null && !curTypeDNVec.isEmpty())
          {
            isSecuredVal = null;
            curDN = null;
            for (int j = 0; j < curTypeDNVec.size(); j++)
            {
              curDN = (DataNode) curTypeDNVec.elementAt(j);
              if (!curDN.isDeleted())
              {
                isSecuredVal = (String) curDN.getFieldData(CSFieldValues.
                    EMPTY_STRING,
                    CSFieldNames.FN_COLLATERAL_SECURED);

                if (isSecuredVal == null ||
                    isSecuredVal.equals(CSFieldValues.TRUE_STRING))
                {
                  secured = true;
                  break;
                }
              }
            } // end for through curTypeDNVec
          } // end if the curTypeDNVec is not null and not empty
        } // end for loop through the collateral types.
      } // collateral types is not null and not empty
    } // collateral data node is not null

    return secured;
  }

  public static boolean isSingleCreditLifeEligible(DataNode appDN)
  {
    boolean eligible = false;

    if (appDN != null)
    {
      VectorX bwrVec = appDN.getReferences(NodeUtils.BWR_DN_TYPE);
      if (bwrVec != null && !bwrVec.isEmpty())
      {
        eligible = true;
      }
    }

    return eligible;
  }

  public static boolean isJointCreditLifeEligible(DataNode appDN)
  {
    boolean eligible = false;

    if (isSingleCreditLifeEligible(appDN))
    {

      // at this point with the above, we know that appDN is not null
      // and the primary applicant is eligible for credit life insurance.
      // we need to check if there are any co-applicants on this loan.
      // There must only be one co-applicant, and they must be the spouse
      // or business partner of the primary applicant.

      DataNode spDN = DataEntrySupport.getSpousalCoApplicant(appDN);
      if (spDN != null)
      {
        eligible = true;
      }

    } // they are at least eligible for single

    return eligible;
  }

  public static boolean isSingleAandHEligible(DataNode appDN)
  {
    boolean eligible = false;

    if (appDN != null)
    {
      VectorX bwrVec = appDN.getReferences(NodeUtils.BWR_DN_TYPE);
      if (bwrVec != null || !bwrVec.isEmpty())
      {
        eligible = true;
      }
    }

    return eligible;
  }

  public static boolean isPurchase(DataNode appDN) throws Exception
  {
    String loanPurpose = (String) appDN.getFieldData(CSFieldValues.EMPTY_STRING,
        CSFieldNames.FN_LOAN_PUR_SELECTION);

    boolean isPurchase = loanPurpose != null &&
        loanPurpose.equals(CSFieldValues.TRUE_STRING);

    if (!isPurchase)
    {
      DataNode colDN = appDN.getReference(NodeUtils.COLL_DN_TYPE, 0);

      if (colDN != null)
      {
        DataNode spColDN = null;

        VectorX collTypes = colDN.getReferenceDataTypes();
        VectorX cdCollVec = null;

        for (int i = 0; i < collTypes.size(); i++)
        {
          cdCollVec = colDN.getReferences( (String) collTypes.elementAt(i));
          if (cdCollVec != null && !cdCollVec.isEmpty())
          {
            for (int j = 0; j < cdCollVec.size(); j++)
            {
              spColDN = (DataNode) cdCollVec.elementAt(j);

              if (!spColDN.isDeleted() && isCollateralPurchaseMoney(spColDN))
              {
                isPurchase = true;
                break;
              } // end delete check

            } // end for loop
          }

        } // end check for cd collateral

      }

    }

    return isPurchase;
  }

  public static boolean isLargeLine(DataNode appDN) throws Exception
  {
    return (getHighestTotalAggregateDebt(appDN) > LARGE_LINE_LIMIT);
  }

  public static boolean isHMDAApplicable(DataNode appDN) throws Exception
  {

    boolean isConsumer = isConsumerApplication(appDN);
    boolean isMortgage = isMortgageApplication(appDN);

    String prodID = (isConsumer || isMortgage)?
        (String) appDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                    CSFieldNames.FN_PRODUCT_ID) :
        (String) appDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                    CSFieldNames.FN_SBPRODUCT_ID);

    if (prodID == null)
    {
      throw new Exception("Product ID not found.");
    }

    GenericProduct genProd = null;

    if (isConsumer)
    {
      genProd = CSDataCache.getProductManager().getProduct(prodID);
    }
    else if (isMortgage)
    {
      genProd = CSDataCache.getMtgProductManager().getProduct(prodID);
    }
    else
    {
      genProd = CSDataCache.getSBProductManager().getProduct(prodID);
    }

    if (genProd == null)
    {
      throw new Exception("Product not found in data cache.");
    }

    // if an application is both CRA && HMDA applicable, then we need to
    // check the product to see if they want to report both, or one or the other

    boolean meetsHMDA = HMDAUtil.meetsHMDACriteria(appDN, genProd);
    boolean meetsCRA = HMDAUtil.meetsCRACriteria(appDN, genProd);

    if (meetsHMDA && meetsCRA && genProd != null)
    {
      // it is both a CRA && HMDA loan, if they want to report CRA only
      // return false
      String collectWhat = genProd.getPrdGovInfoD();

      if (collectWhat != null && collectWhat.equals(genProd.CRA_ONLY))
      {
        meetsHMDA = false;
      }
    }

    return meetsHMDA;
  }

  public static boolean isApplicationPreapproval(DataNode appDN)
  {
    String str = (String) appDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                             CSFieldNames.FN_PRE_APPROVED);
    return str != null && str.equals(CSFieldValues.TRUE_STRING);
  }

  public static boolean isApplicationApproved(DataNode appDN)
  {
    String decision = (String) appDN.getSystemData(CSStatusCodes.APP_DECISION);
    return decision != null &&
        decision.equals(CSStatusCodes.APP_DECISION_APPROVE);
  }

  public static boolean isApplicationConditionallyApproved(DataNode appDN)
  {
    String decision = (String) appDN.getSystemData(CSStatusCodes.APP_DECISION);
    return decision != null && decision.equals(CSStatusCodes.APP_DECISION_COND);
  }

  public static boolean isApplicationDeclined(DataNode appDN)
  {
    String decision = (String) appDN.getSystemData(CSStatusCodes.APP_DECISION);
    return decision != null &&
        decision.equals(CSStatusCodes.APP_DECISION_DECLINE);
  }

  public static boolean isCRAApplicable(DataNode appDN) throws Exception
  {
    boolean isConsumer = isConsumerApplication(appDN);
    boolean isMortgage = isMortgageApplication(appDN);

    String prodID = (isConsumer || isMortgage)?
        (String) appDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                    CSFieldNames.FN_PRODUCT_ID) :
        (String) appDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                    CSFieldNames.FN_SBPRODUCT_ID);

    if (prodID == null)
    {
      throw new Exception("Product ID not found.");
    }

    GenericProduct genProd = null;

    if (isConsumer)
    {
      genProd = CSDataCache.getProductManager().getProduct(prodID);
    }
    else if (isMortgage)
    {
      genProd = CSDataCache.getMtgProductManager().getProduct(prodID);
    }
    else
    {
      genProd = CSDataCache.getSBProductManager().getProduct(prodID);
    }

    if (genProd == null)
    {
      throw new Exception("Product not found in data cache.");
    }

    // if an application is both CRA && HMDA applicable, then we need to
    // check the product to see if they want to report both, or one or the other

    boolean meetsCRA = HMDAUtil.meetsCRACriteria(appDN, genProd);

    if (genProd != null && meetsCRA)
    {
      // If CRA wins out or they
      // want to report both CRA and HMDA, then return true
      // else if it meets HMDA Criteria and they want to report HMDA only,
      // return false
      String collectWhat = genProd.getPrdGovInfoD();

      if (collectWhat != null &&
          collectWhat.equals(genProd.HMDA_ONLY) &&
          HMDAUtil.meetsHMDACriteria(appDN, genProd))
      {
        meetsCRA = false;
      }
    }

    return meetsCRA;
  }

  public static boolean isRealEstateSecured(DataNode appDN)
  {
    boolean isRESecured = false;

    if (appDN == null)
    {
      return false;
    }

    DataNode colDN = appDN.getReference(NodeUtils.COLL_DN_TYPE, 0);

    if (colDN == null)
    {
      return false;
    }

    VectorX reCollVec = colDN.getReferences(NodeUtils.RE_DN_TYPE);

    if (reCollVec == null || reCollVec.isEmpty())
    {
      return false;
    }

    DataNode curDN = null;
    for (int i = 0; i < reCollVec.size(); i++)
    {
      curDN = (DataNode) reCollVec.elementAt(i);

      if (!curDN.isDeleted() && isCollateralSecured(curDN))
      {
        isRESecured = true;
        break;
      }
    }

    curDN = null;
    reCollVec = null;

    return isRESecured;
  }

  public static boolean isMobileHomeSecured(DataNode appDN)
  {
    boolean isMHSecured = false;

    if (appDN == null)
    {
      return false;
    }

    DataNode colDN = appDN.getReference(NodeUtils.COLL_DN_TYPE, 0);

    if (colDN == null)
    {
      return false;
    }

    VectorX mhCollVec = colDN.getReferences(NodeUtils.MH_DN_TYPE);

    if (mhCollVec == null || mhCollVec.isEmpty())
    {
      return false;
    }

    DataNode curDN = null;
    String isSecured = null;

    for (int i = 0; i < mhCollVec.size(); i++)
    {
      curDN = (DataNode) mhCollVec.elementAt(i);

      if (!curDN.isDeleted())
      {
        isSecured = (String) curDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                                CSFieldNames.
                                                FN_COLLATERAL_SECURED);

        if (isSecured == null || isSecured.equals(CSFieldValues.TRUE_STRING))
        {
          isMHSecured = true;
          break;
        }
      }
    }

    curDN = null;
    mhCollVec = null;
    isSecured = null;

    return isMHSecured;
  }

  public static boolean isMobileHomePurchase(DataNode appDN)
  {
    boolean isMHPurchase = false;

    if (appDN == null)
    {
      return false;
    }

    DataNode colDN = appDN.getReference(NodeUtils.COLL_DN_TYPE, 0);

    if (colDN == null)
    {
      return false;
    }

    VectorX mhCollVec = colDN.getReferences(NodeUtils.MH_DN_TYPE);

    if (mhCollVec == null || mhCollVec.isEmpty())
    {
      return false;
    }

    DataNode curDN = null;
    String isPurchase = null,
        clMHPrchMnyCStr = "clMHPrchMnyC";

    for (int i = 0; i < mhCollVec.size(); i++)
    {
      curDN = (DataNode) mhCollVec.elementAt(i);

      if (!curDN.isDeleted())
      {
        isPurchase = (String) curDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                                 clMHPrchMnyCStr);

        if (isPurchase != null && isPurchase.equals(CSFieldValues.TRUE_STRING))
        {
          isMHPurchase = true;
          break;
        }
      }
    }

    curDN = null;
    mhCollVec = null;
    isPurchase = null;

    return isMHPurchase;
  }

  public static double calcRefiHIPurchBalances(DataNode appDN) throws Exception
  {
    double refiBalance = 0.0;

    DataNode colDN = appDN.getReference(NodeUtils.COLL_DN_TYPE, 0);

    if (colDN != null)
    {

      DataNode spColDN = null;

      VectorX collTypes = colDN.getReferenceDataTypes();
      VectorX cdCollVec = null;
      VectorX lienVec = null;

      DataNode lnDN = null;
      for (int i = 0; i < collTypes.size(); i++)
      {

        cdCollVec = colDN.getReferences( (String) collTypes.elementAt(i));

        if (cdCollVec != null && !cdCollVec.isEmpty())
        {
          for (int j = 0; j < cdCollVec.size(); j++)
          {
            spColDN = (DataNode) cdCollVec.elementAt(j);

            if (!spColDN.isDeleted())
            {
              lienVec = spColDN.getReferences(NodeUtils.LIEN_DN_TYPE);

              if (lienVec != null)
              {
                for (int k = 0; k < lienVec.size(); k++)
                {
                  lnDN = (DataNode) lienVec.elementAt(k);

                  if (!lnDN.isDeleted())
                  {
                    refiBalance += getRefiHIPurchBalance(lnDN);
                  }
                }
              }
            }

          } // end for loop
        }
      } // end check for cd collateral
    }

    return refiBalance;
  }

  public static double calcCRAIntRefiBalances(DataNode appDN) throws Exception
  {
    double refiBalance = 0.0;

    DataNode colDN = appDN.getReference(NodeUtils.COLL_DN_TYPE, 0);

    if (colDN != null)
    {

      DataNode spColDN = null;

      VectorX collTypes = colDN.getReferenceDataTypes();
      VectorX cdCollVec = null;
      VectorX lienVec = null;

      DataNode lnDN = null;

      for (int i = 0; i < collTypes.size(); i++)
      {

        cdCollVec = colDN.getReferences( (String) collTypes.elementAt(i));

        if (cdCollVec != null && !cdCollVec.isEmpty())
        {
          for (int j = 0; j < cdCollVec.size(); j++)
          {
            spColDN = (DataNode) cdCollVec.elementAt(j);

            if (!spColDN.isDeleted())
            {
              lienVec = spColDN.getReferences(NodeUtils.LIEN_DN_TYPE);

              if (lienVec != null)
              {
                for (int k = 0; k < lienVec.size(); k++)
                {
                  lnDN = (DataNode) lienVec.elementAt(k);

                  if (!lnDN.isDeleted())
                  {
                    refiBalance += getCRAIntRefiBalance(lnDN, appDN);
                  }
                }
              }
            }

          } // end for loop
        }
      } // end check for cd collateral
    }

    return refiBalance;
  }

  public static int getApplicationLocation(DataNode appDN) throws Exception
  {
    int locationID = -1;

    String branchID = (String) appDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                                  CSFieldNames.FN_BRANCH_ID);

    if (branchID == null)
    {
      throw new Exception("Branch not selected.");
    }

    try
    {
      locationID = Integer.parseInt(branchID);
    }
    catch (NumberFormatException e)
    {
      throw new Exception("Invalid branch selection: " + branchID);
    }

    return locationID;
  }

  public static boolean isEmployeeLoan(DataNode appDN) throws Exception
  {
    boolean isEmployeeLoan = false;

    VectorX bwrVec = appDN.getReferences(NodeUtils.BWR_DN_TYPE);

    if (bwrVec != null)
    {
      DataNode bwrDN = null;
      String bwrType = null;
      String ourEmp = null;

      List list = new ArrayList();

      HashtableX codes = CSDataCache.getCodeTableManager().getTableForType(
          getApplicationLocation(appDN), "Borrower", "Employee");

      if (codes != null)
      {
        list.addAll(codes.keySet());
      }

      codes = CSDataCache.getCodeTableManager().getTableForType(
          getApplicationLocation(appDN), "Borrower", "Reg O");

      if (codes != null)
      {
        list.addAll(codes.keySet());
      }

      for (int i = 0; i < bwrVec.size(); i++)
      {
        bwrDN = (DataNode) bwrVec.elementAt(i);

        bwrType = (String) bwrDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                              CSFieldNames.FN_BWR_TYPE);

        if (!bwrDN.isDeleted() &&
            bwrType != null &&
            (bwrType.equals(CSFieldValues.FV_APPLICANT) ||
             bwrType.equals(CSFieldValues.FV_COAPPLICANT) ||
             bwrType.equals(CSFieldValues.FV_OWNER) ||
             bwrType.equals(CSFieldValues.FV_PRINCIPAL)))
        {
          ourEmp = (String) bwrDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                               CSFieldNames.FN_OUR_EMP);

          if (ourEmp != null)
          {
            ourEmp = ourEmp.trim();

            if (list.contains(ourEmp))
            {
              isEmployeeLoan = true;
              break;
            }
          }
        }
      }

      bwrVec = null;
      bwrDN = null;
      bwrType = null;
      ourEmp = null;
    }

    return isEmployeeLoan;
  }

  public static boolean isRegOLoan(DataNode appDN) throws Exception
  {
    boolean isRegOLoan = false;

    VectorX bwrVec = appDN.getReferences(NodeUtils.BWR_DN_TYPE);

    DataNode bwrDN = null;
    String bwrType = null;
    String ourEmp = null;

    List list = new ArrayList();

    HashtableX codes = CSDataCache.getCodeTableManager().getTableForType(
        getApplicationLocation(appDN), "Borrower", "Reg O");

    if (codes != null)
    {
      list.addAll(codes.keySet());
    }

    if (bwrVec != null && !bwrVec.isEmpty())
    {
      for (int i = 0; i < bwrVec.size(); i++)
      {
        bwrDN = (DataNode) bwrVec.elementAt(i);

        bwrType = (String) bwrDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                              CSFieldNames.FN_BWR_TYPE);

        if (bwrType != null &&
            (bwrType.equals(CSFieldValues.FV_APPLICANT) ||
             bwrType.equals(CSFieldValues.FV_COAPPLICANT) ||
             bwrType.equals(CSFieldValues.FV_OWNER) ||
             bwrType.equals(CSFieldValues.FV_PRINCIPAL)))

        {
          ourEmp = (String) bwrDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                               CSFieldNames.FN_OUR_EMP);

          if (ourEmp != null)
          {
            ourEmp = ourEmp.trim();

            if (list.contains(ourEmp))
            {
              isRegOLoan = true;
              break;
            }
          }
        }
      }
      bwrVec = null;
      bwrDN = null;
      bwrType = null;
      ourEmp = null;
    }

    return isRegOLoan;
  }

  public static boolean isConstructionLoan(DataNode appDN) throws Exception
  {
    String pmtType = (String) appDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                                 CSFieldNames.FN_PMT_TYPE);
    return pmtType != null && pmtType.equals(CSFieldValues.FV_CONSTRUCTION);
  }

  public static boolean isHomeEquityProductLoan(DataNode appDN)
  {
    boolean isHomeEquity = false;

    if (appDN != null)
    {
      try
      {
        boolean isConsumer = isConsumerApplication(appDN);
        boolean isMortgage = isMortgageApplication(appDN);

        String prodID = (isConsumer || isMortgage)?
            (String) appDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                        CSFieldNames.FN_PRODUCT_ID) :
            (String) appDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                        CSFieldNames.FN_SBPRODUCT_ID);

        if (prodID != null)
        {
          String prodType = null;
          String loanType = null;

          if (isConsumer)
          {
            Product prod = CSDataCache.getProductManager().getProduct(prodID);

            if (prod != null)
            {
              prodType = prod.getProductType();
              loanType = prod.getLoanType();
            }
          }
          else if (isMortgage)
          {
            MtgProduct mgProd = CSDataCache.getMtgProductManager().getProduct(prodID);

            if (mgProd != null)
            {
              prodType = mgProd.getProductType();
              loanType = mgProd.getLoanType();
            }
          }
          else
          {
            SBProduct sbProd = CSDataCache.getSBProductManager().getProduct(
                prodID);

            if (sbProd != null)
            {
              prodType = sbProd.getProductType();
              loanType = sbProd.getLoanType();
            }
          }

          isHomeEquity = ( (prodType != null &&
                            prodType.equals(CSFieldValues.
                                            FV_PRODUCT_TYPE_HOME_EQ)) ||
                          loanType != null &&
                          loanType.equals("Home Equity"));

        }
      }
      catch (Exception e)
      {
      }
    }

    return isHomeEquity;
  }

  public static boolean isIndirectProductLoan(DataNode appDN)
  {
    boolean isIndirect = false;

    if (appDN != null)
    {
      try
      {
        String prdType = getApplicationProductType(appDN);

        isIndirect = prdType != null &&
            prdType.equals(CSFieldValues.FV_PRODUCT_TYPE_INDIRECT);
      }
      catch (Exception e)
      {
      }
    }

    return isIndirect;
  }

  public static boolean checkHomeEquity(DataNode appDN) throws Exception
  {
    boolean passing = true;

    double reqAmt = Double.parseDouble( (String) appDN.getFieldData(
        CSFieldValues.EMPTY_STRING,
        CSFieldNames.FN_TTL_FIN_AMT));

    DataNode colDN = appDN.getReference(NodeUtils.COLL_DN_TYPE, 0);

    double ltv = 0.0;
    DataNode reDN = null;

    if (colDN != null)
    {
      VectorX reDNVec = colDN.getReferences(NodeUtils.RE_DN_TYPE);

      if (reDNVec != null && !reDNVec.isEmpty())
      {
        for (int i = 0; i < reDNVec.size(); i++)
        {
          reDN = (DataNode) reDNVec.elementAt(i);

          if (!reDN.isDeleted())
          {
            ltv = calculateLoanToValuePercent(reDN, reqAmt);

            if (ltv > HE_ALLOWED_EQUITY)
            {
              passing = false;
              break;
            }
          }
        }
      }
    }

    return passing;
  }

  public static boolean isCDSecured(DataNode appDN) throws Exception
  {
    boolean cdSecured = false;

    DataNode colDN = appDN.getReference(NodeUtils.COLL_DN_TYPE, 0);

    if (colDN != null)
    {
      VectorX cdVec = colDN.getReferences(NodeUtils.CD_DN_TYPE);

      DataNode cdDN = null;

      if (cdVec != null && !cdVec.isEmpty())
      {
        for (int i = 0; i < cdVec.size() && !cdSecured; i++)
        {
          cdDN = (DataNode) cdVec.elementAt(i);

          if (!cdDN.isDeleted())
          {
            cdSecured = true;
          }
        }
      }

    }

    return cdSecured;
  }

  public static boolean isCDSecuredWithThirdPartyOwner(DataNode appDN) throws
      Exception
  {
    boolean thirdParty = false;

    DataNode colDN = appDN.getReference(NodeUtils.COLL_DN_TYPE, 0);

    if (colDN != null)
    {
      VectorX cdVec = colDN.getReferences(NodeUtils.CD_DN_TYPE);

      if (cdVec != null && !cdVec.isEmpty())
      {
        DataNode cdDN = null;
        for (int i = 0; i < cdVec.size() && !thirdParty; i++)
        {
          cdDN = (DataNode) cdVec.elementAt(i);
          if (!cdDN.isDeleted())
          {
            thirdParty = isCollateralOwnedByThirdParty(cdDN);
          } // end starts, ends check
        }
      }
    }

    return thirdParty;
  }

  public static double calculateLoanToValuePercent(DataNode colSpDN,
      double loanAmt) throws Exception
  {
    double value = getGrossSpecCollateralValue(colSpDN);

    double balance = loanAmt;

    VectorX lienVec = colSpDN.getReferences(NodeUtils.LIEN_DN_TYPE);

    if (lienVec != null && !lienVec.isEmpty())
    {
      for (int i = 0; i < lienVec.size(); i++)
      {
        balance += getNetLienBalance( (DataNode) lienVec.elementAt(i));
      }
    }

    return ( (balance / value) * 100.0);
  }

  public static boolean isCollateralSecured(DataNode colSpDN)
  {
    String secField = (String) colSpDN.getFieldData(CSFieldValues.EMPTY_STRING,
        CSFieldNames.FN_COLLATERAL_SECURED);
    return! (secField != null && secField.equals(CSFieldNames.FALSE_STRING));
  }

  public static boolean isCollateralPurchaseMoney(DataNode colSpDN) throws
      Exception
  {
    boolean purchase = false;
    String purchField = null;

    HashtableX fieldData = colSpDN.getFieldData(CSFieldValues.EMPTY_STRING);

    Iterator it = fieldData.keySet().iterator();

    boolean found = false;

    String key = null,
        prchMnyCStr = "PrchMnyC";

    while (it.hasNext())
    {
      key = (String) it.next();

      if (key.endsWith(prchMnyCStr))
      {
        if (found)
        {
          throw new Exception("More than one value possible");
        }

        purchField = (String) fieldData.get(key);
        purchase = purchField != null &&
            purchField.equals(CSFieldValues.TRUE_STRING);

        found = true;
      }
    }

    return purchase;
  }

  public static double getGrossSpecCollateralValue(DataNode colSpDN) throws
      Exception
  {
    double grVal = 0.0;

    HashtableX fieldData = colSpDN.getFieldData(CSFieldValues.EMPTY_STRING);

    Iterator it = fieldData.keySet().iterator();

    boolean found = false;

    String key = null,
        valStr = "Val";

    while (it.hasNext())
    {
      key = (String) it.next();

      if (key.endsWith(valStr))
      {
        if (found)
        {
          throw new Exception("More than one value possible");
        }

        grVal = Double.parseDouble( (String) fieldData.get(key));

        found = true;
      }
    }

    return grVal;
  }

  public static double getRefiHIPurchBalance(DataNode lnDN) throws Exception
  {
    double refiBalance = 0.0;

    String refinancing = (String) lnDN.getFieldData(CSFieldValues.EMPTY_STRING,
        CSFieldNames.FN_LIEN_REFINANCING);

    if (refinancing != null && refinancing.equals(CSFieldValues.FV_LIEN_REFI))
    {
      String refiType = (String) lnDN.getFieldData(CSFieldValues.EMPTY_STRING,
          CSFieldNames.FN_LIEN_REFI_TYPE);

      if (refiType != null && refiType.equals(CSFieldValues.FV_LIEN_REFI_EXT))
      {
        String refiPurp = (String) lnDN.getFieldData(CSFieldValues.EMPTY_STRING,
            CSFieldNames.FN_LIEN_ORIG_PURPOSE);

        if (refiPurp != null &&
            (refiPurp.equals(CSFieldValues.FV_LIEN_ORIG_PUR_HI) ||
             refiPurp.equals(CSFieldValues.FV_LIEN_ORIG_PUR_HI)))
        {
          refiBalance = Double.parseDouble( (String) lnDN.getFieldData(
              CSFieldValues.EMPTY_STRING,
              CSFieldNames.FN_LIEN_BALANCE)) -
              Double.parseDouble( (String) lnDN.getFieldData(CSFieldValues.
              EMPTY_STRING,
              CSFieldNames.FN_LIEN_NOT_HI_PURCH_AMT));
        }
      }
    }

    return refiBalance;
  }

  public static double getCRAIntRefiBalance(DataNode lnDN, DataNode appDN) throws
      Exception
  {
    double refiBalance = 0.0;

    String refinancing = (String) lnDN.getFieldData(CSFieldValues.EMPTY_STRING,
        CSFieldNames.FN_LIEN_REFINANCING);

    if (refinancing != null && refinancing.equals(CSFieldValues.FV_LIEN_REFI))
    {
      String refiType = (String) lnDN.getFieldData(CSFieldValues.EMPTY_STRING,
          CSFieldNames.FN_LIEN_REFI_TYPE);

      if (refiType != null && refiType.equals(CSFieldValues.FV_LIEN_REFI_INT))
      {
        String lnDt = (String) lnDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                                 CSFieldNames.FN_LIEN_ORIG_DT);
        String appDt = (String) appDN.getFieldData(CSFieldValues.EMPTY_STRING,
            CSFieldNames.FN_APP_DT);

        if (lnDt != null && DateUtility.isValidSlashDate(lnDt) &&
            appDt != null && DateUtility.isValidSlashDate(appDt))
        {
          int lnDtYr = DateUtility.extractYearFromSlashDate(lnDt);
          int appDtYr = DateUtility.extractYearFromSlashDate(appDt);

          if (lnDtYr == appDtYr)
          {
            refiBalance = Double.parseDouble( (String) lnDN.getFieldData(
                CSFieldValues.EMPTY_STRING,
                CSFieldNames.FN_LIEN_BALANCE));
          }

        }
      }
    }

    return refiBalance;
  }

  // calc changed to use the loan balance or laon original amount depending on
  // the existing real estate lien information
  //
  public static double getNetLienBalance(DataNode lnDN) throws Exception
  {
    String refinancing = (String) lnDN.getFieldData(CSFieldValues.EMPTY_STRING, CSFieldNames.FN_LIEN_REFINANCING);

    if (refinancing == null || refinancing.equals(CSFieldValues.FV_LIEN_REFI))
    {
      return 0.0;
    }
    else
    {
      String creditLoanType = (String)lnDN.getFieldData(CSFieldValues.EMPTY_STRING, "lnCredTypD");

      if( creditLoanType != null && creditLoanType.trim().equals("Loan") )
      {
        return Double.parseDouble( (String) lnDN.getFieldData(CSFieldValues.EMPTY_STRING, CSFieldNames.FN_LIEN_BALANCE));
      }
      else if( creditLoanType != null && creditLoanType.trim().equals("Credit Line") )
      {
        return Double.parseDouble( (String) lnDN.getFieldData(CSFieldValues.EMPTY_STRING, CSFieldNames.FN_LIEN_ORIG_AMT));
      }
      else
      {
        return Double.parseDouble( (String) lnDN.getFieldData(CSFieldValues.EMPTY_STRING, CSFieldNames.FN_LIEN_BALANCE));
      }
    }
  }

  // used to calculate the no refi balance only
  //
  public static double calcNetLienBalance(DataNode lnDN) throws Exception
  {
    String refinancing = (String) lnDN.getFieldData(CSFieldValues.EMPTY_STRING, CSFieldNames.FN_LIEN_REFINANCING);

    if (refinancing == null || refinancing.equals(CSFieldValues.FV_LIEN_REFI))
    {
      return 0.0;
    }
    else
    {
      return Double.parseDouble( (String) lnDN.getFieldData(CSFieldValues.EMPTY_STRING, CSFieldNames.FN_LIEN_BALANCE));
    }
  }

  public static boolean isDefaultPurchaseMoneyLien(DataNode lienNode)
  {
    String lnDefPrpFlag =
        (String) lienNode.getSystemData(CSFieldNames.FN_LIEN_DEF_PROP);

    return (lnDefPrpFlag != null &&
            lnDefPrpFlag.equals(CSFieldValues.TRUE_STRING));
  }

  public static void updatePurchaseMoneyFirstLien(DataNode appNode,
                                                  DataNode lienNode)
  {
    lienNode.setSystemData(CSFieldNames.FN_LIEN_DEF_PROP,
                           CSFieldValues.TRUE_STRING);
    lienNode.setFieldData(CSFieldValues.EMPTY_STRING,
                          CSFieldNames.FN_LIEN_POSITION, "First");
    lienNode.setFieldData(CSFieldValues.EMPTY_STRING,
                          CSFieldNames.FN_LIEN_HOLDER, "Proposed Mortgage");

    String mtgBal = (String) appNode.getFieldData(CSFieldValues.EMPTY_STRING,
                                                  CSFieldNames.
                                                  FN_PRP_1ST_MTG_BAL);
    if (mtgBal != null)
    {
      lienNode.setFieldData(CSFieldValues.EMPTY_STRING,
                            CSFieldNames.FN_LIEN_ORIG_AMT, mtgBal);
      lienNode.setFieldData(CSFieldValues.EMPTY_STRING,
                            CSFieldNames.FN_LIEN_BALANCE, mtgBal);
    }
    else
    {
      lienNode.setFieldData(CSFieldValues.EMPTY_STRING,
                            CSFieldNames.FN_LIEN_ORIG_AMT, "0.00");
      lienNode.setFieldData(CSFieldValues.EMPTY_STRING,
                            CSFieldNames.FN_LIEN_BALANCE, "0.00");
    }

    String mtgPmt = (String) appNode.getFieldData(CSFieldValues.EMPTY_STRING,
                                                  CSFieldNames.
                                                  FN_PRP_1ST_MTG_AMT);
    if (mtgPmt != null)
    {
      lienNode.setFieldData(CSFieldValues.EMPTY_STRING,
                            CSFieldNames.FN_LIEN_PAYMENT, mtgPmt);
    }
    lienNode.setFieldData(CSFieldValues.EMPTY_STRING,
                          CSFieldNames.FN_LIEN_PAYMENT_PRD, "Monthly");
    lienNode.setFieldData(CSFieldValues.EMPTY_STRING,
                          CSFieldNames.FN_LIEN_REFINANCING, "0");
  }

  public static boolean isGuarantorLoan(DataNode appDN) throws Exception
  {
    boolean isGuarantorLoan = false;

    VectorX bwrVec = appDN.getReferences(NodeUtils.BWR_DN_TYPE);

    DataNode bwrDN = null;
    String bwrType = null;

    for (int i = 0; i < bwrVec.size(); i++)
    {
      bwrDN = (DataNode) bwrVec.elementAt(i);

      if (!bwrDN.isDeleted())
      {

        bwrType = (String) bwrDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                              CSFieldNames.FN_BWR_TYPE);
        if (bwrType.equals(CSFieldValues.FV_GUARANTOR))
        {
          isGuarantorLoan = true;
          break;
        }
      }
    }

    bwrVec = null;
    bwrDN = null;
    bwrType = null;

    return isGuarantorLoan;
  }

  public static VectorX getBusinessNodesGivenAppNode(DataNode appNode)
  {
    VectorX vx = null;
    if (appNode != null)
    {
      vx = appNode.getReferences(NodeUtils.BUS_DN_TYPE);
    }
    return vx;
  }

  public static VectorX getBorrowerNodesGivenAppNode(DataNode appNode)
  {
    return AppNode.getInstance().getBorrowerNodes(appNode);
  }

  public static String getAppNodeType(DataNode appNode)
  {
    return AppNode.getInstance().getAppNodeType(appNode);
  }

  // 9-4-07, ccl
  //
  /*
  public static boolean isBusinessApplication(DataNode appNode)
  {
    return!isConsumerApplication(appNode);
  }
  */
  public static boolean isConsumerApplication(DataNode appDN)
  {
    String type = getAppNodeType(appDN);
    return type == null || type.equals("c");
  }

  public static boolean isBusinessApplication(DataNode appDN)
  {
    String type = getAppNodeType(appDN);
    return type != null && type.equals("b");
  }

  public static boolean isMortgageApplication(DataNode appDN)
  {
    String type = getAppNodeType(appDN);
    return type != null && type.equals("m");
  }


  public static boolean isDepositApplication(DataNode appDN)
  {
    String type = getAppNodeType(appDN);
    return type != null && type.equals("d");
  }


  public static DataNode getBusinessNodeAtIndex(DataNode appNode, int index)
  {
    return AppNode.getInstance().getBusinessNodeAtIndex(appNode, index);
  }

  public static DataNode getAppNode(String appId)
  {
    return AppNode.getInstance().getAppNode(appId);
  }

  public static DataNode getBusinessNodeAtIndex(String appId, int index)
  {
    return AppNode.getInstance().getBusinessNodeAtIndex(getAppNode(appId),
        index);
  }

  public static VectorX getFinancialNodesGivenBusinessNode(DataNode busNode)
  {
    VectorX vx = null;
    if (busNode != null)
    {
      vx = busNode.getReferences(NodeUtils.BUS_BAL_DN_TYPE);
    }
    return vx;
  }

  public static DataNode getInterimFinancialNode(VectorX vx)
  {
    // financila nodes are  for a business
    // the vector contains Financials
    DataNode financialNode = null;
    if (vx != null && !vx.isEmpty())
    {
      int size = vx.size();
      String interimStr = "Interim",
          bfBSPrdDtDStr = "_bfBSPrdDtD";

      for (int i = 0; i < size; i++)
      {
        financialNode = (DataNode) vx.get(i);
        //if (financialNode != null)   // 12-20-06, ccl
        if (financialNode != null && !financialNode.isDeleted())
        {
          if (interimStr.equalsIgnoreCase( (SBDataEntrySupport.
                                            getStringFromDataNode(financialNode,
              bfBSPrdDtDStr))))
          {
            i = size + 1;
          }
          else
          {
            financialNode = null;
          }
        }
      }
    }
    return financialNode;
  }

  public static int get4DigitPreviousYearGivenBusinessNodeAndYearWanted(
      DataNode busNode, int previousYrWanted)
  {
    String todaysDate = DateUtility.getTodaysDate("MDY", "/");
    int currentYr = DateUtility.extractYearFromSlashDate(todaysDate);
    int prvYr1 = 0;
    // If there are no fiscal year end value, we will default it to 06/30. This may
    // handle the old applications which may have no such value because it is not
    // required in the past.
    //
    String fiscYrEnd = SBDataEntrySupport.getStringFromDataNode(busNode,
        CSFieldNames.FN_BUS_FISC_YR_END);

    if (fiscYrEnd == null || fiscYrEnd.length() == 0)
    {
      fiscYrEnd = "06/30";
    }

    // Since the value of field "fiscal year end" has only month and date, so we need
    // to append the year for comparison.
    //
    String fiscYr = fiscYrEnd + "/" + currentYr;
    //general.errLog("SBDataEntrySupport: createBalSh: fiscTr = " + fiscYr);

    // The norm to calculate the fiscal year is like this:
    // If the fiscal year ends with December 31, then the fiscal year is the same
    // as calandar year; otherwise, the fiscal year is one year more than calandar
    // year. For example, if the fiscal year is ended with June 30, then the fiscal
    // year 2004 is from 7/1/2003 to 6/30/2004. Got it?
    //
    if (DateUtility.afterWithSlashDate(fiscYr, todaysDate))
    {
      // If today's date is after the fiscal year end
      //

      prvYr1 = currentYr - previousYrWanted + 1;
    }
    else
    {
      // The fiscal year is the same as calandar year
      //
      prvYr1 = currentYr - previousYrWanted;
    }
    return prvYr1;
  }

  public static DataNode getFinancialNodeForGivenYear(VectorX vx, int year)
  {
    // financila nodes are for a business
    // the vector contains financial nodes
    //
    DataNode financialNode = null;
    if (vx != null && !vx.isEmpty())
    {
      int size = vx.size();
      for (int i = 0; i < size; i++)
      {
        financialNode = (DataNode) vx.get(i);
        if (financialNode != null)
        {
          if (year ==
              SBDataEntrySupport.getYearGivenFinancialNode(financialNode))
          {
            i = size + 1;
          }
          else
          {
            financialNode = null;
          }
        }
      }
    }
    return financialNode;
  }


  public static DataNode getBorrowerWithID(String custID, DataNode appNode)
  {
    DataNode theBwr = null;

    List borrowers = appNode.getEffectiveReferences(NodeUtils.BWR_DN_TYPE);

    String bwrCustID;
    DataNode bwrNode;
    for (int i = 0, c = borrowers.size(); i < c; ++i)
    {
      bwrNode = (DataNode)borrowers.get(i);

      bwrCustID = (String)bwrNode.getFieldData("", CSFieldNames.FN_CUST_ID);
      if (bwrCustID != null && bwrCustID.equals(custID))
      {
        theBwr = bwrNode;
        break;
      }
    }

    return theBwr;
  }

  public static DataNode getBorrowerNodeAtIndex(DataNode appNode, int index)
  {

    return AppNode.getInstance().getBorrowerNodeAtIndex(appNode, index);
  }

  public static DataNode getBorrowerNodeAtIndex(String appId, int index)
  {
    return AppNode.getInstance().getBorrowerNodeAtIndex(appId, index);
  }

  public static VectorX getTradeNodesGivenBorrowerNode(DataNode bwrNode)
  {
    return BwrNode.getInstance().getTradeNodesGivenBorrowerNode(bwrNode);
  }

  public static DataNode getAdjustmentNodeGivenBorrowerNode(DataNode bwrNode)
  {
    return BwrNode.getInstance().getAdjustmentNodeGivenBorrowerNode(bwrNode);
  }

  public static GenericProduct getProductFromAppNode(DataNode appNode) throws
      Exception
  {
    // 9-17-07, ccl
    /*
    boolean isConsumer = isConsumerApplication(appNode);
    return AppNode.getInstance().getProductFromAppNode(appNode, isConsumer);
    */
   return AppNode.getInstance().getProductFromAppNode(appNode);
  }

  public static boolean isCreditOrRevolvingApp(DataNode appDN) throws Exception
  {
    boolean isConsumer = isConsumerApplication(appDN);
    boolean isMortgage = isMortgageApplication(appDN);

    String prodID = (isConsumer || isMortgage)?
        (String) appDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                    CSFieldNames.FN_PRODUCT_ID) :
        (String) appDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                    CSFieldNames.FN_SBPRODUCT_ID);

    if (prodID == null)
    {
      throw new Exception("Product ID not found.");
    }

    Product product = null;
    SBProduct sbProduct = null;
    MtgProduct mgProduct = null;

    if (isConsumer)
    {
      product = CSDataCache.getProductManager().getProduct(prodID);
    }
    else if (isMortgage)
    {
      mgProduct = CSDataCache.getMtgProductManager().getProduct(prodID);
    }
    else
    {
      sbProduct = CSDataCache.getSBProductManager().getProduct(prodID);
    }

    if (product == null && sbProduct == null && mgProduct == null)
    {
      throw new Exception("Product not found in data cache.");
    }

    String prdType = isConsumer ? product.getProductType() :
        isMortgage ? mgProduct.getProductType() :
        sbProduct.getProductType();

    String lnType = isConsumer ? product.getLoanType() :
        isMortgage ? mgProduct.getLoanType() :
        sbProduct.getLoanType();

    boolean isCredit = prdType.equals(CSFieldValues.FV_PRODUCT_TYPE_CREDIT) ||
        prdType.equals(CSFieldValues.FV_PRODUCT_TYPE_REVOLVE) ||
        lnType.equals(CSFieldValues.FV_PRODLOAN_TYPE_LOC) ||
        lnType.equals(CSFieldValues.FV_PRODLOAN_TYPE_REVOLVE);

    return isCredit;
  }


  public static boolean isCSCloseDocPrepAllowedByProduct(DataNode appDN) throws
      Exception
  {
    boolean okToPrint = false;

    String appType = (String) appDN.getSystemData(CSFieldNames.FN_APP_TYPE);

    if (appType != null && appType.trim().equals("c"))
    {
      String prodID = (String) appDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                                  CSFieldNames.FN_PRODUCT_ID);
      Product prd = CSDataCache.getProductManager().getProduct(prodID);
      okToPrint = prd.getCloseDocsOK().trim().equals(CSFieldValues.TRUE_STRING);
    }
    else if (appType != null && appType.trim().equals("m"))
    {
      // 10-22-09, ccl
      // check the program first
      //
      /*
       String prodID = (String) appDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                                  CSFieldNames.FN_PRODUCT_ID);
       MtgProduct prd = CSDataCache.getMtgProductManager().getProduct(prodID);
       okToPrint = prd.getCloseDocsOK().trim().equals(CSFieldValues.TRUE_STRING);
       */
      String prodID = null;
      MtgProduct prd = null;
      HashtableX docPrepSetupTables = null;

      String pgId = (String)appDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                                  CSFieldNames.FN_PROGRAM_ID);
      Program program = null;
      if (pgId != null && pgId.length() > 0)
      {
        program = CSDataCache.getProgramManager().getProgram(pgId);

        if (program != null)
        {
          docPrepSetupTables = program.getDocPrepSetupTable();

          if (docPrepSetupTables != null && !docPrepSetupTables.isEmpty())
          {
            okToPrint = program.getPgCSClsgDocsC();
          }
          else
          {
            // use product's
            //
            prodID = (String) appDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                                    CSFieldNames.FN_PRODUCT_ID);
            prd = CSDataCache.getMtgProductManager().getProduct(prodID);
            okToPrint = prd.getCloseDocsOK().trim().equals(CSFieldValues.TRUE_STRING);
          }
        }
        else
        {
          // use product's
          //
          prodID = (String) appDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                                  CSFieldNames.FN_PRODUCT_ID);
          prd = CSDataCache.getMtgProductManager().getProduct(prodID);
          okToPrint = prd.getCloseDocsOK().trim().equals(CSFieldValues.TRUE_STRING);
        }
      }
      else
      {
        // use product's
        //
        prodID = (String) appDN.getFieldData(CSFieldValues.EMPTY_STRING,
            CSFieldNames.FN_PRODUCT_ID);
        prd = CSDataCache.getMtgProductManager().getProduct(prodID);
        okToPrint = prd.getCloseDocsOK().trim().equals(CSFieldValues.
            TRUE_STRING);
      }
    }
    else
    {
      if (appType != null && appType.trim().equals("b"))
      {
        String prodID = (String) appDN.getFieldData(CSFieldValues.EMPTY_STRING,
            CSFieldNames.FN_SBPRODUCT_ID);
        SBProduct sbPrd = CSDataCache.getSBProductManager().getProduct(prodID);
        okToPrint = sbPrd.getCloseDocsOK().trim().equals(CSFieldValues.
            TRUE_STRING);
      }
    }
//    else
//    if (appType != null && appType.trim().equals("d"))
//    {
//      // LEND-785 - See other 'isCSCloseDocPrepAllowedByProduct()'
//      // for Deposit handling
//      //
//    } // if - Deposit

    return okToPrint;

  } // isCSCloseDocPrepAllowedByProduct( DataNode )


  public static boolean isCSCloseDocPrepAllowedByProduct( DataNode appDN, HashtableX inFieldsHash ) throws
  Exception
  {
    boolean okToPrint = false;

    String appType = (String)appDN.getSystemData( CSFieldNames.FN_APP_TYPE );

    if ((appType != null) && appType.trim().equals( "c" ))
    {
      String prodID = (String)appDN.getFieldData( CSFieldValues.EMPTY_STRING,
                                                  CSFieldNames.FN_PRODUCT_ID );

      Product prd = CSDataCache.getProductManager().getProduct( prodID );

      okToPrint = prd.getCloseDocsOK().trim().equals( CSFieldValues.TRUE_STRING );

    } // if - Consumer
    else
    if ((appType != null) && appType.trim().equals( "m" ))
    {
      // 10-22-09, ccl
      // check the program first
      //
      /*
      String prodID = (String) appDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                                CSFieldNames.FN_PRODUCT_ID);
      MtgProduct prd = CSDataCache.getMtgProductManager().getProduct(prodID);
      okToPrint = prd.getCloseDocsOK().trim().equals(CSFieldValues.TRUE_STRING);
      */
      String prodID = null;
      MtgProduct prd = null;
      HashtableX docPrepSetupTables = null;

      Program program = null;

      boolean useProductsFlag = false;

      String pgId = (String)appDN.getFieldData( CSFieldValues.EMPTY_STRING,
                                                CSFieldNames.FN_PROGRAM_ID );
      if ((pgId != null) && (pgId.length() > 0))
      {
        program = CSDataCache.getProgramManager().getProgram( pgId );

        if (program != null)
        {
          docPrepSetupTables = program.getDocPrepSetupTable();

          if ((docPrepSetupTables != null) && ( ! docPrepSetupTables.isEmpty()))
          {
            okToPrint = program.getPgCSClsgDocsC();
          }
          else
          {
            // use product's
            //
            useProductsFlag = true;
          }
        }
        else
        {
          // use product's
          //
          useProductsFlag = true;
        }
      }
      else
      {
        // use product's
        //
        useProductsFlag = true;
      }

      if (useProductsFlag)
      {
        // use product's
        //
        prodID = (String)appDN.getFieldData( CSFieldValues.EMPTY_STRING,
                                             CSFieldNames.FN_PRODUCT_ID );

        prd = CSDataCache.getMtgProductManager().getProduct( prodID );

        okToPrint = prd.getCloseDocsOK().trim().equals( CSFieldValues.TRUE_STRING );

      } // if - use the product's flag

    } // if - Mortgage
    else
    if ((appType != null) && appType.trim().equals( "b" ))
    {
      String prodID = (String)appDN.getFieldData( CSFieldValues.EMPTY_STRING,
                                                  CSFieldNames.FN_SBPRODUCT_ID );

      SBProduct sbPrd = CSDataCache.getSBProductManager().getProduct( prodID );

      okToPrint = sbPrd.getCloseDocsOK().trim().equals( CSFieldValues.TRUE_STRING );

    } // if - Business
    else
    if (appType != null && appType.trim().equals( "d" ))
    {
      // LEND-785
      //
      String depIndex = (String)inFieldsHash.get( "depAcctNodeIndex" );

      DataNode depAcctDN =
        (DataNode)appDN.getReference(
          "depAccount", StringSupport.changeStringToInt( depIndex ));

      String prodID = (String)depAcctDN.getFieldData( "", "daProdTypeD" );

      DepProduct prd = CSDataCache.getDepProductManager().getProduct( prodID );

      okToPrint = prd.getCloseDocsOK().trim().equals( CSFieldValues.TRUE_STRING );

    } // if - Deposit


    return okToPrint;

  } // isCSCloseDocPrepAllowedByProduct( DataNode , HashtableX )


  public static List getCSCloseDocAllowedErrors(DataNode appDN) throws
      Exception
  {
    ArrayList errors = new ArrayList();

    if (!isCSCloseDocPrepAllowedByProduct(appDN))
    {
      errors.add(
          "Product does not allow closing documents to be printed in S1 Lending.");
    }

    if (isGuarantorLoan(appDN))
    {
      errors.add("Guarantor loan.");
    }

    if (isRegOLoan(appDN))
    {
      errors.add("Regulation O loan.");
    }

    if (isConstructionLoan(appDN))
    {
      errors.add("Construction loans.");
    }

    if (isFirstPmtDateDelayed(appDN, DELAY_DAYS))
    {
      errors.add("Delayed first payment date.");
    }

    if (isRegistrationForeign(appDN))
    {
      errors.add("Non-standard Registration state.");
    }

    if (hasSpecialAccount(appDN))
    {
      errors.add("Collateral characteristic of one or more of the following:");
      errors.add("\tCollateral requires multiple signatures.");
      errors.add("\tCollateral is payable on death.");
      errors.add("\tCollateral is in the name of a minor.");
      errors.add("\tCollateral is issued by another institution.");
      errors.add("\tCollateral requires book entry.");
    }

    if ( (hasThirdPartyOwner(appDN) &&
          ! (isCDSecuredWithThirdPartyOwner(appDN) &&
             isCreditOrRevolvingApp(appDN))))
    {
      errors.add("Third party owner.");
    }

    String intRate = (String) appDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                                 CSFieldNames.FN_INT_RATE);

    if (intRate != null)
    {
      double rate = Double.parseDouble(intRate);

      if (rate == 0.0)
      {
        errors.add("Interest rate is zero.");
      }
    }
    else
    {
      errors.add("Missing interest rate.");
    }

    return errors;
  }

  public static HashtableX defaultFirstPaymentDate(HashtableX inFieldsHash, DataNode appDN) throws Exception
  {
    //general.errLog("START defaultFirstPaymentDate(HashtableX inFieldsHash, DataNode appDN)", "DfltFrstPmtDt.log");

    HashtableX outFieldsHash = new HashtableX();

    String disDateStr = (String) inFieldsHash.get(CSFieldNames.FN_DISBURSE_DATE);
    //general.errLog("disDateStr: "+disDateStr, "DfltFrstPmtDt.log");

    Object pmtPrdObject = inFieldsHash.get(CSFieldNames.FN_PMT_PRD);

    boolean isMortgage = isMortgageApplication(appDN);

    Date date = null;

    //general.errLog("if (pmtPrdObject != null)"+(pmtPrdObject != null), "DfltFrstPmtDt.log");
    if (pmtPrdObject != null)
    {
      String pmtPrd = null;
      if (pmtPrdObject instanceof String)
      {
        pmtPrd = (String) pmtPrdObject;
      }
      else
      {
        // pmtPrd = (String) ((VectorX) pmtPrdObject).firstElement();
        //
        VectorX pmtVec = (VectorX) pmtPrdObject;
        if( pmtVec != null && ! pmtVec.isEmpty() )
        {
          pmtPrd = (String)pmtVec.firstElement();
        }

      }

      //general.errLog("pmtPrd: "+pmtPrd, "DfltFrstPmtDt.log");

      if( pmtPrd != null && pmtPrd.trim().length() > 0 )
      {
        date = getFirstPaymentDate(appDN, disDateStr, pmtPrd);

        //general.errLog("1.0 date: "+date, "DfltFrstPmtDt.log");

        if (date != null)
        {
          if (isMortgage)
          {
            Calendar cal = Calendar.getInstance();

            cal.setTime(date);

            if (cal.get(cal.DAY_OF_MONTH) != 1)
            {
              cal.add(Calendar.MONTH, 1);
              cal.set(cal.DAY_OF_MONTH, 1);
              date = cal.getTime();
            }
          }

          //general.errLog("1.1 date: "+date, "DfltFrstPmtDt.log");
          outFieldsHash.put(CSFieldNames.FN_1ST_PMT_DT, DateUtility.assignJavaDateToSlashDate(date));
          //general.errLog("SET "+CSFieldNames.FN_1ST_PMT_DT+": "+ DateUtility.assignJavaDateToSlashDate(date), "DfltFrstPmtDt.log");
        }
      }
    } // if (pmtPrdObject != null)

    Object intPmtPrdObject = inFieldsHash.get(CSFieldNames.FN_INT_PMT_PRD);

    //general.errLog("if (intPmtPrdObject != null)"+(intPmtPrdObject != null), "DfltFrstPmtDt.log");
    if (intPmtPrdObject != null)
    {
      String intPmtPrd = null;
      if (intPmtPrdObject instanceof String)
      {
        intPmtPrd = (String) intPmtPrdObject;
      }
      else
      {
        // intPmtPrd = (String) ( (VectorX) intPmtPrdObject).firstElement();
        //
        VectorX intPmtPrdVec = (VectorX)intPmtPrdObject;
        if( intPmtPrdVec != null && ! intPmtPrdVec.isEmpty() )
        {
          intPmtPrd = (String)intPmtPrdVec.firstElement();
        }
      }

      //general.errLog("intPmtPrd: "+intPmtPrd, "DfltFrstPmtDt.log");

      if( intPmtPrd != null && intPmtPrd.trim().length() > 0 )
      {
        date = getFirstPaymentDate(appDN, disDateStr, intPmtPrd);
        //general.errLog("2.0 date: "+date, "DfltFrstPmtDt.log");

        if (date != null)
        {
          if (isMortgage)
          {
            Calendar cal = Calendar.getInstance();
            cal.setTime(date);
            cal.set(cal.DAY_OF_MONTH,1);
            cal.add(Calendar.MONTH,1);
            date = cal.getTime();
          }

          //general.errLog("2.1 date: "+date, "DfltFrstPmtDt.log");
          outFieldsHash.put(CSFieldNames.FN_1ST_INT_PMT_DT, DateUtility.assignJavaDateToSlashDate(date));
          //general.errLog("SET "+CSFieldNames.FN_1ST_INT_PMT_DT+": "+ DateUtility.assignJavaDateToSlashDate(date), "DfltFrstPmtDt.log");
        }
      }
    } // if (intPmtPrdObject != null)

    //general.errLog("return outFieldsHash: "+outFieldsHash, "DfltFrstPmtDt.log");
    //general.errLog("START defaultFirstPaymentDate(HashtableX inFieldsHash, DataNode appDN)", "DfltFrstPmtDt.log");

    return outFieldsHash;
  }

  public static Date getFirstPaymentDate(DataNode appDN,
                                         String loanDt, String pmtPrd) throws
      Exception
  {
    Date firstPmtDt = null;

    Calendar cal = Calendar.getInstance();

    cal.setTime(DateUtility.assignSlashDateToJavaDate(loanDt));

    if (pmtPrd.equals(CSFieldValues.FV_MONTH) ||
        pmtPrd.equals(CSFieldValues.FV_WEEK) ||
        pmtPrd.equals(CSFieldValues.FV_BIWEEK) ||
        pmtPrd.equals(CSFieldValues.FV_SEMIMONTH))
    {
      //cal.add(cal.MONTH, 1);   // 3-3-09, ccl
      String defDaysStr = SystemProperties.getProperty(CSFieldNames.SYS_DEF_PMT_DAYS);

      if ( defDaysStr != null )
      {
        try
        {
          int defDays = Integer.parseInt(defDaysStr);
          cal.add(cal.DAY_OF_MONTH, defDays);
        }
        catch (NumberFormatException e) {
          throw new Exception("Invalid default_payment_days: " + defDaysStr);
        }
      }
      else
      {
        cal.add(cal.MONTH, 1);
      }
      firstPmtDt = cal.getTime();
    }
    else
    {
      if (pmtPrd.equals(CSFieldValues.FV_QUARTER))
      {
        cal.add(cal.MONTH, 3);
        firstPmtDt = cal.getTime();
      }
      else
      {
        if (pmtPrd.equals(CSFieldValues.FV_SEMIANNUAL))
        {
          cal.add(cal.MONTH, 6);
          firstPmtDt = cal.getTime();
        }
        else
        {
          if (pmtPrd.equals(CSFieldValues.FV_ANNUAL))
          {
            cal.add(cal.YEAR, 1);
            firstPmtDt = cal.getTime();
          }
          else
          {
            if (pmtPrd.equals(CSFieldValues.FV_MATURITY))
            {
              if (appDN != null)
              {
                firstPmtDt = getMaturityDate(appDN);
              }
            }
          }
        }
      }
    }

    return firstPmtDt;
  }

  public static boolean isDateDiffBy(DataNode appDN, String pmtPrd,
                                     String pmtDtStr, String loanDtStr,
                                     int NumberOfDays) throws Exception
  {
    boolean delayed = false;

    Date pmtDate = DateUtility.assignSlashDateToJavaDate(pmtDtStr);
    Date defDate = getFirstPaymentDate(appDN, loanDtStr, pmtPrd);
    if (defDate != null)
    {
      Calendar cal = Calendar.getInstance();

      cal.setTime(defDate);
      cal.add(cal.DAY_OF_MONTH, NumberOfDays);

      Date lastDate = cal.getTime();

      if (lastDate.before(pmtDate))
      {
        delayed = true;
      }
    }

    return delayed;
  }

  public static String getPaymentPeriod(HashtableX inFieldsHash) throws
      Exception
  {
    String pmtPrd = null;

    Object pmtTypeObject = inFieldsHash.get(CSFieldNames.FN_PMT_TYPE);

    String pmtType = null;
    if (pmtTypeObject instanceof String)
    {
      pmtType = (String) pmtTypeObject;
    }
    else
    {
      pmtType = (String) ( (VectorX) pmtTypeObject).firstElement();
    }

    if (pmtType.equals(CSFieldValues.FV_INSTALLMENT) ||
        pmtType.equals(CSFieldValues.FV_BALLOON) ||
        pmtType.equals(CSFieldValues.FV_FNMA_BIWEEKLY_INST))
    {
      pmtPrd = (String) inFieldsHash.get(CSFieldNames.FN_PMT_PRD);
    }

    else
    {
      if (pmtType.equals(CSFieldValues.FV_PRININT))
      {
        pmtPrd = (String) inFieldsHash.get("anPrnPmtPrdD");
      }

      else
      {
        pmtPrd = CSFieldValues.FV_MATURITY;
      }
    }

    return pmtPrd;
  }

  public static int calcTermInMonths(HashtableX inFieldsHash) throws Exception
  {
    int term = 0;

    int numOfPmts = Integer.parseInt( (String) inFieldsHash.get(CSFieldNames.
        FN_NUM_PMT));

    String pmtPrd = (String) inFieldsHash.get(CSFieldNames.FN_PMT_PRD); ;

    if (pmtPrd.equals(CSFieldValues.FV_MONTH))
    {
      term = numOfPmts;
    }
    else
    {
      if (pmtPrd.equals(CSFieldValues.FV_WEEK))
      {
        term = (int) Math.ceil(FinCalcs.round(numOfPmts / 4.3333, 2));
      }
      else
      {
        if (pmtPrd.equals(CSFieldValues.FV_BIWEEK))
        {
          term = (int) Math.ceil(FinCalcs.round(numOfPmts / 2.1666, 2));
        }
        else
        {
          if (pmtPrd.equals(CSFieldValues.FV_SEMIMONTH))
          {
            term = (int) Math.ceil(FinCalcs.round(numOfPmts / 2.0, 2)); ;
          }
          else
          {
            if (pmtPrd.equals(CSFieldValues.FV_QUARTER))
            {
              term = numOfPmts * 3;
            }
            else
            {
              if (pmtPrd.equals(CSFieldValues.FV_SEMIANNUAL))
              {
                term = numOfPmts * 6;
              }
              else
              {
                if (pmtPrd.equals(CSFieldValues.FV_ANNUAL))
                {
                  term = numOfPmts * 12;
                }
                else
                {
                  if (pmtPrd.equals(CSFieldValues.FV_MATURITY))
                  {
                    term = (int) DateUtility.diffMonthsUsingSlashDates(
                        (String) inFieldsHash.get(CSFieldNames.FN_DUE_DT),
                        (String) inFieldsHash.get(CSFieldNames.FN_DISBURSE_DATE));
                  }
                }
              }
            }
          }
        }
      }
    }

    return term;
  }

  public static boolean isFirstPmtDateDelayed(DataNode appDN, int numberOfDays) throws
      Exception
  {
    boolean delayed = false;

    if (!isCreditOrRevolvingApp(appDN))
    {
      String pmtType = (String) appDN.getFieldData(CSFieldValues.EMPTY_STRING,
          CSFieldNames.FN_PMT_TYPE);
      String loanDtStr = (String) appDN.getFieldData(CSFieldValues.EMPTY_STRING,
          CSFieldNames.FN_DISBURSE_DATE);
      String pmtPrd = null;
      String pmtDtStr = null;

      if (pmtType.equals(CSFieldValues.FV_INSTALLMENT) ||
          pmtType.equals(CSFieldValues.FV_BALLOON) ||
          pmtType.equals(CSFieldValues.FV_FNMA_BIWEEKLY_INST))
      {
        pmtPrd = (String) appDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                             CSFieldNames.FN_PMT_PRD);
        pmtDtStr = (String) appDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                               CSFieldNames.FN_1ST_PMT_DT);

        delayed = isDateDiffBy(appDN, pmtPrd, pmtDtStr, loanDtStr, numberOfDays);
      }

      // adjustment made to handle the new vista associated with the single paymnt type.
      // vista: Single_Payment_Details_
      //
      else
      {
        if (pmtType.equals(CSFieldValues.FV_SINGLE_INT))
        {
          pmtPrd = (String) appDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                               CSFieldNames.FN_INT_PMT_PRD);
          pmtDtStr = (String) appDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                                 CSFieldNames.FN_1ST_INT_PMT_DT);

          delayed = isDateDiffBy(appDN, pmtPrd, pmtDtStr, loanDtStr,
                                 numberOfDays);

        }
        else
        {
          if (pmtType.equals(CSFieldValues.FV_PRININT))
          {
            pmtPrd = (String) appDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                                 CSFieldNames.FN_INT_PMT_PRD);
            pmtDtStr = (String) appDN.getFieldData(CSFieldValues.EMPTY_STRING,
                CSFieldNames.FN_1ST_INT_PMT_DT);

            delayed = isDateDiffBy(appDN, pmtPrd, pmtDtStr, loanDtStr,
                                   numberOfDays);

            if (!delayed)
            {
              pmtPrd = (String) appDN.getFieldData(CSFieldValues.EMPTY_STRING,
                  CSFieldNames.FN_PMT_PRD);
              pmtDtStr = (String) appDN.getFieldData(CSFieldValues.EMPTY_STRING,
                  CSFieldNames.FN_1ST_PMT_DT);

              delayed = isDateDiffBy(appDN, pmtPrd, pmtDtStr, loanDtStr,
                                     numberOfDays);
            }
          }
        }
      }
    }

    return delayed;
  }

  public static String calcLoanMaturityDate(HashtableX fieldsHash) throws
      Exception
  {
    String matDt = null;
    String pmtDt = (String) fieldsHash.get(CSFieldNames.FN_1ST_PMT_DT);
    String firstEndStr = (String) fieldsHash.get(CSFieldNames.FN_PMT_END);
    boolean isFirstEnd = firstEndStr != null &&
                         firstEndStr.equals(CSFieldValues.TRUE_STRING);

    if (pmtDt == null)
    {
      throw new Exception("Payment date is null.");
    }
    String numPmtsStr = (String) fieldsHash.get(CSFieldNames.FN_NUM_PMT);
    if (numPmtsStr == null || numPmtsStr.trim().length() == 0) {
    	return matDt;
    }
    int numOfPmts = Integer.parseInt(numPmtsStr);

    String pmtType = (String) fieldsHash.get(CSFieldNames.FN_PMT_TYPE_RADIO);

    if (pmtType != null && pmtType.equals(CSFieldValues.FV_FNMA_BIWEEKLY_RD))
    {
      // Cheat.
      numOfPmts = Integer.parseInt( (String) fieldsHash.get(CSFieldNames.
          FN_AMORT_PRD));
      numOfPmts *= 2;
    }

    Calendar cal = Calendar.getInstance();
    cal.setTime(DateUtility.assignSlashDateToJavaDate(pmtDt));
    if (isFirstEnd)
    {
      // really first end?
      if (cal.getActualMaximum(Calendar.DAY_OF_MONTH) !=
          cal.get(Calendar.DAY_OF_MONTH))
      {
        isFirstEnd = false;
      }
    }

    String pmtPrd = null;

    Object obj = fieldsHash.get(CSFieldNames.FN_PMT_PRD);

    if (obj instanceof String)
      pmtPrd = (String)obj;
    else if (obj instanceof VectorX)
      pmtPrd = (String)((VectorX)obj).firstElement();

    if (pmtPrd.equals(CSFieldValues.FV_MONTH))
    {
      cal.add(cal.MONTH, numOfPmts - 1);
      if (isFirstEnd)
      {
        cal.set(Calendar.DAY_OF_MONTH,
                cal.getActualMaximum(Calendar.DAY_OF_MONTH));
      }
      matDt = DateUtility.assignJavaDateToSlashDate(cal.getTime());
    }
    else
    {
      if (pmtPrd.equals(CSFieldValues.FV_BIWEEK))
      {
        cal.add(cal.WEEK_OF_YEAR, (numOfPmts - 1) * 2);
        matDt = DateUtility.assignJavaDateToSlashDate(cal.getTime());
      }
      else
      {
        if (pmtPrd.equals(CSFieldValues.FV_WEEK))
        {
          cal.add(cal.WEEK_OF_YEAR, numOfPmts - 1);
          matDt = DateUtility.assignJavaDateToSlashDate(cal.getTime());
        }
        else
        {
          if (pmtPrd.equals(CSFieldValues.FV_SEMIMONTH))
          {
            cal.add(cal.MONTH, (numOfPmts - 1) / 2);

            int dayOfMonth = cal.get(cal.DAY_OF_MONTH);

            if (dayOfMonth < 16)
            {
              if (cal.get(cal.MONTH) == cal.FEBRUARY && dayOfMonth > 13)
              {
                cal.set(cal.DAY_OF_MONTH,
                        FinCalcs.isLeapYear(cal.get(cal.YEAR)) ? 29 : 28);
              }
              else
              {
                cal.add(cal.DAY_OF_MONTH, 15 * ( (numOfPmts - 1) % 2));
              }
            }
            else
            {
              cal.add(cal.DAY_OF_MONTH, -15 * ( (numOfPmts - 1) % 2));
              cal.add(cal.MONTH, 1 * ( (numOfPmts - 1) % 2));
            }

            if (cal.get(cal.DAY_OF_MONTH) == 31)
            {
              cal.add(cal.DAY_OF_MONTH, 1);
            }
            matDt = DateUtility.assignJavaDateToSlashDate(cal.getTime());
          }
          else
          {
            if (pmtPrd.equals(CSFieldValues.FV_QUARTER))
            {
              cal.add(cal.MONTH, (numOfPmts - 1) * 3);
              if (isFirstEnd)
              {
                cal.set(Calendar.DAY_OF_MONTH,
                        cal.getActualMaximum(Calendar.DAY_OF_MONTH));
              }
              matDt = DateUtility.assignJavaDateToSlashDate(cal.getTime());
            }
            else
            {
              if (pmtPrd.equals(CSFieldValues.FV_SEMIANNUAL))
              {
                cal.add(cal.MONTH, (numOfPmts - 1) * 6);
                if (isFirstEnd)
                {
                  cal.set(Calendar.DAY_OF_MONTH,
                          cal.getActualMaximum(Calendar.DAY_OF_MONTH));
                }
                matDt = DateUtility.assignJavaDateToSlashDate(cal.getTime());
              }
              else
              {
                if (pmtPrd.equals(CSFieldValues.FV_ANNUAL))
                {
                  cal.add(cal.MONTH, (numOfPmts - 1) * 12);
                  if (isFirstEnd)
                  {
                    cal.set(Calendar.DAY_OF_MONTH,
                            cal.getActualMaximum(Calendar.DAY_OF_MONTH));
                  }
                  matDt = DateUtility.assignJavaDateToSlashDate(cal.getTime());
                }
              }
            }
          }
        }
      }
    }

    return matDt;
  }

  public static boolean isForeignIssuer(DataNode spColDN, String type) throws
      Exception
  {
    String holder = (String) spColDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                                  CL_NODE_PREFIX + type +
                                                  CSFieldNames.
                                                  FN_SFX_HOLDER_RADIO);

    return holder != null && holder.equals(CSFieldValues.FV_HLDR_OTHER_ISSUER);
  }

  public static boolean isPayableOnDeath(DataNode spColDN, String type) throws
      Exception
  {
    String poc = (String) spColDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                               CL_NODE_PREFIX + type +
                                               CSFieldNames.FN_SFX_PAY_DEATH);

    return poc != null && poc.equals(CSFieldValues.TRUE_STRING);
  }

  public static boolean isNameOfMinor(DataNode spColDN, String type) throws
      Exception
  {
    String minor = (String) spColDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                                 CL_NODE_PREFIX + type +
                                                 CSFieldNames.FN_SFX_MINOR);

    return minor != null && minor.equals(CSFieldValues.TRUE_STRING);
  }

  public static boolean isAcctRequireMultSign(DataNode spColDN, String type) throws
      Exception
  {
    String mlSgn = (String) spColDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                                 CL_NODE_PREFIX + type +
                                                 CSFieldNames.FN_SFX_MULT_SIGN);

    return mlSgn != null && mlSgn.equals(CSFieldValues.TRUE_STRING);
  }

  public static boolean isBookEntry(DataNode spColDN, String type) throws
      Exception
  {
    String bkEntry = (String) spColDN.getFieldData(CSFieldValues.EMPTY_STRING,
        CL_NODE_PREFIX + type + CSFieldNames.FN_SFX_BOOK_ENTRY);

    return bkEntry != null && bkEntry.equals(CSFieldValues.TRUE_STRING);
  }

  public static boolean hasSpecialAccount(DataNode appDN) throws Exception
  {

    boolean hasSpecialAccount = false;

    DataNode colDN = appDN.getReference(NodeUtils.COLL_DN_TYPE, 0);

    // if no collateral at all then return Unsecured.

    if (colDN != null)
    {
      VectorX cdCollVec = colDN.getReferences(NodeUtils.CD_DN_TYPE);
      VectorX ckCollVec = colDN.getReferences(NodeUtils.CK_DN_TYPE);
      VectorX svCollVec = colDN.getReferences(NodeUtils.SV_DN_TYPE);

      DataNode spColDN = null;

      if (cdCollVec != null && !cdCollVec.isEmpty())
      {

        for (int i = 0; i < cdCollVec.size(); i++)
        {
          spColDN = (DataNode) cdCollVec.elementAt(i);

          if (!spColDN.isDeleted())
          {
            if (isAcctRequireMultSign(spColDN, CD_NODE_PREFIX) ||
                isPayableOnDeath(spColDN, CD_NODE_PREFIX) ||
                isNameOfMinor(spColDN, CD_NODE_PREFIX) ||
                isForeignIssuer(spColDN, CD_NODE_PREFIX) ||
                isBookEntry(spColDN, CD_NODE_PREFIX))
            {
              hasSpecialAccount = true;
              break;
            }
          } // end delete check

        } // end for loop

      } // end check for cd collateral

      if (!hasSpecialAccount && ckCollVec != null && !ckCollVec.isEmpty())
      {

        for (int i = 0; i < ckCollVec.size(); i++)
        {
          spColDN = (DataNode) ckCollVec.elementAt(i);

          if (!spColDN.isDeleted())
          {
            if (isAcctRequireMultSign(spColDN, CK_NODE_PREFIX) ||
                isPayableOnDeath(spColDN, CK_NODE_PREFIX) ||
                isNameOfMinor(spColDN, CK_NODE_PREFIX) ||
                isForeignIssuer(spColDN, CK_NODE_PREFIX) ||
                isBookEntry(spColDN, CK_NODE_PREFIX))
            {
              hasSpecialAccount = true;
              break;
            }
          } // end delete check

        } // end for loop

      } // end check for ck collateral

      if (!hasSpecialAccount && svCollVec != null && !svCollVec.isEmpty())
      {

        for (int i = 0; i < svCollVec.size(); i++)
        {
          spColDN = (DataNode) svCollVec.elementAt(i);

          if (!spColDN.isDeleted())
          {
            if (isAcctRequireMultSign(spColDN, SV_NODE_PREFIX) ||
                isPayableOnDeath(spColDN, SV_NODE_PREFIX) ||
                isNameOfMinor(spColDN, SV_NODE_PREFIX) ||
                isForeignIssuer(spColDN, SV_NODE_PREFIX) ||
                isBookEntry(spColDN, SV_NODE_PREFIX))
            {
              hasSpecialAccount = true;
              break;
            }
          } // end delete check

        } // end for loop

      } // end check for sv collateral

    } // end check for any collateral

    return hasSpecialAccount;
  }

  public static Date getMaturityDate(DataNode appDN) throws Exception
  {

    Date matDt = null;

    DataNode colDN = appDN.getReference(NodeUtils.COLL_DN_TYPE, 0);

    if (colDN != null)
    {

      VectorX cdCollVec = colDN.getReferences(NodeUtils.CD_DN_TYPE);

      DataNode cdColDN = null;
      String matDateStr = null;

      if (cdCollVec != null && !cdCollVec.isEmpty())
      {

        for (int i = 0; i < cdCollVec.size(); i++)
        {
          cdColDN = (DataNode) cdCollVec.elementAt(i);

          if (!cdColDN.isDeleted())
          {
            matDateStr = (String) cdColDN.getFieldData(CSFieldValues.
                EMPTY_STRING,
                CSFieldNames.FN_CD_MATURITY);

            if (matDateStr != null)
            {
              matDt = DateUtility.assignSlashDateToJavaDate(matDateStr);
              break;
            } // end if matDateStr is null

          } // end delete check

        } // end for loop

      } // end check for cd collateral

    } // end check for any collateral

    return matDt;
  }

  public static double getHighestTotalAggregateDebt(DataNode appDN) throws
      Exception
  {

    String debtStr = (String) appDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                                 CSFieldNames.FN_TTL_FIN_AMT);

    if (debtStr == null)
    {
      debtStr = (String) appDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                            CSFieldNames.FN_LOAN_AMT);
    }

    double totalDebt = 0.0;
    if (debtStr != null && !debtStr.equals(CSFieldValues.EMPTY_STRING))
    {
      totalDebt = Double.parseDouble(debtStr);
    }

    String applicable = (String) appDN.getFieldData(CSFieldValues.EMPTY_STRING,
        CSFieldNames.FN_DEBT_RECAP_APPLIC);
    String zeroStr = "0.0";

    if (applicable != null && !applicable.equals("0"))
    {
      totalDebt = Double.parseDouble( (appDN.getFieldData(CSFieldValues.
          EMPTY_STRING, CSFieldNames.FN_DR_RQ_AMT) == null) ?
                                     zeroStr :
                                     (String) appDN.getFieldData(CSFieldValues.
          EMPTY_STRING, CSFieldNames.FN_DR_RQ_AMT));

      totalDebt +=
          Double.parseDouble( (appDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                                  CSFieldNames.FN_DR_INS_DBT) == null) ?
                             zeroStr :
                             (String) appDN.getFieldData(CSFieldValues.
          EMPTY_STRING,
          CSFieldNames.FN_DR_INS_DBT));

      totalDebt +=
          Double.parseDouble( (appDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                                  CSFieldNames.FN_DR_OVR_DFT) == null) ?
                             zeroStr :
                             (String) appDN.getFieldData(CSFieldValues.
          EMPTY_STRING,
          CSFieldNames.FN_DR_OVR_DFT));

      totalDebt +=
          Double.parseDouble( (appDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                                  CSFieldNames.FN_DR_CCLO_CAMT) == null) ?
                             zeroStr :
                             (String) appDN.getFieldData(CSFieldValues.
          EMPTY_STRING,
          CSFieldNames.FN_DR_CCLO_CAMT));

      totalDebt -=
          Double.parseDouble( (appDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                                  CSFieldNames.
                                                  FN_DR_LESS_CD_SCRD) == null) ?
                             zeroStr :
                             (String) appDN.getFieldData(CSFieldValues.
          EMPTY_STRING,
          CSFieldNames.FN_DR_LESS_CD_SCRD));

      totalDebt -=
          Double.parseDouble( (appDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                                  CSFieldNames.
                                                  FN_DR_LESS_FAB_LN_SCRD_RES) == null) ?
                             zeroStr :
                             (String) appDN.getFieldData(CSFieldValues.
          EMPTY_STRING,
          CSFieldNames.FN_DR_LESS_FAB_LN_SCRD_RES));

      totalDebt +=
          Double.parseDouble( (appDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                                  CSFieldNames.
                                                  FN_DR_FAB_GUAR_DBT) == null) ?
                             zeroStr :
                             (String) appDN.getFieldData(CSFieldValues.
          EMPTY_STRING,
          CSFieldNames.FN_DR_FAB_GUAR_DBT));
    }

    return totalDebt;
  }

  public static double getCollTotalFinanceAmt(DataNode appDN) throws Exception
  {
    double ttlFinAmt = 0.0;

    DataNode colDN = appDN.getReference(NodeUtils.COLL_DN_TYPE, 0);
    if (colDN != null)
    {
      VectorX colTypes = colDN.getReferenceDataTypes();
      if (colTypes != null && !colTypes.isEmpty())
      {
        String amtStr = null;
        String curType = null;
        VectorX curTypeDNVec = null;
        DataNode curDN = null;
        Iterator it = null;
        String key = null,
            finAmtStr = "FinAmt";

        for (int i = 0; i < colTypes.size(); i++)
        {
          curType = (String) colTypes.elementAt(i);
          curTypeDNVec = colDN.getReferences(curType);
          if (curTypeDNVec != null && !curTypeDNVec.isEmpty())
          {
            for (int j = 0; j < curTypeDNVec.size(); j++)
            {
              curDN = (DataNode) curTypeDNVec.elementAt(j);
              if (!curDN.isDeleted())
              {
                it = curDN.getFieldData(CSFieldValues.EMPTY_STRING).keySet().
                    iterator();
                while (it.hasNext())
                {
                  key = (String) it.next();
                  if (key.startsWith(CL_NODE_PREFIX) && key.endsWith(finAmtStr))
                  {
                    amtStr = (String) curDN.getFieldData(CSFieldValues.
                        EMPTY_STRING, key);

                    if (amtStr != null)
                    {
                      ttlFinAmt += Double.parseDouble(amtStr);
                    }
                  } // end starts, ends check
                } // end while
              } // end if deleted
            } // end for loop
          } // end if empty
        } // end for loop
      } // end if collateral types exist
    }

    return ttlFinAmt;
  }

  // 4-2-08, ccl
  // Distiguish business from consumer mode
  //
  /*
  public static DataNode getDecisionParty(DataNode appNode) throws Exception
  {
    VectorX decParty = (VectorX) appNode.getSystemData(CSFieldNames.
        FN_SYS_DEC_PARTY);
    DataNode bwrNode = null;

    if (decParty != null)
    {
      if (decParty.size() == 1)
      {
        String indexS = (String) decParty.get(0);
        int index = StringSupport.strToInt(indexS);

        if (index == -1)
        {
          return appNode;
        }

        bwrNode = appNode.getReference(NodeUtils.BWR_DN_TYPE, index);
      }
      else
      {
        bwrNode = appNode.getReference(NodeUtils.CMB_BWR_DN_TYPE, 0);
      }
    }
    else
    {
      bwrNode = appNode.getReference(NodeUtils.BWR_DN_TYPE, 0);
    }

    if (bwrNode == null)
    {
      throw new Exception("Unable to find decision party.");
    }

    return bwrNode;
  }
  */

  public static DataNode getDecisionParty(DataNode appNode)
  throws Exception
  {
    return CSUtil.getDecisionParty(appNode, false);
  }


  public static DataNode getDecisionParty(DataNode appNode, boolean allowAppNodeResponse)
  throws Exception
  {
    //general.errLog("START getDecisionParty(DataNode appNode)","GetDecPrty.log");

    VectorX decParty = (VectorX) appNode.getSystemData(CSFieldNames.FN_SYS_DEC_PARTY);
    //general.errLog("decParty: "+decParty,"GetDecPrty.log");

    DataNode subjectNode = null;

    if (decParty != null)
    {
      //general.errLog("decParty.size(): "+decParty.size(),"GetDecPrty.log");
      if (decParty.size() == 1)
      {
        String indexS = (String)decParty.get(0);
        //general.errLog("indexS: "+indexS,"GetDecPrty.log");

        // For business, either the business or the primary borrower is the decision
        // party - so there is only one party in the decision party vector.
        //
        if (indexS.equals("B"))
        {
          subjectNode = appNode.getReference(NodeUtils.BUS_DN_TYPE, 0);
          //general.errLog("1 subjectNode","GetDecPrty.log");
        }
        else
        {
          int index = StringSupport.strToInt(indexS);
          if (index == -1)
          {
            if (allowAppNodeResponse)
            {
              subjectNode = appNode;
            }
            else
            {
              subjectNode = appNode.getFirstReference(NodeUtils.CMB_BWR_DN_TYPE);
              if (subjectNode == null) subjectNode = appNode.getFirstReference(NodeUtils.BWR_DN_TYPE);
            }
          }
          else
          {
            subjectNode = appNode.getReference(NodeUtils.BWR_DN_TYPE, index);
          }
          //general.errLog("2 subjectNode","GetDecPrty.log");
        }
      }
      else
      {
        DataNode cmbBwr;
        VectorX indices;
        List cmbBwrList = appNode.getEffectiveReferences(NodeUtils.CMB_BWR_DN_TYPE);
        for (int i = 0, c = cmbBwrList.size(); i < c; ++i)
        {
          cmbBwr = (DataNode)cmbBwrList.get(i);
          indices = (VectorX)cmbBwr.getSystemData("!indices");
          //general.errLog("indices: "+indices,"GetDecPrty.log");
          if (indices != null && indices.toString().equals(decParty.toString()))
          {
            subjectNode = cmbBwr;
            //general.errLog("3 subjectNode","GetDecPrty.log");
            break;
          }
        }

        // Just in case we are dealing with an older application that did not
        // have the !indices field in the combined borrower node (e.g. an app
        // that existed before multiple combined borrowers).
        //
        if (subjectNode == null)
        {
          subjectNode = appNode.getReference(NodeUtils.CMB_BWR_DN_TYPE, 0);
          //general.errLog("4 subjectNode","GetDecPrty.log");
        }
      }
    }
    else
    {
      subjectNode = appNode.getReference(NodeUtils.BWR_DN_TYPE, 0);
      //general.errLog("5 subjectNode","GetDecPrty.log");
    }

    if (subjectNode == null)
    {
      throw new Exception("Unable to find decision party.");
    }

    //general.errLog("return subjectNode: "+subjectNode,"GetDecPrty.log");
    //general.errLog("END getDecisionParty(DataNode appNode)","GetDecPrty.log");

    return subjectNode;
  }


  public static boolean editOrView(String username,
                                   SystemDataObject sdo) throws Exception
  {
    boolean isEdit = false;

    User user = User.getUser(username);

    if (user == null)
    {
      throw new Exception("Unable to load user object.");
    }

    String userBranchId = user.getUserBranch();

    if (userBranchId == null)
    {
      throw new Exception("Unable to determine user branch.");
    }

    String userLevel = user.getUserLevel();

    if (userLevel == null)
    {
      throw new Exception("Unable to determine user level.");
    }

    //
    // archived status? change order 603, mrl, 3-23-04
    //
    try
    {
      DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);
      if (appNode != null)
      {
        String status = (String) appNode.getSystemData(CSStatusCodes.SDO_STATUS);
        if (status != null)
        {
          int stat = 0;
          int archivedStat = 100;

          try
          {
            stat = Integer.parseInt(status);
            archivedStat = Integer.parseInt(CSStatusCodes.SC_ARCHIVE);

            if (stat == archivedStat)
            {
              isEdit = false;

              String msg = "Unable to edit archived application.";
              String msgLevel = "100";
              NotifyUser nu = new NotifyUser(username, msg, msgLevel);
              nu.run();

              return isEdit;
            }
          }
          catch (Exception e)
          {
            e.printStackTrace();
            throw new Exception(
                "Unable to determine the application status. Reason: " +
                e.getMessage());
          }
        }
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
      throw new Exception("Unable to load the application data. Reason: " +
                          e.getMessage());
    }

    if (userLevel.equals(USER_ALL))
    {
      isEdit = true;
    }
    else
    {
      String appBranchId = DataEntrySupport.getBranchIDFromSDO(sdo, username);

      if (appBranchId == null)
      {
        throw new Exception("Unable to determine application branch Id.");
      }

      if (userLevel.equals(USER_BRANCH))
      {
        if (appBranchId.equals(userBranchId))
        {
          isEdit = true;
        }
      }
      else
      {
        if (userLevel.equals(USER_REGION))
        {
          String appRegionId = DBQueries.lookupRegionFromBranch(appBranchId);

          String userRegionId = DBQueries.lookupRegionFromBranch(userBranchId);

          if (appRegionId.equals(userRegionId))
          {
            isEdit = true;
          }
        }
      }
    }

    return isEdit;
  } // editOrView

  public static boolean editOrView(String username,
                                   SystemDataObject sdo,
                                   boolean postDecUpdateAllowed) throws
      Exception
  {
    boolean isEdit = false;

    User user = User.getUser(username);

    if (user == null)
    {
      throw new Exception("Unable to load user object.");
    }

    String userBranchId = user.getUserBranch();

    if (userBranchId == null)
    {
      throw new Exception("Unable to determine user branch.");
    }

    String userLevel = user.getUserLevel();

    if (userLevel == null)
    {
      throw new Exception("Unable to determine user level.");
    }

    //
    // archive status? change order 603, mrl, 3-23-04
    //
    try
    {
      DataNode appDN = sdo.getNodeData(NodeUtils.APP_DN_TYPE);
      if (appDN != null)
      {
        String status = (String) appDN.getSystemData(CSStatusCodes.SDO_STATUS);

        if (status != null)
        {
          int stat = 0;
          int archivedStat = 100;

          try
          {
            stat = Integer.parseInt(status);
            archivedStat = Integer.parseInt(CSStatusCodes.SC_ARCHIVE);

            if (stat == archivedStat)
            {
              isEdit = false;

              String msg = "Unable to edit archived application.";
              String msgLevel = "100";
              NotifyUser nu = new NotifyUser(username, msg, msgLevel);
              nu.run();

              return isEdit;
            }
          }
          catch (Exception e)
          {
            e.printStackTrace();
            throw new Exception(
                "Unable to determine the application status. Reason: " +
                e.getMessage());
          }
        }
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
      throw new Exception("Unable to load the application data. Reason: " +
                          e.getMessage());
    }

    if (userLevel.equals(USER_ALL))
    {
      isEdit = true;
    }
    else
    {
      String appBranchId = DataEntrySupport.getBranchIDFromSDO(sdo, username);

      if (appBranchId == null)
      {
        throw new Exception("Unable to determine application branch Id.");
      }

      if (userLevel.equals(USER_BRANCH))
      {
        if (appBranchId.equals(userBranchId))
        {
          isEdit = true;
        }
      }
      else
      {
        if (userLevel.equals(USER_REGION))
        {
          String appRegionId = DBQueries.lookupRegionFromBranch(appBranchId);

          String userRegionId = DBQueries.lookupRegionFromBranch(userBranchId);

          if (appRegionId.equals(userRegionId))
          {
            isEdit = true;
          }
        }
      }
    }

    if (isEdit)
    {
      // has a decision been made on the application?
      DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);
      if (appNode != null)
      {
        String dcsn = (String) appNode.getSystemData(CSStatusCodes.APP_DECISION);
        if (dcsn != null && !dcsn.equals("N"))
        {
          String review = (String) appNode.getSystemData(CSStatusCodes.
              APP_NEEDS_REVIEW);

          if (review != null && review.equals(CSFieldValues.FALSE_STRING))
          {
            // decision has been made, no review is required.
            if (!postDecUpdateAllowed)
            {
              isEdit = false;

              String msg =
                  "Unable to edit decisioned application in this activity.";
              String msgLevel = "100";
              NotifyUser nu = new NotifyUser(username, msg, msgLevel);
              nu.run();
            }
            else
            {
              if (!userLevel.equals(USER_ALL))
              {
                // need to check the status of the application.
                // If the status is >= 9000 then application has been completed.

                String status = (String) appNode.getSystemData(CSStatusCodes.
                    SDO_STATUS);

                if (status != null)
                {
                  int stat = 0;
                  int greatStat = 100;

                  try
                  {
                    stat = Integer.parseInt(status);
                    greatStat = Integer.parseInt(CSStatusCodes.SC_BOOKING);

                    if (stat >= greatStat)
                    {
                      isEdit = false;

                      String msg = "Unable to edit booked application.";
                      String msgLevel = "100";
                      NotifyUser nu = new NotifyUser(username, msg, msgLevel);
                      nu.run();
                    }
                  }
                  catch (Exception e)
                  {
                    e.printStackTrace();
                  }
                }
              }
            }
          }
        }
      }
    }

    return isEdit;
  } // editOrView

  public static boolean isRegistrationForeign(DataNode appDN)
  {
    boolean foreign = false;

    DataNode colDN = appDN.getReference(NodeUtils.COLL_DN_TYPE, 0);

    if (colDN != null)
    {

      VectorX colTypes = colDN.getReferenceDataTypes();

      if (colTypes != null && !colTypes.isEmpty())
      {
        String curType = null;
        VectorX curTypeDNVec = null;
        DataNode curDN = null;
        Iterator it = null;
        String key = null;
        String state = null,
            rdStDStr = "RgStD";

        for (int i = 0; i < colTypes.size(); i++)
        {
          curType = (String) colTypes.elementAt(i);
          curTypeDNVec = colDN.getReferences(curType);
          if (curTypeDNVec != null && !curTypeDNVec.isEmpty())
          {
            for (int j = 0; j < curTypeDNVec.size(); j++)
            {
              curDN = (DataNode) curTypeDNVec.elementAt(j);
              if (!curDN.isDeleted())
              {
                it = curDN.getFieldData(CSFieldValues.EMPTY_STRING).keySet().
                    iterator();
                while (it.hasNext())
                {
                  key = (String) it.next();
                  if (key.startsWith(CL_NODE_PREFIX) && key.endsWith(rdStDStr))
                  {
                    state = (String) curDN.getFieldData(CSFieldValues.
                        EMPTY_STRING, key);
                    if (state != null)
                    {
                      if (!STATES.contains(state))
                      {
                        foreign = true;
                      }
                    } // end if (state != null)
                  } // end starts, ends check
                } // end while
              } // end if deleted
            } // end for loop
          } // end if empty
        } // end for loop
      } // end if (colTypes != null && !colTypes.isEmpty())
    } // end if (colDN != null)

    return foreign;
  }

  public static boolean hasThirdPartyOwner(DataNode appDN)
  {
    boolean thirdParty = false;

    DataNode colDN = appDN.getReference(NodeUtils.COLL_DN_TYPE, 0);
    if (colDN != null)
    {
      VectorX colTypes = colDN.getReferenceDataTypes();
      if (colTypes != null && !colTypes.isEmpty())
      {
        String curType = null;
        VectorX curTypeDNVec = null;
        DataNode curDN = null;

        for (int i = 0; i < colTypes.size() && !thirdParty; i++)
        {
          curType = (String) colTypes.elementAt(i);
          curTypeDNVec = colDN.getReferences(curType);
          if (curTypeDNVec != null && !curTypeDNVec.isEmpty())
          {
            for (int j = 0; j < curTypeDNVec.size() && !thirdParty; j++)
            {
              curDN = (DataNode) curTypeDNVec.elementAt(j);
              if (!curDN.isDeleted())
              {
                thirdParty = isCollateralOwnedByThirdParty(curDN);
              } // end if collateral is deleted
            } // end for loop
          } // end if empty
        } // end for loop
      }
    }

    return thirdParty;
  }

  public static boolean isCollateralOwnedByThirdParty(DataNode specClDN)
  {
    boolean thirdParty = false;

    VectorX ownerDNVec = specClDN.getReferences(NodeUtils.ONR_DN_TYPE);
    DataNode ownDN = null;
    String ownerType = null;

    if (ownerDNVec != null && !ownerDNVec.isEmpty())
    {
      for (int k = 0; k < ownerDNVec.size() && !thirdParty; k++)
      {
        ownDN = (DataNode) ownerDNVec.elementAt(k);

        if (!ownDN.isDeleted())
        {
          ownerType = (String) ownDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                                  CSFieldNames.FN_OWNER_TYPE);

          if (ownerType != null &&
              ownerType.equals(CSFieldValues.FV_OWNR_TYPE_OTHER))
          {
            thirdParty = true;
          } // end if ownerType is not null and other
        } // end if owner node is deleted
      } // end loop through owners
    } // end if owner vector is not null or empty

    return thirdParty;
  }

  public static void translatePmtType(String pmtType, HashtableX outFieldsHash) throws
      Exception
  {

    if (pmtType.equals(CSFieldValues.FV_INSTALLMENT))
    {
      outFieldsHash.put(CSFieldNames.FN_PMT_TYPE_RADIO,
                        CSFieldValues.FV_INSTALLMENT_RD);
    }
    else
    {
      if (pmtType.equals(CSFieldValues.FV_BALLOON))
      {
        outFieldsHash.put(CSFieldNames.FN_PMT_TYPE_RADIO,
                          CSFieldValues.FV_BALLOON_RD);
      }
      else
      {
        if (pmtType.equals(CSFieldValues.FV_SINGLE))
        {
          outFieldsHash.put(CSFieldNames.FN_PMT_TYPE_RADIO,
                            CSFieldValues.FV_SINGLE_RD);
        }
        else
        {
          if (pmtType.equals(CSFieldValues.FV_PRININT))
          {
            outFieldsHash.put(CSFieldNames.FN_PMT_TYPE_RADIO,
                              CSFieldValues.FV_PRININT_RD);
          }
          else
          {
            if (pmtType.equals(CSFieldValues.FV_SINGLE_INT))
            {
              outFieldsHash.put(CSFieldNames.FN_PMT_TYPE_RADIO,
                                CSFieldValues.FV_SINGLE_INT_RD);
            }
            else
            {
              if (pmtType.equals(CSFieldValues.FV_IRREGULAR))
              {
                outFieldsHash.put(CSFieldNames.FN_PMT_TYPE_RADIO,
                                  CSFieldValues.FV_IRREGULAR_RD);
              }
              else
              {
                if (pmtType.equals(CSFieldValues.FV_FNMA_BIWEEKLY_INST))
                {
                  outFieldsHash.put(CSFieldNames.FN_PMT_TYPE_RADIO,
                                    CSFieldValues.FV_FNMA_BIWEEKLY_RD);
                }
              }
            }
          }
        }
      }
    }
  }

  public static String translatePmtTypeText(String pmtTypeText)
  {

    if (pmtTypeText.equals(CSFieldValues.FV_INSTALLMENT_RD))
    {
      return CSFieldValues.FV_INSTALLMENT;
    }
    else
    {
      if (pmtTypeText.equals(CSFieldValues.FV_BALLOON_RD))
      {
        return CSFieldValues.FV_BALLOON;
      }
      else
      {
        if (pmtTypeText.equals(CSFieldValues.FV_SINGLE_RD))
        {
          return CSFieldValues.FV_SINGLE;
        }
        else
        {
          if (pmtTypeText.equals(CSFieldValues.FV_PRININT_RD))
          {
            return CSFieldValues.FV_PRININT;
          }
          else
          {
            if (pmtTypeText.equals(CSFieldValues.FV_SINGLE_INT_RD))
            {
              return CSFieldValues.FV_SINGLE_INT;
            }
            else
            {
              if (pmtTypeText.equals(CSFieldValues.FV_IRREGULAR_RD))
              {
                return CSFieldValues.FV_IRREGULAR;
              }
              else
              {
                if (pmtTypeText.equals(CSFieldValues.FV_FNMA_BIWEEKLY_RD))
                {
                  return CSFieldValues.FV_FNMA_BIWEEKLY_INST;
                }
              }
            }
          }
        }
      }
    }

    return null;
  }

  public static String getApplicationType(DataNode appNode)
  {
    String appType = "I";
    VectorX bwrVec = appNode.getReferences(NodeUtils.BWR_DN_TYPE);

    if (bwrVec != null && bwrVec.size() > 1)
    {
      // there are multiple borrowers:
      // J - Co-applicant
      // C - Co-signer
      // G - Guarantor

      boolean hasCoApplicant = false;
      boolean hasCoSigner = false;
      boolean hasGuarantor = false;

      DataNode bwrDN = null;
      String bwrType = null;

      for (int i = 1; i < bwrVec.size(); i++)
      {
        bwrDN = (DataNode) bwrVec.get(i);

        if (!bwrDN.isDeleted())
        {
          bwrType = (String) bwrDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                                CSFieldNames.FN_BWR_TYPE);

          if (bwrType != null)
          {
            if (bwrType.equals(CSFieldValues.FV_COAPPLICANT))
            {
              hasCoApplicant = true;
              break;
            }
            else
            {
              if (bwrType.equals(CSFieldValues.FV_COSIGNER))
              {
                hasCoSigner = true;
              }
              else
              {
                if (bwrType.equals(CSFieldValues.FV_GUARANTOR))
                {
                  hasGuarantor = true;
                }
              }
            }
          } // bwrType != null
        } //bwrDN is not deleted
      } // for loop

      if (hasCoApplicant)
      {
        appType = "J";
      }
      else
      {
        if (hasCoSigner)
        {
          appType = "C";
        }
        else
        {
          if (hasGuarantor)
          {
            appType = "G";
          }
        }
      }

    }

    return appType;
  }

  public static String getApplicationProductType(DataNode appNode) throws
      Exception
  {
    boolean isConsumer = isConsumerApplication(appNode);
    boolean isMortgage = isMortgageApplication(appNode);

    String prodID = (isConsumer || isMortgage)?
        (String) appNode.getFieldData(CSFieldValues.EMPTY_STRING,
                                      CSFieldNames.FN_PRODUCT_ID) :
        (String) appNode.getFieldData(CSFieldValues.EMPTY_STRING,
                                      CSFieldNames.FN_SBPRODUCT_ID);

    if (prodID == null)
    {
      throw new Exception("Product ID not found.");
    }

    Product product = null;
    SBProduct sbProduct = null;
    MtgProduct mgProduct = null;

    if (isConsumer)
    {
      product = CSDataCache.getProductManager().getProduct(prodID);
    }
    else if (isMortgage)
    {
      mgProduct = CSDataCache.getMtgProductManager().getProduct(prodID);
    }
    else
    {
      sbProduct = CSDataCache.getSBProductManager().getProduct(prodID);
    }

    if (product == null && sbProduct == null && mgProduct == null)
    {
      throw new Exception("Product not found in data cache.");
    }

    //return isConsumer ? product.getProductType() : sbProduct.getProductType();
    return isConsumer ? product.getProductType() :
      isMortgage ? mgProduct.getProductType() : sbProduct.getProductType();
  }

  public static String getApplicationProductLoanType(DataNode appNode) throws
      Exception
  {
    boolean isConsumer = isConsumerApplication(appNode);
    boolean isMortgage = isMortgageApplication(appNode);

    String prodID = (isConsumer || isMortgage)?
        (String) appNode.getFieldData(CSFieldValues.EMPTY_STRING,
                                      CSFieldNames.FN_PRODUCT_ID) :
        (String) appNode.getFieldData(CSFieldValues.EMPTY_STRING,
                                      CSFieldNames.FN_SBPRODUCT_ID);

    if (prodID == null)
    {
      throw new Exception("Product ID not found.");
    }

    Product product = null;
    SBProduct sbProduct = null;
    MtgProduct mgProduct = null;

    if (isConsumer)
    {
      product = CSDataCache.getProductManager().getProduct(prodID);
    }
    else if (isMortgage)
    {
      mgProduct = CSDataCache.getMtgProductManager().getProduct(prodID);
    }
    else
    {
      sbProduct = CSDataCache.getSBProductManager().getProduct(prodID);
    }

    if (product == null && sbProduct == null && mgProduct == null)
    {
      throw new Exception("Product not found in data cache.");
    }

    return isConsumer ? product.getLoanType() :
      isMortgage ? mgProduct.getLoanType() :sbProduct.getLoanType();
  }


  public static boolean isFullyDisbursed( DataNode appDN )
  {
    boolean isFullyDisbursed = false;

    String appType = (String)appDN.getSystemData( CSFieldNames.FN_APP_TYPE );

    if ((appType != null) && appType.trim().equals( "d" ))
    {
      // LEND-785 - 'fully disbursed' has no meaning for Deposit apps, so
      //            check for status code 8015 'Ready to Book' or
      //            8030 'Loan has been booked' instead
      //
      String curStatus = (String)appDN.getSystemData( CSFieldNames.FN_APP_STAT );

      if ( (curStatus.equals( CSStatusCodes.SC_RDY_TO_BOOK )) ||
           (curStatus.equals( CSStatusCodes.SC_BOOKING )) )
      {
        return( true );
      }

    } // if - Deposit

    String dsbAmt = (String)appDN.getFieldData( CSFieldValues.EMPTY_STRING,
                                                CSFieldNames.FN_DSB_TTL );

    if (dsbAmt != null)
    {
      String dsbNonLoan =
          (String)appDN.getFieldData( CSFieldValues.EMPTY_STRING,
                                      CSFieldNames.FN_DSB_NON_LOAN);
      if (dsbNonLoan != null)
      {
        String loanAmtStr =
            (String)appDN.getFieldData( CSFieldValues.EMPTY_STRING,
                                        CSFieldNames.FN_LOAN_AMT );
        if (loanAmtStr != null)
        {
          try
          {
            String indCLifeStr =
                (String)appDN.getFieldData( CSFieldValues.EMPTY_STRING,
                                            CSFieldNames.FN_IND_CLIFE );
            String indWarrStr =
                (String)appDN.getFieldData( CSFieldValues.EMPTY_STRING,
                                            CSFieldNames.FN_IND_WARR );
            String indOthStr =
                (String)appDN.getFieldData( CSFieldValues.EMPTY_STRING,
                                            CSFieldNames.FN_IND_OTHER );
            // 7-12-07, ccl
            //
            double feeSubAdv = 0.0D;
            String feeSubAdvS =
                (String)appDN.getFieldData( CSFieldValues.EMPTY_STRING,
                                            CSFieldNames.FN_FEE_SUB_ADV );

            if (feeSubAdvS != null && feeSubAdvS.length() > 0)
            {
              try
              {
                feeSubAdv = Double.parseDouble( feeSubAdvS );
              }
              catch (Exception e)
              {
                e.getStackTrace();
              }
            }

            double indTtl = 0.0;

            if (indCLifeStr != null)
            {
              indTtl += Double.parseDouble( indCLifeStr );
            }

            if (indWarrStr != null)
            {
              indTtl += Double.parseDouble( indWarrStr );
            }

            if (indOthStr != null)
            {
              indTtl += Double.parseDouble( indOthStr );
            }

            double loanAmt   = Double.parseDouble( loanAmtStr );
            double nonLoan   = Double.parseDouble( dsbNonLoan );
            double disbursed = Double.parseDouble( dsbAmt );

            // if (FinCalcs.round(loanAmt + indTtl, 2) == // 7-12-07, ccl
            //
            if (FinCalcs.round( loanAmt + indTtl - feeSubAdv, 2 ) ==
                FinCalcs.round( disbursed - nonLoan, 2 ))
            {
              isFullyDisbursed = true;
            }
          }
          catch (Exception e)
          {
            e.printStackTrace();
          }
        }
      }
    }

    return isFullyDisbursed;

  } // isFullyDisbursed


  public static VectorX getCustIdVec( DataNode appNode )
  {
    //general.errLog("START getCustIdVec( DataNode appNode )","GetCustIdVec.log");

    VectorX custIdVec = new VectorX();
    VectorX decPartyVec = (VectorX) appNode.getSystemData(CSFieldNames.FN_SYS_DEC_PARTY);
    //general.errLog("decPartyVec: "+decPartyVec,"GetCustIdVec.log");

    int index = 0;
    String custId = null;
    DataNode bwrNode = null;

    //general.errLog("if( decPartyVec != null && ! decPartyVec.isEmpty() ): "+( decPartyVec != null && ! decPartyVec.isEmpty() ),"GetCustIdVec.log");
    if( decPartyVec != null && ! decPartyVec.isEmpty() )
    {
      // Need to consider both business and consumer mode
      //
      if (decPartyVec.contains("B"))
      {
        DataNode busNode = (DataNode) appNode.getReference(NodeUtils.BUS_DN_TYPE, 0);
        if (busNode != null)
        {
          custId = (String) busNode.getSystemData(CSFieldNames.FN_CUST_ID);
          custIdVec.addElement(custId);
          //general.errLog("1 custIdVec: "+custIdVec,"GetCustIdVec.log");
        }
      }
      else if (decPartyVec.contains("-1"))
      {
        //find all the non deleted borrower
        VectorX vec = appNode.getReferences(NodeUtils.BWR_DN_TYPE);
        if (vec != null)
        {
            Iterator it = vec.iterator();
            while (it.hasNext())
            {
                bwrNode = (DataNode) it.next();
                if (!bwrNode.isDeleted())
                {
                  custId = (String) bwrNode.getSystemData(CSFieldNames.FN_CUST_ID);
                  custIdVec.addElement(custId);
                  //general.errLog("2 custIdVec: "+custIdVec,"GetCustIdVec.log");
                }
            }
        }
      }
      else
      {
        for (int i = 0; i < decPartyVec.size(); i++)
        {
          index = Integer.parseInt( (String) decPartyVec.get(i));
          bwrNode = appNode.getReference(NodeUtils.BWR_DN_TYPE, index);

          if( bwrNode != null && ! bwrNode.isDeleted() )
          {
            custId = (String) bwrNode.getSystemData(CSFieldNames.FN_CUST_ID);
            custIdVec.addElement(custId);
            //general.errLog("3 custIdVec: "+custIdVec,"GetCustIdVec.log");
          }
        } // for(int i=0; i < decPartyVec.size(); i++)
      }

    } // if( decPartyVec != null && !decPartyVec.isEmpty() )

    //general.errLog("return custIdVec: "+custIdVec,"GetCustIdVec.log");
    //general.errLog("END getCustIdVec( DataNode appNode )","GetCustIdVec.log");

    return custIdVec;
  } // getCudtIdVec( DataNode appNode )

  // getCollDownPayment
  //
  public static HashtableX getCollDownPayment(DataNode appDN) throws Exception
  {
    double ttlDwnPmt = 0.0;
    int count = 0;
    HashtableX dwnPmtHT = new HashtableX();

    DataNode colDN = appDN.getReference(NodeUtils.COLL_DN_TYPE, 0);

    if (colDN != null)
    {
      DataNode spColDN = null;

      VectorX collTypes = colDN.getReferenceDataTypes();
      VectorX cdCollVec = null;
      String dwnPmt = CSFieldValues.EMPTY_STRING;

      for (int i = 0; i < collTypes.size(); i++)
      {
        cdCollVec = colDN.getReferences( (String) collTypes.elementAt(i));
        if (cdCollVec != null && !cdCollVec.isEmpty())
        {
          for (int j = 0; j < cdCollVec.size(); j++)
          {
            spColDN = (DataNode) cdCollVec.elementAt(j);
            if (!spColDN.isDeleted())
            {
              count++;
              dwnPmt = (String) spColDN.getFieldData(CSFieldValues.EMPTY_STRING,
                  CSFieldNames.FN_PD_DOWN_PAYMENT);

              if (dwnPmt != null && !dwnPmt.equals(CSFieldValues.EMPTY_STRING))
              {
                ttlDwnPmt += Double.parseDouble(dwnPmt);
              }
            }

          } // end for loop
        }
      } // end check for cd collateral

    }

    dwnPmtHT.put("numOfDwnPmt", CSFieldValues.EMPTY_STRING + count);
    dwnPmtHT.put("ttlDwnPmt", CSFieldValues.EMPTY_STRING + ttlDwnPmt);

    return dwnPmtHT;
  } // getCollDownPayment

  public static void translateVhEvalType(String vhEvalType,
                                         HashtableX fieldsHash) throws
      Exception
  {
    if (vhEvalType.equals(CSFieldValues.FV_KBB_RD))
    {
      fieldsHash.put(CSFieldNames.FN_AUTO_EVAL_TYPE,
                     CSFieldValues.FV_KBB_RD);
    }

    else
    {
      if (vhEvalType.equals(CSFieldValues.FV_MANUAL_RD))
      {
        fieldsHash.put(CSFieldNames.FN_AUTO_EVAL_TYPE,
                       CSFieldValues.FV_MANUAL_RD);
      }

      else
      {
        if (vhEvalType.equals(CSFieldValues.FV_NADA_RD))
        {
          fieldsHash.put(CSFieldNames.FN_AUTO_EVAL_TYPE,
                         CSFieldValues.FV_NADA_RD);
        }
        else
        {
          if (vhEvalType.equals(CSFieldValues.FV_BB))
          {
            fieldsHash.put(CSFieldNames.FN_AUTO_EVAL_TYPE,
                           CSFieldValues.FV_BB_RD);
          }
        }
      }
    }
  }

  public static DataNode getSelectedReportForBwr(DataNode bwrNode)
  {
    DataNode rptNode = null;
    String str = (String) bwrNode.getSystemData(CSFieldNames.FN_SYS_RPT_USED);

    if (str != null)
    {
      int rptUsed = Integer.parseInt(str);
      rptNode = bwrNode.getReference(NodeUtils.RPRT_DN_TYPE, rptUsed);
    }

    return rptNode;
  }

  public static boolean appRequiresVerification(DataNode appNode)
  throws Exception
  {
    boolean approve = isApplicationApproved(appNode);
    boolean review = appNeedsReview(appNode) || appNeedsFinalReview(appNode);

    return appRequiresVerification(appNode, approve, review);
  }

  // overloading method
  //
  public static boolean appRequiresVerification(DataNode appNode,
                                                boolean approve,
                                                boolean review)
  throws Exception
  {
    boolean verify = false;

    // Get the management rule set for this product.
    //
    // 2-19-08, ccl
    // make it generic
    //
    /*
    HashtableX appData = appNode.getFieldData(CSFieldValues.EMPTY_STRING);
    ManagementRuleSet mrs = MgtRuleRepository.getManagementRuleSet(appData);

    if (mrs == null)
    {
      throw new Exception("Unable to load ManagementRuleSet.");
    }

    HashtableX vfRuleTable = mrs.getVfRules();
    */
    HashtableX vfRuleTable = getVfRuleTable(appNode);
    if ( vfRuleTable == null ) vfRuleTable = new HashtableX();

    // Go through application node looking for any unresolved verification items.
    //
    List mrResList = appNode.getReferences(NodeUtils.MR_RES_DN_TYPE);
    if (mrResList != null)
    {
      verify = requiresVerification(mrResList, vfRuleTable, approve, review,
                                    appNode);
    }

    if (!verify)
    {
      // Go through borrowers looking for any unresolved verification items.
      //
      List bwrList = appNode.getEffectiveReferences(NodeUtils.BWR_DN_TYPE);
      bwrList.addAll(appNode.getEffectiveReferences(NodeUtils.CMB_BWR_DN_TYPE));

      DataNode bwrNode = null;
      for (int i = 0, c = bwrList.size(); i < c; ++i)
      {
        bwrNode = (DataNode) bwrList.get(i);
        mrResList = bwrNode.getReferences(NodeUtils.MR_RES_DN_TYPE);
        if (mrResList != null)
        {
          verify = requiresVerification(mrResList, vfRuleTable, approve,
                                        review, appNode);
          if (verify)
          {
            break;
          }
        }
      }
    }

    return verify;
  }

  // requiresVerification
  //
  private static boolean requiresVerification(List mrResList,
                                              HashtableX vfRuleTable,
                                              boolean approve, boolean review,
                                              DataNode appNode)
  {
    DataNode mrNode = null;
    String type, res, category;
    VerificationRuleSet vrs = null;

    boolean verify = false;
    String vfUser = CSFieldValues.EMPTY_STRING;
    String appStatus = (String) appNode.getSystemData(CSStatusCodes.SDO_STATUS);
    String verifyStr = "Verify",
        typeStr = "type",
        vfResDStr = "vfResD",
        vfUserStr = "vfUser",
        systemStr = "System",
        catStr = "cat",
        zeroStr = "0",
        oneStr = "1",
        twoStr = "2",
        threeStr = "3",
        requiresVerStr = "requires verification";

    for (int i = 0, c = mrResList.size(); i < c && !verify; ++i)
    {
      mrNode = (DataNode) mrResList.get(i);
      if (!mrNode.isDeleted())
      {
        type = (String) mrNode.getFieldData(CSFieldValues.EMPTY_STRING, typeStr);
        if (type.equals(verifyStr))
        {
          res = (String) mrNode.getFieldData(CSFieldValues.EMPTY_STRING,
                                             vfResDStr);
          if (res.equals(requiresVerStr))
          {
            if (appStatus != null && appStatus.equals(CSStatusCodes.SC_VERIFY))
            {
              verify = true;
              break;
            }
            else
            {
              category = (String) mrNode.getFieldData(CSFieldValues.
                  EMPTY_STRING, catStr);
              vrs = (VerificationRuleSet) vfRuleTable.get(category);
              if (vrs != null && !vrs.getVfSendOption().equals(twoStr))
              {
                if (vrs.getVfSendOption().equals(zeroStr) ||
                    (approve && (vrs.getVfSendOption().equals(oneStr) ||
                                 (!review &&
                                  vrs.getVfSendOption().equals(threeStr)))))

                {
                  verify = true;
                  break;
                }
              }
              else
              {
                vfUser = (String) mrNode.getFieldData(CSFieldValues.EMPTY_STRING,
                    vfUserStr);
                if (vfUser != null && !vfUser.equals(systemStr))
                {
                  verify = true;
                  break;
                }
              }
            }
          }
        }
      }
    }

    return verify;
  }

  public static VectorX getVerificationSummary(DataNode appNode)
  {
    VectorX summary = new VectorX();

    // Go through application node looking for any unresolved verification items.
    //
    String type, categoryCode, category, resolution, summaryItem, entity, nodeType;
    String rsnCode, rsnText;
    String verifyStr = "Verify",
        typeStr = "type",
        vfResDStr = "vfResD",
        codeStr = "code",
        miStr = "mi",
        catStr = "cat",
        dashStr = " - ",
        colonStr = ":",
        appStr = "Application",
        numStr = "\u0019";
    StringBuffer buf = new StringBuffer();

    // Need to get the ManagementRuleSet in order to translate the tripped
    // rule code to the text.
    //
    boolean isMtg = CSUtil.isMortgageApplication(appNode);

    List theList = new ArrayList();
    List bwrList = appNode.getEffectiveReferences(NodeUtils.BWR_DN_TYPE);
    List cmbBwrList = appNode.getEffectiveReferences(NodeUtils.CMB_BWR_DN_TYPE);

    theList.add(appNode);
    theList.addAll(bwrList);
    theList.addAll(cmbBwrList);

    DataNode theNode = null, mrNode = null;
    for (int i = 0, c = theList.size(); i < c; ++i)
    {
      theNode = (DataNode)theList.get(i);
      nodeType = theNode.getDataType();

      List mrResList = theNode.getEffectiveReferences(NodeUtils.MR_RES_DN_TYPE);

      VectorX usedCats = new VectorX();
      for (int j = 0, k = mrResList.size(); j < k; ++j)
      {
        mrNode = (DataNode) mrResList.get(j);

        boolean displayRuleText = false;
        rsnText = null;

        type = (String) mrNode.getFieldData(CSFieldValues.EMPTY_STRING, typeStr);
        if (type.equals(verifyStr))
        {
          categoryCode = (String) mrNode.getFieldData(CSFieldValues.EMPTY_STRING, catStr);
          category = (String) VerificationRuleSet.vfCatToDescMap.get(categoryCode);

          if (categoryCode != null && ((!isMtg && categoryCode.equals(miStr) || isMtg)))
          {
            displayRuleText = true;

            rsnCode = (String) mrNode.getFieldData(CSFieldValues.EMPTY_STRING, codeStr);
            rsnText = (String)mrNode.getFieldData(CSFieldValues.EMPTY_STRING, "rsn");
            if (rsnText == null) rsnText = rsnCode;

            entity = (String) mrNode.getFieldData(CSFieldValues.EMPTY_STRING, "vfEntityD");
            if (entity != null && entity.length() != 0)
            {
              categoryCode = buf.append(categoryCode).append(colonStr).append(
                  rsnCode).append(colonStr).append(entity).toString();
            }
            else
            {
              categoryCode = buf.append(categoryCode).append(colonStr).append(
                  rsnCode).toString();
            }

            buf.delete(0, buf.length());
          }

         if (!usedCats.contains(categoryCode))
         {
            usedCats.add(categoryCode);
            resolution = (String) mrNode.getFieldData(CSFieldValues.EMPTY_STRING, vfResDStr);

            String desc = nodeType.equals(NodeUtils.APP_DN_TYPE) ? appStr :
                          theNode.getDescription();

            entity = (String) mrNode.getFieldData(CSFieldValues.EMPTY_STRING,
                                                  "vfEntityD");


            if (displayRuleText)
            {
              summaryItem = buf.append(desc).append(dashStr).append(category).
                                append(entity != null ? dashStr : CSFieldValues.EMPTY_STRING).
                                append(entity != null ? entity : CSFieldValues.EMPTY_STRING).
                                append(dashStr).append(rsnText).append(dashStr).
                                append(resolution).toString();
              buf.delete(0, buf.length());
            }
            else
            {
              summaryItem = desc + dashStr + category + dashStr + resolution;
            }

            String index = null;
            if (nodeType.equals(NodeUtils.APP_DN_TYPE))
            {
              index = "a";
            }
            else if (nodeType.equals(NodeUtils.BWR_DN_TYPE))
            {
              index = String.valueOf(theNode.getIndex());
            }
            else
            {
              index = "c-" + theNode.getIndex();
            }

            summary.add(buf.append(index).append(colonStr).append(categoryCode).
                              append(numStr).append(summaryItem).toString());
            buf.delete(0, buf.length());
          }
        }
      }

      // 12-11-09, ccl
      //
      usedCats.clear();
    }

    return summary;
  }

  public static TableTransaction getVerificationSummaryTable(DataNode appNode)
  {
    TableTransaction summary = new TableTransaction();

    VectorX fields = new VectorX();
    fields.add("");
    fields.add("Party              ");
    fields.add("Resolution         ");
    fields.add("Category");
    fields.add("Entity   ");
    fields.add("Reason                  ");

    VectorX keys = new VectorX();
    keys.add(CSFieldValues.TRUE_STRING);
    keys.add(CSFieldValues.FALSE_STRING);
    keys.add(CSFieldValues.FALSE_STRING);
    keys.add(CSFieldValues.FALSE_STRING);
    keys.add(CSFieldValues.FALSE_STRING);
    keys.add(CSFieldValues.FALSE_STRING);

    summary.setFields(fields);
    summary.setKeyFlags(keys);

    VectorX records = new VectorX();
    summary.setRecords(records);

    // Go through application node looking for any unresolved verification items.
    //
    String type, categoryCode, category, resolution, summaryItem, entity, nodeType;
    String rsnCode, rsnText;
    String verifyStr = "Verify",
        typeStr = "type",
        vfResDStr = "vfResD",
        codeStr = "code",
        miStr = "mi",
        catStr = "cat",
        dashStr = " - ",
        colonStr = ":",
        appStr = "Application",
        numStr = "\u0019";
    StringBuffer buf = new StringBuffer();

    // Need to get the ManagementRuleSet in order to translate the tripped
    // rule code to the text.
    //
    boolean isMtg = CSUtil.isMortgageApplication(appNode);

    List theList = new ArrayList();
    List bwrList = appNode.getEffectiveReferences(NodeUtils.BWR_DN_TYPE);
    List cmbBwrList = appNode.getEffectiveReferences(NodeUtils.CMB_BWR_DN_TYPE);

    theList.add(appNode);
    theList.addAll(bwrList);
    theList.addAll(cmbBwrList);

    DataNode theNode = null, mrNode = null;

    TableRecord tr = null;

    for (int i = 0, c = theList.size(); i < c; ++i)
    {
      theNode = (DataNode)theList.get(i);
      nodeType = theNode.getDataType();

      List mrResList = theNode.getEffectiveReferences(NodeUtils.MR_RES_DN_TYPE);

      VectorX usedCats = new VectorX();
      for (int j = 0, k = mrResList.size(); j < k; ++j)
      {
        mrNode = (DataNode) mrResList.get(j);

        rsnText = null;

        type = (String) mrNode.getFieldData(CSFieldValues.EMPTY_STRING, typeStr);
        if (type.equals(verifyStr))
        {
          categoryCode = (String) mrNode.getFieldData(CSFieldValues.EMPTY_STRING, catStr);
          category = (String) VerificationRuleSet.vfCatToDescMap.get(categoryCode);

          if (categoryCode != null && ((!isMtg && categoryCode.equals(miStr) || isMtg)))
          {
            rsnCode = (String) mrNode.getFieldData(CSFieldValues.EMPTY_STRING, codeStr);
            rsnText = (String)mrNode.getFieldData(CSFieldValues.EMPTY_STRING, "rsn");
            if (rsnText == null) rsnText = rsnCode;

            entity = (String) mrNode.getFieldData(CSFieldValues.EMPTY_STRING, "vfEntityD");
            if (entity != null && entity.length() != 0)
            {
              categoryCode = buf.append(categoryCode).append(colonStr).append(
                  rsnCode).append(colonStr).append(entity).toString();
            }
            else
            {
              categoryCode = buf.append(categoryCode).append(colonStr).append(
                  rsnCode).toString();
            }

            buf.delete(0, buf.length());
          }

         if (!usedCats.contains(categoryCode))
         {
            usedCats.add(categoryCode);
            resolution = (String) mrNode.getFieldData(CSFieldValues.EMPTY_STRING, vfResDStr);

            String desc = nodeType.equals(NodeUtils.APP_DN_TYPE) ? appStr :
                          theNode.getDescription();

            String index = null;
            if (nodeType.equals(NodeUtils.APP_DN_TYPE))
            {
              index = "a";
            }
            else if (nodeType.equals(NodeUtils.BWR_DN_TYPE))
            {
              index = String.valueOf(theNode.getIndex());
            }
            else
            {
              index = "c-" + theNode.getIndex();
            }

            tr = new TableRecord();

            entity = (String) mrNode.getFieldData(CSFieldValues.EMPTY_STRING, "vfEntityD");
            if (entity != null && entity.length() != 0)
            {
              tr.addColumnData(buf.append(index).append(colonStr).append(categoryCode).
                          append(colonStr).append(entity).toString());
            }
            else
            {
              tr.addColumnData(buf.append(index).append(colonStr).append(categoryCode).toString());
            }

            buf.delete(0, buf.length());

            tr.addColumnData(desc);
            tr.addColumnData(resolution);
            tr.addColumnData(category);
            tr.addColumnData(entity == null ? CSFieldValues.EMPTY_STRING : entity);
            tr.addColumnData(rsnText == null ? CSFieldValues.EMPTY_STRING : rsnText);
            records.add(tr);
          }
        }
      }

      // 12-11-09, ccl
      //
      usedCats.clear();
    }

    return summary;
  }


  private static Map getVerificationResolutionSet(DataNode appNode)
  {
    Map map = new HashMap();

    String type, resolution, category;
    List catList = null;
    String verifyStr = "Verify",
        typeStr = "type",
        vfResDStr = "vfResD",
        catStr = "cat";

    List mrResList = new ArrayList();

    List list = appNode.getEffectiveReferences(NodeUtils.MR_RES_DN_TYPE);
    mrResList.addAll(list);

    List bwrList = appNode.getEffectiveReferences(NodeUtils.BWR_DN_TYPE);
    bwrList.addAll(appNode.getEffectiveReferences(NodeUtils.CMB_BWR_DN_TYPE));
    for (int i = 0, c = bwrList.size(); i < c; ++i)
    {
      DataNode bwrNode = (DataNode)bwrList.get(i);
      mrResList.addAll(bwrNode.getEffectiveReferences(NodeUtils.MR_RES_DN_TYPE));
    }

    for (int i = 0, c = mrResList.size(); i < c; ++i)
    {
      DataNode mrNode = (DataNode) mrResList.get(i);

      type = (String) mrNode.getFieldData(CSFieldValues.EMPTY_STRING, typeStr);
      if (type.equals(verifyStr))
      {
        category = (String) mrNode.getFieldData(CSFieldValues.EMPTY_STRING, catStr);
        resolution = (String) mrNode.getFieldData(CSFieldValues.EMPTY_STRING, vfResDStr);

        catList = (List) map.get(resolution);

        if (catList == null)
        {
          catList = new ArrayList();
          map.put(resolution, catList);
        }

        catList.add(category);
      }
    }

    /*
    List bwrList = appNode.getReferences(NodeUtils.BWR_DN_TYPE);
    if (bwrList != null)
    {
      DataNode bwrNode = null;
      for (int i = 0, c = bwrList.size(); i < c; ++i)
      {
        bwrNode = (DataNode) bwrList.get(i);
        if (!bwrNode.isDeleted())
        {
          mrResList = bwrNode.getReferences(NodeUtils.MR_RES_DN_TYPE);
          if (mrResList != null)
          {
            for (int j = 0, k = mrResList.size(); j < k; ++j)
            {
              mrNode = (DataNode) mrResList.get(j);
              if (!mrNode.isDeleted())
              {
                type = (String) mrNode.getFieldData(CSFieldValues.EMPTY_STRING,
                    typeStr);
                if (type.equals(verifyStr))
                {
                  category = (String) mrNode.getFieldData(CSFieldValues.
                      EMPTY_STRING, catStr);
                  resolution = (String) mrNode.getFieldData(CSFieldValues.
                      EMPTY_STRING, vfResDStr);

                  catList = (List) map.get(resolution);
                  if (catList == null)
                  {
                    catList = new ArrayList();
                    map.put(resolution, catList);
                  }

                  catList.add(category);
                }
              }
            }
          }
        }
      }
    }
    */

    return map;
  }

 /*
  public static boolean checkVerificationItems(String username,
                                               SystemDataObject sdo,
                                               boolean fromProcessing) throws
  */
  public static boolean checkVerificationItems(SystemDataObject sdo,
                                               boolean fromProcessing) throws

      Exception
  {
    boolean continueMilestones = false;
    DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);

    // 3-4-08, ccl
    // consider both consumer and mortgage
    //
    /*
    HashtableX appData = appNode.getFieldData(CSFieldValues.EMPTY_STRING);
    ManagementRuleSet mrs = MgtRuleRepository.getManagementRuleSet(appData);

    if (mrs == null)
    {
      throw new Exception("Unable to load ManagementRuleSet.");
    }
    */
    // 5-26-2010, ccl
    // call new generic method MgtRuleRepository.getGenericManagementRuleSet()
    //
    /*
    String prodID =
       (String) appNode.getFieldData(CSFieldValues.EMPTY_STRING, CSFieldNames.FN_PRODUCT_ID);

     String mrsName = null;
     String mrsID = null;

     Product product = null;
     ManagementRuleSet mrs = null;

     MtgProduct mgProduct = null;
     MtgMgmtRuleSet mgMrs = null;

     GenericMgmtRuleSet gMrs = null;

     boolean isConsumer = CSUtil.isConsumerApplication(appNode);
     boolean isMortgage = CSUtil.isMortgageApplication(appNode);

     if (prodID != null)
     {
       if (isConsumer)
       {
         product = CSDataCache.getProductManager().getProduct(prodID);

         if (product != null)
         {
           mrsName = product.getManagementRuleSet();
           if (mrsName != null)
           {
             mrsID = ManagementRuleSet.getMgtRuleSetIDFromName(mrsName);
             if (mrsID != null)
             {
               mrs = CSDataCache.getMRSManager().getManagementRuleSet(mrsID);

               if (mrs == null)
               {
                 throw new Exception("Unable to load ManagementRuleSet.");
               }

               gMrs = mrs;
             }
           }
         }
       } // if (isConsumer)
       else if (isMortgage)
       {
         mgProduct = CSDataCache.getMtgProductManager().getProduct(prodID);

         if (mgProduct != null)
         {
           mrsName = mgProduct.getManagementRuleSet();

           if (mrsName != null)
           {
             mrsID = MtgMgmtRuleSet.getMgtRuleSetIDFromName(mrsName);

             if (mrsID != null)
             {
               mgMrs = CSDataCache.getRuleSetManager().getMtgMgmtRuleSet(mrsID);

               if (mgMrs == null)
               {
                 throw new Exception("Unable to load ManagementRuleSet.");
               }

               gMrs = mgMrs;
             }
           }
         }
       } // else if (isMortgage)
     } // if ( prodID != null )
     */

    GenericMgmtRuleSet gMrs = MgtRuleRepository.getGenericManagementRuleSet(appNode);

    if (gMrs == null)
    {
      throw new Exception("Unable to load ManagementRuleSet.");
    }

    boolean verify = true;
    boolean review = false;
    boolean decline = false;

    boolean failed = false;
    boolean unverifiable = false;

    Map resMap = getVerificationResolutionSet(appNode);

    if (resMap.containsKey("failed verification"))
    {
      failed = true;

      //if (mrs.getAvUseAppInfoFails())  // 3-4-08, ccl
      if (gMrs.getAvUseAppInfoFails())
      {
        //String toDo = mrs.getAvAppInfoFailsResponse();
        String toDo = gMrs.getAvAppInfoFailsResponse();

        if (toDo.equals(CSFieldValues.FV_DCSN_DCLN))
        {
          decline = true;
        }
        else
        {
          review = true;
        }

        verify = false;
      }
    }

    if (!decline && resMap.containsKey("could not be verified"))
    {
      unverifiable = true;

      //if (mrs.getAvUseAppInfoUnverifiable())
      if (gMrs.getAvUseAppInfoUnverifiable())
      {
        //String toDo = mrs.getAvAppInfoUnverifiableResponse();
        String toDo = gMrs.getAvAppInfoUnverifiableResponse();

        if (toDo.equals(CSFieldValues.FV_DCSN_DCLN))
        {
          decline = true;
        }
        else
        {
          review = true;
        }

        verify = false;
      }
    }

    boolean failedOrUnverifiable = failed || unverifiable;

    if (verify && !failedOrUnverifiable &&
        !resMap.containsKey("requires verification"))
    {
      verify = false;
    }

    if (!verify)
    {
      appNode.setSystemData(CSStatusCodes.APP_NEEDS_VERIFY,
                            CSFieldValues.FALSE_STRING);
    }

    // Figure out what to do with the app in terms of verification if the
    // current status of the app is "needs verification".
    //
    String status = (String) appNode.getSystemData(CSStatusCodes.SDO_STATUS);
    if (status != null && status.equals(CSStatusCodes.SC_VERIFY))
    {
      // Change the status.
      //
      String newStatus = null;

      if (decline && fromProcessing)
      {
        String dcsn = (String) appNode.getSystemData(CSFieldNames.FN_SYS_DCSN);

        if (dcsn == null || dcsn.equals("n"))
        {
          // Remove the remaining milestones to get it out of live
          //
          //sdo.setRemainingMilestoneNames(new VectorX());   // 5-23-07, ccl

          VectorX remainingMS = sdo.getRemainingMilestoneNames();
          VectorX completedMS = sdo.getCompletedMilestoneNames();

          completedMS.addAll(remainingMS);
          remainingMS.clear();

          sdo.setRemainingMilestoneNames(remainingMS);
          sdo.setCompletedMilestoneNames(completedMS);
          sdo.setSystemData("!!_data_status", "Complete");
          SystemHouse.getSystemDataManager().systemDataObjectCompleted(sdo);
        }

        appNode.setSystemData(CSFieldNames.FN_SYS_DCSN, "d");
        newStatus = CSStatusCodes.SC_DEC_DECLINE;

        DataNode decisionNode = sdo.createDataNode("System",
            NodeUtils.DCSN_DN_TYPE);
        decisionNode.setFieldData(CSFieldValues.EMPTY_STRING,
                                  CSFieldNames.FN_DC_DCSN,
                                  CSFieldValues.FV_DCSN_DCLN);
        decisionNode.setFieldData(CSFieldValues.EMPTY_STRING,
                                  CSFieldNames.FN_DCSN_PARTY, "System");
        decisionNode.setFieldData(CSFieldValues.EMPTY_STRING,
                                  CSFieldNames.FN_DCSN_DATE,
                                  DateUtility.formatDateTime(new java.util.Date()));

        appNode.addReference(decisionNode);

        List categories = failed ? (List) resMap.get("failed verification") :
            (List) resMap.get("could not be verified");

        VectorX decRsnList = new VectorX();
        String systemStr = "System",
            typeStr = "type",
            codeStr = "code",
            rsnStr = "rsn",
            category = null,
            reason = null;

        DataNode rsnNode = null;

        for (int i = 0, c = categories.size(); i < c; ++i)
        {
          category = (String) categories.get(i);
          reason = CSDataCache.getMRReasonsManager().getReason(category);
          if (reason == null)
          {
            reason = CSFieldValues.EMPTY_STRING;
          }

          rsnNode = sdo.createDataNode(systemStr, NodeUtils.UW_RSN_DN_TYPE);
          rsnNode.setFieldData(CSFieldValues.EMPTY_STRING, typeStr,
                               CSFieldValues.FV_DCSN_DCLN);
          rsnNode.setFieldData(CSFieldValues.EMPTY_STRING, codeStr, category);
          rsnNode.setFieldData(CSFieldValues.EMPTY_STRING, rsnStr, reason);

          decisionNode.addReference(rsnNode);
          decRsnList.add(reason);
        }

        decisionNode.setFieldData(CSFieldValues.EMPTY_STRING,
                                  "an_decline_reason_list", decRsnList);
      }
      else
      {
        if (review)
        {
          appNode.setSystemData(CSStatusCodes.APP_NEEDS_REVIEW,
                                CSFieldValues.TRUE_STRING);
          newStatus = CSStatusCodes.SC_REVIEW;
        }
      }

      if (newStatus == null && !verify)
      {
        String appNeedsFnlRvw =
            (String) appNode.getSystemData(CSStatusCodes.APP_NEEDS_FINAL_RVW);

        String appNeedsReview =
            (String) appNode.getSystemData(CSStatusCodes.APP_NEEDS_REVIEW);

        if (appNeedsFnlRvw != null &&
            appNeedsFnlRvw.equals(CSFieldValues.TRUE_STRING))
        {
          newStatus = CSStatusCodes.SC_FINAL_REVIEW;
        }
        else
        {
          if (appNeedsReview != null &&
              appNeedsReview.equals(CSFieldValues.TRUE_STRING))
          {
            newStatus = CSStatusCodes.SC_REVIEW;
          }
          else
          {
            String dcsn = (String) appNode.getSystemData(CSFieldNames.
                FN_SYS_DCSN);

            if (dcsn.equals("a"))
            {
              newStatus = CSStatusCodes.SC_DEC_APPROVE;
            }
            else
            {
              if (dcsn.equals("d"))
              {
                newStatus = CSStatusCodes.SC_DEC_DECLINE;
              }
              else
              {
                if (!failedOrUnverifiable)
                {
                  VectorX remaining = sdo.getRemainingMilestoneNames();

                  if (!remaining.isEmpty())
                  {
                    // Continue on with the CreditBureau milestone.
                    continueMilestones = true;
                  }
                  else
                  {
                    verify = true;
                  }
                }
              }
            }
          }
        }
      }

      if (newStatus != null)
      {
        appNode.setSystemData(CSStatusCodes.SDO_STATUS, newStatus);
      }
    }

    return continueMilestones;
  }


  /**
   *   A method that returns the first non deleted node of the type requested
   *
   *   @param   parentDN (DataNode)
   *            nodeType (String)
   *   @return  DataNode dataNode
   */
  public static DataNode getFirstNodeOfType(DataNode parentDN,
                                            String nodeType)
  {
    DataNode dataNode = null;
    boolean found = false;

    VectorX dataNodeVec = parentDN.getReferences(nodeType);

    if (dataNodeVec != null && !dataNodeVec.isEmpty())
    {
      for (int i = 0; i < dataNodeVec.size() && !found; i++)
      {
        dataNode = (DataNode) dataNodeVec.get(i);

        if (!dataNode.isDeleted())
        {
          found = true;
        } // not deleted
      } // for loop
    } // not null or empty

    if (found)
    {
      return dataNode;
    }
    else
    {
      return null;
    }
  }

  /**
   *   A method that returns the decision date contained in the last decision
   *   datanode
   *
   *   @param   appDN (DataNode)
   *   @return  decision date (String)
   */
  public static String getLastDecisionDate(DataNode appDN)
  {
    String dcsnDt = null;

    if (appDN != null)
    {
      VectorX dcsnVec = appDN.getReferences(NodeUtils.DCSN_DN_TYPE);

      if (dcsnVec != null && !dcsnVec.isEmpty())
      {
        DataNode dcsnDN = (DataNode) dcsnVec.lastElement();
        dcsnDt = (String) dcsnDN.getFieldData(CSFieldValues.EMPTY_STRING,
                                              CSFieldNames.FN_DCSN_DATE);
      }
    }

    return dcsnDt;
  }

  // calculateSBCreditLimit
  //
  private static VectorX calculateSBCreditLimit(DataNode copyOfAppNode,
                                                double sbCreditLmt,
                                                String appId,
                                                String prodName,
                                                VectorX errorMsgVec,
                                                boolean insertFlag) throws Exception
  {
    VectorX tempVec = new VectorX();

    String prodID = (String) copyOfAppNode.getFieldData(CSFieldValues.
        EMPTY_STRING,
        CSFieldNames.FN_SBPRODUCT_ID);

    if (prodID == null)
    {
      throw new Exception("Product ID not found.");
    }

    SBProduct product = CSDataCache.getSBProductManager().getProduct(prodID);

    if (product == null)
    {
      throw new Exception("Product not found in data cache.");
    }

    String pe_maxcredit_xaxis = (String) product.getMaxCreditFieldXDisplay();
    String pe_maxcredit_yaxis = (String) product.getMaxCreditFieldYDisplay();

    if (pe_maxcredit_xaxis != null && pe_maxcredit_yaxis != null)
    {
      try
      {
        sbCreditLmt = AppCalcs.calculateCreditLimit(copyOfAppNode);
      }
      catch (Exception e)
      {
        e.printStackTrace();

        String msg = "App Id: " + appId + " - Product Name: " + prodName + " - Calculate business credit limit. Error: " + e.getMessage();

        errorMsgVec.addElement(msg);
        //errorMsgVec.addElement(CSFieldValues.EMPTY_STRING);

        insertFlag = false;
      }
    }

    tempVec.add(CSFieldValues.EMPTY_STRING + sbCreditLmt);
    tempVec.add(CSFieldValues.EMPTY_STRING + insertFlag);

    return tempVec;

  } // calculateSBCreditLimit



  public static boolean appNeedsReview(DataNode appDN)
  {
    String review = (String) appDN.getSystemData(CSStatusCodes.APP_NEEDS_REVIEW);
    return review != null && review.equals(CSFieldValues.TRUE_STRING);
  }

  public static boolean appNeedsFinalReview(DataNode appDN)
  {
    String finReview = (String) appDN.getSystemData(CSStatusCodes.
        APP_NEEDS_FINAL_RVW);
    return finReview != null && finReview.equals(CSFieldValues.TRUE_STRING);
  }

  /**
   * Below method would have been in a superclass if
   * all object extended the same superclass.  It would have had a function called
   * stringToObject which would have been used to create the object from string.
   *
   * @param htx HashtableX
   * @param cls Class
   * @return HashtableX
   */
  public static HashtableX convertHashStringValuesToHashObjectValues(HashtableX
      htx, Class cls)
  {
    HashtableX returnHtx = null;
    Object obj = null;
    Method method = null;
    try
    {
      obj = cls.newInstance();

      if (htx != null && !htx.isEmpty() && obj != null)
      {
        returnHtx = new HashtableX();
        Object key = null;
        String value = null;
        Class[] clsArray = new Class[1];
        clsArray[0] = String.class;

        method = cls.getMethod("stringToObject", clsArray);
        Iterator it = htx.keySet().iterator();

        Object[] objArray = new Object[1];
        while (it.hasNext())
        {
          key = it.next();
          //S1Log.getLogInstance().log("key " + key + " = " + htx.get(key), true);
          value = StringChanger.getObjectBody( (String) htx.get(key));

          //S1Log.getLogInstance().log("convertHash value " + value, true);
          objArray[0] = value;
          Object valObject = null;
          if (key != null && value != null)
          {
            try
            {
              valObject = method.invoke(obj, objArray);
              //S1Log.getLogInstance().log("convertHash valObject " + valObject, true);
              if (valObject != null)
              {
                returnHtx.put(key, valObject);
              }
            }
            catch (NumberFormatException e)
            {
              returnHtx.put(key, method.invoke(obj, objArray));
            }
          }
        }
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    //log("getVarPricing returnHtx " + returnHtx);
    return returnHtx;
  } //end of

  // 9-17-07, ccl
  /*
  // getProduct
  //
  public static GenericProduct getProduct(String prodId) throws Exception
  {
    return getProduct(prodId, true);
  }
  */
  // getProduct
  //
  //public static GenericProduct getProduct(String prodId, boolean isConsumer)
  public static GenericProduct getProduct(String prodId, boolean isConsumer,
                                          boolean isMortgage)

      throws Exception
  {
    GenericProduct gProduct = null;

    Product product = null;

    SBProduct sbProduct = null;

    MtgProduct mgProduct = null;

    if (isConsumer)
    {
      product = CSDataCache.getProductManager().getProduct(prodId);

      gProduct = product;
    }
    else if (isMortgage)
    {
      mgProduct = CSDataCache.getMtgProductManager().getProduct(prodId);

      gProduct = mgProduct;
    }
    else
    {
      sbProduct = CSDataCache.getSBProductManager().getProduct(prodId);

      gProduct = sbProduct;
    }

    //if (product == null && sbProduct == null)
    if (gProduct == null)
    {
      throw new Exception("Product not found in data cache.");
    }

    return gProduct;
  }

  // defaultCardholderInfo
  //
  private static void defaultCardholderInfo(DataNode appNode, DataNode bwrNode)
  {
    String prdType = (String) appNode.getFieldData(CSFieldValues.EMPTY_STRING,
        CSFieldNames.FN_PRODUCT_TYPE);

    if (prdType != null && prdType.equals(CSFieldValues.FV_PRODUCT_TYPE_CREDIT))
    {
      String tmpName = DataCollection.createCardHolderName(bwrNode.getFieldData(
          CSFieldValues.EMPTY_STRING));

      bwrNode.setSystemData(CSFieldNames.FN_SYS_CRD_BWR, tmpName);
      bwrNode.setSystemData(CSFieldNames.FN_CRD_NAME, tmpName);
      bwrNode.setSystemData(CSFieldNames.FN_CRD_HLDR_C,
                            CSFieldValues.TRUE_STRING);
    }
  }

  // populatePreApprovalTerms
  //
  private static void populatePreApprovalTerms(DataNode newAppNode)
  {
    try
    {
      AppCalcs.calculateCreditLimit(newAppNode);
      AppCalcs.calculatePreApprovedMaxTerm(newAppNode);
      AppCalcs.calculatePricingRate(newAppNode);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }

  public static xResponse reviewAppSetup(SystemDataObject sdo, User user,
                                         boolean canEdit, String appID,
                                         Map nextActionMap,
                                         String editMode, String formName)
  {
    return reviewAppSetup(sdo, user, canEdit, appID, nextActionMap, editMode,
                          formName, null);

  }

  public static xResponse reviewAppSetup(SystemDataObject sdo, User user,
                                         boolean canEdit, String appID,
                                         Map nextActionMap,
                                         String editMode, String formName,
                                         String poolName)
  {
    // the above function is a cut and paste from Underwriting
    // we can call this function with little change from
    // the underwiritng cartridge. 06/27/2006. rn

    String username = user.getUserName();
    if (nextActionMap != null)
    {
      NEXT_ACTION_MAP = nextActionMap;
    }
    xResponse res = new xResponse();

    DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);

    if (appNode == null)
    {
      res.errCode = 1;
      res.param.add("Application data not found in SDO.");
      return res;
    }

    VectorX borrowerNodes = DecisionUtils.getBwrReferences(appNode);

    if (borrowerNodes == null || borrowerNodes.isEmpty())
    {
      try
      {
        if (!editMode.equalsIgnoreCase(CSFieldValues.FV_ARCHIVE_MODE))
        {
          sdo.unlockIfLockedByMe(username);
        }
      }
      catch (SQLException e)
      {
        res.errCode = 1;
        res.param.add(e.getMessage());
        return res;
      }

      res.errCode = 1;
      res.param.add("Application data does not contain any borrowers.");
      return res;
    }

    // Get the product ID that was selected from the application.
    //
    String productID = (String) appNode.getFieldData(username,
        CSFieldNames.FN_PRODUCT_ID);

    if (productID == null)
    {
      try
      {
        if (!editMode.equalsIgnoreCase(CSFieldValues.FV_ARCHIVE_MODE))
        {
          sdo.unlockIfLockedByMe(username);
        }
      }
      catch (SQLException e)
      {
        res.errCode = 1;
        res.param.add(e.getMessage());
        return res;
      }

      res.errCode = 100;
      res.param.addElement("The Product Type is undetermined. \nPlease select a Product Type using the \"Edit\" function in \"ViewApp\" editor.");
      return res;
    }

    // Fetch the product.
    Product appProduct = null;
    MtgProduct mgProduct = null;
    GenericProduct product = null;
    Program program = null;

    boolean isConsumer = CSUtil.isConsumerApplication(appNode);

    if ( isConsumer )
    {
      appProduct = CSDataCache.getProductManager().getProduct(productID);
      product = appProduct;
    }
    else
    {
      mgProduct = CSDataCache.getMtgProductManager().getProduct(productID);
      product = mgProduct;

      String programID = (String)appNode.getFieldData(CSFieldValues.EMPTY_STRING,
          CSFieldNames.FN_PROGRAM_ID);
      if (programID == null)
      {
        res.errCode = 100;
        res.param.add("Program not selected.");
        return res;
      }
      program = CSDataCache.getProgramManager().getProgram(programID);

    }

    if (product == null)
    {
      res.errCode = 1;
      res.param.add("Unable to retrieve Product: " + productID);
      return res;
    }

    // Load the underwriting form.
    String prodType = (String) product.getProductType();
    Form theForm = FormLoader.loadForm(formName, prodType);
    if (theForm == null)
    {
      res.errCode = 1;
      res.param.add("Unable to load form: " + formName);
      return res;
    }

    // Take off the Total_Application_Score vista if not using scorecards.
    theForm.getVistas().remove("Total_Application_Score");

    // Add the product specific vistas to the form.
    VectorX vistas = theForm.getVistas();

    // Remove Fraud/Verification vista if the product is not setup for it.
    if (product.getPrdVerC())
    {
      vistas.remove("Fraud_and_Verification_Reports");
    }

    String warningMsg = null;

    try
    {
      DataEntrySupport.appendLoanSpecificVistas(product, program, vistas, true);
    }
    catch (Exception e)
    {
      warningMsg = e.getMessage();
    }

    // Setup the group object hashtable for showing all the applicant info.
    //
    ClientGOHT goht = DecisionUtils.createBorrowerCycler(appNode, sdo, theForm,
        username);

    DataNode collNode = appNode.getReference(NodeUtils.COLL_DN_TYPE, 0);

    HashtableX systemDecisionInfo = getSystemDecisionInfo(appNode);

    // Populate vista "Cross_Sell_Products".
    //
    HashtableX crossSellProductInfo =
        XSellUtils.getCrossSellProductInfo(appNode, appID);

    VectorX nextActions = new VectorX();

    if (canEdit)
    {
      DataNode lastDecision = DecisionUtils.getLastDecision(appNode);
      if (lastDecision != null)
      {
        String dcsn = (String) lastDecision.getFieldData(CSFieldValues.
            EMPTY_STRING, CSFieldNames.FN_DC_DCSN);
        if (dcsn.equals(COND_APPROVE))
        {
          if (DecisionUtils.evaluateStipulations(lastDecision) != null)
          {
            nextActions.add(SAVE_AND_EXIT);
          }
        }
      }

      if (nextActions.isEmpty())
      {
        nextActions.addAll(nextActionList);
        nextActions.remove(SAVE_AND_EXIT);
        nextActions.add("*" + SAVE_AND_EXIT);
      }
    }
    else
    {
      nextActions.add(CSFieldValues.EMPTY_STRING);
      nextActions.addAll(nextActionList);
    }

    // Check to see if this is a scorecard product or LiquidCredit request.
    //
    boolean isScorecard = product.getPrdAppScoreSel().equals("1");
    boolean isLC = product.getPrdAppScoreSel().equals("2");

    if (isScorecard || isLC)
    {
      int index = nextActions.indexOf(REDECISION);
      if (index != -1)
      {
        nextActions.add(index + 1, RESCORE);
      }
    }

    String appStatus = determineApplicationStatus(appNode);

    // Get all the fields that are not a part of the GOHT.
    //
    HashtableX fieldsHash = appNode.getFieldData(CSFieldValues.EMPTY_STRING);
    fieldsHash.putAll(appNode.getSystemData());

    String loanAmt = (String) appNode.getFieldData(CSFieldValues.EMPTY_STRING,
        CSFieldNames.FN_LOAN_AMT);
    if (loanAmt != null)
    {
      fieldsHash.put(CSFieldNames.FN_DC_ADV_RQ_AMT, loanAmt);
    }

    removeDisabledNextActions(nextActions);

    fieldsHash.put(CSFieldNames.FN_VF_SMYL,
                   CSUtil.getVerificationSummary(appNode));
    fieldsHash.put("an_review_next_action", nextActions);
    fieldsHash.put(CSFieldNames.FN_RETURN_FORM, formName);
    fieldsHash.put(CSFieldNames.FN_EDIT_MODE, editMode);

    VectorX decisionNodes = appNode.getReferences(NodeUtils.DCSN_DN_TYPE);
    if (decisionNodes != null)
    {
      int index = vistas.indexOf("Current_System_Recommended_Decision");

      if (index != -1)
      {
        vistas.insertElementAt("Decision_Details", index + 1);
        vistas.insertElementAt("Stipulation_Details", index + 2);

        DecisionUtils.createDecisionCycler(appNode, goht, appStatus);
      }
    }

    DataEntrySupport.populateAllListBoxes(theForm, sdo, username, fieldsHash);

    //add the _recordStatus to the goht if its PSECU
    String keyName = "_recordStatus";
    String str = (String) fieldsHash.get(keyName);
    if (str != null)
    {
      DataEntrySupport.populateGoHtForCustomer(goht, NodeUtils.DCSN_DN_TYPE,
                                               keyName, str,
                                               CSFieldValues.SYS_CUSTOMER_PSECU);
    }

    if (!editMode.equalsIgnoreCase(CSFieldValues.FV_ARCHIVE_MODE))
    {
      DataEntrySupport.updateFeeTotals(appNode, username, fieldsHash);
    }
    fieldsHash.put(CSFieldNames.FN_APP_ID_HID, appID);

    if (collNode != null)
    {
      fieldsHash.putAll(collNode.getSystemData());
    }

    if (systemDecisionInfo != null)
    {
      fieldsHash.putAll(systemDecisionInfo);
    }

    if (crossSellProductInfo != null)
    {
      fieldsHash.putAll(crossSellProductInfo);
    }

    if (appStatus.length() > 0)
    {
      VectorX vec = new VectorX();
      vec.add(appStatus);

      goht.addToListBoxItems("current_status", vec);
      goht.addToListBoxOrder("current_status");
    }

    if (DecisionUtils.isPreApproval(appNode))
    {
      VectorX vec = new VectorX();
      vec.add("PREAPPROVAL");

      goht.addToListBoxItems("_", vec);
      goht.addToListBoxOrder("_");
    }

    // Setup any form instructions.
    //
    HashtableX instructionHash = new HashtableX();

    if (canEdit)
    {
      //DataEntrySupport.loadInstructionHash(appNode, instructionHash);
      DataEntrySupport.loadInstructionHash(appNode, instructionHash, formName);

      instructionHash.put("Applicant_Summary", readOnlyVista);

      instructionHash.put(CSFieldNames.FN_PRODUCT_ID, readOnlyElement);
      instructionHash.put(CSFieldNames.FN_DC_TTL_HS, readOnlyElement);
      instructionHash.put(CSFieldNames.FN_DC_BASE_CBC, readOnlyElement);
      instructionHash.put(CSFieldNames.FN_DC_BASE_AFFC, readOnlyElement);
      instructionHash.put("an_decline_reason_list", readOnlyElement);
      instructionHash.put("an_override_reason_list", readOnlyElement);
      instructionHash.put(CSFieldNames.FN_BWR_RSK_SCORE, readOnlyElement);
      instructionHash.put(CSFieldNames.FN_BWR_BNK_SCORE, readOnlyElement);
    }
    else
    {
      Iterator it = vistas.iterator();
      String vistaName = null;

      while (it.hasNext())
      {
        vistaName = (String) it.next();

        if (editMode.equalsIgnoreCase(CSFieldValues.FV_ARCHIVE_MODE) &&
            "Select_Bureau_Score.va".equalsIgnoreCase(vistaName))
        {
          // do not make that vista read only.....
        }
        else
        {
          instructionHash.put(vistaName, readOnlyVista);
        }
      }
    }

    if (canEdit)
    {
      // If no system decision, then lockout making a decision.
      //
      if (!hasSystemDecision(decisionNodes))
      {
        nextActions.remove(APPROVE);
        nextActions.remove(DECLINE);
        nextActions.remove(COND_APPROVE);
        nextActions.remove(USE_ALTERNATE);

        warningMsg = "The system has not made a decision on this\n" +
            "application.  You will not be able to submit\n" +
            "a decision at this time.";
      }
    }

    if (poolName != null && poolName.trim().length() > 0)
    {
      fieldsHash.put("_poolName", poolName);
      //get the miscFields from the archived database
      DataEntrySupport.populateUDFVista(fieldsHash, appNode, poolName);

    }

    if (warningMsg != null)
    {
      fieldsHash.put("!!_show_message_box", warningMsg);
    }

    // If the application has more than one collateral and at least one collateral
    // is purchased with money, then the down payment field is read only.
    //
    String isMultColl = (String) fieldsHash.get(CSFieldNames.FN_MULT_PURCHASE);

    if (isMultColl != null && isMultColl.equals(CSFieldValues.TRUE_STRING))
    {
      instructionHash.put(CSFieldNames.FN_DOWN_PAYMENT, readOnlyElement);
    }

    DataEntrySupport.enableSummaryFormButtons(instructionHash);

    HashtableX responseHash = new HashtableX();
    responseHash.put(CSFieldNames.FORM, theForm);
    responseHash.put(CSFieldNames.FIELDS, fieldsHash);
    responseHash.put(CSFieldNames.INSTRUCTIONS, instructionHash);
    responseHash.put("ClientGOHT", goht);

    res.param.addElement(responseHash);
    return res;
  }

  public static xResponse reviewSBAppSetup(SystemDataObject sdo,
                                           User user, boolean canEdit,
                                           String appID, String editMode,
                                           boolean lockedBySomeoneElse,
                                           String formName)
  {
    return reviewSBAppSetup(sdo,
                            user, canEdit,
                            appID, editMode,
                            lockedBySomeoneElse,
                            formName, null);

  }

  public static xResponse reviewSBAppSetup(SystemDataObject sdo,
                                           User user, boolean canEdit,
                                           String appID, String editMode,
                                           boolean lockedBySomeoneElse,
                                           String formName, String poolName)
  {
    // the above function is a cut and paste from SBUnderwriting
    // we can call this function with little change from
    // the SB underwiritng cartridge. 06/27/2006. rn

    String username = user.getUserName();
    xResponse res = new xResponse();
    DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);
    if (appNode == null)
    {
      res.errCode = 1;
      res.param.add("Application data not found in SDO.");
      return res;
    }

    DataNode busNode = appNode.getReference(NodeUtils.BUS_DN_TYPE, 0);
    HashtableX outFields = new HashtableX();

    // Add the application node fields for display.
    //
    outFields.putAll(appNode.getFieldData(CSFieldValues.EMPTY_STRING));
    outFields.putAll(appNode.getSystemData());

    // Add the business node fields for display.
    //
    outFields.putAll(busNode.getFieldData(CSFieldValues.EMPTY_STRING));
    outFields.put("beBsL",
                  DataEntrySupport.buildSubNodeDescriptionsList(appNode,
        NodeUtils.BUS_DN_TYPE));

    // Get the listing of the principals.
    //
    outFields.put("bwrL",
                  DataEntrySupport.buildSubNodeDescriptionsList(appNode,
        NodeUtils.BWR_DN_TYPE));

    // Get the decision information.
    //
    outFields.putAll(DecisionUtils.getSystemDecisionInfo(appNode));

    // Get the collateral information.
    //

    outFields.putAll(DataEntrySupport.getCollateralInfo(sdo, appNode, username));

    //
    // create the debt cap information rn 11/22/2005

    outFields = SBDataEntrySupport.populateCommonDebtRecapValues(outFields,
        appNode);

    // Populate vista "Cross_Sell_Products".
    //
    HashtableX crossSellProductInfo =
        XSellUtils.getSBCrossSellProductInfo(appNode, appID);

    if (crossSellProductInfo != null)
    {
      outFields.putAll(crossSellProductInfo);
    }

    // Get the product ID that was selected from the application.
    //
    String productID = (String) appNode.getFieldData(username,
        CSFieldNames.FN_SBPRODUCT_ID);
    if (productID == null)
    {
      if (canEdit)
      {
        try
        {
          sdo.unlockIfLockedByMe(username);
        }
        catch (SQLException e)
        {
          res.errCode = 1;
          res.param.add(e.getMessage());
          return res;
        }
      }
      res.errCode = 100;
      res.param.add("The Product Type is undetermined. \nPlease select " +
                    "a Product Type using the \"Edit\" function in \"ViewApp\" editor.");
      return res;
    }

    // Fetch the product.
    //
    SBProduct product = CSDataCache.getSBProductManager().getProduct(productID);
    if (product == null)
    {
      res.errCode = 1;
      res.param.add("Unable to retrieve Product: " + productID);
      return res;
    }


    String prodType = (String) product.getProductType();

    // Load the underwriting form.
    String theFormName = formName;
    Form theForm = FormLoader.loadForm(theFormName, prodType);
    if (theForm == null)
    {
      res.errCode = 1;
      res.param.add("Unable to load form: " + theFormName);
      return res;
    }

    String scoreBy = product.getPrdScDetByR();
    boolean LIQUID_CREDIT = scoreBy.equals(FAIR_ISAAC_TOTAL);

    SBDataEntrySupport.populateAllListBoxes(theForm, sdo, appNode, username,
                                            outFields);

    HashtableX instructions = new HashtableX();

    if (CSFieldValues.FV_ARCHIVE_MODE.equalsIgnoreCase(editMode))
    {
      outFields.put("_anProdT",
                    SBDataEntrySupport.createSBProductTableTransaction(sdo,
          user.getUserName(), poolName, false));
    }
    else
    {
      outFields.put("_anProdT",
                    SBDataEntrySupport.createSBProductTableTransaction(sdo,
          user.getUserName(), false));
    }
    if (!canEdit)
    {
      // If the application is opened but cannot be edited, then no need
      // to lock the application.
      //
      if (!lockedBySomeoneElse)
      {
        try
        {
          sdo.unlockIfLockedByMe(username);
        }
        catch (SQLException e)
        {
          res.errCode = 1;
          res.param.add(e.getMessage());
          return res;
        }
      }

      if (poolName != null && poolName.trim().length() > 0)
      {
        //get the miscFields from the archived database
        SBDataEntrySupport.populateUDFVista(outFields, appNode);

      }

      DataEntrySupport.setAllVistasReadOnly(theForm, instructions);
      SBDataEntrySupport.enableSBApplicationFormButtons(instructions);
    }
    else
    {
      //DataEntrySupport.loadInstructionHash(appNode, instructions);
      DataEntrySupport.loadInstructionHash(appNode, instructions, formName);
    }

    String buttonToHide = LIQUID_CREDIT ? "RedecSetupB.sb" : "RedecSetupLCB.sb";
    instructions.put(buttonToHide, readOnlyElement);

    if (canEdit)
    {
      // If no system decision, then lockout making a decision.
      //
      VectorX decisionNodes = appNode.getReferences(NodeUtils.DCSN_DN_TYPE);
      if (!DecisionUtils.hasSystemDecision(decisionNodes))
      {
        String warningMsg = "The system has not made a decision on this\n" +
            "application.";

        outFields.put("!!_show_warning_box", warningMsg);
      }
    }
    if (poolName != null && poolName.trim().length() > 0)
   {
     outFields.put("_poolName", poolName);
   }

    outFields.put(CSFieldNames.FN_RETURN_FORM, theFormName);
    outFields.put(CSFieldNames.FN_EDIT_MODE, canEdit ?
                  CSFieldValues.FV_EDIT_MODE_EDIT :
                  CSFieldValues.FV_EDIT_MODE_VIEW);

    HashtableX responseHash = new HashtableX();
    responseHash.put(CSFieldNames.FORM, theForm);
    responseHash.put(CSFieldNames.FIELDS, outFields);
    responseHash.put(CSFieldNames.INSTRUCTIONS, instructions);

    res.param.add(responseHash);
    return res;
  }

  private static boolean hasSystemDecision(VectorX decisions)
  {
    boolean hasSysDec = false;

    if (decisions != null && !decisions.isEmpty())
    {
      DataNode decisionNode = null;
      String party = null,
          systemStr = "System";

      for (int i = 0; i < decisions.size(); ++i)
      {
        decisionNode = (DataNode) decisions.get(i);
        party = (String) decisionNode.getFieldData(CSFieldValues.EMPTY_STRING,
            CSFieldNames.FN_DCSN_PARTY);
        if (party != null && party.equals(systemStr))
        {
          hasSysDec = true;
          break;
        }
      }
    }

    return hasSysDec;
  }

  private static void removeDisabledNextActions(VectorX nextActions)
  {
    if (NEXT_ACTION_MAP != null)
    {
      Iterator it = NEXT_ACTION_MAP.keySet().iterator();
      String key, value,
          disabledStr = "disabled";

      while (it.hasNext())
      {
        key = (String) it.next();
        value = (String) NEXT_ACTION_MAP.get(key);

        if (value.equals(disabledStr))
        {
          nextActions.remove(key);
        }
      }
    }
  }

  public static String determineApplicationStatus(DataNode appNode)
  {
    String status = (String) appNode.getSystemData(CSStatusCodes.SDO_STATUS);
    String statusDesc = null;

    if (status != null)
    {
      Map statusTable = CSDataCache.getCodeTableManager().getStatusCodes();
      if (statusTable != null)
      {
        statusDesc = (String) statusTable.get(status);
      }
    }

    return statusDesc != null ? statusDesc : CSFieldValues.EMPTY_STRING;
  }

  public static HashtableX getSystemDecisionInfo(DataNode appNode)
  {
    HashtableX fields = null;
    String systemStr = "System";
    VectorX decisions = appNode.getReferences(NodeUtils.DCSN_DN_TYPE);

    if (decisions != null && !decisions.isEmpty())
    {
      DataNode decisionNode = null;
      String party = null;

      int index = 0;

      for (int i = 0; i < decisions.size(); ++i)
      {
        decisionNode = (DataNode) decisions.get(i);
        party = (String) decisionNode.getFieldData(CSFieldValues.EMPTY_STRING, CSFieldNames.FN_DCSN_PARTY);
        if (party != null && party.equals(systemStr))
        {
          index = i;
        }
      }

      decisionNode = (DataNode) decisions.get(index);
      fields = decisionNode.getFieldData(CSFieldValues.EMPTY_STRING);

      String decision = (String) fields.get(CSFieldNames.FN_DC_DCSN);

      if (decision != null)
      {
        fields.put(CSFieldNames.FN_AN_DCSN, decision);
        fields.put(CSFieldNames.FN_AN_DCSN_PARTY, systemStr);
      }
    }

    // Now get all the management rule decision factors.
    //
    Set factors = new TreeSet();

    VectorX borrowers = DecisionUtils.getBwrReferences(appNode);
    if (borrowers != null)
    {
      DataNode bwrNode = null;
      DataNode resNode = null;
      DataNode rptNode = null;

      VectorX results = null;

      StringBuffer buf = new StringBuffer();
      String fname = null;
      String lname = null;
      String name = null;
      String isMerged = null,
          factor = null,
          rpt = null,
          bureau = null,
          date = null,
          mergedStr = "Merged Data",
          spaceStr = " ",
          spaceParenStr = "  (",
          parenStr = ")",
          cbBureauUsedStr = "cb_bureau_used";

      char tChar = 't';

      for (int i = 0; i < borrowers.size(); ++i)
      {
        bwrNode = (DataNode) borrowers.get(i);
        isMerged = (String) bwrNode.getSystemData(CSFieldNames.FN_SYS_MERGED);
        if (isMerged != null && isMerged.charAt(0) == tChar)
        {
          name = mergedStr;
        }
        else
        {
          fname = (String) bwrNode.getFieldData(CSFieldValues.EMPTY_STRING,
                                                CSFieldNames.FN_F_NAME);
          lname = (String) bwrNode.getFieldData(CSFieldValues.EMPTY_STRING,
                                                CSFieldNames.FN_L_NAME);

          if (fname == null)
          {
            fname = CSFieldValues.EMPTY_STRING;
          }
          if (lname == null)
          {
            lname = CSFieldValues.EMPTY_STRING;
          }

          name = buf.append(fname).append(spaceStr).append(lname).toString();
          buf.delete(0, buf.length());
        }

        results = bwrNode.getReferences(NodeUtils.MR_RES_DN_TYPE);

        if (results != null)
        {
          factor = null;

          for (int j = 0; j < results.size(); ++j)
          {
            resNode = (DataNode) results.get(j);
            if (!resNode.isDeleted())
            {
              factor = buf.append(resNode.getDescription()).append(
                  spaceParenStr).
                  append(name).append(parenStr).toString();
              buf.delete(0, buf.length());

              rpt = (String) resNode.getSystemData(CSFieldNames.FN_SYS_RPT);
              if (rpt != null)
              {
                int rptIndex = StringSupport.strToInt(rpt);
                rptNode = bwrNode.getReference(NodeUtils.RPRT_DN_TYPE, rptIndex);

                if (rptNode != null)
                {
                  bureau = (String) rptNode.getFieldData(CSFieldValues.EMPTY_STRING, cbBureauUsedStr);
                  if (bureau == null)
                  {
                    bureau = CSFieldValues.EMPTY_STRING;
                  }

                  date = (String) rptNode.getFieldData(CSFieldValues.EMPTY_STRING, CSFieldNames.FN_CB_RPT_DT);
                  if (date == null)
                  {
                    date = CSFieldValues.EMPTY_STRING;
                  }

                  factor += (buf.append(spaceParenStr).append(bureau).append(spaceStr).
                             append(date).append(parenStr).toString());

                  buf.delete(0, buf.length());
                }
              }

              factors.add(factor);
            }
          }
        }
      }
    }

    // Now get factors from the app node.  These factors don't pertain to
    // any one applicant.
    //
    VectorX appResults = appNode.getReferences(NodeUtils.MR_RES_DN_TYPE);

    if (appResults != null)
    {
      DataNode resNode = null;
      String appStr = "  (Application)";
      for (int i = 0, c = appResults.size(); i < c; ++i)
      {
        resNode = (DataNode) appResults.get(i);
        if (!resNode.isDeleted())
        {
          factors.add(resNode.getDescription() + appStr);
        }
      }
    }

    if (fields == null)
    {
      fields = new HashtableX();
    }

    if (!factors.isEmpty())
    {
      VectorX vec = new VectorX();
      vec.addAll(factors);

      fields.put("an_decision_factor_list", vec);
    }

    return fields;
  }



  /**
   * This method adds the involved personnel data into the map of fields
   * that is passed in.
   *
   * @param appNode DataNode
   * @param fields Map
   */
  public static void getInvolvedPersonnelInfo(DataNode appNode, Map fields)
  {
    // Fill in the "involved personal" vista with the users real names
    //
    User user;

    String str = (String) appNode.getFieldData("", "anDataEntry");
    if (str != null)
    {
      user = User.getUser2(str);
      if (user != null)
      {
        fields.put("anDataEntryName", user.getRealName());
        str = user.getOfficerNumber();
        if (str != null)
        {
          fields.put("anDataEntryOff", str);
        }
      }
    }

    str = (String) appNode.getFieldData("", "anProcessor");
    if (str != null)
    {
      user = User.getUser2(str);
      if (user != null)
      {
        fields.put("anProcessorName", user.getRealName());
        str = user.getOfficerNumber();
        if (str != null)
        {
          fields.put("anProcessorOff", str);
        }
      }
    }

    str = (String) appNode.getFieldData("", "anAuditor");
    if (str != null)
    {
      user = User.getUser2(str);
      if (user != null)
      {
        fields.put("anAuditorName", user.getRealName());
        str = user.getOfficerNumber();
        if (str != null)
        {
          fields.put("anAuditorOff", str);
        }
      }
    }

    str = (String) appNode.getFieldData("", "anVerifier");
    if (str != null)
    {
      user = User.getUser2(str);
      if (user != null)
      {
        fields.put("anVerifierName", user.getRealName());
        str = user.getOfficerNumber();
        if (str != null)
        {
          fields.put("anVerifierOff", str);
        }
      }
    }

    str = (String) appNode.getFieldData("", "anUnder");
    if (str != null)
    {
      user = User.getUser2(str);
      if (user != null)
      {
        fields.put("anUnderName", user.getRealName());
        str = user.getOfficerNumber();
        if (str != null)
        {
          fields.put("anUnderOff", str);
        }
      }
    }

    str = (String) appNode.getFieldData("", "anFnlRvw");
    if (str != null)
    {
      user = User.getUser2(str);
      if (user != null)
      {
        fields.put("anFnlRvwName", user.getRealName());
        str = user.getOfficerNumber();
        if (str != null)
        {
          fields.put("anFnlRvwOff", str);
        }
      }
    }

    str = (String) appNode.getFieldData("", "anLnOff");
    if (str != null)
    {
      user = User.getUser2(str);
      if (user != null)
      {
        fields.put("anLnOffName", user.getRealName());
        str = user.getOfficerNumber();
        if (str != null)
        {
          fields.put("anLnOffOff", str);
        }
      }
    }
  }

  // 6-29-07, ccl
  // hasNoRightToEdit
  //
  public static xResponse hasNoRightToEdit(String username)
  {
    xResponse res = new xResponse();

    boolean isEdit = false;

    User user = User.getUser(username);

    if (user == null)
    {
      res.errCode = 1;
      res.param.addElement("Unable to load user object.");
      return res;
    }

    String userBranchId = user.getUserBranch();

    if (userBranchId == null)
    {
      res.errCode = 1;
      res.param.addElement("Unable to determine user branch.");
      return res;
    }

    String userLevel = user.getUserLevel();

    if (userLevel == null)
    {
      res.errCode = 1;
      res.param.addElement("Unable to determine user level.");
      return res;
    }

    if (userLevel.equals(USER_NONE))
    {
      res.errCode = 100;
      res.param.add(
          "User does not currently have edit rights to this application.");
      return res;
    }

    return res;
  }



  // 2-19-08, ccl
  // getVfRuleTable
  //
  public static HashtableX getVfRuleTable(DataNode appNode) throws
      Exception
  {
    HashtableX vfRuleTable = null;

    // 5-26-2010, ccl
    // call new generic method MgtRuleRepository.getGenericManagementRuleSet()
    //
    /*
    String prodID =
        (String) appNode.getFieldData(CSFieldValues.EMPTY_STRING, CSFieldNames.FN_PRODUCT_ID);

    String mrsName = null;
    String mrsID = null;

    Product product = null;
    ManagementRuleSet mrs = null;

    MtgProduct mgProduct = null;
    MtgMgmtRuleSet mgMrs = null;

    boolean isConsumer = CSUtil.isConsumerApplication(appNode);
    boolean isMortgage = CSUtil.isMortgageApplication(appNode);

    if ( prodID != null )
    {
      if (isConsumer)
      {
        product = CSDataCache.getProductManager().getProduct(prodID);

        if (product != null)
        {
          mrsName = product.getManagementRuleSet();
          if (mrsName != null)
          {
            mrsID = ManagementRuleSet.getMgtRuleSetIDFromName(mrsName);
            if (mrsID != null)
            {
              mrs = CSDataCache.getMRSManager().getManagementRuleSet(mrsID);

              if (mrs == null)
              {
                throw new Exception("Unable to load ManagementRuleSet.");
              }

              vfRuleTable = mrs.getVfRules();
            }
          }
        }
      }  // if (isConsumer)
      else if (isMortgage)
      {
        mgProduct = CSDataCache.getMtgProductManager().getProduct(prodID);

        if (mgProduct != null)
        {
          mrsName = mgProduct.getManagementRuleSet();

          if (mrsName != null) {
            mrsID = MtgMgmtRuleSet.getMgtRuleSetIDFromName(mrsName);

            if (mrsID != null) {
              mgMrs = CSDataCache.getRuleSetManager().getMtgMgmtRuleSet(mrsID);

              if (mgMrs == null)
              {
                throw new Exception("Unable to load ManagementRuleSet.");
              }

              vfRuleTable = mgMrs.getVfRules();
            }
          }
        }
      }    // else if (isMortgage)
    }   // if ( prodID != null )
    */
    GenericMgmtRuleSet gMrs = MgtRuleRepository.getGenericManagementRuleSet(appNode);

    if (gMrs == null)
    {
      throw new Exception("Unable to load ManagementRuleSet.");
    }

    vfRuleTable = gMrs.getVfRules();

    return vfRuleTable;
  }   // getVfRuleTable


  // copy original sdo, delete borrowers and make the decision pary borrowers from
  // the original the borrowers on the copy. then get est pmt node form orig and
  // it to the existing est pmt node in the sdo copy.
  //
  // SystemDataObject sdoCopy = createXSellCopyOfSDO(sdo);
  //
  // public static SystemDataObject createXSellCopyOfSDO( String appId, String prodId ) throws Exception
  //
  public static SystemDataObject createXSellCopyOfSDO( SystemDataObject sdoToCopy, boolean isConsumer ) throws Exception
  {
    //general.errLog("START createXSellCopyOfSDO( SystemDataObject sdoToCopy )","CrtCpySdo.log");
    SystemDataObject sdoCopy = null;

    try
    {
      String body = StringChanger.getObjectBody(sdoToCopy.toString());
      sdoCopy = SystemDataObject.stringToObject( body );
      sdoCopy.writeBigHash("XSell_SdoCopy.log");
    }
    catch( Exception e )
    {
      e.printStackTrace();
    }

    //general.errLog("if( sdoCopy != null ): "+( sdoCopy != null ),"CrtCpySdo.log");
    if( sdoCopy != null )
    {
      DataNode appNode = sdoCopy.getNodeData( NodeUtils.APP_DN_TYPE );

      //general.errLog("if( appNode != null ): "+( appNode != null ),"CrtCpySdo.log");
      if( appNode != null )
      {
        if( isConsumer )
        {

          VectorX decParty  = (VectorX) appNode.getSystemData(CSFieldNames.FN_SYS_DEC_PARTY);

          // leave borrowers
          boolean leaveBorrowers = decParty == null || decParty.isEmpty() ||
                               ((String)decParty.firstElement()).equals("-1");

          try
          {
            if (!leaveBorrowers)
            {
              VectorX borrowerNodes = getAllDecisionPartyBwrNodes(appNode);
              VectorX newDecParty = new VectorX();

              if (borrowerNodes != null && !borrowerNodes.isEmpty())
              {
                if (borrowerNodes.size() > 1)
                {
                  // get NodeUtils.BWR_DN_TYPE, do not process last element
                  //
                  // appNode.removeReferences(NodeUtils.DCSN_DN_TYPE);
                  //
                  appNode.removeReferences(NodeUtils.BWR_DN_TYPE);
                  int counter = -1;

                  for (int i = 0, c = (borrowerNodes.size() - 1); i < c; i++)
                  {
                    DataNode bwrNode = (DataNode) borrowerNodes.get(i);
                    if (bwrNode != null && !bwrNode.isDeleted())
                    {
                      appNode.addReference(bwrNode);
                      counter++;
                      newDecParty.add(String.valueOf(counter));
                    }
                  }

                  // get NodeUtils.CMB_BWR_DN_TYPE, will be last element in vector
                  //
                  appNode.removeReferences(NodeUtils.CMB_BWR_DN_TYPE);
                  DataNode cmbNode = (DataNode) borrowerNodes.lastElement();

                    if (cmbNode != null && !cmbNode.isDeleted())
                    {
                      cmbNode.setSystemData("!indices", newDecParty);
                      appNode.addReference(cmbNode);
                    }
                  }
                  else
                  {
                    appNode.removeReferences(NodeUtils.BWR_DN_TYPE);
                    DataNode bwrNode = (DataNode) borrowerNodes.firstElement();
                    appNode.addReference(bwrNode);
                    newDecParty.add("0");

                  }

                  appNode.setSystemData(CSFieldNames.FN_SYS_DEC_PARTY,newDecParty);

                } // if( borrowerNodes != null && ! borrowerNodes.isEmpty() )
              }

              try
              {
                copyEstimatedPmtNode(appNode);
              }
              catch (Exception o)
              {
                o.printStackTrace();
                //general.errLog("o: " + o, "CrtCpySdo.log");
                throw new Exception("Error - CSUtil.copyEstimatedPmtNode: " +
                                    o);
              }
          }
          catch(Exception ee)
          {
            ee.printStackTrace();
            //general.errLog("ee: "+ee,"CrtCpySdo.log");
          }
        }
        else
        {
          try
          {
            copyEstimatedPmtNode(appNode);
          }
          catch( Exception o )
          {
            o.printStackTrace();
            //general.errLog("o: "+o,"CrtCpySdo.log");
            throw new Exception( "Error - CSUtil.copyEstimatedPmtNode: " + o );
          }

        }
      } // if( appNode != null )
    } // if( sdoCopy != null )

    //general.errLog("END createXSellCopyOfSDO( SystemDataObject sdoToCopy )","CrtCpySdo.log");

    return sdoCopy;
  }

  // copy original sdo, delete borrowers and make a new sdo for each decision
  // party borrower from the original app. then get est pmt node form orig and
  // it to the existing est pmt node in the sdo copy.
  //
  // public static VectorX createBusXSellCopyOfSDO( String appId ) throws Exception
  //
  public static VectorX createBusXSellCopyOfSDO( SystemDataObject sdo ) throws Exception
  {
    // SystemDataObject sdoCopy = null;
    //
    VectorX sdoCopyList = new VectorX();

    //try
    //{
    //  sdoCopy = SDOUtils.getSDO( appId );
    //}
    //catch( Exception e )
    //{
    //  e.printStackTrace();
    //}

    if( sdo != null )
    {
      DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);

      if (appNode != null)
      {
        try
        {
          // use the valid borrowers not the decision party borrowers
          //
          // VectorX borrowerNodes = getAllDecisionPartyBwrNodes(appNode);
          //
          VectorX borrowerNodes = appNode.getEffectiveReferences( NodeUtils.BWR_DN_TYPE );

          if( borrowerNodes != null && !borrowerNodes.isEmpty() )
          {
            for(int i=0,c=borrowerNodes.size(); i<c; i++)
            {
              String body = StringChanger.getObjectBody(sdo.toString());

              SystemDataObject copyOfSdoCopy = SystemDataObject.stringToObject( body );
              DataNode appNodeCopy = copyOfSdoCopy.getNodeData(NodeUtils.APP_DN_TYPE);

              // set app type to consumer
              //
              appNodeCopy.setSystemData("!type", "c");

              // remove borrower and business nodes
              //
              appNodeCopy.removeReferences(NodeUtils.BWR_DN_TYPE);
              appNodeCopy.removeReferences(NodeUtils.BUS_DN_TYPE);

              DataNode bwrNode = (DataNode) borrowerNodes.get(i);

              if( bwrNode != null &&  ! bwrNode.isDeleted() )
              {
                appNodeCopy.addReference(bwrNode);

                try
                {
                  copyEstimatedPmtNode(appNodeCopy);
                }
                catch (Exception o)
                {
                  o.printStackTrace();
                  throw new Exception("Error - CSUtil.copyEstimatedPmtNode: " + o);
                }

                // 7-9-2010, ccl
                // need to reset the status flag of copied nodes
                //
                appNodeCopy.copy();

                sdoCopyList.add(copyOfSdoCopy);

              } //if( bwrNode != null &&  ! bwrNode.isDeleted() )
            } // for(int i=0,c=borrowerNodes.size(); i<c; i++)
          }  // if( borrowerNodes != null && ! borrowerNodes.isEmpty() )
        }
        catch(Exception ee)
        {
          ee.printStackTrace();
        }

      } // if (appNode != null)

    } // if( sdoCopy != null )

    return sdoCopyList;
  }

  // get the list of decision party borrower nodes
  //
  public static VectorX getAllDecisionPartyBwrNodes(DataNode appNode) throws Exception
  {
    DataNode subjectNode = null;
    VectorX decPartyList = null;
    VectorX decPartyVec  = (VectorX) appNode.getSystemData(CSFieldNames.FN_SYS_DEC_PARTY);

    if( decPartyVec != null && ! decPartyVec.isEmpty() )
    {
      decPartyList = new VectorX();

      for( int i=0,c=decPartyVec.size(); i<c; i++ )
      {
        String indexS = (String)decPartyVec.get(i);

        // For business, either the business or the primary borrower is the decision
        // party - so there is only one party in the decision party vector.
        //
        if( indexS != null && indexS.trim().equals("B") )
        {
          subjectNode = appNode.getReference(NodeUtils.BUS_DN_TYPE, 0);
          decPartyList.add( subjectNode );
          break;
        }
        else if( indexS != null )
        {
          int index = StringSupport.strToInt( indexS );

          if (index == -1)
          {
            // get all borrower nodes for application decision party
            decPartyList.addAll(appNode.getReferences(NodeUtils.BWR_DN_TYPE));
          }
          else
          {
            subjectNode = appNode.getReference(NodeUtils.BWR_DN_TYPE, index);
            decPartyList.add(subjectNode);
          }
        }
      }

      if( decPartyList != null && decPartyList.size() > 1 )
      {
        DataNode cmbBwr;
        VectorX indices;
        List cmbBwrList = appNode.getEffectiveReferences(NodeUtils.CMB_BWR_DN_TYPE);

        for (int i = 0, c = cmbBwrList.size(); i < c; ++i)
        {
          subjectNode = null;
          cmbBwr = (DataNode) cmbBwrList.get(i);
          indices = (VectorX) cmbBwr.getSystemData("!indices");

          if( indices != null && indices.toString().equals(decPartyVec.toString()) )
          {
            subjectNode = cmbBwr;

            // Just in case we are dealing with an older application that did not
            // have the !indices field in the combined borrower node (e.g. an app
            // that existed before multiple combined borrowers).
            //
            if (subjectNode == null)
            {
              subjectNode = appNode.getReference(NodeUtils.CMB_BWR_DN_TYPE, 0);
            }

            decPartyList.add( subjectNode );
            break;
          }
        }
      }
    }
    else
    {
      decPartyList = new VectorX();
      subjectNode = appNode.getReference(NodeUtils.BWR_DN_TYPE, 0);
      decPartyList.add( subjectNode );
    }

    if (decPartyList == null )
    {
      throw new Exception("Unable to find decision party.");
    }

    return decPartyList;
  }


  public static void copyEstimatedPmtNode( DataNode appNode ) throws Exception
  {
    DataNode estPmtNode = appNode.getFirstReference( NodeUtils.EP_DN_TYPE );

    if( estPmtNode != null )
    {
      // 7-9-2010, ccl
      // need to reset the status flag of copied nodes
      //
      //DataNode newEstPmtNode = DataNode.stringToObject( estPmtNode.toString() );
      DataNode newEstPmtNode = estPmtNode.copy();

      // pmt set to neg one
      //
      newEstPmtNode.setFieldData(CSFieldValues.EMPTY_STRING, CSFieldNames.FN_CB_TR_PMT, "-1");

      // type set to 'A'
      //
      newEstPmtNode.setFieldData(CSFieldValues.EMPTY_STRING, CSFieldNames.FN_CB_TR_ACT_TYPE, "A");

      appNode.addReference( newEstPmtNode );
    }
  }


  private static void toFile(String fileName, String data)
  {
    FileWriter fw = null;

    try {
      fw = new FileWriter(fileName);
      fw.write(data);
    }
    catch (IOException e) {
      //e.printStackTrace();
    }
    finally {
      try {
        fw.close();
      }
      catch (Exception e) {
      }
    }
  }

  // 4-16-2010, ccl
  // updateRejectedOrOfferedPAO
  //
  public static void updateRejectedOrOfferedPAO(String username, String paoProdId,
                                                String paoSSN, boolean isReject,
                                                boolean isSSN) throws Exception
  {
    // 4-27-2010
    //
    /*
    String status = CSFieldValues.EMPTY_STRING;
    String newAppId = CSFieldValues.EMPTY_STRING;

    if (isReject) {
      status = "r";
    }
    else {
      status = "o";
    }
    */
    try
    {
      DBQueries.updatePAO_DBTable(username, paoProdId, paoSSN, isReject, false, null, null, isSSN);
    }
    catch (SQLException e)
    {
      throw new Exception("Update pre-approval offers DB Table error: " + e);
    }
  } // updateRejectedOrOfferedPAO



  public static boolean isPAOProductEquivalent (String oldProductId,
                                                String paoOfferProductId)
  {
    boolean equivalent = (oldProductId == null ||
                          oldProductId.equals(paoOfferProductId));

    if (!equivalent)
    {
      VectorX products =
                  ApplicationHouse.getListContentCache().getListContents(
                paoOfferProductId + " PAO");
      equivalent = (products != null && products.contains(oldProductId));
    }

    return equivalent;
  }



  // acceptPAO
  //
  public static String acceptPAO( String username,  String paoProdId,
                                    String paoSSN, HashtableX inFieldsHash,
                                    boolean isSSN, String newProdId)
        throws Exception

  {
    String newAppId = null;
    SystemDataObject sdo = null;

    String branch = (String) inFieldsHash.get(CSFieldNames.FN_BRANCH_ID);
    if (branch == null)
    {
      User user = User.getUser(username);
      branch = user.getUserBranch();
    }

    int branchID = StringSupport.strToInt(branch);

    try
    {
      sdo = SDOUtils.createSDO(branchID, username);
    }
    catch (Exception e)
    {
      e.printStackTrace();
      throw new Exception("Error from creating SDO: " + e);
    }

    HashtableX bwrHT = NodeUtils.extractDataHash(NodeUtils.BWR_DN_TYPE, inFieldsHash);   // 6-7-2010, CKD

    try
    {
      //updateAppAndBwrNode(sdo, paoProdId, paoSSN, username);   // 5-11-2010, ccl,   6-7-2010, CKD
      updateAppAndBwrNode(sdo, paoProdId, paoSSN, username, isSSN, bwrHT, newProdId);
    }
    catch (SQLException e)
    {
      e.printStackTrace();
      DBLogger.log("Accept Pre-approval offer error: " + e);
      throw new Exception("Accept Pre-approval offer error: " + e);
    }

    newAppId = SDOUtils.getAppIDFromSDO(sdo, username);

    if (newAppId == null)
    {
      throw new Exception("Unable to obtain Cross-Sell application id.");
    }

    // Save the new paoSDO
    //
    try
    {
      SDOUtils.saveSDO(username, sdo, CSStatusCodes.SDO_UNLOCK);
      //general.errLog("SDOUtils.saveSDO(username, xSellSDO, CSStatusCodes.SDO_UNLOCK)","AcceptXSell.log");
    }
    catch (SQLException e)
    {
      e.printStackTrace();
      throw new Exception("Unable to save application: " + newAppId +". Database error: " + e);
    }

    DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);

    String newRefId = (String) appNode.getFieldData(username, CSFieldNames.FN_APP_REF_ID);

    try
    {
      // accepted cross sell sdo in database is set to null. there shuld be no
      // need to load from the db table. can load from credisphere sdo directory
      //
      //DBQueries.updatePAO_DBTable(username, paoProdId, paoSSN,  false, true, newAppId, newRefId);
      DBQueries.updatePAO_DBTable(username, paoProdId, paoSSN,  false, true,
                                  newAppId, newRefId, isSSN);
      //general.errLog("DBQueries.updateAppXSellDBTable * EXECUTED *","AcceptXSell.log");
    }
    catch (SQLException e)
    {
      e.printStackTrace();
      DBLogger.log("Update Pre-approval offer Table error: " + e);
      throw new Exception("Update Pre-approval offer Table error: " + e);
    }

    return newAppId;
  } // acceptPAO


  // updateAppAndBwrNode
  //
  private static void updateAppAndBwrNode(SystemDataObject sdo, String paoProdId,
                                          String paoSSN, String username, boolean isSSN,
                                          HashtableX bwrFields,
                                          String newProdId) throws Exception, SQLException
  {
    //general.errLog("START updateAppAndBwrNode(...)", "AcceptPOA.log");

    Statement stmt = null;
    String selectStmt = null;

    if (isSSN)
    {
      selectStmt = "SELECT * FROM xntPreApprovalOffers WHERE nProdId='" + paoProdId +
          "' AND cSSN='" + paoSSN +
          "' AND (dtExpire is NULL or dtExpire > getDate())";
    }
    else
    {
      selectStmt = "SELECT * FROM xntPreApprovalOffers WHERE nProdId='" + paoProdId +
          "' AND cCif='" + paoSSN +
          "' AND (dtExpire is NULL or dtExpire > getDate())";

    }

    try
    {
      Connection con = DBConnPool.getConnection();
      stmt = con.createStatement();

      ResultSet rs = stmt.executeQuery(selectStmt);

      String str;
      Timestamp ts;

      HashtableX bwrHT = null;
      HashtableX appHT = null;
      HashtableX fieldsHash = new HashtableX();

      DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);

      // create borrower node
      //
      DataNode bwrNode = sdo.createDataNode(username, NodeUtils.BWR_DN_TYPE);

      appNode.addReference(bwrNode);

      // create decision node
      //
      DataNode dcsnNode = sdo.createDataNode(username, NodeUtils.DCSN_DN_TYPE);

      String todaysDate = DateUtility.getTodaysDate("MDY", "/");
      String todaysTime = DateUtility.getTimeHourMinuteAMPM();

      dcsnNode.setFieldData(username, CSFieldNames.FN_DCSN, CSFieldValues.FV_DCSN_APRV);  // dcDcsn = "Approve"
      dcsnNode.setFieldData(username, CSFieldNames.FN_DCSN_PARTY, "Preapproval");  // dcDcsnPty = "Preapproval"
      dcsnNode.setFieldData(username, CSFieldNames.FN_DCSN_DATE, todaysDate + " " + todaysTime);  // dcDcsnDt

      appNode.addReference(dcsnNode);

      // set the flag and status
      //
      appNode.setSystemData("!pao_sdo", "t");
      appNode.setSystemData(CSStatusCodes.SDO_STATUS,
                          CSStatusCodes.SC_INCOMPLETE_PREAPV);

      appNode.setSystemData(CSStatusCodes.APP_DECISION,
                          CSStatusCodes.APP_DECISION_APPROVE);   // !dcsn = 'a'

      // 8-31-2010, ccl
      // set !review and !finrvw to be false
      //
      appNode.setSystemData(CSStatusCodes.APP_NEEDS_REVIEW, CSFieldValues.FALSE_STRING);
      appNode.setSystemData(CSStatusCodes.APP_NEEDS_FINAL_RVW, CSFieldValues.FALSE_STRING);

      appHT = appNode.getFieldData(username);
      if (appHT == null) appHT = new HashtableX();

      bwrHT = bwrNode.getFieldData(username);
      if (bwrHT == null) bwrHT = new HashtableX();

      GenericProduct gp = CSDataCache.getProductManager().getProduct(newProdId);

      boolean appIsRisk = gp.getPrdAppScoreSel() != null &&
                          gp.getPrdAppScoreSel().equals("0");


      while (rs.next())
      {
        // get borrower's information
        //
        str = rs.getString("cFName");
        if (str != null) bwrHT.put(CSFieldNames.FN_F_NAME, str.trim());

        str = rs.getString("cLName");
        if (str != null) bwrHT.put(CSFieldNames.FN_L_NAME, str.trim());

        str = rs.getString("cSSN");
        if (str != null) bwrHT.put(CSFieldNames.FN_SSN, str.trim());

        str = rs.getString("cCif");
        if (str != null) bwrHT.put(CSFieldNames.FN_BWR_CIF, str.trim());

        // split the address and put them into eaxh individual field
        //
        str = rs.getString("cAddr");
        if (str != null)
        {
          AppImportUtils.parseAddressLine(str, bwrHT, true);
        }

        str = rs.getString("cAddrTwo");
        if (str != null) bwrHT.put(CSFieldNames.FN_BWR_ADDR_TWO, str.trim());

        str = rs.getString("cCity");
        if (str != null) bwrHT.put(CSFieldNames.FN_BWR_CITY, str.trim());

        str = rs.getString("cSt");
        if (str != null) bwrHT.put(CSFieldNames.FN_BWR_STATE, str.trim());

        str = rs.getString("cZip");
        if (str != null) bwrHT.put(CSFieldNames.FN_BWR_ZIP, str.trim());

        bwrHT.putAll(bwrFields);

        // get score for creating report node
        //
        str = rs.getString("cRiskScore");
        if (str != null)
        {
          bwrHT.put(CSFieldNames.FN_BWR_RSK_SCORE, str.trim());
          fieldsHash.put(CSFieldNames.FN_BWR_RSK_SCORE, str.trim());
          if (appIsRisk)
          {
            appNode.setSystemData(CSFieldNames.FN_APP_SCORE, str.trim());
            bwrNode.setSystemData(CSFieldNames.FN_APP_SCORE, str.trim());
          }

          appNode.setSystemData(CSFieldNames.FN_SYS_RSK_SCORE, str.trim());
        }

        str = rs.getString("cBnkScore");
        if (str != null)
        {
          bwrHT.put(CSFieldNames.FN_BWR_BNK_SCORE, str.trim());
          fieldsHash.put(CSFieldNames.FN_BWR_BNK_SCORE, str.trim());
          appNode.setSystemData(CSFieldNames.FN_BKCY_SCORE, str.trim());
        }

        bwrNode.setFieldData(username, bwrHT);

        // get application data
        // used passed in productId
        //String productId = String.valueOf(rs.getInt("nProdId"));

        appHT.put(CSFieldNames.FN_PRODUCT_ID, newProdId);  // anProdTypeD
        appHT.put(CSFieldNames.FN_INT_RATE, String.valueOf(rs.getDouble("fIntRate")));  // anIntRate
        //appHT.put(CSFieldNames.FN_MARGIN, String.valueOf(rs.getDouble("fMargin")));  // anIntRate
        appHT.put(CSFieldNames.FN_NUM_PMT, String.valueOf(rs.getInt("nNumPmt")));  // anNumPmt
        appHT.put(CSFieldNames.FN_AMT_APPROVED, String.valueOf(rs.getDouble("mAmtApv")));  // anAmtApv
        appHT.put(CSFieldNames.FN_LOAN_AMT, String.valueOf(rs.getDouble("mAmtApv")));  // anLoanAmt
        // 6-7-2010, CKD
        appHT.put(CSFieldNames.FN_NW_REQ, String.valueOf(rs.getDouble("mAmtApv")));  // anLoanAmt
        appHT.put(CSFieldNames.FN_AMT_REQ, String.valueOf(rs.getDouble("mAmtApv")));  // anLoanAmt
        appHT.put(CSFieldNames.FN_PRE_APPROVED, CSFieldValues.TRUE_STRING);
        // get product data and put in application node
        //
        //DataEntrySupport.getProductDefaultInfo(sdo, username, appHT);

        AppImportUtils.getProductDefaultData(gp, appHT, true, false);
        AppImportUtils.loadDateFields(appHT);

        appHT.remove("anDfltFeesHash");

        // 6-7-2010, ccl
        //
        boolean isMortgage = isMortgageApplication(appNode);

        DataEntrySupport.defaultPaymentInfo(appHT, isMortgage, appNode);

        try
        {
          String dueDate = CSUtil.calcLoanMaturityDate(appHT);
          if (dueDate != null) appHT.put(CSFieldNames.FN_DUE_DT, dueDate);
        }
        catch (Exception e) {
          e.printStackTrace();
        }

        appNode.setFieldData(username, appHT);

        DataEntrySupport.createDefaultFeeNodes(sdo, appNode, username);

        if (!fieldsHash.isEmpty())
        {
          DataCollection.createReportNode(sdo, appNode, bwrNode, fieldsHash, username);

          DataNode rptNode = bwrNode.getFirstReference(NodeUtils.RPRT_DN_TYPE);
          if (rptNode != null)
          {
            rptNode.removeSystemData("!de");
          }
        }
      }  // while
    }
    catch (SQLException e)
    {
      e.printStackTrace();

      String errorMsg = "CSUtil.updateAppAndBwrNode(...) - SQLException thrown: " + e.getMessage();

      DBErrorLogger.log(errorMsg);

      throw e;
    }
    finally
    {
      DBConnPool.closeConnection(stmt);
    }

    //general.errLog("END updateAppAndBwrNode(...)", "AcceptPOA.log");

  }   // updateAppAndBwrNode


  private static xResponse invokeDoOpcode(String opcode, String extension, VectorX params)
  {
    Class ex = null;

    try
    {
      ex = Class.forName(extension);
    }
    catch (Exception e)
    {
      xResponse res = new xResponse();
      res.errCode = 2;
      res.param.addElement(SystemHouse.getMessages().get(CSFieldValues.EMPTY_STRING + 2));
    }

    xResponse res = null;

    try
    {
      Object instance = ex.newInstance();

      Class[] ca = new Class[2];
      ca[0] = Class.forName( "java.lang.String" ); // opCode
      ca[1] = Class.forName( "java.lang.Object" ); // args

      Method mm = ex.getMethod( "doOpCode", ca );

      Object[] oa = new Object[2];
      oa[0] = opcode;
      oa[1] = params;

      Object obj = mm.invoke(instance, oa);

      if (obj instanceof xResponse)
      {
        res = (xResponse)obj;
      }
      else
      {
        res = new xResponse();
      }
    }
    catch( NoSuchMethodException e)
    {
      res = new xResponse();
      res.errCode = 2;
      res.param.addElement(e.toString());
    }
    catch( SecurityException e )
    {
      res = new xResponse();
      res.errCode = 2;
      res.param.addElement(e.toString());
    }
    catch( ClassNotFoundException e)
    {
      res = new xResponse();
      res.errCode = 2;
      res.param.addElement(e.toString());
    }
    catch( IllegalAccessException e)
    {
      res = new xResponse();
      res.errCode = 2;
      res.param.addElement(e.toString());
    }
    catch( InstantiationException e)
    {
      res = new xResponse();
      res.errCode = 2;
      res.param.addElement(e.toString());
    }
    catch ( NullPointerException e)
    {
      res = new xResponse();
      res.errCode = 2;
      res.param.addElement("Unknown Extension.");

      AdminGUIManager.displayS("Unknown extension (" + extension + ").");
    }
    catch( Exception e)
    {
      ExceptionLogger.logException(e);
      res = new xResponse();
      res.errCode = 4;
      res.param.addElement(e.toString());

      AdminGUIManager.displayS("Uncaught Exception: " +
                               opcode + "." + extension);
      //logException(e);

      StringWriter sw = new StringWriter();
      PrintWriter pw = new PrintWriter(sw);
      e.printStackTrace(pw);

      Map fields = new HashMap();
      fields.put("opcode", opcode + "." + extension);
      fields.put("error", sw.toString());

      MailAlertMessage.sendAlert("UncaughtException", fields);
    }

    return res;
  }


  /**
   * Method to find the primary applicant on the app.  This would be the
   * borrower node with atBwrTypD = "Applicant"
   *
   * @param appNode
   * @return
   */
  public static DataNode getPrimaryApplicant(DataNode appNode)
  {
    List borrowers = appNode.getEffectiveReferences(NodeUtils.BWR_DN_TYPE);

    boolean found = false;
    DataNode borrower = null;
    for (int i = 0, c = borrowers.size(); i < c; ++i)
    {
      borrower = (DataNode)borrowers.get(i);
      String bwrType = (String)borrower.getFieldData("", CSFieldNames.FN_BWR_TYPE);
      if (bwrType != null && bwrType.equals(CSFieldValues.FV_APPLICANT))
      {
        found = true;
        break;
      }
    }

    if (! found) borrower = null;

    return borrower;
  }


  /**
   * Method to find the primary applicant on the app.  This would be the
   * borrower node with atBwrTypD = "Applicant"
   *
   * @param appNode
   * @return
   */
  public static void defaultAuthorizedUserName(HashtableX auFields)
  {
    String newName = null;

    String str = (String)auFields.get("auLName");

    if (str != null)
    {
       newName = str.trim() + ',';
    }

    str = (String)auFields.get("auFName");
    if (str != null)
    {
       newName += str.trim();
    }

    newName += ",";

    str = (String)auFields.get("auMInit");
    if (str != null)
    {
       newName += ' ' + str.trim();
    }

    if (newName != null)
    {
      auFields.put("auName", newName);
    }

  }


  // This method assigns a loan number if automatic loan number is
  // chosen and the application does not already have a loan number
  // assigned.  If an error occurs, the String that is returned will
  // have the error message, otherwise it will be null (indicating
  // success).
  //
  public static String assignLoanNum(SystemDataObject sdo)
  {
    DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);
    if (appNode == null)
    {
      return "Application node not found in SDO.";
    }

    String appID = (String)appNode.getFieldData("", "anAppId");

    if (appID == null)
    {
      return "Application ID not found.";
    }


    String prodID = null;

    if (isConsumerApplication(appNode))
    {
      prodID = (String)appNode.getFieldData("", CSFieldNames.FN_PRODUCT_ID);
    }
    else
    {
      prodID = (String)appNode.getFieldData("", CSFieldNames.FN_SBPRODUCT_ID);
    }

    if (prodID == null)
    {
      return "Product ID not found in application data.";
    }

    String appProdTypeD = null;
    if (isConsumerApplication(appNode))
    {
      Product product = CSDataCache.getProductManager().getProduct(prodID);
      if (product != null)
      {
        appProdTypeD = product.getAppProductTypeD();
      }
    }
    else if (isMortgageApplication(appNode))
    {
      MtgProduct product = CSDataCache.getMtgProductManager().getProduct(prodID);
      if (product != null)
      {
        appProdTypeD = product.getAppProductTypeD();
      }
    }
    else
    {
      SBProduct product = CSDataCache.getSBProductManager().getProduct(prodID);
      if (product != null)
      {
        appProdTypeD = product.getAppProductTypeD();
      }
    }


    if (appProdTypeD == null)
    {
      return "Unable to load product " + prodID + ".";
    }

    String loanNumR = (String)appNode.getFieldData("", "anLoanNumR");

    if (loanNumR != null && loanNumR.equals("0"))
    {
      String loanNumber = (String)appNode.getFieldData("", "anLoanNum");

      if (loanNumber == null)
      {
        try
        {
          loanNumber = DBUtils.getNextLoanNumber(appID, appProdTypeD);
        }
        catch (SQLException e)
        {
          return "A database error occured while obtaining the new loan number: " + e;
        }

        if (loanNumber == null)
        {
          return "Unable to assign a loan number to this application.";
        }

        appNode.setFieldData("System", "anLoanNum", loanNumber);
      }
    }

    return null;
  }


} // End Class CSUtil **********************************************************
