package com.xnai.xtm.metasage;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import java.util.List;
import java.util.ArrayList;

import java.text.SimpleDateFormat;

import org.jdom.CDATA;
import org.jdom.Element;
import org.jdom.Document;
import org.jdom.output.XMLOutputter;


import java.util.Set;
import java.util.Map;
import java.util.List;
import java.util.Date;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Iterator;
import java.util.Calendar;
import java.util.ArrayList;

import com.xnai.net.xResponse;

import com.xnai.xtm.ErrorDocumentFactory;

import com.xnai.mulder.util.VectorX;

import com.xnai.mulder.util.S1Log;
import com.xnai.mulder.util.DataFile;
import com.xnai.mulder.util.HashtableX;
import com.xnai.mulder.util.ClientUtils;
import com.xnai.mulder.util.StringSupport;
import com.xnai.mulder.util.Configuration;
import com.xnai.credisphere.util.XSellUtils;

import com.xnai.mulder.systemCore.FileManager;

import com.xnai.mulder.systemObject.DataNode;
import com.xnai.mulder.systemObject.SystemDataObject;

import com.xnai.credisphere.db.DBQueries;

import com.xnai.credisphere.util.SDOUtils;
import com.xnai.credisphere.util.NodeUtils;
import com.xnai.credisphere.util.CSFieldNames;
import com.xnai.credisphere.util.CSFieldValues;
import com.xnai.credisphere.deposits.DepUtils;

import com.xnai.credisphere.calcs.AppCalcs;

import com.xnai.credisphere.appImport.AppImportUtils;
import com.xnai.credisphere.collateralEditor.Collateral;
import com.xnai.credisphere.dataCache.CSDataCache;
import com.xnai.credisphere.db.DBAccess;
import com.xnai.credisphere.db.DBLogger;
import com.xnai.credisphere.depProduct.DepProduct;
import com.xnai.credisphere.deposits.DepUtils;
import com.xnai.credisphere.productEditor.Product;
import com.xnai.credisphere.util.CSStatusCodes;

import com.xnai.credisphere.util.DataCollection;

import java.sql.SQLException;
import com.xnai.mulder.visual.TableTransaction;
import com.xnai.credisphere.util.DecisionUtils;
import com.xnai.credisphere.util.XSellData;
import com.xnai.mulder.systemCore.AdminGUIManager;
import com.xnai.mulder.util.StringChanger;
import com.xnai.mulder.visual.TableRecord;
import com.xnai.mulder.util.GeneralToolkit;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import java.util.Enumeration;
import java.util.HashMap;


public class FundingApplication extends S1Log
{
  //private static DataFile LOG_FILE = null;
  //private Map DATA_SETS = null;
  //private static HashtableX WFE_KEY_NAMES = null;
  //private Configuration cfgForXML = null;

  //private static GeneralToolkit general = new GeneralToolkit();
  private static String  CFG_FILE = "config" + File.separator + "xml2ms.ini";
  private static String LOG_API_DIR = FileManager.getLogPath() + File.separator + "logAPI_XML";
  private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
  private static boolean LOG_REQ_AND_RESP = true;
  private static Configuration cfg = null;
  private static String DATA_ENTRY_USER = null;
  private static String TIME_STAMP = null;

  static
  {
    try
    {
      initialize();
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
  
    public xResponse execute(VectorX param)
    {
      //time stamp for logging
      TIME_STAMP = sdf.format(Calendar.getInstance().getTime());
      Document respDoc = null;
      Document reqDoc = (Document) param.get(1);
      if (reqDoc != null)
      {
        String appId = null;

        try
        {
          Element reqRoot = reqDoc.getRootElement();
          appId = reqRoot.getChildText("AppId");

          if (LOG_REQ_AND_RESP)
          {
            logRequestOrRespoonse(reqDoc, "Incoming_Request", "Request", TIME_STAMP, LOG_API_DIR);
          }
          
          if (appId != null && appId.trim().length() > 0)
          {
            respDoc = getResponseDoc(appId, reqRoot);
          }
          else
          {
            throw new Exception("appId is NULL.");
          }
        }
        catch (Exception e)
        {
          e.printStackTrace();
          respDoc = ErrorDocumentFactory.getInvalidDataDoc("An error occurred while processing the Funding Application request. Error: " + e.getMessage());
        }
      }
      else
      {
        // invalid request document
        respDoc = ErrorDocumentFactory.getInvalidDataDoc("Invalid Funding Application.");
      }

      try
      {
        if (LOG_REQ_AND_RESP)
        {
          logRequestOrRespoonse(respDoc, "Outgoing_Response", "Response", TIME_STAMP, LOG_API_DIR);
        }
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }

      xResponse res = new xResponse();
      res.param.add(respDoc);
      return res;
    }
    
  
    protected Document getResponseDoc(String appId, Element reqRoot)
    throws Exception
    {        
      Element successElement = new Element("Success");
      SystemDataObject sdo = null;
      
      String fundingType = null;
      String fundingSource = null;
      Element fundingAmountEle = null;
      List fundingAmounts = null;
      Element fundingProdKeysEle = null;
      List fundingProdKeys = null;
      String fundingSourceType = null;
      String fundingAmountTtl = null;
      String fundingDate = null;
      String fundingTransId = null;
        
      try
      {
        if (reqRoot != null)
        {
            fundingType = reqRoot.getChildText("FundingType");
            fundingSource = reqRoot.getChildText("FundingSource");
            fundingAmountEle = reqRoot.getChild("FundingAmounts");
            fundingAmounts = fundingAmountEle.getChildren("AMT");
            fundingProdKeysEle = reqRoot.getChild("FundingProdKeys");
            fundingProdKeys = fundingProdKeysEle.getChildren("prodKey");
            fundingSourceType = reqRoot.getChildText("FundingSourceType");
            fundingAmountTtl = reqRoot.getChildText("FundingAmount");
            fundingDate = reqRoot.getChildText("OrderTime");
            fundingTransId = reqRoot.getChildText("TransactionId");
            
            DataNode appNode = null;
            String daProdTypeD = null; 
    
            //get the sdo
            sdo = SDOUtils.getSDO(appId);
            if(sdo != null) 
            {
                appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);
                if (appNode != null)
                {
                    List<DataNode> depAccounts = appNode.getEffectiveReferences(NodeUtils.DEP_ACCOUNT_DN_TYPE);

                    DataNode fundingNode = null;
                    String daProdKeyStr = "!wfePrdKey";
                    String daProdKey = null;
                    boolean isOverdraftProduct = false;
                        
                    
                    
                    for(DataNode depAccountNode : depAccounts)
                    {
                        daProdTypeD = (String) depAccountNode.getFieldData(DATA_ENTRY_USER, CSFieldNames.FN_DEP_PROD_ID);
                        daProdKey = (String) depAccountNode.getSystemData(daProdKeyStr);
                        isOverdraftProduct = DepUtils.isOverdraftProduct(daProdTypeD);

                        Element prodKeyNode = null;
                        Element amtNode = null;
                        String prodKeyText = null;
                        String amtText = null;
                        
                        
                        //AdminGUIManager.displayE("fudingProdKeys.size: " + fundingProdKeys.size());
                        
                        for (int i=0; i<fundingProdKeys.size(); i++) 
                        {
                            prodKeyNode = (Element) fundingProdKeys.get(i);
                            prodKeyText = prodKeyNode.getText();   
                            if (daProdKey.equals(prodKeyText)) 
                            {                                
                                // get the right amount from XML
                                amtNode = (Element) fundingAmounts.get(i);
                                amtText = amtNode.getText();                                
                                fundingNode = sdo.createDataNode(DATA_ENTRY_USER, NodeUtils.DEP_FUNDING_DN_TYPE);
                                if (isOverdraftProduct)
                                {
                                    fundingNode.setFieldData(DATA_ENTRY_USER, CSFieldNames.FN_DEP_FUNDING_TYPE, CSFieldValues.FV_DEP_FUND_TYPE_OVERDRAFT);
                                }
                                else 
                                {
                                    fundingNode.setFieldData(DATA_ENTRY_USER, CSFieldNames.FN_DEP_FUNDING_TYPE, CSFieldValues.FV_DEP_FUND_TYPE_ONLINE);
                                    fundingNode.setFieldData(DATA_ENTRY_USER, CSFieldNames.FN_DEP_FUNDING_SOURCE, fundingSource);
                                    fundingNode.setFieldData(DATA_ENTRY_USER, CSFieldNames.FN_DEP_FUNDING_DATE, fundingDate);
                                    fundingNode.setFieldData(DATA_ENTRY_USER, CSFieldNames.FN_DEP_FUNDING_TRANSID, fundingTransId);
                                    fundingNode.setFieldData(DATA_ENTRY_USER, CSFieldNames.FN_DEP_FUNDING_TRANSTYPE, fundingSourceType);
                                }
                                fundingNode.setFieldData(DATA_ENTRY_USER, CSFieldNames.FN_DEP_FUNDING_AMT, amtText);
                                depAccountNode.addReference(fundingNode);
                                
                            }
                        }
                        depAccountNode.setSystemData(CSFieldNames.FN_SYS_DEP_ISFUNDED_FLAG, "true");
                        //sdo.save();
                        SDOUtils.saveSDO(DATA_ENTRY_USER, sdo, CSStatusCodes.SDO_UNLOCK);
                        successElement.setText(CSFieldValues.TRUE_STRING);
                        
                        
                    }
                }
                else {
                    throw new Exception("getResponseDoc : appNode is null");
                }
            }
            else {
                throw new Exception("sdo is null for application id: " + appId);
            }
        }
        else {
            successElement.setText(CSFieldValues.FALSE_STRING);
        }
      }
      catch(Exception e)
      {
          e.printStackTrace();
          throw new Exception("FundingApplication.getResponseDoc: Error! " + e.toString());
      }  
          
        Element root = new Element("XNAI");
        root.setAttribute("meta", "funding.application.response.1.0");
        root.addContent(successElement);
        Document doc = new Document(root);
        
        toFile("funding.txt",CSFieldValues.TRUE_STRING);
        
      return doc;
    }
  

  public void logRequestOrRespoonse(Document reqOrRespDoc, String dirType, String transType, String TIME_STAMP, String LOG_API_DIR)
  {
    try
    {
      FileWriter fw = null;
      File impLogPath = null;
      if( LOG_API_DIR.endsWith("\\") )
      {
        impLogPath = new File(LOG_API_DIR + "logFundingApplication_XML" + File.separator + dirType);
        if (!impLogPath.exists())
        {
          impLogPath.mkdirs();
        }

        fw = new FileWriter(LOG_API_DIR + "logFundingApplication_XML" + File.separator + dirType + File.separator + transType + "_" + TIME_STAMP + ".xml");
      }
      else
      {
        impLogPath = new File(LOG_API_DIR + File.separator + "logFundingApplication_XML" + File.separator + dirType);
        if (!impLogPath.exists())
        {
          impLogPath.mkdirs();
        }

        fw = new FileWriter(LOG_API_DIR + File.separator + "logFundingApplication_XML" + File.separator + dirType + File.separator + transType + "_" + TIME_STAMP + ".xml");
      }

      XMLOutputter outputter = new XMLOutputter("    ", true);
      outputter.output(reqOrRespDoc, fw);

      fw.close();
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
  
  private static void initialize()
  {
    String tempStr = null;
    cfg = new Configuration();
    cfg.load(CFG_FILE);

    DATA_ENTRY_USER = cfg.getSectionProperty("Settings", "username").trim();
    if (DATA_ENTRY_USER == null)
    {
      DATA_ENTRY_USER = "xml2ms";
    }
    
    tempStr = cfg.getSectionProperty("Settings", "log");
    if (tempStr != null && tempStr.trim().equals(CSFieldValues.FALSE_STRING))
    {
      LOG_REQ_AND_RESP = false;
    }
    else if (tempStr != null && tempStr.trim().equals(CSFieldValues.TRUE_STRING))
    {
      LOG_REQ_AND_RESP = true;
    }
    
    tempStr = cfg.getSectionProperty("Settings", "logAPIDirPath");
    if (tempStr != null && tempStr.trim().length() > 0)
    {
      LOG_API_DIR = tempStr;
    }
  }

  // toFile
  // for debugging
  private void toFile(String fileName, String data)
  {
    FileWriter fw = null;

    try
    {
      fw = new FileWriter(fileName);
      fw.write(data);
    }
    catch (IOException e)
    {
      //e.printStackTrace();
    }
    finally
    {
      try
      {
        fw.close();
      }
      catch (Exception e)
      {
      }
    }
  }
}
