/**
 * Title:        BookingMonitor
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:      X/Net Associates
 * @author Len Doerich
 * @version 1.0
 */

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.xnai.credisphere.SBProductEditor.SBProduct;
import com.xnai.credisphere.dataCache.CSDataCache;
import com.xnai.credisphere.db.DBAccess;
import com.xnai.credisphere.db.DBLogger;
import com.xnai.credisphere.db.DBUtils;
import com.xnai.credisphere.deposits.DepUtils;
import com.xnai.credisphere.mtgProduct.MtgProduct;
import com.xnai.credisphere.productEditor.GenericProduct;
import com.xnai.credisphere.productEditor.Product;
import com.xnai.credisphere.util.AppNode;
import com.xnai.credisphere.util.CSFieldNames;
import com.xnai.credisphere.util.CSFieldValues;
import com.xnai.credisphere.util.CSStatusCodes;
import com.xnai.credisphere.util.CSUtil;
import com.xnai.credisphere.util.NodeUtils;
import com.xnai.credisphere.util.SDOUtils;
import com.xnai.mulder.systemCore.AdminGUIManager;
import com.xnai.mulder.systemCore.SystemProperties;
import com.xnai.mulder.systemObject.DataNode;
import com.xnai.mulder.systemObject.SDOConstants;
import com.xnai.mulder.systemObject.SystemDataObject;
import com.xnai.mulder.user.User;
import com.xnai.mulder.util.DateFormatter;
import com.xnai.mulder.util.VectorX;
import com.xnai.net.XCSRequest;
import com.xnai.net.XCSResponse;
import com.xnai.net.xResponse;


public abstract class BookingMonitor extends XMMCartridge
{
  private static long FIVE_MINUTES_MS = 5 * 60 * 1000;

  // error logs
  private static boolean ERROR_LOG      = false;
  private static boolean DOS_ERROR_LOG  = false;
  private static boolean GUI_ERROR_LOG  = false;

  // Booking rule codes.
  protected static final int AUTO   = 0;
  protected static final int MANUAL = 1;
  protected static final int NONE   = 2;

  protected String  APPROVE_CODE       = null;
  protected String  DECLINE_CODE       = null;
  protected boolean INCLUDE_FRAUD      = false;
  protected boolean INCLUDE_DUPLICATE  = false;
  protected boolean DEPEND_APPR        = false;
  protected boolean LOG                = false;
  protected String  LOG_DIR            = null;
  protected boolean MUST_BE_DISBURSED  = false;
  protected boolean ASSIGN_LOAN_NUM    = false;
  protected boolean LOAN_NUM_DECLINE   = false;
  protected boolean ALLOW_PREAPPROVE   = false;
  protected boolean EXCLUDE_MTG_PREAPV = false;
  protected boolean CHECK_CLOSING_REQS = false;
  protected boolean CHECK_CONTRACT_TERMS = false;
  protected List    PRE_REQS           = null;
  protected boolean USE_DECLINE_STATUS = false;
  protected boolean MUST_BE_FUNDED = false;



  public BookingMonitor()
  {
    super();

    getOpCodes().add("Book");
    getOpCodes().add("Query");

    setName("BookingMonitor");
  }


  public Object doOpCode(String opcode, Object obj)
  {
    VectorX inVec = (VectorX)obj;

    if (opcode.equals("Book"))
    {
      return opCodeBook(inVec);
    }

    if (opcode.equals("Query"))
    {
      return opCodeQuery(inVec);
    }

    return super.doOpCode(opcode, obj);
  }


  protected xResponse opCodeQuery(VectorX inVec)
  {
    xResponse res = new xResponse();

    String sql = CHECK_CONTRACT_TERMS ? createQuery(true, false) + " UNION " +
                                        createQuery(false, true) :
                                        createQuery(false, false);

    res.param.add(sql);
    return res;
  }


  // the generic method below is not used. an customer specific opCodeBook method has been
  // placed in the MiserBookingMonitor class that is an extension of the BookingMonitor class
  //
  protected xResponse opCodeBook(VectorX inVec)
  {
    xResponse res = new xResponse();

    String username = null;
    VectorX appIDList = null;

    try
    {
      username = (String)inVec.get(0);
      Object obj = inVec.get(1);
      if (obj instanceof String)
      {
        appIDList = new VectorX();
        appIDList.add((String)obj);
      }
      else
      {
        appIDList = (VectorX)obj;
      }
    }
    catch (Exception e)
    {
      res.errCode = 1;
      res.param.add("Error with incoming data.");
      return res;
    }

    String appID;
    StringBuffer msgToUser = new StringBuffer();
    SystemDataObject sdo;
    DataNode appNode;
    String decision = null;
    List log = new ArrayList();

    for (int i = 0, c = appIDList.size(); i < c; ++i)
    {
      appID = (String)appIDList.get(i);

      msgToUser.append(appID).append(": ");

      try
      {
        sdo = SDOUtils.getSDO(appID);
      }
      catch (SQLException e)
      {
        msgToUser.append("Unable to retrieve application from the database: " + e + "\n");
        continue;
      }

      if (sdo == null)
      {
        msgToUser.append("Application not found in the database.\n");
        continue;
      }

      String sdoStatus = SDOUtils.getSDOStatus(sdo);

      if (sdoStatus != null &&
           (!sdoStatus.equals(CSStatusCodes.SC_RDY_TO_BOOK) &&
            !sdoStatus.equals(CSStatusCodes.SC_BK_FAILED) &&
            !sdoStatus.equals(CSStatusCodes.SC_RDY_TO_BOOK_DECLINE) &&
            !sdoStatus.equals(CSStatusCodes.SC_BK_FAILED_DECLINE)))
      {
        msgToUser.append("This application is not in the proper status for booking.\n");
        continue;
      }

      if (! isProductQualified(sdo, log))
      {
        msgToUser.append("Product is not qualified for booking.\n");
        continue;
      }

      boolean lockedOk = false;

      try
      {
        // SDOUtils.lockSDO(getName(), sdo);
        //
        lockedOk = sdo.lock( getName() );
      }
      catch (SQLException e)
      {
        msgToUser.append(e.getMessage()).append("\n");
        continue;
      }

      if (! lockedOk)
      {
        String lockedBy = null;

        try
        {
          lockedBy = sdo.lockedBy();
        }
        catch (SQLException e)
        {
          lockedBy = "Unknown";
        }

        msgToUser.append("Application is currently locked by '" + lockedBy + "'\n");
        continue;
      }

      log.add("Processing " + appID);

      StringBuffer errorMsg = new StringBuffer();
      boolean ok = processApplication(username, sdo, log, errorMsg);
      String msg = null;

      appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);
      if (appNode != null)
      {
        decision = (String)appNode.getSystemData("!dcsn");
      }

      if (decision == null) decision = CSFieldValues.EMPTY_STRING;

      if (ok)
      {
        if (errorMsg.length() > 0)
        {
          // Application booked, but had warnings.
          //
          msg = "Export was successful with warnings:\n" + errorMsg;
        }
        else
        {
          msg = "Export was successful.";
        }

        // Change status to something other than booking failed.
        //
        updateAppStatusAndSave(sdo, log, null,
                               USE_DECLINE_STATUS && !decision.equals("a") ?
                               CSStatusCodes.SC_BOOKING_DECLINE :
                               CSStatusCodes.SC_BOOKING, true);
      }
      else
      {
        StringBuffer sb = new StringBuffer();
        sb.append("Export was unsuccessful: ");

        if (errorMsg.length() > 0)
        {
          sb.append(errorMsg.toString());
          updateAppStatusAndSave(sdo, log, errorMsg,
                                 USE_DECLINE_STATUS && !decision.equals("a") ?
                                 CSStatusCodes.SC_BK_FAILED_DECLINE :
                                 CSStatusCodes.SC_BK_FAILED,
                                 true);
        }
        else
        {
          sb.append("This application did not meet the criteria set for booking.");
          updateAppStatusAndSave(sdo, log, null, null, false);
        }

        msg = sb.toString();
      }

      msgToUser.append(msg);
      msgToUser.append("\n");
    }

    writeLogFile(log);

    res.errCode = 200;
    res.param.add(msgToUser.toString());
    return res;
  }


  protected String getProductID(SystemDataObject sdo)
  {
    String prodID = null;

    DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);

    if (appNode != null)
    {
      prodID = (String)appNode.getFieldData("", CSFieldNames.FN_PRODUCT_ID);
      if (prodID == null)
      {
        prodID = (String)appNode.getFieldData("", CSFieldNames.FN_SBPRODUCT_ID);
      }
    }

    return prodID;
  }


  // This method attempts to find both a primary applicant and a co-applicant.
  // The primary applicant should always be found, but the co-applicant may
  // not exist.
  //
  protected DataNode[] getApplicantNodes(DataNode appNode)
  {
    List list = appNode.getReferences(NodeUtils.BWR_DN_TYPE);
    DataNode primary = null;
    DataNode coapp = null;

    if (list != null)
    {
      DataNode node = null;
      String bwrType = null;

      for (int i = 0, c = list.size(); i < c; ++i)
      {
        node = (DataNode)list.get(i);

        if (! node.isDeleted())
        {
          bwrType = (String)node.getFieldData("", "atBwrTypD");

          if (bwrType.equals("Applicant"))
          {

            primary = node;
          }
          else if (bwrType.equals("Co-applicant") ||
                   bwrType.equals("Co-signer"))
          {
            coapp = node;
          }

          if (primary != null && coapp != null) break;
        }
      }
    }

    return new DataNode[]{primary, coapp};
  }


  protected void writeExportFile(String filename, List lines) throws IOException
  {
    FileWriter fw = null;

    try
    {
      fw = new FileWriter(filename, false);

      String line = null;

      for (int i = 0, c = lines.size(); i < c; ++i)
      {
        line = (String)lines.get(i);
        fw.write(line + "\r\n");
      }
    }
    finally
    {
      if (fw != null)
      {
        try
        {
          fw.close();
        }
        catch (Exception e)
        {
        }
      }
    }
  }


  protected String getOfficerNumber(String username)
  {
    String officerNumber = null;

    User user = User.getUser2(username);

    if (user != null)
    {
      officerNumber = user.getOfficerNumber();
    }

    return officerNumber;
  }


  public void doWork()
  {
    List log = new ArrayList();

    List appList = null;
    List modifTimeList = null;

    try
    {
      List[] queryData = doMonitorAppListQuery();
      appList = (List)queryData[0];
      modifTimeList = (List)queryData[1];
    }
    catch (SQLException e)
    {
      log.add("App list query failed.  Check DBLog.");
    }

    int numAppsNeedingDisb = 0;

    if (appList != null && !appList.isEmpty())
    {
      boolean ok;
      log.add("Apps to process: " + appList);

      String appID = null;
      Long lastModif = null;
      SystemDataObject sdo = null;
      StringBuffer errorMsg = null;

      for (int i = 0, c = appList.size(); i < c; ++i)
      {
        if (!super.checkIn())
        {
          log.add("Check-in Failed.");
          break;
        }

        appID = (String)appList.get(i);
        lastModif = (Long)modifTimeList.get(i);

        ok = false;

        log.add("");
        log.add("Processing " + appID);

        try
        {
          sdo = SDOUtils.getSDO(appID);
        }
        catch (SQLException e)
        {
          String msg = "Unable to retrieve application from the database: " + e;
          log.add(msg);
        }

        if (sdo != null)
        {
          // Check to see if the application is "live" and was last modified
          // in the last 5 minutes.  If so, don't book it now, as it may be
          // finishing up a milestone.
          //
          if (isLiveAndRecentlyModified(sdo, lastModif))
          {
            log.add("Application is live and has recently been modified.");
            log.add("The app may be finishing a milestone and will not be processed.");
            continue;
          }

          errorMsg = new StringBuffer();
          String decision = validateDecisionAndProduct(sdo, log, errorMsg);

		  DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);

          if (CSUtil.isDepositApplication(appNode) && MUST_BE_FUNDED && 
              ! DepUtils.isApplicationFunded(appNode))
          {
      		  log.add("Application " + appID + " is not yet funded.");
            continue;
          }

          // Check to see if the application has been disbursed before
          // booking it (if the customer has it configured this way).
          //
		  if (! CSUtil.isDepositApplication(appNode))
          {
            if (isProductDisburseable(appNode) &&
                ! CSUtil.isFullyDisbursed(appNode) &&
                decision != null && decision.equals("a"))
            {
              log.add("Loan is not fully disbursed.");
              ++numAppsNeedingDisb;
              continue;
            }
          }

          boolean locked = false;

          try
          {
            // SDOUtils.lockSDO(getName(), sdo);
            // locked = true;
            //
            locked = sdo.lock( getName() );
          }
          catch (SQLException e)
          {
            log.add(e.getMessage());
          }

          if (locked)
          {
            boolean prereqsOK = true;
            errorMsg = new StringBuffer();

            String statusToSet = null;

            if (decision != null)
            {
              // Assign Loan # now, if automatic.
              // Commented out 3/3/2003 LED.
              // Commented back in 6/11/2003 LED.
              //
              String assignError = null;

              if (ASSIGN_LOAN_NUM)
              {
                if (decision.equals("a") ||
                   ( (decision.equals("d") || decision.equals("f") ||
                      decision.equals("p")) && LOAN_NUM_DECLINE))
                {
                  if (CSUtil.isDepositApplication(appNode))
                  {
                    assignError = DepUtils.assignLoanNum(sdo);
                  }
                  else {
                    assignError = CSUtil.assignLoanNum(sdo);
                  }
                }
              }

              if (assignError == null)
              {
                // Do the pre-requisites if there are any on approvals only.
                //
                prereqsOK = !decision.equals("a") ||
                            doPrequisites(sdo, log);
                if (prereqsOK)
                {
                  int bookingRule = determineBookingRule(decision);

                  if (bookingRule == AUTO)
                  {
                    // Send to Summit system.
                    //
                    ok = processApplication("", sdo, log, errorMsg);
                  }
                  else if (bookingRule == MANUAL)
                  {
                    // Send to status "ready to book" (8015)
                    //
                    if (USE_DECLINE_STATUS && !decision.equals("a"))
                    {
                      statusToSet = CSStatusCodes.SC_RDY_TO_BOOK_DECLINE;
                    }
                    else
                    {
                      statusToSet = CSStatusCodes.SC_RDY_TO_BOOK;
                    }
                  }
                  else
                  {
                    // Mark application as skipped booking.
                    // Don't need to do anything... if errorMsg.length() == 0
                    // and statusToSet is null, it will do the right thing
                    // in updateAppStatusAndSave()
                    //
                  }
                }
              }
              else
              {
                errorMsg.append("Error assigning loan number: ").append(assignError);
                log.add("Error assigning loan number: " + assignError);
              }
            }

            if (prereqsOK)
            {
              if (ok)
              {
                updateAppStatusAndSave(sdo, log, null,
                                       USE_DECLINE_STATUS &&
                                       !decision.equals("a") ?
                                       CSStatusCodes.SC_BOOKING_DECLINE :
                                       CSStatusCodes.SC_BOOKING,
                                       true);
              }
              else
              {
                if (errorMsg.length() == 0)
                {
                  updateAppStatusAndSave(sdo, log, null, statusToSet, true);
                }
                else
                {
                  updateAppStatusAndSave(sdo, log, errorMsg,
                                         USE_DECLINE_STATUS &&
                                         !"a".equals(decision) ?
                                         CSStatusCodes.SC_BK_FAILED_DECLINE :
                                         CSStatusCodes.SC_BK_FAILED, true);
                }
              }
            }
          }
        }
        else
        {
          String msg = "Application not found in the database.";
          log.add(msg);
        }
      }
    }

    // Don't write a log file out if we did not book anything because all the
    // apps haven't been disbursed yet.  We don't want to fill up the folder
    // with a bunch of logs that say nothing could be booked.
    //
    if (appList != null && (appList.size() == numAppsNeedingDisb))
    {
      log.clear();
    }

    writeLogFile(log);
  }


  protected boolean isProductDisburseable(DataNode appNode)
  {
    try
    {
      GenericProduct genProd = AppNode.getInstance().getProductFromAppNode(appNode);

      VectorX disbTypes = genProd.getPrdDsbM();

      return (disbTypes != null && !disbTypes.isEmpty() &&
         ((disbTypes.size() == 1 && !((String)disbTypes.firstElement()).equals(CSFieldValues.FV_DSB_TYPE_NONE) ||
          disbTypes.size() > 1)));
    }
    catch (Exception e)
    {
      return true;
    }
  }


  protected boolean isProductQualified(SystemDataObject sdo, List log)
  {
    String prodID = getProductID(sdo);
    List products = getProductListing();

    boolean qualified = prodID != null &&
        (products != null &&
         (products.contains("ALL") || products.contains(prodID)));

    if (!qualified)
    {
      log.add("Product " + prodID + " not qualified for Booking.");
    }

    return qualified;
  }


  protected boolean isLiveAndRecentlyModified(SystemDataObject sdo, Long lastModified)
  {
    boolean liveAndRecentMod = false;

    String liveFlag = (String)sdo.getSystemData(SDOConstants.SDO_STAT);
    if (liveFlag != null && liveFlag.equals(SystemDataObject.STATUS_LIVE))
    {
      long timeSinceMod = System.currentTimeMillis() - lastModified.longValue();

      if (timeSinceMod < FIVE_MINUTES_MS)
      {
        liveAndRecentMod = true;
      }
    }

    return liveAndRecentMod;
  }


  protected String validateDecisionAndProduct(SystemDataObject sdo, List log,
                                              StringBuffer errorMsg)
  {
    String dcsn = null;

    String productID = getProductID(sdo);
    if (productID == null)
    {
      log.add("Product ID not found.");
      errorMsg.append("Product ID not found.");
    }
    else
    {
      DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);
      if (appNode == null)
      {
        log.add("Application node not found in SDO.");
        errorMsg.append("Application node not found in SDO.");
      }
      else
      {
        dcsn = (String)appNode.getSystemData("!dcsn");

        if (dcsn == null)
        {
          log.add("Decision field not found in application.");
          errorMsg.append("Decision field not found in application.");
        }
      }
    }

    return dcsn;
  }


  protected int determineBookingRule(String decision)
  {
    String code = null;

    if (decision.equals("a"))
    {
      code = APPROVE_CODE;
    }
    else if (decision.equals("d") || decision.equals("f") || decision.equals("p"))
    {
      code = DECLINE_CODE;
    }
    else
    {
      code = "none";
    }

    code = code.toLowerCase();

    int iCode;

    if (code.equals("auto"))
    {
      iCode = AUTO;
    }
    else if (code.equals("manual"))
    {
      iCode = MANUAL;
    }
    else
    {
      iCode = NONE;
    }

    return iCode;
  }


  protected List[] doMonitorAppListQuery() throws SQLException
  {
    String sql = CHECK_CONTRACT_TERMS ? createQuery(true, false) + " UNION " +
                                        createQuery(false, true) :
                                        createQuery(false, false);


    Statement stmt = null;

    List appList = new ArrayList();
    List modifTimes = new ArrayList();

    if (sql.length() > 10)
    {
      // eliminate none/none query or query with just " UNION "
      try
      {
        Connection con = DBAccess.getConnection();
        stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery(sql);

        Timestamp ts;

        while (rs.next())
        {
          ts = rs.getTimestamp("dtLastModif");

          appList.add(rs.getString("nAppId"));
          modifTimes.add(Long.valueOf(ts.getTime()));
        }
      }
      catch (SQLException e)
      {
        DBLogger.log("Executing " + sql + ": " + e);
        throw e;
      }
      finally
      {
        DBAccess.closeConnection(stmt);
      }
    }

    return new List[]{ appList, modifTimes };
  }


  protected void writeLogFile(List log)
  {
    if (! LOG) return;
    if (log.isEmpty()) return;

    FileWriter fw = null;

    String logFilename = DateFormatter.logFileFmt(new java.util.Date()) + ".log";

    try
    {
      fw = new FileWriter(LOG_DIR + File.separator + logFilename, false);

      Iterator it = log.iterator();

      while (it.hasNext())
      {
        fw.write((String)it.next() + "\r\n");
      }
    }
    catch (IOException e)
    {
    }
    finally
    {
      if (fw != null)
      {
        try
        {
          fw.close();
        }
        catch (IOException e)
        {
        }
      }
    }
  }

  protected void updateAppStatusAndSave(SystemDataObject sdo, List log,
                                        StringBuffer errorMsg, String status,
                                        boolean productQualified)
  {
    updateAppStatusAndSave(sdo,log,errorMsg,status,productQualified,null);
  }



  protected void updateAppStatusAndSave(SystemDataObject sdo, List log,
                                        StringBuffer errorMsg, String status,
                                        boolean productQualified,
                                        String username)
  {
    debugMsg("START: updateAppStatusAndSave(...) status: "+status);
    DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);

    if (status != null)
    {
      debugMsg("1/6 if (status != null): status: "+status);
      appNode.setSystemData(CSStatusCodes.SDO_STATUS, status);
    }

    if (errorMsg != null)
    {
      debugMsg("2/6 if (errorMsg != null): errorMsg: "+errorMsg);

      //
      //appNode.setSystemData("!booked", "f");
      //

      appNode.setSystemData("!bkErr", errorMsg.toString());
    }
    else
    {
      debugMsg("3/6 if (status != null && !status.equals(CSStatusCodes.SC_RDY_TO_BOOK)): status: "+status);
      debugMsg("4/6 else if (! productQualified): status: "+status);

      if (status != null &&
          !status.equals(CSStatusCodes.SC_RDY_TO_BOOK) &&
          !status.equals(CSStatusCodes.SC_RDY_TO_BOOK_DECLINE))
      {
        appNode.removeFieldData("", "!bkErr");
        appNode.setSystemData("!booked", "c");
        if (username != null) appNode.setSystemData("!bkUser", username);
      }
      else if (! productQualified)
      {
        appNode.setSystemData("!booked", "s");
      }
    }

    try
    {
      debugMsg("5/6 save sdo and change status: status: "+status);
      DBUtils.updateAppStatus(username == null ? getName() : username, sdo);
      SDOUtils.saveSDO(getName(), sdo, CSStatusCodes.SDO_UNLOCK);

      if (status != null)
      {
        log.add("Status of application changed to " + status);
      }
      else
      {
        log.add("Skipped Booking.  Status unchanged.");
      }

      debugMsg("6/6 save completed");
    }
    catch (SQLException e)
    {
      log.add("Unable to change status of application: " + e);
    }

    debugMsg("END: updateAppStatusAndSave(...) status: "+status);
  }

  private String createQuery(boolean excludeIndirect, boolean indirectOnly)
  {
    boolean needApproval = !(APPROVE_CODE.equals("none"));
    boolean needDecline = !(DECLINE_CODE.equals("none"));

    StringBuffer sql = new StringBuffer();

    if (needApproval || needDecline)
    {
      sql.append("SELECT xntQuickSearch.nAppId, xntSDO.dtLastModif ");
      sql.append("FROM xntSDO, xntQuickSearch ");

      if (indirectOnly)
      {
        sql.append("INNER JOIN xntContractTerms ON ");
        sql.append("xntQuickSearch.nAppId = xntContractTerms.nAppId ");
        sql.append("INNER JOIN xntProducts ON ");
        sql.append("xntQuickSearch.nProdId = xntProducts.nProdId AND ");
        sql.append("xntProducts.cProdTyp = 'IL' ");
      }

      if (excludeIndirect)
      {
        sql.append("INNER JOIN xntProducts ON ");
        sql.append("xntQuickSearch.nProdId = xntProducts.nProdId AND ");
        sql.append("xntProducts.cProdTyp != 'IL' ");
      }

      sql.append("WHERE ");

      if (ALLOW_PREAPPROVE)
      {
        // This flag is for PSECU... they want consumer pre-approvals to book, but not mortgage
        // pre-approvals.
        //
        if (EXCLUDE_MTG_PREAPV)
        {
          sql.append("(cAppType != 'm' OR ");
          sql.append("(cAppType = 'm' AND bPreApproved='false' OR bPreApproved IS NULL)) AND ");
        }
      }
      else
      {
        sql.append("(bPreApproved='false' OR bPreApproved IS NULL) AND ");
      }

      sql.append("(bReview='false' OR bReview IS NULL) AND ");
      sql.append("(bVerify='false' OR bVerify IS NULL) AND ");
      sql.append("(bFinReview IS NULL OR bFinReview='false') AND ");
      sql.append("((cBooked IS NULL AND ((cStatus >= '3000' AND cStatus < '8000') OR cStatus = '8005')) OR ");
      sql.append("cStatus = '" + CSStatusCodes.SC_REBOOK + "') AND ");

      sql.append("xntQuickSearch.nAppId = xntSDO.nAppId AND xntSDO.cSDOStatus = 0 AND ");

      if (needDecline && needApproval) sql.append("((");

      if (needApproval)
      {
        // approval clauses
        sql.append("cDecision = 'a' ");
        if (DEPEND_APPR) sql.append(" AND cAppraised IN ('c','s') ");
        sql.append(buildProductClause(true));

        if (indirectOnly) sql.append(" AND xntContractTerms.cTermsAccepted = 'true' ");

        if (CHECK_CLOSING_REQS)
        {
          sql.append(" AND NOT EXISTS (SELECT nAppId FROM xntApRequirements WHERE ");
          sql.append("cStatus = 'Pending' AND bEnforced = 't' AND cType = 'Closing' AND ");
          sql.append("xntQuickSearch.nAppId = xntApRequirements.nAppId) ");
        }
      }

      if (needDecline && needApproval) sql.append(") OR (");

      if (needDecline) sql.append(buildDeclineClause()).append(buildProductClause(false));

      if (needDecline && needApproval) sql.append("))");
    }

    return sql.toString();
  }


  private String buildProductClause(boolean isApprove)
  {
    StringBuffer clause = new StringBuffer();

    List PRODUCTS = isApprove ? getApproveProductListing() : getDeclineProductListing();
    if (PRODUCTS == null) PRODUCTS = new ArrayList();
    if (PRODUCTS.isEmpty()) PRODUCTS.add("-1");

    if (!PRODUCTS.contains("ALL"))
    {
      if (PRODUCTS.size() > 1)
      {
        clause.append(" AND xntQuickSearch.nProdId IN (");

        for (int i = 0, c = PRODUCTS.size(); i < c; ++i)
        {
          if (i != 0) clause.append(", ");
          clause.append((String)PRODUCTS.get(i));
        }

        clause.append(") ");
      }
      else
      {
        clause.append(" AND xntQuickSearch.nProdId = ").append((String)PRODUCTS.get(0));
      }
    }

    return clause.toString();
  }


  private String buildDeclineClause()
  {
    StringBuffer clause = new StringBuffer();

    if (INCLUDE_FRAUD || INCLUDE_DUPLICATE)
    {
      clause.append("cDecision IN ('d'");
      if (INCLUDE_FRAUD) clause.append(",'f'");
      if (INCLUDE_DUPLICATE) clause.append(",'p'");
      clause.append(") ");
    }
    else
    {
      clause.append("cDecision = 'd'");
    }

    return clause.toString();
  }


  private boolean doPrequisites(SystemDataObject sdo, List log)
  {
    boolean goodToGo = true;

    if (PRE_REQS != null)
    {
      String opcode;
      for (int i = 0, c = PRE_REQS.size(); i < c; ++i)
      {
        opcode = (String)PRE_REQS.get(i);

        XCSRequest req = new XCSRequest(opcode);
        req.param.add("admin");
        req.param.add(String.valueOf(sdo.getObjectID()));
        req.param.add(sdo);

        XCSResponse resp = contactSystem(req);

        log.add("Executed " + opcode + " - Response Code was " + resp.errCode);

        if (resp.errCode == 0)
        {
          // Just in case there was a message passed along, check the first
          // param slot.
          //
          if (! resp.param.isEmpty())
          {
            log.add("Message: " + (String)resp.param.get(0));
          }
        }
        else
        {
          goodToGo = false;

          if (! resp.param.isEmpty())
          {
            log.add("Pre-requisite failed for: " + opcode);
            log.addAll(resp.param);
          }

          break;
        }
      }
    }

    return goodToGo;
  }


  private void debugMsg(String str)
  {
    if( ERROR_LOG )
        {
        errLog("");errLog(str);errLog("");
        }

    if( DOS_ERROR_LOG )
        {
        System.out.println(str);
        }

    if( GUI_ERROR_LOG )
        {
         AdminGUIManager.displayE(str);
        }
  }

  protected void storeAccountTypes(VectorX acctTypes)
  {
    if (acctTypes != null)
    {
      super.storeGlobalDataMember(CSFieldNames.SYS_DATA_MEMBER_HOST_ACCT_TYPES, acctTypes);

      SystemProperties.getProperties().put(CSFieldNames.SYS_DATA_MEMBER_HOST_ACCT_TYPES, acctTypes);
    }
  }


  protected void storeAccountSubtypes(VectorX acctSubtypes)
  {
    if (acctSubtypes != null)
    {
      super.storeGlobalDataMember(CSFieldNames.SYS_DATA_MEMBER_HOST_SUB_ACCT_TYPES, acctSubtypes);

      SystemProperties.getProperties().put(CSFieldNames.SYS_DATA_MEMBER_HOST_SUB_ACCT_TYPES, acctSubtypes);
    }
  }


  protected abstract boolean processApplication(String username, SystemDataObject sdo,
                                                List log, StringBuffer errorMsg);

  protected List getDeclineProductListing()
  {
    return getProductListing();
  }

  protected List getApproveProductListing()
  {
    return getProductListing();
  }

  protected abstract List getProductListing();
}
