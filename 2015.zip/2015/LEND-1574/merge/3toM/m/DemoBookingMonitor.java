/**
 * Title:        DemoBookingMonitor
 * Description:
 * Copyright:    Copyright (c) 2012
 * Company:      ACI Worldwide
 * @author Len Doerich
 * @version 1.0
 */

import com.xnai.credisphere.appFilter.AppFilterParams;
import com.xnai.credisphere.db.DBUtils;
import com.xnai.credisphere.util.CSFieldNames;
import com.xnai.credisphere.util.CSFieldValues;
import com.xnai.credisphere.util.CSStatusCodes;
import com.xnai.credisphere.util.NodeUtils;
import com.xnai.credisphere.util.SDOUtils;

import java.util.List;
import java.io.File;

import com.xnai.mulder.systemCore.AdminGUIManager;
import com.xnai.mulder.systemCore.FileManager;
import com.xnai.mulder.systemCore.SystemHouse;
import com.xnai.mulder.systemObject.DataNode;
import com.xnai.mulder.systemObject.SystemDataObject;
import com.xnai.mulder.user.User;
import com.xnai.mulder.util.ClientUtils;
import com.xnai.mulder.util.Configuration;
import com.xnai.mulder.util.FormLoader;
import com.xnai.mulder.util.HashtableX;
import com.xnai.mulder.util.StringChanger;
import com.xnai.mulder.util.StringSupport;
import com.xnai.mulder.util.VectorX;
import com.xnai.net.XCSRequest;
import com.xnai.net.XCSResponse;
import com.xnai.net.xResponse;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;


public class DemoBookingMonitor extends BookingMonitor
{
  private static String CFG_FILE = "config" + File.separator + "DemoBooking.ini";
  private static String LOG_PATH = FileManager.getDataPath() + "demo_booking";

  private Configuration cfg = null;
  private List PRODUCTS = null;


  public DemoBookingMonitor()
  {
    super();

    getOpCodes().add("Book");

    setName("DemoBookingMonitor");
  }


  public Object doOpCode(String opcode, Object obj)
  {
    VectorX inVec = (VectorX)obj;

    if (opcode.equals("Start"))
    {
      return opCodeStart(inVec, null);
    }

    if (opcode.equals("Export"))
    {
      return opCodeExport(inVec);
    }

    if (opcode.equals("ViewError"))
    {
      return opCodeViewError(inVec);
    }

    if (opcode.equals("CancelExport"))
    {
      return opCodeCancelExport(inVec);
    }

    if (opcode.equals("Finish"))
    {
      return opCodeFinish(inVec);
    }

    return super.doOpCode(opcode, obj);
  }


  private xResponse opCodeStart(VectorX inVec, String message)
  {
    xResponse res = new xResponse();

    String username = null;

    try
    {
      username = ClientUtils.getUsername(inVec);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Error with incoming data.");
      return res;
    }

    String formName = "Booking_Export.DEMO";
    String form = FormLoader.loadFormString(formName);
    if (form.length() == 0)
    {
      res.errCode = 202;
      res.param.add("Unable to load form: " + formName);
      return res;
    }

    Map newAppStatusMap = new LinkedHashMap();
    newAppStatusMap.put("8015", "Ready to Book");
    newAppStatusMap.put("8025", "Booking Failed");

    AppFilterParams afp = new AppFilterParams();
    afp.setAppStatusMap(newAppStatusMap);
    afp.setDefaultStatus("8015");
    afp.setBranch(CSFieldValues.EMPTY_STRING);
    afp.setRegion(CSFieldValues.EMPTY_STRING);
    afp.overrideSavedCriteria();
    afp.setFilter(true);

    XCSRequest req = new XCSRequest("Initialize.AppFilter");
    req.param.add(username);
    req.param.add(afp);

    XCSResponse xcsres = contactSystem(req);

    if (xcsres.errCode != 0)
    {
      String msg = xcsres.param.size() > 0 ? (String)xcsres.param.get(0) :
                                             "Unknown Error";
      res.errCode = 202;
      res.param.add("Error filtering for applications: " + msg);
      return res;
    }

    HashtableX fields =
      StringChanger.stringToHashtable((String)xcsres.param.get(0));

    if (message != null) fields.put("!!_show_message_box", message);

    HashtableX response = super.createClientResponse(form, fields, null);

    res.param.add(response);
    return res;
  }


  private xResponse opCodeExport(VectorX inVec)
  {
    xResponse res = new xResponse();

    String username = null;
    HashtableX inFields = null;

    try
    {
      username = ClientUtils.getUsername(inVec);
      inFields = ClientUtils.getFieldsHash(inVec);
    }
    catch (Exception e)
    {
      res.errCode = 1;
      res.param.add("Error with incoming data.");
      return res;
    }

    VectorX appList = (VectorX)inFields.get(CSFieldNames.FN_APP_ID_FILTER);
    if (appList == null || appList.isEmpty())
    {
      res.errCode = 202;
      res.param.add("Please select one or more applications to export.");
      return res;
    }

    String appKey, appID;
    SystemDataObject sdo;
    DataNode appNode;
    String decision = null;
    StringBuffer errorMsg;
    StringBuilder msg = new StringBuilder();
    List log = new ArrayList();
    boolean hadProblem = false;

    for (int i = 0, c = appList.size(); i < c; ++i)
    {
      appKey = (String)appList.get(i);
      String[] keys = appKey.split(":");
      appID = keys[0];

      try
      {
        sdo = SDOUtils.getSDO(appID);
      }
      catch (SQLException e)
      {
        msg.append(appID).append(": Error retrieving application: ").append(e).append("\n");
        hadProblem = true;
        continue;
      }

      if (sdo == null)
      {
        msg.append(appID).append(": Application not found in database.\n");
        hadProblem = true;
        continue;
      }

      String sdoStatus = SDOUtils.getSDOStatus(sdo);

      if (sdoStatus != null &&
           (!sdoStatus.equals(CSStatusCodes.SC_RDY_TO_BOOK) &&
            !sdoStatus.equals(CSStatusCodes.SC_BK_FAILED)))

      {
        msg.append(appID).append(": Application not in proper status for booking.\n");
        hadProblem = true;
        continue;
      }

      try
      {
        boolean ok = sdo.lock(getName());
        if (! ok)
        {
          msg.append(appID).append(": Application currently locked by '").append(sdo.lockedBy()).append("'");
        }
      }
      catch (SQLException e)
      {
        msg.append(appID).append(": ").append(e.getMessage());
        continue;
      }

      errorMsg = new StringBuffer();

      boolean ok = processApplication(username, sdo, log, errorMsg);

      appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);
      if (appNode != null)
      {
        decision = (String)appNode.getSystemData(CSStatusCodes.APP_DECISION);
      }

      if (decision == null) decision = CSFieldValues.EMPTY_STRING;

      if (ok)
      {
        // Change status to something other than booking failed.
        //
        updateAppStatusAndSave(sdo, log, null,
                               super.USE_DECLINE_STATUS && !decision.equals("a") ?
                               CSStatusCodes.SC_BOOKING_DECLINE :
                               CSStatusCodes.SC_BOOKING, true, username);
      }
      else
      {
        hadProblem = true;

        if (errorMsg.length() > 0)
        {
          msg.append(errorMsg).append("\n");
          updateAppStatusAndSave(sdo, log, errorMsg,
                                 USE_DECLINE_STATUS && !decision.equals("a") ?
                                 CSStatusCodes.SC_BK_FAILED_DECLINE :
                                 CSStatusCodes.SC_BK_FAILED,
                                 true, username);
        }
        else
        {
          msg.append(appID).append(": Product is not qualified for booking.\n");
          updateAppStatusAndSave(sdo, log, null, null, false, username);
        }
      }
    }

    StringBuilder sb = new StringBuilder();

    if (hadProblem)
    {
      sb.append("Export was unsuccessful: ").append("\n\n");
      sb.append(msg);
    }
    else
    {
      sb.append("The export completed successfully.");
    }

    super.writeLogFile(log);

    return opCodeStart(inVec, sb.toString());
  }


  private xResponse opCodeViewError(VectorX inVec)
  {
    xResponse res = new xResponse();

    String username = null;
    HashtableX inFields = null;

    try
    {
      username = ClientUtils.getUsername(inVec);
      inFields = ClientUtils.getFieldsHash(inVec);
    }
    catch (Exception e)
    {
      res.errCode = 1;
      res.param.add("Error with incoming data.");
      return res;
    }

    VectorX appList = null;

    boolean MULTISELECT = true;
    if (MULTISELECT)
    {
      appList = (VectorX)inFields.get(CSFieldNames.FN_APP_ID_FILTER);
      if (appList == null || appList.isEmpty())
      {
        res.errCode = 202;
        res.param.add("Please select an application from the table.");
        return res;
      }
    }
    else
    {
      String appID = (String)inFields.get("afAppT");
      if (appID == null || appID.trim().length() == 0)
      {
        res.errCode = 202;
        res.param.add("Please select an application from the table.");
        return res;
      }

      appList = new VectorX();
      appList.add(appID);
    }

    SystemDataObject sdo;
    String appKey, appID;
    StringBuilder msg = new StringBuilder();

    for (int i = 0, c = appList.size(); i < c; ++i)
    {
      appKey = (String)appList.get(i);
      String[] keys = appKey.split(":");
      appID = keys[0];

      try
      {
        sdo = SDOUtils.getSDO(appID);
      }
      catch (SQLException e)
      {
        msg.append(appID).append(": Unable to load System File: ").append(e).append("\n");
        continue;
      }

      DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);

      String errorMsg = (String)appNode.getSystemData("!bkErr");
      if (errorMsg == null || errorMsg.length() == 0)
      {
        errorMsg = "Application did not contain any booking errors.";
      }

      msg.append(errorMsg).append("\n");
    }

    res.errCode = 200;
    res.param.add(msg.toString());
    return res;
  }


  private xResponse opCodeCancelExport(VectorX inVec)
  {
    xResponse res = new xResponse();

    String username = null;
    HashtableX inFields = null;

    try
    {
      username = ClientUtils.getUsername(inVec);
      inFields = ClientUtils.getFieldsHash(inVec);
    }
    catch (Exception e)
    {
      res.errCode = 1;
      res.param.add("Error with incoming data.");
      return res;
    }

    VectorX appList = null;

    boolean MULTISELECT = true;
    if (MULTISELECT)
    {
      appList = (VectorX)inFields.get(CSFieldNames.FN_APP_ID_FILTER);
      if (appList == null || appList.isEmpty())
      {
        res.errCode = 202;
        res.param.add("Please select an application from the table.");
        return res;
      }
    }
    else
    {
      String appID = (String)inFields.get("afAppT");
      if (appID == null || appID.trim().length() == 0)
      {
        res.errCode = 202;
        res.param.add("Please select an application from the table.");
        return res;
      }

      appList = new VectorX();
      appList.add(appID);
    }

    SystemDataObject sdo;
    String appKey, appID, refID, decision;
    StringBuilder msg = new StringBuilder();

    for (int i = 0, c = appList.size(); i < c; ++i)
    {
      appKey = (String)appList.get(i);
      String[] keys = appKey.split(":");
      appID = keys[0];

      try
      {
        sdo = SDOUtils.getSDO(appID);
      }
      catch (SQLException e)
      {
        msg.append(appID).append(": Unable to load System File: ").append(e).append("\n");
        continue;
      }

      DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);
      refID = (String)appNode.getFieldData(CSFieldValues.EMPTY_STRING, CSFieldNames.FN_APP_REF_ID);

      try
      {
        boolean success = sdo.lock(username);
        if (! success)
        {
          String lockedBy = sdo.lockedBy();
          msg.append(refID).append(": Application locked by '").append(lockedBy).append("'\n");
          continue;
        }
      }
      catch (SQLException e)
      {
        msg.append(refID).append(": ").append(e).append("\n");
        continue;
      }

      decision = (String)appNode.getSystemData(CSStatusCodes.APP_DECISION);
      if (decision == null) decision = CSFieldValues.EMPTY_STRING;

      appNode.setSystemData(CSStatusCodes.SDO_STATUS,
                            USE_DECLINE_STATUS && !decision.equals("a") ?
                            CSStatusCodes.SC_BOOKING_DECLINE :CSStatusCodes.SC_BOOKING);
      appNode.setSystemData("!booked", "b");


      String branchId = (String)appNode.getFieldData(username, CSFieldNames.FN_BRANCH_ID);
      if (branchId.trim().length() == 0)
      {
        if (username != null)
        {
          User user = User.getUser(username);
          if (user != null) branchId = user.getUserBranch();
        }
      }

      if (branchId != null) appNode.setSystemData("!bkBranchId", branchId);
      if (username != null) appNode.setSystemData("!bkUser", username);

      try
      {
        DBUtils.updateAppStatus(username, sdo);
        SDOUtils.saveSDO(username, sdo, CSStatusCodes.SDO_UNLOCK);
      }
      catch (SQLException e)
      {
        msg.append(refID).append(": Error saving application: ").append(e).append("\n");
      }
    }

    String message = null;

    if (msg.length() > 0)
    {
      StringBuilder sb = new StringBuilder();
      sb.append("The following error(s) were encountered:\n\n");
      sb.append(msg);

      message = sb.toString();
    }

    return opCodeStart(inVec, message);
  }


  private xResponse opCodeFinish(VectorX inVec)
  {
    return new xResponse();
  }


  protected boolean processApplication(String username, SystemDataObject sdo, List log,
                                       StringBuffer errorMsg)
  {
    return true;
  }


  protected List getProductListing()
  {
    return PRODUCTS;
  }


  // -------------------------------------------------------------
  // Cartridge Initialization
  // -------------------------------------------------------------


  public void startupInitializer()
  {
    initialize();

    //Booking.setBookingCartName(getName());
    //Booking.setMultiselect(false);

    // Start it up if interval is > 0.
    //
    if (getInterval() > 0)
    {
      AdminGUIManager.displayE(getName() + " interval is " +
                               (getInterval() / 60000) + " minute(s).");

      Thread thread = new Thread(SystemHouse.threadGroup, this,
                                 getName() + " (" + SystemHouse.getBankName() + ")");
      setThread(thread);
      thread.start();
    }
  }


  public void initialize()
  {
    cfg = new Configuration();
    cfg.load(CFG_FILE);

    String str = cfg.getSectionProperty("Settings", "enabled");
    boolean enabled = str != null && str.equals("true");
    setEnabled(enabled);

    if (! enabled) return;

    String intervalS = cfg.getSectionProperty("Settings", "interval");
    int interval = StringSupport.strToInt(intervalS) * 60000;
    setInterval(interval);

    APPROVE_CODE = cfg.getSectionProperty("Settings", "approve");
    if (APPROVE_CODE == null) APPROVE_CODE = "none";

    DECLINE_CODE = cfg.getSectionProperty("Settings", "decline");
    if (DECLINE_CODE == null) DECLINE_CODE = "none";

    String incFraud = cfg.getSectionProperty("Settings", "include_fraud");
    INCLUDE_FRAUD = incFraud != null && incFraud.equals("true");

    String incDuplicate = cfg.getSectionProperty("Settings", "include_duplicate");
    INCLUDE_DUPLICATE = incDuplicate != null && incDuplicate.equals("true");

    String assignLoanNum = cfg.getSectionProperty("Settings", "assign_loan_num");
    ASSIGN_LOAN_NUM = assignLoanNum != null && assignLoanNum.equals("true");

    if (ASSIGN_LOAN_NUM)
    {
      String assignOnDecline = cfg.getSectionProperty("Settings", "loan_num_on_decline");
      LOAN_NUM_DECLINE = assignOnDecline != null && assignOnDecline.equals("true");
    }

    String disburseFlag = cfg.getSectionProperty("Settings", "disbursed");
    MUST_BE_DISBURSED = disburseFlag != null && disburseFlag.equals("true");

    final String fundedFlag = cfg.getSectionProperty("Settings", "must_be_funded");
    MUST_BE_FUNDED = "true".equals(fundedFlag);

    str = cfg.getSectionProperty("Settings", "check_closing_reqs");
    CHECK_CLOSING_REQS = str != null && str.equals("true");

    String logS = cfg.getSectionProperty("Settings", "log");
    LOG = (logS != null && logS.equals("true"));

    if (LOG)
    {
      LOG_DIR = LOG_PATH;
      File file = new File(LOG_DIR);
      if (! file.exists()) file.mkdirs();
    }

    PRODUCTS = cfg.getSectionElements("Products");
  }
}
