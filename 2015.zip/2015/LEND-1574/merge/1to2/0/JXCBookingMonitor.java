/**
 * Title:        JXCBookingMonitor
 * Description:
 * Copyright:    Copyright (c) 2012
 * Company:      ACI Worldwide
 * @author Len Doerich / Chiu Chan
 * @version 1.0
 */

import java.io.File;
import java.io.FileWriter;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.ws.Binding;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.Handler;

import com.jackhenry.jxchange.tpg._2008.*;
import com.xnai.credisphere.appFilter.AppFilterParams;
import com.xnai.credisphere.appImport.AppImportUtils;
import com.xnai.credisphere.calcs.AppCalcs;
import com.xnai.credisphere.dataCache.CSDataCache;
import com.xnai.credisphere.db.DBQueries;
import com.xnai.credisphere.db.DBUtils;
import com.xnai.credisphere.depProduct.DepProduct;
import com.xnai.credisphere.deposits.DepUtils;
import com.xnai.credisphere.locations.Location;
import com.xnai.credisphere.util.CSFieldNames;
import com.xnai.credisphere.util.CSFieldValues;
import com.xnai.credisphere.util.CSStatusCodes;
import com.xnai.credisphere.util.CSUtil;
import com.xnai.credisphere.util.DecisionUtils;
import com.xnai.credisphere.util.NodeUtils;
import com.xnai.credisphere.util.SDOUtils;
import com.xnai.httpHost.MyX509TrustManager;
import com.xnai.mulder.security.AES;
import com.xnai.mulder.systemCore.AdminGUIManager;
import com.xnai.mulder.systemCore.SystemConfig;
import com.xnai.mulder.systemCore.SystemHouse;
import com.xnai.mulder.systemObject.DataNode;
import com.xnai.mulder.systemObject.SystemDataObject;
import com.xnai.mulder.user.User;
import com.xnai.mulder.util.AESUtils;
import com.xnai.mulder.util.AESUtils.InitVector;
import com.xnai.mulder.util.ClientUtils;
import com.xnai.mulder.util.CmdEvaluator;
import com.xnai.mulder.util.Configuration;
import com.xnai.mulder.util.DataFile;
import com.xnai.mulder.util.DateUtility;
import com.xnai.mulder.util.ExceptionLogger;
import com.xnai.mulder.util.FormLoader;
import com.xnai.mulder.util.GeneralToolkit;
import com.xnai.mulder.util.HashtableX;
import com.xnai.mulder.util.StringChanger;
import com.xnai.mulder.util.StringSupport;
import com.xnai.mulder.util.VectorX;
import com.xnai.mulder.visual.Form;
import com.xnai.mulder.visual.TableRecord;
import com.xnai.mulder.visual.TableTransaction;
import com.xnai.net.XCSRequest;
import com.xnai.net.XCSResponse;
import com.xnai.net.xResponse;


public class JXCBookingMonitor extends BookingMonitor
{
  GeneralToolkit general = new GeneralToolkit();
  private static String CFG_FILE = "config" + File.separator + "JXCBooking.ini";
  private static String ROOT_PATH = "jxcBooking";

  private Configuration CONFIG = null;
  private List PRODUCTS = null;
  
  private boolean isProduction = false;
  private String prodURL = null;
  private String testURL = null;
  private String jxcUsername = null;
  private String jxcPassword = null;
  private String version = null;
  private String auditUserId = null;
  private String auditWsId = null;
  private String consumerName = null;
  private String consumerProd = null;
  private String trackingPrefix = null;

  // Controls which product checking routine to use.
  private boolean FROM_ACTIVITY = false;
  private boolean LOOKUP_RATE = false;

  
  public JXCBookingMonitor()
  {
    super();

    getOpCodes().add("Start");
    getOpCodes().add("Export");
    getOpCodes().add("ViewError");
    getOpCodes().add("CancelExport");
    getOpCodes().add("Finish");
    getOpCodes().add("MemberSearch");
    getOpCodes().add("CustomerSearch");
    getOpCodes().add("CustomerInquiry");
    getOpCodes().add("AccountSearch");
    getOpCodes().add("Test");

    setName("JXCBookingMonitor");
  }


  public Object doOpCode(String opcode, Object obj)
  {
    VectorX inVec = (VectorX) obj;

    if (opcode.equals("Start"))
    {
      return opCodeStart(inVec, null);
    }

    if (opcode.equals("Export"))
    {
      return opCodeExport(inVec);
    }

    if (opcode.equals("ViewError"))
    {
      return opCodeViewError(inVec);
    }

    if (opcode.equals("CancelExport"))
    {
      return opCodeCancelExport(inVec);
    }

    if (opcode.equals("Finish"))
    {
      return opCodeFinish(inVec);
    }

    if (opcode.equals("CustomerSearch"))
    {
      return opCodeCustomerSearch(inVec);
    }
    
    if (opcode.equals("MemberSearch"))
    {
      return opCodeCustomerSearch(inVec);
    }
    
    if (opcode.equals("CustomerInquiry"))
    {
      return opCodeCustomerInquiry(inVec);
    }
    
    if (opcode.equals("AccountSearch"))
    {
      return opCodeAccountSearch(inVec);
    }
    
    if (opcode.equals("Test"))
    {
      return opCodeTest(inVec);
    }
    
    return super.doOpCode(opcode, obj);
  }


  private xResponse opCodeStart(VectorX inVec, String message)
  {
    xResponse res = new xResponse();

    String username = null;

    try
    {
      username = ClientUtils.getUsername(inVec);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Error with incoming data.");
      return res;
    }

    String formName = "Booking_Export.JXC";
    String form = FormLoader.loadFormString(formName);
    if (form.length() == 0)
    {
      res.errCode = 202;
      res.param.add("Unable to load form: " + formName);
      return res;
    }

    Map newAppStatusMap = new LinkedHashMap();
    newAppStatusMap.put("8015", "Ready to Book");
    newAppStatusMap.put("8025", "Booking Failed");

    AppFilterParams afp = new AppFilterParams();
    afp.setAppStatusMap(newAppStatusMap);
    afp.setDefaultStatus("8015");
    afp.setBranch(CSFieldValues.EMPTY_STRING);
    afp.setRegion(CSFieldValues.EMPTY_STRING);
    afp.overrideSavedCriteria();
    afp.setFilter(true);

    XCSRequest req = new XCSRequest("Initialize.AppFilter");
    req.param.add(username);
    req.param.add(afp);

    XCSResponse xcsres = contactSystem(req);

    if (xcsres.errCode != 0)
    {
      String msg = xcsres.param.size() > 0 ? (String)xcsres.param.get(0) :
                                             "Unknown Error";
      res.errCode = 202;
      res.param.add("Error filtering for applications: " + msg);
      return res;
    }

    HashtableX fields =
      StringChanger.stringToHashtable((String)xcsres.param.get(0));

    if (message != null) fields.put("!!_show_message_box", message);

    HashtableX response = super.createClientResponse(form, fields, null);

    res.param.add(response);
    return res;
  }


  private xResponse opCodeExport(VectorX inVec)
  {
    //general.errLog( "START opCodeExport(VectorX inVec)", "JXC.log" );

    xResponse res = new xResponse();

    String username = null;
    HashtableX inFields = null;

    try
    {
      username = ClientUtils.getUsername(inVec);
      inFields = ClientUtils.getFieldsHash(inVec);
    }
    catch (Exception e)
    {
      res.errCode = 1;
      res.param.add("Error with incoming data.");
      return res;
    }

    VectorX appList = (VectorX)inFields.get(CSFieldNames.FN_APP_ID_FILTER);
    if (appList == null || appList.isEmpty())
    {
      res.errCode = 202;
      res.param.add("Please select one or more applications to export.");
      return res;
    }

    String appKey, appID;
    SystemDataObject sdo;
    DataNode appNode;
    String decision = null;
    StringBuffer errorMsg;
    StringBuilder msg = new StringBuilder();
    List log = new ArrayList();
    boolean hadProblem = false;

    for (int i = 0, c = appList.size(); i < c; ++i)
    {
      appKey = (String)appList.get(i);
      String[] keys = appKey.split(":");
      appID = keys[0];

      try
      {
        sdo = SDOUtils.getSDO(appID);
      }
      catch (SQLException e)
      {
        msg.append(appID + ": Error retrieving application: " + e + "\n");
        hadProblem = true;
        continue;
      }

      if (sdo == null)
      {
        msg.append(appID + ": Application not found in database.\n");
        hadProblem = true;
        continue;
      }

      String sdoStatus = SDOUtils.getSDOStatus(sdo);

      if (sdoStatus != null &&
           (!sdoStatus.equals(CSStatusCodes.SC_RDY_TO_BOOK) &&
            !sdoStatus.equals(CSStatusCodes.SC_BK_FAILED)))

      {
        msg.append(appID + ": Application not in proper status for booking.\n");
        hadProblem = true;
        continue;
      }

      try
      {
        boolean ok = sdo.lock(getName());
        if (! ok)
        {
          msg.append(appID + ": Application currently locked by '" + sdo.lockedBy() + "'");
        }
      }
      catch (SQLException e)
      {
        msg.append(appID + ": " + e.getMessage());
        continue;
      }

      errorMsg = new StringBuffer();
      FROM_ACTIVITY = true;

      boolean ok = processApplication(username, sdo, log, errorMsg);

      appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);
      if (appNode != null)
      {
        decision = (String)appNode.getSystemData(CSStatusCodes.APP_DECISION);
      }

      if (decision == null) decision = CSFieldValues.EMPTY_STRING;

      if (ok)
      {
        // Change status to something other than booking failed.
        //
        updateAppStatusAndSave(sdo, log, null,
                               super.USE_DECLINE_STATUS && !decision.equals("a") ?
                               CSStatusCodes.SC_BOOKING_DECLINE :
                               CSStatusCodes.SC_BOOKING, true, username);
      }
      else
      {
        hadProblem = true;

        if (errorMsg.length() > 0)
        {
          msg.append(errorMsg).append("\n");
          updateAppStatusAndSave(sdo, log, errorMsg,
                                 USE_DECLINE_STATUS && !decision.equals("a") ?
                                 CSStatusCodes.SC_BK_FAILED_DECLINE :
                                 CSStatusCodes.SC_BK_FAILED,
                                 true, username);
        }
        else
        {
          msg.append(appID + ": Product is not qualified for booking.\n");
          updateAppStatusAndSave(sdo, log, null, null, false, username);
        }
      }
    }

    StringBuilder sb = new StringBuilder();

    if (hadProblem)
    {
      sb.append("Export was unsuccessful: ").append("\n\n");
      sb.append(msg);
    }
    else
    {
      sb.append("The export completed successfully.");
    }

    super.writeLogFile(log);

    //general.errLog( "END opCodeExport(VectorX inVec)", "JXC.log" );

    return opCodeStart(inVec, sb.toString());
  }


  private xResponse opCodeViewError(VectorX inVec)
  {
    xResponse res = new xResponse();

    String username = null;
    HashtableX inFields = null;

    try
    {
      username = ClientUtils.getUsername(inVec);
      inFields = ClientUtils.getFieldsHash(inVec);
    }
    catch (Exception e)
    {
      res.errCode = 1;
      res.param.add("Error with incoming data.");
      return res;
    }

    VectorX appList = null;

    boolean MULTISELECT = true;
    if (MULTISELECT)
    {
      appList = (VectorX)inFields.get(CSFieldNames.FN_APP_ID_FILTER);
      if (appList == null || appList.isEmpty())
      {
        res.errCode = 202;
        res.param.add("Please select an application from the table.");
        return res;
      }
    }
    else
    {
      String appID = (String)inFields.get("afAppT");
      if (appID == null || appID.trim().length() == 0)
      {
        res.errCode = 202;
        res.param.add("Please select an application from the table.");
        return res;
      }

      appList = new VectorX();
      appList.add(appID);
    }

    SystemDataObject sdo;
    String appKey, appID;
    StringBuilder msg = new StringBuilder();

    for (int i = 0, c = appList.size(); i < c; ++i)
    {
      appKey = (String)appList.get(i);
      String[] keys = appKey.split(":");
      appID = keys[0];

      try
      {
        sdo = SDOUtils.getSDO(appID);
      }
      catch (SQLException e)
      {
        msg.append(appID + ": Unable to load System File: " + e + "\n");
        continue;
      }

      DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);

      String errorMsg = (String)appNode.getSystemData("!bkErr");
      if (errorMsg == null || errorMsg.length() == 0)
      {
        errorMsg = "Application did not contain any booking errors.";
      }

      msg.append(errorMsg + "\n");
    }

    res.errCode = 200;
    res.param.add(msg.toString());
    return res;
  }


  private xResponse opCodeCancelExport(VectorX inVec)
  {
    xResponse res = new xResponse();

    String username = null;
    HashtableX inFields = null;

    try
    {
      username = ClientUtils.getUsername(inVec);
      inFields = ClientUtils.getFieldsHash(inVec);
    }
    catch (Exception e)
    {
      res.errCode = 1;
      res.param.add("Error with incoming data.");
      return res;
    }

    VectorX appList = null;

    boolean MULTISELECT = true;
    if (MULTISELECT)
    {
      appList = (VectorX)inFields.get(CSFieldNames.FN_APP_ID_FILTER);
      if (appList == null || appList.isEmpty())
      {
        res.errCode = 202;
        res.param.add("Please select an application from the table.");
        return res;
      }
    }
    else
    {
      String appID = (String)inFields.get("afAppT");
      if (appID == null || appID.trim().length() == 0)
      {
        res.errCode = 202;
        res.param.add("Please select an application from the table.");
        return res;
      }

      appList = new VectorX();
      appList.add(appID);
    }

    SystemDataObject sdo;
    String appKey, appID, refID, decision;
    StringBuilder msg = new StringBuilder();

    for (int i = 0, c = appList.size(); i < c; ++i)
    {
      appKey = (String)appList.get(i);
      String[] keys = appKey.split(":");
      appID = keys[0];

      try
      {
        sdo = SDOUtils.getSDO(appID);
      }
      catch (SQLException e)
      {
        msg.append(appID + ": Unable to load System File: " + e + "\n");
        continue;
      }

      DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);
      refID = (String)appNode.getFieldData(CSFieldValues.EMPTY_STRING, CSFieldNames.FN_APP_REF_ID);

      try
      {
        boolean success = sdo.lock(username);
        if (! success)
        {
          String lockedBy = sdo.lockedBy();
          msg.append(refID + ": Application locked by '" + lockedBy + "'\n");
          continue;
        }
      }
      catch (SQLException e)
      {
        msg.append(refID + ": " + e + "\n");
        continue;
      }

      decision = (String)appNode.getSystemData(CSStatusCodes.APP_DECISION);
      if (decision == null) decision = CSFieldValues.EMPTY_STRING;

      appNode.setSystemData(CSStatusCodes.SDO_STATUS,
                            USE_DECLINE_STATUS && !decision.equals("a") ?
                            CSStatusCodes.SC_BOOKING_DECLINE :CSStatusCodes.SC_BOOKING);
      appNode.setSystemData("!booked", "b");


      String branchId = (String)appNode.getFieldData(username, CSFieldNames.FN_BRANCH_ID);
      if (branchId.trim().length() == 0)
      {
        if (username != null)
        {
          User user = User.getUser(username);
          if (user != null) branchId = user.getUserBranch();
        }
      }

      if (branchId != null) appNode.setSystemData("!bkBranchId", branchId);
      if (username != null) appNode.setSystemData("!bkUser", username);

      try
      {
        DBUtils.updateAppStatus(username, sdo);
        SDOUtils.saveSDO(username, sdo, CSStatusCodes.SDO_UNLOCK);
      }
      catch (SQLException e)
      {
        msg.append(refID + ": Error saving application: " + e + "\n");
      }
    }

    String message = null;

    if (msg.length() > 0)
    {
      StringBuilder sb = new StringBuilder();
      sb.append("The following error(s) were encountered:\n\n");
      sb.append(msg);

      message = sb.toString();
    }

    return opCodeStart(inVec, message);
  }


  private xResponse opCodeFinish(VectorX inVec)
  {
    return new xResponse();
  }
  


  public xResponse opCodeCustomerSearch(VectorX inVec)
  {
    //general.errLog( "START opCodeCustomerSearch(VectorX inVec)", "CustSerach.log" );
    xResponse res = new xResponse();      
    String username = null;
    HashtableX inHash = null;
    HashtableX inFields = null;

    try
    {
      //username = ClientUtils.getUsername(inVec);
      //inFields = ClientUtils.getFieldsHash(inVec);
        username = (String) inVec.elementAt(0);
        inHash = (HashtableX) inVec.elementAt(1);
        inFields = (HashtableX) inHash.get("Fields");
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Error with incoming data.");
      return res;
    }
      
    String custodianFlag = (String)inFields.get("daCustC");
    boolean isCustodian = custodianFlag != null && custodianFlag.equals(CSFieldValues.TRUE_STRING);
      
    String custID = (String)inFields.get("_atCIF");
    if (custID != null)
    {
      //general.errLog( "GOTO opCodeCustomerInquiry(inVec)", "CustSerach.log" );

      // If the user entered a customer ID, then we can do a customer inquiry rather than a
      // search.
      //
      inFields.put("_csT", custID);
      return opCodeCustomerInquiry(inVec);
    }
      
    // Otherwise proceed with a customer search using the SSN.
    //    
    String ssn = (String)inFields.get("_atSSN");
    if (ssn == null || ssn.length() == 0)
    {
      res.errCode = 202;
      res.param.add("Please enter a SSN.");
      return res;
    }
          
    // Perform the transaction to search customers by SSN.
    //
    CustSrchRecArrayAType searchArray = null;
    
    try
    {
      searchArray = doCustomerSearch(username, ssn);
    }
    catch (MessageFault mf)
    {
      StringBuilder mfText = generateFaultMessage(mf);
      StringBuilder msg = new StringBuilder();
      msg.append("One or more faults occurred while performing a customer search:\n\n");
      msg.append(mfText);
        
      res.errCode = 202;
      res.param.add(msg.toString());
      return res;
    }
    catch (Exception e)
    {
      ExceptionLogger.logException(e);
      res.errCode = 202;
      res.param.add("An error occurred while performing a customer search: " + e);
      return res;
    }
      
    if (searchArray == null)
    {
      res.errCode = 201;
      res.param.add("There were no customer matches found.");
      return res;
    }
      
    HashtableX fields = null;
      
    List<CustSrchRecCType> searchRecords = searchArray.getCustSrchRecs();
    if (searchRecords.size() == 1)
    {
      // If one match, then do a customer inquiry transaction using the customer #.
      //
      CustSrchRecCType searchRecord = searchRecords.get(0);
      String customerID = searchRecord.getCustId().getValue();
        
      CustInqResponse customerInqResponse;
        
      try
      {
        customerInqResponse = doCustomerInquiry(username, customerID, null);
      }
      catch (MessageFault mf)
      {
        StringBuilder mfText = generateFaultMessage(mf);
        StringBuilder msg = new StringBuilder();
        msg.append("One or more faults occurred while performing a customer inquiry:\n\n");
        msg.append(mfText);
          
        res.errCode = 202;
        res.param.add(msg.toString());
        return res;
      }
      catch (Exception e)
      {
        ExceptionLogger.logException(e);
        res.errCode = 202;
        res.param.add("An error occurred while performing a customer inquiry: " + e);
        return res;
      }
        
      fields = generateApplicantFieldsFromCustInq(customerInqResponse, isCustodian);
      fields.put("csVisC", "false");
      fields.put("_csT", "");
    }
    else
    {
      // We want to show the customer create date in the search table, so we need
      // to do a customer inquiry for each customer that came back in the search
      // results.  The following method call does the customer inquiry and retrieves
      // the CustOrgDt property from the inquiry results.  The map returned has the      
      // the key as customer ID, and the value as the date.  The map will be used
      // in the method that generates the customer search table.
      //
      Map<String, String> jhaCreateDateMap = null;
      
      try
      {
        jhaCreateDateMap = createCustomerOrgDateMapping(username, searchRecords);
      }
      catch (MessageFault mf)
      {
        StringBuilder mfText = generateFaultMessage(mf);
        StringBuilder msg = new StringBuilder();
        msg.append("One or more faults occurred while performing a customer inquiry:\n\n");
        msg.append(mfText);
          
        res.errCode = 202;
        res.param.add(msg.toString());
        return res;
      }
      catch (Exception e)
      {
        ExceptionLogger.logException(e);
        res.errCode = 202;
        res.param.add("An error occurred while performing a customer inquiry: " + e);
        return res;
      }
        
      // If multiple matches, show the table of hits so the user can choose which
      // is the correct match.
      //
      TableTransaction resultsTable = generateCustomerSearchTable(searchRecords, jhaCreateDateMap);
      VectorX resultsHashTables = generateCustomerSearchHashtables(searchRecords, jhaCreateDateMap);

      fields = new HashtableX();            
      fields.put("csVisC", "true");
      fields.put("_csT", resultsTable);
      fields.put("_jxcCustAccounts",resultsHashTables);
    }
      
    HashtableX response = super.createClientResponse((Form)null, fields, null);
      
    res.param.add(response);

    //general.errLog( "END opCodeCustomerSearch(VectorX inVec)", "CustSerach.log" );

    return res;
  }
    
  private xResponse opCodeCustomerInquiry(VectorX inVec)
  {
    //general.errLog( "START opCodeCustomerInquiry(inVec)", "CustSerach.log" );

    xResponse res = new xResponse();
    
    String username;
    HashtableX inFields;
    
    try
    {
      username = ClientUtils.getUsername(inVec);
      inFields = ClientUtils.getFieldsHash(inVec);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Error with incoming data.");
      return res;
    }

    String custodianFlag = (String)inFields.get("daCustC");
    boolean isCustodian = custodianFlag != null && custodianFlag.equals(CSFieldValues.TRUE_STRING);

    String customerID = (String)inFields.get("_csT");
    if (customerID == null)
    {
      res.errCode = 202;
      res.param.add("Please choose a customer record from the table.");
      return res;
    }

    CustInqResponse customerInqResponse;
    
    try
    {
      customerInqResponse = doCustomerInquiry(username, customerID, null);
      //general.errLog( "customerInqResponse: " + customerInqResponse, "CustSerach.log" );

    }
    catch (MessageFault mf)
    {
      StringBuilder mfText = generateFaultMessage(mf);
      StringBuilder msg = new StringBuilder();
      msg.append("One or more faults occurred while performing a customer inquiry:\n\n");
      msg.append(mfText);
      
      res.errCode = 202;
      res.param.add(msg.toString());
      return res;
    }
    catch (Exception e)
    {
      ExceptionLogger.logException(e);
      res.errCode = 202;
      res.param.add("An error occurred while performing a customer inquiry: " + e);
      return res;
    }
    
    if (customerInqResponse == null)
    {
      res.errCode = 202;
      res.param.add("Unable to find a customer record for the ID: " + customerID);
      return res;
    }
    
    HashtableX fields = generateApplicantFieldsFromCustInq(customerInqResponse, isCustodian);
    //general.errLog( "fields: "+fields, "CustSerach.log" );

    HashtableX response = super.createClientResponse((Form)null, fields, null);
    
    res.param.add(response);

    //general.errLog( "END opCodeCustomerInquiry(inVec)", "CustSerach.log" );

    return res;
  }
  
  
  public xResponse opCodeAccountSearch(VectorX inVec)
  {
    xResponse res = new xResponse();
    
    String username;
    HashtableX inFields;
    
    try
    {
      username = ClientUtils.getUsername(inVec);
      inFields = ClientUtils.getFieldsHash(inVec);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Error with incoming data.");
      return res;
    }

    String customerID = (String)inFields.get("_csT");
    if (customerID == null)
    {
      res.errCode = 202;
      res.param.add("Please choose a customer record from the table.");
      return res;
    }

    String formName = "Customer_Accounts.JXC";
    String form = FormLoader.loadFormString(formName);
    if (form.length() == 0)
    {
      res.errCode = 202;
      res.param.add("Unable to load form: " + formName);
      return res;
    }
    
    AcctSrchRecArrayAType acctSearchRespArray = null;
    
    try
    {
      acctSearchRespArray = doAccountSearch(username, customerID);
    }
    catch (MessageFault mf)
    {
      StringBuilder mfText = generateFaultMessage(mf);
      StringBuilder msg = new StringBuilder();
      msg.append("One or more faults occurred while performing an account search:\n\n");
      msg.append(mfText);
      
      res.errCode = 202;
      res.param.add(msg.toString());
      return res;
    }
    catch (Exception e)
    {
      ExceptionLogger.logException(e);
      res.errCode = 202;
      res.param.add("An error occurred while performing an account search: " + e);
      return res;
    }

    if (acctSearchRespArray == null)
    {
      res.errCode = 200;
      res.param.add("No accounts were found for this customer.");
      return res;
    }
    
    List<AcctSrchRecCType> searchRecList = acctSearchRespArray.getAcctSrchRecs();
    
    TableTransaction table = generateCustomerAccountTable(searchRecList);

    HashtableX fields = new HashtableX();
    fields.put("_acctInfoT", table);
    
    HashtableX response = super.createClientResponse(form, fields, null);
    
    res.param.add(response);
    return res;
  }
  

  public xResponse opCodeTest(VectorX inVec)
  {
    xResponse res = new xResponse();
    
    String username = (String)inVec.get(0);
    String ssn = (String)inVec.get(1);
    
    try
    {
      CustSrchRecArrayAType resultArray = doCustomerSearch(username, ssn);
      if (resultArray != null)
      {
        List<CustSrchRecCType> results = resultArray.getCustSrchRecs();
        
        //TableTransaction table = generateCustomerSearchTable(results);
        //AdminGUIManager.displayE(table.toString());
        
        //TableRecord tr = (TableRecord)table.getRecords().get(0);
        //String custID = tr.getColumnData(0);
        
        //CustRecCType customerRecord = doCustomerInquiry(custID, null);
      }
      else
      {
        AdminGUIManager.displayE("No matches on: " + ssn);
      }
    }
    catch (MessageFault mf)
    {
      ExceptionLogger.logException(mf);
      AdminGUIManager.displayE(generateFaultMessage(mf).toString());
    }
    catch (Exception e)
    {
      ExceptionLogger.logException(e);
      AdminGUIManager.displayE(e.toString());      
    }
    
    return res;
  }
  
  /**
   * This method executes the CustomerSearch web service call to JXChange.  The SSN is used as input and a list
   * of customer matches is returned.
   * 
   * @param ssn
   * @return
   * @throws MessageFault
   */
  private CustSrchRecArrayAType doCustomerSearch(String username, String ssn)
  throws MessageFault
  {    
    if (ssn.indexOf('-') != -1) ssn = StringSupport.stripCharacter(ssn, '-');
    
    CustomerService service = createCustomerService();
        
    // Create the search message header and set the max number of results.
    //
    SrchMsgRqHdrCType searchMsgHeader = new SrchMsgRqHdrCType();
    searchMsgHeader.setMaxRec(10);
    searchMsgHeader.setJXchangeHdr(generateJXChangeHeader(username));
    
    // Create a tax ID type from the social security number.
    //
    TaxIdType taxIDType = new TaxIdType();
    taxIDType.setValue(ssn);    

    // Create the main search request object, setting the SSN and the search header.
    //
    CustSrch searchReq = new CustSrch();
    searchReq.setTaxId(taxIDType);
    searchReq.setSrchMsgRqHdr(searchMsgHeader);
  
    CustSrchResponse searchResp = service.custSrch(searchReq);
    
    CustSrchRecArrayAType searchArray = searchResp.getCustSrchRecArray();
    
    return searchArray;
  }

  /**
   * This method executes the Add Customer Relationship web service call to JXChange.  
   * 
   */
  private CustRelAddResponse doCustomerRelationshipAdd(String username, CustomerService customerSvc, String acctId,
                                                       String acctType, String primaryCustomerID, String jointCustId,
                                                       String relationshipType)
  throws MessageFault
  {
      if (customerSvc == null)
      {
          customerSvc = createCustomerService();
      }
      
      CustRelAdd custRelAdd = new CustRelAdd();
      
      /* ***********************************************
      *  CustRelAdd:MsgRqHdr                           *
      * ************************************************/
      MsgRqHdrCType msgRq = new MsgRqHdrCType();
      msgRq.setJXchangeHdr(generateJXChangeHeader(username));
      custRelAdd.setMsgRqHdr(msgRq);
      
      
      /* ***********************************************
      *  CustRelAdd:CustId                             *
      * ************************************************/
      CustIdType custId = new CustIdType();
      custId.setValue(jointCustId);
      custRelAdd.setCustId(custId);
      
      
      /* ***********************************************
      *  CustRelAdd:RelCustId (primaryCustomerID's Id) *
      * ************************************************/
      String relCustId = primaryCustomerID;

//custRelAdd.setRelCustId(relCustId);
    
      // need a RelCustIdType
      RelCustIdType relCustIdType = new RelCustIdType();      
      relCustIdType.setValue( relCustId );
      custRelAdd.setRelCustId( relCustIdType );


    /* ***********************************************
      *  CustRelAdd:RelAcctId - Related account ID     *
      * ************************************************/
      RelAcctIdType relAcctId = new RelAcctIdType();
      relAcctId.setValue(acctId);
      custRelAdd.setRelAcctId(relAcctId);
      
      
      /* ***********************************************
      *  CustRelAdd:RelAcctType - Related account Type *
      * ************************************************/              
      RelAcctTypeType relAcctType = new RelAcctTypeType();
      relAcctType.setValue(acctType);
      custRelAdd.setRelAcctType(relAcctType);
      
              
      /* ***********************************************
      *  CustRelAdd:CustRelRec                         *
      * ************************************************/   
      CustRelRecCType custRelRec = new CustRelRecCType();
      
      //CustRelAdd:CustRelRec:AcctRelCode - The account relationship code is a bank defined, single alpha character.
      //Need to get the code from Five Star for Co-appliant and Custodial
      AcctRelCodeType acctRelCode = new AcctRelCodeType();
      acctRelCode.setValue(relationshipType);
      custRelRec.setAcctRelCode(acctRelCode);
      
      //CustRelAdd:CustRelRec:CopyRelCustMail - Would like a copy of all related customer mailings
      // This field should be optional but when it is not set we get ERROR 46 - Mailing Instruction code is not valid
      CopyRelCustMailType copyRelCustMail = new CopyRelCustMailType();
      copyRelCustMail.setValue("N");
      custRelRec.setCopyRelCustMail(copyRelCustMail); 
      
      //CustRelAdd:CustRelRec:PctOwned - Percentage that is owned.     
      //CustRelAdd:CustRelRec:AmtOwned - Amount that is owned 
      //CustRelAdd:CustRelRec:FDICCat - FDIC Catagory 
      //CustRelAdd:CustRelRec:OvrFDICInsurLmt - Over FDIC insurance limit. True or False. Defaults to False which would say they were FDIC insured as they were under the limit. If True then they are not covered as they are over the limit.
      //CustRelAdd:CustRelRec:FDICMrgAcct - Old account number prior to merger of financial institution.  
      //CustRelAdd:CustRelRec:FDICMrgDt - Date the merger of the account took place.
      //CustRelAdd:CustRelRec:PrtPastDueNotCode - 
      custRelAdd.setCustRelRec(custRelRec);
              
      CustRelAddResponse custRelAddResponse = customerSvc.custRelAdd(custRelAdd);
      return custRelAddResponse;
  }

  /**
   * This method executes the Account Number Generator web service call to JXChange.  
   * 
   */
  private AcctIdGenResponse doAccountIdGenerator(String username, CustomerService customerSvc, Map<String, String> inputParams) 
  throws MessageFault
  {
    //general.errLog( "START doAccountIdGenerator(String username, CustomerService customerSvc, Map<String, String> inputParams)" );
    //general.errLog( "Map<String, String> inputParams: "+inputParams );

    
    if (customerSvc == null)
      {
          customerSvc = createCustomerService();
      }
      
      AcctIdGen acctIdGen = new AcctIdGen();
       
      MsgRqHdrCType msgRq = new MsgRqHdrCType();
      msgRq.setJXchangeHdr(generateJXChangeHeader(username));
      acctIdGen.setMsgRqHdr(msgRq);
      
      if (inputParams != null) 
      {                
          // AcctType (REQUIRED)
          // The number(s) or character(s) that categorize the AcctId.
          if (inputParams.get("AcctType") != null) 
          {
            AcctTypeType acctType = new AcctTypeType();
            acctType.setValue(inputParams.get("AcctType"));
            acctIdGen.setAcctType(acctType);
          }
      
          // Branch code
          if (inputParams.get("BrCode") != null) 
          {
              BrCodeType branch = new BrCodeType();
              branch.setValue(inputParams.get("BrCode"));
              acctIdGen.setBrCode(branch);
          }
          
          // ProdCode - The code that identifies a product, type of account within an application.
          if (inputParams.get("ProdCode") != null) 
          {
              ProdCodeType prod = new ProdCodeType();
              prod.setValue(inputParams.get("ProdCode"));
              acctIdGen.setProdCode(prod);
          }
          
          // Officer code. Allowed values are bank defined.
          if (inputParams.get("OffCode") != null) 
          {
              OffCodeType offer = new OffCodeType();
              offer.setValue(inputParams.get("OffCode"));
              acctIdGen.setOffCode(offer);
          }
          
          // SubCatType - A subordinate category of the account type element for requesting account identification(s) from a service provider.
          if (inputParams.get("SubCatType") != null) 
          {
              acctIdGen.setSubCatType(inputParams.get("SubCatType"));
          }
          
          //The quantity of account numbers that should be returned when generating new account numbers. 
          if (inputParams.get("QtyNeeded") != null) 
          {
              acctIdGen.setQtyNeeded(Integer.parseInt(inputParams.get("QtyNeeded")));
          }          
      }
                    
                    
      AcctIdGenResponse acctIdGenRsp = customerSvc.acctIdGen(acctIdGen);


    //general.errLog( "return acctIdGenRsp: "+ acctIdGenRsp );
    //general.errLog( "END doAccountIdGenerator(String username, CustomerService customerSvc, Map<String, String> inputParams)" );

    return acctIdGenRsp;
   }


  /**
   * This method executes the CustomerInquiry web service call to JXChange.  Using the customer ID as
   * input, a customer record is returned (1 or none).
   * 
   * @param customerID
   * @param customerSvc
   * @return
   * @throws MessageFault
   */
  private CustInqResponse doCustomerInquiry(String username, String customerID, CustomerService customerSvc)
  throws MessageFault
  {
    //general.errLog( "START doCustomerInquiry(inVec)", "CustSerach.log" );
    //general.errLog( "customerID: "+customerID, "CustSerach.log" );

    if (customerSvc == null)
    {
      customerSvc = createCustomerService();
    }
    
    MsgRqHdrCType msgRq = new MsgRqHdrCType();
    msgRq.setJXchangeHdr(generateJXChangeHeader(username));

    CustIdType custID = new CustIdType();
    custID.setValue(customerID);    

    IncXtendElemInfoCType incXTendElemInfo_xTaxDetail = new IncXtendElemInfoCType();
    incXTendElemInfo_xTaxDetail.setXtendElem("x_TaxDetail");
    
    IncXtendElemInfoCType incXTendElemInfo_xPersonName = new IncXtendElemInfoCType();
    incXTendElemInfo_xPersonName.setXtendElem("x_PersonName");

    IncXtendElemAType incXTendArray = new IncXtendElemAType();
    incXTendArray.getIncXtendElemInfos().add(incXTendElemInfo_xTaxDetail);
    incXTendArray.getIncXtendElemInfos().add(incXTendElemInfo_xPersonName);
    
    CustInq custInqReq = new CustInq();
    custInqReq.setMsgRqHdr(msgRq);
    custInqReq.setCustId(custID);
    custInqReq.setIncXtendElemArray(incXTendArray);
    
    CustInqResponse custInqResp = customerSvc.custInq(custInqReq);

    //general.errLog( "END doCustomerInquiry(inVec)", "CustSerach.log" );

    return custInqResp;
  }


  /**
   * This method executes the CustomerAdd web service call to JXChange. 
   * 
   */
  private CustAddResponse doCustomerAdd(String username, String branchRefID, DataNode bwrNode, DataNode primaryApplicantNode,
                                        CustomerService customerSvc, boolean isCustodian)
  throws MessageFault
  {
      HashtableX applicantFields = bwrNode.getFieldData("");
      HashtableX primaryApplicantFields = primaryApplicantNode.getFieldData("");
          
      if (customerSvc == null)
      {
        customerSvc = createCustomerService();
      }
      
      CustAdd custAddReq = new CustAdd();
      
      /* ***********************************************
      *  CustAdd:MsgRqHdr                              *
      * ************************************************/ 
      MsgRqHdrCType msgRq = new MsgRqHdrCType();
      msgRq.setJXchangeHdr(generateJXChangeHeader(username));
      custAddReq.setMsgRqHdr(msgRq);

      /* ***********************************************
      *  CustAdd:CustDetail                            *
      * ************************************************/ 
      CustDetailCType customerDetail = new CustDetailCType();      

      /* ***********************************************
      *  CustAdd:CustDetail:PersonaName                *
      * ************************************************/       
      PersonNameCType personName = new PersonNameCType();
          
      //CustAdd:CustDetail:PersonName:FirstName
      String fName = isCustodian? (String)applicantFields.get("minFName") : (String)applicantFields.get(CSFieldNames.FN_F_NAME);
      if (fName != null) 
      {     
          FirstNameType firstName = new FirstNameType();
          firstName.setValue(fName);
          personName.setFirstName(firstName);
      }
      
      //CustAdd:CustDetail:PersonName:MiddleName
      String mName = isCustodian? (String)applicantFields.get("minMName") : (String)applicantFields.get(CSFieldNames.FN_M_NAME);
      if (mName != null) 
      {
          MiddleNameType middleName = new MiddleNameType();
          middleName.setValue(mName);
          personName.setMiddleName(middleName);    
      }
        
      //CustAdd:CustDetail:PersonName:LastName
      String lName = isCustodian? (String)applicantFields.get("minLName") : (String)applicantFields.get(CSFieldNames.FN_L_NAME);
      if (lName != null) 
      {
          LastNameType lastName = new LastNameType();
          lastName.setValue(lName);
          personName.setLastName(lastName);
      }
      
      /* ***********************************************
      *  CustAdd:CustDetail:PersonaName:XPersonName    *
      * ************************************************/        
      XPersonNameCType xPersonName = new XPersonNameCType();
      
      //CustAdd:CustDetail:PersonaName:XPersonName:TitlePrefix
      String tPrefix = isCustodian? (String)applicantFields.get("minSalD") : (String)applicantFields.get(CSFieldNames.FN_NAME_SALUTE);
      if (tPrefix != null) 
      {
          TitlePrefixType titlePrefix = new TitlePrefixType();    
          titlePrefix.setValue(tPrefix);
          xPersonName.setTitlePrefix(titlePrefix);     
      }
      
      //CustAdd:CustDetail:PersonaName:XPersonName:NameSuffix
      String nSuffix = isCustodian? (String)applicantFields.get("minSuffixD") : (String)applicantFields.get(CSFieldNames.FN_NAME_SFX);
      if (nSuffix != null) 
      {
          NameSuffixType nameSuffix = new NameSuffixType();    
          nameSuffix.setValue(nSuffix);
          xPersonName.setNameSuffix(nameSuffix);
      }      
      personName.setXPersonName(xPersonName);
            
      customerDetail.setPersonName(personName);


      /* ***********************************************
      *  CustAdd:CustDetail:Addr                       *
      * ************************************************/  
      AddrCType address = new AddrCType();
            
      Boolean isMinMailSameAsPrmAddrC = false;
      // if Minor's address is the same as the primary
      if ((((String)applicantFields.get("minMailSameAsPrmAddrC")) != null) && (((String)applicantFields.get("minMailSameAsPrmAddrC")).equalsIgnoreCase("true"))) 
      {
          isMinMailSameAsPrmAddrC = true;
      }
      
      
      //CustAdd:CustDetail:Addr:Street1      
      String applicantStreet1 = null;
      if (isCustodian) 
      {
          if (!isMinMailSameAsPrmAddrC) 
          {
              applicantStreet1 = (String)applicantFields.get("minAddr");
          }
          else           
          {
              // if minor address is same as primary address, get street 1 from primary
              String addressType = (String)primaryApplicantFields.get(CSFieldNames.FN_BWR_ADDR_TYPE);
              // Standard address
              if (addressType.equalsIgnoreCase("0")) 
              {
                  applicantStreet1 = AppImportUtils.createAddressLine(primaryApplicantFields);
              }
              // Rural Route
              else if (addressType.equalsIgnoreCase("1")) 
              {
                  applicantStreet1 = (String)primaryApplicantFields.get("atRtTypeD") + "Number: " + (String)primaryApplicantFields.get(CSFieldNames.FN_BWR_RT_NUM) + " Box:" + (String)primaryApplicantFields.get(CSFieldNames.FN_BWR_BOX_NUM);
              }
              // PO BOX
              else if (addressType.equalsIgnoreCase("2"))
              {
                  applicantStreet1 = "PO Box " + (String)primaryApplicantFields.get(CSFieldNames.FN_BWR_PO_BOX);
              }
          }
      }
      else
      {
          String addressType = (String)applicantFields.get(CSFieldNames.FN_BWR_ADDR_TYPE);
          // Standard address
          if (addressType.equalsIgnoreCase("0")) 
          {
              applicantStreet1 = AppImportUtils.createAddressLine(applicantFields);
          }
          // Rural Route
          else if (addressType.equalsIgnoreCase("1")) 
          {
              applicantStreet1 = (String)applicantFields.get("atRtTypeD") + "Number: " + (String)applicantFields.get(CSFieldNames.FN_BWR_RT_NUM) + " Box:" + (String)applicantFields.get(CSFieldNames.FN_BWR_BOX_NUM);
          }
          // PO BOX
          else if (addressType.equalsIgnoreCase("2"))
          {
              applicantStreet1 = "PO Box " + (String)applicantFields.get(CSFieldNames.FN_BWR_PO_BOX);
          }
      }
      if (applicantStreet1 != null)
      {
          StreetAddr1Type street1 = new StreetAddr1Type();
          street1.setValue(applicantStreet1);
          address.setStreetAddr1(street1);
      }

      //CustAdd:CustDetail:Addr:Street2
      String applicantStreet2 = null;
      if (isCustodian)
      {
          if (!isMinMailSameAsPrmAddrC) 
          {
              applicantStreet2 = (String)applicantFields.get("minAddrTwo");
          }
          else
          {
              // if minor address is same as primary address, get street 2 from primary
              applicantStreet2 = (String)primaryApplicantFields.get(CSFieldNames.FN_BWR_ADDR_TWO);
          }
      }
      else
      {
          applicantStreet2 = (String)applicantFields.get(CSFieldNames.FN_BWR_ADDR_TWO);
      }
      if (applicantStreet2 != null) 
      {
          StreetAddr2Type street2 = new StreetAddr2Type();
          street2.setValue(applicantStreet2);
          address.setStreetAddr2(street2);
      }
      
      //CustAdd:CustDetail:Addr:City
      String applicantCity = null;
      if (isCustodian)
      {
          if (!isMinMailSameAsPrmAddrC) 
          {
            applicantCity = (String)applicantFields.get("minCity");
          }
          else
          {
              // if minor address is same as primary address, get city from primary
              applicantCity = (String)primaryApplicantFields.get(CSFieldNames.FN_BWR_CITY);
          }
      }
      else 
      {
          applicantCity = (String)applicantFields.get(CSFieldNames.FN_BWR_CITY);          
      }
      if (applicantCity != null) 
      {
          CityType city = new CityType();
          city.setValue(applicantCity);
          address.setCity(city);
      }
      
      //CustAdd:CustDetail:Addr:StateProv
      String applicantStateProv = null;
      if (isCustodian)
      {
          if (!isMinMailSameAsPrmAddrC) 
          {
              applicantStateProv = (String)applicantFields.get("minProv");
          }
          else
          {
              // if minor address is same as primary address, get province from primary
              applicantStateProv = (String)primaryApplicantFields.get(CSFieldNames.FN_BWR_PROVINCE);
          }
      }
      else 
      {
          applicantStateProv = (String)applicantFields.get(CSFieldNames.FN_BWR_PROVINCE);          
      }
      if (applicantStateProv != null)
      {
          StateProvType stateProv = new StateProvType();
          stateProv.setValue(applicantStateProv);
          address.setStateProv(stateProv);
      } 
      
      //CustAdd:CustDetail:Addr:StateCode     
      String applicantState = null;
      if (isCustodian)
      {
          if (!isMinMailSameAsPrmAddrC) 
          {
              applicantState = (String)applicantFields.get("minStD");
          }
          else
          {
              // if minor address is same as primary address, get state from primary
              applicantState = (String)primaryApplicantFields.get(CSFieldNames.FN_BWR_STATE);
          }
      }
      else 
      {
          applicantState = (String)applicantFields.get(CSFieldNames.FN_BWR_STATE);          
      }
      if (applicantState != null) 
      {
          StateCodeType stateCode = new StateCodeType();    
          stateCode.setValue(applicantState);  
          address.setStateCode(stateCode);
      }
      
      Boolean isForeignAddr = false;
      if (isCustodian)
      {
          if (!isMinMailSameAsPrmAddrC) 
          {
              if ((String)applicantFields.get("minFrgnAddrC") != null)
              {
                  if (((String)applicantFields.get("minFrgnAddrC")).equalsIgnoreCase("true")) 
                  {
                      isForeignAddr = true;
                  }
              }
          }
          else 
          {
              // if minor address is same as primary address, get foreign address check from primary
              if ((String)primaryApplicantFields.get(CSFieldNames.FN_BWR_FRGN_ADDR) != null)
              {
                  if (((String)primaryApplicantFields.get(CSFieldNames.FN_BWR_FRGN_ADDR)).equalsIgnoreCase("true")) 
                  {
                      isForeignAddr = true;
                  }
              } 
          }
      }
      else
      {
          if ((String)applicantFields.get(CSFieldNames.FN_BWR_FRGN_ADDR) != null)
          {
              if (((String)applicantFields.get(CSFieldNames.FN_BWR_FRGN_ADDR)).equalsIgnoreCase("true")) 
              {
                  isForeignAddr = true;
              }
          }
      }
        
      //CustAdd:CustDetail:Addr:PostalCode  
      PostalCodeType postalCode = new PostalCodeType();
      if (isForeignAddr) 
      {
          String applicantPstlCd = null;
          if (isCustodian)
          {
              if (!isMinMailSameAsPrmAddrC) 
              {
                  applicantPstlCd = (String)applicantFields.get("minPstlCd");
              }
              else
              {
                  // if minor address is same as primary address, get postal code from primary
                  applicantPstlCd = (String)primaryApplicantFields.get(CSFieldNames.FN_BWR_POSTAL_CODE);
              }
          }
          else 
          {
              applicantPstlCd = (String)applicantFields.get(CSFieldNames.FN_BWR_POSTAL_CODE);
          }
          if (applicantPstlCd == null || applicantPstlCd.equalsIgnoreCase("")) applicantPstlCd = "000000000";
          postalCode.setValue(applicantPstlCd);
      }
      else 
      {
          String applicantZip = null;
          String applicantZipPlus = null;
          if (isCustodian)
          {
              if (!isMinMailSameAsPrmAddrC) 
              {
                  applicantZip = (String)applicantFields.get("minZip");
                  applicantZipPlus = (String)applicantFields.get("minZipPlus");
              }
              else
              {
                  // if minor address is same as primary address, get zip codes from primary
                  applicantZip = (String)primaryApplicantFields.get(CSFieldNames.FN_BWR_ZIP);
                  applicantZipPlus = (String)primaryApplicantFields.get(CSFieldNames.FN_BWR_ZIP_PLUS);
              }
          }
          else 
          {
              applicantZip = (String)applicantFields.get(CSFieldNames.FN_BWR_ZIP);
              applicantZipPlus = (String)applicantFields.get(CSFieldNames.FN_BWR_ZIP_PLUS);
          }
          if (applicantZip == null || applicantZip.equalsIgnoreCase("")) applicantZip = "00000";
          if (applicantZipPlus == null || applicantZipPlus.equalsIgnoreCase("")) applicantZipPlus = "0000";
          postalCode.setValue(applicantZip+applicantZipPlus);
      }
      address.setPostalCode(postalCode);
      
      //CustAdd:CustDetail:Addr:County
      String applicantCounty = (String)applicantFields.get(CSFieldNames.FN_BWR_COUNTY);
      if (applicantCounty != null) 
      {
          CountyType county = new CountyType();    
          county.setValue(applicantCounty);
          address.setCounty(county);
      }
      
      //CustAdd:CustDetail:Addr:Country
      String applicantCountry = null;
      if (isCustodian)
      {
          if (!isMinMailSameAsPrmAddrC) 
          {
              applicantCountry = (String)applicantFields.get("minCntry");
          }
          else
          {
              // if minor address is same as primary address, get country from primary
              applicantCountry = (String)primaryApplicantFields.get(CSFieldNames.FN_BWR_COUNTRY);
          }
      }
      else
      {
          applicantCountry = (String)applicantFields.get(CSFieldNames.FN_BWR_COUNTRY);
          
      }          
      if ((applicantCountry != null) && (isForeignAddr))
      {
          CntryTypeType country = new CntryTypeType();    
          country.setValue(applicantCountry);
          address.setCntryType(country);
      }
      
      //CustAdd:CustDetail:Addr:FornAddr
      String applicantFrgnAddr = isCustodian? (String)applicantFields.get("minFrgnAddrC") : (String)applicantFields.get(CSFieldNames.FN_BWR_FRGN_ADDR);
      if (applicantFrgnAddr != null)
      {
          FornAddrType foreignAddress = new FornAddrType();
          foreignAddress.setValue(applicantFrgnAddr);
          address.setFornAddr(foreignAddress); 
      }
            
      customerDetail.setAddr(address);
            
      /* ****************************************************************************************
      *  CustAdd:CustDetail:CustType  (Required field - Individual code must be Y or N)         *
      * *****************************************************************************************/ 
      CustTypeType custType = new CustTypeType();
      custType.setValue("Y");
      customerDetail.setCustType(custType);
      
      
      /* ***********************************************
      *  CustAdd:CustDetail:BirthDt                    *
      * ************************************************/ 
      String dob = (isCustodian ? (String)applicantFields.get("minBirthDt") : (String)applicantFields.get(CSFieldNames.FN_BIRTH_DT));
      if ((dob != null) && (dob.length() == 10))
      {
          try
          {
              GregorianCalendar gc = new GregorianCalendar(
                                           Integer.parseInt(dob.substring(6)),
                                           Integer.parseInt(dob.substring(0,2)), 
                                           Integer.parseInt(dob.substring(3,5)));  
              DatatypeFactory df = DatatypeFactory.newInstance();
              XMLGregorianCalendar birthDateGC = df.newXMLGregorianCalendar(gc);
              BirthDtType birthDate = new BirthDtType();
              birthDate.setValue(birthDateGC);
              customerDetail.setBirthDt(birthDate);
          }
          catch ( Exception e )
          {
              ExceptionLogger.logException(e);
          }
      }
      
      /* ***********************************************
      *  CustAdd:CustDetail:EmplName                   *
      * ************************************************/ 
      String applicantEmployer = (String)applicantFields.get("atEmp");
      if (applicantEmployer != null)
      {
          EmplNameType employerName = new EmplNameType();
          employerName.setValue(applicantEmployer);
          customerDetail.setEmplName(employerName);
      }
      
      /* ***********************************************
      *  CustAdd:CustDetail:OccType                    *
      * ************************************************/ 
      String applicantOccupation = (String)applicantFields.get("atPos");
      if (applicantOccupation != null) 
      {
          OccTypeType occupation = new OccTypeType();
          occupation.setValue(applicantOccupation);    
          customerDetail.setOccType(occupation);    
      }
      
      /* ***********************************************
      *  CustAdd:CustDetail:EmailArray                 *
      * ************************************************/
      String applicantEmail = isCustodian? (String)applicantFields.get("minEmail") : (String)applicantFields.get(CSFieldNames.FN_EMAIL);
      if (applicantEmail != null)
      {
          EmailArrayAType emailArray = new EmailArrayAType();
          EmailInfoCType emailInfo = new EmailInfoCType();
          EmailAddrType emailAddr = new EmailAddrType();
          emailAddr.setValue(applicantEmail);
          EmailTypeType emailType = new EmailTypeType();
          emailType.setValue("Primary E-Mail");
          emailInfo.setEmailAddr(emailAddr);
          emailInfo.setEmailType(emailType);
          emailArray.getEmailInfos().add(emailInfo);
          customerDetail.setEmailArray(emailArray);
      } 
      
      
      /* ***********************************************
      *  CustAdd:CustDetail:PhoneArray                 *
      * ************************************************/
      PhoneArrayAType phoneArray = new PhoneArrayAType();          
            
      //CustAdd:CustDetail:PhoneArray:Home Phone
      PhoneInfoCType homePhoneInfo = new PhoneInfoCType();
      PhoneNumType homePhoneNumber = new PhoneNumType();
      PhoneTypeType homePhoneType = new PhoneTypeType();    
      String applicantHomePhone = (isCustodian? (String)applicantFields.get("minPh") : (String)applicantFields.get(CSFieldNames.FN_HOME_PH));           
      if ((applicantHomePhone != null) && (applicantHomePhone.length() == 14))
      {
          String homeAreaCode = applicantHomePhone.substring(1, 4);
          String homePhoneNum = applicantHomePhone.substring(6,9) + applicantHomePhone.substring(10);                    
          homePhoneNumber.setValue(homeAreaCode+homePhoneNum);
          homePhoneType.setValue("Home Phone");
          homePhoneInfo.setPhoneNum(homePhoneNumber);
          homePhoneInfo.setPhoneType(homePhoneType);
          phoneArray.getPhoneInfos().add(homePhoneInfo);
      }
               
      //CustAdd:CustDetail:PhoneArray:Cellular
      PhoneInfoCType cellPhoneInfo = new PhoneInfoCType();
      PhoneNumType cellPhoneNumber = new PhoneNumType();
      PhoneTypeType cellPhoneType = new PhoneTypeType();
      String applicantCellPhone = (String)applicantFields.get("atCellPh");           
      if ((applicantCellPhone != null) && (applicantCellPhone.length() == 14))
      {
          String cellAreaCode = applicantCellPhone.substring(1, 4);
          String cellPhoneNum = applicantCellPhone.substring(6,9) + applicantCellPhone.substring(10);
          cellPhoneNumber.setValue(cellAreaCode+cellPhoneNum);
          cellPhoneType.setValue("Home Cell Phone");
          cellPhoneInfo.setPhoneNum(cellPhoneNumber);
          cellPhoneInfo.setPhoneType(cellPhoneType);
          phoneArray.getPhoneInfos().add(cellPhoneInfo);
      }
            
      //CustAdd:CustDetail:PhoneArray:Fax
      PhoneInfoCType faxPhoneInfo = new PhoneInfoCType();
      PhoneNumType faxPhoneNumber = new PhoneNumType();
      PhoneTypeType faxPhoneType = new PhoneTypeType();
      String applicantFax = (String)applicantFields.get("atFax");           
      if ((applicantFax != null) && (applicantFax.length() == 14))
      {
          String faxAreaCode = applicantFax.substring(1, 4);
          String faxPhoneNum = applicantFax.substring(6,9) + applicantFax.substring(10);
          faxPhoneNumber.setValue(faxAreaCode+faxPhoneNum);
          faxPhoneType.setValue("Home Fax Number");
          faxPhoneInfo.setPhoneNum(faxPhoneNumber);
          faxPhoneInfo.setPhoneType(faxPhoneType);
          phoneArray.getPhoneInfos().add(faxPhoneInfo);
      }
      
      //CustAdd:CustDetail:PhoneArray:Work      
      PhoneInfoCType workPhoneInfo = new PhoneInfoCType();
      PhoneNumType workPhoneNumber = new PhoneNumType();
      PhoneExtType workPhoneExt = new PhoneExtType();
      PhoneTypeType workPhoneType = new PhoneTypeType();
      String applicantWorkNum = (String)applicantFields.get(CSFieldNames.FN_EMP_PH);
      if ((applicantWorkNum != null) && (applicantWorkNum.length() == 14))
      {
          String workAreaCode = applicantWorkNum.substring(1, 4);
          String workPhoneNum = applicantWorkNum.substring(6,9) + applicantWorkNum.substring(10);
          workPhoneNumber.setValue(workAreaCode+workPhoneNum);
          workPhoneExt.setValue((String)applicantFields.get(CSFieldNames.FN_EMP_PH_EXT));
          workPhoneType.setValue("Business Phone");
          workPhoneInfo.setPhoneNum(workPhoneNumber);
          workPhoneInfo.setPhoneType(workPhoneType);
          phoneArray.getPhoneInfos().add(workPhoneInfo);
      }
      customerDetail.setPhoneArray(phoneArray);
      
      custAddReq.setCustDetail(customerDetail);
      
      /* ***********************************************
      *  CustAdd:TaxDetail                             *
      * ************************************************/
      TaxDetailCType taxDetail = new TaxDetailCType();   
      
      /* ***********************************************
      *  CustAdd:TaxDetail:TINInfo                     *
      * ************************************************/
      TINInfoCType taxInfo = new TINInfoCType();
      
      // CustAdd:TaxDetail:TINInfo:TinCode - Required field otherwise error - Tax ID type is not valid
      TINCodeType TINCode = new TINCodeType();
      TINCode.setValue("I");
      taxInfo.setTINCode(TINCode);
      
      //CustAdd:TaxDetail:TINInfo:TINDesc
      
      //CustAdd:TaxDetail:TINInfo:TaxId
      String ssn = isCustodian? (String)applicantFields.get("minSSN") : (String)applicantFields.get(CSFieldNames.FN_SSN);
      if (ssn != null) 
      {
          TaxIdType taxId = new TaxIdType();    
          if (ssn.indexOf('-') != -1) ssn = StringSupport.stripCharacter(ssn, '-');
          taxId.setValue(ssn);
          taxInfo.setTaxId(taxId);    
      }      
      //CustAdd:TaxDetail:TINInfo:TaxIdMod
      //CustAdd:TaxDetail:TINInfo:CertCode
      //CustAdd:TaxDetail:TINInfo:CertCodeDesc
      //CustAdd:TaxDetail:TINInfo:CertCodeDt
      //CustAdd:TaxDetail:TINInfo:BNotStat
      //CustAdd:TaxDetail:TINInfo:BNotIRSDt
      //CustAdd:TaxDetail:TINInfo:TaxIdOwnerName
      taxDetail.setTINInfo(taxInfo);
      
      custAddReq.setTaxDetail(taxDetail);
        
      /* ***********************************************
      *  CustAdd:BusDetail                             *
      * ************************************************/      
      BusDetailCType businessDetail = new BusDetailCType();
      //CustAdd:BusDetail:OffCode
      
      //CustAdd:BusDetail:CustCode - The code that further defines the customer. Required field, I for Individual
      CustCodeType businessCustCode = new CustCodeType();
      businessCustCode.setValue("I");
      businessDetail.setCustCode(businessCustCode);

      // Branch #
      //
      BrCodeType branchCode = new BrCodeType();
      branchCode.setValue(branchRefID);        
      businessDetail.setBrCode(branchCode);
      
      // Officer Code
      //
      OffCodeType officerCode = new OffCodeType();
      officerCode.setValue(branchRefID);        
      businessDetail.setOffCode(officerCode);

      //CustAdd:BusDetail:GroupCode - This code is used to group loans of different types for general ledger reporting purposes. It may also be used to group customer accounts together.
      //CustAdd:BusDetail:AbbrCustDesc - An abbreviated customer description with open-user free form text.
      
      custAddReq.setBusDetail(businessDetail);

      // Set the Error Override Array.
      //
      ErrOvrRdInfoArrayAType errOvrRdArray = new ErrOvrRdInfoArrayAType();
      List<ErrOvrRdCType> errOvrRdList = errOvrRdArray.getErrOvrRds();

      // Set the Error Override sub-types.
      //
      ErrOvrRdCType errOvrRdDetail = new ErrOvrRdCType();
      errOvrRdDetail.setErrCode( "410015" ); // Desc: Cell Phone Number required, may be overridden
      errOvrRdList.add( errOvrRdDetail );

      errOvrRdDetail = new ErrOvrRdCType();
      errOvrRdDetail.setErrCode( "410021" ); // Desc: E-Mail Address required, may be overridden
      errOvrRdList.add( errOvrRdDetail );

      errOvrRdDetail = new ErrOvrRdCType();
      errOvrRdDetail.setErrCode( "410022" ); // Desc: Other E-Mail Address required, may be overridden
      errOvrRdList.add( errOvrRdDetail );

      errOvrRdDetail = new ErrOvrRdCType();
      errOvrRdDetail.setErrCode( "410031" ); // Desc: Inquiry Code required, may be overridden
      errOvrRdList.add( errOvrRdDetail );

      errOvrRdDetail = new ErrOvrRdCType();
      errOvrRdDetail.setErrCode( "410066" ); // Desc: UserDefCode required, may be overridden
      errOvrRdList.add( errOvrRdDetail );

      custAddReq.setErrOvrRdInfoArray( errOvrRdArray );

      CustAddResponse custAddRsp = customerSvc.custAdd(custAddReq);
      return custAddRsp;
    }

  /**
   * This method executes the Service Default web service call to JXChange.  
   * 
   */
  private SvcDftResponse doServiceDefault(String username, CustomerService customerSvc, String serviceName,
                                          int serviceCallLvl, CriteriaArrayAType criteriaArray)
  throws MessageFault
  {
    if (customerSvc == null)
    {
        customerSvc = createCustomerService();
    }
      
    MsgRqHdrCType msgRq = new MsgRqHdrCType();
    msgRq.setJXchangeHdr(generateJXChangeHeader(username));
    
    SvcDft serviceDefault = new SvcDft();          
    serviceDefault.setMsgRqHdr(msgRq);  
    serviceDefault.setSvcName(serviceName);
    serviceDefault.setSvcCallLvl(serviceCallLvl);
    serviceDefault.setCriteriaArray(criteriaArray);

    return customerSvc.svcDft(serviceDefault);    
  }
  
  
  private CriteriaInfoCType addCriteria(String criteriaName, String criteriaValue)
  {
      CriteriaInfoCType criteriaInfo = new CriteriaInfoCType();
      criteriaInfo.setCriteriaName(criteriaName);
      criteriaInfo.setCriteriaVal(criteriaValue);
      return criteriaInfo;
  }
  
  
  /**
   * This method executes the AccountSearch web service call to JXChange.  Using the customer ID as
   * input, it returns a list of all accounts known to be tied to the customer.
   * 
   * @param customerID
   * @return
   * @throws MessageFault
   */
  private AcctSrchRecArrayAType doAccountSearch(String username, String customerID)
  throws MessageFault
  {
    InquiryService inquirySvc = createInquiryService();
        
    SrchMsgRqHdrCType searchMsgHeader = new SrchMsgRqHdrCType();
    searchMsgHeader.setJXchangeHdr(generateJXChangeHeader(username));
    searchMsgHeader.setMaxRec(30);

    CustIdType custID = new CustIdType();
    custID.setValue(customerID);
    
    AcctSrch acctSearch = new AcctSrch();
    acctSearch.setCustId(custID);
    acctSearch.setSrchMsgRqHdr(searchMsgHeader);
    
    AcctSrchResponse acctSearchResp = inquirySvc.acctSrch(acctSearch);
    AcctSrchRecArrayAType acctSearchRespArray = acctSearchResp.getAcctSrchRecArray();
    
    return acctSearchRespArray;
  }
  

  private TableTransaction generateCustomerSearchTable(List<CustSrchRecCType> results, Map<String, String> jhaCreateDateMap)
  {
    TableTransaction table = new TableTransaction();
    table.getFields().add("Customer #");
    table.getFields().add("Name                  ");
    table.getFields().add("Create Date");
    
    table.getKeyFlags().add("true");
    table.getKeyFlags().add("false");
    table.getKeyFlags().add("false");
    
    if (results != null)
    {
      TableRecord tr;
      String customerID, date;
      for (CustSrchRecCType searchRecord : results)
      {
        tr = new TableRecord();
        
        // Customers' ID #
        //
        customerID = searchRecord.getCustId().getValue();
        tr.addColumnData(customerID);
        
        // Customer's Name
        //
        PersonNameCType personName = searchRecord.getPersonName();
        tr.addColumnData(personName != null ? personName.getComName().getValue() : "");
        
        // Creation Date in Jack Henry system.
        //
        date = jhaCreateDateMap.get(customerID);
        tr.addColumnData(date != null ? date : "");

        table.getRecords().add(tr);        
      }
    }
    
    return table;
  }
  
  private VectorX generateCustomerSearchHashtables(List<CustSrchRecCType> results, Map<String, String> jhaCreateDateMap)
  {
    VectorX accounts = new VectorX();
    if (results != null)
    {
        String customerID, date;
        
        for (CustSrchRecCType searchRecord : results)
        {
            HashtableX acctHash = new HashtableX();
            
            // Customers' ID #
            customerID = searchRecord.getCustId().getValue();
            acctHash.put("customerID", customerID);
        
            // Customer's Name
            PersonNameCType personName = searchRecord.getPersonName();
            acctHash.put("customerName", (personName != null ? personName.getComName().getValue() : ""));

            // Creation Date in Jack Henry system.
            date = jhaCreateDateMap.get(customerID);
            acctHash.put("createDate",(date != null ? date : ""));
            
            accounts.add(acctHash);        
        }
    }
      
    return accounts;
  }
    
  private TableTransaction generateCustomerAccountTable(List<AcctSrchRecCType> acctList)
  {
    TableTransaction table = new TableTransaction();
    
    table.getFields().add("Account #    ");
    table.getFields().add("Type         ");
    table.getFields().add("Status       ");
    table.getFields().add("Description            ");
    table.getFields().add("Amount      ");
    
    table.getKeyFlags().add("false");
    table.getKeyFlags().add("false");
    table.getKeyFlags().add("false");
    table.getKeyFlags().add("false");
    table.getKeyFlags().add("false");
    
    if (acctList != null)
    {
      TableRecord tr;

      for (AcctSrchRecCType acctSrchRec : acctList)
      {        
        tr = new TableRecord();
        
        AccountIdCType accountIDType = acctSrchRec.getAccountId();
        
        AcctIdType acctIDType = accountIDType.getAcctId();
        String accountID = acctIDType.getValue();
        tr.addColumnData(accountID);
                
        AcctTypeType acctTypeType = accountIDType.getAcctType();
        String accountType = acctTypeType.getValue();
        tr.addColumnData(accountType != null ? translateAccountTypeCode(accountType) : "");

        String acctStatusDesc = acctSrchRec.getAcctStatDesc();
        if (acctStatusDesc == null) acctStatusDesc = "";
        tr.addColumnData(acctStatusDesc);
        
        String productDesc = acctSrchRec.getProdDesc();
        tr.addColumnData(productDesc != null ? productDesc : "");
        
        AmtType amountType = acctSrchRec.getAmt();
        BigDecimal amount = amountType.getValue();
        tr.addColumnData(amount != null ? String.format("$%s", amount.toString()) : "");

        table.getRecords().add(tr);
        
        // We've gotten what we can out of the search results, now we have to get the
        // finer details of the account from the account inquiry transaction.  Right
        // now we are only going to get the current balance of the account.
        //
        /*
        String balance = doAccountInquiry(inquirySvc, accountIDType);
        System.out.println("Bal: " + balance);
        System.out.println("---------------------");
        */
        
      }
    }
    
    return table;
  }
  
  
  private Map<String, String> createCustomerOrgDateMapping(String username, List<CustSrchRecCType> searchRecords)
  throws MessageFault
  {
    Map<String, String> dateMap = new HashMap<String, String>();
    
    CustomerService customerSvc = createCustomerService();
    
    for (CustSrchRecCType searchRecord : searchRecords)
    {
      String customerID = searchRecord.getCustId().getValue();
      
      CustInqResponse customerInqResponse = doCustomerInquiry(username, customerID, customerSvc);
      
      CustRecCType customerRecord = customerInqResponse.getCustRec();
      
      CustDetailCType customerDetail = customerRecord.getCustDetail();
      if (customerDetail != null)
      {
        CustOrgDtType custOrgDtType = customerDetail.getCustOrgDt();
        if (custOrgDtType != null)
        {
          XMLGregorianCalendar xmlGC = custOrgDtType.getValue();
          if (xmlGC != null)
          {
            String theDate = DateUtility.formatDate(xmlGC.toGregorianCalendar().getTime());
            dateMap.put(customerID, theDate);
          }
        }
      }
    }
            
    return dateMap;
  }
  
  
  private HashtableX generateApplicantFieldsFromCustInq(CustInqResponse custInqResp, boolean isCustodian)
  {    
    HashtableX applicantFields = new HashtableX();
    

    List<String> clearFieldList = isCustodian ? Arrays.asList("minSalD", "minFName", "minMName", "minLName", "minSuffixD",
                                                              "minBirthDt", "minSSN", "minEmail", "minCIF", "minFrgnAddrC",
                                                              "minPh", "minAddr", "minAddrTwo", "minCity", "minStD",
                                                              "minZip", "minZipPlus") :    
                                                Arrays.asList("atFName","atMName","atLName","atSalD","atSuffixD",
                                                              "atAddress","atAddrTwo","atFrgnAddrC","atCity","atStD",
                                                              "atCntyD","atPstlCd","atZip","atZipPlus","atProv","atCntry",
                                                              "atBirthDt","atEmp","atPos","atEmail","atPh","atEmpPh",
                                                              "atEmpPhExt","atFax","atCellPh","atCIF","atSSN");
    for (String clearField : clearFieldList) 
    {
      applicantFields.put(clearField, "");
    }
    
    CustRecCType customerRecord = custInqResp.getCustRec();
    
    // Grab the customer ID.
    //
    CustIdType custIdType = customerRecord.getCustId();
    applicantFields.put(isCustodian ? "minCIF" : CSFieldNames.FN_CUST_NUM, custIdType.getValue());
    
    // From the customer record, get the customer details.
    //
    CustDetailCType customerDetails = customerRecord.getCustDetail();
    
    // Get the customer name details.
    //
    PersonNameCType personDetails = customerDetails.getPersonName();
    if (personDetails != null)
    {
      FirstNameType firstName = personDetails.getFirstName();
      if (firstName != null) applicantFields.put(isCustodian ? "minFName" : CSFieldNames.FN_F_NAME, firstName.getValue());
      
      MiddleNameType middleName = personDetails.getMiddleName();
      if (middleName != null) applicantFields.put(isCustodian ? "minMName" : CSFieldNames.FN_M_NAME, middleName.getValue());
      
      LastNameType lastName = personDetails.getLastName();
      if (lastName != null) applicantFields.put(isCustodian ? "minLName" : CSFieldNames.FN_L_NAME, lastName.getValue());
      
      XPersonNameCType xPerson = personDetails.getXPersonName();
      if (xPerson != null)
      {
        TitlePrefixType titlePrefix = xPerson.getTitlePrefix();
        if (titlePrefix != null) applicantFields.put(isCustodian ? "minSalD" : CSFieldNames.FN_NAME_SALUTE, titlePrefix.getValue());
          
        NameSuffixType nameSuffix = xPerson.getNameSuffix();
        if (nameSuffix != null) applicantFields.put(isCustodian ? "minSuffixD" : CSFieldNames.FN_NAME_SFX, nameSuffix.getValue());
      }
    }
        
    // Get the customer address details.
    //
    AddrCType addrDetails = customerDetails.getAddr();
    if (addrDetails != null) 
    {
      StreetAddr1Type streetAddr1 = addrDetails.getStreetAddr1();
      if (streetAddr1 != null)
      {
        if (isCustodian)
        {
          applicantFields.put("minAddr", streetAddr1.getValue());
        }
        else
        {
          try
          {
            Map addrMap = AppImportUtils.reformatAddress("atAddress", streetAddr1.getValue(), true);
            if(addrMap != null && !addrMap.isEmpty())
            {
              applicantFields.putAll(addrMap);
            }
            else
            {
              throw new Exception( "Unable to format address line." );
            }
          }
          catch( Exception e )
          {
            ExceptionLogger.logException(e);
            applicantFields.putAll(AppImportUtils.parseAddressLineFiserv(streetAddr1.getValue()));
          }
        }
      }
      
      StreetAddr2Type streetAddr2 = addrDetails.getStreetAddr2();
      if (streetAddr2 != null) applicantFields.put(isCustodian ? "minAddrTwo" : CSFieldNames.FN_BWR_ADDR_TWO, streetAddr2.getValue());
    
      Boolean isForeignAddr = false;
      FornAddrType foreignAddr = addrDetails.getFornAddr();
      if (foreignAddr != null) 
      {
        if (foreignAddr.getValue().equalsIgnoreCase("Y")) isForeignAddr = true;
      }
      applicantFields.put(isCustodian? "minFrgnAddrC" : CSFieldNames.FN_BWR_FRGN_ADDR, isForeignAddr);
      
      CityType city = addrDetails.getCity();
      if (city != null) applicantFields.put(isCustodian ? "minCity" : CSFieldNames.FN_BWR_CITY, city.getValue());
        
      StateCodeType state = addrDetails.getStateCode();
      if (state != null) applicantFields.put(isCustodian ? "minStD" : CSFieldNames.FN_BWR_STATE, state.getValue());
      
      CountyType county = addrDetails.getCounty();
      if (county != null) applicantFields.put(CSFieldNames.FN_BWR_COUNTY, county.getValue());
      
      PostalCodeType postalCode = addrDetails.getPostalCode();
      if (postalCode != null) 
      {
        String postalCodeStr = postalCode.getValue();
        // if foregin address postalCode = atPstlCd
        if (isForeignAddr)
        {
          if (!postalCodeStr.equalsIgnoreCase("000000000")) 
          {
            applicantFields.put(isCustodian ? "minPstlCd" : CSFieldNames.FN_BWR_POSTAL_CODE, postalCodeStr);
          }
        }
        // else postalCode = atZip + atZipPlus
        else
        {
          String zip = postalCodeStr.substring(0, 5);
          String zipPlus = postalCodeStr.substring(5);
          if (!zip.equalsIgnoreCase("00000")) applicantFields.put(isCustodian ? "minZip" : CSFieldNames.FN_BWR_ZIP, zip);
          if (!zipPlus.equalsIgnoreCase("0000")) applicantFields.put(isCustodian ? "minZipPlus" : CSFieldNames.FN_BWR_ZIP_PLUS, zipPlus);              
        }          
      }
      
      if (isForeignAddr) 
      {
        StateProvType stateProv = addrDetails.getStateProv();
        if (stateProv != null) applicantFields.put(isCustodian ? "minProv" : CSFieldNames.FN_BWR_PROVINCE, stateProv.getValue());
        
        CntryType country = addrDetails.getCntry();
        if (country != null) applicantFields.put(isCustodian ? "minCntry" : CSFieldNames.FN_BWR_COUNTRY, country.getValue());
      }
    }
    
    // Get the customer birth date.
    //
    BirthDtType birthDate = customerDetails.getBirthDt();
    if (birthDate != null)
    {
      XMLGregorianCalendar birthDateGC = birthDate.getValue();
      if (birthDateGC != null) applicantFields.put(isCustodian ? "minBirthDt" :CSFieldNames.FN_BIRTH_DT,
                                                   String.format("%02d/%02d/%04d",
                                                                 birthDateGC.getMonth(),
                                                                 birthDateGC.getDay(),
                                                                 birthDateGC.getYear()));
    }
    
    // Get the employer name.
    //
    EmplNameType employerName = customerDetails.getEmplName();
    if (employerName != null) applicantFields.put("atEmp", employerName.getValue());
    
    // Get the occupation of the applicant.
    //
    OccTypeType occupation = customerDetails.getOccType();
    if (occupation != null) applicantFields.put("atPos", occupation.getValue());
    
    // Get the email address.  It looks like JXChange can return a primary and
    // a secondary.  We only collect 1 email address, so we'll look for the
    // primary address.
    //
    EmailArrayAType emailArray = customerDetails.getEmailArray();
    if (emailArray != null)
    {
      List<EmailInfoCType> emailInfoList = emailArray.getEmailInfos();
      if (emailInfoList != null)
      {
        for (EmailInfoCType emailInfo : emailInfoList)
        {
          EmailTypeType emailType = emailInfo.getEmailType();
          if (emailType != null && emailType.getValue().equals("Primary E-Mail"))
          {
            EmailAddrType emailAddrType = emailInfo.getEmailAddr();
            if (emailAddrType != null)
            {
              applicantFields.put(isCustodian ? "minEmail" : CSFieldNames.FN_EMAIL, emailAddrType.getValue());
              break;
            }
          }
        }
      }
      
      // Get Phone numbers
      // P.S. Only "Business Phone" has the Extension
      PhoneArrayAType phoneArray = customerDetails.getPhoneArray();
      if (phoneArray != null) 
      {
          List<PhoneInfoCType> phoneInfoList = phoneArray.getPhoneInfos();
          if (phoneInfoList != null) 
          {
              String phoneTypeStr = "";
              String phoneNumStr = "";
              for (PhoneInfoCType phoneInfo : phoneInfoList) 
              {
                  PhoneTypeType phoneType = phoneInfo.getPhoneType();
                  PhoneNumType phoneNumType = phoneInfo.getPhoneNum();
                  PhoneExtType phoneExtType = phoneInfo.getPhoneExt();
                  if (phoneType != null && phoneNumType != null)
                  {
                      phoneTypeStr = phoneType.getValue();
                      phoneNumStr = phoneNumType.getValue();
                      if (phoneNumStr.length() == 10)
                      {
                          if (phoneTypeStr.equalsIgnoreCase("Home Phone"))
                          {
                            applicantFields.put(isCustodian ? "minPh" : CSFieldNames.FN_HOME_PH, String.format("(%s) %s-%s", phoneNumStr.substring(0, 3), phoneNumStr.substring(3, 6), phoneNumStr.substring(6, 10)));
                          }
                          
                          if (phoneTypeStr.equalsIgnoreCase("Business Phone")) 
                          {
                            applicantFields.put(CSFieldNames.FN_EMP_PH, String.format("(%s) %s-%s", phoneNumStr.substring(0, 3), phoneNumStr.substring(3, 6), phoneNumStr.substring(6, 10)));
                            if ((phoneExtType != null) && !phoneExtType.getValue().equalsIgnoreCase("0")) applicantFields.put(CSFieldNames.FN_EMP_PH_EXT,phoneExtType.getValue());
                          }
                          if (phoneTypeStr.equalsIgnoreCase("Home Fax Number")) applicantFields.put("atFax", String.format("(%s) %s-%s", phoneNumStr.substring(0, 3), phoneNumStr.substring(3, 6), phoneNumStr.substring(6, 10)));
                          if (phoneTypeStr.equalsIgnoreCase("Home Cell Phone")) applicantFields.put("atCellPh", String.format("(%s) %s-%s", phoneNumStr.substring(0, 3), phoneNumStr.substring(3, 6), phoneNumStr.substring(6, 10)));
                      }
                  }
              }
          }
      }
      
      // Grab the SSN
      //
      XTaxDetailCType xTaxDetail = custInqResp.getXTaxDetail();
      if (xTaxDetail != null)
      {
          TaxDetailCType taxDetail = xTaxDetail.getTaxDetail();
          if (taxDetail != null)
          {
            TINInfoCType tinInfo = taxDetail.getTINInfo();
            if (tinInfo != null)
            {
              TaxIdType taxIdType = tinInfo.getTaxId();
              if (taxIdType != null) applicantFields.put(isCustodian ? "minSSN" : CSFieldNames.FN_SSN, taxIdType.getMaskVal());
            }
          }
      }
      
      // CustDetail:CustType 
      // - This is the customer type, Y for Individual or N for Business customer
      // CustTypeType custType = customerDetails.getCustType();
    
      // CustDetail:NAICSCode 
      // - This is a valid NAICS (Northern American Industry Classification System) code. Value is passed from
      //   the service of record during the pilot phase.  Must be set up in bank parameter if entered.
      // NAICSCodeType NAICSCode = customerDetails.getNAICSCode();
    
      // CustDetail:StdIndustCode 
      // - This is the standard industry code. Must be set up in bank parameter if entered.
      // StdIndustCodeType StdIndustCode = customerDetails.getStdIndustCode();
    
      // CustDetail:Gender 
      // - This is the customer's gender.  If individual flag CFINDI is set to �Y� then �M� or �F� is required.
      // GenderType gender = customerDetails.getGender();
    
      // CustDetail:CustOrgDt 
      // - This is the original customer date.
      // CustOrgDtType CustOrgDt = customerDetails.getCustOrgDt();
    
      // CustDetail:LastMainDt 
      // - This is the last maintenance date.
      // LastMainDtType LastMainDt = customerDetails.getLastMainDt();
    
      // CustDetail:Deceased
      // - This is the deceased customer flag.
      // DeceasedType deceased = customerDetails.getDeceased();
    
      // CustDetail:DeceasedDt
      // - This is the date deceased.
      // DeceasedDtType DeceasedDt = customerDetails.getDeceasedDt();
    
      // CustDetail:HouseHoldNum
      // - This is the number of persons that resides in the customer's household.
      // HouseHoldNumType HouseHoldNum = customerDetails.getHouseHoldNum();
    
      // CustDetail:HouseHoldName
      // - This is the name provided to a customer household. For example, this could be their last name
      //   followed by household.
      // HouseHoldNameType HouseHoldName = customerDetails.getHouseHoldName();
    
      // CustDetail:SpouseName
      // PersonNameCType spouseName = customerDetails.getSpouseName();
    
      // CustDetail:AnnIncmAmt
      // - This is the annual income amount. This field is used for reporting purposes for the bank.
      // AnnIncmAmtType AnnIncmAmt = customerDetails.getAnnIncmAmt();
    
      // CustDetail:AssetToAmt
      // - This is the total amount of assets owned by a customer.
      // AssetTotAmtType AssetToAmt = customerDetails.getAssetTotAmt();
    
      // CustDetail:EducLvl
      // - This is the level of completed accredited education for a customer. Canonical values are:
      //   . AssocDegree
      //   . BachelorDegree
      //   . Doctorate
      //   . Elementary
      //   . HighSchool
      //   . MastersDegree
      // EducLvlType EducLvl = customerDetails.getEducLvl();
    
      // CustDetail:HouseHoldMbrArray
      // This is an array of household members 
      // Contains:
      // . HouseHoldMbrInfo_CType
      // HouseHoldMbrArrayAType HouseHoldMbrArray = customerDetails.getHouseHoldMbrArray();
    
      // BusDetail
      // - BusDetail_CType is a complex CType element containing customer, statement, bank officer, and
      //   branch codes. This is optional.
      //   Contains:
      //   . BnkRptcyInfoRec_CType
      //   . OffInfoArray_AType
      //   . Custom_CType
      //   . UserDefInfoArray_AType
      // BustDetailCType businessDetail = custInqResp.getXBusDetail();
    
      // RegDetail
      // RegDetailCType regDetail = custInqResp.getXRegDetail();
    }
    return applicantFields;
  }
  
  
  private String translateAccountTypeCode(String accountTypeCode)
  {
    String accountType = null;
    
    if (accountTypeCode.equals("D"))
    {
      accountType = "Demand";
    }
    else if (accountTypeCode.equals("L"))
    {
      accountType = "Loan";
    }
    else if (accountTypeCode.equals("T"))
    {
      accountType = "Time Deposit";
    }
    else if (accountTypeCode.equals("B"))
    {
      accountType = "Safe Deposit Box";      
    }
    else if (accountTypeCode.equals("X"))
    {
      accountType = "Club";
    }
    else
    {
      accountType = "";
    }
    
    return accountType;
  }


  private CustomerService createCustomerService()
  {
    CustomerService_Service service = new CustomerService_Service();
    CustomerService customerSvc = service.getCustomerServiceSoap();
    
    BindingProvider bp = (BindingProvider)customerSvc;
    configureBindingProvider(bp, "Customer.svc");

    return customerSvc;    
  }
  
  
  private InquiryService createInquiryService()
  {
    InquiryService_Service service = new InquiryService_Service();
    InquiryService inquirySvc = service.getInquiryServiceSoap();
    
    BindingProvider bp = (BindingProvider)inquirySvc;
    configureBindingProvider(bp, "Inquiry.svc");

    return inquirySvc;    
  }
    

  private DepositService createDepositService()
  {
    DepositService_Service service = new DepositService_Service();
    DepositService depositSvc = service.getDepositServiceSoap();
    
    BindingProvider bp = (BindingProvider)depositSvc;
    configureBindingProvider(bp, "Deposit.svc");

    return depositSvc;    
  }
  

  private TransactionService createTransactionService()
  {
        
    TransactionService_Service service = new TransactionService_Service();
    TransactionService transactionSvc = service.getTransactionServiceSoap();
     
    BindingProvider bp = (BindingProvider)transactionSvc;
    configureBindingProvider(bp, "Transaction.svc");

    return transactionSvc;    
  }  


  private LoanService createLoanService()
  {
    LoanService_Service service = new LoanService_Service();
    LoanService loanSvc = service.getLoanServiceSoap();
    
    BindingProvider bp = (BindingProvider)loanSvc;
    configureBindingProvider(bp, "Loan.svc");
    
    return loanSvc;
  }
  
    
  private void configureBindingProvider(BindingProvider bp, String serviceName)  
  {
    StringBuilder endPoint = new StringBuilder();
    endPoint.append(isProduction ? prodURL : testURL);
    endPoint.append("/");
    endPoint.append(serviceName);

    Map<String, Object> context = bp.getRequestContext();
    context.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endPoint.toString());
    Binding binding = bp.getBinding();

    List<Handler> handlerList = binding.getHandlerChain();
    if (handlerList == null) handlerList = new ArrayList<Handler>();
    handlerList.add(new JXCSecurityHandler(jxcUsername, jxcPassword));
    
    binding.setHandlerChain(handlerList);    
  }
  

  private JXchangeHdrCType generateJXChangeHeader(String auditUser)
  {
    UUID uuid = UUID.randomUUID();
    
    JXchangeHdrCType jxcHeader = new JXchangeHdrCType();
    jxcHeader.setJxVer(version);
    jxcHeader.setAuditUsrId(auditUser);
    jxcHeader.setAuditWsId(auditWsId);
    jxcHeader.setConsumerName(consumerName);
    jxcHeader.setConsumerProd(consumerProd);
    jxcHeader.setJXLogTrackingId(trackingPrefix + uuid.toString());

    //general.errLog( "TRACKING ID: trackingPrefix + uuid.toString(): "+trackingPrefix + uuid.toString(), "jXchange_tracking_id.log" );

    return jxcHeader;
  }
  
  
  private StringBuilder generateFaultMessage(MessageFault mf)
  {
    HdrFault faultHdr = mf.getFaultInfo();
    
    FaultRecInfoArrayAType faultArray = faultHdr.getFaultRecInfoArray();
    List<FaultMsgRecCType> faultMsgList = faultArray.getFaultMsgRecs();
    
    StringBuilder sb = new StringBuilder();
    
    int faultNum = 1;
    for (FaultMsgRecCType faultMsgCType : faultMsgList)
    {
      sb.append("Fault #").append(faultNum).append("\n");
      sb.append("Error Category: ").append(faultMsgCType.getErrCat()).append("\n");
      sb.append("Error Code: ").append(faultMsgCType.getErrCode()).append("\n");
      sb.append("Error Desc: ").append(faultMsgCType.getErrDesc()).append("\n");
      sb.append("Error Element: ").append(faultMsgCType.getErrElem()).append("\n");
      sb.append("Error Value: ").append(faultMsgCType.getErrElemVal()).append("\n");
      sb.append("Error Location: ").append(faultMsgCType.getErrLoc()).append("\n");
      sb.append("\n");
      ++faultNum;
    }
    
    return sb;
  }
  
  
  private AcctAddResponse doAccountAdd(String username, Map allFields, DataNode appNode, String productType,
                                       String customerID, DepositService depositSvc) 
  throws MessageFault, DatatypeConfigurationException
  {    
      if (depositSvc == null)
      {
        depositSvc = createDepositService();
      }
          
      // Data Type Factory for XML Gregorian Calendar.
      //
      DatatypeFactory dataTypeFactory = DatatypeFactory.newInstance();

      AcctAdd accountAdd = new AcctAdd();

      /* ************************************************
       *  AcctAdd:MsgRqHdr                              *
       * ************************************************/
      MsgRqHdrCType msgRq = new MsgRqHdrCType();
      msgRq.setJXchangeHdr(generateJXChangeHeader(username));
      accountAdd.setMsgRqHdr(msgRq);


      /* ************************************************
       *  AcctAdd:AccountId                             *
       * ************************************************/
      AccountIdCType accountIdCType = new AccountIdCType();
      
      String field = (String)allFields.get("ACCTNO");
      if  (field != null)
      {
        AcctIdType acctId = new AcctIdType();      
        acctId.setValue(field);
        accountIdCType.setAcctId(acctId);
      }
      
      field = (String)allFields.get("ACTYPE");
      if (field != null)
      {
        AcctTypeType acctType = new AcctTypeType();
        acctType.setValue(field);
        accountIdCType.setAcctType(acctType);
      }
      
      accountAdd.setAccountId(accountIdCType); 
            
      if (productType.equals("CD"))
      {
        /* ************************************************
         *  AcctAdd:TimeDepAdd                            *
         * ************************************************/
        TimeDepAddCType timeDepAdd = new TimeDepAddCType();
              

        /* ************************************************
         *  AcctAdd:TimeDepAdd:TimeDepInfoRec             *
         * ************************************************/
        TimeDepInfoRecCType timeDepInfoRec = new TimeDepInfoRecCType();
        
        //AcctAdd:TimeDepAdd:TimeDepInfoRec:BrCode - overwriting the branch code
        //The deafult Service response return 0 even we specific the branch code in the request.
        //RETEST - Need to test this again in Five Star environment
        
        field = (String)allFields.get("BRANCH");
        if (field != null)
        {
          BrCodeType brCode = new BrCodeType();
          brCode.setValue(field);
          timeDepInfoRec.setBrCode(brCode);
        }
        
        //AcctAdd:TimeDepAdd:TimeDepInfoRec:AcctTitleArray - This field is used to determine if there are additional names on the account. 
        //AcctAdd:TimeDepAdd:TimeDepInfoRec:ProdCode - A bank defined code used to identify the type of product. This code would be used to inform the institution if this was a six month certificate, a variable rate IRA, etc.
        //AcctAdd:TimeDepAdd:TimeDepInfoRec:AcctStat - This is the account status.
        
        //AcctAdd:TimeDepAdd:TimeDepInfoRec:OpenDt
        field = (String)allFields.get("DATOP7");
        if (field != null)
        {
          XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
          OpenDtType openDate = new OpenDtType();
          openDate.setValue(xCal);
          timeDepInfoRec.setOpenDt(openDate);
        }
        
        //AcctAdd:TimeDepAdd:TimeDepInfoRec:ClsDt - This is the closing date.
        //AcctAdd:TimeDepAdd:TimeDepInfoRec:OffCode - This is the allowed values for officer code that are bank defined.
        
        //AcctAdd:TimeDepAdd:TimeDepInfoRec:AcctClsfCode -  This is the allowed account classification values that are bank defined.
        field = (String)allFields.get("accountClsf");
        if (field != null)
        {
          AcctClsfCodeType accountClsfCode = new AcctClsfCodeType();
          accountClsfCode.setValue(field);
          timeDepInfoRec.setAcctClsfCode(accountClsfCode);
        }
        
        //AcctAdd:TimeDepAdd:TimeDepInfoRec:LastConDt - This is the date of last contact.
        //AcctAdd:TimeDepAdd:TimeDepInfoRec:MatDt - This is the maturity date.
        
        //AcctAdd:TimeDepAdd:TimeDepInfoRec:CDTerm
        CDTermType cdTerm = new CDTermType();
        cdTerm.setValue(Integer.parseInt((String) allFields.get("daTerm")));
        timeDepInfoRec.setCDTerm(cdTerm);
        
        //AcctAdd:TimeDepAdd:TimeDepInfoRec:CDTermUnits
        CDTermUnitsType cdTermUnits = new CDTermUnitsType();
        if (((String) allFields.get("daTermPrdD")).equalsIgnoreCase("m"))
        {
          cdTermUnits.setValue("Months");
        }
        // Ask Len 
        //cdTermUnits.setValue((String) accountFields.get("daTermPrdD"));
        timeDepInfoRec.setCDTermUnits(cdTermUnits);
       
        //AcctAdd:TimeDepAdd:CustId
        CustIdType custId = new CustIdType();
        custId.setValue(customerID);
        timeDepInfoRec.setCustId(custId);

        //AcctAdd:TimeDepAdd:TimeDepInfoRec:OrigBal
        //Need to enter an non-zero orig balance, otherwise will get Error 300020 - Certificate amount cannot be zero
        OrigBalType origBal = new OrigBalType();
        origBal.setValue(new BigDecimal((String) allFields.get(CSFieldNames.FN_DEP_OPEN_AMT)));
        timeDepInfoRec.setOrigBal(origBal);

        //AcctAdd:TimeDepAdd:TimeDepInfoRec:PlnCode
        //Need to overwrting this field, the default service response return "N" which is invalid
        //RETEST - Need to test this again in Five Star environment 
        PlnCodeType plnCode = new PlnCodeType();
        plnCode.setValue("");
        timeDepInfoRec.setPlnCode(plnCode);
        
        //AcctAdd:TimeDepAdd:TimeDepInfoRec:CertifId - Additional number sequence for this account if using another numbering system for certificates.
        //AcctAdd:TimeDepAdd:TimeDepInfoRec:SalesPerson - Unparameterized field. Identifies the employee that sold the product or service to the customer.
        //AcctAdd:TimeDepAdd:TimeDepInfoRec:TINInfo - This element contains tax information number codes and descriptions
        //AcctAdd:TimeDepAdd:TimeDepInfoRec:AliasAcctName - This is an alias name provided to an account that is often used for GUI representation that is understandable to an end consumer.
        timeDepAdd.setTimeDepInfoRec(timeDepInfoRec);

        /* ************************************************
         *  AcctAdd:TimeDepAdd:TimeDepAcctInfo            *
         * ************************************************/
        TimeDepAcctInfoCType timeDepAcctInfo = new TimeDepAcctInfoCType(); //defaultAcctAddResponse.getTimeDepAcctInfo();
        //AcctAdd:TimeDepAdd:TimeDepAcctInfo:HldMailCode - This field includes the mailing instructions. Valid values are 1 - 9 or blank.
        //AcctAdd:TimeDepAdd:TimeDepAcctInfo:RepoBlkId - The repurchase agreements block identification.
        //AcctAdd:TimeDepAdd:TimeDepAcctInfo:AcctLvlSecCode - The code that references the special handling security processes/accesses at the account level.
        //AcctAdd:TimeDepAdd:TimeDepAcctInfo:SrcFundsCode - A code that represents the source of funds for credit transactions and the outgoing source for debit transactions.
        //AcctAdd:TimeDepAdd:TimeDepAcctInfo:PenCode - The code that references the penalty for early withdrawals of a deposit instrument.
        //AcctAdd:TimeDepAdd:TimeDepAcctInfo:PaperLessCode - The code that references if the deposit instrument was not issued a paper certification at account opening.
        //AcctAdd:TimeDepAdd:TimeDepAcctInfo:UserDefInfoArray - This element contains time deposit account information
        //AcctAdd:TimeDepAdd:TimeDepAcctInfo:PrtIntNotCode - The code that designates the behavior for print interest paid notices.
        //AcctAdd:TimeDepAdd:TimeDepAcctInfo:LangType - The language as defined by ISO 639�2 Language code list
        timeDepAdd.setTimeDepAcctInfo(timeDepAcctInfo);
              

        /* ************************************************
         *  AcctAdd:TimeDepAdd:TimeDepBalDtInfo           *
         * ************************************************/
        TimeDepBalDtInfoCType timeDepBalDtInfo = new TimeDepBalDtInfoCType(); //defaultAcctAddResponse.getTimeDepBalDtInfo();
        //AcctAdd:TimeDepAdd:TimeDepBalDtInfo:HldAmt - This is the hold amount.
        //AcctAdd:TimeDepAdd:TimeDepBalDtInfo:LastMainDt - This is the last maintenance date.
        //AcctAdd:TimeDepAdd:TimeDepBalDtInfo:LastDepDt - This is the date of last deposit.
        //AcctAdd:TimeDepAdd:TimeDepBalDtInfo:LastDepAmt - This is the last deposit amount.
        //AcctAdd:TimeDepAdd:TimeDepBalDtInfo:MinBal - The balance established for an account that triggers some business activity.
        //AcctAdd:TimeDepAdd:TimeDepBalDtInfo:NetMemoPostAmt - This is the sum of the current memo posted items against this account.
        timeDepAdd.setTimeDepBalDtInfo(timeDepBalDtInfo);
              
              
        /* ************************************************
        *  AcctAdd:TimeDepAdd:TimeDepRenInfo              *
        * *************************************************/
        TimeDepRenInfoCType timeDepRenInfo = new TimeDepRenInfoCType(); //defaultAcctAddResponse.getTimeDepRenInfo();
        //AcctAdd:TimeDepAdd:TimeDepRenInfo:LastRenDt - This is the date of last renewal.
        //AcctAdd:TimeDepAdd:TimeDepRenInfo:RenCode - The code that details the action for renewal on a timed instrument.
                
        //AcctAdd:TimeDepAdd:TimeDepRenInfo:OvrrdRenCode - The code that indicates if overrides exist when renewing a deposit instrument.
        //Need to overwrting this field, the default service reponse return "blank" which is invalid
        //RETEST - Need to test this again in Five Star environment 
        OvrrdRenCodeType ovrrdRenCode = new OvrrdRenCodeType();
        ovrrdRenCode.setValue("N");
        timeDepRenInfo.setOvrrdRenCode(ovrrdRenCode);
        
        //AcctAdd:TimeDepAdd:TimeDepRenInfo:OvrrdRenRate - The renewal of the deposit instrument is at this rate.
        //AcctAdd:TimeDepAdd:TimeDepRenInfo:OvrrdRenRateNum - The renewal of the deposit instrument is at this rate number.
        //AcctAdd:TimeDepAdd:TimeDepRenInfo:RenToProdCode - The renewal of the deposit instrument is this product.
        //AcctAdd:TimeDepAdd:TimeDepRenInfo:RenTermFreq - This is the integer length of the term.
        //AcctAdd:TimeDepAdd:TimeDepRenInfo:RenTermUnits - This is the term units: years, months, days, indefinite.
        timeDepAdd.setTimeDepRenInfo(timeDepRenInfo);
              
        /* ************************************************
        *  AcctAdd:TimeDepAdd:TimeDepRateIntInfo          *
        * *************************************************/
        TimeDepRateIntInfoCType timeDepRateIntInfo = new TimeDepRateIntInfoCType(); //defaultAcctAddResponse.getTimeDepRateIntInfo();
        
        //AcctAdd:TimeDepAdd:TimeDepRateIntInfo:YTDInt - This is the YTD interest.
        //AcctAdd:TimeDepAdd:TimeDepRateIntInfo:LastYrInt - This is last year's interest amount.
        //AcctAdd:TimeDepAdd:TimeDepRateIntInfo:LastInt - This is the last interest amount.
        //AcctAdd:TimeDepAdd:TimeDepRateIntInfo:NxtInt - This is the next interest amount.
        
        //AcctAdd:TimeDepAdd:TimeDepRateIntInfo:IntRate - This is the interest rate.  
        IntRateType intRate = new IntRateType();
        intRate.setValue(new BigDecimal((String) allFields.get(CSFieldNames.FN_DEP_INT_RATE)).divide((new BigDecimal(100))));
        timeDepRateIntInfo.setIntRate(intRate);

        //AcctAdd:TimeDepAdd:TimeDepRateIntInfo:LastPayDt - The last pay date.
        //AcctAdd:TimeDepAdd:TimeDepRateIntInfo:NxtPayDt - This is the next payment date.  
        
        //AcctAdd:TimeDepAdd:TimeDepRateIntInfo:IntDisp - This code designates the disposition of interest. 
        // Canonical values are:
        // ? AddBackToAcct
        // ? DepToAcct
        // ? NA
        // ? PayByACH
        // ? PayByChk
        //Need to overwrting this field, the default service reponse return "blank" which is invalid
        //RETEST - Need to test this again in Five Star environment 
        IntDispType intDispType = new IntDispType();
        intDispType.setValue("AddBackToAcct");
        timeDepRateIntInfo.setIntDisp(intDispType);

        //AcctAdd:TimeDepAdd:TimeDepRateIntInfo:IntDispAcctId - This is the interest disposition account number.
        //AcctAdd:TimeDepAdd:TimeDepRateIntInfo:IntDispAcctType - This is the interest disposition account type.
        //AcctAdd:TimeDepAdd:TimeDepRateIntInfo:IntYrBaseCode - The code for the Year Base.
        //AcctAdd:TimeDepAdd:TimeDepRateIntInfo:IntCalcCode - This is the interest calculation method.
        //AcctAdd:TimeDepAdd:TimeDepRateIntInfo:IntTerm - This is the Interest term.
        //AcctAdd:TimeDepAdd:TimeDepRateIntInfo:IntTermUnits - Interest term units
        //AcctAdd:TimeDepAdd:TimeDepRateIntInfo:EvenPayCode - Even payment code.
        //AcctAdd:TimeDepAdd:TimeDepRateIntInfo:VarIntRateInfo - This element contains variable interest rate info
        //AcctAdd:TimeDepAdd:TimeDepRateIntInfo:IntDayMonth - The day of month that interest payments should always be generated.
        //AcctAdd:TimeDepAdd:TimeDepRateIntInfo:CombIntChkCode - The code that references the combining of interest payments from a group of deposit instruments.
        //AcctAdd:TimeDepAdd:TimeDepRateIntInfo:CombIntChkCustId - The customer identification to be used to combine interest payments from a group of deposit instruments
        //AcctAdd:TimeDepAdd:TimeDepRateIntInfo:PayAllIntCode - The code that references how to handle the final interest payment.
        //AcctAdd:TimeDepAdd:TimeDepRateIntInfo:IntPmtDtCode - The code that references the action to be taken on interest payment date exceptions.
        //AcctAdd:TimeDepAdd:TimeDepRateIntInfo:MultiRateCode - The code that references the action to be taken on interest payment date exceptions.
        //AcctAdd:TimeDepAdd:TimeDepRateIntInfo:MultiDrCode - The code that indicates which deposit set withdrawals should be posted to when multi-rate exists.
        //AcctAdd:TimeDepAdd:TimeDepRateIntInfo:RateSchedCode - The code that references the rate schedule to be used.
        //AcctAdd:TimeDepAdd:TimeDepRateIntInfo:StepUpIntRateInfoArray - This is an array of step up interest rates
        //AcctAdd:TimeDepAdd:TimeDepRateIntInfo:TeaserRate - A rate that is paid specific to an account for a period of time.
        //AcctAdd:TimeDepAdd:TimeDepRateIntInfo:TeaserRateEffDt - The effective start date for a rate that is paid specific to an account for a period of time.
        //AcctAdd:TimeDepAdd:TimeDepRateIntInfo:TeaserRateExpDt - The expiration date for a rate that is paid specific to an account for a period of time.
        //AcctAdd:TimeDepAdd:TimeDepRateIntInfo:DlyDayFinalIntPmt - Can't find desc for this field
        timeDepAdd.setTimeDepRateIntInfo(timeDepRateIntInfo);
        
        
        /* ************************************************
        *  AcctAdd:TimeDepAdd:TimeDepRegRptInfo           *
        * *************************************************/
        TimeDepRegRptInfoCType timeDepRegRptInfo = new TimeDepRegRptInfoCType(); //defaultAcctAddResponse.getTimeDepRegRptInfo();
        //AcctAdd:TimeDepAdd:TimeDepRegRptInfo:GLCostCtr - The GL cost center provided for bank use in reporting the account to a specific GL cost center.
        //AcctAdd:TimeDepAdd:TimeDepRegRptInfo:GLProdCode - The GL product code provided for bank use in reporting the account to a specific GL product code.
        //AcctAdd:TimeDepAdd:TimeDepRegRptInfo:CRARec - element containing CRA information
        //AcctAdd:TimeDepAdd:TimeDepRegRptInfo:StdIndustCode - This is the standard industry code.
        //AcctAdd:TimeDepAdd:TimeDepRegRptInfo:CallRptCode - This is the call report code.
        //AcctAdd:TimeDepAdd:TimeDepRegRptInfo:ARGOProdCode - The code used to interface to the JHA Argo product.
        //AcctAdd:TimeDepAdd:TimeDepRegRptInfo:OIDCode - The code that describes the deposit account qualifications as Original Issue Discount.
        timeDepAdd.setTimeDepRegRptInfo(timeDepRegRptInfo);
        
              
        /* ************************************************
        *  AcctAdd:TimeDepAdd:TimeDepStmtInfo             *
        * *************************************************/
        TimeDepStmtInfoCType timeDepStmtInfo = new TimeDepStmtInfoCType(); //defaultAcctAddResponse.getTimeDepStmtInfo();
        //AcctAdd:TimeDepAdd:TimeDepStmtInfo:IncCombStmt - Include on combined statement. This indicates if this account is to be included in combined statement info
        //AcctAdd:TimeDepAdd:TimeDepStmtInfo:StmtPasCode - The code that designates if the account holder has a passbook for transaction posting.
        //AcctAdd:TimeDepAdd:TimeDepStmtInfo:StmtFreqCode - This is the statement frequency code.
        //AcctAdd:TimeDepAdd:TimeDepStmtInfo:StmtCycle - This is the statement cycle.
        field = (String)allFields.get("stmtCycle");
        if (field != null)
        {
          StmtCycleType stmtCycleCode = new StmtCycleType();
          stmtCycleCode.setValue(field);
          timeDepStmtInfo.setStmtCycle(stmtCycleCode);
        }
        
        //AcctAdd:TimeDepAdd:TimeDepStmtInfo:LastStmtDt - This is the last statement date.
        timeDepAdd.setTimeDepStmtInfo(timeDepStmtInfo);
              
              
        /* ************************************************
        *  AcctAdd:TimeDepAdd:TimeDepTaxInfo              *
        * *************************************************/      
        TimeDepTaxInfoCType timeDepTaxInfo = new TimeDepTaxInfoCType(); //defaultAcctAddResponse.getTimeDepTaxInfo();
        //AcctAdd:TimeDepAdd:TimeDepTaxInfo:FedWith - This element contains federal tax withholding information.
        //AcctAdd:TimeDepAdd:TimeDepTaxInfo:StateWith - This element contains state tax withholding information.
        timeDepAdd.setTimeDepTaxInfo(timeDepTaxInfo);
              
        /* ************************************************
        *  AcctAdd:TimeDepAdd:AchPmtInfo                  *
        * *************************************************/ 
        ACHPmtInfoCType achPmtInfo = new ACHPmtInfoCType(); //defaultAcctAddResponse.getACHPmtInfo();
        //AcctAdd:TimeDepAdd:AchPmtInfo:ACHCompDiscrData - The ACH company discretionary data, as governed by NACHA rules.
        //AcctAdd:TimeDepAdd:AchPmtInfo:ACHCompEntryDesc - The ACH company entry description, as governed by NACHA rules.
        //AcctAdd:TimeDepAdd:AchPmtInfo:ACHCompId - The ACH company ID.
        //AcctAdd:TimeDepAdd:AchPmtInfo:ACHCompName - The ACH company name, as governed by NACHA rules.
        //AcctAdd:TimeDepAdd:AchPmtInfo:ACHCrAcctId - The account ID of the credit account for the ACH item.
        //AcctAdd:TimeDepAdd:AchPmtInfo:ACHCrName - The account holder's name of the credit account for the ACH item.
        //AcctAdd:TimeDepAdd:AchPmtInfo:ACHCrRtNum - The routing and transit number of the credit account's bank for the ACH item.
        //AcctAdd:TimeDepAdd:AchPmtInfo:ACHDrAcctId - The account ID of the debit account for the ACH item.
        //AcctAdd:TimeDepAdd:AchPmtInfo:ACHDrName - The account holder's name of the debit account for the ACH item.
        //AcctAdd:TimeDepAdd:AchPmtInfo:ACHDrRtNum - The routing and transit number of the debit account's bank for the ACH item.
        //AcctAdd:TimeDepAdd:AchPmtInfo:ACHSendPreNoteCode - The code that determines if an ACH prenotification should be generated, as governed by NACHA rule
        //AcctAdd:TimeDepAdd:AchPmtInfo:ACHStdEntryClass - The ACH standard entry class.
        //AcctAdd:TimeDepAdd:AchPmtInfo:ACHTrnCode - The transaction code to be used for the ACH item, as governed by NACHA rules.
        timeDepAdd.setACHPmtInfo(achPmtInfo);
        
              
        accountAdd.setTimeDepAdd(timeDepAdd);
      }
      
      // For Savings, Checking, and MoneyMarket
      //
      if (! productType.equals("CD"))
      {
          /* ************************************************
           *  AcctAdd:DepAdd                                *
           * ************************************************/
          DepAddCType depAdd = new DepAddCType();
          
          /* ************************************************
           *  AcctAdd:DepAdd:DepInfoRec                     *
           * ************************************************/
          DepInfoRecCType depInfoRec = new DepInfoRecCType(); //defaultAcctAddResponse.getDepInfoRec();
          
          field = (String)allFields.get("SCCODE");
          if (field != null)
          {
            ProdCodeType prodCode = new ProdCodeType();
            prodCode.setValue(field);
            depInfoRec.setProdCode(prodCode);
          }
          
          //AcctAdd:DepAdd:DepInfoRec:BrCode - overwriting the branch code
          field = (String)allFields.get("BRANCH");
          if (field != null)
          {
            BrCodeType brCode = new BrCodeType();
            brCode.setValue(field);
            depInfoRec.setBrCode(brCode);
          }

          //AcctAdd:DepAdd:DepInfoRec:OffCode - This is the allowed values for officer code that are bank defined.
          field = (String)allFields.get("OFFICR");
          if (field != null)
          {
            OffCodeType offCode = new OffCodeType();
            offCode.setValue(field);
            depInfoRec.setOffCode(offCode);
          }
          
          //AcctAdd:DepAdd:DepInfoRec:AcctStat - This is the account status.
          field = (String)allFields.get("STATUS");
          if (field != null)
          {
            AcctStatType acctStat = new AcctStatType();
            acctStat.setValue(field);
            depInfoRec.setAcctStat(acctStat);
          }

          //AcctAdd:DepAdd:DepInfoRec:SerChgWav - This is the field that defines when an institution debits the account for service charges.
          field = (String)allFields.get("SCTYPE");
          if (field != null)
          {
            SerChgWavType serviceChargeWaive = new SerChgWavType();
            serviceChargeWaive.setValue(field);
            depInfoRec.setSerChgWav(serviceChargeWaive);
          }
          
          //AcctAdd:DepAdd:DepInfoRec:AcctTitleArray - This field is used to determine if there are additional names on the account.
          List<String> aahList = (List<String>)allFields.get(CSFieldNames.FN_SYS_DEP_ADD_ACCT_HLDRS);
          if (aahList != null)
          {
            // Because field substitution occurs prior to getting to this point in the code,
            // I needed to have the tags be "<" and ">" rather than "[" and "]" for this
            // field so that I can do the field substitution using additional account holder
            // data.
            //
            field = (String)allFields.get("ADDN1");
            field = field.replace('<', '[');
            field = field.replace('>', ']');

            AcctTitleAType accountTitleArray = new AcctTitleAType();
            
            for (String aahIndex : aahList)
            {
              DataNode bwrNode = appNode.getReference(NodeUtils.BWR_DN_TYPE, Integer.parseInt(aahIndex));
                            
              String result = StringSupport.substituteTags(field, bwrNode.getFieldData(username));
              result = CmdEvaluator.evaluate(result);
              
              AcctTitleType acctTitle = new AcctTitleType();
              acctTitle.setValue(result.toUpperCase());
                                          
              AcctTitleInfoCType acctTitleInfo = new AcctTitleInfoCType();
              acctTitleInfo.setAcctTitle(acctTitle);

              String birthDate = (String)bwrNode.getFieldData(username, CSFieldNames.FN_BIRTH_DT);
              if (birthDate != null)
              {
                XMLGregorianCalendar xBirthDt = dateToXMLGregorian(dataTypeFactory, birthDate);

                BirthDtType birthDt = new BirthDtType();
                birthDt.setValue(xBirthDt);
                
                acctTitleInfo.setAddlBirthDt(birthDt);
              }
                            
              accountTitleArray.getAcctTitleInfos().add(acctTitleInfo);
            }
            
            depInfoRec.setAcctTitleArray(accountTitleArray);
          }
          
          //AcctAdd:DepAdd:DepInfoRec:ClsDt - This is the closing date.
          //AcctAdd:DepAdd:DepInfoRec:AcctClsfCode -  This is the allowed account classification values that are bank defined.
          field = (String)allFields.get("CLASS");
          if (field != null)
          {
            AcctClsfCodeType accountClsfCode = new AcctClsfCodeType();
            accountClsfCode.setValue(field);
            depInfoRec.setAcctClsfCode(accountClsfCode);
          }
          
          //AcctAdd:DepAdd:DepInfoRec:LastConDt - This is the date of last contact.          
          //AcctAdd:DepAdd:DepInfoRec:SigVerifyCode - This "Y" or "N" code is used to designate if items clearing through the account should be checked for signature verification.
          field = (String)allFields.get("SGCODE");
          if (field != null)
          {
            SigVerifyCodeType sigVerifyCode = new SigVerifyCodeType();
            sigVerifyCode.setValue(field);
            depInfoRec.setSigVerifyCode(sigVerifyCode);
          }

          //AcctAdd:DepAdd:DepInfoRec:CustId
          CustIdType custId = new CustIdType();
          custId.setValue(customerID);
          depInfoRec.setCustId(custId);

          //AcctAdd:DepAdd:DepInfoRec:OpenDt
          field = (String)allFields.get("DATOP7"); 
          if (field != null)
          {
            XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
            OpenDtType openDt = new OpenDtType();
            openDt.setValue(xCal);
            depInfoRec.setOpenDt(openDt);
          }
          
          //AcctAdd:DepAdd:DepInfoRec:TellerSICCode - This is the code that designates special instructions to the teller.
          field = (String)allFields.get("SPMESG");
          if (field != null)
          {
            TellerSICCodeType tellerSIC = new TellerSICCodeType();
            tellerSIC.setValue(field);
            depInfoRec.setTellerSICCode(tellerSIC);
          }
          
          //AcctAdd:DepAdd:DepInfoRec:SalesPerson - This is a free form entry of the sales associate.
          field = (String)allFields.get("SALESAC");
          if (field != null)
          {
            SalesPersonType salesPerson = new SalesPersonType();
            salesPerson.setValue(field);
            depInfoRec.setSalesPerson(salesPerson);
          }
          
          //AcctAdd:DepAdd:DepInfoRec:SerChgWavRsnCode - This is the code that indicates the reason an account is not being charged any fees.
          //AcctAdd:DepAdd:DepInfoRec:TINInfo - This element contains tax information number codes and descriptions. This element is optional.
          //AcctAdd:DepAdd:DepInfoRec:MICRAcctId - This is the magnetic ink character recognition account identification that could differ from the account identification.
          //AcctAdd:DepAdd:DepInfoRec:AliasAcctName - This is an alias name provided to an account that is often used for GUI representation that is understandable to an end consumer.
          //AcctAdd:DepAdd:DepInfoRec:DormantChgWav - This is a list of values that designate the behavior for charging or waiving dormant charges. Canonical          
          //AcctAdd:DepAdd:DepInfoRec:ODPrvlgOptInfoArray - This is an array of overdraft privilege option settings.
          //    ODPrvlgOptInfoArrayAType ODPrvlgOptInfoArray = new ODPrvlgOptInfoArrayAType();
          //AcctAdd:DepAdd:DepInfoRec:ODPrvlgOptInfoArray:ODPrvlgOptInfoRec
          //    ODPrvlgOptInfoRecCType ODPrvlgOptInfoRec = new ODPrvlgOptInfoRecCType();
          //AcctAdd:DepAdd:DepInfoRec:ODPrvlgOptInfoArray:ODPrvlgOptInfoRec:ODPrvlgOptType - This field identifies the type of overdraft privilege option. Canonical values are:  "Elec"
          //AcctAdd:DepAdd:DepInfoRec:ODPrvlgOptInfoArray:ODPrvlgOptInfoRec:ODPrvlgOptDt - This field identifies the date the value of the overdraft privilege option type was last updated.
          //AcctAdd:DepAdd:DepInfoRec:ODPrvlgOptInfoArray:ODPrvlgOptInfoRec:ODPrvlgOptVal - This field identifies the value of the overdraft privilege option type.

          field = (String)allFields.get("CRDOPT");
          if (field != null)
          {
            ODPrvlgOptValType odPrvlgOptVal = new ODPrvlgOptValType();
            odPrvlgOptVal.setValue(field);
            
            ODPrvlgOptTypeType odPrvlgOptType = new ODPrvlgOptTypeType();
            odPrvlgOptType.setValue("Elec");
            
            ODPrvlgOptInfoRecCType odPrvlgRec = new ODPrvlgOptInfoRecCType();
            odPrvlgRec.setODPrvlgOptVal(odPrvlgOptVal);
            odPrvlgRec.setODPrvlgOptType(odPrvlgOptType);
            
            ODPrvlgOptInfoArrayAType odPrvlgArray = new ODPrvlgOptInfoArrayAType();
            odPrvlgArray.getODPrvlgOptInfoRecs().add(odPrvlgRec);
            
            depInfoRec.setODPrvlgOptInfoArray(odPrvlgArray);
          }
          
          depAdd.setDepInfoRec(depInfoRec);


          /* ************************************************
           *  AcctAdd:DepAdd:DepAcctInfo                    *
           * ************************************************/
          
          DepAcctInfoCType depAcctInfo = new DepAcctInfoCType();
          
          field = (String)allFields.get("NOCLOS");
          if (field != null)
          {
            ClsOnZeroBalType clsOnZero = new ClsOnZeroBalType();
            clsOnZero.setValue(field);
            depAcctInfo.setClsOnZeroBal(clsOnZero);
          }
          
          //AcctAdd:DepAdd:DepAcctInfo:HldMailCode - This field includes the mailing instructions. Valid values are 1 - 9 or blank.
          field = (String)allFields.get("MALHLD");
          if (field != null)
          {
            HldMailCodeType holdMail = new HldMailCodeType();
            holdMail.setValue(field);
            depAcctInfo.setHldMailCode(holdMail);
          }
          
          //AcctAdd:DepAdd:DepAcctInfo:RelAcctId - This is the related account ID or number.
          field = (String)allFields.get("RELACT");
          if (field != null)
          {
            RelAcctIdType relAcctID = new RelAcctIdType();
            relAcctID.setValue(field);
            depAcctInfo.setRelAcctId(relAcctID);
          }
          
          //AcctAdd:DepAdd:DepAcctInfo:RelAcctType - If the related account number field is used, this field is used to define to the system the type of account. "D" demand, "S" savings, or "X" club, are valid entries.
          field = (String)allFields.get("RACTTP");
          if (field != null)
          {
            RelAcctTypeType relAcctType = new RelAcctTypeType();
            relAcctType.setValue(field);
            depAcctInfo.setRelAcctType(relAcctType);
          }
          
          //AcctAdd:DepAdd:DepAcctInfo:ClubType - If the account is a club type account, a plan number may be entered in this field to determine the type of plan. Valid entries are 1-9. Required for account type "X".
          //AcctAdd:DepAdd:DepAcctInfo:ChkGuar - This code defines if there is a check guaranty in effect for this customer.  Valid codes are �Y� or �N�.
          field = (String)allFields.get("CHKGTY");
          if (field != null)
          {
            ChkGuarType chkGuar = new ChkGuarType();
            chkGuar.setValue(field);
            depAcctInfo.setChkGuar(chkGuar);
          }
          
          //AcctAdd:DepAdd:DepAcctInfo:ATMCard - This code may be used to designate if the account holder is an ATM card holder.  Valid codes are �Y� or �N�.
          field = (String)allFields.get("ATMCRD");
          if (field != null)
          {
            ATMCardType atmCard = new ATMCardType();
            atmCard.setValue(field);
            depAcctInfo.setATMCard(atmCard);
          }
          
          //AcctAdd:DepAdd:DepAcctInfo:ClsOnZeroBal - Enter a �N� for account to remain open with a zero balance, or enter �Y� for account to close automatically at a zero balance for the required number of days.
          //AcctAdd:DepAdd:DepAcctInfo:RepoBlkId - If the account is part of a repurchase agreement arrangement, this field is available for entry of block number information.    
          field = (String)allFields.get("RPBLK#");
          if (field != null)
          {
            RepoBlkIdType repoBlockNum = new RepoBlkIdType();
            repoBlockNum.setValue(field);
            depAcctInfo.setRepoBlkId(repoBlockNum);
          }
          
          //AcctAdd:DepAdd:DepAcctInfo:AcctLvlSecCode - Overrides the insider security for this account.  �B�=Balance only, �A�= All authority, �N�=No authority, �E�=Existence only, and blank means there is no account level override.
          field = (String)allFields.get("SECURE");
          if (field != null)
          {
            AcctLvlSecCodeType secure = new AcctLvlSecCodeType();
            secure.setValue(field);
            depAcctInfo.setAcctLvlSecCode(secure);
          }
          
          //AcctAdd:DepAdd:DepAcctInfo:HighVolAcctCode - This code may be used to flag an account as "high volume" in regard to account activity. Valid entries are "Y" or "N".
          field = (String)allFields.get("HIVOL");
          if (field != null)
          {
            HighVolAcctCodeType hiVol = new HighVolAcctCodeType();
            hiVol.setValue(field);
            depAcctInfo.setHighVolAcctCode(hiVol);
          }
          
          //AcctAdd:DepAdd:DepAcctInfo:LstPostAcctCode - If the account will be list posting a "Y" will be in this field. If list post is not to be used for this account this field will contain an "N".
          field = (String)allFields.get("LSTPST");
          if (field != null)
          {
            LstPostAcctCodeType listPosting = new LstPostAcctCodeType();
            listPosting.setValue(field);
            depAcctInfo.setLstPostAcctCode(listPosting);
          }
          
          //AcctAdd:DepAdd:DepAcctInfo:UserDefInfoArray - This is an array of UserDefInfo simple elements used to describe user defined information.
          //AcctAdd:DepAdd:DepAcctInfo:ClubPlnAcctId - The number(s) or character(s) that identify an account record that receives payment from club account distributions.
          field = (String)allFields.get("XMASPL");
          if (field != null)
          {
            ClubPlnType clubPlan = new ClubPlnType();
            clubPlan.setValue(field);
            depAcctInfo.setClubPln(clubPlan);
          }
          
          //AcctAdd:DepAdd:DepAcctInfo:ClubPlnAcctType - The number(s) or character(s) that categorize the ClubPlnAcct ID that receives payment from club account distributions.
          //AcctAdd:DepAdd:DepAcctInfo:PrtACHNotCode - The code that dictates the behavior when creating notices for ACH activity.
          //AcctAdd:DepAdd:DepAcctInfo:AcctReOpenCode - The code that dictates the behavior when re-opening an already closed account.             
          //AcctAdd:DepAdd:DepAcctInfo:FltSchedCode - This code represents the float schedule to be used by the service provider.
          //AcctAdd:DepAdd:DepAcctInfo:EFTCardInfo - This is an array of EFT cards issued to an account
          //AcctAdd:DepAdd:DepAcctInfo:AllowTrnActArray - This is an array of permissible transaction activity for an account.
          //AcctAdd:DepAdd:DepAcctInfo:LangType - The language as defined by ISO 639�2 Language code list
          field = (String)allFields.get("DDLANG");
          if  (field != null)
          {
            LangTypeType langType = new LangTypeType();
            langType.setValue(field);
            depAcctInfo.setLangType(langType);
          }          

          // Special Information Codes
          //
          UserDefInfoArrayAType userDefArray = new UserDefInfoArrayAType();
          
          for (int i = 1; i <= 6; ++i)
          {
            String code = (String)allFields.get("DDSIC" + i + "_CODE");
            String desc = (String)allFields.get("DDSIC" + i + "_DESC");
            
            if (code != null && desc != null)
            {
              UserDefCodeType userDefCode = new UserDefCodeType();
              userDefCode.setValue(code);
              
              UserDefTxtType userDefText = new UserDefTxtType();
              userDefText.setValue(desc);
              
              UserDefInfoCType userDefInfo = new UserDefInfoCType();
              userDefInfo.setUserDefCode(userDefCode);
              userDefInfo.setUserDefTxt(userDefText);
              
              userDefArray.getUserDefInfos().add(userDefInfo);
            }
          }
                    
          if (! userDefArray.getUserDefInfos().isEmpty())
          {
            depAcctInfo.setUserDefInfoArray(userDefArray);
          }
                    
          depAdd.setDepAcctInfo(depAcctInfo);
          
          
          /* ************************************************
           *  AcctAdd:DepAdd:DepBalDtInfo                   *
           * ************************************************/
          
          DepBalDtInfoCType DepBalDtInfo = new DepBalDtInfoCType();
          
          //AcctAdd:DepAdd:DepBalDtInfo:HldAmt - This is the hold amount.
          //AcctAdd:DepAdd:DepBalDtInfo:FltAmt - This is the amount of float outstanding against this account.
          //AcctAdd:DepAdd:DepBalDtInfo:RegCCAmt - This is the amount of Reg CC against this account.
          //AcctAdd:DepAdd:DepBalDtInfo:ODProtAmt - This is the amount of overdraft protection (credit line) this account has.
          //AcctAdd:DepAdd:DepBalDtInfo:AvlSweepAmt - This the amount of available sweep that could be used to cover this account.
          //AcctAdd:DepAdd:DepBalDtInfo:NetMemoPostAmt - This is the sum of the current memo posted items against this account.
          //AcctAdd:DepAdd:DepBalDtInfo:LastMainDt - This is the last maintenance date.
          //AcctAdd:DepAdd:DepBalDtInfo:LastDepDt - This is the date of last deposit.
          //AcctAdd:DepAdd:DepBalDtInfo:LastDepAmt - This is the last deposit amount.
          //AcctAdd:DepAdd:DepBalDtInfo:CashInExmp - This is the cash-in exemption.
          //AcctAdd:DepAdd:DepBalDtInfo:CashOutExmp - This is the cash-out exemption.
          //AcctAdd:DepAdd:DepBalDtInfo:ChgdOffDt - This is the charge off date.
          //AcctAdd:DepAdd:DepBalDtInfo:ChgdOffAmt - This is the amount charged off.
          //AcctAdd:DepAdd:DepBalDtInfo:MinBal - The balance established for an account that triggers some business activity.
          depAdd.setDepBalDtInfo(DepBalDtInfo);
          
          /* ************************************************
           *  AcctAdd:DepAdd:DepNSFODInfo                   *
           * ************************************************/
          
          DepNSFODInfoCType depNSFODInfo = new DepNSFODInfoCType();
          
          //AcctAdd:DepAdd:DepNSFODInfo:ODLmt -  This is the overdraft limit.  In a "Post None" environment this code may be used to pay items on specific accounts up to a set OD amount. The codes are bank defined 1-9 and the limits tied to each code are established in parameter maintenance (For DDA only).
          field = (String)allFields.get("ODLMT");
          if (field != null)
          {
            ODLmtType odLimit = new ODLmtType();
            odLimit.setValue(new BigDecimal(field));
            depNSFODInfo.setODLmt(odLimit);
          }
          
          //AcctAdd:DepAdd:DepNSFODInfo:ODPrvlgAmt - This is the amount of overdraft privilege (bounce protection) this account has.
          //AcctAdd:DepAdd:DepNSFODInfo:AutoNSFFee - Automatic NSF fee.
          field = (String)allFields.get("AUTNSF");
          if (field != null)
          {
            AutoNSFFeeType autoNSFFee = new AutoNSFFeeType();
            autoNSFFee.setValue(field);
            depNSFODInfo.setAutoNSFFee(autoNSFFee);
          }
          
          //AcctAdd:DepAdd:DepNSFODInfo:ConsDaysNSF - The number of consecutive days NSF
          //AcctAdd:DepAdd:DepNSFODInfo:ConsDaysOD - The number of consecutive days overdrawn
          //AcctAdd:DepAdd:DepNSFODInfo:ConsDaysRet - The number of consecutive days returned.          
          //AcctAdd:DepAdd:DepNSFODInfo:LastODDt - This is the last overdrawn date.
          //AcctAdd:DepAdd:DepNSFODInfo:ODStat - This is the OD status
          //AcctAdd:DepAdd:DepNSFODInfo:ODItemsYTD - The number of overdraft items, year to date.
          //AcctAdd:DepAdd:DepNSFODInfo:ODTimesYTD - The number of times the account has been overdrawn, year to date.
          //AcctAdd:DepAdd:DepNSFODInfo:NSFItemsYTD - The number of items that were NSF (non sufficient funds), year to date.
          //AcctAdd:DepAdd:DepNSFODInfo:NSFTimesYTD - The number of times the account was NSF (non sufficient funds), year to date.
          //AcctAdd:DepAdd:DepNSFODInfo:ChgODCode - A code that indicates the business logic to be used for charging a continuous charge while an account is maintained in a negative balance position.  If the account will be charged a fee for each day the balance remains in the negative, the entry here would be "Y". If not, "N" would be entered. �B� creates a continuous OD Charge AND an NSF Fee. So valid entries are �Y�,�N� or �B�. If no entry is made the system will use new account defaults from core.
          field = (String)allFields.get("CODCHG");
          if (field != null)
          {
            ChgODCodeType chgODCode = new ChgODCodeType();
            chgODCode.setValue(field);
            depNSFODInfo.setChgODCode(chgODCode);
          }
          
          //AcctAdd:DepAdd:DepNSFODInfo:ChgODFeeMin - The minimum amount an account should be charged for maintaining a negative balance position.
          field = (String)allFields.get("CODFEE");
          if (field != null)
          {
            ChgODFeeMinType chgODFeeMin = new ChgODFeeMinType();
            chgODFeeMin.setValue(new BigDecimal(field));
            depNSFODInfo.setChgODFeeMin(chgODFeeMin);
          }
          
          //AcctAdd:DepAdd:DepNSFODInfo:ChgODFeeMax - The maximum amount an account should be charged for maintaining a negative balance position.
          field = (String)allFields.get("CODFMX");
          if (field != null)
          {
            ChgODFeeMaxType chgODFeeMax = new ChgODFeeMaxType();
            chgODFeeMax.setValue(new BigDecimal(field));
            depNSFODInfo.setChgODFeeMax(chgODFeeMax);
          }
          
          //AcctAdd:DepAdd:DepNSFODInfo:ChgODFeePct - The percentage to be used to determine the charge for an account for maintaining a negative balance position.
          field = (String)allFields.get("CODFPC");
          if (field != null)
          {
            ChgODFeePctType chgODFeePct = new ChgODFeePctType();
            chgODFeePct.setValue(new BigDecimal(field));
            depNSFODInfo.setChgODFeePct(chgODFeePct);
          }
          
          //AcctAdd:DepAdd:DepNSFODInfo:ChgODFeeDays - The number of days that can elapse before charging an account for maintaining a negative balance position.
          field = (String)allFields.get("CODFDY");
          if (field != null)
          {
            ChgODFeeDaysType chgODFeeDays = new ChgODFeeDaysType();
            chgODFeeDays.setValue(Integer.parseInt(field));
            depNSFODInfo.setChgODFeeDays(chgODFeeDays);
          }
          
          //AcctAdd:DepAdd:DepNSFODInfo:ChgODFeeBal - The threshold balance of an account before charging an account for maintaining a negative balance position.
          field = (String)allFields.get("CODFBL");
          if (field != null)
          {
            ChgODFeeBalType chgODFeeBal = new ChgODFeeBalType();
            chgODFeeBal.setValue(new BigDecimal(field));
            depNSFODInfo.setChgODFeeBal(chgODFeeBal);
          }
          
          //AcctAdd:DepAdd:DepNSFODInfo:DlyNSFMaxChg - The maximum amount an account can be charged for NSF items on a daily basis.
          field = (String)allFields.get("NSFMAX");
          if (field != null)
          {
            DlyNSFMaxChgType dailyNSFMax = new DlyNSFMaxChgType();
            dailyNSFMax.setValue(new BigDecimal(field));
            depNSFODInfo.setDlyNSFMaxChg(dailyNSFMax);
          }
          
          //AcctAdd:DepAdd:DepNSFODInfo:DlyODMaxChg - The maximum amount an account can be charged for OD items on a daily basis.
          field = (String)allFields.get("ODIMAX");
          if (field != null)
          {
            DlyODMaxChgType dailyODMax = new DlyODMaxChgType();
            dailyODMax.setValue(new BigDecimal(field));
            depNSFODInfo.setDlyODMaxChg(dailyODMax);
          }
          
          //AcctAdd:DepAdd:DepNSFODInfo:DlyUCFMaxChgType - The maximum amount an account can be charged for items paid on uncollected funds on a daily basis.
          field = (String)allFields.get("UCFMAX");
          if (field != null)
          {
            DlyUCFMaxChgType dailyUCFMax = new DlyUCFMaxChgType();
            dailyUCFMax.setValue(new BigDecimal(field));
            depNSFODInfo.setDlyUCFMaxChg(dailyUCFMax);
          }
          
          //AcctAdd:DepAdd:DepNSFODInfo:PostAFTNSFCode - A code that indicates how to handle automatic funds transfers for accounts that are in or that could go into a negative balance position.
          field = (String)allFields.get("PSTAFTNSF");
          if (field != null)
          {
            PostAFTNSFCodeType postNSFCode = new PostAFTNSFCodeType();
            postNSFCode.setValue(field);
            depNSFODInfo.setPostAFTNSFCode(postNSFCode);
          }
          
          //AcctAdd:DepAdd:DepNSFODInfo:AllowReDepCode - The code that indicates how to redeposit foreign return items. Enter "Y" to allow redeposits to be processed on this account.  A redeposit is a return item that is being re-submitted through the Federal Reserve or a correspondent bank for posting. The number of times an item can be redeposited is controlled by the institution at the service charge level and the account level. These are also referred to as Reruns or Reclears.
          field = (String)allFields.get("ALLREDEP");
          if (field != null)
          {
            AllowReDepCodeType allowRedeposits = new AllowReDepCodeType();
            allowRedeposits.setValue(field);
            depNSFODInfo.setAllowReDepCode(allowRedeposits);
          }
          
          //AcctAdd:DepAdd:DepNSFODInfo:NumAllowReDepItems - The allowable number of redeposit foreign return items.
          field = (String)allFields.get("NOREDEP");
          if (field != null)
          {
            NumAllowReDepItemsType numRedeposits = new NumAllowReDepItemsType();
            numRedeposits.setValue(Integer.parseInt(field));
            depNSFODInfo.setNumAllowReDepItems(numRedeposits);
          }
          
          //AcctAdd:DepAdd:DepNSFODInfo:ReDepNotCode - The code that indicates the business logic for redeposit notices.  Enter "Y" to send a redeposit notice to the customer.  Will be �N� if ALLREDEP = �N� */
          field = (String)allFields.get("SNDREDPNO");
          if (field != null)
          {
            ReDepNotCodeType redepNoticeCode = new ReDepNotCodeType();
            redepNoticeCode.setValue(field);
            depNSFODInfo.setReDepNotCode(redepNoticeCode);
          }
          
          //AcctAdd:DepAdd:DepNSFODInfo:ODNot1Days - The number of days to lapse, prior to sending the first overdraft notice.
          field = (String)allFields.get("DDODNOTDY1");
          if (field != null)
          {
            ODNot1DaysType odNot1Days = new ODNot1DaysType();
            odNot1Days.setValue(Integer.parseInt(field));
            depNSFODInfo.setODNot1Days(odNot1Days);
          }

          //AcctAdd:DepAdd:DepNSFODInfo:ODNot2Days - The number of days to lapse, prior to sending the second overdraft notice.
          field = (String)allFields.get("DDODNOTDY2");
          if (field != null)
          {
            ODNot2DaysType odNot2Days = new ODNot2DaysType();
            odNot2Days.setValue(Integer.parseInt(field));
            depNSFODInfo.setODNot2Days(odNot2Days);
          }

          //AcctAdd:DepAdd:DepNSFODInfo:ODNot3Days - The number of days to lapse, prior to sending the third overdraft notice.
          field = (String)allFields.get("DDODNOTDY3");
          if (field != null)
          {
            ODNot3DaysType odNot3Days = new ODNot3DaysType();
            odNot3Days.setValue(Integer.parseInt(field));
            depNSFODInfo.setODNot3Days(odNot3Days);
          }

          //AcctAdd:DepAdd:DepNSFODInfo:ODNot4Days - The number of days to lapse, prior to sending the fourth overdraft notice.
          field = (String)allFields.get("DDODNOTDY4");
          if (field != null)
          {
            ODNot4DaysType odNot4Days = new ODNot4DaysType();
            odNot4Days.setValue(Integer.parseInt(field));
            depNSFODInfo.setODNot4Days(odNot4Days);            
          }

          //AcctAdd:DepAdd:DepNSFODInfo:ODNot5Days - The number of days to lapse, prior to sending the fifth overdraft notice.
          field = (String)allFields.get("DDODNOTDY5");
          if (field != null)
          {
            ODNot5DaysType odNot5Days = new ODNot5DaysType();
            odNot5Days.setValue(Integer.parseInt(field));
            depNSFODInfo.setODNot5Days(odNot5Days);
          }

          //AcctAdd:DepAdd:DepNSFODInfo:ODNot6Days - The number of days to lapse, prior to sending the sixth overdraft notice.
          field = (String)allFields.get("DDODNOTDY6");
          if (field != null)
          {
            ODNot6DaysType odNot6Days = new ODNot6DaysType();
            odNot6Days.setValue(Integer.parseInt(field));
            depNSFODInfo.setODNot6Days(odNot6Days);            
          }

          //AcctAdd:DepAdd:DepNSFODInfo:ChgdOffAutoCode - unknown
          
          depAdd.setDepNSFODInfo(depNSFODInfo);
          
          /* ************************************************
           *  AcctAdd:DepAdd:DepRateIntInfo                 *
           * ************************************************/
          
          DepRateIntInfoCType depRateIntInfo = new DepRateIntInfoCType();        
          
          //AcctAdd:DepAdd:DepRateIntInfo:YTDInt - This is the YTD interest.
          //AcctAdd:DepAdd:DepRateIntInfo:IntRate - This is the interest rate.
          field = (String)allFields.get(CSFieldNames.FN_DEP_INT_RATE);
          if (field != null)
          {
            IntRateType intRate = new IntRateType();
            intRate.setValue(new BigDecimal(field).divide((new BigDecimal(100))));
            depRateIntInfo.setIntRate(intRate);
          }
          
          //AcctAdd:DepAdd:DepRateIntInfo:AltAccrInt - This is the alternate accrued interest.
          //AcctAdd:DepAdd:DepRateIntInfo:AmtLastIntPd - This is the amount of last interest paid.
          //AcctAdd:DepAdd:DepRateIntInfo:PrevYTDIntPaid - This is the previous year to date interest paid.
          //AcctAdd:DepAdd:DepRateIntInfo:IntDisp - This code designates the disposition of interest. 
          field = (String)allFields.get("PCHECK");
          if (field != null)
          {
            IntDispType intDisp = new IntDispType();
            intDisp.setValue(field);
            depRateIntInfo.setIntDisp(intDisp);
          }

          //AcctAdd:DepAdd:DepRateIntInfo:IntDispAcctId -This is the interest disposition account number.
          field = (String)allFields.get("PCHACT");
          if (field != null)
          {
            IntDispAcctIdType dispAcct = new IntDispAcctIdType();
            dispAcct.setValue(field);
            depRateIntInfo.setIntDispAcctId(dispAcct);
          }

          //AcctAdd:DepAdd:DepRateIntInfo:IntDispAcctType -This is the interest disposition account type.
          field = (String)allFields.get("PCHATY");
          if (field != null)
          {
            IntDispAcctTypeType dispAcctType = new IntDispAcctTypeType();
            dispAcctType.setValue(field);
            depRateIntInfo.setIntDispAcctType(dispAcctType);
          }
          
          //AcctAdd:DepAdd:DepRateIntInfo:IntBasis - The interest base method used for the loan.
          //AcctAdd:DepAdd:DepRateIntInfo:AccrMeth - This is the accrual method.
          //AcctAdd:DepAdd:DepRateIntInfo:PrtIntChkCode - The code that indicates the business logic for printing interest checks for deposit accounts.
          //AcctAdd:DepAdd:DepRateIntInfo:PayIntEOMCode - The code that indicates the business logic for handling of interest payments through the end of the month.
          //AcctAdd:DepAdd:DepRateIntInfo:LastPayDt - The last pay date.
          //AcctAdd:DepAdd:DepRateIntInfo:TeaserRate - A rate that is paid specific to an account for a period of time.
          //AcctAdd:DepAdd:DepRateIntInfo:TeaserRateEffDt - The effective start date for a rate that is paid specific to an account for a period of time.
          //AcctAdd:DepAdd:DepRateIntInfo:TeaserRateExpDt - The expiration date for a rate that is paid specific to an account for a period of time.
                    
          // Sub Element - Var Int Rate Info
          VarIntRateInfoCType varIntRateInfo = new VarIntRateInfoCType();
          
          //AcctAdd:DepAdd:DepRateIntInfo:VarIntRateInfo:RateVar
          field = (String)allFields.get("PVAR");
          if  (field != null)
          {
            RateVarType rateVar = new RateVarType();
            rateVar.setValue(new BigDecimal(field));
            varIntRateInfo.setRateVar(rateVar);
          }
          
          //AcctAdd:DepAdd:DepRateIntInfo:VarIntRateInfo:RateVarCode
          field = (String)allFields.get("PVAR1");
          if (field != null)
          {
            RateVarCodeType rateVarCode = new RateVarCodeType();
            rateVarCode.setValue(field);
            varIntRateInfo.setRateVarCode(rateVarCode);
          }

          //AcctAdd:DepAdd:DepRateIntInfo:VarIntRateInfo:RateFlr
          field = (String)allFields.get("PFLOOR");
          if (field != null)
          {
            RateFlrType rateFloor = new RateFlrType();
            rateFloor.setValue(new BigDecimal(field));
            varIntRateInfo.setRateFlr(rateFloor);
          }
          
          //AcctAdd:DepAdd:DepRateIntInfo:VarIntRateInfo:RateCeil
          field = (String)allFields.get("PCEIL");
          if (field != null)
          {
            RateCeilType rateCeil = new RateCeilType();
            rateCeil.setValue(new BigDecimal(field));
            varIntRateInfo.setRateCeil(rateCeil);            
          }
          
          //AcctAdd:DepAdd:DepRateIntInfo:VarIntRateInfo:RateRevDt
          field = (String)allFields.get("REVDT7");
          if (field != null)
          {
            XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
            RateRevDtType rateRevDt = new RateRevDtType();
            rateRevDt.setValue(xCal);
            varIntRateInfo.setRateRevDt(rateRevDt);
          }
          
          //AcctAdd:DepAdd:DepRateIntInfo:VarIntRateInfo:RateRevTerm
          field = (String)allFields.get("TERM");
          if (field != null)
          {
            RateRevTermType term = new RateRevTermType();
            term.setValue(Integer.parseInt(field));
            varIntRateInfo.setRateRevTerm(term);
          }
          
          //AcctAdd:DepAdd:DepRateIntInfo:VarIntRateInfo:RateRevTermCode
          field = (String)allFields.get("TERMCD");
          if (field != null)
          {
            RateRevTermUnitsType termUnits = new RateRevTermUnitsType();
            termUnits.setValue(field);
            varIntRateInfo.setRateRevTermUnits(termUnits);
          }
                    
          depRateIntInfo.setVarIntRateInfo(varIntRateInfo);

          depAdd.setDepRateIntInfo(depRateIntInfo);

          
          /* ************************************************
           *  AcctAdd:DepAdd:DepRegRptInfo                  *
           * ************************************************/
          
          DepRegRptInfoCType depRegRptInfo = new DepRegRptInfoCType();

          //AcctAdd:DepAdd:DepRegRptInfo:GLCostCtr - The GL cost center provided for bank use in reporting the account to a specific GL cost center.
          field = (String)allFields.get("GLCOST");
          if (field != null)
          {
            GLCostCtrType glCost = new GLCostCtrType();
            glCost.setValue(field);
            depRegRptInfo.setGLCostCtr(glCost);
          }
          
          //AcctAdd:DepAdd:DepRegRptInfo:GLProdCode - The GL product code provided for bank use in reporting the account to a specific GL product code.
          field = (String)allFields.get("GLPROD");
          if (field != null)
          {
            GLProdCodeType glProd = new GLProdCodeType();
            glProd.setValue(field);
            depRegRptInfo.setGLProdCode(glProd);
          }
          
          //AcctAdd:DepAdd:DepRegRptInfo:StdIndustCode - This is the standard industry code.
          //AcctAdd:DepAdd:DepRegRptInfo:CallRptCode - This is the call report code.
          field = (String)allFields.get("CALLREP");
          if (field != null)
          {
            CallRptCodeType callReportCode = new CallRptCodeType();
            callReportCode.setValue(field);
            depRegRptInfo.setCallRptCode(callReportCode);
          }
          
          //AcctAdd:DepAdd:DepRegRptInfo:ARGOProdCode - The code used to interface to the JHA Argo product. 
          //AcctAdd:DepAdd:DepRegRptInfo:ODRegRptCode - The code used to determine how overdraft plans should be reported to regulatory agencies.
          field = (String)allFields.get("ODRGRPT");
          if (field != null)
          {
            ODRegRptCodeType odRegRpt = new ODRegRptCodeType();
            odRegRpt.setValue(field);
            depRegRptInfo.setODRegRptCode(odRegRpt);
          }
          
          CRARecCType craRec = new CRARecCType();
          
          field = (String)allFields.get("SMSA");
          if (field != null)
          {
            CRASMSACodeType smsaCode = new CRASMSACodeType();
            smsaCode.setValue(field);
            craRec.setCRASMSACode(smsaCode);
          }
          
          field = (String)allFields.get("CRALOC");
          if (field != null)
          {
            CRALocType craLoc = new CRALocType();
            craLoc.setValue(field);
            craRec.setCRALoc(craLoc);
          }

          field = (String)allFields.get("CRASTA");
          if (field != null)
          {
            CRAStateCodeType craState = new CRAStateCodeType();
            craState.setValue(field);
            craRec.setCRAStateCode(craState);
          }
          
          field = (String)allFields.get("COUNTY");
          if (field != null)
          {
            CRACountyCodeType craCounty = new CRACountyCodeType();
            craCounty.setValue(field);
            craRec.setCRACountyCode(craCounty);
          }
          
          depRegRptInfo.setCRARec(craRec);

          depAdd.setDepRegRptInfo(depRegRptInfo);
          
          
          /* ************************************************
           *  AcctAdd:DepAdd:DepStmtInfo                    *
           * ************************************************/
          
          DepStmtInfoCType depStmtInfo = new DepStmtInfoCType();
                
          //AcctAdd:DepAdd:DepStmtInfo:IncCombStmt - Include on combined statement. This indicates if this account is to be included in combined statement information.
          field = (String)allFields.get("COMBIN");
          if (field != null)
          {
            IncCombStmtType incCombStmt = new IncCombStmtType();
            incCombStmt.setValue(field);
            depStmtInfo.setIncCombStmt(incCombStmt);
          }
          
          //AcctAdd:DepAdd:DepStmtInfo:LastStmtDt - This is the last statement date.
          //AcctAdd:DepAdd:DepStmtInfo:StmtCycle - The current statement cycle of the account. This is a bank defined code that allows the bank to select when accounts will have a statement generated.
          field = (String)allFields.get("STCYC");
          if (field != null)
          {
            StmtCycleType stmtCycleCode = new StmtCycleType();
            stmtCycleCode.setValue(field);
            depStmtInfo.setStmtCycle(stmtCycleCode);
          }

          //AcctAdd:DepAdd:DepStmtInfo:IntCycle - The current interest cycle of the account. This is a bank defined code which allows the bank to determine when interest will be paid to the account.  Normally this code will be the same as the statement cycle code
          field = (String)allFields.get("INTCYC");
          if (field != null) 
          {
            IntCycleType intCycleCode = new IntCycleType();
            intCycleCode.setValue(Integer.parseInt(field));
            depStmtInfo.setIntCycle(intCycleCode);
          }
          
          //AcctAdd:DepAdd:DepStmtInfo:SerChgCycle - The service charge cycle used when an institution debits the account for service charges.
          field = (String)allFields.get("SCCYC");
          if (field != null)
          {
            SerChgCycleType serChgCycleCode = new SerChgCycleType();
            serChgCycleCode.setValue(field);
            depStmtInfo.setSerChgCycle(serChgCycleCode);
          }
          
          //AcctAdd:DepAdd:DepStmtInfo:SerChgWavExpDt - Service charge waive expiration date          
          //AcctAdd:DepAdd:DepStmtInfo:StmtPasCode - The code that designates if the account holder has a passbook for transaction posting.            
          field = (String)allFields.get("STMPAS");
          if (field != null)
          {
            StmtPasCodeType stmtPassCode = new StmtPasCodeType();
            stmtPassCode.setValue(field); 
            depStmtInfo.setStmtPasCode(stmtPassCode);
          }

          //AcctAdd:DepAdd:DepStmtInfo:SerChgLvl - This is the service charge level.
          //AcctAdd:DepAdd:DepStmtInfo:ItmTrunc - Item truncation/safekeeping                
          field = (String)allFields.get("TRUNC");
          if (field != null)
          {
            ItmTruncType itemTrunc = new ItmTruncType();
            itemTrunc.setValue(field);
            depStmtInfo.setItmTrunc(itemTrunc);
          }
          
          //AcctAdd:DepAdd:DepStmtInfo:NxtStmtDt - This is the next statement date.
          field = (String)allFields.get("NXTSTM7");
          if (field != null)
          {
            XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
            NxtStmtDtType nextStmtDt = new NxtStmtDtType();
            nextStmtDt.setValue(xCal);
            depStmtInfo.setNxtStmtDt(nextStmtDt);
          }
          
          //AcctAdd:DepAdd:DepStmtInfo:StmtDay - This is the statement day.
          field = (String)allFields.get("STMDAY");
          if (field != null)
          {
            StmtDayType stmtDay = new StmtDayType();
            stmtDay.setValue(Integer.parseInt(field));
            depStmtInfo.setStmtDay(stmtDay);
          }
                    
          //AcctAdd:DepAdd:DepStmtInfo:StmtFreqCode - This is the statement frequency code.
          field = (String)allFields.get("STMFRC");
          if (field != null)
          {
            StmtFreqCodeType stmtFreqCode = new StmtFreqCodeType();
            stmtFreqCode.setValue(field);
            depStmtInfo.setStmtFreqCode(stmtFreqCode);
          }
          
          //AcctAdd:DepAdd:DepStmtInfo:StmtPrtCode - This is the statement print code.
          field = (String)allFields.get("STMPR");
          if (field != null)
          {
            StmtPrtCodeType stmtPrtCode = new StmtPrtCodeType();
            stmtPrtCode.setValue(field);
            depStmtInfo.setStmtPrtCode(stmtPrtCode);
          }
          
          //AcctAdd:DepAdd:DepStmtInfo:StmtSerChg - This is the statement service charge.
          field = (String)allFields.get("STMSC");
          if (field != null)
          {
            StmtSerChgType stmtSerChg = new StmtSerChgType();
            stmtSerChg.setValue(field);
            depStmtInfo.setStmtSerChg(stmtSerChg);
          }
          
          //AcctAdd:DepAdd:DepStmtInfo:StmtFreq - This is the statement frequency.
          field = (String)allFields.get("STMFRQ");
          if (field != null)
          {
            StmtFreqType stmtFreq = new StmtFreqType();
            stmtFreq.setValue(Integer.parseInt(field));
            depStmtInfo.setStmtFreq(stmtFreq);
          }
          
          //AcctAdd:DepAdd:DepStmtInfo:StmtCrInt - Statement credit interest.
          //AcctAdd:DepAdd:DepStmtInfo:ImgPrtChkOrderCode - The code used to determine the order the checks print on the deposit periodic statement.
          field = (String)allFields.get("PRTCKO");
          if (field != null)
          {
            ImgPrtChkOrderCodeType imgPrtChkOrder = new ImgPrtChkOrderCodeType();
            imgPrtChkOrder.setValue(field);
            depStmtInfo.setImgPrtChkOrderCode(imgPrtChkOrder);
          }
          
          //AcctAdd:DepAdd:DepStmtInfo:ImgItemsPerPgCode - The code used to determine how many image items should print per page on the deposit periodic statement.
          field = (String)allFields.get("IPERPG");
          if (field != null)
          {
            ImgItemsPerPgCodeType imgItemsPerPage = new ImgItemsPerPgCodeType();
            imgItemsPerPage.setValue(field);
            depStmtInfo.setImgItemsPerPgCode(imgItemsPerPage);
          }
          
          //AcctAdd:DepAdd:DepStmtInfo:ImgItemsFrntBackCode - The code used to determine how the front and back of the image items should print on the deposit periodic statement.
          field = (String)allFields.get("IFROBK");
          if (field != null)
          {
            ImgItemsFrntBackCodeType imgItemFrontBack = new ImgItemsFrntBackCodeType();
            imgItemFrontBack.setValue(field);
            depStmtInfo.setImgItemsFrntBackCode(imgItemFrontBack);
          }
          
          //AcctAdd:DepAdd:DepStmtInfo:ImgIncCrCode - The code used to determine if credit image items should be included on the deposit periodic statement.
          field = (String)allFields.get("ICREDS");
          if (field != null)
          {
            ImgIncCrCodeType imageCredits = new ImgIncCrCodeType();
            imageCredits.setValue(field);
            depStmtInfo.setImgIncCrCode(imageCredits);
          }
          
          //AcctAdd:DepAdd:DepStmtInfo:StmtCycResetFreqCode - The code used to determine the frequency of resetting the counters that track the number of statements cycled/printed over a period of time.
          field = (String)allFields.get("DDSTCYRSFQ");
          if (field != null)
          {
            StmtCycResetFreqCodeType stmtCycleReset = new StmtCycResetFreqCodeType();
            stmtCycleReset.setValue(field);
            depStmtInfo.setStmtCycResetFreqCode(stmtCycleReset);
          }
          
          //AcctAdd:DepAdd:DepStmtInfo:StmtFormatCode - The code that determines the format of the deposit periodic statement
          field = (String)allFields.get("DDSTMFMTCD");
          if (field != null)
          {
            StmtFormatCodeType stmtFormatCode = new StmtFormatCodeType();
            stmtFormatCode.setValue(field);
            depStmtInfo.setStmtFormatCode(stmtFormatCode);
          }
          
          //AcctAdd:DepAdd:DepStmtInfo:ElecStmtType - The type of electronic statement.
          field = (String)allFields.get("DDPSCOD");
          if (field != null)
          {
            ElecStmtTypeType elecStmtType = new ElecStmtTypeType();
            elecStmtType.setValue(field);
            depStmtInfo.setElecStmtType(elecStmtType);
          }
          
          //AcctAdd:DepAdd:DepStmtInfo:ElecStmtChgWav - The service charging method for electronic statement.
          depAdd.setDepStmtInfo(depStmtInfo);
          
          /* ************************************************
           *  AcctAdd:DepAdd:DepTaxInfo                     *
           * ************************************************/          
          DepTaxInfoCType depTaxInfo = new DepTaxInfoCType();
          //AcctAdd:DepAdd:DepTaxInfo:FedWith - This element contains federal tax withholding information.
          //AcctAdd:DepAdd:DepTaxInfo:StateWith - This element contains state tax withholding information.
          depAdd.setDepTaxInfo(depTaxInfo);
          
          /* ************************************************
           *  AcctAdd:DepAdd:ACHPmtInfo                     *
           * ************************************************/  
          ACHPmtInfoCType achPmtInfo = new ACHPmtInfoCType();
          //AcctAdd:DepAdd:AchPmtInfo:ACHCompDiscrData - The ACH company discretionary data, as governed by NACHA rules.
          //AcctAdd:DepAdd:AchPmtInfo:ACHCompEntryDesc - The ACH company entry description, as governed by NACHA rules.
          //AcctAdd:DepAdd:AchPmtInfo:ACHCompId - The ACH company ID.
          //AcctAdd:DepAdd:AchPmtInfo:ACHCompName - The ACH company name, as governed by NACHA rules.
          //AcctAdd:DepAdd:AchPmtInfo:ACHCrAcctId - The account ID of the credit account for the ACH item.
          //AcctAdd:DepAdd:AchPmtInfo:ACHCrName - The account holder's name of the credit account for the ACH item.
          //AcctAdd:DepAdd:AchPmtInfo:ACHCrRtNum - The routing and transit number of the credit account's bank for the ACH item.
          //AcctAdd:DepAdd:AchPmtInfo:ACHDrAcctId - The account ID of the debit account for the ACH item.
          //AcctAdd:DepAdd:AchPmtInfo:ACHDrName - The account holder's name of the debit account for the ACH item.
          //AcctAdd:DepAdd:AchPmtInfo:ACHDrRtNum - The routing and transit number of the debit account's bank for the ACH item.
          //AcctAdd:DepAdd:AchPmtInfo:ACHSendPreNoteCode - The code that determines if an ACH prenotification should be generated, as governed by NACHA rule
          //AcctAdd:DepAdd:AchPmtInfo:ACHStdEntryClass - The ACH standard entry class.
          //AcctAdd:DepAdd:AchPmtInfo:ACHTrnCode - The transaction code to be used for the ACH item, as governed by NACHA rules.
          depAdd.setACHPmtInfo(achPmtInfo);
          
          accountAdd.setDepAdd(depAdd);
        }
      
      AcctAddResponse accountAddResponse = depositSvc.acctAdd(accountAdd);
      return accountAddResponse;
}
    
    private TrnAddResponse doTransactionAdd(String username, Map allFields, TransactionService transacationSvc)  
    throws MessageFault
    {
        
        if (transacationSvc == null)
        {
            transacationSvc = createTransactionService();
        }
                     
        TrnAdd transacationAdd = new TrnAdd();

        /* ************************************************
         *  TrnAdd:MsgRqHdr                               *
         * ************************************************/
        MsgRqHdrCType msgRq = new MsgRqHdrCType();
        msgRq.setJXchangeHdr(generateJXChangeHeader(username));
        transacationAdd.setMsgRqHdr(msgRq);


        /* ************************************************
         *  TrnAdd:AccountId                              *
         * ************************************************/
        AccountIdCType accountIdCType = new AccountIdCType();
        
        String field = (String)allFields.get("ACCTNO");
        if (field != null)
        {
          AcctIdType acctId = new AcctIdType();        
          acctId.setValue(field);
          accountIdCType.setAcctId(acctId);
        }
        
        field = (String)allFields.get("ACTYPE");
        if (field != null)
        {
          AcctTypeType acctType = new AcctTypeType();
          acctType.setValue(field);
          accountIdCType.setAcctType(acctType);        
        }

        transacationAdd.setAccountId(accountIdCType); 
        
        
        /* ************************************************
         *  TrnAdd:TrnInfo                                *
         * ************************************************/
        TrnInfoCType trnInfo = new TrnInfoCType();
        
        // TrnAdd:TrnInfo:Amt - This is the amount or quantity.        
        field = (String)allFields.get("AMOUNT");
        if (field != null)
        {
          AmtType amount = new AmtType();
          amount.setValue(new BigDecimal(field));
          trnInfo.setAmt(amount);
        }
        
        // TrnAdd:TrnInfo:TrnCodeCode - The code that identifies the behavior of a monetary transaction.
        // Need to get this code from FiveStar
        field = (String)allFields.get("TRANCODE");
        if (field != null)
        {
          TrnCodeCodeType transcationCode = new TrnCodeCodeType();
          transcationCode.setValue(field);
          trnInfo.setTrnCodeCode(transcationCode);
        }
        
        // TrnAdd:TrnInfo:EftType - The type of electronic transaction.
        // TrnAdd:TrnInfo:EffDt - The date assigned to transactions when it is different from the posting date.
        // TrnAdd:TrnInfo:SrcCode - Source code. The source of a transaction. Where it was generated from.
        // TrnAdd:TrnInfo:BatchNum - The integer that groups transactions together. The batch number is often used to trace the origins of transacations.
        // TrnAdd:TrnInfo:ChkNum - The number(s) or character(s) assigned to monetary drafts, often times referred to as the serial number
        // TrnAdd:TrnInfo:DrCr - This is either debit or credit.
        // TrnAdd:TrnInfo:TrnDescArray
        // TrnAdd:TrnInfo:RefDescCode - This is a code that references a longer description. Used mostly in GL applications where a standard description is used so often that a code replacement is preferable.
        // TrnAdd:TrnInfo:OffCode - This is the allowed values for officer code that are bank defined.
        field = (String)allFields.get("OFFICR");
        if (field != null)
        {
          OffCodeType offCode = new OffCodeType();
          offCode.setValue(field);
          trnInfo.setOffCode(offCode);
        }
        
        // TrnAdd:TrnInfo:BrCode - This is the branch code.
        field = (String)allFields.get("BRANCH");
        if (field != null)
        {
          BrCodeType branchCode = new BrCodeType();
          branchCode.setValue(field);
          trnInfo.setBrCode(branchCode);
        }
        
        // TrnAdd:TrnInfo:GLCostCtr - The GL cost center provided for bank use in reporting the account to a specific GL cost center.
        field = (String)allFields.get("GLCOST");
        if (field != null)
        {
          GLCostCtrType glCost = new GLCostCtrType();
          glCost.setValue(field);
          trnInfo.setGLCostCtr(glCost);
        }
        
        // TrnAdd:TrnInfo:GLProdCode - The GL product code provided for bank use in reporting the account to a specific GL product code.
        field = (String)allFields.get("GLPROD");
        if (field != null)
        {
          GLProdCodeType glProd = new GLProdCodeType();
          glProd.setValue(field);
          trnInfo.setGLProdCode(glProd);
        }
        
        // TrnAdd:TrnInfo:GLInterfaceCode - A code that describes the GL account number which this transaction's interface applies.
        // TrnAdd:TrnInfo:RunNum - The Run number. A way of grouping items together. Typical series is Run/Batch/Seq.
        // TrnAdd:TrnInfo:RtNum - Routing number.
        // TrnAdd:TrnInfo:FltSchedCode - This code represents the float schedule to be used by the service provider.
        // TrnAdd:TrnInfo:FltDays - This code represents the float schedule to be used by the service provider.
        // TrnAdd:TrnInfo:ImgNum - The number(s) or character(s) that identifies the key of the transaction's stored image.
        // TrnAdd:TrnInfo:MemoPostOnly - If a Y is sent then the transaction is only to be memo posted.
        // TrnAdd:TrnInfo:ColBalAmt - Amount that should be applied to the collected balance of the account.
        // TrnAdd:TrnInfo:AvlBalAmt - Amount that should be applied to the available balance of the account.
        // TrnAdd:TrnInfo:LdgrBalAmt - Amount that should be applied to the ledger balance of the account.
        // TrnAdd:TrnInfo:SrcFundsCode - A code that represents the source of funds for credit transactions and the outgoing source for debit
        // TrnAdd:TrnInfo:ChkDlvryMthd - The method to deliver a check disbursement.
        // TrnAdd:TrnInfo:MemoPostHldOvr

        transacationAdd.setTrnInfo(trnInfo);
        
        TrnAddResponse transacationAddResponse = transacationSvc.trnAdd(transacationAdd);

        return transacationAddResponse;
    }
    
  private boolean processAddAccount(String username, Map allFields, DataNode appNode, String productType,
                                    DepositService depositSvc, String customerId, List log, StringBuffer msg) 
  {
    Map accountAddFields = new HashMap();
    accountAddFields.putAll(allFields);
    
    generateCallSpecificFields("DD Account Add", accountAddFields);
    
    try 
    {
        AcctAddResponse response = doAccountAdd(username, accountAddFields, appNode, productType,
                                                customerId, depositSvc);
        if (response != null) 
        {
            if (response.getRsStat().equalsIgnoreCase("Success"))
                return true;
        }
    }
    catch (MessageFault mf)
    {
      StringBuilder mfText = generateFaultMessage(mf);
      msg.append("One or more faults occurred while creating an account:\n\n");
      msg.append(mfText);
      log.add("Unable to add Account:");
      log.add(changeLineBreaks(mfText.toString()));
    }
    catch (DatatypeConfigurationException e)
    {
      log.add("Unable to add Account: DataTypeConfig Error encountered for date processing.");
    }
    return false;
  }
  
  
  private boolean processEFTCardAdd(String username, String primaryCustomerID, Map allFields, CustomerService customerSvc,
                                    List log, StringBuffer msg)
  {
    Map cardAddFields = new HashMap();
    cardAddFields.putAll(allFields);

    generateCallSpecificFields("EFT Card Add", cardAddFields);

    EFTCardAdd cardAdd = new EFTCardAdd();

    MsgRqHdrCType msgRq = new MsgRqHdrCType();
    msgRq.setJXchangeHdr(generateJXChangeHeader(username));
    cardAdd.setMsgRqHdr(msgRq);

    CustIdType custID = new CustIdType();
    custID.setValue(primaryCustomerID);
    cardAdd.setCustId(custID);
    
    String field = (String)cardAddFields.get("EMBOSNAME");
    if (field != null)
    {
      EFTCardAddInfoArrayAType cardAddInfoArray = new EFTCardAddInfoArrayAType();
      List<EFTCardAddInfoRecCType> array = cardAddInfoArray.getEFTCardAddInfoRecs();
            
      EmbosNameType embosName = new EmbosNameType();
      embosName.setValue(field);
      
      EFTCardAddInfoRecCType cardAddInfo = new EFTCardAddInfoRecCType();
      cardAddInfo.setEmbosName(embosName);
      
      array.add(cardAddInfo);
      cardAdd.setEFTCardAddInfoArray(cardAddInfoArray);
    }
    
    field = (String)cardAddFields.get("CARDTYPE");
    if (field != null)
    {
      EFTCardTypeType cardType = new EFTCardTypeType();
      cardType.setValue(field);
      
      cardAdd.setEFTCardType(cardType);
    }
    
    try 
    {
      EFTCardAddResponse response = customerSvc.eftCardAdd(cardAdd);
      if (response != null) 
      {
        if (response.getRsStat().equalsIgnoreCase("Success")) return true;
      }
    }
    catch (MessageFault mf)
    {
      StringBuilder mfText = generateFaultMessage(mf);
      msg.append("One or more faults occurred while creating an account:\n\n");
      msg.append(mfText);
      log.add("Unable to add Account:");
      log.add(changeLineBreaks(mfText.toString()));
    }
    
    return false;
  }
  
  
    private boolean processTransactionAdd(String username, Map allFields, TransactionService transactionSvc, List log, StringBuffer msg) 
    {
      Map transactionAddFields = new HashMap();
      transactionAddFields.putAll(allFields);
      
      generateCallSpecificFields("Transaction Add", transactionAddFields);

      try 
      {
          TrnAddResponse response = doTransactionAdd(username, transactionAddFields, transactionSvc);
          if (response != null) 
          {
              if (response.getRsStat().equalsIgnoreCase("Success"))
                  return true;
          }
      }
      catch (MessageFault mf)
      {
        StringBuilder mfText = generateFaultMessage(mf);
        msg.append("One or more faults occurred while adding a transaction:\n\n");
        msg.append(mfText);
        log.add("Unable to add Transaction:");
        log.add(changeLineBreaks(mfText.toString()));
      }
      return false;
    }
  
  private boolean processAddCustRel(String username, CustomerService customerSvc, String acctId, String acctType, String primaryCustomerID,  String relCustId, String relCode, List log, StringBuffer msg) 
  {
      try 
      {
          CustRelAddResponse response = doCustomerRelationshipAdd(username, customerSvc, acctId, acctType, primaryCustomerID, relCustId, relCode);
          if (response != null) 
          {
              if (response.getRsStat().equalsIgnoreCase("Success"))
                  return true;
          }
      }
      catch (MessageFault mf)
      {
        StringBuilder mfText = generateFaultMessage(mf);
        msg.append("One or more faults occurred while adding an relationship to the account:\n\n");
        msg.append(mfText);
        log.add("Unable to Add Customer Relationship:");
        log.add(changeLineBreaks(mfText.toString()));
      }
      return false;
  }
  
  private String AddCustomerAndGetCustId(String username, DataNode appNode, DataNode bwrNode, DataNode primaryBwrNode,
                                         CustomerService customerSvc, boolean isCustodian, Map baseFields,
                                         Map<String, Integer> bwrTypeCountTable, Integer bwrIndex, List log, StringBuffer errorMsg) 
  {
      /*   
      String custId = null;
      try
      {
          CustAddResponse response = doCustomerAdd(username, branchRefID, bwrNode, primaryBwrNode, customerSvc, isCustodian);
          if (response != null) 
          {
              CustIdType custIdType  = response.getCustId();
              custId = custIdType.getValue();
              log.add("Customer Record Created (CIF#): " + custId);
              
              //Customer was added, got back a customer ID, now set in the applicant data node.
              if (isCustodian) 
              {
                  bwrNode.setFieldData(username, "minCIF", custId);
              }
              else
              {
                  bwrNode.setFieldData(username, CSFieldNames.FN_CUST_NUM, custId);
              }
          }
      }
      catch (MessageFault mf)
      {
        StringBuilder mfText = generateFaultMessage(mf);
        msg.append("One or more faults occurred while performing an customer add:\n\n");
        msg.append(mfText);
        log.add("Unable to add Customer:");
        log.add(changeLineBreaks(mfText.toString()));

      }
      */

      boolean isBorrowerType = bwrNode.getDataType().equals(NodeUtils.BWR_DN_TYPE);

      String cifNum = null;
      
      String refID = (String)appNode.getFieldData(username, CSFieldNames.FN_APP_REF_ID);
      String bwrType = (String)bwrNode.getFieldData(getName(), CSFieldNames.FN_BWR_TYPE);
      int bwrTypeIndex = indexOfThisBorrowerType(bwrType, bwrTypeCountTable);
  
      Map bwrFields = new HashMap();
      bwrFields.putAll(baseFields);
      bwrFields.putAll(bwrNode.getFieldData(""));
      bwrFields.putAll(bwrNode.getSystemData());
      bwrFields.put("bwrIndex", String.valueOf(bwrIndex));
      bwrFields.put("bwrTypeIndex", String.valueOf(bwrTypeIndex));
      generateCallSpecificFields("CFPLAT", bwrFields);
            
      // Create and populate the CustAdd request object.
      //
      CustAdd custAdd = null;        
      try
      {
        custAdd = assembleCustAdd(username, bwrFields);
        //general.errLog( "PAST: custAdd = assembleCustAdd(username, bwrFields);", "JXC.log" );
      }
      catch (Exception e)
      {
        ExceptionLogger.logException(e);
        String errMsg = refID + ": Error assembling CustAdd: " + e;
        log.add(errMsg);
        errorMsg.append(errMsg);
        return null;
      }
              
      // Execute the customer add call.
      //
      CustAddResponse custAddResponse = null;        
      try
      {
        custAddResponse = customerSvc.custAdd(custAdd);
        CustIdType custIDType = custAddResponse.getCustId();
        
        // We successfully added the customer into Jack Henry.  Now retrieve the
        // customer number (CIF) and set it into the borrower data node.
        //
        cifNum = custIDType.getValue();
        bwrNode.setFieldData(getName(), isBorrowerType ? "atCIF" : "minCIF", cifNum);
        
        log.add("CIF created: " + cifNum);
        
        ++bwrIndex;
      }
      catch (MessageFault mf)
      {
        StringBuilder mfText = generateFaultMessage(mf);
        log.add("Unable to add Customer:");
        log.add(changeLineBreaks(mfText.toString()));
        errorMsg.append("One or more faults occurred while performing a customer add:\n\n");
        errorMsg.append(mfText);
        return null;
      }
    
      return cifNum;
  }
  
  
  private GenAcctIdArrayAType generateAcctIdArray(String username, CustomerService customerSvc, Map<String, String> inputParams, List log, StringBuffer msg)
  {
      GenAcctIdArrayAType acctIdArray = null;
      
      try 
      {
          AcctIdGenResponse response = doAccountIdGenerator(username, customerSvc, inputParams);          
          acctIdArray = response.getGenAcctIdArray();
      }
      catch (MessageFault mf)
      {
        StringBuilder mfText = generateFaultMessage(mf);
        msg.append("One or more faults occurred while generating an account id:\n\n");
        msg.append(mfText);
        log.add("Acct Id Generator Error:");
        log.add(changeLineBreaks(mfText.toString()));
      }

      return acctIdArray;
  }
  
  private SvcDftResponse AcctAddServiceDefault(String username, CustomerService customerSvc, CriteriaArrayAType criteriaArray, List log, StringBuffer msg) 
  {
    SvcDftResponse response = null;
    try
    {
      log.add("Executing Account Add Service Defaults");
      response = doServiceDefault(username, customerSvc, "AcctAdd", 1, criteriaArray);        
      if (response != null)
      {
        List<String> sdFields = new ArrayList<String>();
        
        try
        {
          DepRegRptInfoCType depRegInfo = response.getDepRegRptInfo();
          if (depRegInfo != null)
          {
            sdFields.add("DepRegRptInfo");
            sdFields.add("-------------");
            sdFields.add("GLCOST = " + depRegInfo.getGLCostCtr() != null ? depRegInfo.getGLCostCtr().getValue() : "NULL");          
            sdFields.add("GLPROD = " + depRegInfo.getGLProdCode() != null ? depRegInfo.getGLProdCode().getValue() : "NULL");
          }
          
          DepAcctInfoCType depAcctInfo = response.getDepAcctInfo();
          if (depAcctInfo != null)
          {
            sdFields.add("DepAcctInfo");
            sdFields.add("-----------");
            sdFields.add("NOCLOS = " + depAcctInfo.getClsOnZeroBal() != null ? depAcctInfo.getClsOnZeroBal().getValue() : "NULL");          
            sdFields.add("CHKGTY = " + depAcctInfo.getChkGuar() != null ? depAcctInfo.getChkGuar().getValue() : "NULL");
            sdFields.add("ATMCRD = " + depAcctInfo.getATMCard() != null ? depAcctInfo.getATMCard().getValue() : "NULL");
            sdFields.add("MALHLD = " + depAcctInfo.getHldMailCode() != null ? depAcctInfo.getHldMailCode().getValue() : "NULL");
            sdFields.add("HIVOL = " + depAcctInfo.getHighVolAcctCode() != null ? depAcctInfo.getHighVolAcctCode().getValue() : "NULL");
            sdFields.add("RELACT = " + depAcctInfo.getRelAcctId() != null ? depAcctInfo.getRelAcctId().getValue() : "NULL");
            sdFields.add("RACTTP = " + depAcctInfo.getRelAcctType() != null ? depAcctInfo.getRelAcctType().getValue() : "NULL");
            sdFields.add("LSTPST = " + depAcctInfo.getLstPostAcctCode() != null ? depAcctInfo.getLstPostAcctCode().getValue() : "NULL");
            sdFields.add("XMASPL = " + depAcctInfo.getClubPln() != null ? depAcctInfo.getClubPln().getValue() : "NULL");
            sdFields.add("RPBLK# = " + depAcctInfo.getRepoBlkId() != null ? depAcctInfo.getRepoBlkId().getValue() : "NULL");
            sdFields.add("SECURE = " + depAcctInfo.getAcctLvlSecCode() != null ? depAcctInfo.getAcctLvlSecCode().getValue() : "NULL");
            sdFields.add("DDLANG = " + depAcctInfo.getLangType() != null  ? depAcctInfo.getLangType().getValue() : "NULL");
          }
          
          DepInfoRecCType depInfo = response.getDepInfoRec();
          if (depInfo != null)
          {
            sdFields.add("DepInfoRec");
            sdFields.add("----------");
            sdFields.add("OFFICR = " + depInfo.getOffCode() != null ? depInfo.getOffCode().getValue() : "NULL");
            sdFields.add("STATUS = " + depInfo.getAcctStat() != null ? depInfo.getAcctStat().getValue() : "NULL");
            sdFields.add("DATOP7 = " + depInfo.getOpenDt() != null ? depInfo.getOpenDt().getValue().toString() : "NULL");
            sdFields.add("SCCODE = " + depInfo.getProdCode() != null ? depInfo.getProdCode().getValue() : "NULL");
            sdFields.add("SCTYPE = " + depInfo.getSerChgWav() != null ? depInfo.getSerChgWav().getValue() : "NULL");
            sdFields.add("SGCODE = " + depInfo.getSigVerifyCode() != null ? depInfo.getSigVerifyCode().getValue() : "NULL");
            sdFields.add("SPMESG = " + depInfo.getTellerSICCode() != null ? depInfo.getTellerSICCode().getValue() : "NULL");
            sdFields.add("SALESAC = " + depInfo.getSalesPerson() != null ? depInfo.getSalesPerson().getValue() : "NULL");
          }
          
          DepRateIntInfoCType depRateInfo = response.getDepRateIntInfo();
          if (depRateInfo != null)
          {
            sdFields.add("DepRateIntInfo");
            sdFields.add("--------------");
            sdFields.add("PCHECK = " + depRateInfo.getIntDisp() != null ? depRateInfo.getIntDisp().getValue() : "NULL");
            sdFields.add("PCHACT = " + depRateInfo.getIntDispAcctId() != null ? depRateInfo.getIntDispAcctId().getValue() : "NULL");
            sdFields.add("PCHATY = " + depRateInfo.getIntDispAcctType() != null ? depRateInfo.getIntDispAcctType().getValue() : "NULL");
            
            VarIntRateInfoCType varIntRateInfo = depRateInfo.getVarIntRateInfo();
            if (varIntRateInfo != null)
            {
              sdFields.add("PVAR = " + varIntRateInfo.getRateVar() != null ? varIntRateInfo.getRateVar().getValue().toString() : "NULL");
              sdFields.add("PVAR1 = " + varIntRateInfo.getRateVarCode() != null ? varIntRateInfo.getRateVarCode().getValue() : "NULL");
              sdFields.add("PFLOOR = " + varIntRateInfo.getRateFlr() != null ? varIntRateInfo.getRateFlr().getValue().toString() : "NULL");
              sdFields.add("PCEIL = " + varIntRateInfo.getRateCeil() != null ? varIntRateInfo.getRateCeil().getValue().toString() : "NULL");
              sdFields.add("REVDT7 = " + varIntRateInfo.getRateRevDt() != null ? varIntRateInfo.getRateRevDt().getValue().toString() : "NULL");
              sdFields.add("TERM = " + varIntRateInfo.getRateRevTerm() != null ? String.valueOf(varIntRateInfo.getRateRevTerm().getValue()) : "NULL");
              sdFields.add("TERMCD = " + varIntRateInfo.getRateRevTermUnits() != null ? varIntRateInfo.getRateRevTermUnits().getValue() : "NULL");
            }
          }
          
          DepStmtInfoCType depStmtInfo = response.getDepStmtInfo();
          if (depStmtInfo != null)
          {
            sdFields.add("DepStmtInfo");
            sdFields.add("--------------");
            sdFields.add("STCYC = " + depStmtInfo.getStmtCycle() != null ? depStmtInfo.getStmtCycle().getValue() : "NULL");
            sdFields.add("INTCYC = " + depStmtInfo.getIntCycle() != null ? String.valueOf(depStmtInfo.getIntCycle().getValue()) : "NULL");
            sdFields.add("SCCYC = " + depStmtInfo.getSerChgCycle() != null ? depStmtInfo.getSerChgCycle().getValue() : "NULL");
            sdFields.add("NXTSTM7 = " + depStmtInfo.getNxtStmtDt() != null ? String.valueOf(depStmtInfo.getNxtStmtDt().getValue()) : "NULL");
            sdFields.add("STMDAY = " + depStmtInfo.getStmtDay() != null ? String.valueOf(depStmtInfo.getStmtDay().getValue()) : "NULL");
            sdFields.add("STMFRC = " + depStmtInfo.getStmtFreqCode() != null ? depStmtInfo.getStmtFreqCode().getValue() : "NULL");
            sdFields.add("STMFRQ = " + depStmtInfo.getStmtFreq() != null ? String.valueOf(depStmtInfo.getStmtFreq().getValue()) : "NULL");
            sdFields.add("STMPR = " + depStmtInfo.getStmtPrtCode() != null ? depStmtInfo.getStmtPrtCode().getValue() : "NULL");
            sdFields.add("STMSC = " + depStmtInfo.getStmtSerChg() != null ? depStmtInfo.getStmtSerChg().getValue() : "NULL");
            sdFields.add("COMBIN = " + depStmtInfo.getIncCombStmt() != null ? depStmtInfo.getIncCombStmt().getValue() : "NULL");
            sdFields.add("STMPAS = " + depStmtInfo.getStmtPasCode() != null ? depStmtInfo.getStmtPasCode().getValue() : "NULL");
            sdFields.add("PRTCKO = " + depStmtInfo.getImgPrtChkOrderCode() != null ? depStmtInfo.getImgPrtChkOrderCode().getValue() : "NULL");
            sdFields.add("TRUNC = " + depStmtInfo.getItmTrunc() != null ? depStmtInfo.getItmTrunc().getValue() : "NULL");
            sdFields.add("IPERPG = " + depStmtInfo.getImgItemsPerPgCode() != null ? depStmtInfo.getImgItemsPerPgCode().getValue() : "NULL");
            sdFields.add("IFROBK = " + depStmtInfo.getImgItemsFrntBackCode() != null ? depStmtInfo.getImgItemsFrntBackCode().getValue() : "NULL");
            sdFields.add("ICREDS = " + depStmtInfo.getImgIncCrCode() != null ? depStmtInfo.getImgIncCrCode().getValue() : "NULL");
            sdFields.add("DDSTCYRSFQ = " + depStmtInfo.getStmtCycResetFreqCode() != null ? depStmtInfo.getStmtCycResetFreqCode().getValue() : "NULL");
            sdFields.add("DDSTMFMTCD = " + depStmtInfo.getStmtFormatCode() != null ? depStmtInfo.getStmtFormatCode().getValue() : "NULL");
            sdFields.add("DDPSCOD = " + depStmtInfo.getElecStmtType() != null ? depStmtInfo.getElecStmtType().getValue() : "NULL");
          }
          
          DepNSFODInfoCType depNSFInfo = response.getDepNSFODInfo();
          if (depNSFInfo != null)
          {
            sdFields.add("DepNSFODInfo");
            sdFields.add("--------------");
            sdFields.add("ODLMT = " + depNSFInfo.getODLmt() != null ? String.valueOf(depNSFInfo.getODLmt().getValue()) : "NULL");
            sdFields.add("AUTNSF = " + depNSFInfo.getAutoNSFFee() != null ? depNSFInfo.getAutoNSFFee().getValue() : "NULL");
            sdFields.add("CODCHG = " + depNSFInfo.getChgODCode() != null ? depNSFInfo.getChgODCode().getValue() : "NULL");
            sdFields.add("CODFEE = " + depNSFInfo.getChgODFeeMin() != null ? String.valueOf(depNSFInfo.getChgODFeeMin().getValue()) : "NULL");
            sdFields.add("CODFMX = " + depNSFInfo.getChgODFeeMax() != null ? String.valueOf(depNSFInfo.getChgODFeeMax().getValue()) : "NULL");
            sdFields.add("CODFPC = " + depNSFInfo.getChgODFeePct() != null ? String.valueOf(depNSFInfo.getChgODFeePct().getValue()) : "NULL");
            sdFields.add("CODFDY = " + depNSFInfo.getChgODFeeDays() != null ? String.valueOf(depNSFInfo.getChgODFeeDays().getValue()) : "NULL");
            sdFields.add("CODFBL = " + depNSFInfo.getChgODFeeBal() != null ? String.valueOf(depNSFInfo.getChgODFeeBal().getValue()) : "NULL");
            sdFields.add("ODIMAX = " + depNSFInfo.getDlyODMaxChg() != null ? String.valueOf(depNSFInfo.getDlyODMaxChg().getValue()) : "NULL");
            sdFields.add("DDODNOTDY1 = " + depNSFInfo.getODNot1Days() != null ? String.valueOf(depNSFInfo.getODNot1Days().getValue()) : "NULL");
            sdFields.add("DDODNOTDY2 = " + depNSFInfo.getODNot2Days() != null ? String.valueOf(depNSFInfo.getODNot2Days().getValue()) : "NULL");
            sdFields.add("DDODNOTDY3 = " + depNSFInfo.getODNot3Days() != null ? String.valueOf(depNSFInfo.getODNot3Days().getValue()) : "NULL");
            sdFields.add("DDODNOTDY4 = " + depNSFInfo.getODNot4Days() != null ? String.valueOf(depNSFInfo.getODNot4Days().getValue()) : "NULL");
            sdFields.add("DDODNOTDY5 = " + depNSFInfo.getODNot5Days() != null ? String.valueOf(depNSFInfo.getODNot5Days().getValue()) : "NULL");
            sdFields.add("DDODNOTDY6 = " + depNSFInfo.getODNot6Days() != null ? String.valueOf(depNSFInfo.getODNot6Days().getValue()) : "NULL");
            sdFields.add("PSTAFTNSF = " + depNSFInfo.getPostAFTNSFCode() != null ? depNSFInfo.getPostAFTNSFCode().getValue() : "NULL");
            sdFields.add("ALLREDEP = " + depNSFInfo.getAllowReDepCode() != null ? depNSFInfo.getAllowReDepCode().getValue() : "NULL");
            sdFields.add("NOREDEP = " + depNSFInfo.getNumAllowReDepItems() != null ? String.valueOf(depNSFInfo.getNumAllowReDepItems().getValue()) : "NULL");
            sdFields.add("SNDREDPNO = " + depNSFInfo.getReDepNotCode() != null ? depNSFInfo.getReDepNotCode().getValue() : "NULL");
            sdFields.add("UCFMAX = " + depNSFInfo.getDlyUCFMaxChg() != null ? String.valueOf(depNSFInfo.getDlyUCFMaxChg().getValue()) : "NULL");
          }
          
          DepRegRptInfoCType depRegRptInfo = response.getDepRegRptInfo();
          if (depRegRptInfo != null)
          {            
            sdFields.add("DepRegRptInfo");
            sdFields.add("-------------");
            sdFields.add("CALLREP = " + depRegRptInfo.getCallRptCode() != null ? depRegRptInfo.getCallRptCode().getValue() : "NULL");
            sdFields.add("ODRGRPT = " + depRegRptInfo.getODRegRptCode() != null ? depRegRptInfo.getODRegRptCode().getValue() : "NULL");
            
            CRARecCType craRec = depRegRptInfo.getCRARec();
            if (craRec != null)
            {
              sdFields.add("SMSA = " + craRec.getCRASMSACode() != null ? craRec.getCRASMSACode().getValue() : "NULL");
              sdFields.add("CRALOC = " + craRec.getCRALoc() != null ? craRec.getCRALoc().getValue() : "NULL");
              sdFields.add("CRASTA = " + craRec.getCRAStateCode() != null ? craRec.getCRAStateCode().getValue() : "NULL");
              sdFields.add("COUNTY = " + craRec.getCRACountyCode() != null ? craRec.getCRACountyCode().getValue() : "NULL");
            }
          }

          FileWriter fw = new FileWriter("data/jxcBooking/_ServiceDefault.log");
          for (String s : sdFields)
          {
            fw.write(s);
            fw.write("\r\n");
          }
          fw.close();
        }
        catch (Exception e)
        {
          log.add("Unable to log service defaults: " + e);
          ExceptionLogger.logException(e);
        }        
      }
    }
    catch (MessageFault mf)
    {
      StringBuilder mfText = generateFaultMessage(mf);
      msg.append("One or more faults occurred while creating an account:\n\n");
      msg.append(mfText);
      log.add("Service Default (AcctAdd) Error:");
      log.add(changeLineBreaks(mfText.toString()));
    }

    return response;
  }
  
    
  private SvcDftResponse TrnAddServiceDefault(String username, CustomerService customerSvc, CriteriaArrayAType criteriaArray, List log, StringBuffer msg) 
  {
      SvcDftResponse response = null;
      try
      {
          response = doServiceDefault(username, customerSvc, "TrnAdd", 1, criteriaArray);
      }
      catch (MessageFault mf)
      {
        StringBuilder mfText = generateFaultMessage(mf);
        msg.append("One or more faults occurred while creating an account:\n\n");
        msg.append(mfText);
        log.add("Service Default (AcctAdd) Error:");
        log.add(changeLineBreaks(mfText.toString()));
      }
      return response;
  }
    

  private String getApplicantStreet1(HashtableX applicantFields, boolean isCustodian, boolean isMinMailSameAsPrmAddrC)
  { 
    String applicantStreet1 = null;
    if (isCustodian && !isMinMailSameAsPrmAddrC) 
    {
        applicantStreet1 = (String)applicantFields.get("minAddr");
    }
    else 
    {
        String addressType = (String)applicantFields.get(CSFieldNames.FN_BWR_ADDR_TYPE);
        // Standard address
        if (addressType.equalsIgnoreCase("0")) 
        {
            applicantStreet1 = AppImportUtils.createAddressLine(applicantFields);
        }
        // Rural Route
        else if (addressType.equalsIgnoreCase("1")) 
        {
            applicantStreet1 = (String)applicantFields.get("atRtTypeD") + "Number: " + (String)applicantFields.get(CSFieldNames.FN_BWR_RT_NUM) + " Box:" + (String)applicantFields.get(CSFieldNames.FN_BWR_BOX_NUM);
        }
        // PO BOX
        else if (addressType.equalsIgnoreCase("2"))
        {
            applicantStreet1 = "PO Box " + (String)applicantFields.get(CSFieldNames.FN_BWR_PO_BOX);
        }
    }
    return applicantStreet1;
  }


  private boolean processConsumerApplication(String username, DataNode appNode, List log, StringBuffer errorMsg)
  {
    //general.errLog( "START processConsumerApplication(...)", "JXC.log" );    

    String appID = (String)appNode.getFieldData(username, CSFieldNames.FN_APP_ID);
    String refID = (String)appNode.getFieldData(username, CSFieldNames.FN_APP_REF_ID);

    DataNode primaryApplicant = null;
    try
    {  
      String branchId = (String) appNode.getFieldData(username, CSFieldNames.FN_BRANCH_ID);
      Location location = Location.find(Integer.parseInt(branchId));
      String branchRefId = location.getLocationRefId();

      log.add("App ID: " + appID);
      log.add("Ref ID: " + refID);
      log.add("Branch Ref ID: " + branchRefId);
                        
      //DataNode primaryApplicant = CSUtil.getPrimaryApplicant(appNode);
      //
      primaryApplicant = CSUtil.getPrimaryApplicant( appNode );
      if (primaryApplicant == null)
      {
        String msg = "Primary applicant not found.";
        log.add(msg);
        errorMsg.append(msg);
        return false;
      }
    }
    catch (Exception e)
    {
      ExceptionLogger.logException(e);
      
      String msg = "Unexpected Error: " + e;
      log.add(msg);
      errorMsg.append(msg);
      return false;
    }

    if (LOOKUP_RATE)
    {
      try
      {
        AppCalcs.calculatePricingRate(appNode);
      }
      catch (Exception e)
      {
        String errMsg = refID + ": Unable to lookup pricing rate: " + e;
        log.add(errMsg);
        errorMsg.append(errMsg);
        return false;
      }
    }

    String productID = (String)appNode.getFieldData(username, CSFieldNames.FN_PRODUCT_ID);

    String branchStr = (String) appNode.getFieldData("", CSFieldNames.FN_BRANCH_ID);
    int branchLoc = Integer.parseInt(branchStr);

    List<DataNode>[] info = generateBorrowerAndCollateralList(appNode);
    List<DataNode> borrowerList = info[0];
    List<DataNode> collateralList = info[1];
    adjustPrimaryBorrower(borrowerList);

    // Aggregate the application fields necessary to set all of the web service method calls.
    //
    Map baseFields = appNode.getFieldData("");
    baseFields.putAll(appNode.getSystemData());
    baseFields.put("bwrCount", String.valueOf(borrowerList.size()));

    generalPurposeSelection(baseFields);
    involvedPersonnel(appNode, baseFields);
    codeTableFields(branchLoc, baseFields);
    contractTermsFields(appNode, baseFields);
    lastDecisionFields(appNode, baseFields);
    totalBorrowerAnnualIncome(appNode, baseFields);
    firstRealEstateCollateral(collateralList, baseFields);
    dealerFields(appNode, baseFields);
    branchFields(branchLoc, baseFields);
    trippedManagementRules(appNode, borrowerList, baseFields);
    addMiscFields(appNode, baseFields);
    generatePreProcessFields(baseFields);
    generateProductSpecificFields(productID, baseFields);

    // The primary applicant CIF is used for the relationship transaction that
    // is necessary when there are multiple applicants on the loan.
    //
    String primaryApplicantCIF = null;    
    List<String> coBorrowerCIFList = new ArrayList<String>();
    List<String> relationshipList = new ArrayList<String>();

    //
    // Process the applicants first (CFPLAT).
    //

    // This map keeps track of how many of a certain borrower type there
    // is so we can create a field that contains the index of the type.
    // "Co-applicant 1, Co-applicant 2, Co-signer 1, etc."
    //
    Map<String, Integer> bwrTypeCountTable = new HashMap<String, Integer>();

    CustomerService customerSvc = createCustomerService();
    
    int bwrIndex = 0;
    for (DataNode bwrNode : borrowerList)
    {      
      log.add("Checking applicant: " + bwrNode.getIndex());
      //general.errLog( "Checking applicant: " + bwrNode.getIndex(), "JXC.log" );

      boolean isBorrowerType = bwrNode.getDataType().equals(NodeUtils.BWR_DN_TYPE);
      
      // Only fill a template if the borrower does not already
      // have a CIF number.
      //
      String cifNum = (String)bwrNode.getFieldData(getName(), isBorrowerType ? "atCIF" : "OnrCIF");
      log.add("CIF: " + cifNum);
      //general.errLog( "CIF: " + cifNum, "JXC.log" );

      if (cifNum == null || cifNum.length() == 0)
      {
        log.add("No CIF... executing CustomerAdd.");
        //general.errLog( "No CIF... executing CustomerAdd.", "JXC.log" );

        String bwrType = (String)bwrNode.getFieldData(getName(), CSFieldNames.FN_BWR_TYPE);
        int bwrTypeIndex = indexOfThisBorrowerType(bwrType, bwrTypeCountTable);

        Map bwrFields = new HashMap();
        bwrFields.putAll(baseFields);
        bwrFields.putAll(bwrNode.getFieldData(""));
        bwrFields.putAll(bwrNode.getSystemData());
        bwrFields.put("bwrIndex", String.valueOf(bwrIndex));
        bwrFields.put("bwrTypeIndex", String.valueOf(bwrTypeIndex));
        generateCallSpecificFields("CFPLAT", bwrFields);
        
        // Create and populate the CustAdd request object.
        //
        CustAdd custAdd = null;        
        try
        {
          custAdd = assembleCustAdd(username, bwrFields);
          //general.errLog( "PAST: custAdd = assembleCustAdd(username, bwrFields);", "JXC.log" );
        }
        catch (Exception e)
        {
          ExceptionLogger.logException(e);
          String errMsg = refID + ": Error assembling CustAdd: " + e;
          log.add(errMsg);
          errorMsg.append(errMsg);
          return false;
        }
                
        // Execute the customer add call.
        //
        CustAddResponse custAddResponse = null;        
        try
        {
          custAddResponse = customerSvc.custAdd(custAdd);
          CustIdType custIDType = custAddResponse.getCustId();
          
          // We successfully added the customer into Jack Henry.  Now retrieve the
          // customer number (CIF) and set it into the borrower data node.
          //
          cifNum = custIDType.getValue();
          bwrNode.setFieldData(getName(), isBorrowerType ? "atCIF" : "OnrCIF", cifNum);
          
          log.add("CIF created: " + cifNum);
        }
        catch (MessageFault mf)
        {
          StringBuilder mfText = generateFaultMessage(mf);
          log.add("Unable to add Customer:");
          log.add(changeLineBreaks(mfText.toString()));
          errorMsg.append("One or more faults occurred while performing a customer add:\n\n");
          errorMsg.append(mfText);
          return false;
        }
                        
        bwrFields.clear();
        bwrFields = null;
      }
      
      // Capture the primary applicant CIF.
      //
      String bwrType = (String)bwrNode.getFieldData(getName(), CSFieldNames.FN_BWR_TYPE);
      if (bwrType != null)
      {
        if (bwrType.equals(CSFieldValues.FV_APPLICANT))
        {
          primaryApplicantCIF = cifNum;
          //general.errLog( "primaryApplicantCIF: " + primaryApplicantCIF, "JXC.log" );
        }
        else
        {
          String relType = CONFIG.getSectionProperty("CFPLAT", "RELTYP");
          relType = StringSupport.substituteTags(relType, bwrNode.getFieldData(getName()));
          relType = CmdEvaluator.evaluate(relType);

          //general.errLog( "Co-ApplicantCIF: " + cifNum, "JXC.log" );
          //general.errLog( "Co-ApplicantRelationshipType " + relType, "JXC.log" );
          
          coBorrowerCIFList.add(cifNum);
          relationshipList.add(relType);
        }
      }
      
      ++bwrIndex;
    }

    //general.errLog( "Now process the application (LNPLAT)", "JXC.log" );

    //
    // Now process the application (LNPLAT).
    //    
    Map loanFields = new HashMap();
    loanFields.putAll(baseFields);
    
    // add borrower info fields, as in JHSBooking line 292
    //
    loanFields.putAll( primaryApplicant.getFieldData( "" ) );
    loanFields.putAll( primaryApplicant.getSystemData() );
    addBorrowerInfo( appNode, borrowerList, loanFields );

    generateCallSpecificFields("LNPLAT", loanFields);

    //general.errLog( "Executing LoanAdd.", "JXC.log" );
    
    LoanService loanSvc = createLoanService();

    // Create and populate the loan account object.
    //
    log.add("Executing LoanAdd.");
    //general.errLog( "Executing LoanAdd.", "JXC.log" );

    LnAcctAdd loanAcctAdd = null;
    try
    {
      loanAcctAdd = assembleLoanAccountAdd(username, loanFields);
    }
    catch (Exception e)
    {
      //general.errLog(refID + ": Error assembling LoanAcctAdd: " + e, "JXC.log" );

      ExceptionLogger.logException(e);
      String errMsg = refID + ": Error assembling LoanAcctAdd: " + e;
      log.add(errMsg);
      errorMsg.append(errMsg);
      return false;
    }

    //general.errLog( "Executing LoanAddResponse.", "JXC.log" );

    LnAcctAddResponse loanAddResponse = null;
    try
    {
      loanAddResponse = loanSvc.lnAcctAdd(loanAcctAdd);
    }
    catch (MessageFault mf)
    {
      StringBuilder mfText = generateFaultMessage(mf);
      log.add("Unable to add loan:");
      log.add(changeLineBreaks(mfText.toString()));
      errorMsg.append("One or more faults occurred while performing a loan add:\n\n");
      errorMsg.append(mfText);
      return false;
    }

    //general.errLog( "Executing Create the customer message (LNPLMS) records (per collateral).", "JXC.log" );

    // Create the customer message (LNPLMS) records (per collateral).
    //
    int collIndex = 0;
    for (DataNode collNode : collateralList)
    {
      log.add("Executing CustMsgAdd for collateral: " + collNode.getDescription());
      
      Map collFields = new HashMap();
      collFields.putAll(baseFields);
      collFields.putAll(collNode.getFieldData(""));
      collFields.putAll(collNode.getSystemData());
      collFields.put("collateralIndex", String.valueOf(collIndex));
      generateCallSpecificFields("LNPLMS", collFields);
      ++collIndex;

      //general.errLog( "Now process the application (LNPLMS)", "JXC.log" );

      CustMsgAdd custMsg = null;
      
      try
      {
        //general.errLog( "Now assemble Customer Message Add", "JXC.log" );
        custMsg = assembleCustomerMessageAdd(username, collFields);
      }
      catch (Exception e)
      {
        ExceptionLogger.logException(e);
        String errMsg = refID + ": Error assembling CustMsgAdd: " + e;
        log.add(errMsg);
        errorMsg.append(errMsg);
        return false;
      }
      
      // Do the customer message add transaction.
      //
      CustMsgAddResponse custMsgAddResp = null;
      try
      {
        //general.errLog( "Customer Message Add", "JXC.log" );
        custMsgAddResp = customerSvc.custMsgAdd(custMsg);
      }
      catch (MessageFault mf)
      {
        StringBuilder mfText = generateFaultMessage(mf);
        log.add("Unable to add customer message:");
        log.add(changeLineBreaks(mfText.toString()));
        errorMsg.append("One or more faults occurred while performing a CustMsgAdd:\n\n");
        errorMsg.append(mfText);
        return false;
      }
      
      collFields.clear();
      collFields = null;
    }

    //general.errLog( "Create the optional transaction objects.", "JXC.log" );

    // Create the optional transaction objects.
    //
    VectorX[] optTransactions = CONFIG.getSectionPropertyKeyValues("Transactions");
    if (optTransactions != null)
    {
      VectorX transactions = optTransactions[0];
      VectorX rules = optTransactions[1];

      //general.errLog( "transactions: "+transactions, "JXC.log" );

      for (int i = 0, c = transactions.size(); i < c; ++i)
      {
        String transaction = (String)transactions.get(i);
        //general.errLog( "transaction: "+transaction, "JXC.log" );
        
        String rule = (String)rules.get(i);
        //general.errLog( "rule 1: "+rule, "JXC.log" );
        
        rule = StringSupport.substituteTags(rule, baseFields);
        //general.errLog( "rule 2: "+rule, "JXC.log" );

        rule = CmdEvaluator.evaluate(rule);
        //general.errLog( "rule 3: "+rule, "JXC.log" );

        if (rule.equals("Y"))
        {        	
          //general.errLog( "baseFields.size(): "+baseFields.size(), "JXC.log" );
          //general.errLog( "loanFields.size(): "+rule, "JXC.log" );

          Map transFields = new HashMap();

//transFields.putAll(baseFields);
transFields.putAll(loanFields);

		  generateCallSpecificFields(transaction, transFields);
          
          log.add("Assembling Optional Transaction: " + transaction);
          //general.errLog("Assembling Optional Transaction: " + transaction, "JXC.log" );
          //general.errLog("Assembling Optional TransFields: " + transFields, "JXC.log" );

          if (transaction.startsWith("LNPLED"))
          {
            log.add("START: " + transaction);
            // Assemble the Escrow Add transaction.
            //
            EscrwAdd escrowAdd = null;
            try
            {
              escrowAdd = assembleEscrowAdd(username, transFields);
            }
            catch (Exception e)
            {
              ExceptionLogger.logException(e);
              String errMsg = refID + ": Error assembling EscrwAdd: " + e;
              log.add(errMsg);
              errorMsg.append(errMsg);
              return false;              
            }
            
            // Do the Escrow Add transaction.
            //
            EscrwAddResponse escrowAddResp = null;
            try
            {
              escrowAddResp = loanSvc.escrwAdd(escrowAdd);
            }
            catch (MessageFault mf)
            {
              StringBuilder mfText = generateFaultMessage(mf);
              log.add("Unable to add escrow:");
              log.add(changeLineBreaks(mfText.toString()));
              errorMsg.append("One or more faults occurred while performing a EscrwAdd:\n\n");
              errorMsg.append(mfText);
              return false;
            }
       
            log.add("END: " + transaction);
          }
          else if (transaction.equals("LNPLMS"))
          {
            log.add("START: " + transaction);
        	  
            CustMsgAdd custMsg = null;
            
            try
            {
              custMsg = assembleCustomerMessageAdd(username, transFields);
            }
            catch (Exception e)
            {
              ExceptionLogger.logException(e);
              String errMsg = refID + ": Error assembling CustMsgAdd: " + e;
              log.add(errMsg);
              errorMsg.append(errMsg);
              return false;
            }

            // Do the customer message add transaction.
            //
            CustMsgAddResponse custMsgAddResp = null;
            try
            {
              custMsgAddResp = customerSvc.custMsgAdd(custMsg);
            }
            catch (MessageFault mf)
            {
              StringBuilder mfText = generateFaultMessage(mf);
              log.add("Unable to add customer message:");
              log.add(changeLineBreaks(mfText.toString()));
              errorMsg.append("One or more faults occurred while performing a CustMsgAdd:\n\n");
              errorMsg.append(mfText);
              return false;
            }
            
            log.add("END: " + transaction);            
          }
        }
      }
    }
        
    // Complete the account relationship transaction.
    //
    String accountID = (String)loanFields.get("ACCTNO");
    String accountType = (String)loanFields.get("ACTYPE");

    //general.errLog( "accountID: "+accountID, "JXC.log" );
    //general.errLog( "accountType: " + accountType, "JXC.log" );

    int i = 0;
    for (String coBorrowerCIF : coBorrowerCIFList)
    {
      log.add("Executing customer relationship for co-applicant CIF: " + coBorrowerCIF);
      
      String relType = relationshipList.get(i);
      ++i;
      
      CustRelAddResponse custRelAddResp =  null;
      try
      {
        custRelAddResp = doCustomerRelationshipAdd(username, customerSvc, accountID, accountType,
                                                   primaryApplicantCIF, coBorrowerCIF, relType);
      }
      catch (MessageFault mf)
      {
        ExceptionLogger.logException( mf );
        StringBuilder mfText = generateFaultMessage(mf);
        log.add("Unable to add Customer Relationship:");
        log.add(changeLineBreaks(mfText.toString()));
        errorMsg.append("One or more faults occurred while performing a customer relationship add:\n\n");
        errorMsg.append(mfText);
        return false;
      }
    }
    
    StringBuilder msg = new StringBuilder();
    msg.append("Completed Process Application. App ID: ").append(appID);    
    AdminGUIManager.displayE(msg.toString());

    //general.errLog( "msg: " + msg.toString(), "JXC.log" );
    //general.errLog( "END processConsumerApplication(...)", "JXC.log" );

    return true;
  }


  /**
   * assembleLoanAccountAdd
   * 
   * @param fields
   * @return LnAcctAdd
   * @throws DatatypeConfigurationException
   */
  private LnAcctAdd assembleLoanAccountAdd(String username, Map fields)
  throws DatatypeConfigurationException
  {
    //general.errLog( "START assembleLoanAccountAdd(String username, Map fields)", "JXC.log" );
    //general.errLog( "Map fields: "+fields, "JXC.log" );

    // Temporary Logging of fields
    //
    try
    {
      FileWriter fw = new FileWriter("data/jxcbooking/_LNPLAT.log");
      String f,v = null;
      Iterator it = fields.keySet().iterator();
      while (it.hasNext())
      {
        f = (String)it.next();
        v = (String)fields.get(f);
        fw.write(f + " = " + v + "\r\n");
      }
      fw.close();
    }
    catch (Exception e)
    {
      
    }

    // Message: LnAcctAdd
    //
    LnAcctAdd loanAccount = new LnAcctAdd();

    // Set the message request header.
    //
    MsgRqHdrCType msgRq = new MsgRqHdrCType();
    msgRq.setJXchangeHdr(generateJXChangeHeader(username));
    loanAccount.setMsgRqHdr(msgRq);
    
    // Declare the LnAcctAdd major sub-types.
    //
    LnAddCType lnAdd = new LnAddCType();
    LnInfoRecCType loanInfo = new LnInfoRecCType();
    LnAcctInfoCType loanAccountInfo = new LnAcctInfoCType();
    LnDlrInfoCType loanDealerInfo = new LnDlrInfoCType();
    LnBalDtInfoCType loanBalDtInfo = new LnBalDtInfoCType();
    LnRealEstateInfoCType loanREInfo = new LnRealEstateInfoCType();
    LnPmtInfoCType loanPmtInfo = new LnPmtInfoCType();
    LnRateInfoCType loanRateInfo = new LnRateInfoCType();
    LnRegRptInfoCType loanRegRptInfo = new LnRegRptInfoCType();
    LnMtgInfoCType loanMtgInfo = new LnMtgInfoCType();
    LnStopInfoCType loanStopInfo = new LnStopInfoCType();
        
//
// Do we need an OffInfoArray...???
//
  
    // Declare Array types.
    //
    AcctTitleAType accountTitleArray = new AcctTitleAType();
    BorwInfoArrayAType borrowerInfoArray = new BorwInfoArrayAType();
    HousingInfoArrayAType housingInfoArray = new HousingInfoArrayAType();
    FHLBSICInfoArrayAType fhlbsicInfoArray = new FHLBSICInfoArrayAType();
    LnStopInfoArrayAType loanStopInfoArray = new LnStopInfoArrayAType();
    LnFeeArrayAType loanFeeArray = new LnFeeArrayAType();
    UserDefInfoArrayAType userDefInfoArray = new UserDefInfoArrayAType();
    		
    AccountIdCType accountID = new AccountIdCType();
    TermCType loanTerm = new TermCType();
    CRARecCType craRec = new CRARecCType();

    // Declare borrower and coborrower types.
    //
    BorwInfoCType primaryBorrowerInfo = new BorwInfoCType();
    BorwInfoCType coBorrowerInfo = new BorwInfoCType();

    // Declare housing info 1 - 4.
    //
    HousingInfoCType housingInfo1 = new HousingInfoCType();
    HousingInfoCType housingInfo2 = new HousingInfoCType();
    HousingInfoCType housingInfo3 = new HousingInfoCType();
    HousingInfoCType housingInfo4 = new HousingInfoCType();
    
    // Declare FHLBSIC info 1 - 6.
    //
    FHLBSICInfoCType fhlbsicInfo1 = new FHLBSICInfoCType();
    FHLBSICInfoCType fhlbsicInfo2 = new FHLBSICInfoCType();
    FHLBSICInfoCType fhlbsicInfo3 = new FHLBSICInfoCType();
    FHLBSICInfoCType fhlbsicInfo4 = new FHLBSICInfoCType();
    FHLBSICInfoCType fhlbsicInfo5 = new FHLBSICInfoCType();
    FHLBSICInfoCType fhlbsicInfo6 = new FHLBSICInfoCType();
    
    // Declare Loan Stop Information
    //
    LnStopFuncInfoCType stopAdvancesInfo = new LnStopFuncInfoCType();
    LnStopFuncInfoCType stopPaymentInfo = new LnStopFuncInfoCType();
    LnStopFuncInfoCType stopTaxDisbInfo = new LnStopFuncInfoCType();
    LnStopFuncInfoCType stopHazDisbInfo = new LnStopFuncInfoCType();
    LnStopFuncInfoCType stopOptInsInfo = new LnStopFuncInfoCType();
    LnStopFuncInfoCType stopLoanSaleInfo = new LnStopFuncInfoCType();
    LnStopFuncInfoCType stopNoticesInfo = new LnStopFuncInfoCType();
    LnStopFuncInfoCType stopCreditRptInfo = new LnStopFuncInfoCType();
    LnStopFuncInfoCType stopPrepayInfo = new LnStopFuncInfoCType();
    LnStopFuncInfoCType stopAccrualInfo = new LnStopFuncInfoCType();
    LnStopFuncInfoCType stopCorrespInfo = new LnStopFuncInfoCType();
    LnStopFuncInfoCType stopIRSInfo = new LnStopFuncInfoCType();
    LnStopFuncInfoCType stopStateInfo = new LnStopFuncInfoCType();
    LnStopFuncInfoCType stopCouponInfo = new LnStopFuncInfoCType();
    LnStopFuncInfoCType stopEscrowInfo = new LnStopFuncInfoCType();
    LnStopFuncInfoCType stopEscrowAnalInfo = new LnStopFuncInfoCType();
    LnStopFuncInfoCType stopPastDueRptInfo = new LnStopFuncInfoCType();
    
    // Declare Loan Fee Information
    //
    LnFeeInfoRecCType loanFeeInfo = new LnFeeInfoRecCType();

    
    // Data Type Factory for XML Gregorian Calendar.
    //
    DatatypeFactory dataTypeFactory = DatatypeFactory.newInstance();

    
    /*
     * BEGIN FIELD MAPPING
     *
     */
    
    // Branch #
    //
    String field = (String)fields.get("BR#");
    if (field != null)
    {
      BrCodeType brCode = new BrCodeType();
      brCode.setValue(field);    
      loanInfo.setBrCode(brCode);
    }
    
    // Account Number
    //
    field = (String)fields.get("ACCTNO");
    //general.errLog( "ACCTNO: " + field, "JXC.log" );

    if (field != null)
    {
      AcctIdType acctIDType = new AcctIdType();
      acctIDType.setValue(field);
      
      accountID.setAcctId(acctIDType);
    }
    
    // Account Type
    //
    field = (String)fields.get("ACTYPE");
    //general.errLog( "ACTTYPE: " + field, "JXC.log" );
    if (field != null)
    {
      AcctTypeType acctTypeType = new AcctTypeType();
      acctTypeType.setValue(field);
      
      accountID.setAcctType(acctTypeType);
    }
    
    // ARGO Product Type
    // Not in jXchange
    //
    
    // CIF #
    //
    field = (String)fields.get("CIFNO");
    if (field != null)
    {
      CustIdType custID = new CustIdType();
      custID.setValue(field);
      
      loanInfo.setCustId(custID);
    }
    
    // Additional Name #1 (CFAAL1)
    //
    List<AcctTitleInfoCType> accountTitles = accountTitleArray.getAcctTitleInfos();
    loanInfo.setAcctTitleArray(accountTitleArray);
  
    field = (String)fields.get("ADDNAM");
    if (field != null)
    {
      AcctTitleType acctTitleType = new AcctTitleType();
      acctTitleType.setValue(field);
      
      AcctTitleInfoCType acctTitleInfo = new AcctTitleInfoCType();
      acctTitleInfo.setAcctTitle(acctTitleType);
      accountTitles.add(acctTitleInfo);
    }
    
    // Alternate Names (CFAAL2)
    //
    field = (String)fields.get("ALTNAM");
    if (field != null)
    {
      AcctTitleType acctTitleType = new AcctTitleType();
      acctTitleType.setValue(field);
      
      AcctTitleInfoCType acctTitleInfo = new AcctTitleInfoCType();
      acctTitleInfo.setAcctTitle(acctTitleType);
      accountTitles.add(acctTitleInfo);
    }
    
    // Officer
    //
    field = (String)fields.get("OFFCR");
    //general.errLog( "OFFCR: " + field, "JXC.log" );

    if (field != null)
    {
      OffCodeType officerCode = new OffCodeType();
      officerCode.setValue(field);
      
      loanInfo.setOffCode(officerCode);
    }
    
    // Status
    //
    field = (String)fields.get("STATUS");
    if (field != null)
    {
      AcctStatType status = new AcctStatType();
      status.setValue(field);
      
      loanInfo.setAcctStat(status);
    }
    
    // Class Code
    //
    field = (String)fields.get("CLASS");
    if (field != null)
    {
      AcctClsfCodeType classCode = new AcctClsfCodeType();
      classCode.setValue(field);
      
      loanAccountInfo.setAcctClsfCode(classCode);
    }
    
    // Loan Type
    //
    field = (String)fields.get("TYPE");
    //general.errLog( "TYPE: " + field, "JXC.log" );

    if (field != null)
    {
      ProdCodeType prodCode = new ProdCodeType();
      prodCode.setValue(field);
      
      loanInfo.setProdCode(prodCode);
    }
    
    // Original Amount
    //
    field = (String)fields.get("ORGAMT");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      OrigBalType origBal = new OrigBalType();
      origBal.setValue(bd);
      
      loanInfo.setOrigBal(origBal);
    }
    
    // Bank Discount
    //
    field = (String)fields.get("BKDISC");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      BankDiscType bankDisc = new BankDiscType();
      bankDisc.setValue(bd);
      
      loanDealerInfo.setBankDisc(bankDisc);
    }
    
    // Dealer Discount
    //
    field = (String)fields.get("DLRDSC");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      DlrDiscType dealerDisc = new DlrDiscType();
      dealerDisc.setValue(bd);
      
      loanDealerInfo.setDlrDisc(dealerDisc);
    }
    
    // Minimum Charge
    //
    field = (String)fields.get("MINCH");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      MinIntType minCharge = new MinIntType();
      minCharge.setValue(bd);
      
      loanBalDtInfo.setMinInt(minCharge);
    }
    
    // Payment Amount
    //
    field = (String)fields.get("PMTAMT");
    //general.errLog( "PMTAMT: " + field, "JXC.log" );

    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      PmtAmtType paymentAmt = new PmtAmtType();
      paymentAmt.setValue(bd);
      
      loanInfo.setPmtAmt(paymentAmt);
    }
    
    // P&I Amount
    //
    field = (String)fields.get("PIAMT");
    //general.errLog( "PIAMT: " + field, "JXC.log" );

    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      PIAmtType piAmt = new PIAmtType();
      piAmt.setValue(bd);
      
      loanInfo.setPIAmt(piAmt);
    }
    
    // Appraised Value
    //
    field = (String)fields.get("APRAMT");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      ApprValType appraisedVal = new ApprValType();
      appraisedVal.setValue(bd);
      
      loanREInfo.setApprVal(appraisedVal);
    }
    
    // Annual Income
    //
    field = (String)fields.get("ANINCM");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      AnnIncmAmtType annualIncome = new AnnIncmAmtType();
      annualIncome.setValue(bd);
      
      loanAccountInfo.setAnnIncmAmt(annualIncome);
    }
    
    // Balloon Payment
    //
    field = (String)fields.get("BALLON");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      BallPmtAmtType balloonPmt = new BallPmtAmtType();
      balloonPmt.setValue(bd);
      
      loanPmtInfo.setBallPmtAmt(balloonPmt);
    }
    
    // Points Paid
    //
    field = (String)fields.get("PNTPD");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      PtPaidType pointsPaid = new PtPaidType();
      pointsPaid.setValue(bd);
      
      loanAccountInfo.setPtPaid(pointsPaid);
    }
    
    // Last Advance
    // Not in jXchange
    //
    
    // Original Loan Date
    //
    field = (String)fields.get("ORGDT");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      OpenDtType loanDate = new OpenDtType();
      loanDate.setValue(xCal);
      
      loanInfo.setOpenDt(loanDate);
    }
    
    // Maturity Date
    //
    field = (String)fields.get("MATDT");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      MatDtType maturityDate = new MatDtType();
      maturityDate.setValue(xCal);
      
      loanInfo.setMatDt(maturityDate);
    }
    
    // Date Entered
    //
    field = (String)fields.get("DATOP");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      OpenDtType loanDate = new OpenDtType();
      loanDate.setValue(xCal);
      
      loanInfo.setOpenDt(loanDate);      
    }
    
    // Next Review Date
    //
    field = (String)fields.get("NREVDT");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      NxtRvwDtType nextReviewDate = new NxtRvwDtType();
      nextReviewDate.setValue(xCal);
      
      loanBalDtInfo.setNxtRvwDt(nextReviewDate);
    }
    
    // Collateral Ins Exp
    //
    field = (String)fields.get("COEXD6");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      CollatInsurExpDtType collExpDate = new CollatInsurExpDtType();
      collExpDate.setValue(xCal);
      
      loanBalDtInfo.setCollatInsurExpDt(collExpDate);
    }
    
    // UCC Expiration
    //
    field = (String)fields.get("UCEXD6");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      UCCExpDtType uccExpDate = new UCCExpDtType();
      uccExpDate.setValue(xCal);
      
      loanBalDtInfo.setUCCExpDt(uccExpDate);
    }
    
    // 1st Payment Date
    //
    field = (String)fields.get("FPDT");
    //general.errLog( "FPDT: " + field, "JXC.log" );
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      FirstPmtDtType firstPmtDate = new FirstPmtDtType();
      firstPmtDate.setValue(xCal);
      
      loanBalDtInfo.setFirstPmtDt(firstPmtDate);
    }
    
    // Payment Day Of Month
    //
    field = (String)fields.get("NPDAY");
    if (field != null)
    {
      PmtDayOfMonthType pmtDayOfMonth = new PmtDayOfMonthType();
      pmtDayOfMonth.setValue(Integer.parseInt(field));
      
      loanInfo.setPmtDayOfMonth(pmtDayOfMonth);
    }
    
    // Examiner Class Date
    //
    field = (String)fields.get("EXAMD6");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      ExmnrClsfDtType examinerClassDate = new ExmnrClsfDtType();
      examinerClassDate.setValue(xCal);
      
      loanBalDtInfo.setExmnrClsfDt(examinerClassDate);
    }
    
    // Coupon Reorder Date
    //
    field = (String)fields.get("CPNDT");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      CouponReOrderDtType couponReorderDate = new CouponReOrderDtType();
      couponReorderDate.setValue(xCal);
      
      loanBalDtInfo.setCouponReOrderDt(couponReorderDate);
    }
    
    // Prime Review Day
    // JXChange Docs: NO ELEMENT - API HANDLES THIS VALUE
    //
    
    // Last Appraisal Date
    //
    field = (String)fields.get("APPDT7");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      ApprDtType apprDate = new ApprDtType();
      apprDate.setValue(xCal);
      
      loanREInfo.setApprDt(apprDate);
    }
    
    // Amortize Thru Date
    //
    field = (String)fields.get("AMRDT6");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      ReAmrtzThruDtType amortThruDate = new ReAmrtzThruDtType();
      amortThruDate.setValue(xCal);
      
      loanBalDtInfo.setReAmrtzThruDt(amortThruDate);
    }
    
    // Rate Cap Review Date
    //
    field = (String)fields.get("ESCRDT");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      RateCapRevDtType rateCapReviewDate = new RateCapRevDtType();
      rateCapReviewDate.setValue(xCal);
      
      loanRateInfo.setRateCapRevDt(rateCapReviewDate);
    }
    
    // Convertible Expiration Date
    //
    field = (String)fields.get("CVEXP6");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      ConvARMExpDtType convArmExpDate = new ConvARMExpDtType();
      convArmExpDate.setValue(xCal);
      
      loanRateInfo.setConvARMExpDt(convArmExpDate);
    }
    
    // Loan Conversion Date
    //
    field = (String)fields.get("HECNV7");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      LnConvDtType loanConvDate = new LnConvDtType();
      loanConvDate.setValue(xCal);
      
      loanBalDtInfo.setLnConvDt(loanConvDate);
    }
    
    // Step Rate End Date
    //
    field = (String)fields.get("STEPRD6");
    if (field != null)
    {
      // According to the JXChange Document, this value is set in the ConvArmExpDate.  Does not
      // seem correct.
      /*
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      ConvARMExpDtType convArmExpDate = new ConvARMExpDtType();
      convArmExpDate.setValue(xCal);
      
      loanRateInfo.setConvARMExpDt(convArmExpDate);      
      */
    }
    
    // Note Rate
    //
    field = (String)fields.get("RATE");
    //general.errLog( "RATE: " + field, "JXC.log" );

    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      IntRateType rate = new IntRateType();

      //bd = new BigDecimal( ".0509" );
      //general.errLog( "RATE: BigDecimal: bd: " + bd, "JXC.log" );

      rate.setValue(bd);
      
      loanInfo.setIntRate(rate);
    }
    
    // Dealer Rate
    //
    field = (String)fields.get("DLRATE");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      DlrRateType dealerRate = new DlrRateType();
      dealerRate.setValue(bd);
      
      loanDealerInfo.setDlrRate(dealerRate);
    }

    // Maturity Rate
    //
    field = (String)fields.get("MATRAT");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      MatRateType maturityRate = new MatRateType();
      maturityRate.setValue(bd);
      
      loanRateInfo.setMatRate(maturityRate);
    }

    // Prime Rate #
    //
    field = (String)fields.get("PRATE#");
    if (field != null)
    {
      RateIdxNumType primeRate = new RateIdxNumType();
      primeRate.setValue(Integer.parseInt(field));
      
      loanRateInfo.setRateIdxNum(primeRate);
    }

    // Prime Variance
    //
    field = (String)fields.get("PVARI");
    //general.errLog( "PVARI: " + field, "JXC.log" );
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      
      //bd = new BigDecimal( "5.9" );
      //bd = new BigDecimal( ".0509" );

      RateVarType primeVariance = new RateVarType();

      //general.errLog( "2 PVARI: " + field, "JXC.log" );
      primeVariance.setValue(bd);
      
      loanRateInfo.setRateVar(primeVariance);
    }

    // Prime Variance Code
    //
    field = (String)fields.get("PVCODE");
    //general.errLog( "PVCODE: " + field, "JXC.log" );

    if (field != null)
    {
      RateVarCodeType primeVarianceCode = new RateVarCodeType();
      primeVarianceCode.setValue(field);
      
      loanRateInfo.setRateVarCode(primeVarianceCode);
    }

    // Prime Rate Floor
    //
    field = (String)fields.get("PFLOOR");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      RateFlrType primeRateFloor = new RateFlrType();
      primeRateFloor.setValue(bd);
      
      loanRateInfo.setRateFlr(primeRateFloor);
    }
    
    // Prime Rate Ceiling
    //
    field = (String)fields.get("PCEIL");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      RateCeilType primeRateCeil = new RateCeilType();
      primeRateCeil.setValue(bd);
      
      loanRateInfo.setRateCeil(primeRateCeil);
    }
    
    // Prime Review Term
    //
    field = (String)fields.get("PRTERM");
    if (field != null)
    {
      RateRevTermType primeReviewTerm = new RateRevTermType();
      primeReviewTerm.setValue(Integer.parseInt(field));
      
      loanRateInfo.setRateRevTerm(primeReviewTerm);
    }
    
    // Prime Review Code
    //
    field = (String)fields.get("PRCODE");
    //general.errLog( "PRCODE: " + field, "JXC.log" );

    if (field != null)
    {
      RateRevTermUnitsType primeReviewTermCode = new RateRevTermUnitsType();
      primeReviewTermCode.setValue(field);
      
      loanRateInfo.setRateRevTermUnits(primeReviewTermCode);
    }
    
    // Rate Cap Upwards
    //
    field = (String)fields.get("ECAPUP");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      RateCapUpType rateCapUp = new RateCapUpType();
      rateCapUp.setValue(bd);
      
      loanRateInfo.setRateCapUp(rateCapUp);
    }
    
    // Rate Cap Downwards
    //
    field = (String)fields.get("ECAPDN");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      RateCapDownType rateCapDown = new RateCapDownType();
      rateCapDown.setValue(bd);
      
      loanRateInfo.setRateCapDown(rateCapDown);
    }

    // Rate Cap Period
    //
    field = (String)fields.get("ECRTRM");
    if (field != null)
    {
      RateCapRevTermType rateCapRevTerm = new RateCapRevTermType();
      rateCapRevTerm.setValue(Integer.parseInt(field));
      
      loanRateInfo.setRateCapRevTerm(rateCapRevTerm);
    }
    
    // Rate Cap Period Code
    //
    field = (String)fields.get("ECRTCD");
    if (field != null)
    {
      RateCapRevTermUnitsType rateCapRevTermUnits = new RateCapRevTermUnitsType();
      rateCapRevTermUnits.setValue(field);
      
      loanRateInfo.setRateCapRevTermUnits(rateCapRevTermUnits);
    }
    
    // Use Rate Carryover
    //
    field = (String)fields.get("ECRYOU");
    if (field != null)
    {
      UseRateCarryOvrsType useRateCarryover = new UseRateCarryOvrsType();
      useRateCarryover.setValue(field);
      
      loanRateInfo.setUseRateCarryOvrs(useRateCarryover);
    }
    
    // Rounding Method
    //
    field = (String)fields.get("ERMETH");
    if (field != null)
    {
      RateRoundMthdType roundMethod = new RateRoundMthdType();
      roundMethod.setValue(field);
      
      loanRateInfo.setRateRoundMthd(roundMethod);
    }
    
    // Round To Amount
    //
    field = (String)fields.get("ERAMT");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      RateRoundToPctType roundTo = new RateRoundToPctType();
      roundTo.setValue(bd);
      
      loanRateInfo.setRateRoundToPct(roundTo);
    }
    
    // Original Index
    //
    field = (String)fields.get("ORIGIDX");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      OrigIdxValType origIndex = new OrigIdxValType();
      origIndex.setValue(bd);

      loanRateInfo.setOrigIdxVal(origIndex);
    }
    
    // Convertible ARM
    //
    field = (String)fields.get("CVRTAB");
    if (field != null)
    {
      ConvARMCodeType convARMCode = new ConvARMCodeType();
      convARMCode.setValue(field);
      
      loanRateInfo.setConvARMCode(convARMCode);
    }
    
    // Convertible Index #
    //
    field = (String)fields.get("CINDX#");
    if (field != null)
    {
      ConvIdxNumType convIndexNum = new ConvIdxNumType();
      convIndexNum.setValue(Integer.parseInt(field));
      
      loanRateInfo.setConvIdxNum(convIndexNum);
    }
    
    // Convertible Variance
    //
    field = (String)fields.get("CVVARI");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      ConvVarType convVariance = new ConvVarType();
      convVariance.setValue(bd);
      
      loanRateInfo.setConvVar(convVariance);
    }
    
    // Convertible Variance Code
    //
    field = (String)fields.get("CVVARC");
    if (field != null)
    {
      ConvVarCodeType convVarianceCode = new ConvVarCodeType();
      convVarianceCode.setValue(field);
      
      loanRateInfo.setConvVarCode(convVarianceCode);
    }
    
    // Loan Term
    //
    field = (String)fields.get("TERM");
    //general.errLog( "TERM: " + field, "JXC.log" );

    if (field != null)
    {
      TermCntType term = new TermCntType();
      term.setValue(Integer.parseInt(field));
      
      loanTerm.setTermCnt(term);
    }
    
    // Loan Term Code
    //
    field = (String)fields.get("TMCODE");
    //general.errLog( "TMCODE: " + field, "JXC.log" );
    if (field != null)
    {
      TermUnitsType termUnits = new TermUnitsType();
      termUnits.setValue(field);
      
      loanTerm.setTermUnits(termUnits);
    }
    
    // Payment Frequency
    //
    field = (String)fields.get("FREQ");
    //general.errLog( "FREQ: " + field, "JXC.log" );
    if (field != null)
    {
      PmtTermType pmtTerm = new PmtTermType();
      pmtTerm.setValue(Integer.parseInt(field));
      
      loanInfo.setPmtTerm(pmtTerm);
    }
    
    // Frequency Code
    //
    field = (String)fields.get("FRCODE");
    //general.errLog( "FRCODE: " + field, "JXC.log" );
    if (field != null)
    {
      PmtTermUnitsType pmtTermUnits = new PmtTermUnitsType();
      pmtTermUnits.setValue(field);
      
      loanInfo.setPmtTermUnits(pmtTermUnits);
    }
    
    // Payment Code
    //
    field = (String)fields.get("PMTCOD");
    if (field != null)
    {
      PmtCodeType paymentCode = new PmtCodeType();
      paymentCode.setValue(field);
      
      loanInfo.setPmtCode(paymentCode);
    }
    
    // Reamort Payment Amount
    //
    field = (String)fields.get("REAMOR");
    //general.errLog( "REAMOR: " + field, "JXC.log" );
    if (field != null)
    {
      ReAmrtzPmtType reamortPmtAmt = new ReAmrtzPmtType();
      reamortPmtAmt.setValue(field);
      
      loanPmtInfo.setReAmrtzPmt(reamortPmtAmt);
    }
    
    // Department Code
    //
    field = (String)fields.get("DEPTCD");
    if (field != null)
    {
      DeptCodeType deptCode = new DeptCodeType();
      deptCode.setValue(field);
      
      loanAccountInfo.setDeptCode(deptCode);
    }
    
    // GL Cost Center
    //
    field = (String)fields.get("GLCOST");
    if (field != null)
    {
      GLCostCtrType glCost = new GLCostCtrType();
      glCost.setValue(field);
      
      loanRegRptInfo.setGLCostCtr(glCost);
    }
    
    // GL Product Code
    //
    field = (String)fields.get("GLPROD");
    if (field != null)
    {
      GLProdCodeType glProductCode = new GLProdCodeType();
      glProductCode.setValue(field);
      
      loanRegRptInfo.setGLProdCode(glProductCode);
    }
    
    // Call Report Code
    //
    field = (String)fields.get("CALREP");
    //general.errLog( "CALREP: " + field, "JXC.log" );

    if (field != null)
    {
      CallRptCodeType callReportCode = new CallRptCodeType();
      callReportCode.setValue(field);
      
      loanRegRptInfo.setCallRptCode(callReportCode);
    }
    
    // Collateral Code
    //
    field = (String)fields.get("COLCOD");
    if (field != null)
    {
      CollatCodeType collateralCode = new CollatCodeType();
      collateralCode.setValue(field);
      
      loanAccountInfo.setCollatCode(collateralCode);
    }
    
    // Purpose Code
    //
    field = (String)fields.get("PURCOD");
    if (field != null)
    {
      PurpCodeType purposeCode = new PurpCodeType();
      purposeCode.setValue(field);
      
      loanAccountInfo.setPurpCode(purposeCode);
    }
    
    // Dealer #
    //
    field = (String)fields.get("DLRNO");
    if (field != null)
    {
      DlrIdType dealerNum = new DlrIdType();
      dealerNum.setValue(field);
      
      loanDealerInfo.setDlrId(dealerNum);
    }
    
    // Hold Mail
    //
    field = (String)fields.get("HMAIL");
    if (field != null)
    {
      HldMailCodeType holdMail = new HldMailCodeType();
      holdMail.setValue(field);
      
      loanAccountInfo.setHldMailCode(holdMail);
    }
    
    // Include on Stmt Code
    //
    field = (String)fields.get("INCLUD");
    if (field != null)
    {
      IncCombStmtType incStmtCode = new IncCombStmtType();
      incStmtCode.setValue(field);
      
      loanAccountInfo.setIncCombStmt(incStmtCode);
    }
    
    // Demand/Student Code
    //
    field = (String)fields.get("DEMSTU");
    if (field != null)
    {
      StudentLnCodeType studentCode = new StudentLnCodeType();
      studentCode.setValue(field);
      
      loanAccountInfo.setStudentLnCode(studentCode);
    }
    
    // Standard Industry
    //
    field = (String)fields.get("INDCOD");
    if (field != null)
    {
      StdIndustCodeType indCode = new StdIndustCodeType();
      indCode.setValue(field);
      
      loanRegRptInfo.setStdIndustCode(indCode);
    }
    
    // Escrow Posting Seq
    //
    field = (String)fields.get("ESCPSQ");
    //general.errLog( "ESCPSQ: " + field, "JXC.log" );

    if (field != null)
    {
      PostSeq5CodeType p5c = new PostSeq5CodeType();
      p5c.setValue(field);
      
      loanPmtInfo.setPostSeq5Code(p5c);
    }
    
    // Interest Posting Seq
    //
    field = (String)fields.get("INTPSQ");
    //general.errLog( "INTPSQ: " + field, "JXC.log" );
    if (field != null)
    {
      PostSeq4CodeType p4c = new PostSeq4CodeType();
      p4c.setValue(field);
      
      loanPmtInfo.setPostSeq4Code(p4c);
    }
    
    // Late Charge Post Seq
    //
    field = (String)fields.get("LTCPSQ");
    //general.errLog( "LTCPSQ: " + field, "JXC.log" );

    if (field != null)
    {
      PostSeq3CodeType p3c = new PostSeq3CodeType();
      p3c.setValue(field);
      
      loanPmtInfo.setPostSeq3Code(p3c);
    }
    
    // Other Charges Post Seq
    //
    field = (String)fields.get("OTHPSQ");
    //general.errLog( "OTHPSQ: " + field, "JXC.log" );
    if (field != null)
    {
      PostSeq2CodeType p2c = new PostSeq2CodeType();
      p2c.setValue(field);
      
      loanPmtInfo.setPostSeq2Code(p2c);
    }
    
    // Principal Post Seq
    //
    field = (String)fields.get("PRNPSQ");
    //general.errLog( "PRNPSQ: " + field, "JXC.log" );

    if (field != null)
    {
      PostSeq1CodeType p1c = new PostSeq1CodeType();
      p1c.setValue(field);
      
      loanPmtInfo.setPostSeq1Code(p1c);
    }
    
    // Use Billed Amounts?
    //
    field = (String)fields.get("USEBIL");
    if (field != null)
    {
      SplitPmtAsBilType useBill = new SplitPmtAsBilType();
      useBill.setValue(field);
      
      loanPmtInfo.setSplitPmtAsBil(useBill);
    }
    
    // Print Billing Notice?
    //
    field = (String)fields.get("SENDCD");
    //general.errLog( "SENDCD: " + field, "JXC.log" );

    if (field != null)
    {
      PrtBilNotCodeType printBill = new PrtBilNotCodeType();
      printBill.setValue(field);
      
      loanAccountInfo.setPrtBilNotCode(printBill);
    }
    
    // Title Still Needed?
    //
    field = (String)fields.get("TITLE");
    if (field != null)
    {
      TitleNeededType titleNeeded = new TitleNeededType();
      titleNeeded.setValue(field);
      
      loanAccountInfo.setTitleNeeded(titleNeeded);
    }
    
    // Send Past Due Notice
    //
    field = (String)fields.get("SENDPD");
    if (field != null)
    {
      PrtPastDueNotCodeType pastDue = new PrtPastDueNotCodeType();
      pastDue.setValue(field);
      
      loanAccountInfo.setPrtPastDueNotCode(pastDue);
    }
    
    // Late Charge Type
    //
    field = (String)fields.get("LCTYPE");
    //general.errLog( "LCTYPE: " + field, "JXC.log" );
    if (field != null)
    {
      LateChgCodeType lateChargeCode = new LateChgCodeType();
      lateChargeCode.setValue(field);
      
      loanAccountInfo.setLateChgCode(lateChargeCode);
    }
    
    // Ignore L/C Posting
    //
    field = (String)fields.get("IGNLCP");
    //general.errLog( "IGNLCP: "+field, "JXC.log" );
    if (field != null)
    {
      IgnrLateChgMultiType ignoreLCP = new IgnrLateChgMultiType();
      ignoreLCP.setValue(field);
      
      loanPmtInfo.setIgnrLateChgMulti(ignoreLCP);
    }
    
    // Classification Type
    //
    field = (String)fields.get("TYPECLS");
    if (field != null)
    {
      ExmnrClsfCodeType classType = new ExmnrClsfCodeType();
      classType.setValue(field);
      
      loanAccountInfo.setExmnrClsfCode(classType);
    }
    
    // Credit Rating Code
    //
    field = (String)fields.get("RATCOD");
    if (field != null)
    {
      CrRatingCodeType creditRatingCode = new CrRatingCodeType();
      creditRatingCode.setValue(field);
      
      loanAccountInfo.setCrRatingCode(creditRatingCode);
    }
    
    // Census Tract
    //
    field = (String)fields.get("CENSUS");
    //general.errLog( "CENSUS: " + field, "JXC.log" );
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      CRACenTractType census = new CRACenTractType();
      census.setValue(bd);
      
      craRec.setCRACenTract(census);
    }
    
    // SMSA Number
    //
    field = (String)fields.get("SMSA");
    //general.errLog( "SMSA: " + field, "JXC.log" );
    if (field != null)
    {
      CRASMSACodeType smsa = new CRASMSACodeType();
      smsa.setValue(field);
      
      craRec.setCRASMSACode(smsa);
    }
    
    // CRA Location
    //
    field = (String)fields.get("CRALOC");
    //general.errLog( "CRALOC: " + field, "JXC.log" );
    if (field != null)
    {
      CRALocType craLocation = new CRALocType();
      craLocation.setValue(field);
      
      craRec.setCRALoc(craLocation);
    }
    
    // State Code
    //
    field = (String)fields.get("STATE");
    //general.errLog( "STATE: " + field, "JXC.log" );
    if (field != null)
    {
      StateType state = new StateType();
      state.setValue(field);
      
      loanAccountInfo.setState(state);
    }
    
    // CRA State Code
    //
    field = (String)fields.get("CRASTA");
    //general.errLog( "CRASTA: " + field, "JXC.log" );
    if (field != null)
    {
      CRAStateCodeType craStateCode = new CRAStateCodeType();
      craStateCode.setValue(field);
      
      craRec.setCRAStateCode(craStateCode);
    }
    
    // County Code
    //
    field = (String)fields.get("COUNTY");
    //general.errLog( "COUNTY: " + field, "JXC.log" );

    if (field != null)
    {
      CRACountyCodeType countyCode = new CRACountyCodeType();
      countyCode.setValue(field);
      
      craRec.setCRACountyCode(countyCode);
    }
    
    // VIN #
    //
    field = (String)fields.get("VIN#");
    if (field != null)
    {
      VehicleIdType vin = new VehicleIdType();
      vin.setValue(field);
      
      loanAccountInfo.setVehicleId(vin);
    }
    
    // Close on Zero
    //
    field = (String)fields.get("CLSZRO");
    if (field != null)
    {
      ClsOnZeroBalType closeOnZero = new ClsOnZeroBalType();
      closeOnZero.setValue(field);
      
      loanAccountInfo.setClsOnZeroBal(closeOnZero);
    }
    
    // Print Coupon Book
    //
    field = (String)fields.get("COUPON");
    if (field != null)
    {
      PrtCouponBookType printBook = new PrtCouponBookType();
      printBook.setValue(field);
      
      loanAccountInfo.setPrtCouponBook(printBook);
    }
    
    // Coupon Book Term
    //
    field = (String)fields.get("CPNTRM");
    if (field != null)
    {
      CouponBookTermType couponBookTerm = new CouponBookTermType();
      couponBookTerm.setValue(Integer.parseInt(field));
      
      loanAccountInfo.setCouponBookTerm(couponBookTerm);
    }
    
    // Participation Percent
    //
    field = (String)fields.get("PRTPCT");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      OrigPartPctType partPercent = new OrigPartPctType();
      partPercent.setValue(bd);
      
      loanAccountInfo.setOrigPartPct(partPercent);
    }
    
    // Partial Charge Off Account #
    //
    field = (String)fields.get("PCACC#");
    if (field != null)
    {
      PrtcpAcctIdType pcoffAcct = new PrtcpAcctIdType();
      pcoffAcct.setValue(field);
      
      loanAccountInfo.setPrtcpAcctId(pcoffAcct);
    }
    
    // Partial Charge Off Type
    //
    field = (String)fields.get("PCACTP");
    if (field != null)
    {
      PrtcpAcctTypeType pcoffAcctType = new PrtcpAcctTypeType();
      pcoffAcctType.setValue(field);
      
      loanAccountInfo.setPrtcpAcctType(pcoffAcctType);
    }
    
    // Hold Account #
    //
    field = (String)fields.get("HDACC#");
    if (field != null)
    {
      HldAcctIdType holdAcctNum = new HldAcctIdType();
      holdAcctNum.setValue(field);
      
      loanAccountInfo.setHldAcctId(holdAcctNum);
    }
    
    // Hold Account Type
    //
    field = (String)fields.get("HDACTP");
    if (field != null)
    {
      HldAcctTypeType holdAcctType = new HldAcctTypeType();
      holdAcctType.setValue(field);
      
      loanAccountInfo.setHldAcctType(holdAcctType);
    }
    
    // Requires 1098?
    //
    field = (String)fields.get("RQ1098");
    if (field != null)
    {
      Req1098Type req1098 = new Req1098Type();
      req1098.setValue(field);
      
      loanRegRptInfo.setReq1098(req1098);
    }
    
    // Maturity Grace Days
    //
    field = (String)fields.get("MATGRC");
    if (field != null)
    {
      MatGraceDaysType matGraceDays = new MatGraceDaysType();
      matGraceDays.setValue(Integer.parseInt(field));
      
      loanRateInfo.setMatGraceDays(matGraceDays);
    }
    
    // Watch List Code
    //
    field = (String)fields.get("WCHCOD");
    if (field != null)
    {
      WatchListCodeType watchListCode = new WatchListCodeType();
      watchListCode.setValue(field);
      
      loanAccountInfo.setWatchListCode(watchListCode);
    }
    
    // Prepayment Penalty Code
    //
    field = (String)fields.get("PPPCOD");
    if (field != null)
    {
      PrePmtPenCodeType pppCode = new PrePmtPenCodeType();
      pppCode.setValue(field);
      
      loanAccountInfo.setPrePmtPenCode(pppCode);
    }
    
    // Flood Insurance Required?
    //
    field = (String)fields.get("FLINRQ");
    if (field != null)
    {
      FloodInsurCodeType floodInsReq = new FloodInsurCodeType();
      floodInsReq.setValue(field);
      
      loanREInfo.setFloodInsurCode(floodInsReq);
    }
    
    // Borrower Paid Directly
    //
    field = (String)fields.get("BRWPD");
    if (field != null)
    {
      PtPaidByOwnerType paidByOwner = new PtPaidByOwnerType();
      paidByOwner.setValue(field);
      
      loanBalDtInfo.setPtPaidByOwner(paidByOwner);
    }
    
    // Restructured Debt
    //
    field = (String)fields.get("RSTRUC");
    if (field != null)
    {
      RestructuredDrType restructuredDebt = new RestructuredDrType();
      restructuredDebt.setValue(field);
      
      loanAccountInfo.setRestructuredDr(restructuredDebt);
    }
    
    // Annual Interest Income
    //
    field = (String)fields.get("LNANIC");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      AnnIncmAmtType annualIntIncome = new AnnIncmAmtType();
      annualIntIncome.setValue(bd);
      
      loanAccountInfo.setAnnIncmAmt(annualIntIncome);
    }
    
    // Loan To Value Ratio
    //
    field = (String)fields.get("LTVRAT");
    //general.errLog( "LTVRAT: " + field, "JXC.log" );

    if (field != null)
    {
      field = formatLTVRatio(field);
      //general.errLog( "FORMATED LTVRAT: " + field, "JXC.log" );
      
      BigDecimal bd = new BigDecimal(field);
      //general.errLog( "LTVRAT: BigDecimal bd = " + bd, "JXC.log" );

      OrigLnToValRatioType ltv = new OrigLnToValRatioType();      
      ltv.setValue(bd);
      
      loanAccountInfo.setOrigLnToValRatio(ltv);
    }
    
    // Senior Lien Outsourced
    //
    field = (String)fields.get("SLOUTS");
    if (field != null)
    {
      RegSeniorLienCodeType senLien = new RegSeniorLienCodeType();
      senLien.setValue(field);
      
      loanRegRptInfo.setRegSeniorLienCode(senLien);
    }
    
    // New Money
    //
    field = (String)fields.get("NEWMNY");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      NewLnFundAmtType newMoney = new NewLnFundAmtType();
      newMoney.setValue(bd);
      
      loanBalDtInfo.setNewLnFundAmt(newMoney);
    }
    
    // Down Payment
    //
    field = (String)fields.get("DWNPMT");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      DownPmtAmtType downPmt = new DownPmtAmtType();
      downPmt.setValue(bd);
      
      LnClsInfoCType loanClsInfo = new LnClsInfoCType();
      loanClsInfo.setDownPmtAmt(downPmt);
      
      LnClsInfoArrayAType downPayments = new LnClsInfoArrayAType();
      List<LnClsInfoCType> list = downPayments.getLnClsInfos();
      list.add(loanClsInfo);
      
      loanAccountInfo.setLnClsInfoArray(downPayments);
    }
    
    // Unposted Advances Over Credit Limit
    //
    field = (String)fields.get("UNPADV");
    if (field != null)
    {
      RstrAdvaOvrLmtType advOverLimit = new RstrAdvaOvrLmtType();
      advOverLimit.setValue(field);
      
      loanAccountInfo.setRstrAdvaOvrLmt(advOverLimit);
    }
    
    // CRA Military Code
    //
    field = (String)fields.get("CRAMIL");
    //general.errLog( "CRAMIL: " + field, "JXC.log" );
    if (field != null)
    {
      MltryAppType militaryCode = new MltryAppType();
      militaryCode.setValue(field);
      
      loanRegRptInfo.setMltryApp(militaryCode);
    }
    
    // Restrict Auto Advances
    //
    field = (String)fields.get("RSTADV");
    //general.errLog( "RSTADV: "+field, "JXC.log" );
    
    if (field != null)
    {
      RstrAdvaType restrictAdvType = new RstrAdvaType();
      restrictAdvType.setValue(field);
      
      loanAccountInfo.setRstrAdva(restrictAdvType);
    }
    
    // Restrict Auto Payments
    //
    field = (String)fields.get("RSTPMT");
    if (field != null)
    {
      RstrAutoPmtType restrictAutoPmt = new RstrAutoPmtType();
      restrictAutoPmt.setValue(field);
      
      loanPmtInfo.setRstrAutoPmt(restrictAutoPmt);
    }
    
    // Minimum Check Advance
    //
    field = (String)fields.get("LNMCHK");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      MinChkAdvaType minCheckAdv = new MinChkAdvaType();
      minCheckAdv.setValue(bd);
      
      loanPmtInfo.setMinChkAdva(minCheckAdv);
    }
    
    // Mortgage Insurance Cert #
    //
    field = (String)fields.get("MICERT");
    if (field != null)
    {
      MtgInsurCertifIdType miCert = new MtgInsurCertifIdType();
      miCert.setValue(field);
      
      loanMtgInfo.setMtgInsurCertifId(miCert);
    }
    
    // Mortgage Insurance Percent
    //
    field = (String)fields.get("MIPCT");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      MtgInsurPctType miPct = new MtgInsurPctType();
      miPct.setValue(bd);
      
      loanMtgInfo.setMtgInsurPct(miPct);
    }
    
    // Property Street
    //
    field = (String)fields.get("PROPSR");
    if (field != null)
    {
      PropStreetType propStreet = new PropStreetType();
      propStreet.setValue(field);
      
      loanREInfo.setPropStreet(propStreet);
    }
    
    // Property City
    //
    field = (String)fields.get("PROPCT");
    if (field != null)
    {
      PropCityType propCity = new PropCityType();
      propCity.setValue(field);
      
      loanREInfo.setPropCity(propCity);
    }
    
    // Property State
    //
    field = (String)fields.get("PROPST");
    if (field != null)
    {
      PropStateType propState = new PropStateType();
      propState.setValue(field);
      
      loanREInfo.setPropState(propState);
    }
    
    // Property Zip
    //
    field = (String)fields.get("PROPZP");
    if (field != null)
    {
      PropPostalCodeType propPostalCode = new PropPostalCodeType();
      propPostalCode.setValue(Integer.parseInt(field));
      
      loanREInfo.setPropPostalCode(propPostalCode);
    }
    
    // Amount Of Proceeds
    //
    field = (String)fields.get("PROC");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      ProceedAmtType proceeds = new ProceedAmtType();
      proceeds.setValue(bd);
      
      loanBalDtInfo.setProceedAmt(proceeds);
    }
    
    // Number of Borrowers
    //
    field = (String)fields.get("NUMBOR");
    if (field != null)
    {
      NumBorwType numBorrowers = new NumBorwType();
      numBorrowers.setValue(Integer.parseInt(field));
      
      loanAccountInfo.setNumBorw(numBorrowers);
    }
    
    // Borrower Gender
    //
    List<BorwInfoCType> borrowerInfoList = borrowerInfoArray.getBorwInfos();
    borrowerInfoList.add(primaryBorrowerInfo);
    borrowerInfoList.add(coBorrowerInfo);
    loanAccountInfo.setBorwInfoArray(borrowerInfoArray);
    
    field = (String)fields.get("BORSEX");
    if (field != null)
    {
      BorwGenderType gender = new BorwGenderType();
      gender.setValue(field);
      
      primaryBorrowerInfo.setBorwGender(gender);
    }
        
    // Co-Borrower Gender
    //
    field = (String)fields.get("COBSEX");
    if (field != null)
    {
      BorwGenderType gender = new BorwGenderType();
      gender.setValue(field);
  
      coBorrowerInfo.setBorwGender(gender);      
    }
    
    // Borrower Race
    //
    field = (String)fields.get("BORRAC");
    if (field != null)
    {
      BorwRaceCodeType race = new BorwRaceCodeType();
      race.setValue(field);
      
      primaryBorrowerInfo.setBorwRaceCode(race);
    }
    
    // Co-Borrower Race
    //
    field = (String)fields.get("COBRAC");
    if (field != null)
    {
      BorwRaceCodeType race = new BorwRaceCodeType();
      race.setValue(field);
      
      coBorrowerInfo.setBorwRaceCode(race);      
    }
    
    // Borrower Age
    //
    field = (String)fields.get("BORAGE");
    if (field != null)
    {
      BorwAgeType age = new BorwAgeType();
      age.setValue(Integer.parseInt(field));
      
      primaryBorrowerInfo.setBorwAge(age);
    }
    
    // Co-Borrower Age
    //
    field = (String)fields.get("COBAGE");
    if (field != null)
    {
      BorwAgeType age = new BorwAgeType();
      age.setValue(Integer.parseInt(field));
      
      coBorrowerInfo.setBorwAge(age);
    }
    
    // First Time Buyer
    //
    field = (String)fields.get("FRSTTM");
    if (field != null)
    {
      FirstHomePurType firstHomePur = new FirstHomePurType();
      firstHomePur.setValue(field);
      
      loanMtgInfo.setFirstHomePur(firstHomePur);
    }
    
    // Year Built
    //
    field = (String)fields.get("YRBULT");
    if (field != null)
    {
      YrBuiltType yearBuilt = new YrBuiltType();
      yearBuilt.setValue(Integer.parseInt(field));
      
      loanREInfo.setYrBuilt(yearBuilt);
    }
    
    // # of Bedrooms Unit 1
    //
    List<HousingInfoCType> housingInfoList = housingInfoArray.getHousingInfos();
    housingInfoList.add(housingInfo1);
    housingInfoList.add(housingInfo2);
    housingInfoList.add(housingInfo3);
    housingInfoList.add(housingInfo4);
    loanMtgInfo.setHousingInfoArray(housingInfoArray);

    field = (String)fields.get("BEDRM1");
    if (field != null)
    {
      NumBdrmType bedrooms = new NumBdrmType();
      bedrooms.setValue(Integer.parseInt(field));
      
      housingInfo1.setNumBdrm(bedrooms);
    }
    
    // # of Bedrooms Unit 2
    //
    field = (String)fields.get("BEDRM2");
    if (field != null)
    {
      NumBdrmType bedrooms = new NumBdrmType();
      bedrooms.setValue(Integer.parseInt(field));
      
      housingInfo2.setNumBdrm(bedrooms);
    }

    // # of Bedrooms Unit 3
    //
    field = (String)fields.get("BEDRM3");
    if (field != null)
    {
      NumBdrmType bedrooms = new NumBdrmType();
      bedrooms.setValue(Integer.parseInt(field));
      
      housingInfo3.setNumBdrm(bedrooms);
    }

    // # of Bedrooms Unit 4
    //
    field = (String)fields.get("BEDRM4");
    if (field != null)
    {
      NumBdrmType bedrooms = new NumBdrmType();
      bedrooms.setValue(Integer.parseInt(field));
      
      housingInfo4.setNumBdrm(bedrooms);
    }
    
    // Purchase Price
    //
    field = (String)fields.get("PURCHP");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      PropPurchaseAmtType purchaseAmt = new PropPurchaseAmtType();
      purchaseAmt.setValue(bd);
      
      loanREInfo.setPropPurchaseAmt(purchaseAmt);
    }
    
    // Monthly Income
    //
    field = (String)fields.get("MONINC");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      MoIncmAmtType monthlyIncome = new MoIncmAmtType();
      monthlyIncome.setValue(bd);
      
      loanAccountInfo.setMoIncmAmt(monthlyIncome);
    }

    // Monthly Housing Expense
    //
    field = (String)fields.get("MHOUEX");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      MoHouseAmtType monthlyHouseAmt = new MoHouseAmtType();
      monthlyHouseAmt.setValue(bd);
      
      loanMtgInfo.setMoHouseAmt(monthlyHouseAmt);
    }
    
    // Monthly Debt Expense
    //
    field = (String)fields.get("MDEBEX");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      MoDebtAmtType monthlyDebt = new MoDebtAmtType();
      monthlyDebt.setValue(bd);
      
      loanAccountInfo.setMoDebtAmt(monthlyDebt);
    }
    
    // Eligible Rent Unit 1
    //
    field = (String)fields.get("ELRNT1");
    if (field != null)
    {
      NumRentalUnitType rental = new NumRentalUnitType();
      rental.setValue(Integer.parseInt(field));
      
      housingInfo1.setNumRentalUnit(rental);
    }

    // Eligible Rent Unit 2
    //
    field = (String)fields.get("ELRNT2");
    if (field != null)
    {
      NumRentalUnitType rental = new NumRentalUnitType();
      rental.setValue(Integer.parseInt(field));
      
      housingInfo2.setNumRentalUnit(rental);
    }

    // Eligible Rent Unit 3
    //
    field = (String)fields.get("ELRNT3");
    if (field != null)
    {
      NumRentalUnitType rental = new NumRentalUnitType();
      rental.setValue(Integer.parseInt(field));
      
      housingInfo3.setNumRentalUnit(rental);
    }
    
    // Eligible Rent Unit 4
    //
    field = (String)fields.get("ELRNT4");
    if (field != null)
    {
      NumRentalUnitType rental = new NumRentalUnitType();
      rental.setValue(Integer.parseInt(field));
      
      housingInfo4.setNumRentalUnit(rental);
    }
    
    // Special Feature #1
    //
    List<FHLBSICInfoCType> fhlbsicInfoList = fhlbsicInfoArray.getFHLBSICInfos();
    fhlbsicInfoList.add(fhlbsicInfo1);
    fhlbsicInfoList.add(fhlbsicInfo2);
    fhlbsicInfoList.add(fhlbsicInfo3);
    fhlbsicInfoList.add(fhlbsicInfo4);
    fhlbsicInfoList.add(fhlbsicInfo5);
    fhlbsicInfoList.add(fhlbsicInfo6);
    loanMtgInfo.setFHLBSICInfoArray(fhlbsicInfoArray);
    
    field = (String)fields.get("SPCCFE1");
    //general.errLog( "SPCCFE1: " + field, "JXC.log" );

    if (field != null)
    {
      FHLBSICType sf = new FHLBSICType();
      sf.setValue(field);
      fhlbsicInfo1.setFHLBSIC(sf);

      //FHLBSICTxtType txyType = new FHLBSICTxtType();
      //txyType.setValue( " " ); // Send in a blank or nothing not null
      //fhlbsicInfo1.setFHLBSICTxt( txyType );
    }

    // Special Feature #2
    //
    field = (String)fields.get("SPCCFE2");
    //general.errLog( "SPCCFE2: " + field, "JXC.log" );

    if (field != null)
    {
      FHLBSICType sf = new FHLBSICType();
      sf.setValue(field);
      
      fhlbsicInfo2.setFHLBSIC(sf);
    }

    // Special Feature #3
    //
    field = (String)fields.get("SPCCFE3");
    //general.errLog( "SPCCFE3: " + field, "JXC.log" );

    if (field != null)
    {
      FHLBSICType sf = new FHLBSICType();
      sf.setValue(field);
      
      fhlbsicInfo3.setFHLBSIC(sf);
    }

    // Special Feature #4
    //
    field = (String)fields.get("SPCCFE4");
    //general.errLog( "SPCCFE4: " + field, "JXC.log" );

    if (field != null)
    {
      FHLBSICType sf = new FHLBSICType();
      sf.setValue(field);
      
      fhlbsicInfo4.setFHLBSIC(sf);
    }

    // Special Feature #5
    //
    field = (String)fields.get("SPCCFE5");
    //general.errLog( "SPCCFE5: " + field, "JXC.log" );

    if (field != null)
    {
      FHLBSICType sf = new FHLBSICType();
      sf.setValue(field);
      
      fhlbsicInfo5.setFHLBSIC(sf);
    }

    // Special Feature #6
    //
    field = (String)fields.get("SPCCFE6");
    //general.errLog( "SPCCFE6: " + field, "JXC.log" );

    if (field != null)
    {
      FHLBSICType sf = new FHLBSICType();
      sf.setValue(field);
      
      fhlbsicInfo6.setFHLBSIC(sf);
    }

    // Second Mortgage Flag
    //
    field = (String)fields.get("SECMTG");
    if (field != null)
    {
      SecdMtgCodeType secondMtg = new SecdMtgCodeType();
      secondMtg.setValue(field);
      
      loanMtgInfo.setSecdMtgCode(secondMtg);
    }

    // FHA/VA Flag
    //
    field = (String)fields.get("FHAVA");
    if (field != null)
    {
      FHAVACodeType fhaVa = new FHAVACodeType();
      fhaVa.setValue(field);
      
      loanMtgInfo.setFHAVACode(fhaVa);
    }

    // Number of Units
    //
    field = (String)fields.get("UNITS#");
    if (field != null)
    {
      NumUnitType numUnits = new NumUnitType();
      numUnits.setValue(Integer.parseInt(field));
      
      loanMtgInfo.setNumUnit(numUnits);
    }

    // Occupancy Code
    //
    field = (String)fields.get("OCCCOD");
    if (field != null)
    {
      OccupCodeType occupancyCode = new OccupCodeType();
      occupancyCode.setValue(field);
      
      loanREInfo.setOccupCode(occupancyCode);
    }

    // Project Type
    //
    field = (String)fields.get("PRJTYP");
    if (field != null)
    {
      ProjectCodeType projectCode = new ProjectCodeType();
      projectCode.setValue(field);
      
      loanREInfo.setProjectCode(projectCode);
    }

    // Saleable Code
    //
    field = (String)fields.get("SALABL");
    if (field != null)
    {
      AvlSecdMktgCodeType saleableCode = new AvlSecdMktgCodeType();
      saleableCode.setValue(field);
      
      loanMtgInfo.setAvlSecdMktgCode(saleableCode);
    }
    
    // Investor Purpose
    //
    field = (String)fields.get("INVPUR");
    if (field != null)
    {
      InvrPurpCodeType investorPurpose = new InvrPurpCodeType();
      investorPurpose.setValue(field);
      
      loanAccountInfo.setInvrPurpCode(investorPurpose);
    }
    
    // Property Type
    //
    field = (String)fields.get("PROPTY");
    if (field != null)
    {
      FHLBPropCodeType propertyType = new FHLBPropCodeType();
      propertyType.setValue(field);
      
      loanMtgInfo.setFHLBPropCode(propertyType);
    }
    
    // JHA MI Code
    //
    field = (String)fields.get("MICODE");
    if (field != null)
    {
      MtgInsurCodeType miCode = new MtgInsurCodeType();
      miCode.setValue(field);
      
      loanMtgInfo.setMtgInsurCode(miCode);
    }
    
    // Investor MI Code
    //
    field = (String)fields.get("INVMIC");
    if (field != null)
    {
      InvrInsurCodeType investorMICode = new InvrInsurCodeType();
      investorMICode.setValue(field);
      
      loanAccountInfo.setInvrInsurCode(investorMICode);
    }
    
    // Balloon Call Date
    //
    field = (String)fields.get("BLNCD6");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      BallCallDtType balloonCallDate = new BallCallDtType();
      balloonCallDate.setValue(xCal);
      
      loanBalDtInfo.setBallCallDt(balloonCallDate);
    }
    
    // Original Rate
    // Not in jXchange
    
    // Interest Only End Date
    //
    field = (String)fields.get("INOED6");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      IntOnlyExpDtType intOnlyEndDate = new IntOnlyExpDtType();
      intOnlyEndDate.setValue(xCal);
      
      loanBalDtInfo.setIntOnlyExpDt(intOnlyEndDate);
    }
    
    // Feature Code
    //
    field = (String)fields.get("FEATCD");
    if (field != null)
    {
      LnFeatureCodeType featureCode = new LnFeatureCodeType();
      featureCode.setValue(field);
      
      loanMtgInfo.setLnFeatureCode(featureCode);
    }
    
    // Condo PUD Name
    //
    field = (String)fields.get("CONDOP");
    if (field != null)
    {
      CondoPUDInfoType condoPUD = new CondoPUDInfoType();
      condoPUD.setValue(field);
      
      loanREInfo.setCondoPUDInfo(condoPUD);
    }
    
    // Reduced Document
    //
    field = (String)fields.get("REDDOC");
    if (field != null)
    {
      RedDocCodeType reducedDocCode = new RedDocCodeType();
      reducedDocCode.setValue(field);
      
      loanMtgInfo.setRedDocCode(reducedDocCode);
    }
    
    // Borrower Initial Payment
    // Not in jXchange
    
    // % Yearly Payment Increase
    //
    field = (String)fields.get("YRLTPI");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      YrPmtIncrPctType yearlyPmtIncPct = new YrPmtIncrPctType();
      yearlyPmtIncPct.setValue(bd);
      
      loanPmtInfo.setYrPmtIncrPct(yearlyPmtIncPct);
    }
    
    // Graduated Payment Option
    //
    field = (String)fields.get("GRADPO");
    if (field != null)
    {
      GradPmtCodeType gradPmtCode = new GradPmtCodeType();
      gradPmtCode.setValue(field);
      
      loanPmtInfo.setGradPmtCode(gradPmtCode);
    }
    
    // Convertible Flag
    // Not in jXchange

    /*
     * SKIPPING AHI SECTION.  UNUSED.  DOWNPAYMENT IS CAPTURED BY DWNPMT FIELD.
     */

    // Participation Principal Payment Split Percentage
    //
    field = (String)fields.get("PRPRPC");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      PrtcpPrincPmtPctType partPrinPmt = new PrtcpPrincPmtPctType();
      partPrinPmt.setValue(bd);
      
      loanPmtInfo.setPrtcpPrincPmtPct(partPrinPmt);
    }
    
    // Participation Interest Payment Split Percentage
    //
    field = (String)fields.get("PRINPC");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      PrtcpIntPmtPctType partIntPmt = new PrtcpIntPmtPctType();
      partIntPmt.setValue(bd);
      
      loanPmtInfo.setPrtcpIntPmtPct(partIntPmt);
    }
    
    // Participation Serquence Number
    //
    field = (String)fields.get("PRTSQ#");
    if (field != null)
    {
      PrtcpSeqIdType partSeq = new PrtcpSeqIdType();
      partSeq.setValue(field);
      
      loanPmtInfo.setPrtcpSeqId(partSeq);
    }
    
    // Participation Payment Split Option
    //
    field = (String)fields.get("PRTPMS");
    if (field != null)
    {
      PrtcpPmtSplitCodeType partSplit = new PrtcpPmtSplitCodeType();
      partSplit.setValue(field);
      
      loanPmtInfo.setPrtcpPmtSplitCode(partSplit);
    }
    
    // Participation First Payment Interest Option
    //
    field = (String)fields.get("PRT1PM");
    if (field != null)
    {
      PrtcpFirstPmtCodeType partFirstPmt = new PrtcpFirstPmtCodeType();
      partFirstPmt.setValue(field);
      
      loanPmtInfo.setPrtcpFirstPmtCode(partFirstPmt);
    }
    
    // Exclude From Non-accrual
    //
    field = (String)fields.get("XCLSTT");
    if (field != null)
    {
      ExclAutoNonAccrType excludeNonAccrual = new ExclAutoNonAccrType();
      excludeNonAccrual.setValue(field);
      
      loanAccountInfo.setExclAutoNonAccr(excludeNonAccrual);
    }
    
    // # of Days for Billing Notice
    //
    field = (String)fields.get("BILNDY");
    if (field != null)
    {
      BilLeadDaysType billLeadDays = new BilLeadDaysType();
      billLeadDays.setValue(Integer.parseInt(field));
      
      loanPmtInfo.setBilLeadDays(billLeadDays);
    }
    
    // High Risk Customer
    //
    field = (String)fields.get("HIRISK");
    if (field != null)
    {
      HighRiskCustType highRiskCustomer = new HighRiskCustType();
      highRiskCustomer.setValue(field);
      
      loanAccountInfo.setHighRiskCust(highRiskCustomer);
    }
    
    // Upfront Percentage
    //
    field = (String)fields.get("DLRUPC");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      UpfrntPctType upfrontPct = new UpfrntPctType();
      upfrontPct.setValue(bd);
      
      loanDealerInfo.setUpfrntPct(upfrontPct);
    }
    
    // Dealer Reserve Percent
    //
    field = (String)fields.get("DLRRPC");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      RemResrvPctType dealerRsvPct = new RemResrvPctType();
      dealerRsvPct.setValue(bd);
      
      loanDealerInfo.setRemResrvPct(dealerRsvPct);
    }
    
    // Upfront Payoff # of Days
    //
    field = (String)fields.get("DLRDYS");
    if (field != null)
    {
      DaysToFrftType daysToForfeit = new DaysToFrftType();
      daysToForfeit.setValue(Integer.parseInt(field));
      
      loanDealerInfo.setDaysToFrft(daysToForfeit);
    }
    
    // Upfront Payoff # of Payments
    //
    field = (String)fields.get("DLRPMT");
    if (field != null)
    {
      PmtsToFrftType paymentsToForfeit = new PmtsToFrftType();
      paymentsToForfeit.setValue(Integer.parseInt(field));
      
      loanDealerInfo.setPmtsToFrft(paymentsToForfeit);
    }
    
    // Forfeit U/F Dlr Discount
    //
    field = (String)fields.get("DLRFOR");
    if (field != null)
    {
      FrftDiscAtPayoffType forfeitDlrDiscount = new FrftDiscAtPayoffType();
      forfeitDlrDiscount.setValue(field);
      
      loanDealerInfo.setFrftDiscAtPayoff(forfeitDlrDiscount);
    }
    
    // U/F Remainder Bank/Dealer
    //
    field = (String)fields.get("DLRBOD");
    if (field != null)
    {
      RebateToBankDlrType rebateToBankOrDlr = new RebateToBankDlrType();
      rebateToBankOrDlr.setValue(field);
      
      loanDealerInfo.setRebateToBankDlr(rebateToBankOrDlr);
    }
    
    // Dealer Reserve
    // ??

    // Bank Reserve
    //
    field = (String)fields.get("DLRBRS");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      RemResrvAmtType bankReserve = new RemResrvAmtType();
      bankReserve.setValue(bd);
      
      loanDealerInfo.setRemResrvAmt(bankReserve);
    }
    
    // Total Interest
    //
    field = (String)fields.get("TTLINT");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      TotIntAmtType totalInt = new TotIntAmtType();
      totalInt.setValue(bd);
      
      loanBalDtInfo.setTotIntAmt(totalInt);
    }
    
    // Semi Monthly 1st Day
    //
    field = (String)fields.get("SEMDY1");
    if (field != null)
    {
      SemiDay1Type semiDay1 = new SemiDay1Type();
      semiDay1.setValue(Integer.parseInt(field));
      
      loanInfo.setSemiDay1(semiDay1);
    }
    
    // Semi Monthly 2nd Day
    //
    field = (String)fields.get("SEMDY2");
    if (field != null)
    {
      SemiDay2Type semiDay2 = new SemiDay2Type();
      semiDay2.setValue(Integer.parseInt(field));
      
      loanInfo.setSemiDay2(semiDay2);
    }
    
    // NAICS Code
    //
    field = (String)fields.get("NAICSC");
    if (field != null)
    {
      NAICSCodeType naicsCode = new NAICSCodeType();
      naicsCode.setValue(field);
      
      loanRegRptInfo.setNAICSCode(naicsCode);
    }
    
    // Account Level Security
    //
    field = (String)fields.get("SECURE");
    if (field != null)
    {
      AcctLvlSecCodeType accountLevelSec = new AcctLvlSecCodeType();
      accountLevelSec.setValue(field);
      
      loanInfo.setAcctLvlSecCode(accountLevelSec);
    }
    
    // Participation Funding Sequence
    //
    field = (String)fields.get("FNDSQ#");
    if (field != null)
    {
      FundSeqIdType fundSeq = new FundSeqIdType();
      fundSeq.setValue(field);
      
      loanPmtInfo.setFundSeqId(fundSeq);
    }
    
    // Participation Funding Limit
    //
    field = (String)fields.get("FNDLMT");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      FundLmtType fundLimit = new FundLmtType();
      fundLimit.setValue(bd);
      
      loanBalDtInfo.setFundLmt(fundLimit);
    }
    
    // Participation Funding Percentage
    //
    field = (String)fields.get("FNDPCT");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      FundPctType fundPct = new FundPctType();
      fundPct.setValue(bd);
      
      loanPmtInfo.setFundPct(fundPct);
    }
    
    // Delinquent Rate
    //
    field = (String)fields.get("DLQRATE");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      DlqRateType delinqRate = new DlqRateType();
      delinqRate.setValue(bd);
      
      loanRateInfo.setDlqRate(delinqRate);
    }
    
    // Delinquent Rate #
    //
    field = (String)fields.get("DLQRATE#");
    if (field != null)
    {
      DlqRateIdxNumType delinqRateNum = new DlqRateIdxNumType();
      delinqRateNum.setValue(Integer.parseInt(field));
      
      loanRateInfo.setDlqRateIdxNum(delinqRateNum);
    }
    
    // Delinquent Rate Variance
    //
    field = (String)fields.get("DLQVARI");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      DlqRateMarginType delinqRateVar = new DlqRateMarginType();
      delinqRateVar.setValue(bd);
      
      loanRateInfo.setDlqRateMargin(delinqRateVar);
    }
    
    // Delinquent Rate Variance Code
    //
    field = (String)fields.get("DLQVCODE");
    if (field != null)
    {
      DlqRateMarginSignType delinqRateVarCode = new DlqRateMarginSignType();
      delinqRateVarCode.setValue(field);
      
      loanRateInfo.setDlqRateMarginSign(delinqRateVarCode);
    }
    
    // Delinquent Rate Days
    //
    field = (String)fields.get("DLQRTDYS");
    if (field != null)
    {
      DlqRateDaysType delinqRateDays = new DlqRateDaysType();
      delinqRateDays.setValue(Integer.parseInt(field));
      
      loanRateInfo.setDlqRateDays(delinqRateDays);
    }
    
    // Payment Re-amortization Date
    //
    field = (String)fields.get("REAMD6");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      ReAmrtzPmtDtType reamortPmtDt = new ReAmrtzPmtDtType();
      reamortPmtDt.setValue(xCal);
      
      loanBalDtInfo.setReAmrtzPmtDt(reamortPmtDt);
    }
    
    // Payment Re-amortization
    //
    field = (String)fields.get("REAMDAY");
    if (field != null)
    {
      ReAmrtzDOMType reamortDOM = new ReAmrtzDOMType();
      reamortDOM.setValue(Integer.parseInt(field));
      
      loanBalDtInfo.setReAmrtzDOM(reamortDOM);
    }
    
    // Re-amortization Term
    //
    field = (String)fields.get("REAMTRM");
    if (field != null)
    {
      PmtReAmrtzPeriodType reamortPeriod = new PmtReAmrtzPeriodType();
      reamortPeriod.setValue(Integer.parseInt(field));
      
      loanPmtInfo.setPmtReAmrtzPeriod(reamortPeriod);
    }
    
    // Re-amortization Term Code
    //
    field = (String)fields.get("REAMTMCD");
    if (field != null)
    {
      PmtReAmrtzPeriodCodeType reamortPeriodCode = new PmtReAmrtzPeriodCodeType();
      reamortPeriodCode.setValue(field);
      
      loanPmtInfo.setPmtReAmrtzPeriodCode(reamortPeriodCode);
    }
    
    // Print Receipt
    //
    field = (String)fields.get("RECEIT");
    if (field != null)
    {
      PrtRcptType printReceipt = new PrtRcptType();
      printReceipt.setValue(field);
      
      loanAccountInfo.setPrtRcpt(printReceipt);
    }
    
    // Negative Amortization Percent Cap
    //
    field = (String)fields.get("NEGPCT");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      NegAmrtzCapPctType negAmortPct = new NegAmrtzCapPctType();
      negAmortPct.setValue(bd);
      
      loanPmtInfo.setNegAmrtzCapPct(negAmortPct);
    }
    
    // Default NSF Fee
    //
    field = (String)fields.get("NSFFEE");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      NSFFeeAmtType nsfFee = new NSFFeeAmtType();
      nsfFee.setValue(bd);
      
      loanPmtInfo.setNSFFeeAmt(nsfFee);
    }
    
    // Minimum Check Tolerance
    //
    field = (String)fields.get("MADVFE");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      MinChkTolrType minCheckTol = new MinChkTolrType();
      minCheckTol.setValue(bd);
      
      loanPmtInfo.setMinChkTolr(minCheckTol);
    }
    
    // Loan User Status Codes
    //
    field = (String)fields.get("USRSTS");
    if (field != null)
    {
      LnStopCodeType loanUserStat = new LnStopCodeType();
      loanUserStat.setValue(field);
      
      loanStopInfo.setLnStopCode(loanUserStat);
    }
        
    // Stop Advances
    //
    field = (String)fields.get("STPADV");
    if (field != null)
    {
      LnStopFuncCodeType stopAdv = new LnStopFuncCodeType();
      stopAdv.setValue(field);
      
      stopAdvancesInfo.setLnStopFuncCode(stopAdv);
    }
    
    // Stop Advances Expiration Date
    //
    field = (String)fields.get("STPAD7");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      LnStopFuncExpDtType stopAdvExpDt = new LnStopFuncExpDtType();
      stopAdvExpDt.setValue(xCal);
      
      stopAdvancesInfo.setLnStopFuncExpDt(stopAdvExpDt);
    }
    
    // Stop Payments
    //
    field = (String)fields.get("STPPMT");
    if (field != null)
    {
      LnStopFuncCodeType stopPmt = new LnStopFuncCodeType();
      stopPmt.setValue(field);
      
      stopPaymentInfo.setLnStopFuncCode(stopPmt);
    }
    
    // Stop Payments Expiration Date
    //
    field = (String)fields.get("STPPM7");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      LnStopFuncExpDtType stopPmtExpDt = new LnStopFuncExpDtType();
      stopPmtExpDt.setValue(xCal);
      
      stopPaymentInfo.setLnStopFuncExpDt(stopPmtExpDt);
    }
    
    // Stop Tax Disbursements
    //
    field = (String)fields.get("STPTAX");
    if (field != null)
    {
      LnStopFuncCodeType stopTaxDisb = new LnStopFuncCodeType();
      stopTaxDisb.setValue(field);
      
      stopTaxDisbInfo.setLnStopFuncCode(stopTaxDisb);
    }
    
    // Stop Tax Disbursements Expiration Date
    //
    field = (String)fields.get("STPTX7");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      LnStopFuncExpDtType stopTaxDisbExpDt = new LnStopFuncExpDtType();
      stopTaxDisbExpDt.setValue(xCal);
      
      stopTaxDisbInfo.setLnStopFuncExpDt(stopTaxDisbExpDt);
    }
    
    // Stop Hazard Disbursements
    //
    field = (String)fields.get("STPHZD");
    if (field != null)
    {
      LnStopFuncCodeType stopHazDisb = new LnStopFuncCodeType();
      stopHazDisb.setValue(field);
      
      stopHazDisbInfo.setLnStopFuncCode(stopHazDisb);
    }

    // Stop Hazard Disbursement Expiration Date
    //
    field = (String)fields.get("STPHZ7");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      LnStopFuncExpDtType stopHazDisbExpDt = new LnStopFuncExpDtType();
      stopHazDisbExpDt.setValue(xCal);
      
      stopHazDisbInfo.setLnStopFuncExpDt(stopHazDisbExpDt);
    }
    
    // Stop Optional Insurance
    //
    field = (String)fields.get("STPOPT");
    if (field != null)
    {
      LnStopFuncCodeType stopOptIns = new LnStopFuncCodeType();
      stopOptIns.setValue(field);
      
      stopOptInsInfo.setLnStopFuncCode(stopOptIns);
    }
    
    // Stop Optional Insurance Expiration Date
    //
    field = (String)fields.get("STPOP7");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      LnStopFuncExpDtType stopOptInsExpDt = new LnStopFuncExpDtType();
      stopOptInsExpDt.setValue(xCal);
      
      stopOptInsInfo.setLnStopFuncExpDt(stopOptInsExpDt);
    }
    
    // Stop Loan Sale
    //
    field = (String)fields.get("STPLNS");
    if (field != null)
    {
      LnStopFuncCodeType stopLoanSale = new LnStopFuncCodeType();
      stopLoanSale.setValue(field);
      
      stopLoanSaleInfo.setLnStopFuncCode(stopLoanSale);
    }
    
    // Stop Loan Sale Expiration Date
    //
    field = (String)fields.get("STPLS7");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      LnStopFuncExpDtType stopLoanSaleExpDt = new LnStopFuncExpDtType();
      stopLoanSaleExpDt.setValue(xCal);
      
      stopLoanSaleInfo.setLnStopFuncExpDt(stopLoanSaleExpDt);
    }
    
    // Stop Notices
    //
    field = (String)fields.get("STPNOT");
    if (field != null)
    {
      LnStopFuncCodeType stopNotices = new LnStopFuncCodeType();
      stopNotices.setValue(field);
      
      stopNoticesInfo.setLnStopFuncCode(stopNotices);
    }
    
    // Stop Notices Expiration
    //
    field = (String)fields.get("STPNT7");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      LnStopFuncExpDtType stopNoticesExpDt = new LnStopFuncExpDtType();
      stopNoticesExpDt.setValue(xCal);
      
      stopNoticesInfo.setLnStopFuncExpDt(stopNoticesExpDt);
    }
    
    // Stop Credit Reporting
    //
    field = (String)fields.get("STPCRP");
    if (field != null)
    {
      LnStopFuncCodeType stopCreditRpt = new LnStopFuncCodeType();
      stopCreditRpt.setValue(field);
      
      stopCreditRptInfo.setLnStopFuncCode(stopCreditRpt);
    }
    
    // Stop Credit Reporting Expiration Date
    //
    field = (String)fields.get("STPCR7");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      LnStopFuncExpDtType stopCreditRptExpDt = new LnStopFuncExpDtType();
      stopCreditRptExpDt.setValue(xCal);
      
      stopCreditRptInfo.setLnStopFuncExpDt(stopCreditRptExpDt);      
    }
    
    // Stop Prepayments
    //
    field = (String)fields.get("STPPRP");
    if (field != null)
    {
      LnStopFuncCodeType stopPrepay = new LnStopFuncCodeType();
      stopPrepay.setValue(field);
      
      stopPrepayInfo.setLnStopFuncCode(stopPrepay);
    }
    
    // Stop Prepayments Expiration Date
    //
    field = (String)fields.get("STPPR7");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      LnStopFuncExpDtType stopPrepayExpDt = new LnStopFuncExpDtType();
      stopPrepayExpDt.setValue(xCal);
      
      stopPrepayInfo.setLnStopFuncExpDt(stopPrepayExpDt);      
    }
    
    // Stop Accrual
    //
    field = (String)fields.get("STPESA");
    if (field != null)
    {
      LnStopFuncCodeType stopAccrual = new LnStopFuncCodeType();
      stopAccrual.setValue(field);
      
      stopAccrualInfo.setLnStopFuncCode(stopAccrual);
    }
    
    // Stop Accrual Expiration
    //
    field = (String)fields.get("STPEA7");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      LnStopFuncExpDtType stopAccrualExpDt = new LnStopFuncExpDtType();
      stopAccrualExpDt.setValue(xCal);
      
      stopAccrualInfo.setLnStopFuncExpDt(stopAccrualExpDt);      
    }
    
    // Stop Correspondence
    //
    field = (String)fields.get("STPCOR");
    if (field != null)
    {
      LnStopFuncCodeType stopCorr = new LnStopFuncCodeType();
      stopCorr.setValue(field);
      
      stopCorrespInfo.setLnStopFuncCode(stopCorr);
    }
    
    // Stop Correspondence Expiration Date
    //
    field = (String)fields.get("STPCO7");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      LnStopFuncExpDtType stopCorrExpDt = new LnStopFuncExpDtType();
      stopCorrExpDt.setValue(xCal);
      
      stopCorrespInfo.setLnStopFuncExpDt(stopCorrExpDt);      
    }
    
    // Stop IRS Reporting
    //
    field = (String)fields.get("STPIRS");
    if (field != null)
    {
      LnStopFuncCodeType stopIRS = new LnStopFuncCodeType();
      stopIRS.setValue(field);
      
      stopIRSInfo.setLnStopFuncCode(stopIRS);
    }
    
    // Stop IRS Reporting Expiration
    //
    field = (String)fields.get("STPIR7");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      LnStopFuncExpDtType stopIRSExpDt = new LnStopFuncExpDtType();
      stopIRSExpDt.setValue(xCal);
      
      stopIRSInfo.setLnStopFuncExpDt(stopIRSExpDt);      
    }
    
    // Stop Statements
    //
    field = (String)fields.get("STPSTM");
    if (field != null)
    {
      LnStopFuncCodeType stopState = new LnStopFuncCodeType();
      stopState.setValue(field);
      
      stopStateInfo.setLnStopFuncCode(stopState);
    }
    
    // Stop Statements Expiration Date
    //
    field = (String)fields.get("STPST7");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      LnStopFuncExpDtType stopStateExpDt = new LnStopFuncExpDtType();
      stopStateExpDt.setValue(xCal);
      
      stopStateInfo.setLnStopFuncExpDt(stopStateExpDt);      
    }
    
    // Stop Coupon Generation
    //
    field = (String)fields.get("STPCOU");
    if (field != null)
    {
      LnStopFuncCodeType stopCoupon = new LnStopFuncCodeType();
      stopCoupon.setValue(field);
      
      stopCouponInfo.setLnStopFuncCode(stopCoupon);
    }
    
    // Stop Coupon Generation Expiration Date
    //
    field = (String)fields.get("STPCP7");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      LnStopFuncExpDtType stopCouponExpDt = new LnStopFuncExpDtType();
      stopCouponExpDt.setValue(xCal);
      
      stopCouponInfo.setLnStopFuncExpDt(stopCouponExpDt);      
    }
    
    // Stop All Escrow Disbursements
    //
    field = (String)fields.get("STPESD");
    if (field != null)
    {
      LnStopFuncCodeType stopAllEscrowDisb = new LnStopFuncCodeType();
      stopAllEscrowDisb.setValue(field);
      
      stopEscrowInfo.setLnStopFuncCode(stopAllEscrowDisb);
    }
    
    // Stop All Escrow Disbursements Expiration Date
    //
    field = (String)fields.get("STPED7");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      LnStopFuncExpDtType stopAllEscrowDisbExpDt = new LnStopFuncExpDtType();
      stopAllEscrowDisbExpDt.setValue(xCal);
      
      stopEscrowInfo.setLnStopFuncExpDt(stopAllEscrowDisbExpDt);      
    }
    
    // Stop Escrow Analysis
    //
    field = (String)fields.get("STPPDP");
    if (field != null)
    {
      LnStopFuncCodeType stopEscrowAnalysis = new LnStopFuncCodeType();
      stopEscrowAnalysis.setValue(field);
      
      stopEscrowAnalInfo.setLnStopFuncCode(stopEscrowAnalysis);
    }
    
    // Stop Escrow Analysis Expiration Date
    //
    field = (String)fields.get("STPPD7");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      LnStopFuncExpDtType stopEscrowAnalExpDt = new LnStopFuncExpDtType();
      stopEscrowAnalExpDt.setValue(xCal);
      
      stopEscrowAnalInfo.setLnStopFuncExpDt(stopEscrowAnalExpDt);      
    }
    
    // Stop Past Due Reporting
    //
    field = (String)fields.get("STPACR");
    if (field != null)
    {
      LnStopFuncCodeType stopPstDueRpt = new LnStopFuncCodeType();
      stopPstDueRpt.setValue(field);
      
      stopPastDueRptInfo.setLnStopFuncCode(stopPstDueRpt);
    }
    
    // Stop Past Due Reporting Expiration Date
    //
    field = (String)fields.get("STPAC7");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      LnStopFuncExpDtType stopPstDueRptExpDt = new LnStopFuncExpDtType();
      stopPstDueRptExpDt.setValue(xCal);
      
      stopPastDueRptInfo.setLnStopFuncExpDt(stopPstDueRptExpDt);
    }
    
    // Set all of the stop payments array elements into the main type.
    //
    List<LnStopFuncInfoCType> loanStopList = loanStopInfoArray.getLnStopFuncInfos();
    loanStopList.add(stopAdvancesInfo);
    loanStopList.add(stopPaymentInfo);
    loanStopList.add(stopTaxDisbInfo);
    loanStopList.add(stopHazDisbInfo);
    loanStopList.add(stopOptInsInfo);
    loanStopList.add(stopLoanSaleInfo);
    loanStopList.add(stopNoticesInfo);
    loanStopList.add(stopCreditRptInfo);
    loanStopList.add(stopPrepayInfo);
    loanStopList.add(stopAccrualInfo);
    loanStopList.add(stopCorrespInfo);
    loanStopList.add(stopIRSInfo);
    loanStopList.add(stopStateInfo);
    loanStopList.add(stopCouponInfo);
    loanStopList.add(stopEscrowInfo);
    loanStopList.add(stopEscrowAnalInfo);
    loanStopList.add(stopPastDueRptInfo);
    loanStopInfo.setLnStopInfoArray(loanStopInfoArray);
    
    // Post Short Payment
    //
    field = (String)fields.get("PSTSHR");
    if (field != null)
    {
      PostShortPmtsType postShortPmts = new PostShortPmtsType();
      postShortPmts.setValue(field);
      
      loanPmtInfo.setPostShortPmts(postShortPmts);
    }
    
    // Use Payment Suspense
    //
    field = (String)fields.get("USEUNA");
    if (field != null)
    {
      UsePmtSuspType usePmtSuspense = new UsePmtSuspType();
      usePmtSuspense.setValue(field);
      
      loanPmtInfo.setUsePmtSusp(usePmtSuspense);
    }
    
    // Payment Suspense Method
    //
    field = (String)fields.get("HOWUNA");
    if (field != null)
    {
      PmtSuspPostCodeType pmtSuspenseMethod = new PmtSuspPostCodeType();
      pmtSuspenseMethod.setValue(field);
      
      loanPmtInfo.setPmtSuspPostCode(pmtSuspenseMethod);
    }
    
    // Dealer Location
    //
    field = (String)fields.get("DLRLOC");
    if (field != null)
    {
      DlrLocIdType dealerLoc = new DlrLocIdType();
      dealerLoc.setValue(field);
      
      loanDealerInfo.setDlrLocId(dealerLoc);
    }
    
    // Dealer Type
    //
    field = (String)fields.get("DLRTYP");
    if (field != null)
    {
      DlrCodeType dealerCode = new DlrCodeType();
      dealerCode.setValue(field);
      
      loanDealerInfo.setDlrCode(dealerCode);
    }

    // Forfeit Rebate U/F Response
    //
    field = (String)fields.get("DLRFDP");
    if (field != null)
    {
      FrftRebateOnPayoffType forfeitRebate = new FrftRebateOnPayoffType();
      forfeitRebate.setValue(field);
      
      loanDealerInfo.setFrftRebateOnPayoff(forfeitRebate);
    }
    
    // Charge Off Forfeit
    //
    field = (String)fields.get("DLRFDPC");
    if (field != null)
    {
      FrftRebateAfterChgoffType forfeitRebate = new FrftRebateAfterChgoffType();
      forfeitRebate.setValue(field);
      
      loanDealerInfo.setFrftRebateAfterChgoff(forfeitRebate);
    }
    
    // Charged Off Forfeit U/F Dealer Discount
    //
    field = (String)fields.get("CDLRFOR");
    if (field != null)
    {
      FrftRebateIfChgoffType forfeitRebate = new FrftRebateIfChgoffType();
      forfeitRebate.setValue(field);
      
      loanDealerInfo.setFrftRebateIfChgoff(forfeitRebate);
    }

    // Charged Off U/F # of Days
    //
    field = (String)fields.get("CDLRDYS");
    if (field != null)
    {
      DaysToFrftOnChgoffType daysToForfeit = new DaysToFrftOnChgoffType();
      daysToForfeit.setValue(Integer.parseInt(field));
      
      loanDealerInfo.setDaysToFrftOnChgoff(daysToForfeit);
    }
    
    // Charged Off Upfront Payoff
    //
    field = (String)fields.get("CDLRPMT");
    if (field != null)
    {
      PmtsToFrftOnChgoffType paymentsToForfeit = new PmtsToFrftOnChgoffType();
      paymentsToForfeit.setValue(Integer.parseInt(field));
      
      loanDealerInfo.setPmtsToFrftOnChgoff(paymentsToForfeit);
    }
    
    // Charged Off Upfront Forfeit
    //
    field = (String)fields.get("CDLRPDD");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      PctRebateToChgoffType percentRebate = new PctRebateToChgoffType();
      percentRebate.setValue(bd);
      
      loanDealerInfo.setPctRebateToChgoff(percentRebate);
    }
    
    // Recourse Code
    //
    field = (String)fields.get("RECRSCD");
    if (field != null)
    {
      RecourseCodeType recourseCode = new RecourseCodeType();
      recourseCode.setValue(field);
      
      loanDealerInfo.setRecourseCode(recourseCode);
    }
    
    // Recourse %
    //
    field = (String)fields.get("RECRSPC");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      RecoursePctType recoursePct = new RecoursePctType();
      recoursePct.setValue(bd);
      
      loanDealerInfo.setRecoursePct(recoursePct);
    }
    
    // Recourse Term
    //
    field = (String)fields.get("RECRSTM");
    if (field != null)
    {
      RecourseTermType recourseTerm = new RecourseTermType();
      recourseTerm.setValue(Integer.parseInt(field));
      
      loanDealerInfo.setRecourseTerm(recourseTerm);
    }

    // Recourse Term Unit Code
    //
    field = (String)fields.get("RECRSTC");
    if (field != null)
    {
      RecourseTermUnitType recourseTerm = new RecourseTermUnitType();
      recourseTerm.setValue(field);
      
      loanDealerInfo.setRecourseTermUnit(recourseTerm);
    }

    // Recourse Days Past Due
    //
    field = (String)fields.get("RECDAYP");
    if (field != null)
    {
      RecourseDayType recourseDaysPastDue = new RecourseDayType();
      recourseDaysPastDue.setValue(Integer.parseInt(field));
      
      loanDealerInfo.setRecourseDay(recourseDaysPastDue);
    }
    
    // Participation ID Number
    //
    field = (String)fields.get("PARTID#");
    if (field != null)
    {
      PrtcpAcctIdType participationID = new PrtcpAcctIdType();
      participationID.setValue(field);
      
      loanAccountInfo.setPrtcpAcctId(participationID);
    }

    // % of Balance to Reamortize
    //
    field = (String)fields.get("PCTREA");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      PctBalReAmrtzType pctBalReamort = new PctBalReAmrtzType();
      pctBalReamort.setValue(bd);
      
      loanPmtInfo.setPctBalReAmrtz(pctBalReamort);
    }
    
    // Participation Percentage
    //
    field = (String)fields.get("PARTPC");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      OrigPartPctType participationPct = new OrigPartPctType();
      participationPct.setValue(bd);
      
      loanAccountInfo.setOrigPartPct(participationPct);
    }
    
    // Sub-Prime Lending
    //
    field = (String)fields.get("SUBPRM");
    if (field != null)
    {
      SubPrimeLnCodeType subPrimeLendingCode = new SubPrimeLnCodeType();
      subPrimeLendingCode.setValue(field);
      
      loanAccountInfo.setSubPrimeLnCode(subPrimeLendingCode);
    }
    
    // Credit Line CIF #
    //
    field = (String)fields.get("CLCIF#");
    if (field != null)
    {
      CustIdType custID = new CustIdType();
      custID.setValue(field);
      
      loanInfo.setCustId(custID);
    }

    // Add Overline Fee to Next Bill
    //
    field = (String)fields.get("ADOTNB");
    if (field != null)
    {
      OvrLineFeeAddNxtBilType addOverline = new OvrLineFeeAddNxtBilType();
      addOverline.setValue(field);
      
      loanPmtInfo.setOvrLineFeeAddNxtBil(addOverline);
    }
    
    // Senior Lien
    //
    field = (String)fields.get("LNSENL");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      SrLienAmtType seniorLien = new SrLienAmtType();
      seniorLien.setValue(bd);
      
      loanRegRptInfo.setSrLienAmt(seniorLien);
    }
    
    // Syndication Agent Number
    //
    field = (String)fields.get("SYNDAGTNBR");
    if (field != null)
    {
      SynAgentIdType synAgentID = new SynAgentIdType();
      synAgentID.setValue(field);
      
      loanMtgInfo.setSynAgentId(synAgentID);
    }
    
    // Syndication Member Number
    //
    field = (String)fields.get("SYNDMBRNBR");
    if (field != null)
    {
      SynMemberIdType synMemberID = new SynMemberIdType();
      synMemberID.setValue(field);
      
      loanMtgInfo.setSynMemberId(synMemberID);
    }

    // Shared National Credit
    //
    field = (String)fields.get("SHRNTLCRD");
    if (field != null)
    {
      ShareNatCrLnType sharedCredit = new ShareNatCrLnType();
      sharedCredit.setValue(field);
      
      loanMtgInfo.setShareNatCrLn(sharedCredit);
    }
    
    // Correspondent Bank
    //
    field = (String)fields.get("CORRESBANK");
    if (field != null)
    {
      CorrBankCodeType correspondentBank = new CorrBankCodeType();
      correspondentBank.setValue(field);
      
      loanREInfo.setCorrBankCode(correspondentBank);
    }

    // Currency Type
    //
    field = (String)fields.get("CRCYTYPE");
    if (field != null)
    {
      CurrencyCodeType currencyCode = new CurrencyCodeType();
      currencyCode.setValue(field);
      
      loanAccountInfo.setCurrencyCode(currencyCode);
    }
    
    // Borrower Self-Employed
    //
    field = (String)fields.get("BORRSLFEMP");
    if (field != null)
    {
      BorwSelfEmplType selfEmp = new BorwSelfEmplType();
      selfEmp.setValue(field);
      
      primaryBorrowerInfo.setBorwSelfEmpl(selfEmp);
    }
    
    // Borrower FICO Score
    //
    field = (String)fields.get("BORRFICO");
    if (field != null)
    {
      BorwFICOIdType ficoScore = new BorwFICOIdType();
      ficoScore.setValue(field);
      
      primaryBorrowerInfo.setBorwFICOId(ficoScore);
    }
    
    // Co-Borrower Income
    //
    field = (String)fields.get("COBORRINC");
    //general.errLog( "COBORRINC: " + field, "JXC.log" );
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      BorwIncmAmtType coborrowerIncome = new BorwIncmAmtType();
      coborrowerIncome.setValue(bd);
      
      coBorrowerInfo.setBorwIncmAmt(coborrowerIncome);

      //
      // NEED TO SET BORROWER INFO TXT - Send in a blank or nothing not null
      //
      BorwInfoTxtType infoTxt = new BorwInfoTxtType();
      infoTxt.setValue( "Co Borrower" );
      //infoTxt.setValue();
      coBorrowerInfo.setBorwInfoTxt( infoTxt );
    }
    
    // Co-Borrower FICO Score
    //
    field = (String)fields.get("COBORRFICO");
    if (field != null)
    {
      BorwFICOIdType ficoScore = new BorwFICOIdType();
      ficoScore.setValue(field);
      
      coBorrowerInfo.setBorwFICOId(ficoScore);
    }
    
    // FHLB Property Type
    // This was already set with PROPTY
    
    // FHLB Loan Purpose
    //
    field = (String)fields.get("LOANPURP");
    if (field != null)
    {
      FHLBPurpCodeType loanPurpose = new FHLBPurpCodeType();
      loanPurpose.setValue(field);
      
      loanMtgInfo.setFHLBPurpCode(loanPurpose);
    }
    
    // FHLB Product Loan
    //
    field = (String)fields.get("LOANPRDCT");
    if (field != null)
    {
      FHLBProdCodeType productCode = new FHLBProdCodeType();
      productCode.setValue(field);
      
      loanMtgInfo.setFHLBProdCode(productCode);
    }
    
    // Subordinated Financing
    //
    field = (String)fields.get("SUBORDFIN");
    if (field != null)
    {
      SubDebtCodeType subFin = new SubDebtCodeType();
      subFin.setValue(field);
      
      loanMtgInfo.setSubDebtCode(subFin);
    }
    
    // Housing Expense Ratio
    // ??
    
    // Total Debt Ratio
    //
    field = (String)fields.get("TOTDBTRAT");
    //general.errLog( "TOTDBTRAT: " + field, "JXC.log" );

    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      //general.errLog( "BigDecimal(field) debtRatio.setValue(bd): " + bd, "JXC.log" );
      TotDebtPctType debtRatio = new TotDebtPctType();
      debtRatio.setValue(bd);
      
      loanAccountInfo.setTotDebtPct(debtRatio);
    }
    
    // MPF Master Commitment #
    //
    field = (String)fields.get("MPFMSTRC#");
    if (field != null)
    {
      MPFCommIdType mpfCommNum = new MPFCommIdType();
      mpfCommNum.setValue(field);
      
      loanMtgInfo.setMPFCommId(mpfCommNum);
    }
    
    // FHLB Documentation Type
    //
    field = (String)fields.get("DOCTYPE");
    if (field != null)
    {
      FHLBDocCodeType fhlbDoc = new FHLBDocCodeType();
      fhlbDoc.setValue(field);
      
      loanMtgInfo.setFHLBDocCode(fhlbDoc);
    }
    
    // Total Other Debt
    //
    field = (String)fields.get("TOTOTHDBT");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      TotOtherDebtAmtType otherDebt = new TotOtherDebtAmtType();
      otherDebt.setValue(bd);
      
      loanAccountInfo.setTotOtherDebtAmt(otherDebt);
    }
    
    // MERS #
    //
    field = (String)fields.get("MERS#");
    if (field != null)
    {
      MERSIdType mersNum = new MERSIdType();
      mersNum.setValue(field);
      
      loanMtgInfo.setMERSId(mersNum);
    }
    
    // Rent Plus Utilities 1
    //
    field = (String)fields.get("RENTPUTL1");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      RentUtlAmtType rentUtil = new RentUtlAmtType();
      rentUtil.setValue(bd);
      
      housingInfo1.setRentUtlAmt(rentUtil);
    }

    // Rent Plus Utilities 2
    //
    field = (String)fields.get("RENTPUTL2");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      RentUtlAmtType rentUtil = new RentUtlAmtType();
      rentUtil.setValue(bd);
      
      housingInfo2.setRentUtlAmt(rentUtil);
    }

    // Rent Plus Utilities 3
    //
    field = (String)fields.get("RENTPUTL3");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      RentUtlAmtType rentUtil = new RentUtlAmtType();
      rentUtil.setValue(bd);
      
      housingInfo3.setRentUtlAmt(rentUtil);
    }
    
    // Rent Plus Utilities 4
    //
    field = (String)fields.get("RENTPUTL4");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      RentUtlAmtType rentUtil = new RentUtlAmtType();
      rentUtil.setValue(bd);
      
      housingInfo4.setRentUtlAmt(rentUtil);
    }

    // Unit Owner Occupied Unit 1
    //
    field = (String)fields.get("UNITOWNO1");
    if (field != null)
    {
      UnitOwnerCodeType unitOwnerCode = new UnitOwnerCodeType();
      unitOwnerCode.setValue(field);
      
      housingInfo1.setUnitOwnerCode(unitOwnerCode);
    }

    // Unit Owner Occupied Unit 2
    //
    field = (String)fields.get("UNITOWNO2");
    if (field != null)
    {
      UnitOwnerCodeType unitOwnerCode = new UnitOwnerCodeType();
      unitOwnerCode.setValue(field);
      
      housingInfo2.setUnitOwnerCode(unitOwnerCode);
    }

    // Unit Owner Occupied Unit 3
    //
    field = (String)fields.get("UNITOWNO3");
    if (field != null)
    {
      UnitOwnerCodeType unitOwnerCode = new UnitOwnerCodeType();
      unitOwnerCode.setValue(field);
      
      housingInfo3.setUnitOwnerCode(unitOwnerCode);
    }

    // Unit Owner Occupied Unit 4
    //
    field = (String)fields.get("UNITOWNO4");
    if (field != null)
    {
      UnitOwnerCodeType unitOwnerCode = new UnitOwnerCodeType();
      unitOwnerCode.setValue(field);
      
      housingInfo4.setUnitOwnerCode(unitOwnerCode);
    }
    
    // Property County Name
    //
    field = (String)fields.get("PROPCNTNME");
    if (field != null)
    {
      PropCountyType county = new PropCountyType();
      county.setValue(field);
      
      loanREInfo.setPropCounty(county);
    }
    
    // Estimated Closing Date
    //
    field = (String)fields.get("CLOSEDATE7");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      EstClsDtType estimatedCloseDate = new EstClsDtType();
      estimatedCloseDate.setValue(xCal);
      
      loanBalDtInfo.setEstClsDt(estimatedCloseDate);
    }
    
    // Agency Case Number
    //
    field = (String)fields.get("AGENCYCASE");
    if (field != null)
    {
      AgencyCaseIdType agencyCaseNum = new AgencyCaseIdType();
      agencyCaseNum.setValue(field);
      
      loanMtgInfo.setAgencyCaseId(agencyCaseNum);
    }
    
    // Borrower Income
    //
    field = (String)fields.get("BORROWINC");
    //general.errLog( "BORROWINC: " + field, "JXC.log" );

    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      BorwIncmAmtType borrowerIncome = new BorwIncmAmtType();
      borrowerIncome.setValue(bd);
      
      primaryBorrowerInfo.setBorwIncmAmt(borrowerIncome);

      //
      // NEED TO SET BORROWER INFO TXT - Send in a blank or nothing not null
      //
      BorwInfoTxtType infoTxt = new BorwInfoTxtType();
      infoTxt.setValue( "Borrower" );
      //infoTxt.setValue();
      primaryBorrowerInfo.setBorwInfoTxt( infoTxt );
    }
    
    // Borrower Race 2
    // ?? How To Set Race 2 - 5
    //

    // CoBorrower Race 2
    // ?? How to Set Race 2 - 5
    
    // Borrower Ethnicity
    //
    field = (String)fields.get("BORRETH");
    if (field != null)
    {
      BorwEthnicCodeType ethnicity = new BorwEthnicCodeType();
      ethnicity.setValue(field);
      
      primaryBorrowerInfo.setBorwEthnicCode(ethnicity);
    }

    // CoBorrower Ethnicity
    //
    field = (String)fields.get("COBOETH");
    if (field != null)
    {
      BorwEthnicCodeType ethnicity = new BorwEthnicCodeType();
      ethnicity.setValue(field);
      
      coBorrowerInfo.setBorwEthnicCode(ethnicity);
    }
    
    // Borrower Birth Date
    //
    field = (String)fields.get("BORRBD8");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      BorwBirthDtType birthDate = new BorwBirthDtType();
      birthDate.setValue(xCal);
      
      primaryBorrowerInfo.setBorwBirthDt(birthDate);
    }
    
    // Co-Borrower Birth Date
    //
    field = (String)fields.get("COBORBD8");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      BorwBirthDtType birthDate = new BorwBirthDtType();
      birthDate.setValue(xCal);
      
      coBorrowerInfo.setBorwBirthDt(birthDate);
    }
    
    // HOEPA Status
    //
    field = (String)fields.get("HOEPASTAT");
    if (field != null)
    {
      HOEPAStatType hoepa = new HOEPAStatType();
      hoepa.setValue(field);
      
      loanMtgInfo.setHOEPAStat(hoepa);
    }
    
    // Rate Spread
    //
    field = (String)fields.get("RATESPRD");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      RateSpreadType rateSpread = new RateSpreadType();
      rateSpread.setValue(bd);
      
      loanRateInfo.setRateSpread(rateSpread);
    }
    
    // Construction Loan Tracking
    //
    field = (String)fields.get("CONSTR");
    if (field != null)
    {
      ConstLnCodeType constructionLoan = new ConstLnCodeType();
      constructionLoan.setValue(field);
      
      loanREInfo.setConstLnCode(constructionLoan);
    }
    
    // Regulatory Risk Weight
    //
    field = (String)fields.get("RGRISK");
    if (field != null)
    {
      RegRiskIdType regRisk = new RegRiskIdType();
      regRisk.setValue(field);
      
      loanRegRptInfo.setRegRiskId(regRisk);
    }
    
    // Regulatory Teaser Rate Applies
    //
    field = (String)fields.get("TEASER");
    if (field != null)
    {
      TeaserRateCodeType teaserRateCode = new TeaserRateCodeType();
      teaserRateCode.setValue(field);
      
      loanRateInfo.setTeaserRateCode(teaserRateCode);
    }
    
    // Exclude From Supervisory LTV
    //
    field = (String)fields.get("EXSLTV");
    if (field != null)
    {
      ExclRealEstateRptCodeType excludeSuperLTV = new ExclRealEstateRptCodeType();
      excludeSuperLTV.setValue(field);
      
      loanRegRptInfo.setExclRealEstateRptCode(excludeSuperLTV);
    }
    
    // Exception to Re-Lending Policy
    //
    field = (String)fields.get("EXRELP");
    if (field != null)
    {
      // ?????
    }
    
    // ATM Card Access
    //
    field = (String)fields.get("LNATMCRD");
    if (field != null)
    {
      // ?????
    }
    
    // HMDA Required?
    //
    field = (String)fields.get("HMDA");
    if (field != null)
    {
      // ?????
    }
    
    // Affiliate
    // Not supported by jXchange at this time
    //
    
    // Min Amount To Create Bill
    //
    field = (String)fields.get("MINBIL");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      MinBilAmtType minBill = new MinBilAmtType();
      minBill.setValue(bd);
      
      loanAccountInfo.setMinBilAmt(minBill);
    }
    
    // Interest First Product
    // Not supported by jXchange at this time
    //
    
    // Step Rate Loan
    // Not supported by jXchange at this time
    //
    
    // Language Code
    //
    field = (String)fields.get("LNLANG");
    if (field != null)
    {
      LangTypeType languageCode = new LangTypeType();
      languageCode.setValue(field);
      
      loanAccountInfo.setLangType(languageCode);
    }
    
    // Apply Payments To Past Due Loans
    //
    field = (String)fields.get("APPDLNS");
    if (field != null)
    {
      PostPmtPastDueCodeType pmtPastDue = new PostPmtPastDueCodeType();
      pmtPastDue.setValue(field);
      
      loanPmtInfo.setPostPmtPastDueCode(pmtPastDue);
    }
    
    // Number of Payments Past Due To Trigger
    //
    field = (String)fields.get("NBRPDPMT");
    if (field != null)
    {
      PostPmtPastDueDayType postPmtPastDueDay = new PostPmtPastDueDayType();
      postPmtPastDueDay.setValue(Integer.parseInt(field));
      
      loanPmtInfo.setPostPmtPastDueDay(postPmtPastDueDay);
    }
    
    // Apply Payments To Prepaid Loans
    //
    field = (String)fields.get("APPPDLNS");
    if (field != null)
    {
      PostPmtPrePaidCodeType applyPmtsToPrepaidLoans = new PostPmtPrePaidCodeType();
      applyPmtsToPrepaidLoans.setValue(field);
      
      loanPmtInfo.setPostPmtPrePaidCode(applyPmtsToPrepaidLoans);
    }
    
    // Post Excess as a Principal Curtailment
    //
    field = (String)fields.get("POSTEXPC");
    if (field != null)
    {
      PostPrincCurtCodeType postPrincipal = new PostPrincCurtCodeType();
      postPrincipal.setValue(field);
      
      loanPmtInfo.setPostPrincCurtCode(postPrincipal);
    }
    
    // Number, Percent or Dollar Amount to Trigger
    //
    field = (String)fields.get("NPDAPPLT");
    if (field != null)
    {
      PrePaidNumType prepaidNum = new PrePaidNumType();
      prepaidNum.setValue(Integer.parseInt(field));
      
      loanPmtInfo.setPrePaidNum(prepaidNum);
    }
    
    // Number, Percent, or Dollar (Code) to Trigger
    //
    field = (String)fields.get("NPDPPLTR");
    if (field != null)
    {
      PrePaidAmtCodeType prepaidCode = new PrePaidAmtCodeType();
      prepaidCode.setValue(field);
      
      loanPmtInfo.setPrePaidAmtCode(prepaidCode);
    }
    
    // FHLB Appraisal Type
    //
    field = (String)fields.get("APRTYP");
    if (field != null)
    {
      FHLBApprCodeType appraisalCode = new FHLBApprCodeType();
      appraisalCode.setValue(field);
      
      loanMtgInfo.setFHLBApprCode(appraisalCode);
    }
    
    // Loan Orig. Source
    //
    field = (String)fields.get("LNRGSRC");
    if (field != null)
    {
      LnOrigSrcCodeType loanOrigSource = new LnOrigSrcCodeType();
      loanOrigSource.setValue(field);
      
      loanMtgInfo.setLnOrigSrcCode(loanOrigSource);
    }
    
    // Anti-Pred. Category
    //
    field = (String)fields.get("ANTIPRD");
    if (field != null)
    {
      PredatoryLnCodeType antiPredCode = new PredatoryLnCodeType();
      antiPredCode.setValue(field);
      
      loanMtgInfo.setPredatoryLnCode(antiPredCode);
    }
    
    // MH-Prior Occupancy Status
    //
    field = (String)fields.get("MHPROC");
    if (field != null)
    {
      MHOccupCodeType mhOccup = new MHOccupCodeType();
      mhOccup.setValue(field);
      
      loanMtgInfo.setMHOccupCode(mhOccup);
    }
    
    // MH-# of Units
    //
    field = (String)fields.get("MHUNITS");
    if (field != null)
    {
      MHNumUnitType mhNumUnits = new MHNumUnitType();
      mhNumUnits.setValue(field);
      
      loanMtgInfo.setMHNumUnit(mhNumUnits);
    }
    
    // MH-Loan To Invoice
    //
    field = (String)fields.get("MHLTI");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      MHPriceToOrigPctType mhLTI = new MHPriceToOrigPctType();
      mhLTI.setValue(bd);
      
      loanMtgInfo.setMHPriceToOrigPct(mhLTI);
    }
    
    // MH-Year Built
    //
    field = (String)fields.get("MHYear");
    if (field != null)
    {
      MHYrBuiltType year = new MHYrBuiltType();
      year.setValue(Integer.parseInt(field));
      
      loanMtgInfo.setMHYrBuilt(year);
    }
    
    // Sales Associate
    //
    field = (String)fields.get("SALESAC");
    if (field != null)
    {
      SalesPersonType salesPerson = new SalesPersonType();
      salesPerson.setValue(field);
      
      loanInfo.setSalesPerson(salesPerson);
    }
    
    // Accrue Odd Days at 365 ibase
    //
    field = (String)fields.get("ODIBAS");
    if (field != null)
    {
      OddDaysIntBasisType oddDays = new OddDaysIntBasisType();
      oddDays.setValue(field);
      
      loanInfo.setOddDaysIntBasis(oddDays);
    }
    
    // Yearly Fee Calc Code
    // Not in jXchange
    
    List<LnFeeInfoRecCType> loanFeeList = loanFeeArray.getLnFeeInfoRecs();
    loanFeeList.add(loanFeeInfo);
    
    // LOC Fee Calc Code
    //
    field = (String)fields.get("LOCCALC");
    if (field != null)
    {
      LnFeeCodeType feeCode = new LnFeeCodeType();
      feeCode.setValue(field);
      
      loanFeeInfo.setLnFeeCode(feeCode);
    }
    
    // LOC Fee Frequency
    //
    field = (String)fields.get("LOCFREQ");
    if (field != null)
    {
      LnFeeFreqType loanFreq = new LnFeeFreqType();
      loanFreq.setValue(Integer.parseInt(field));
      
      loanFeeInfo.setLnFeeFreq(loanFreq);
    }
    
    // LOC Fee Freq Code
    //
    field = (String)fields.get("LOCFRCD");
    if (field != null)
    {
      LnFeeFreqUnitsType loanFreqUnits = new LnFeeFreqUnitsType();
      loanFreqUnits.setValue(field);
      
      loanFeeInfo.setLnFeeFreqUnits(loanFreqUnits);
    }
    
    // LOC Fee Date
    //
    field = (String)fields.get("LOCFDT7");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      LnFeeAssmntDtType feeDate = new LnFeeAssmntDtType();
      feeDate.setValue(xCal);
      
      loanFeeInfo.setLnFeeAssmntDt(feeDate);
    }
    
    // Penalty Rate #
    //
    field = (String)fields.get("PENRAT#");
    if (field != null)
    {
      PenAnnPctIdxNumType penaltyRateNum = new PenAnnPctIdxNumType();
      penaltyRateNum.setValue(Integer.parseInt(field));
      
      loanRateInfo.setPenAnnPctIdxNum(penaltyRateNum);
    }
    
    // Penalty Rate
    //
    field = (String)fields.get("PENRATE");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      PenAnnPctRateType penaltyRate = new PenAnnPctRateType();
      penaltyRate.setValue(bd);
      
      loanRateInfo.setPenAnnPctRate(penaltyRate);
    }
    
    // Days Past Due To Send Penalty Rate Notice
    //
    field = (String)fields.get("PENPDAYS");
    if (field != null)
    {
      PenNotDaysType noticeDays = new PenNotDaysType();
      noticeDays.setValue(Integer.parseInt(field));
      
      loanRateInfo.setPenNotDays(noticeDays);
    }
    
    // Days After Notice Penalty Rate Begins
    //
    field = (String)fields.get("PENAFTNT");
    if (field != null)
    {
      PenEffDaysType penaltyEffectiveDays = new PenEffDaysType();
      penaltyEffectiveDays.setValue(Integer.parseInt(field));
      
      loanRateInfo.setPenEffDays(penaltyEffectiveDays);
    }
    
    // Penalty APR Review Term
    //
    field = (String)fields.get("PENRVTM");
    if (field != null)
    {
      PenRevTermType penaltyReviewTerm = new PenRevTermType();
      penaltyReviewTerm.setValue(Integer.parseInt(field));
      
      loanRateInfo.setPenRevTerm(penaltyReviewTerm);
    }
    
    // Penalty APR Review Term Code
    //
    field = (String)fields.get("PENRVTMC");
    if (field != null)
    {
      PenRevTermUnitsType penaltyReviewTermUnits = new PenRevTermUnitsType();
      penaltyReviewTermUnits.setValue(field);
      
      loanRateInfo.setPenRevTermUnits(penaltyReviewTermUnits);
    }
    
    // Part Rate Variance
    // Not in jXchange
    
    // Part Rate Variance Code
    // Not in jXchange
    
    // Specialty Lending
    // Not in jXchange
    
    // Loan Originator ID
    // Not in jXchange
    
    // Loan Origination Company ID
    // Not in jXchange
    
    // Appraiser State License #
    // Not in jXchange
    
    // Supervisor Appraiser State License #
    // Not in jXchange
    
    // Appraisal Document File
    // Not in jXchange    

    
    // Set loan info sub-types.
    //
    loanInfo.setTerm(loanTerm);
    
    // Set loan regulation reporting sub-types.
    //
    loanRegRptInfo.setCRARec(craRec);
    

    //general.errLog( "START SIC CODES", "JXC.log" );
    // Set loan special information codes
    //
    List<UserDefInfoCType> userDefInfoList = userDefInfoArray.getUserDefInfos();    
    
    // load special information code array.
    //
    VectorX[] usrDefTransactions = CONFIG.getSectionPropertyKeyValues("LNPLSC");
    //general.errLog( "usrDefTransactions: "+usrDefTransactions, "JXC.log" );
    if (usrDefTransactions != null)
    {
      VectorX transactions = usrDefTransactions[0];
      VectorX rules = usrDefTransactions[1];

      //general.errLog( "transactions: "+transactions, "JXC.log" );
      //general.errLog( "rules: "+rules, "JXC.log" );

      for (int i = 0, c = transactions.size(); i < c; ++i)
      {
        String code = (String)transactions.get(i);
        //general.errLog( "code: "+code, "JXC.log" );
        
        String rule = (String)rules.get(i);
        //general.errLog( "rule 1: "+rule, "JXC.log" );
        
        rule = StringSupport.substituteTags(rule, fields);
        //general.errLog( "rule 2: "+rule, "JXC.log" );

        rule = CmdEvaluator.evaluate(rule);
        //general.errLog( "rule 3: "+rule, "JXC.log" );
        
        
        UserDefInfoCType info = new UserDefInfoCType();    
        
        // LNSICD
        UserDefCodeType defCode = new UserDefCodeType();
        defCode.setValue(rule);
        info.setUserDefCode(defCode);

        // LNSICV
        UserDefTxtType defTxt = new UserDefTxtType();
        defTxt.setValue(code);
        info.setUserDefTxt(defTxt);
                
        userDefInfoList.add(info);        
      }
    }
    
    //general.errLog( "userDefInfoList: "+userDefInfoList, "JXC.log" );
    
    if(userDefInfoList != null && ! userDefInfoList.isEmpty() )
    {
    	loanAccountInfo.setUserDefInfoArray(userDefInfoArray);
    }       
    
    // Set the main sub-types of the LnAdd class.
    //
    lnAdd.setLnInfoRec(loanInfo);
    lnAdd.setLnAcctInfo(loanAccountInfo);
    lnAdd.setLnDlrInfo(loanDealerInfo);
    lnAdd.setLnBalDtInfo(loanBalDtInfo);
    lnAdd.setLnRealEstateInfo(loanREInfo);
    lnAdd.setLnPmtInfo(loanPmtInfo);
    lnAdd.setLnRateInfo(loanRateInfo);
    lnAdd.setLnRegRptInfo(loanRegRptInfo);
    lnAdd.setLnMtgInfo(loanMtgInfo);


    loanAccount.setAccountId( accountID );
    loanAccount.setLnAdd( lnAdd );

    // Set the Error Override Array.
    //    
    List<String> overrideList = CONFIG.getSectionElements("LoanAdd Override");
    if (overrideList != null)
    {
      // Set the Error Override Array.
      //
      ErrOvrRdInfoArrayAType errOvrRdArray = new ErrOvrRdInfoArrayAType();
      List<ErrOvrRdCType> errOvrRdList = errOvrRdArray.getErrOvrRds();
  
      for (String overrideCode : overrideList)
      {
        // Set the Error Override sub-types.
        //
        ErrOvrRdCType errOvrRdDetail = new ErrOvrRdCType();
        errOvrRdDetail.setErrCode(overrideCode);
        errOvrRdList.add( errOvrRdDetail );
      }
          
      loanAccount.setErrOvrRdInfoArray( errOvrRdArray );
    }

    //general.errLog( "END assembleLoanAccountAdd(String username, Map fields)", "JXC.log" );

    return loanAccount;
  }
  
  
  /**
   * assembleCustomerMessageAdd
   * 
   * This message is used when collateral information is put in the Customer or Account
   * level messages.  Any other information pertinent to the loan may also be added here.
   * 
   * @param fields
   * @return CustMsgAdd
   * @throws DatatypeConfigurationException
   */
  private CustMsgAdd assembleCustomerMessageAdd(String username, Map fields)
  throws DatatypeConfigurationException
  {
    CustMsgAdd custMsg = new CustMsgAdd();

    // Set the message request header.
    //
    MsgRqHdrCType msgRq = new MsgRqHdrCType();
    msgRq.setJXchangeHdr(generateJXChangeHeader(username));
    custMsg.setMsgRqHdr(msgRq);
    
    // Create the message sub-types.
    //
    AccountIdCType accountID = new AccountIdCType();
    CustMsgInfoRecCType custMsgInfo = new CustMsgInfoRecCType();
    
    
    // Account Type
    //
    String field = (String)fields.get("CFATYP");
    if (field != null)
    {
      AcctTypeType accountType = new AcctTypeType();
      accountType.setValue(field);
      
      accountID.setAcctType(accountType);
    }
    
    // Account Number
    //
    field = (String)fields.get("CFACC#");
    if (field != null)
    {
      AcctIdType accountNum = new AcctIdType();
      accountNum.setValue(field);
      
      accountID.setAcctId(accountNum);
    }
    
    // Message Type
    //
    field = (String)fields.get("CFCOLM");
    if (field != null)
    {
//custMsg.setMsgType(field);

      // need a MsgTypeType
      MsgTypeType msgTypeType = new MsgTypeType();
      msgTypeType.setValue( field );
      custMsg.setMsgType( msgTypeType );
    }
    
    // Message Text
    //
    field = (String)fields.get("CFMSG");
    if (field != null)
    {
      MsgType message = new MsgType();
      message.setValue(field);
      
      custMsgInfo.setMsg(message);
    }
    
    // CIF #
    //
    field = (String)fields.get("CFCIF#");
    if (field != null)
    {
      CustIdType custID = new CustIdType();
      custID.setValue(field);
      
      custMsg.setCustId(custID);
    }
    
    // Expiration Date
    //
    field = (String)fields.get("CFEXPD");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(DatatypeFactory.newInstance(), field);
      MsgExpDtType expirationDate = new MsgExpDtType();
      expirationDate.setValue(xCal);
      
      custMsgInfo.setMsgExpDt(expirationDate);
    }
    
    // Officer Code
    //
    field = (String)fields.get("CFAOFF");
    if (field != null)
    {
      OffInfoArrayAType officerCodeArray = new OffInfoArrayAType();
      List<OffInfoRecCType> officerCodeList = officerCodeArray.getOffInfoRecs();
      
      OffCodeType officerCode = new OffCodeType();
      officerCode.setValue(field);
      
      OffInfoRecCType officerCodeRec = new OffInfoRecCType();
      officerCodeRec.setOffCode(officerCode);
      officerCodeList.add(officerCodeRec);
      
      custMsgInfo.setOffInfoArray(officerCodeArray);
    }
    
    // Message User Code
    //
    field = (String)fields.get("CFMUIC");
    if (field != null)
    {
      UserDefInfoArrayAType userDefInfoArray = new UserDefInfoArrayAType();
      List<UserDefInfoCType> userDefInfoList = userDefInfoArray.getUserDefInfos();
      
      UserDefCodeType userDefCode = new UserDefCodeType();
      userDefCode.setValue(field);
      
      UserDefInfoCType userDefInfoRec = new UserDefInfoCType();
      userDefInfoRec.setUserDefCode(userDefCode);
      userDefInfoList.add(userDefInfoRec);
      
      custMsgInfo.setUserDefInfoArray(userDefInfoArray);
    }    
    
    // Set the CustMsg sub-types.
    //
    custMsg.setAccountId(accountID);
    custMsg.setCustMsgInfoRec(custMsgInfo);
    
    return custMsg;
  }
  
  
  /**
   * assembleEscrowAdd
   * 
   * This message is used for escrow and insurance information.  If you have either
   * of these one or more of the following records are required.
   * 
   * @param fields
   * @return
   */
  private EscrwAdd assembleEscrowAdd(String username, Map fields)
  throws DatatypeConfigurationException
  {
    //general.errLog( "START assembleEscrowAdd(String username, Map fields)", "JXC.log" );
    //general.errLog( "Map fields: "+fields, "JXC.log" );

    EscrwAdd escrow = new EscrwAdd();
    
    // Set the message request header.
    //
    MsgRqHdrCType msgRq = new MsgRqHdrCType();
    msgRq.setJXchangeHdr(generateJXChangeHeader(username));
    escrow.setMsgRqHdr(msgRq);

    // Create the message sub-types.
    //
    AccountIdCType accountID = new AccountIdCType();
    EscrwInfoRecCType escrowInfo = new EscrwInfoRecCType();
    EscrwAnlysInfoRecCType escrowAnalysisInfo = new EscrwAnlysInfoRecCType();
    FldInsurInfoRecCType floodInsInfo = new FldInsurInfoRecCType();
    EscrwPmtBalInfoRecCType escrowPmtBalInfo = new EscrwPmtBalInfoRecCType();

    // Create the array types
    //
    FldZoneIdArrayAType floodZoneArray = new FldZoneIdArrayAType();
    EscrwPmtBalArrayAType escrowPmtBalArray = new EscrwPmtBalArrayAType();
    EscrwAnlysArrayAType escrowAnalysisArray = new EscrwAnlysArrayAType();
    
    // Escrow Analysis Info
    //
    EscrwAnlysInfoCType escrowAnalysis1 = new EscrwAnlysInfoCType();
    EscrwAnlysInfoCType escrowAnalysis2 = new EscrwAnlysInfoCType();
    EscrwAnlysInfoCType escrowAnalysis3 = new EscrwAnlysInfoCType();
    EscrwAnlysInfoCType escrowAnalysis4 = new EscrwAnlysInfoCType();
    EscrwAnlysInfoCType escrowAnalysis5 = new EscrwAnlysInfoCType();
    
    // Data Type Factory for XML Gregorian Calendar.
    //
    DatatypeFactory dataTypeFactory = DatatypeFactory.newInstance();


    // Account #
    //
    String field = (String)fields.get("EACCTN");
    //general.errLog( "EACCTN: "+field, "JXC.log" );
    if (field != null)
    {
      AcctIdType accountNum = new AcctIdType();
      accountNum.setValue(field);
      
      accountID.setAcctId(accountNum);
    }
    
    // Account Type
    //
    field = (String)fields.get("EACTYP");
    //general.errLog( "EACTYP: "+field, "JXC.log" );
    if (field != null)
    {
      AcctTypeType accountType = new AcctTypeType();
      accountType.setValue(field);
      
      accountID.setAcctType(accountType);
    }
    
    // Escrow Type
    //
    field = (String)fields.get("ETYPE");
    //general.errLog( "ETYPE: "+field, "JXC.log" );
    if (field != null)
    {
      escrow.setEscrwTypeCode(field);
    }
    
    // Tracking Only Flag
    //
    field = (String)fields.get("ETRACK");
    //general.errLog( "ETRACK: "+field, "JXC.log" );
    if (field != null)
    {
      EscrwStatType tracking = new EscrwStatType();
      tracking.setValue(field);
      
      escrowInfo.setEscrwStat(tracking);
    }
    
    // Policy #
    //
    field = (String)fields.get("EPLCY#");
    if (field != null)
    {
      InsurPlcyIdType policyNum = new InsurPlcyIdType();
      policyNum.setValue(field);
      
      escrowInfo.setInsurPlcyId(policyNum);
    }
    
    // Policy Amount
    //
    field = (String)fields.get("EPLCY$");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      InsurPlcyAmtType policyAmt = new InsurPlcyAmtType();
      policyAmt.setValue(bd);
      
      escrowInfo.setInsurPlcyAmt(policyAmt);
    }
    
    // Insurance Premium
    //
    field = (String)fields.get("EPREM");
    //general.errLog( "EPREM: "+field, "JXC.log" );

    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      InsurPlcyPremiumType insPremium = new InsurPlcyPremiumType();
      insPremium.setValue(bd);
      
      escrowInfo.setInsurPlcyPremium(insPremium);
    }
    
    // Policy Term
    //
    field = (String)fields.get("EPLTRM");
    //general.errLog( "EPLTRM: "+field, "JXC.log" );
    if (field != null)
    {
      InsurPlcyTermType policyTerm = new InsurPlcyTermType();
      policyTerm.setValue(Integer.parseInt(field));
      
      escrowInfo.setInsurPlcyTerm(policyTerm);
    }
    
    // Policy Term Code
    //
    field = (String)fields.get("EPLTCD");
    //general.errLog( "EPLTCD: "+field, "JXC.log" );
    if (field != null)
    {
      InsurPlcyTermUnitType termCode = new InsurPlcyTermUnitType();
      termCode.setValue(field);
      
      escrowInfo.setInsurPlcyTermUnit(termCode);
    }
    
    // Policy Origination Date
    //
    field = (String)fields.get("EPLOD7");
    //general.errLog( "EPLOD7: "+field, "JXC.log" );
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      //general.errLog( "xCal: "+xCal, "JXC.log" );
      InsurPlcyOrigDtType policyOrigDate = new InsurPlcyOrigDtType();
      policyOrigDate.setValue(xCal);
      
      escrowInfo.setInsurPlcyOrigDt(policyOrigDate);
    }
    
    // Policy Expiration Date
    //
    field = (String)fields.get("EPLED7");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      InsurPlcyExpDtType policyExpDate = new InsurPlcyExpDtType();
      policyExpDate.setValue(xCal);
      
      escrowInfo.setInsurPlcyExpDt(policyExpDate);
    }
    
    // Distribution Term
    //
    field = (String)fields.get("EDSTRM");
    if (field != null)
    {
      EscrwDistrTermType distributionTerm = new EscrwDistrTermType();
      distributionTerm.setValue(Integer.parseInt(field));
      
      escrowInfo.setEscrwDistrTerm(distributionTerm);
    }
    
    // Distribution Term Code
    //
    field = (String)fields.get("EDSTCD");
    if (field != null)
    {
      EscrwDistrTermUnitType distributionTermCode = new EscrwDistrTermUnitType();
      distributionTermCode.setValue(field);
      
      escrowInfo.setEscrwDistrTermUnit(distributionTermCode);
    }
    
    // Next Distribution Date
    //
    field = (String)fields.get("ENDSD7");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      EscrwDistrDtType nextDistDate = new EscrwDistrDtType();
      nextDistDate.setValue(xCal);
      
      escrowInfo.setEscrwDistrDt(nextDistDate);
    }
    
    // Next Distribution Day
    //
    field = (String)fields.get("ENDSDY");
    if (field != null)
    {
      EscrwDistrDOMType nextDistDOM = new EscrwDistrDOMType();
      nextDistDOM.setValue(Integer.parseInt(field));
      
      escrowInfo.setEscrwDistrDOM(nextDistDOM);
    }
    
    // Next Distribution Amount
    //
    field = (String)fields.get("ENDSAM");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      EscrwDistrAmtType nextDistAmount = new EscrwDistrAmtType();
      nextDistAmount.setValue(bd);
      
      escrowInfo.setEscrwDistrAmt(nextDistAmount);
    }
    
    // Company Dist Location
    //
    field = (String)fields.get("ECOLOC");
    if (field != null)
    {
      EscrwPmtCompCodeType paymentCompanyCode = new EscrwPmtCompCodeType();
      paymentCompanyCode.setValue(field);
      
      escrowInfo.setEscrwPmtCompCode(paymentCompanyCode);
    }
    
    // Agent Dist Location
    //
    field = (String)fields.get("EAGLOC");
    if (field != null)
    {
      EscrwPmtAgentCodeType paymentAgentCode = new EscrwPmtAgentCodeType();
      paymentAgentCode.setValue(field);
      
      escrowInfo.setEscrwPmtAgentCode(paymentAgentCode);
    }
    
    // Payee Code
    //
    field = (String)fields.get("EPAYEE");
    if (field != null)
    {
      EscrwPayeeCodeType payeeCode = new EscrwPayeeCodeType();
      payeeCode.setValue(field);
      
      escrowInfo.setEscrwPayeeCode(payeeCode);
    }
    
    // Tax Reference #
    //
    field = (String)fields.get("ETAXRF");
    if (field != null)
    {
      EscrwTaxRefIdType taxRefID = new EscrwTaxRefIdType();
      taxRefID.setValue(field);
      
      escrowInfo.setEscrwTaxRefId(taxRefID);
    }
    
    // Parcel #
    //
    field = (String)fields.get("EPARCL");
    if (field != null)
    {
      PropParcelIdType parcelNum = new PropParcelIdType();
      parcelNum.setValue(field);
      
      escrowInfo.setPropParcelId(parcelNum);
    }
    
    // Force Placed Insurance
    //
    field = (String)fields.get("EFRCPL");
    //general.errLog( "EFRCPL: "+field, "JXC.log" );
    if (field != null)
    {
      ForcedPlaceInsurType forcePlacedIns = new ForcedPlaceInsurType();
      forcePlacedIns.setValue(field);
      
      escrowInfo.setForcedPlaceInsur(forcePlacedIns);
    }
    
    // Legal Description
    //
    field = (String)fields.get("ELEGAL");
    if (field != null)
    {
      PropLegalInfoType legalInfo = new PropLegalInfoType();
      legalInfo.setValue(field);
      
      escrowInfo.setPropLegalInfo(legalInfo);
    }
    
    // PMI Termination Date
    //
    field = (String)fields.get("EMITD7");
    //general.errLog( "EMITD7: "+field, "JXC.log" );
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      PMIExpDtType pmiTermDate = new PMIExpDtType();
      pmiTermDate.setValue(xCal);
      
      escrowInfo.setPMIExpDt(pmiTermDate);
    }
    
    // PMI Cancel Code
    //
    field = (String)fields.get("ECANCL");
    //general.errLog( "ECANCL: "+field, "JXC.log" );    
    if (field != null)
    {
      PMICancelCodeType pmiCancelCode = new PMICancelCodeType();
      pmiCancelCode.setValue(field);
      
      escrowInfo.setPMICancelCode(pmiCancelCode);
    }
    
    // PMI Cancel Notice Printed
    //
    field = (String)fields.get("ENTPRT");
    if (field != null)
    {
      PMICancelNotCodeType pmiCancelNotice = new PMICancelNotCodeType();
      pmiCancelNotice.setValue(field);
      
      escrowInfo.setPMICancelNotCode(pmiCancelNotice);
    }
    
    // Next Distribution Rate
    //
    field = (String)fields.get("ENDSRT");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      EscrwDistrRateType escrowDistRate = new EscrwDistrRateType();
      escrowDistRate.setValue(bd);
      
      escrowInfo.setEscrwDistrRate(escrowDistRate);
    }
    
    // Next Distribution Tax Amount
    //
    field = (String)fields.get("ENTXAM");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      EscrwDistrTaxAmtType escrowTaxAmt = new EscrwDistrTaxAmtType();
      escrowTaxAmt.setValue(bd);
      
      escrowInfo.setEscrwDistrTaxAmt(escrowTaxAmt);
    }
    
    // Next Distribution Tax Rate
    //
    field = (String)fields.get("ENTXRT");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      EscrwDistrTaxRateType escrowTaxRate = new EscrwDistrTaxRateType();
      escrowTaxRate.setValue(bd);
      
      escrowInfo.setEscrwDistrTaxRate(escrowTaxRate);
    }
    
    // Last Distribution Rate
    //
    field = (String)fields.get("ELDSRT");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      EscrwLastDistrRateType escrowLastDistRate = new EscrwLastDistrRateType();
      escrowLastDistRate.setValue(bd);
      
      escrowInfo.setEscrwLastDistrRate(escrowLastDistRate);
    }
    
    // Last Distribution Tax Amount
    //
    field = (String)fields.get("ELTXAM");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      EscrwLastDistrTaxAmtType lastDistTaxAmount = new EscrwLastDistrTaxAmtType();
      lastDistTaxAmount.setValue(bd);
      
      escrowInfo.setEscrwLastDistrTaxAmt(lastDistTaxAmount);
    }
    
    // Last Distribution Tax Rate
    //
    field = (String)fields.get("ELTXRT");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      EscrwLastDistrTaxRateType lastDistTaxRate = new EscrwLastDistrTaxRateType();
      lastDistTaxRate.setValue(bd);
      
      escrowInfo.setEscrwLastDistrTaxRate(lastDistTaxRate);
    }
    
    // Premium Anniversary Date
    //
    field = (String)fields.get("EPRAN7");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      InsurPlcyRenDtType anniversaryDate = new InsurPlcyRenDtType();
      anniversaryDate.setValue(xCal);
      
      escrowInfo.setInsurPlcyRenDt(anniversaryDate);
    }
    
    // Termination Date
    // Already filed in above
    
    // Community Name
    //
    field = (String)fields.get("ECOMN");
    if (field != null)
    {
      CmntyNameType communityName = new CmntyNameType();
      communityName.setValue(field);
      
      floodInsInfo.setCmntyName(communityName);
    }
    
    // Map/Panel Number
    //
    field = (String)fields.get("EMAP#");
    if (field != null)
    {
      FldZoneMapIdType mapPanelNum = new FldZoneMapIdType();
      mapPanelNum.setValue(field);
      
      floodInsInfo.setFldZoneMapId(mapPanelNum);
    }
    
    // Letter of Mapped Revision 7
    //
    field = (String)fields.get("ELOMA7");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      FldZoneMapRevDtType letterRev7 = new FldZoneMapRevDtType();
      letterRev7.setValue(xCal);
      
      floodInsInfo.setFldZoneMapRevDt(letterRev7);
    }
    
    // Insurance Type
    //
    field = (String)fields.get("EINSTY");
    //general.errLog( "EINSTY: "+field, "JXC.log" );
    if (field != null)
    {
      FldInsurCodeType floodInsCode = new FldInsurCodeType();
      floodInsCode.setValue(field);
      
      floodInsInfo.setFldInsurCode(floodInsCode);
    }
    
    // Panel Date
    //
    field = (String)fields.get("EPANL7");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      FldZonePanelDtType panelDate = new FldZonePanelDtType();
      panelDate.setValue(xCal);
      
      floodInsInfo.setFldZonePanelDt(panelDate);
    }    
    
    // Use Cushion in Analysis
    //
    field = (String)fields.get("EUCSHIN");
    if (field != null)
    {
      EscrwAnlysCusCodeType useCushion = new EscrwAnlysCusCodeType();
      useCushion.setValue(field);
      
      escrowAnalysisInfo.setEscrwAnlysCusCode(useCushion);
    }
    
    // Flood Zone 1
    //    
    List<FldZoneIdInfoCType> floodZoneList = floodZoneArray.getFldZoneIdInfos();
    
    field = (String)fields.get("EFLDZ1");
    if (field != null)
    {
      FldZoneIdType floodZone1 = new FldZoneIdType();
      floodZone1.setValue(field);
      
      FldZoneIdInfoCType floodZoneId = new FldZoneIdInfoCType();
      floodZoneId.setFldZoneId(floodZone1);
      
      floodZoneList.add(floodZoneId);
    }
    
    // Flood Zone 2
    //
    field = (String)fields.get("EFLDZ2");
    if (field != null)
    {
      FldZoneIdType floodZone2 = new FldZoneIdType();
      floodZone2.setValue(field);
      
      FldZoneIdInfoCType floodZoneId = new FldZoneIdInfoCType();
      floodZoneId.setFldZoneId(floodZone2);
      
      floodZoneList.add(floodZoneId);
    }

    floodInsInfo.setFldZoneIdArray(floodZoneArray);
    
    // Coastal Bara Resource Area
    //
    field = (String)fields.get("ECBRA7");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      CoastalBaraDtType coastalBara = new CoastalBaraDtType();
      coastalBara.setValue(xCal);
      
      floodInsInfo.setCoastalBaraDt(coastalBara);
    }
    
    // Community #
    //
    field = (String)fields.get("ECOM#");
    if (field != null)
    {
      CmntyIdType communityNum = new CmntyIdType();
      communityNum.setValue(field);
      
      floodInsInfo.setCmntyId(communityNum);
    }
    
    // Map/Index Date
    //
    field = (String)fields.get("EMAPD7");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      FldZoneMapDtType mapDate = new FldZoneMapDtType();
      mapDate.setValue(xCal);
      
      floodInsInfo.setFldZoneMapDt(mapDate);
    }
    
    // Determination Date
    //
    field = (String)fields.get("EDETD7");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      FldZoneDtrDtType determinationDate = new FldZoneDtrDtType();
      determinationDate.setValue(xCal);
      
      floodInsInfo.setFldZoneDtrDt(determinationDate);
    }
    
    // Community Program Date
    //
    field = (String)fields.get("ECOMD7");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      CmntyPgmDtType commPgmDate = new CmntyPgmDtType();
      commPgmDate.setValue(xCal);
      
      floodInsInfo.setCmntyPgmDt(commPgmDate);
    }
    
    // Compliance Company ID
    //
    field = (String)fields.get("ECPLID");
    if (field != null)
    {
      ComplCompIdType complianceCompanyID = new ComplCompIdType();
      complianceCompanyID.setValue(field);
      
      floodInsInfo.setComplCompId(complianceCompanyID);
    }
    
    // Determination Company ID
    //
    field = (String)fields.get("EDETCID");
    if (field != null)
    {
      FldZoneDtrCompIdType determinationCompID = new FldZoneDtrCompIdType();
      determinationCompID.setValue(field);
      
      floodInsInfo.setFldZoneDtrCompId(determinationCompID);
    }
    
    // Determination #
    //
    field = (String)fields.get("EDET#");
    if (field != null)
    {
      FldZoneDtrIdType determinationID = new FldZoneDtrIdType();
      determinationID.setValue(field);
      
      floodInsInfo.setFldZoneDtrId(determinationID);
    }
    
    // Determination Contract
    //
    field = (String)fields.get("EDETCON");
    if (field != null)
    {
      FldZoneDtrContractCodeType determinationContract = new FldZoneDtrContractCodeType();
      determinationContract.setValue(field);
      
      floodInsInfo.setFldZoneDtrContractCode(determinationContract);
    }
    
        
    // Escrow Rate #1
    //
    List<EscrwPmtBalInfoCType> rateList = escrowPmtBalArray.getEscrwPmtBalInfos();
    
    field = (String)fields.get("ERT1");
    if (field != null)
    {
      EscrwRateIdxType rateIndex = new EscrwRateIdxType();
      rateIndex.setValue(Integer.parseInt(field));
      
      EscrwPmtBalInfoCType escrowPmtBal = new EscrwPmtBalInfoCType();
      escrowPmtBal.setEscrwRateIdx(rateIndex);
      
      rateList.add(escrowPmtBal);
    }
    
    // Escrow Rate #2
    //
    field = (String)fields.get("ERT2");
    if (field != null)
    {
      EscrwRateIdxType rateIndex = new EscrwRateIdxType();
      rateIndex.setValue(Integer.parseInt(field));
      
      EscrwPmtBalInfoCType escrowPmtBal = new EscrwPmtBalInfoCType();
      escrowPmtBal.setEscrwRateIdx(rateIndex);
      
      rateList.add(escrowPmtBal);
    }

    // Escrow Rate #3
    //
    field = (String)fields.get("ERT3");
    if (field != null)
    {
      EscrwRateIdxType rateIndex = new EscrwRateIdxType();
      rateIndex.setValue(Integer.parseInt(field));
      
      EscrwPmtBalInfoCType escrowPmtBal = new EscrwPmtBalInfoCType();
      escrowPmtBal.setEscrwRateIdx(rateIndex);
      
      rateList.add(escrowPmtBal);
    }

    // Escrow Rate #4
    //
    field = (String)fields.get("ERT4");
    if (field != null)
    {
      EscrwRateIdxType rateIndex = new EscrwRateIdxType();
      rateIndex.setValue(Integer.parseInt(field));
      
      EscrwPmtBalInfoCType escrowPmtBal = new EscrwPmtBalInfoCType();
      escrowPmtBal.setEscrwRateIdx(rateIndex);
      
      rateList.add(escrowPmtBal);
    }

    // Escrow Rate #5
    //
    field = (String)fields.get("ERT5");
    if (field != null)
    {
      EscrwRateIdxType rateIndex = new EscrwRateIdxType();
      rateIndex.setValue(Integer.parseInt(field));
      
      EscrwPmtBalInfoCType escrowPmtBal = new EscrwPmtBalInfoCType();
      escrowPmtBal.setEscrwRateIdx(rateIndex);
      
      rateList.add(escrowPmtBal);
    }
    
    // Escrow Rate #6
    //
    field = (String)fields.get("ERT6");
    if (field != null)
    {
      EscrwRateIdxType rateIndex = new EscrwRateIdxType();
      rateIndex.setValue(Integer.parseInt(field));
      
      EscrwPmtBalInfoCType escrowPmtBal = new EscrwPmtBalInfoCType();
      escrowPmtBal.setEscrwRateIdx(rateIndex);
      
      rateList.add(escrowPmtBal);
    }

    // Escrow Rate #7
    //
    field = (String)fields.get("ERT7");
    if (field != null)
    {
      EscrwRateIdxType rateIndex = new EscrwRateIdxType();
      rateIndex.setValue(Integer.parseInt(field));
      
      EscrwPmtBalInfoCType escrowPmtBal = new EscrwPmtBalInfoCType();
      escrowPmtBal.setEscrwRateIdx(rateIndex);
      
      rateList.add(escrowPmtBal);
    }

    // Escrow Rate #8
    //
    field = (String)fields.get("ERT8");
    if (field != null)
    {
      EscrwRateIdxType rateIndex = new EscrwRateIdxType();
      rateIndex.setValue(Integer.parseInt(field));
      
      EscrwPmtBalInfoCType escrowPmtBal = new EscrwPmtBalInfoCType();
      escrowPmtBal.setEscrwRateIdx(rateIndex);
      
      rateList.add(escrowPmtBal);
    }

    // Escrow Rate #9
    //
    field = (String)fields.get("ERT9");
    if (field != null)
    {
      EscrwRateIdxType rateIndex = new EscrwRateIdxType();
      rateIndex.setValue(Integer.parseInt(field));
      
      EscrwPmtBalInfoCType escrowPmtBal = new EscrwPmtBalInfoCType();
      escrowPmtBal.setEscrwRateIdx(rateIndex);
      
      rateList.add(escrowPmtBal);
    }
    
    // Escrow Rate #10
    //
    field = (String)fields.get("ERT10");
    if (field != null)
    {
      EscrwRateIdxType rateIndex = new EscrwRateIdxType();
      rateIndex.setValue(Integer.parseInt(field));
      
      EscrwPmtBalInfoCType escrowPmtBal = new EscrwPmtBalInfoCType();
      escrowPmtBal.setEscrwRateIdx(rateIndex);
      
      rateList.add(escrowPmtBal);
    }
    
    escrowPmtBalInfo.setEscrwPmtBalArray(escrowPmtBalArray);
    
    // PMI Notification Printed
    //
    field = (String)fields.get("ENOTPT");
    if (field != null)
    {
      PMILTVNotCodeType pmiNoticePrinted = new PMILTVNotCodeType();
      pmiNoticePrinted.setValue(field);
      
      escrowInfo.setPMILTVNotCode(pmiNoticePrinted);
    }
    
    // Cancellation Date
    //
    field = (String)fields.get("EMICD7");
    //general.errLog( "EMICD7: "+field, "JXC.log" );    
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      PMICancelDtType pmiCancelDate = new PMICancelDtType();
      pmiCancelDate.setValue(xCal);
      
      escrowInfo.setPMICancelDt(pmiCancelDate);
    }
    
    // Fed W/H Code
    // ?? Can't find EscrwFedWith
    field = (String)fields.get("EHCODE");
    if (field != null)
    {
      FedWithCodeType fedWithCode = new FedWithCodeType();
      fedWithCode.setValue(field);      
    }
    
    
    // Federal and State W/H section skipped... can't find jXchange element.
    //
    
    
    // Escrow Shortage < 1 Payment
    //
    field = (String)fields.get("EDSLOP");
    //general.errLog( "EDSLOP: "+field, "JXC.log" );
    if (field != null)
    {
      EscrwShtLTPmtCodeType esPmtCode = new EscrwShtLTPmtCodeType();
      esPmtCode.setValue(field);
      
      escrowAnalysisInfo.setEscrwShtLTPmtCode(esPmtCode);
    }
    
    List<EscrwAnlysInfoCType> escrowAnalysisList = escrowAnalysisArray.getEscrwAnlysInfos();
    escrowAnalysisList.add(escrowAnalysis1);
    escrowAnalysisList.add(escrowAnalysis2);
    escrowAnalysisList.add(escrowAnalysis3);
    escrowAnalysisList.add(escrowAnalysis4);
    escrowAnalysisList.add(escrowAnalysis5);
    escrowAnalysisInfo.setEscrwAnlysArray(escrowAnalysisArray);
    
    // Escrow Shortage < 1 Payment Amount Tier 1
    //
    field = (String)fields.get("EDSLT1");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      EscrwShtLTPmtAmtType esPmtAmt = new EscrwShtLTPmtAmtType();
      esPmtAmt.setValue(bd);      
      
      escrowAnalysis1.setEscrwShtLTPmtAmt(esPmtAmt);      
    }

    // Escrow Shortage < 1 Payment Amount Tier 2
    //
    field = (String)fields.get("EDSLT2");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      EscrwShtLTPmtAmtType esPmtAmt = new EscrwShtLTPmtAmtType();
      esPmtAmt.setValue(bd);      

      escrowAnalysis2.setEscrwShtLTPmtAmt(esPmtAmt);
    }

    // Escrow Shortage < 1 Payment Amount Tier 3
    //
    field = (String)fields.get("EDSLT3");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      EscrwShtLTPmtAmtType esPmtAmt = new EscrwShtLTPmtAmtType();
      esPmtAmt.setValue(bd);      

      escrowAnalysis3.setEscrwShtLTPmtAmt(esPmtAmt);
    }

    // Escrow Shortage < 1 Payment Amount Tier 4
    //
    field = (String)fields.get("EDSLT4");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      EscrwShtLTPmtAmtType esPmtAmt = new EscrwShtLTPmtAmtType();
      esPmtAmt.setValue(bd);      

      escrowAnalysis4.setEscrwShtLTPmtAmt(esPmtAmt);
    }

    // Escrow Shortage < 1 Payment Amount Tier 5
    //
    field = (String)fields.get("EDSLT5");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      EscrwShtLTPmtAmtType esPmtAmt = new EscrwShtLTPmtAmtType();
      esPmtAmt.setValue(bd);      

      escrowAnalysis5.setEscrwShtLTPmtAmt(esPmtAmt);
    }
        
    // Escrow Shortage < 1 Payment Months To Spread Tier 1
    //
    field = (String)fields.get("EDSLM1");
    if (field != null)
    {
      EscrwShtLTPmtTermType esPmtTerm = new EscrwShtLTPmtTermType();
      esPmtTerm.setValue(Integer.parseInt(field));
      
      escrowAnalysis1.setEscrwShtLTPmtTerm(esPmtTerm);
    }

    // Escrow Shortage < 1 Payment Months To Spread Tier 2
    //
    field = (String)fields.get("EDSLM2");
    if (field != null)
    {
      EscrwShtLTPmtTermType esPmtTerm = new EscrwShtLTPmtTermType();
      esPmtTerm.setValue(Integer.parseInt(field));
      
      escrowAnalysis2.setEscrwShtLTPmtTerm(esPmtTerm);
    }

    // Escrow Shortage < 1 Payment Months To Spread Tier 3
    //
    field = (String)fields.get("EDSLM3");
    if (field != null)
    {
      EscrwShtLTPmtTermType esPmtTerm = new EscrwShtLTPmtTermType();
      esPmtTerm.setValue(Integer.parseInt(field));
      
      escrowAnalysis3.setEscrwShtLTPmtTerm(esPmtTerm);
    }

    // Escrow Shortage < 1 Payment Months To Spread Tier 4
    //
    field = (String)fields.get("EDSLM4");
    if (field != null)
    {
      EscrwShtLTPmtTermType esPmtTerm = new EscrwShtLTPmtTermType();
      esPmtTerm.setValue(Integer.parseInt(field));
      
      escrowAnalysis4.setEscrwShtLTPmtTerm(esPmtTerm);
    }

    // Escrow Shortage < 1 Payment Months To Spread Tier 5
    //
    field = (String)fields.get("EDSLM5");
    if (field != null)
    {
      EscrwShtLTPmtTermType esPmtTerm = new EscrwShtLTPmtTermType();
      esPmtTerm.setValue(Integer.parseInt(field));
      
      escrowAnalysis5.setEscrwShtLTPmtTerm(esPmtTerm);
    }
    
    // Escrow Shortage > 1 Payment
    //
    field = (String)fields.get("EDSGOP");
    //general.errLog( "EDSGOP: "+field, "JXC.log" );
    if (field != null)
    {
      EscrwShtGEPmtCodeType esPmtCode = new EscrwShtGEPmtCodeType();
      esPmtCode.setValue(field);
      
      escrowAnalysisInfo.setEscrwShtGEPmtCode(esPmtCode);
    }
    
    // Escrow Shortage > 1 Payment Amount Tier 1
    //
    field = (String)fields.get("EDSGT1");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      EscrwShtGEPmtAmtType esPmtAmt = new EscrwShtGEPmtAmtType();
      esPmtAmt.setValue(bd);
      
      escrowAnalysis1.setEscrwShtGEPmtAmt(esPmtAmt);
    }

    // Escrow Shortage > 1 Payment Amount Tier 2
    //
    field = (String)fields.get("EDSGT2");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      EscrwShtGEPmtAmtType esPmtAmt = new EscrwShtGEPmtAmtType();
      esPmtAmt.setValue(bd);
      
      escrowAnalysis2.setEscrwShtGEPmtAmt(esPmtAmt);
    }
    
    // Escrow Shortage > 1 Payment Amount Tier 3
    //
    field = (String)fields.get("EDSGT3");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      EscrwShtGEPmtAmtType esPmtAmt = new EscrwShtGEPmtAmtType();
      esPmtAmt.setValue(bd);
      
      escrowAnalysis3.setEscrwShtGEPmtAmt(esPmtAmt);
    }

    // Escrow Shortage > 1 Payment Amount Tier 4
    //
    field = (String)fields.get("EDSGT4");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      EscrwShtGEPmtAmtType esPmtAmt = new EscrwShtGEPmtAmtType();
      esPmtAmt.setValue(bd);
      
      escrowAnalysis4.setEscrwShtGEPmtAmt(esPmtAmt);
    }
    
    // Escrow Shortage > 1 Payment Amount Tier 5
    //
    field = (String)fields.get("EDSGT5");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      EscrwShtGEPmtAmtType esPmtAmt = new EscrwShtGEPmtAmtType();
      esPmtAmt.setValue(bd);
      
      escrowAnalysis5.setEscrwShtGEPmtAmt(esPmtAmt);
    }

    // Escrow Shortage > 1 payment Months to Spread Tier 1
    //
    field = (String)fields.get("EDSGM1");
    if (field != null)
    {
      EscrwShtGEPmtTermType esPmtTerm = new EscrwShtGEPmtTermType();
      esPmtTerm.setValue(Integer.parseInt(field));
      
      escrowAnalysis1.setEscrwShtGEPmtTerm(esPmtTerm);
    }

    // Escrow Shortage > 1 payment Months to Spread Tier 2
    //
    field = (String)fields.get("EDSGM2");
    if (field != null)
    {
      EscrwShtGEPmtTermType esPmtTerm = new EscrwShtGEPmtTermType();
      esPmtTerm.setValue(Integer.parseInt(field));
      
      escrowAnalysis2.setEscrwShtGEPmtTerm(esPmtTerm);
    }

    // Escrow Shortage > 1 payment Months to Spread Tier 3
    //
    field = (String)fields.get("EDSGM3");
    if (field != null)
    {
      EscrwShtGEPmtTermType esPmtTerm = new EscrwShtGEPmtTermType();
      esPmtTerm.setValue(Integer.parseInt(field));
      
      escrowAnalysis3.setEscrwShtGEPmtTerm(esPmtTerm);
    }

    // Escrow Shortage > 1 payment Months to Spread Tier 4
    //
    field = (String)fields.get("EDSGM4");
    if (field != null)
    {
      EscrwShtGEPmtTermType esPmtTerm = new EscrwShtGEPmtTermType();
      esPmtTerm.setValue(Integer.parseInt(field));
      
      escrowAnalysis4.setEscrwShtGEPmtTerm(esPmtTerm);
    }
    
    // Escrow Shortage > 1 payment Months to Spread Tier 5
    //
    field = (String)fields.get("EDSGM5");
    if (field != null)
    {
      EscrwShtGEPmtTermType esPmtTerm = new EscrwShtGEPmtTermType();
      esPmtTerm.setValue(Integer.parseInt(field));
      
      escrowAnalysis5.setEscrwShtGEPmtTerm(esPmtTerm);
    }
    
    // Escrow Deficiency < 1 Payment
    //
    field = (String)fields.get("EDDLOP");
    //general.errLog( "EDDLOP: "+field, "JXC.log" );
    if (field != null)
    {
      EscrwDefcLTPmtCodeType edPmtCode = new EscrwDefcLTPmtCodeType();
      edPmtCode.setValue(field);
      
      escrowAnalysisInfo.setEscrwDefcLTPmtCode(edPmtCode);
    }
    
    // Escrow Deficiency < 1 payment Amount Tier 1
    //
    field = (String)fields.get("EDDLT1");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      EscrwDefcLTPmtAmtType edPmtAmt = new EscrwDefcLTPmtAmtType();
      edPmtAmt.setValue(bd);
      
      escrowAnalysis1.setEscrwDefcLTPmtAmt(edPmtAmt);
    }

    // Escrow Deficiency < 1 payment Amount Tier 2
    //
    field = (String)fields.get("EDDLT2");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      EscrwDefcLTPmtAmtType edPmtAmt = new EscrwDefcLTPmtAmtType();
      edPmtAmt.setValue(bd);
      
      escrowAnalysis2.setEscrwDefcLTPmtAmt(edPmtAmt);
    }

    // Escrow Deficiency < 1 payment Amount Tier 3
    //
    field = (String)fields.get("EDDLT3");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      EscrwDefcLTPmtAmtType edPmtAmt = new EscrwDefcLTPmtAmtType();
      edPmtAmt.setValue(bd);
      
      escrowAnalysis3.setEscrwDefcLTPmtAmt(edPmtAmt);
    }

    // Escrow Deficiency < 1 payment Amount Tier 4
    //
    field = (String)fields.get("EDDLT4");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      EscrwDefcLTPmtAmtType edPmtAmt = new EscrwDefcLTPmtAmtType();
      edPmtAmt.setValue(bd);
      
      escrowAnalysis4.setEscrwDefcLTPmtAmt(edPmtAmt);
    }

    // Escrow Deficiency < 1 payment Amount Tier 5
    //
    field = (String)fields.get("EDDLT5");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      EscrwDefcLTPmtAmtType edPmtAmt = new EscrwDefcLTPmtAmtType();
      edPmtAmt.setValue(bd);
      
      escrowAnalysis5.setEscrwDefcLTPmtAmt(edPmtAmt);
    }
    
    // Escrow Deficiency < 1 payment Months to Spread Tier 1
    //
    field = (String)fields.get("EDDLM1");
    if (field != null)
    {
      EscrwDefcLTPmtTermType edTermType = new EscrwDefcLTPmtTermType();
      edTermType.setValue(Integer.parseInt(field));
      
      escrowAnalysis1.setEscrwDefcLTPmtTerm(edTermType);
    }

    // Escrow Deficiency < 1 payment Months to Spread Tier 2
    //
    field = (String)fields.get("EDDLM2");
    if (field != null)
    {
      EscrwDefcLTPmtTermType edTermType = new EscrwDefcLTPmtTermType();
      edTermType.setValue(Integer.parseInt(field));
      
      escrowAnalysis2.setEscrwDefcLTPmtTerm(edTermType);
    }

    // Escrow Deficiency < 1 payment Months to Spread Tier 3
    //
    field = (String)fields.get("EDDLM3");
    if (field != null)
    {
      EscrwDefcLTPmtTermType edTermType = new EscrwDefcLTPmtTermType();
      edTermType.setValue(Integer.parseInt(field));
      
      escrowAnalysis3.setEscrwDefcLTPmtTerm(edTermType);
    }

    // Escrow Deficiency < 1 payment Months to Spread Tier 4
    //
    field = (String)fields.get("EDDLM4");
    if (field != null)
    {
      EscrwDefcLTPmtTermType edTermType = new EscrwDefcLTPmtTermType();
      edTermType.setValue(Integer.parseInt(field));
      
      escrowAnalysis4.setEscrwDefcLTPmtTerm(edTermType);
    }

    // Escrow Deficiency < 1 payment Months to Spread Tier 5
    //
    field = (String)fields.get("EDDLM5");
    if (field != null)
    {
      EscrwDefcLTPmtTermType edTermType = new EscrwDefcLTPmtTermType();
      edTermType.setValue(Integer.parseInt(field));
      
      escrowAnalysis5.setEscrwDefcLTPmtTerm(edTermType);
    }

    // Escrow Deficiency > 1 payment
    //
    field = (String)fields.get("EDDGOP");
    //general.errLog( "EDDGOP: "+field, "JXC.log" );
    if (field != null)
    {
      EscrwDefcGEPmtCodeType edPmtCode = new EscrwDefcGEPmtCodeType();
      edPmtCode.setValue(field);
      
      escrowAnalysisInfo.setEscrwDefcGEPmtCode(edPmtCode);
    }
    
    // Escrow Deficiency > 1 payment Amount Tier 1
    //
    field = (String)fields.get("EDDGT1");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      EscrwDefcGEPmtAmtType edPmtAmt = new EscrwDefcGEPmtAmtType();
      edPmtAmt.setValue(bd);
      
      escrowAnalysis1.setEscrwDefcGEPmtAmt(edPmtAmt);
    }
    
    // Escrow Deficiency > 1 payment Amount Tier 2
    //
    field = (String)fields.get("EDDGT2");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      EscrwDefcGEPmtAmtType edPmtAmt = new EscrwDefcGEPmtAmtType();
      edPmtAmt.setValue(bd);
      
      escrowAnalysis2.setEscrwDefcGEPmtAmt(edPmtAmt);
    }

    // Escrow Deficiency > 1 payment Amount Tier 3
    //
    field = (String)fields.get("EDDGT3");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      EscrwDefcGEPmtAmtType edPmtAmt = new EscrwDefcGEPmtAmtType();
      edPmtAmt.setValue(bd);
      
      escrowAnalysis3.setEscrwDefcGEPmtAmt(edPmtAmt);
    }

    // Escrow Deficiency > 1 payment Amount Tier 4
    //
    field = (String)fields.get("EDDGT4");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      EscrwDefcGEPmtAmtType edPmtAmt = new EscrwDefcGEPmtAmtType();
      edPmtAmt.setValue(bd);
      
      escrowAnalysis4.setEscrwDefcGEPmtAmt(edPmtAmt);
    }

    // Escrow Deficiency > 1 payment Amount Tier 5
    //
    field = (String)fields.get("EDDGT5");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      EscrwDefcGEPmtAmtType edPmtAmt = new EscrwDefcGEPmtAmtType();
      edPmtAmt.setValue(bd);
      
      escrowAnalysis5.setEscrwDefcGEPmtAmt(edPmtAmt);
    }
    
    // Escrow Deficiency > 1 payment Months to Spread Tier 1
    //
    field = (String)fields.get("EDDGM1");
    if (field != null)
    {
      EscrwDefcGEPmtTermType edPmtTerm = new EscrwDefcGEPmtTermType();
      edPmtTerm.setValue(Integer.parseInt(field));
      
      escrowAnalysis1.setEscrwDefcGEPmtTerm(edPmtTerm);
    }

    // Escrow Deficiency > 1 payment Months to Spread Tier 2
    //
    field = (String)fields.get("EDDGM2");
    if (field != null)
    {
      EscrwDefcGEPmtTermType edPmtTerm = new EscrwDefcGEPmtTermType();
      edPmtTerm.setValue(Integer.parseInt(field));
      
      escrowAnalysis2.setEscrwDefcGEPmtTerm(edPmtTerm);
    }

    // Escrow Deficiency > 1 payment Months to Spread Tier 3
    //
    field = (String)fields.get("EDDGM3");
    if (field != null)
    {
      EscrwDefcGEPmtTermType edPmtTerm = new EscrwDefcGEPmtTermType();
      edPmtTerm.setValue(Integer.parseInt(field));
      
      escrowAnalysis3.setEscrwDefcGEPmtTerm(edPmtTerm);
    }

    // Escrow Deficiency > 1 payment Months to Spread Tier 4
    //
    field = (String)fields.get("EDDGM4");
    if (field != null)
    {
      EscrwDefcGEPmtTermType edPmtTerm = new EscrwDefcGEPmtTermType();
      edPmtTerm.setValue(Integer.parseInt(field));
      
      escrowAnalysis4.setEscrwDefcGEPmtTerm(edPmtTerm);
    }

    // Escrow Deficiency > 1 payment Months to Spread Tier 5
    //
    field = (String)fields.get("EDDGM5");
    if (field != null)
    {
      EscrwDefcGEPmtTermType edPmtTerm = new EscrwDefcGEPmtTermType();
      edPmtTerm.setValue(Integer.parseInt(field));
      
      escrowAnalysis5.setEscrwDefcGEPmtTerm(edPmtTerm);
    }
    
    // Escrow Analysis Overage $
    //
    field = (String)fields.get("EDOVRD");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      EscrwPrtChkAmtType escrowPrintCheckAmt = new EscrwPrtChkAmtType();
      escrowPrintCheckAmt.setValue(bd);
      
      escrowAnalysisInfo.setEscrwPrtChkAmt(escrowPrintCheckAmt);
    }
    
    // Escrow Analysis Overage %
    //
    field = (String)fields.get("EDOVRP");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      EscrwPrtChkPctType escrowPrintCheckPct = new EscrwPrtChkPctType();
      escrowPrintCheckPct.setValue(bd);
      
      escrowAnalysisInfo.setEscrwPrtChkPct(escrowPrintCheckPct);
    }
    
    // New Payment Rounding Option
    //
    field = (String)fields.get("EDRNDO");
    if (field != null)
    {
      EscrwRoundMthdType roundingOption = new EscrwRoundMthdType();
      roundingOption.setValue(field);
      
      escrowAnalysisInfo.setEscrwRoundMthd(roundingOption);
    }
    
    // Update Non Accrual Loans
    //
    field = (String)fields.get("EDUPDN");
    //general.errLog( "EDUPDN: "+field, "JXC.log" );
    if (field != null)
    {
      EscrwNonAccrCodeType nonAccrual = new EscrwNonAccrCodeType();
      nonAccrual.setValue(field);
      
      escrowAnalysisInfo.setEscrwNonAccrCode(nonAccrual);
    }

    // Next Analysis Date required field, Not in documentation, 
    //
    field = (String)fields.get("NXTANLYSDT");
    //general.errLog( "ESRNAD: "+field, "JXC.log" );
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      EscrwNxtAnlysDtType nxtAnlysDt = new EscrwNxtAnlysDtType();
      nxtAnlysDt.setValue(xCal);
      
      escrowAnalysisInfo.setEscrwNxtAnlysDt(nxtAnlysDt);
    }
    
    // Print Analysis With ARM Letter
    //
    field = (String)fields.get("EDASTM");
    //general.errLog( "EDASTM: "+field, "JXC.log" );
    if (field != null)
    {
      EscrwARMNotCodeType armLetter = new EscrwARMNotCodeType();
      armLetter.setValue(field);
      
      escrowAnalysisInfo.setEscrwARMNotCode(armLetter);
    }
    
    // Minimum Payment Change
    //
    field = (String)fields.get("EDCHGT");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      EscrwChgPmtAmtType minPmtChange = new EscrwChgPmtAmtType();
      minPmtChange.setValue(bd);
      
      escrowAnalysisInfo.setEscrwChgPmtAmt(minPmtChange);
    }
    
    // Days Till Initial Escrow Statement
    //
    field = (String)fields.get("EDINIT");
    if (field != null)
    {
      EscrwBegStmtTermType term = new EscrwBegStmtTermType();
      term.setValue(Integer.parseInt(field));
      
      escrowAnalysisInfo.setEscrwBegStmtTerm(term);
    }
        
    
    // Set the main sub-types of the EscrwAdd class.
    //
    escrow.setAccountId(accountID);
    escrow.setEscrwInfoRec(escrowInfo);

    escrow.setEscrwAnlysInfoRec(escrowAnalysisInfo);
    escrow.setFldInsurInfoRec(floodInsInfo);
    escrow.setEscrwPmtBalInfoRec(escrowPmtBalInfo);
    
    //general.errLog( "END assembleEscrowAdd(String username, Map fields)", "JXC.log" );

    return escrow;
  }


  /**
   * assembleCustAdd
   * 
   * This message is used to create a customer information file.
   * 
   * @param fields
   * @return
   * @throws DatatypeConfigurationException
   */
  private CustAdd assembleCustAdd(String username, Map fields)
  throws DatatypeConfigurationException
  {
    //general.errLog("START assembleCustAdd(String username, Map fields)", "JXC.log");
    //general.errLog("Map fields: "+fields, "JXC.log");

    // Temporary Logging of fields
    //
    try
    {
      FileWriter fw = new FileWriter("data/jxcbooking/_CFPLAT.log");
      String f,v = null;
      Iterator it = fields.keySet().iterator();
      while (it.hasNext())
      {
        f = (String)it.next();
        v = (String)fields.get(f);
        fw.write(f + " = " + v + "\r\n");
      }
      fw.close();
    }
    catch (Exception e)
    {
    }
        
    CustAdd customer = new CustAdd();

    // Set the message request header.
    //
    MsgRqHdrCType msgRq = new MsgRqHdrCType();
    msgRq.setJXchangeHdr(generateJXChangeHeader(username));
    customer.setMsgRqHdr(msgRq);
    
    // Create the CustAdd sub-types.
    //
    RegDetailCType regDetail = new RegDetailCType();
    BusDetailCType busDetail = new BusDetailCType();
    CustDetailCType custDetail = new CustDetailCType();
    TaxDetailCType taxDetail = new TaxDetailCType();
        
    // The following are sub-sub-types.
    //
    AddrCType addressInfo = new AddrCType();
    AddrCType irsAddrInfo = new AddrCType();
    PersonNameCType personNameInfo = new PersonNameCType();
    CRARecCType craRec = new CRARecCType();
    TINInfoCType tinInfo = new TINInfoCType();
    AlienCType alien = new AlienCType();
    
    // Create the array types.
    //
    UserDefInfoArrayAType userDefArray = new UserDefInfoArrayAType();
    PhoneArrayAType phoneArray = new PhoneArrayAType();
    EmailArrayAType emailArray = new EmailArrayAType();

    // Data Type Factory for XML Gregorian Calendar.
    //
    DatatypeFactory dataTypeFactory = DatatypeFactory.newInstance();
            
    // Retention
    //
    String field = (String)fields.get("CFRETN");
    if (field != null)
    {
      CustDataRtnPeriodType custRetention = new CustDataRtnPeriodType();
      custRetention.setValue(Integer.parseInt(field));
      
      regDetail.setCustDataRtnPeriod(custRetention);      
    }
    
    // Branch #
    //
    field = (String)fields.get("CFBRNN");
    if (field != null)
    {
      BrCodeType branchCode = new BrCodeType();
      branchCode.setValue(field);
      
      busDetail.setBrCode(branchCode);
    }
    
    // Inquiry Code
    //
    field = (String)fields.get("CFINQC");
    if (field != null)
    {
      AbbrCustDescType inquiryCode = new AbbrCustDescType();
      inquiryCode.setValue(field);
      
      busDetail.setAbbrCustDesc(inquiryCode);
    }
    
    // Officer Code
    //
    field = (String)fields.get("CFOFFR");
    if (field != null)
    {
      OffCodeType officerCode = new OffCodeType();
      officerCode.setValue(field);
      
      busDetail.setOffCode(officerCode);
    }
    
    // Employer Name
    //
    field = (String)fields.get("CFEMPL");
    if (field != null)
    {
      EmplNameType employerName = new EmplNameType();
      employerName.setValue(field);
      
      custDetail.setEmplName(employerName);
    }
    
    // Insider Code
    //
    field = (String)fields.get("CFINSC");
    if (field != null)
    {
      InsiderCodeType insiderCode = new InsiderCodeType();
      insiderCode.setValue(field);
      
      busDetail.setInsiderCode(insiderCode);
    }
    
    // VIP Customer
    //
    field = (String)fields.get("CFVIPC");
    if (field != null)
    {
      CustImporCodeType vipCustomer = new CustImporCodeType();
      vipCustomer.setValue(field);
      
      busDetail.setCustImporCode(vipCustomer);
    }
    
    // Insufficient Address
    //
    field = (String)fields.get("CFBADA");
    if (field != null)
    {
      InvAddrType invalidAddr = new InvAddrType();
      invalidAddr.setValue(field);
      
      addressInfo.setInvAddr(invalidAddr);
    }
    
    // Hold Mail Code
    //
    field = (String)fields.get("CFHLDM");
    if (field != null)
    {
      MailDirCodeType holdMailCode = new MailDirCodeType();
      holdMailCode.setValue(field);
      
      busDetail.setMailDirCode(holdMailCode);
    }
    
    // Profit Analysis
    //
    field = (String)fields.get("CFPROA");
    if (field != null)
    {
      ProfAnlysType profitAnalysis = new ProfAnlysType();
      profitAnalysis.setValue(field);
      
      busDetail.setProfAnlys(profitAnalysis);
    }
    
    // SIC #1
    //
    List<UserDefInfoCType> userDefList = userDefArray.getUserDefInfos();
    
    field = (String)fields.get("CFSIC1");
    if (field != null)
    {
      UserDefCodeType userDefCode = new UserDefCodeType();
      userDefCode.setValue(field);
      
      UserDefInfoCType userDefInfo = new UserDefInfoCType();
      userDefInfo.setUserDefCode(userDefCode);
      
      userDefList.add(userDefInfo);
    }

    // SIC #2
    //
    field = (String)fields.get("CFSIC2");
    if (field != null)
    {
      UserDefCodeType userDefCode = new UserDefCodeType();
      userDefCode.setValue(field);
      
      UserDefInfoCType userDefInfo = new UserDefInfoCType();
      userDefInfo.setUserDefCode(userDefCode);
      
      userDefList.add(userDefInfo);
    }

    // SIC #3
    //
    field = (String)fields.get("CFSIC3");
    if (field != null)
    {
      UserDefCodeType userDefCode = new UserDefCodeType();
      userDefCode.setValue(field);
      
      UserDefInfoCType userDefInfo = new UserDefInfoCType();
      userDefInfo.setUserDefCode(userDefCode);
      
      userDefList.add(userDefInfo);
    }

    // SIC #4
    //
    field = (String)fields.get("CFSIC4");
    if (field != null)
    {
      UserDefCodeType userDefCode = new UserDefCodeType();
      userDefCode.setValue(field);
      
      UserDefInfoCType userDefInfo = new UserDefInfoCType();
      userDefInfo.setUserDefCode(userDefCode);
      
      userDefList.add(userDefInfo);
    }

    // SIC #5
    //
    field = (String)fields.get("CFSIC5");
    if (field != null)
    {
      UserDefCodeType userDefCode = new UserDefCodeType();
      userDefCode.setValue(field);
      
      UserDefInfoCType userDefInfo = new UserDefInfoCType();
      userDefInfo.setUserDefCode(userDefCode);
      
      userDefList.add(userDefInfo);
    }

    // SIC #6
    //
    field = (String)fields.get("CFSIC6");
    if (field != null)
    {
      UserDefCodeType userDefCode = new UserDefCodeType();
      userDefCode.setValue(field);
      
      UserDefInfoCType userDefInfo = new UserDefInfoCType();
      userDefInfo.setUserDefCode(userDefCode);
      
      userDefList.add(userDefInfo);
    }

    // SIC #7
    //
    field = (String)fields.get("CFSIC7");
    if (field != null)
    {
      UserDefCodeType userDefCode = new UserDefCodeType();
      userDefCode.setValue(field);
      
      UserDefInfoCType userDefInfo = new UserDefInfoCType();
      userDefInfo.setUserDefCode(userDefCode);
      
      userDefList.add(userDefInfo);
    }

    // SIC #8
    //
    field = (String)fields.get("CFSIC8");
    if (field != null)
    {
      UserDefCodeType userDefCode = new UserDefCodeType();
      userDefCode.setValue(field);
      
      UserDefInfoCType userDefInfo = new UserDefInfoCType();
      userDefInfo.setUserDefCode(userDefCode);
      
      userDefList.add(userDefInfo);
    }
    
    // Customer Name
    //
    field = (String)fields.get("CFNA1");
    //general.errLog("CFNA1: "+field, "JXC.log");
    if (field != null)
    {
      ComNameType customerName = new ComNameType();
      customerName.setValue(field);
      
      personNameInfo.setComName(customerName);
    }
    
    // Address Line 1
    //
    field = (String)fields.get("CFNA2");
    if (field != null)
    {
      StreetAddr1Type address1 = new StreetAddr1Type();
      address1.setValue(field);
      
      addressInfo.setStreetAddr1(address1);
    }
    
    // Address Line 2
    //
    field = (String)fields.get("CFNA3");
    if (field != null)
    {
      StreetAddr2Type address2 = new StreetAddr2Type();
      address2.setValue(field);
      
      addressInfo.setStreetAddr2(address2);
    }
    
    // IRS Address
    //
    field = (String)fields.get("CFIRSA");
    if (field != null)
    {
      StreetAddr1Type address = new StreetAddr1Type();
      address.setValue(field);
      
      irsAddrInfo.setStreetAddr1(address);      
    }
    
    // City State Zip
    // Not in jXchange
    
    // City
    //
    field = (String)fields.get("CFCITY");
    if (field != null)
    {
      CityType city = new CityType();
      city.setValue(field);
      
      addressInfo.setCity(city);
    }
    
    // State
    //
    field = (String)fields.get("CFSTAT");
    if (field != null)
    {
      StateCodeType state = new StateCodeType();
      state.setValue(field);
      
      addressInfo.setStateCode(state);
    }
    
    // Zip Code
    //
    field = (String)fields.get("CFZIP");
    if (field != null)
    {
      if (field.trim().length() == 5)
      {
        field = field.trim() + "0000";
      }
      
      PostalCodeType zip = new PostalCodeType();
      zip.setValue(field);
      
      addressInfo.setPostalCode(zip);
    }
    
    // Zip Code Delivery Code
    //
    field = (String)fields.get("CFZIPD");
    if (field != null)
    {
      DlvryPtType deliveryCode = new DlvryPtType();
      deliveryCode.setValue(field);
      
      addressInfo.setDlvryPt(deliveryCode);
    }
    
    // CIF Expanded Title
    //
    field = (String)fields.get("CFEXTTL");
    //general.errLog("CFEXTTL: "+field, "JXC.log");
    if (field != null)
    {
      LegalNameType legalName = new LegalNameType();
      legalName.setValue(field);
      
      XPersonNameCType xPerson = new XPersonNameCType();
      xPerson.setLegalName(legalName);
      
      personNameInfo.setXPersonName(xPerson);
    }
    
    // CRA State Code
    //
    field = (String)fields.get("CFCRAS");
    if (field != null)
    {
      CRAStateCodeType state = new CRAStateCodeType();
      state.setValue(field);
      
      craRec.setCRAStateCode(state);
    }
    
    // County
    //
    field = (String)fields.get("CFCNTY");
    if (field != null)
    {
      CRACountyCodeType county = new CRACountyCodeType();
      county.setValue(field);
      
      craRec.setCRACountyCode(county);
    }
    
    // Census Tract
    //
    field = (String)fields.get("CFCENS");
    if (field != null)
    {
      BigDecimal bd = new BigDecimal(field);
      CRACenTractType censusTract = new CRACenTractType();
      censusTract.setValue(bd);
      
      craRec.setCRACenTract(censusTract);
    }
    
    // SMSA Code
    //
    field = (String)fields.get("CFSMSA");
    if (field != null)
    {
      CRASMSACodeType smsa = new CRASMSACodeType();
      smsa.setValue(field);
      
      craRec.setCRASMSACode(smsa);
    }
    
    // CRA Location
    //
    field = (String)fields.get("CFCRAL");
    if (field != null)
    {
      CRALocType location = new CRALocType();
      location.setValue(field);
      
      craRec.setCRALoc(location);
    }
    
    // Individual
    //
    field = (String)fields.get("CFINDI");
    if (field != null)
    {
      CustTypeType custType = new CustTypeType();
      custType.setValue(field);
      
      custDetail.setCustType(custType);
    }
    
    // Customer First Name
    //
    field = (String)fields.get("CFFNA");
    //general.errLog("CFFNA: "+field, "JXC.log");
    if (field != null)
    {
      FirstNameType name = new FirstNameType();
      name.setValue(field);
      
      personNameInfo.setFirstName(name);
    }
    
    // Customer Middle Name
    //
    field = (String)fields.get("CFMNA");
    //general.errLog("CFLMA: "+field, "JXC.log");
    if (field != null)
    {
      MiddleNameType name = new MiddleNameType();
      name.setValue(field);
      
      personNameInfo.setMiddleName(name);
    }
    
    // Customer Last Name
    //
    field = (String)fields.get("CFLNA");
    //general.errLog("CFLNA: "+field, "JXC.log");
    if (field != null)
    {
      LastNameType name = new LastNameType();
      name.setValue(field);
      
      personNameInfo.setLastName(name);
    }
    
    // Home Phone
    //
    List<PhoneInfoCType> phoneList = phoneArray.getPhoneInfos();
    
    field = (String)fields.get("CFHPHO");
    if (field != null)
    {
      PhoneNumType phone = new PhoneNumType();
      phone.setValue(field);
      
      PhoneTypeType phoneType = new PhoneTypeType();
      phoneType.setValue("Home Phone");
      
      PhoneInfoCType phoneInfo = new PhoneInfoCType();
      phoneInfo.setPhoneNum(phone);
      phoneInfo.setPhoneType(phoneType);
      
      phoneList.add(phoneInfo);
    }
    
    // Business Phone
    //
    field = (String)fields.get("CFBPHO");
    if (field != null)
    {
      PhoneNumType phone = new PhoneNumType();
      phone.setValue(field);
      
      PhoneTypeType phoneType = new PhoneTypeType();
      phoneType.setValue("Business Phone");
            
      PhoneInfoCType phoneInfo = new PhoneInfoCType();
      phoneInfo.setPhoneNum(phone);
      phoneInfo.setPhoneType(phoneType);
      
      // Business Phone Extension
      //
      field = (String)fields.get("CFBPHX");
      if (field != null)
      {
        PhoneExtType phoneExt = new PhoneExtType();
        phoneExt.setValue(field);
        
        phoneInfo.setPhoneExt(phoneExt);
      }
      
      phoneList.add(phoneInfo);
    }
    
    // Tax ID #
    //
    field = (String)fields.get("CFSSNO");
    if (field != null)
    {
      TaxIdType taxID = new TaxIdType();
      taxID.setValue(field);
      
      tinInfo.setTaxId(taxID);
    }
    
    // Tax ID Suffix (Tax ID Suffix for older SSNs that have a suffix)
    //
    field = (String)fields.get("CFSSFX");
    if (field != null)
    {
      TaxIdModType tinSuffix = new TaxIdModType();
      tinSuffix.setValue(field);
      
      tinInfo.setTaxIdMod(tinSuffix);
    }
    
    // Tax ID Type
    //
    field = (String)fields.get("CFSSCD");
    if (field != null)
    {
      TINCodeType tinCode = new TINCodeType();
      tinCode.setValue(field);
      
      tinInfo.setTINCode(tinCode);      
    }
    
    // TIN Status
    //
    field = (String)fields.get("CFTINS");
    if (field != null)
    {
      CertCodeType certCode = new CertCodeType();
      certCode.setValue(field);
      
      tinInfo.setCertCode(certCode);
    }
    
    // TIN Status Changed Date
    //
    field = (String)fields.get("CFTND6");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      CertCodeDtType certCodeDate = new CertCodeDtType();
      certCodeDate.setValue(xCal);
      
      tinInfo.setCertCodeDt(certCodeDate);
    }
        
    // Gender
    //
    field = (String)fields.get("CFSEX");
    if (field != null)
    {
      GenderType gender = new GenderType();
      gender.setValue(field);
      
      custDetail.setGender(gender);
    }
    
    // Class
    //
    field = (String)fields.get("CFCLAS");
    if (field != null)
    {
      CustCodeType custCode = new CustCodeType();
      custCode.setValue(field);
      
      busDetail.setCustCode(custCode);
    }
    
    // CRA Income Level
    //
    field = (String)fields.get("CFINCL");
    if (field != null)
    {
      CRAIncmLvlType incomeLevel = new CRAIncmLvlType();
      incomeLevel.setValue(field);
      
      craRec.setCRAIncmLvl(incomeLevel);
    }
    
    // Business Type
    //
    field = (String)fields.get("CFBUST");
    if (field != null)
    {
      StdIndustCodeType businessType = new StdIndustCodeType();
      businessType.setValue(field);
      
      custDetail.setStdIndustCode(businessType);
    }
    
    // NAICS Code
    //
    field = (String)fields.get("CFNAICS");
    if (field != null)
    {
      NAICSCodeType naicsCode = new NAICSCodeType();
      naicsCode.setValue(field);
      
      custDetail.setNAICSCode(naicsCode);
    }
    
    // CIF Combined Cycle
    //
    field = (String)fields.get("CFCCYC");
    if (field != null)
    {
      CustCycleCodeType custCycle = new CustCycleCodeType();
      custCycle.setValue(Integer.parseInt(field));
      
      busDetail.setCustCycleCode(custCycle);
    }
    
    // Alien Flag
    //
    field = (String)fields.get("CFAFLG");
    if (field != null)
    {
      AlienTypeCodeType alienFlag = new AlienTypeCodeType();
      alienFlag.setValue(field);
      
      alien.setAlienTypeCode(alienFlag);      
    }
    
    // Group #
    //
    field = (String)fields.get("CFGRP#");
    if (field != null)
    {
      GroupCodeType groupCode = new GroupCodeType();
      groupCode.setValue(field);
      
      busDetail.setGroupCode(groupCode);
    }
    
    // Financial Statement
    // Not in jXchange
    
    // Net Worth
    //
    field = (String)fields.get("CFWRTH");
    if (field != null)
    {
      NetWorthType netWorth = new NetWorthType();
      netWorth.setValue(Integer.parseInt(field));
      
      busDetail.setNetWorth(netWorth);
    }
    
    // F/S Waive Code
    // F/S Waive Date
    // Tax Return Date
    // Tax Extension Date
    // Postal Province
    // Postal Code
    // Postal Country
    // Residency Country
    // Exemption Code
    // Recipient Code
    // These are not in jXchange
    
    // Lease Security Flag
    //
    field = (String)fields.get("CFLEAS");
    if (field != null)
    {
      LeaseSecCodeType leaseSecFlag = new LeaseSecCodeType();
      leaseSecFlag.setValue(field);
      
      busDetail.setLeaseSecCode(leaseSecFlag);
    }
    
    // Date of Birth
    //
    field = (String)fields.get("CFBIR8");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      BirthDtType birthDate = new BirthDtType();
      birthDate.setValue(xCal);
      
      custDetail.setBirthDt(birthDate);
    }
    
    // Fax #
    //
    field = (String)fields.get("CFFAX1");
    if (field != null)
    {
      PhoneNumType phone = new PhoneNumType();
      phone.setValue(field);
      
      PhoneTypeType phoneType = new PhoneTypeType();
      phoneType.setValue("Fax Phone");
      
      PhoneInfoCType phoneInfo = new PhoneInfoCType();
      phoneInfo.setPhoneNum(phone);
      phoneInfo.setPhoneType(phoneType);
      
      phoneList.add(phoneInfo);
    }

    // Additional Fax #
    //
    field = (String)fields.get("CFFAX2");
    if (field != null)
    {
      PhoneNumType phone = new PhoneNumType();
      phone.setValue(field);
      
      PhoneTypeType phoneType = new PhoneTypeType();
      phoneType.setValue("Additional Fax Phone");
      
      PhoneInfoCType phoneInfo = new PhoneInfoCType();
      phoneInfo.setPhoneNum(phone);
      phoneInfo.setPhoneType(phoneType);
      
      phoneList.add(phoneInfo);
    }

    // Cell Phone #
    //
    field = (String)fields.get("CFCEL1");
    if (field != null)
    {
      PhoneNumType phone = new PhoneNumType();
      phone.setValue(field);
      
      PhoneTypeType phoneType = new PhoneTypeType();
      phoneType.setValue("Cell Phone");
      
      PhoneInfoCType phoneInfo = new PhoneInfoCType();
      phoneInfo.setPhoneNum(phone);
      phoneInfo.setPhoneType(phoneType);
      
      phoneList.add(phoneInfo);
    }

    // Other Cell Phone #
    //
    field = (String)fields.get("CFCEL2");
    if (field != null)
    {
      PhoneNumType phone = new PhoneNumType();
      phone.setValue(field);
      
      PhoneTypeType phoneType = new PhoneTypeType();
      phoneType.setValue("Other Cell Phone");
      
      PhoneInfoCType phoneInfo = new PhoneInfoCType();
      phoneInfo.setPhoneNum(phone);
      phoneInfo.setPhoneType(phoneType);
      
      phoneList.add(phoneInfo);
    }
    
    // Email Address
    //
    List<EmailInfoCType> emailList = emailArray.getEmailInfos();
    
    field = (String)fields.get("CFEML1");
    if (field != null)
    {
      //general.errLog( "field: " + field, "JXC.log" );
      //general.errLog( "email.setValue(field): " + field, "JXC.log");
      //general.errLog( "emailType.setValue(Primary): Primary E-Mail", "JXC.log");

      EmailAddrType email = new EmailAddrType();
      // flip value & type LED 4-17-13
      //
      email.setValue(field);
      
      // flip
      //email.setValue( "Primary E-mail" );
      //

      EmailTypeType emailType = new EmailTypeType();
      emailType.setValue( "Primary E-Mail" );
      //emailType.setValue( "Secondary E-Mail" );
      //emailType.setValue("Work");
    
      // flip
      //emailType.setValue( field );
      //
      EmailInfoCType emailInfo = new EmailInfoCType();
      emailInfo.setEmailAddr(email);
      emailInfo.setEmailType(emailType);
      
      emailList.add(emailInfo);
    }

    // Other Email Address
    //
    field = (String)fields.get("CFEML2");
    if (field != null)
    {
      EmailAddrType email = new EmailAddrType();
      email.setValue(field);
      
      EmailTypeType emailType = new EmailTypeType();
      emailType.setValue("Other");
      
      EmailInfoCType emailInfo = new EmailInfoCType();
      emailInfo.setEmailAddr(email);
      emailInfo.setEmailType(emailType);
      
      emailList.add(emailInfo);
    }
    
    // Privacy Act Opt Out
    //
    field = (String)fields.get("CFREGP");
    if (field != null)
    {
      RegPOptOutCodeType optOut = new RegPOptOutCodeType();
      optOut.setValue(field);
      
      regDetail.setRegPOptOutCode(optOut);
    }
    
    // Privacy Act Last Notice Sent Date
    //
    field = (String)fields.get("CFRPD7");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      RegPSentDtType noticeSentDate = new RegPSentDtType();
      noticeSentDate.setValue(xCal);
      
      regDetail.setRegPSentDt(noticeSentDate);
    }
    
    // IRS City
    //
    field = (String)fields.get("CFIRSC");
    if (field != null)
    {
      CityType city = new CityType();
      city.setValue(field);
      
      irsAddrInfo.setCity(city);
    }
    
    // IRS State
    //
    field = (String)fields.get("CFIRSS");
    if (field != null)
    {
      StateCodeType state = new StateCodeType();
      state.setValue(field);
      
      irsAddrInfo.setStateCode(state);
    }
    
    // IRS Zip
    //
    field = (String)fields.get("CFIRSZ");
    if (field != null)
    {
      PostalCodeType zip = new PostalCodeType();
      zip.setValue(field);
      
      irsAddrInfo.setPostalCode(zip);
    }
    
    // IRS Delivery Point
    //
    field = (String)fields.get("CFIRSD");
    if (field != null)
    {
      DlvryPtType deliveryPoint = new DlvryPtType();
      deliveryPoint.setValue(field);
      
      irsAddrInfo.setDlvryPt(deliveryPoint);
    }
    
    // IRS Foreign Delivery Point
    // Not available at this time
    
    // CIF Do Not Call Flag
    //
    field = (String)fields.get("CFNOCALL");
    if (field != null)
    {
      DoNotCallCodeType doNotCall = new DoNotCallCodeType();
      doNotCall.setValue(field);
      
      regDetail.setDoNotCallCode(doNotCall);
    }
    
    // CIF Do Not Call Flag Expiration Date
    //
    field = (String)fields.get("CFNCLEX7");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      DoNotCallExpDtType doNotCallExp = new DoNotCallExpDtType();
      doNotCallExp.setValue(xCal);
      
      regDetail.setDoNotCallExpDt(doNotCallExp);
    }
    
    // CIF Risk Rating
    //
    field = (String)fields.get("CFRSKRT");
    if (field != null)
    {
      RiskRateCodeType riskRating = new RiskRateCodeType();
      riskRating.setValue(field);
      
      regDetail.setRiskRateCode(riskRating);
    }
    
    // CIF Risk Rating Date
    //
    field = (String)fields.get("CFRSKD7");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      RiskRateDtType riskRatingDate = new RiskRateDtType();
      riskRatingDate.setValue(xCal);
      
      regDetail.setRiskRateDt(riskRatingDate);
    }
    
    // CIF Risk Rated By Code
    //
    field = (String)fields.get("CFRSKBY");
    if (field != null)
    {
      RiskRateByCodeType riskRateByCode = new RiskRateByCodeType();
      riskRateByCode.setValue(field);
      
      regDetail.setRiskRateByCode(riskRateByCode);
    }
    
    // CIF Occupation Designation
    //
    field = (String)fields.get("CFOCPCD");
    if (field != null)
    {
      OccTypeType occupationType = new OccTypeType();
      occupationType.setValue(field);
      
      custDetail.setOccType(occupationType);
    }
    
    // Affiliate Opt Out
    //
    field = (String)fields.get("CFAFLOPT");
    if (field != null)
    {
      AflOptOutCodeType affiliateOptOutCode = new AflOptOutCodeType();
      affiliateOptOutCode.setValue(field);
      
      regDetail.setAflOptOutCode(affiliateOptOutCode);
    }
    
    // Affiliate Opt Out Expiration Date
    //
    field = (String)fields.get("CFAFLEXD7");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      AflOptOutExpDtType affiliateOptOutDate = new AflOptOutExpDtType();
      affiliateOptOutDate.setValue(xCal);
      
      regDetail.setAflOptOutExpDt(affiliateOptOutDate);
    }
    
    // Affiliate Opt Out Exception Date
    //
    field = (String)fields.get("CFAFLECD7");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      AflOptOutExcptDtType affiliateOptOutExcDate = new AflOptOutExcptDtType();
      affiliateOptOutExcDate.setValue(xCal);
      
      regDetail.setAflOptOutExcptDt(affiliateOptOutExcDate);
    }
    
    // Affiliate Opt Out Exception Code
    //
    field = (String)fields.get("CFAFLEXCD");
    if (field != null)
    {
      AflOptOutExcptCodeType affiliateOptOutExcCode = new AflOptOutExcptCodeType();
      affiliateOptOutExcCode.setValue(field);
      
      regDetail.setAflOptOutExcptCode(affiliateOptOutExcCode);
    }
    
    // Sales Associate
    //
    field = (String)fields.get("SALESAC");
    if (field != null)
    {
      SalesPersonType salesPerson = new SalesPersonType();
      salesPerson.setValue(field);
      
      busDetail.setSalesPerson(salesPerson);
    }
    
    // Language Identifier
    //
    field = (String)fields.get("CFLANG");
    if (field != null)
    {
      LangTypeType languageType = new LangTypeType();
      languageType.setValue(field);
      
      busDetail.setLangType(languageType);
    }
    
    // Foreign Country
    //
    field = (String)fields.get("CFFORC");
    if (field != null)
    {
      CntryType country = new CntryType();
      country.setValue(field);
      
      addressInfo.setCntry(country);
    }
    
    // IRS Foreign Country
    //
    field = (String)fields.get("CFIRSFC");
    if (field != null)
    {
      CntryType country = new CntryType();
      country.setValue(field);

      irsAddrInfo.setCntry(country);
    }
    
    // Alien Cert. Expiration
    //
    field = (String)fields.get("CFAEDAT");
    if (field != null)
    {
      XMLGregorianCalendar xCal = dateToXMLGregorian(dataTypeFactory, field);
      AlienLastW8DtType alienCertDate = new AlienLastW8DtType();
      alienCertDate.setValue(xCal);      
      
      alien.setAlienLastW8Dt(alienCertDate);
    }
    
    // W8 Status Code
    //
    field = (String)fields.get("W8STAT");
    if (field != null)
    {
      AlienW8StatType alienW8Stat = new AlienW8StatType();
      alienW8Stat.setValue(field);
      
      alien.setAlienW8Stat(alienW8Stat);
    }
    
    // W8 Type Code
    //
    field = (String)fields.get("W8TYPE");
    if (field != null)
    {
      AlienW8TypeType alienW8Code = new AlienW8TypeType();
      alienW8Code.setValue(field);
      
      alien.setAlienW8Type(alienW8Code);
    }
    
    // W8 Programmer Use
    // Physical Address Line 1
    // Physical Address Line 2
    // Physical Address City
    // Physical Address State
    // Physical Address Zip
    // Physical Address Delivery Point
    // Date Last Contact
    // The above fields are not used by jXchange
    
    
    // Set the CustDetail sub-type.
    //
    custDetail.setAddr(addressInfo);
    custDetail.setPersonName(personNameInfo);
    custDetail.setPhoneArray(phoneArray);    
    custDetail.setEmailArray(emailArray);
    
    // Set the RegDetail sub-types.
    //
    regDetail.setCRARec(craRec);
    
    // Set the TaxDetail sub-types.
    //
    taxDetail.setAlien(alien);
    taxDetail.setTINInfo(tinInfo);
    taxDetail.setIRSPostAddr(irsAddrInfo);

    // Set the CustAdd sub-types.
    //
    customer.setRegDetail(regDetail);
    customer.setBusDetail(busDetail);
    customer.setCustDetail(custDetail);
    customer.setTaxDetail(taxDetail);

    
    List<String> overrideList = CONFIG.getSectionElements("CustAdd Override");
    if (overrideList != null)
    {
      // Set the Error Override Array.
      //
      ErrOvrRdInfoArrayAType errOvrRdArray = new ErrOvrRdInfoArrayAType();
      List<ErrOvrRdCType> errOvrRdList = errOvrRdArray.getErrOvrRds();
  
      for (String overrideCode : overrideList)
      {
        // Set the Error Override sub-types.
        //
        ErrOvrRdCType errOvrRdDetail = new ErrOvrRdCType();
        errOvrRdDetail.setErrCode(overrideCode);
        errOvrRdList.add( errOvrRdDetail );
      }
          
      customer.setErrOvrRdInfoArray( errOvrRdArray );
    }

    //general.errLog( "END assembleCustAdd(String username, Map fields)", "JXC.log" );

    return customer;
  }
  
  
  
  private XMLGregorianCalendar dateToXMLGregorian(DatatypeFactory dataTypeFactory, String theDate)
  {
    Date date = DateUtility.assignSlashDateToJavaDate(theDate);
    GregorianCalendar cal = new GregorianCalendar();
    cal.setTime(date);
    XMLGregorianCalendar xCal = dataTypeFactory.newXMLGregorianCalendar(cal);
    
    return xCal;
  }
  
          
  private boolean processDepositApplication(String username, DataNode appNode, List log, StringBuffer errorMsg)
  {
    String appID = (String)appNode.getFieldData(username, CSFieldNames.FN_APP_ID);
    String refID = (String)appNode.getFieldData(username, CSFieldNames.FN_APP_REF_ID);

    try
    {  
      String branchId = (String) appNode.getFieldData(username, CSFieldNames.FN_BRANCH_ID);
      Location location = Location.find(Integer.parseInt(branchId));
      String branchRefId = location.getLocationRefId();

      log.add("App ID: " + appID);
      log.add("Ref ID: " + refID);
      log.add("Branch Ref ID: " + branchRefId);
            
      DataNode primaryApplicant = CSUtil.getPrimaryApplicant(appNode);
      if (primaryApplicant == null)
      {
        String msg = "Primary applicant not found.";
        log.add(msg);
        errorMsg.append(msg);
        return false;
      }

      List<DataNode> bwrList = appNode.getEffectiveReferences(NodeUtils.BWR_DN_TYPE);

      // Aggregate the application fields necessary to set all of the web service method calls.
      //
      Map baseFields = appNode.getFieldData("");
      baseFields.putAll(appNode.getSystemData());
      baseFields.put("bwrCount", String.valueOf(bwrList.size()));

      dealerFields(appNode, baseFields);
      branchFields(Integer.parseInt(branchId), baseFields);
      generatePreProcessFields(baseFields);
      
      CustomerService customerSvc = createCustomerService();

      // This map keeps track of how many of a certain borrower type there
      // is so we can create a field that contains the index of the type.
      // "Co-applicant 1, Co-applicant 2, Co-signer 1, etc."
      //
      Map<String, Integer> bwrTypeCountTable = new HashMap<String, Integer>();
      Integer bwrIndex = new Integer(1);
  
      // Does the primary applicant have a customer ID already?
      //
      String primaryCustomerID = getCustomerIDFromApplicantNode(username, primaryApplicant, false);
      if ((primaryCustomerID == null) || (primaryCustomerID.equalsIgnoreCase("")))
      {
        // A customer ID was not in the data for this applicant.  Will need to do a customer add in
        // Jack Henry.
        //
        AdminGUIManager.displayE("Processing Add Primary Customer ...");
        primaryCustomerID = AddCustomerAndGetCustId(username,appNode,primaryApplicant,primaryApplicant,
                                                    customerSvc,false,baseFields, bwrTypeCountTable,
                                                    bwrIndex, log,errorMsg);
        if (primaryCustomerID == null) return false;
      }
      log.add("Primary applicant customer ID: " + primaryCustomerID);
  
      List<DataNode> accounts = appNode.getEffectiveReferences(NodeUtils.DEP_ACCOUNT_DN_TYPE);
      
      for (DataNode account : accounts)
      {
        Map allFields = new HashMap();
        
        // For each product (account) on the application, create the account in Jack Henry.
        //
        allFields.putAll(baseFields);
        allFields.putAll(account.getFieldData(username));
        allFields.putAll(account.getSystemData());
        
        String productID = (String)allFields.get(CSFieldNames.FN_DEP_PROD_ID);
        DepProduct product = CSDataCache.getDepProductManager().getProduct(productID);
        if (product == null)
        {
          String msg = "Unable to load product ID: " + productID;
          log.add(msg);
          errorMsg.append(msg);
          return false;
        }
  
        log.add("Processing product: " + product.getName());
          
        String productType = product.getProductType();
        log.add("Product Type: " + productType);
        
        // Load any product type specific data.
        //
        generateProductSpecificFields(productType, allFields);
        generateProductSpecificFields(productID, allFields);      
        
        // Get the account type code from .ini file
        String acctTypeCode = (String) allFields.get("acctType");      
        if (acctTypeCode == null)
        {
            String msg = "Unable to load product type (acctType) on the product: " + productID;
            log.add(msg);
            errorMsg.append(msg);
            return false;
        }
        log.add("acctType: " + acctTypeCode);          
  
        String acctId = (String)allFields.get(CSFieldNames.FN_DEP_ACCT_NUM);
        //if (acctId == null) 
        {
          /*
            // THEY WILL GET THE ACCT # FROM THE DATABASE

            // Generate the account number.
            //
            Map acctIdsGenInputParams = new HashMap();
            acctIdsGenInputParams.put("AcctType", acctTypeCode);
            acctIdsGenInputParams.put("QtyNeeded", "1");
            acctIdsGenInputParams.put("BrCode", branchRefId);
            
            // Not sure if Five Star wants the brCode, prodCode and other codes to assocaite with the AcctIds
            // P.S. We might get an error if the prodCode is not match with the branch code
            // <ErrCode>800010</ErrCode><ErrCat>Error</ErrCat><ErrDesc>Invalid product</ErrDesc>
            
            //acctIdGeneratorParams.put("ProdCode", "RC");
            //acctIdGeneratorParams.put("OffCode", "MJG");
            //acctIdGeneratorParams.put("SubCatType", null);

            AdminGUIManager.displayE("Processing Acct Id Generator..."); 
            GenAcctIdArrayAType acctIdArray = generateAcctIdArray(username, customerSvc, acctIdsGenInputParams, log, errorMsg);
            if (acctIdArray != null) 
            {
                GenAcctIdCType genAcctId = acctIdArray.getGenAcctIds().get(0);
                AcctIdType acctIdType = genAcctId.getAcctId();
                acctId = acctIdType.getValue();
                accountFields.put(CSFieldNames.FN_DEP_ACCT_NUM, acctId);
            }
            else {
                // Fail to generate Acct Ids
                String msg = "Unable to generate account ids";
                log.add(msg);
                errorMsg.append(msg);
                return false;
            }
            */
            
            /* 
            
            SKIP PRODUCT DEFAULTS TRANSACTION... MAY BE MORE TROUBLE THAN ITS WORTH RIGHT NOW
            
            // Do the product defaults transaction.
            //
            CriteriaArrayAType criteriaArray = new CriteriaArrayAType();
            criteriaArray.getCriteriaInfos().add(addCriteria("Actype",acctTypeCode));
            criteriaArray.getCriteriaInfos().add(addCriteria("Branch",branchRefId));
            
            if (productType.equals("CD"))
            {
                // Get the CD product type code from .ini file
                String cdProdTypeCode = (String) productFields.get("cdProdType");
                if (cdProdTypeCode == null) 
                {
                    String msg = "Unable to load the CD Product Type Code";
                    log.add(msg);
                    errorMsg.append(msg);
                    return false;
                }
                log.add("cdProdType: " + cdProdTypeCode);
                criteriaArray.getCriteriaInfos().add(addCriteria("Type",cdProdTypeCode));
            }
            else
            //if ((acctTypeCode.equalsIgnoreCase("D") || (acctTypeCode.equalsIgnoreCase("S"))))
            {
                // Get the service charge code from .ini file
                String serviceChargeCode = (String) productFields.get("scCode");
                if (serviceChargeCode == null) 
                {
                    String msg = "Unable to load the Service Charge Code";
                    log.add(msg);
                    errorMsg.append(msg);
                    return false;
                }
                log.add("scCode: " + serviceChargeCode);
                criteriaArray.getCriteriaInfos().add(addCriteria("ScCode",serviceChargeCode));
            }
              
            AdminGUIManager.displayE("Processing Acct Add Service Default ..."); 
            SvcDftResponse defaultAcctAddResponse =  AcctAddServiceDefault(username, customerSvc, criteriaArray, log, errorMsg);
            if (defaultAcctAddResponse == null) 
            {
                // Fail to generate Acct Ids
                String msg = "Unable to create an default account";
                log.add(msg);
                errorMsg.append(msg);
                return false;
            }
            */
          
            // Add the product/account in Jack Henry.
            //
            DepositService depositSvc = createDepositService();
            AdminGUIManager.displayE("Processing Account Add ...");
            boolean addAccountSuccess = processAddAccount(username, allFields, appNode, productType,
                                                          depositSvc, primaryCustomerID, log, errorMsg);
            if (!addAccountSuccess) 
            {
              // Fail to Create Account
              String msg = "Unable to create an account";
              log.add(msg);
              errorMsg.append(msg);
              return false;
            }                   

            // Add product Success, now update the daAcctNum field
            // account.setFieldData(username, CSFieldNames.FN_DEP_ACCT_NUM, acctId);
            log.add("Account Add Success. Acct Id: " + acctId);

            // Option 3 in the field "daAncProdrM" is a Debit Card.
            //
            List<String> productOptions = (List<String>)allFields.get("daAncProdrM");
            if (productOptions != null && productOptions.contains("3"))
            {
              AdminGUIManager.displayE("Processing EFT Card Add ...");
              boolean success = processEFTCardAdd(username, primaryCustomerID, allFields, customerSvc, log, errorMsg);
              if (!success) 
              {
                // Fail to execute EFT Card Add
                String msg = "Unable to perform EFT Card Add";
                log.add(msg);
                errorMsg.append(msg);
                return false;
              }                   
            }
            
            // If it not a CD account (ex. savings or checking account), call "transaction add" to set the opening amount
            if (!productType.equals("CD") && CONFIG.containsSection("Transaction Add")) 
            {
                TransactionService tranactionSvc = createTransactionService();
                AdminGUIManager.displayE("Processing Transacation Add ...");
                boolean addTransactionSuccess = processTransactionAdd(username, allFields, tranactionSvc, log, errorMsg);
                if (!addTransactionSuccess) 
                {
                    // Fail to Add Transacation
                    String msg = "Unable to add transacation to an account.  Acct Id:" + acctId;
                    log.add(msg);
                    errorMsg.append(msg);
                    return false;
                }  
                log.add("Transacation Add Success.");
            }            
        }
              
        // Check to see if the account specifies a minor (custodial account).
        //
        boolean isCustodial = accountHasCustodianRelationship(username, account);
        log.add("Is Custodial: " + isCustodial);
        if (isCustodial)
        {
  
          // Check to see if we have a customer ID for the minor.
          //
          String customerID = getCustomerIDFromApplicantNode(username, account, true);
          if ((customerID == null) || (customerID.equalsIgnoreCase("")))
          {
            // Create the minor in Jack Henry.
            //
            AdminGUIManager.displayE("Processing Add Custodian ...");
            customerID = AddCustomerAndGetCustId(username,appNode,account,primaryApplicant,customerSvc,
                                                 true,baseFields,bwrTypeCountTable, bwrIndex,log,errorMsg);
            if (customerID == null) return false;
          }
          log.add("Custodial Cust Id: " + customerID);
          
          // Relationship Transaction.
          //
          String custodianRelCode =  CONFIG.getSectionProperty("Misc", "custodianRelCode");
          if (custodianRelCode == null) 
          {
              // Fail to customer relationship with the custoidan
              String msg = "Unable to create customer relationship.  Undefined custoidan relationship code.";
              log.add(msg);
              errorMsg.append(msg);
              return false;
          }
          Boolean successAddCustRel = false;
          AdminGUIManager.displayE("Processing Customer Relationship with the Custodian ...");
          successAddCustRel = processAddCustRel(username, null, acctId, acctTypeCode, primaryCustomerID,  customerID, custodianRelCode, log, errorMsg);
          if (!successAddCustRel) return false;
          log.add("AddCustRel Success");
        }
        else
        {
          // If not a custodial account, then look for any additional account holders.
          // Each additional account holder will need to possibly be added to Jack Henry
          // as a customer, and a relationship to the account defined.        
          //
          List<String> additionalAccountHolders = (List<String>)account.getSystemData(CSFieldNames.FN_SYS_DEP_ADD_ACCT_HLDRS);
            
          
          if (additionalAccountHolders != null)
          {
            Map<String, String> titleMap = (Map<String, String>)account.getSystemData(CSFieldNames.FN_SYS_DEP_TITLE_MAP);
            if (titleMap == null) 
            {
                StringBuilder msg = new StringBuilder();
                msg.append("Unable to get the Title Map");
                log.add(msg.toString());
                errorMsg.append(msg.toString());
                return false;
            }
            String relationshipCode = null;
            log.add("Additional account holders: " + additionalAccountHolders);
            for (String aahIndex : additionalAccountHolders)
            {
              DataNode accountHolder = appNode.getReference(NodeUtils.BWR_DN_TYPE, Integer.parseInt(aahIndex));        
              if (accountHolder == null)
              {
                StringBuilder msg = new StringBuilder();
                msg.append("On product " + account.getDescription()).append(": Unable to locate\n");
                msg.append("the additional account holder with node index of '").append(aahIndex).append("'");
                
                log.add(msg.toString());
                errorMsg.append(msg.toString());
                return false;
              }
      
              // Check to see if we have a customer ID for the co-applicant.
              //
              String customerID = getCustomerIDFromApplicantNode(username, accountHolder, false);
              if ((customerID == null) || (customerID.equalsIgnoreCase("")))
              {
                // Create the co-applicant in Jack Henry.
                //
                AdminGUIManager.displayE("Processing Add Additional Account Holders ...");
                customerID = AddCustomerAndGetCustId(username,appNode,accountHolder,primaryApplicant,
                                                     customerSvc,false,baseFields,bwrTypeCountTable, bwrIndex,
                                                     log,errorMsg);
                if (customerID == null) return false;
              }
              log.add("Additional Account Holder's Cust Id: " + customerID);
              
              // Relationship Transaction.
              //
              relationshipCode = titleMap.get(aahIndex);
              if (relationshipCode == null) 
              {
                  // Fail to customer relationship with the additional account holder
                  String msg = "Unable to create customer relationship.  Undefined additional account holder relationship code.";
                  log.add(msg);
                  errorMsg.append(msg);
                  return false;
              }
              Boolean successAddCustRel = false;
              AdminGUIManager.displayE("Processing Customer Relationship with Additional Account Holders ...");
              successAddCustRel = processAddCustRel(username, customerSvc, acctId, acctTypeCode, primaryCustomerID,  customerID, relationshipCode, log, errorMsg);
              if (!successAddCustRel) return false;
              log.add("AddCustRel Success");
            }
          }
        }
      }
    }
    catch (Exception e)
    {
      ExceptionLogger.logException(e);
      
      String msg = "Unexpected Error: " + e;
      log.add(msg);
      errorMsg.append(msg);
      return false;
    }
      
    StringBuilder msg = new StringBuilder();
    msg.append("Completed Process Application. App ID: ").append(appID);    
    AdminGUIManager.displayE(msg.toString());
    return true;
  }


  /**
   * Retrieves the customer ID field (atCIF) from the applicant data node.
   * 
   * @param username
   * @param applicant
   * @return
   */
  private String getCustomerIDFromApplicantNode(String username, DataNode applicant, boolean isMinor)
  {
    return (String)applicant.getFieldData(username, isMinor ? "minCIF" : CSFieldNames.FN_CUST_NUM);
  }
  

  /**
   * Determines whether the account specifies a custodian.
   * 
   * @param username
   * @param account
   * @return
   */
  private boolean accountHasCustodianRelationship(String username, DataNode account)
  {
    String daCustC = (String)account.getFieldData(username, "daCustC");
    
    return daCustC != null && daCustC.equals("true");
  }
  
  
  private String changeLineBreaks(String msg)
  {
    return msg.replaceAll(Matcher.quoteReplacement("\n"), "\r\n");
  }
  
  
  @Override
  protected boolean processApplication(String username, SystemDataObject sdo, List log, StringBuffer errorMsg)
  {
    //general.errLog( "START processApplication(...): SDO ID:"+sdo.getObjectID(), "JXC.log" );

    AdminGUIManager.displayE("jXchange -> " + sdo.getObjectID());
    
    DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);

    if (FROM_ACTIVITY)
    {
      if (!isProductQualified(sdo, log))
      {
        return false;
      }
    }
    else
    {
      if (!isMonitoredProductQualified(sdo, log))
      {
        return false;
      }
    }
    
    // Double check to see if the application is fully funded
    if (CSUtil.isDepositApplication(appNode) && MUST_BE_FUNDED && ! DepUtils.isApplicationFunded(appNode))
    {
      return false;
    }
    
    boolean response;
    
    if (CSUtil.isConsumerApplication(appNode))
    {
      response = processConsumerApplication(username, appNode, log, errorMsg);
    }
    else
    {
      response = processDepositApplication(username, appNode, log, errorMsg);
    }
    
    //general.errLog( "END processApplication(...): SDO ID:"+sdo.getObjectID(), "JXC.log" );

    return response;
  }


  private void generalPurposeSelection(Map baseFields)
  {
    VectorX vec = (VectorX) baseFields.get("anGenPurM");
    if (vec != null && !vec.isEmpty())
    {
      List list = new ArrayList(vec.size());
      list.addAll(vec);

      baseFields.put("anGenPurM", createCommandStringFromList(list));
    }
  }


  private void involvedPersonnel(DataNode appNode, Map baseFields)
  {
    //general.errLog( "START involvedPersonnel(DataNode appNode, Map baseFields)", "JXC.log" );
    // Fill in the "involved personal" vista with the users real names
    //
    User user;

    String str = (String) appNode.getFieldData("", "anDataEntry");
    //general.errLog( "1 str: "+str, "JXC.log" );
    if (str != null)
    {
      user = User.getUser2(str);
      if (user != null)
      {
        baseFields.put("anDataEntryName", user.getRealName());
        str = user.getOfficerNumber();
        //general.errLog( "1 str: " + str, "JXC.log" );
        if (str != null)
        {
          baseFields.put("anDataEntryOff", str);
        }
      }
    }

    str = (String) appNode.getFieldData("", "anProcessor");
    //general.errLog( "2 str: " + str, "JXC.log" );
    if (str != null)
    {
      user = User.getUser2(str);
      if (user != null)
      {
        baseFields.put("anProcessorName", user.getRealName());
        str = user.getOfficerNumber();
        //general.errLog( "2 str: " + str, "JXC.log" );
        if (str != null)
        {
          baseFields.put("anProcessorOff", str);
        }
      }
    }

    str = (String) appNode.getFieldData("", "anAuditor");
    //general.errLog( "3 str: " + str, "JXC.log" );
    if (str != null)
    {
      user = User.getUser2(str);
      if (user != null)
      {
        baseFields.put("anAuditorName", user.getRealName());
        str = user.getOfficerNumber();
        //general.errLog( "3 str: " + str, "JXC.log" );
        if (str != null)
        {
          baseFields.put("anAuditorOff", str);
        }
      }
    }

    str = (String) appNode.getFieldData("", "anVerifier");
    //general.errLog( "4 str: " + str, "JXC.log" );
    if (str != null)
    {
      user = User.getUser2(str);
      if (user != null)
      {
        baseFields.put("anVerifierName", user.getRealName());
        str = user.getOfficerNumber();
        //general.errLog( "4 str: " + str, "JXC.log" );
        if (str != null)
        {
          baseFields.put("anVerifierOff", str);
        }
      }
    }

    str = (String) appNode.getFieldData("", "anUnder");
    //general.errLog( "5 str: " + str, "JXC.log" );
    if (str != null)
    {
      user = User.getUser2(str);
      if (user != null)
      {
        baseFields.put("anUnderName", user.getRealName());
        str = user.getOfficerNumber();
        //general.errLog( "5 str: " + str, "JXC.log" );
        if (str != null)
        {
          baseFields.put("anUnderOff", str);
        }
      }
    }

    str = (String) appNode.getFieldData("", "anFnlRvw");
    //general.errLog( "6 str: " + str, "JXC.log" );
    if (str != null)
    {
      user = User.getUser2(str);
      if (user != null)
      {
        baseFields.put("anFnlRvwName", user.getRealName());
        str = user.getOfficerNumber();
        //general.errLog( "6 str: " + str, "JXC.log" );
        if (str != null)
        {
          baseFields.put("anFnlRvwOff", str);
        }
      }
    }

    str = (String) appNode.getFieldData("", "anLnOff");
    //general.errLog( "7 str: " + str, "JXC.log" );
    if (str != null)
    {
      user = User.getUser2(str);
      if (user != null)
      {
        baseFields.put("anLnOffName", user.getRealName());
        str = user.getOfficerNumber();
        //general.errLog( "7 str: " + str, "JXC.log" );
        if (str != null)
        {
          baseFields.put("anLnOffOff", str);
        }
      }
    }
    
// SET OFFICER CODE FOR DMZ
//
//baseFields.put( "anLnOffOff", "AMR" );
//baseFields.put( "anUnderOff", "AMR" );

    //general.errLog( "END involvedPersonnel(DataNode appNode, Map baseFields)", "JXC.log" );

  }


  // This method generates both borrower and collateral lists because
  // as part of the work needed to generate a borrower list, we can
  // easily capture the collateral for no additional processing.
  //
  private List<DataNode>[] generateBorrowerAndCollateralList(DataNode appNode)
  {
    // We need to generate a list of all borrowers on the application
    // as well as all 3rd party owners on all collateral.  In this
    // process, we need to make sure the list does not contain any
    // duplicate borrowers.
    //
    List<DataNode> bwrList = appNode.getEffectiveReferences(NodeUtils.BWR_DN_TYPE);
    List<DataNode> collateralList = new ArrayList<DataNode>();
    Map<String, DataNode> tpoTable = new HashMap<String, DataNode>();

    // Now look through all collateral nodes and gather up all unique
    // 3rd party borrowers.
    //
    DataNode node = appNode.getReference(NodeUtils.COLL_DN_TYPE, 0);
    if (node != null)
    {
      Map<String, List> collMap = node.getReferences();

      String collType;
      List<DataNode> collList, ownerList;

      Iterator<String> it = collMap.keySet().iterator();
      while (it.hasNext())
      {
        collType = it.next();
        collList = collMap.get(collType);

        for (DataNode collNode : collList)
        {
          if (!collNode.isDeleted())
          {
            collateralList.add(collNode);

            ownerList = collNode.getReferences(NodeUtils.ONR_DN_TYPE);
            addThirdPartyOwners(tpoTable, ownerList);
          }
        }
      }
    }

    Iterator it = tpoTable.keySet().iterator();
    while (it.hasNext())
    {
      bwrList.add(tpoTable.get(it.next()));
    }

    return new List[] { bwrList, collateralList };
  }


  private void addThirdPartyOwners(Map<String, DataNode> tpoTable, List<DataNode> ownerList)
  {
    if (ownerList != null)
    {
      String ownerType;

      for (DataNode ownerNode : ownerList)
      {
        if (!ownerNode.isDeleted())
        {
          ownerType = (String) ownerNode.getFieldData("", CSFieldNames.FN_OWNER_TYPE);
          if (ownerType != null &&
              ownerType.equals(CSFieldValues.FV_OWNR_TYPE_OTHER))
          {
            // Found a 3rd party owner.  Add it to the tpoTable.  Since
            // the table is using the SSN as the key, any duplicate
            // owners will hash into the same table location.
            //
            String ssn = (String) ownerNode.getFieldData("", "OnrSSN");
            String lname = (String) ownerNode.getFieldData("",
                CSFieldNames.FN_ONR_L_NAME);

            StringBuilder key = new StringBuilder();
            key.append(ssn).append("-").append(lname);

            tpoTable.put(key.toString(), ownerNode);
          }
        }
      }
    }
  }


  // This method looks for a non-individual 3rd party owner.  If one
  // is found, move it to the begining of the borrowerList so that is
  // can be considered the primary borrower.  If none is found, the
  // applicant borrower will be the primary borrower.
  //
  private void adjustPrimaryBorrower(List<DataNode> borrowerList)
  {
    String nodeType, entityType;
    DataNode ownerNode;
    int index = -1;

    for (int i = 0, c = borrowerList.size(); i < c; ++i)
    {
      ownerNode = borrowerList.get(i);
      nodeType = ownerNode.getDataType();
      if (nodeType.equals(NodeUtils.ONR_DN_TYPE))
      {
        entityType = (String) ownerNode.getFieldData("", "OnrEntTypD");
        if (!entityType.equals("Individual"))
        {
          // Found a non-individual entity type.  Remember the index
          // of the owner node and move it to the front of the list.
          //
          index = i;
          break;
        }
      }
    }

    if (index != -1)
    {
      ownerNode = borrowerList.remove(index);
      borrowerList.add(0, ownerNode);
    }
  }
  

  // This method checks the product list against the "Monitored Products"
  // section in the configuration file.  This is only used for the
  // threaded process.  The on-demand book via the activity will use
  // the isProductQualified() method above.
  //
  private boolean isMonitoredProductQualified(SystemDataObject sdo, List log)
  {
    String prodID = super.getProductID(sdo);

    VectorX products = CONFIG.getSectionElements("Monitored Products");

    boolean qualified = prodID != null &&
        (products != null &&
         (products.contains("ALL") || products.contains(prodID)));

    if (!qualified)
    {
      log.add("Product " + prodID + " not qualified for Booking.");
    }

    return qualified;
  }


  private void codeTableFields(int branch, Map baseFields)
  {
    List codeTypes = CONFIG.getSectionElements("Code Table");
    if (codeTypes != null)
    {
      String codeType;
      Map table;
      for (int i = 0, c = codeTypes.size(); i < c; ++i)
      {
        codeType = (String) codeTypes.get(i);

        try
        {
          table = CSDataCache.getCodeTableManager().getDescTableForType(branch,
              codeType);
          if (table != null)
          {
            baseFields.put(codeType, table.toString());
          }
        }
        catch (SQLException e)
        {
        }
      }
    }
  }


  private void lastDecisionFields(DataNode appNode, Map baseFields)
  {
    DataNode lastDecision = DecisionUtils.getLastDecision(appNode);
    if (lastDecision != null)
    {
      Map decisionFields = lastDecision.getFieldData(getName());
      decisionFields.putAll(lastDecision.getSystemData());

      Iterator it = decisionFields.keySet().iterator();
      String key;
      Object val;

      while (it.hasNext())
      {
        key = (String) it.next();
        val = decisionFields.get(key);

        if (val instanceof String)
        {
          baseFields.put(key, val);
        }
        else if (val instanceof VectorX)
        {
          List list = new ArrayList();
          list.addAll( (VectorX) val);

          baseFields.put(key, createCommandStringFromList(list));
        }
      }
    }
  }


  private void totalBorrowerAnnualIncome(DataNode appNode, Map baseFields)
  {
    List borrowers = appNode.getReferences(NodeUtils.BWR_DN_TYPE);

    DataNode bwrNode;
    String grsMonInc;
    double totalInc = 0.0;

    for (int i = 0, c = borrowers.size(); i < c; ++i)
    {
      bwrNode = (DataNode) borrowers.get(i);
      if (!bwrNode.isDeleted())
      {
        grsMonInc = (String) bwrNode.getSystemData(CSFieldNames.
            FN_BWR_GRS_MON_INCOME);
        totalInc += (StringSupport.strToDouble(grsMonInc) * 12);
      }
    }

    baseFields.put("total_income", String.valueOf(totalInc));
  }


  private void firstRealEstateCollateral(List collateralList, Map baseFields)
  {
    boolean found = false;

    DataNode collNode;
    for (int i = 0, c = collateralList.size(); i < c; ++i)
    {
      collNode = (DataNode) collateralList.get(i);
      if (collNode.getDataType().equals(NodeUtils.RE_DN_TYPE))
      {
        baseFields.putAll(collNode.getFieldData(getName()));
        found = true;
        break;
      }
    }

    if (!found && !collateralList.isEmpty())
    {
      collNode = (DataNode) collateralList.get(0);
      baseFields.putAll(collNode.getFieldData(getName()));
    }
  }


  private void dealerFields(DataNode appNode, Map baseFields)
  {
    String dealerID = (String) appNode.getFieldData(getName(),
        CSFieldNames.FN_DEALER_ID);

    if (dealerID != null)
    {
      try
      {
        Map dealerFields = DBQueries.getDealerData(dealerID);
        baseFields.putAll(dealerFields);
      }
      catch (SQLException e)
      {
      }
    }
  }


  private void branchFields(int branchID, Map baseFields)
  {
    try
    {
      Map branchData = DBQueries.getBranchData(String.valueOf(branchID));
      baseFields.putAll(branchData);
    }
    catch (SQLException e)
    {
    }
  }


  private int indexOfThisBorrowerType(String bwrType, Map<String, Integer> bwrTypeCountTable)
  {
    if (bwrType == null) bwrType = "";

    Integer bwrTypeCounter = bwrTypeCountTable.get(bwrType);
    bwrTypeCounter = bwrTypeCounter == null ? new Integer(0) :
                                              new Integer(bwrTypeCounter + 1);

    bwrTypeCountTable.put(bwrType, bwrTypeCounter);

    return bwrTypeCounter;
  }


  private void trippedManagementRules(DataNode appNode, List borrowerList,
                                      Map baseFields)
  {
    List appLevelCodes = new ArrayList();

    DataNode dataNode;
    String code;

    // First get all application level rules that were tripped.
    // We just need to get the code.
    //
    List mrList = appNode.getReferences(NodeUtils.MR_RES_DN_TYPE);
    if (mrList != null)
    {
      for (int i = 0, c = mrList.size(); i < c; ++i)
      {
        dataNode = (DataNode) mrList.get(i);
        if (!dataNode.isDeleted())
        {
          code = (String) dataNode.getFieldData(getName(), "code");
          appLevelCodes.add(code);
        }
      }
    }

    List mrCodes = new ArrayList();
    mrCodes.addAll(appLevelCodes);

    // Now grab the borrower level rules that were tripped.
    //
    DataNode bwrNode;
    for (int i = 0, c = borrowerList.size(); i < c; ++i)
    {
      bwrNode = (DataNode) borrowerList.get(i);
      if (!bwrNode.isDeleted())
      {
        mrList = bwrNode.getEffectiveReferences(NodeUtils.MR_RES_DN_TYPE);
        for (int j = 0, d = mrList.size(); j < d; ++j)
        {
          dataNode = (DataNode)mrList.get(j);
          code = (String) dataNode.getFieldData(getName(), "code");
          if (code != null) mrCodes.add(code);
        }
      }
    }

    // Now grab the combined borrower's rules that were tripped.
    //
    List cmbBwrList = appNode.getEffectiveReferences(NodeUtils.CMB_BWR_DN_TYPE);
    for (int i = 0, c = cmbBwrList.size(); i < c; ++i)
    {
      bwrNode = (DataNode)cmbBwrList.get(i);
      mrList = bwrNode.getEffectiveReferences(NodeUtils.MR_RES_DN_TYPE);
      for (int j = 0, d = mrList.size(); j < d; ++j)
      {
        dataNode = (DataNode)mrList.get(j);
        code = (String)dataNode.getFieldData(getName(), "code");
        if (code != null) mrCodes.add(code);
      }
    }

    List decPartyCodes = new ArrayList();
    decPartyCodes.addAll(appLevelCodes);

    // Now grab a list of codes for the decision party.  We will store this
    // list in a different field name.
    //
    try
    {
      DataNode decParty = CSUtil.getDecisionParty(appNode);
      mrList = decParty.getReferences(NodeUtils.MR_RES_DN_TYPE);
      if (mrList != null)
      {
        for (int i = 0, c = mrList.size(); i < c; ++i)
        {
          dataNode = (DataNode) mrList.get(i);
          if (!dataNode.isDeleted())
          {
            code = (String) dataNode.getFieldData(getName(), "code");
            decPartyCodes.add(code);
            mrCodes.add(code);
          }
        }
      }
    }
    catch (Exception e)
    {
      ExceptionLogger.logException(e);
    }

    baseFields.put("!mgtRules", createCommandStringFromList(mrCodes));
    baseFields.put("!mgtRulesDP", createCommandStringFromList(decPartyCodes));
  }


  private void addMiscFields(DataNode appNode, Map fields)
  {
    VectorX miscFields = DBQueries.buildUserDefinedFieldsTable(appNode);
    VectorX cols = null;

    for (int i = 1, c = miscFields.size(); i < c; ++i)
    {
      cols = (VectorX) miscFields.get(i);

      fields.put( (String) cols.get(3), (String) cols.get(1));
    }
  }


  private void generatePreProcessFields(Map baseFields)
  {
    VectorX[] preprocessItems = CONFIG.getSectionPropertyKeyValues("pre-process");
    if (preprocessItems != null)
    {
      String targetField, line;

      List keys = preprocessItems[0];
      List values = preprocessItems[1];

      for (int i = 0, c = keys.size(); i < c; ++i)
      {
        targetField = (String)keys.get(i);
        line = (String)values.get(i);

        if (targetField.equals(line))
        {
          // Special condition.  Load a map structure from somewhere
          // else in the configuration file.
          //
          Map map = CONFIG.getSectionProperties(line);
          if (map != null)
          {
            baseFields.put(line, map.toString());
          }
        }
        else
        {
          line = StringSupport.substituteTags(line, baseFields);
          line = CmdEvaluator.evaluate(line);

          baseFields.put(targetField, line);
        }
      }
    }
  }


  private void generateProductSpecificFields(String productID, Map baseFields)
  {
    VectorX[] mapping = CONFIG.getSectionPropertyKeyValues(productID);
    if (mapping != null)
    {
      String targetField, line;

      List keys = mapping[0];
      List values = mapping[1];

      for (int i = 0, c = keys.size(); i < c; ++i)
      {
        targetField = (String)keys.get(i);
        line = (String)values.get(i);

        line = StringSupport.substituteTags(line, baseFields);
        line = CmdEvaluator.evaluate(line);

        baseFields.put(targetField, line);
      }
    }
  }


  private void generateCallSpecificFields(String call, Map fields)
  {
    //general.errLog( "START generateCallSpecificFields(String call, Map fields)", "CallSpecFlds.log" );
    //general.errLog( "call: "+call,"CallSpecFlds.log" );
    //general.errLog( "fields: "+fields, "CallSpecFlds.log" );
    
    Map<String, String> mapping = CONFIG.getSectionProperties(call);
    if (mapping != null)
    {
      String targetField, line;
      
      Iterator<String> it = mapping.keySet().iterator();      
      while (it.hasNext())
      {
        targetField = it.next();
        line = mapping.get(targetField);
        
        if (line.length() > 0)
        {
          //general.errLog( "line: "+line, "CallSpecFlds.log" );

          line = StringSupport.substituteTags(line, fields);
          line = CmdEvaluator.evaluate(line);
          
          if (line.length() > 0)
          {
              //general.errLog( "PUT targetField: "+targetField, "CallSpecFlds.log" );
              //general.errLog( "PUT line: "+line, "CallSpecFlds.log" );
            fields.put(targetField, line);
          }
        }
      }
    }
    
    //general.errLog( "fields: "+fields, "CallSpecFlds.log" );
    //general.errLog( "END generateCallSpecificFields(String call, Map fields)", "CallSpecFlds.log" );
  }
  

  private void contractTermsFields(DataNode appNode, Map baseFields)
  {
    DataNode contractTerms = appNode.getReference(NodeUtils.CNTRCT_DN_TYPE, 0);
    if (contractTerms != null)
    {
      baseFields.putAll(contractTerms.getFieldData(getName()));
      baseFields.putAll(contractTerms.getSystemData());
    }
  }


  private String createCommandStringFromList(List list)
  {
    String command = null;

    if (list.isEmpty())
    {
      command = "";
    }
    else
    {
      command = list.toString();
      command = command.substring(1, command.length() - 1);
      command = command.replaceAll(", ", ",");
    }

    return command;
  }
  
  
  @Override
  protected List getProductListing()
  {
    return PRODUCTS;
  }


  private void initializeTrustManager()
  {
    // Create a trust manager that does not validate certificate chains
    //
    TrustManager[] trustAllCerts = new TrustManager[]
    {
      new MyX509TrustManager()
    };

    try
    {
      SSLContext ssl = SSLContext.getInstance("TLS");
      ssl.init(null, trustAllCerts, null);
      SSLContext.setDefault(ssl);
    }
    catch (Exception e)
    {
      AdminGUIManager.displayE("Unable to initialize the TrustManager" + e);
      ExceptionLogger.logException(e);
    }
  }
  

  @Override
  public void initialize()
  {
    CONFIG = new Configuration();
    CONFIG.load(CFG_FILE);

    String str = CONFIG.getSectionProperty("Settings", "enabled");
    setEnabled(str != null && str.equals("true"));

    if (!isEnabled())
    {
      return;
    }

    str = CONFIG.getSectionProperty("Settings", "interval");
    setInterval(StringSupport.strToInt(str) * 60000);

    APPROVE_CODE = CONFIG.getSectionProperty("Settings", "approve");
    if (APPROVE_CODE == null)
    {
      APPROVE_CODE = "none";
    }

    DECLINE_CODE = CONFIG.getSectionProperty("Settings", "decline");
    if (DECLINE_CODE == null)
    {
      DECLINE_CODE = "none";
    }

    if (APPROVE_CODE.equals("none") && DECLINE_CODE.equals("none"))
    {
      AdminGUIManager.displayE("Approve and Decline actions set to none.");
      AdminGUIManager.displayE(getName() + " has been disabled.");
      setInterval(0);
    }

    str = CONFIG.getSectionProperty("Settings", "log");
    LOG = (str != null && str.equals("true"));
    if (LOG)
    {
      DataFile dir = new DataFile(ROOT_PATH);
      if (! dir.exists()) dir.mkdir();
      
      LOG_DIR = dir.getPath();
    }

    str = CONFIG.getSectionProperty("Settings", "log_transport");
    if (str != null && str.equals("true"))
    {
      System.setProperty("com.sun.xml.internal.ws.transport.http.client.HttpTransportPipe.dump", "true");
    }
    
    PRODUCTS = CONFIG.getSectionElements("Products");

    super.PRE_REQS = CONFIG.getSectionElements("Prerequisites");

    str = CONFIG.getSectionProperty("Settings", "disbursed");
    MUST_BE_DISBURSED = str != null && str.equals("true");

    final String fundedFlag = CONFIG.getSectionProperty("Settings", "must_be_funded");
    MUST_BE_FUNDED = "true".equals(fundedFlag);

    str = CONFIG.getSectionProperty("Settings", "preapprove");
    ALLOW_PREAPPROVE = str != null && str.equals("true");

    str = CONFIG.getSectionProperty("Settings", "check_closing_reqs");
    CHECK_CLOSING_REQS = str != null && str.equals("true");

    str = CONFIG.getSectionProperty("Settings", "use_decline_status");
    USE_DECLINE_STATUS = str != null && str.equals("true");

    str = CONFIG.getSectionProperty("Settings", "lookup_pricing_rate");
    LOOKUP_RATE = str != null && str.equals("true");

    String assignLoanNum = CONFIG.getSectionProperty("Settings", "assign_loan_num");
    ASSIGN_LOAN_NUM = assignLoanNum != null && assignLoanNum.equals("true");

    if (ASSIGN_LOAN_NUM)
    {
      String assignOnDecline = CONFIG.getSectionProperty("Settings", "loan_num_on_decline");
      LOAN_NUM_DECLINE = assignOnDecline != null && assignOnDecline.equals("true");
    }

    // JXChange specific configuration
    //
    str = CONFIG.getSectionProperty("JXC", "production");
    isProduction = str != null && str.equals("true");
    
    prodURL = CONFIG.getSectionProperty("JXC", "url_production");
    testURL = CONFIG.getSectionProperty("JXC", "url_test");
    jxcUsername = CONFIG.getSectionProperty("JXC", "username");    
    jxcPassword = CONFIG.getSectionProperty("JXC", "password");
    version = CONFIG.getSectionProperty("JXC", "version");
    auditUserId = CONFIG.getSectionProperty("JXC", "auditUserId");
    auditWsId = CONFIG.getSectionProperty("JXC", "auditWsId");
    consumerName = CONFIG.getSectionProperty("JXC", "consumerName");
    consumerProd = CONFIG.getSectionProperty("JXC", "consumerProd");
    trackingPrefix = CONFIG.getSectionProperty("JXC", "trackingPrefix");
    
    // Decrypt Password
    //
    try
    {
      jxcPassword = new AES().decrypt(jxcPassword, AESUtils.getInitVector(InitVector.JXC_BOOKING_PWD));
    }
    catch (final Exception e)
    {
      ExceptionLogger.logException(e);
      AdminGUIManager.displayE("Unable to decrypt JXC password.");
    }
  }
  
  
  @Override
  public void startupInitializer()
  {
    //initializeTrustManager();

    initialize();

    /*
    Booking.setBookingCartName(getName());
    Booking.setMultiselect(true);
    */

    // Start it up if interval is > 0.
    //
    if (getInterval() > 0)
    {
      AdminGUIManager.displayE(getName() + " interval is " +
                               (getInterval() / 60000) + " minute(s).");

      Thread thread = new Thread(SystemHouse.threadGroup, this,
                                 getName() + " (" + SystemHouse.getBankName() + ")");
      setThread(thread);
      thread.start();
    }
    
    SystemConfig.registerLog("JXCBookingMonitor", "StatusLogs", "data" + File.separator + ROOT_PATH, "Multiple");
  }

  private void addBorrowerInfo( DataNode appNode, List borrowerList, Map appFields )
  {
	//general.errLog( "START addBorrowerInfo( DataNode appNode, List borrowerList, Map appFields )", "JXC.log" );

    DataNode bwrNode;
    String index;

    int highRiskScore = 0;
    double totalHousing = 0.0;
    double totalMonthlyDebt = 0.0;

    // This map keeps track of how many of a certain borrower type there
    // is so we can create a field that contains the index of the type.
    // "Co-applicant 1, Co-applicant 2, Co-signer 1, etc."
    //
    Map bwrTypeCountTable = new HashMap();

    for( int i = 0, c = borrowerList.size(); i < c; ++i )
    {
      index = String.valueOf( i );

      bwrNode = ( DataNode ) borrowerList.get( i );

      String bwrType = ( String ) bwrNode.getFieldData( getName(), CSFieldNames.FN_BWR_TYPE );
   	  //general.errLog( "bwrType: "+bwrType, "JXC.log" );

      // Make all the borrower / owner fields available to the application
      // fields.
      //
      Map bwrData = bwrNode.getFieldData( getName() );
      bwrData.putAll( bwrNode.getSystemData() );

      String fieldName;
      Object obj;
      Iterator it = bwrData.keySet().iterator();
      while( it.hasNext() )
      {
        fieldName = ( String ) it.next();
        obj = bwrData.get( fieldName );

        if( obj instanceof String )
        {
          appFields.put( fieldName + "_" + index, ( String ) obj );
        }
      }

      if( bwrNode.getDataType().equals( NodeUtils.BWR_DN_TYPE ) )
      {
        // Must total up the monthly debt and monthly housing payment for
        // all borrowers on the loan.
        //
        totalMonthlyDebt += AppCalcs.calculateMonthlyDebt( appNode, bwrNode, true, false, false );
     	//general.errLog( "totalMonthlyDebt: "+totalMonthlyDebt, "JXC.log" );

        totalHousing += DecisionUtils.getHousingPayment( bwrNode );
   	    //general.errLog( "totalHousing: "+totalHousing, "JXC.log" );

        // Use highest riskScore out of Applicant and Co-applicants.
        // Ignore Co-signers and guarantors.
        //
        if( bwrType.equals( "Applicant" ) || bwrType.equals( "Co-applicant" ) )
        {
          String riskScore = ( String ) bwrNode.getSystemData( CSFieldNames.FN_BWR_CB_SCORE );
          int score = StringSupport.strToInt( riskScore );
          if( score > highRiskScore )
          {
            highRiskScore = score;
       	    //general.errLog( "highRiskScore: "+highRiskScore, "JXC.log" );
          }
        }
      }

      int bwrTypeIndex = indexOfThisBorrowerType( bwrType, bwrTypeCountTable );
      //general.errLog( "bwrTypeIndex: "+bwrTypeIndex, "JXC.log" );

      appFields.put( "bwrIndex_" + index, index );
      appFields.put( "bwrTypeIndex_" + index, String.valueOf( bwrTypeIndex ) );
    }

    appFields.put( "highest_risk_score", String.valueOf( highRiskScore ) );
    appFields.put( "total_monthly_debt", String.valueOf( totalMonthlyDebt ) );
    appFields.put( "total_monthly_housing", String.valueOf( totalHousing ) );
    
	//general.errLog( "END addBorrowerInfo( DataNode appNode, List borrowerList, Map appFields )", "JXC.log" );
  }

  /*
   * Both of the elements that you are testing are 5 in length with 4 decimal positions.  The value input must include a decimal
     On the OrigLnToValRatio, input would be .7493 for the core to populate 74.93 and the TotDebtPct would need to be 3.2
     to populate 32.000 on the core
  */     
  private String formatLTVRatio( String field )
  {
    //general.errLog( "START String formatLTVRatio( String field )", "JXC.log" );

    DecimalFormat df = new DecimalFormat( "0.0000" );

    String tempVal = null;
    String tempFieldStr = null;

    if( field != null && field.trim().length() > 0 )
    {
      // remove leading zeros
      double fldVal = Double.parseDouble( field );
      System.out.println( "fldVal: " + fldVal );

      if( fldVal >= 100 )
      {
        field = "1.000";
      }
      else if( fldVal >= 10 && fldVal < 100 )
      {
        tempFieldStr = String.valueOf( fldVal );
        tempVal = StringSupport.removeEmbeddedString( tempFieldStr, "." );
        field = "0." + tempVal;
      }
      else if( fldVal >= 1 && fldVal < 10 )
      {
        tempFieldStr = String.valueOf( fldVal );
        tempVal = StringSupport.removeEmbeddedString( tempFieldStr, "." );
        field = "0.0" + tempVal;
      }
      else if( fldVal >= 0.1 && fldVal < 1 )
      {
        tempFieldStr = String.valueOf( fldVal );
        tempVal = StringSupport.removeEmbeddedString( tempFieldStr, "." );
        field = "0.00" + tempVal;
      }

      //general.errLog( "field: " + field, "JXC.log" );
      field = df.format( Double.parseDouble( field ) );
      //general.errLog( "formatted field: " + field, "JXC.log" );
    }

    //general.errLog( "return field: "+field, "JXC.log" );
    //general.errLog( "END String formatDebtRatio( String field )", "JXC.log" );

    return field;
  }

  
  /**
   * Replace the password in the ini file
   *
   * @param pwd
   *          - clear password to be saved in ini file
   * @return true - if passwd was saved ok, otherwise false
   */
  public static boolean savePasswordToIni(final String pwd) {
    final Configuration cfg = new Configuration();
    cfg.load(CFG_FILE);
    boolean isOk = false;
    try {
      cfg.setSectionProperty("JXC", "password",
          new AES().encrypt(pwd, AESUtils.getInitVector(InitVector.JXC_BOOKING_PWD)));
      cfg.setSectionProperty("JXC", "is_password_encrypted", "true");
      cfg.store(cfg.getFileName());
      isOk = true;
    } catch (final Exception e) {
      ExceptionLogger.logException(e);
    }
    return isOk;
  }

  /**
   * Utility: replaced clear password from ini files with encrypted one
   *
   * @return true - if passwd was saved ok, otherwise false
   */
  public static boolean encryptClearPassword() {
    final Configuration cfg = new Configuration();
    cfg.load(CFG_FILE);
    boolean isOk = false;
    String pwd = cfg.getSectionProperty("JXC", "password");
    final String isEncrypted = cfg.getSectionProperty("JXC", "is_password_encrypted");
    if (pwd != null && !"true".equalsIgnoreCase(isEncrypted)) {
      try {
        pwd = new AES().encrypt(pwd, AESUtils.getInitVector(InitVector.JXC_BOOKING_PWD));
        cfg.setSectionProperty("JXC", "password", pwd);
        cfg.setSectionProperty("JXC", "is_password_encrypted", "true");
        cfg.store(cfg.getFileName());
        isOk = true;
      } catch (final Exception e) {
        ExceptionLogger.logException(e);
      }
    }
    return isOk;
  }


  //  CKD TESTING... FOR WHICH WE ARE TRULY GRATEFUL...
  //
/*
  public static void main( String[] args )
  {
    DecimalFormat df = new DecimalFormat( "0.0000" );

    String field = "55";
    System.out.println( "field: " + field );

    String tempVal = null;
    String tempFieldStr = null;

    if( field != null && field.trim().length() > 0 )
    {
      // remove leading zeros
      double fldVal = Double.parseDouble(field);
      System.out.println( "fldVal: " + fldVal );

      if( fldVal >= 100  )
      {
        field = "1.000";
      }
      else if( fldVal >= 10 && fldVal < 100 )
      {
        tempFieldStr = String.valueOf( fldVal );
        System.out.println( "tempFieldStr: " + tempFieldStr );
        
        int index = tempFieldStr.indexOf( "." );
        if( index != -1 )
        {
          String bfrDec  = tempFieldStr.substring( 0, index );
          System.out.println( "bfrDec: " + bfrDec) ;

          String aftrDec = tempFieldStr.substring( index +1 );
          System.out.println( "aftrDec: " + aftrDec );
        }


        tempVal = StringSupport.removeEmbeddedString( tempFieldStr, "." );
        System.out.println( "tempVal: " + tempVal );
        
        // field = "0." + tempVal;
        field = tempFieldStr;
      }
      else if( fldVal >= 1 && fldVal < 10 )
      {
        tempFieldStr = String.valueOf( fldVal );
        System.out.println( "tempFieldStr: " + tempFieldStr );

        tempVal = StringSupport.removeEmbeddedString( tempFieldStr, "." );
        System.out.println( "tempVal: " + tempVal );

        field = "0.0" + tempVal;
      }
      else if( fldVal >= 0.1 && fldVal < 1 )
      {
        tempFieldStr = String.valueOf( fldVal );
        System.out.println( "tempFieldStr: " + tempFieldStr );

        tempVal = StringSupport.removeEmbeddedString( tempFieldStr, "." );
        System.out.println( "tempVal: " + tempVal );

        field = "0.00" + tempVal;
      }

      System.out.println( "return field: " + field );
      field = df.format( Double.parseDouble(field) );
      System.out.println( "return formatted field: " + field );
    }
  }
*/

} // public class JXCBookingMonitor extends BookingMonitor
