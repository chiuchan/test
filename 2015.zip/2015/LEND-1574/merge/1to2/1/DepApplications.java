/**
 * Title:        DepApplications
 * Description:
 * Copyright:    Copyright (c) 2012
 * Company:      S1 Corporation, Inc
 * @author Len Doerich
 * @version 1.0
*/


import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

import com.xnai.credisphere.calcs.DepCalcs;
import com.xnai.credisphere.dataCache.CSDataCache;
import com.xnai.credisphere.dataCache.SDODataCache;
import com.xnai.credisphere.depProduct.DepProduct;
import com.xnai.credisphere.deposits.DataEntryValidator;
import com.xnai.credisphere.deposits.DepUtils;
import com.xnai.credisphere.util.CSFieldNames;
import com.xnai.credisphere.util.CSFieldValues;
import com.xnai.credisphere.util.CSStatusCodes;
import com.xnai.credisphere.util.CSUtil;
import com.xnai.credisphere.util.DataEntrySupport;
import com.xnai.credisphere.util.DataValidation;
import com.xnai.credisphere.util.DecisionUtils;
import com.xnai.credisphere.util.NodeUtils;
import com.xnai.credisphere.util.SDOUtils;
import com.xnai.credisphere.util.XSellUtils;
import com.xnai.credisphere.util.XVectorExtractor;
import com.xnai.credisphere.vistaPop.VistaPopUtils;
import com.xnai.mulder.systemCore.AdminGUIManager;
import com.xnai.mulder.systemObject.DataNode;
import com.xnai.mulder.systemObject.SystemDataObject;
import com.xnai.mulder.user.NotifyUser;
import com.xnai.mulder.user.User;
import com.xnai.mulder.user.UserSession;
import com.xnai.mulder.util.ClientUtils;
import com.xnai.mulder.util.DateUtility;
import com.xnai.mulder.util.ExceptionLogger;
import com.xnai.mulder.util.FormLoader;
import com.xnai.mulder.util.HashtableX;
import com.xnai.mulder.util.StringSupport;
import com.xnai.mulder.util.VectorX;
import com.xnai.mulder.visual.Form;
import com.xnai.mulder.visual.TableTransaction;
import com.xnai.net.XCSRequest;
import com.xnai.net.XCSResponse;
import com.xnai.net.xResponse;


public class DepApplications extends XCartridge
{
  private static final String DA_IRA_ID = "daIRAId";
private static final String OP_CODE_DEL_OD_ASSOC_ACCT = "DelODAssocAcct";
private static final String OP_CODE_ADD_OD_ASSOC_ACCT = "AddODAssocAcct";
private static final String OP_CODE_DEL_ACCT_HOLDER = "DelAcctHolder";
private static final String OP_CODE_ADD_ACCT_HOLDER = "AddAcctHolder";
private static final String OP_CODE_REPORT_DETAILS = "ReportDetails";
private static final String OP_CODE_SCORE_DETAILS = "ScoreDetails";
private static final String OP_CODE_VIEW_DECISION = "ViewDecision";
private static final String OP_CODE_FINISH = "Finish";
private static final String OP_CODE_DEF_PRD_INFO = "DefPrdInfo";
private static final String OP_CODE_GET_PRODUCT_INFO = "GetProductInfo";
private static final String OP_CODE_ADD_BWR = "AddBwr";
private static final String OP_CODE_EDIT_BWR = "EditBwr";
private static final String OP_CODE_DEL_BWR = "DelBwr";
private static final String OP_CODE_SAVE_BWR = "SaveBwr";
private static final String OP_CODE_CANCEL_BWR = "CancelBwr";
private static final String OP_CODE_ADD_PR = "AddPR";
private static final String OP_CODE_EDIT_PR = "EditPR";
private static final String OP_CODE_DEL_PR = "DelPR";
private static final String OP_CODE_SAVE_PR = "SavePR";
private static final String OP_CODE_CANCEL_PR = "CancelPR";
private static final String OP_CODE_SAVE = "Save";
private static final String OP_CODE_SAVE_BEFORE_REDECISION = "SaveBeforeRedecision";
private static final String OP_CODE_SAVE_PART = "SavePart";
private static final String OP_CODE_SUBMIT = "Submit";
private static final String OP_CODE_ABANDON_APP = "AbandonApp";
private static final String OP_CODE_REVIEW_APP = "ReviewApp";
private static final String OP_CODE_EDIT = "Edit";
private static final String OP_CODE_CHANGE_STATUS = "ChangeStatus";
private static final String OP_CODE_CANCEL = "Cancel";
private static final String OP_CODE_EDIT_PG_OFFER = "EditPGOffer";
private static final String OP_CODE_CANCEL_SUB_FORM = "CancelSubForm";
private static final String OP_CODE_SAVE_PG = "SavePG";
private static final String OP_CODE_DISCARD_PG = "DiscardPG";
private static final String OP_CODE_ADD_FUNDING = "AddFunding";
private static final String OP_CODE_EDIT_FUNDING = "EditFunding";
private static final String OP_CODE_DEL_FUNDING = "DelFunding";
private static final String OP_CODE_SAVE_FUNDING = "SaveFunding";
private static final String OP_CODE_ADD_POD = "AddPOD";
private static final String OP_CODE_EDIT_POD = "EditPOD";
private static final String OP_CODE_DEL_POD = "DelPOD";
private static final String OP_CODE_SAVE_POD = "SavePOD";
private static final String OP_CODE_SAVE_IRA = "SaveIRA";
private static final String OP_CODE_DEL_IRA = "DelIRA";
private static final String OP_CODE_EDIT_IRA = "EditIRA";
private static final String OP_CODE_ADD_IRA = "AddIRA";



public DepApplications()
  {
    super();

    getOpCodes().add("DefProdInfo");
    getOpCodes().add(OP_CODE_GET_PRODUCT_INFO);
    getOpCodes().add(OP_CODE_ADD_BWR);
    getOpCodes().add(OP_CODE_EDIT_BWR);
    getOpCodes().add(OP_CODE_DEL_BWR);
    getOpCodes().add(OP_CODE_SAVE_BWR);
    getOpCodes().add(OP_CODE_CANCEL_BWR);
    getOpCodes().add(OP_CODE_ADD_PR);
    getOpCodes().add(OP_CODE_EDIT_PR);
    getOpCodes().add(OP_CODE_DEL_PR);
    getOpCodes().add(OP_CODE_SAVE_PR);
    getOpCodes().add(OP_CODE_CANCEL_PR);
    getOpCodes().add(OP_CODE_SAVE_PART);
    getOpCodes().add(OP_CODE_SUBMIT);
    getOpCodes().add(OP_CODE_ABANDON_APP);
    getOpCodes().add(OP_CODE_REVIEW_APP);
    getOpCodes().add(OP_CODE_EDIT);
    getOpCodes().add(OP_CODE_SAVE);
    getOpCodes().add(OP_CODE_SAVE_BEFORE_REDECISION);
    getOpCodes().add(OP_CODE_CANCEL);
    getOpCodes().add(OP_CODE_EDIT_PG_OFFER);
    getOpCodes().add(OP_CODE_SAVE_PG);
    getOpCodes().add(OP_CODE_DISCARD_PG);
    getOpCodes().add(OP_CODE_ADD_FUNDING);
    getOpCodes().add(OP_CODE_EDIT_FUNDING);
    getOpCodes().add(OP_CODE_DEL_FUNDING);
    getOpCodes().add(OP_CODE_SAVE_FUNDING);
    getOpCodes().add(OP_CODE_ADD_POD);
    getOpCodes().add(OP_CODE_EDIT_POD);
    getOpCodes().add(OP_CODE_DEL_POD);
    getOpCodes().add(OP_CODE_SAVE_POD);
    getOpCodes().add(OP_CODE_FINISH);
    getOpCodes().add(OP_CODE_CANCEL_SUB_FORM);
    getOpCodes().add(OP_CODE_VIEW_DECISION);
    getOpCodes().add(OP_CODE_REPORT_DETAILS);
    getOpCodes().add(OP_CODE_SCORE_DETAILS);
    getOpCodes().add(OP_CODE_ADD_ACCT_HOLDER);
    getOpCodes().add(OP_CODE_DEL_ACCT_HOLDER);
    getOpCodes().add(OP_CODE_ADD_OD_ASSOC_ACCT);
    getOpCodes().add(OP_CODE_DEL_OD_ASSOC_ACCT);

    setName(getClass().getName());
  }


  public Object doOpCode(String opcode, Object obj)
  {
    VectorX inVec = (VectorX)obj;

    if (opcode.equals(OP_CODE_DEF_PRD_INFO))
    {
      return opCodeDefPrdInfo(inVec);
    }

    if (opcode.equals(OP_CODE_GET_PRODUCT_INFO))
    {
      return opCodeGetProductInfo(inVec);
    }

    if (opcode.equals(OP_CODE_ADD_BWR))
    {
      return opCodeAddOrEditBwr(inVec, false);
    }

    if (opcode.equals(OP_CODE_EDIT_BWR))
    {
      return opCodeAddOrEditBwr(inVec, true);
    }

    if (opcode.equals(OP_CODE_DEL_BWR))
    {
      return opCodeDelBwr(inVec);
    }

    if (opcode.equals(OP_CODE_SAVE_BWR))
    {
      return opCodeSaveBwr(inVec);
    }

    if (opcode.equals(OP_CODE_CANCEL_BWR))
    {
      return opCodeCancelBwr(inVec);
    }

    if (opcode.equals(OP_CODE_ADD_PR))
    {
      return opCodeAddOrEditPR(inVec, true);
    }

    if (opcode.equals(OP_CODE_EDIT_PR))
    {
      return opCodeAddOrEditPR(inVec, false);
    }

    if (opcode.equals(OP_CODE_DEL_PR))
    {
      return opCodeDelPR(inVec);
    }

    if (opcode.equals(OP_CODE_SAVE_PR))
    {
      return opCodeSavePR(inVec);
    }

    if (opcode.equals(OP_CODE_CANCEL_PR))
    {
      return opCodeCancelPR(inVec);
    }

    if (opcode.equals(OP_CODE_SAVE_PART) ||
        opcode.equals(OP_CODE_SAVE))
    {
      return opCodeSaveOrSubmit(inVec, false, false);
    }

    if (opcode.equals(OP_CODE_SAVE_BEFORE_REDECISION))
    {
      return opCodeSaveOrSubmit(inVec, false, true);
    }
    if (opcode.equals(OP_CODE_SUBMIT))
    {
      return opCodeSaveOrSubmit(inVec, true, false);
    }

    if (opcode.equals(OP_CODE_ABANDON_APP))
    {
      return opCodeAbandonApp(inVec);
    }

    if (opcode.equals(OP_CODE_REVIEW_APP))
    {
      return opCodeOpenApp(inVec, "Underwriting_Review.DA");
    }

    if (opcode.equals(OP_CODE_EDIT))
    {
      return opCodeOpenApp(inVec, "View_Application.DA");
    }

    if (opcode.equals(OP_CODE_CHANGE_STATUS))
    {
      return opCodeOpenApp(inVec, "ChangeStatus.DA");
    }

    if (opcode.equals(OP_CODE_CANCEL))
    {
      return opCodeCancel(inVec, true, true);
    }

    if (opcode.equals(OP_CODE_EDIT_PG_OFFER))
    {
      return opCodeEditPGOffer(inVec);
    }

    if (opcode.equals(OP_CODE_CANCEL_SUB_FORM))
    {
      return opCodeCancel(inVec, false, false);
    }

    if (opcode.equals(OP_CODE_SAVE_PG))
    {
      return opCodeSavePG(inVec);
    }

    if (opcode.equals(OP_CODE_DISCARD_PG))
    {
      return opCodeDiscardPG(inVec);
    }

    if (opcode.equals(OP_CODE_ADD_FUNDING))
    {
      return opCodeAddOrEditFunding(inVec, true);
    }

    if (opcode.equals(OP_CODE_EDIT_FUNDING))
    {
      return opCodeAddOrEditFunding(inVec, false);
    }

    if (opcode.equals(OP_CODE_DEL_FUNDING))
    {
      return opCodeDelFunding(inVec);
    }

    if (opcode.equals(OP_CODE_SAVE_FUNDING))
    {
      return opCodeSaveFunding(inVec);
    }

    if (opcode.equals(OP_CODE_ADD_POD))
    {
      return opCodeAddOrEditPOD(inVec, true);
    }

    if (opcode.equals(OP_CODE_EDIT_POD))
    {
      return opCodeAddOrEditPOD(inVec, false);
    }

    if (opcode.equals(OP_CODE_DEL_POD))
    {
      return opCodeDelPOD(inVec);
    }

    if (opcode.equals(OP_CODE_SAVE_POD))
    {
      return opCodeSavePOD(inVec);
    }

    if (opcode.equals(OP_CODE_ADD_IRA))
    {
      return opCodeAddOrEditIRA(inVec, true);
    }

    if (opcode.equals(OP_CODE_EDIT_IRA))
    {
      return opCodeAddOrEditIRA(inVec, false);
    }

    if (opcode.equals(OP_CODE_DEL_IRA))
    {
      return opCodeDelIRA(inVec);
    }

    if (opcode.equals(OP_CODE_SAVE_IRA))
    {
      return opCodeSaveIRA(inVec);
    }

    if (opcode.equals(OP_CODE_FINISH))
    {
      return opCodeFinish(inVec);
    }

    if (opcode.equals(OP_CODE_VIEW_DECISION))
    {
      return opCodeViewDecision(inVec);
    }

    if (opcode.equals(OP_CODE_SCORE_DETAILS))
    {
      return opCodeScoreDetails(inVec);
    }

    if (opcode.equals(OP_CODE_REPORT_DETAILS))
    {
      return opCodeReportDetails(inVec);
    }

    if (opcode.equals(OP_CODE_ADD_ACCT_HOLDER))
    {
      return opCodeAddOrDelAcctHolder(inVec, true);
    }

    if (opcode.equals(OP_CODE_DEL_ACCT_HOLDER))
    {
      return opCodeAddOrDelAcctHolder(inVec, false);
    }

    if (opcode.equals(OP_CODE_ADD_OD_ASSOC_ACCT))
    {
      return opCodeAddOrDelODAssocAcct(inVec, true);
    }

    if (opcode.equals(OP_CODE_DEL_OD_ASSOC_ACCT))
    {
      return opCodeAddOrDelODAssocAcct(inVec, false);
    }

    xResponse res = new xResponse();
    res.errCode = 1;
    res.param.add("doOpCode ==> Invalid OpCode: " + opcode);
    return res;
  }


  private xResponse opCodeDefPrdInfo(VectorX inVec)
  {
    xResponse res = new xResponse();

    String username = null;
    HashtableX inFields = null;

    try
    {
      username = ClientUtils.getUsername(inVec);
      inFields = ClientUtils.getFieldsHash(inVec);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Error with incoming data.");
      return res;
    }

    User user = User.getUser(username);
    if (user == null)
    {
      res.errCode = 202;
      res.param.add("Unable to load user '" + username + "'");
      return res;
    }

    String productID = (String)inFields.get(CSFieldNames.FN_PRODUCT_ID);

    UserSession session = user.getUserSession();
    session.setAttribute("primary_product", productID);

    DepProduct product = CSDataCache.getDepProductManager().getProduct(productID);
    if (product == null)
    {
      res.errCode = 202;
      res.param.add("Unable to load product: " + productID);
      return res;
    }

    VectorX productList = null;

    try
    {
      productList = VistaPopUtils.getProductListing(username, user.getBaseLocationID(), null, true);
    }
    catch (SQLException e)
    {
      ExceptionLogger.logException(e);
      res.errCode = 202;
      res.param.add("Error getting product list: " + e);
      return res;
    }

    // Generate a new list of products for the Product Requests vista.  This list of
    // products should not include the first product selected on the Application Information
    // vista.
    //
    String prodItem;
    for (int i = 0, c = productList.size(); i < c; ++i)
    {
      prodItem = (String)productList.get(i);
      if (prodItem.length() > 0)
      {
        int tokenIndex = prodItem.indexOf(ClientUtils.TOKEN);

        if (prodItem.substring(0, tokenIndex).equals(productID))
        {
          productList.remove(i);
          break;
        }
      }
    }

    TableTransaction tt = null;//generateProductRequestTable(product);

    HashtableX fields = new HashtableX();
    fields.put("_anProdT", tt);
    fields.put("_anProdD", productList);

    HashtableX response = super.createClientResponse((Form)null, fields, null);

    res.param.add(response);
    return res;
  }


  private xResponse opCodeGetProductInfo(VectorX inVec)
  {
    xResponse res = new xResponse();

    String username = null;
    HashtableX inFields = null;

    try
    {
      username = ClientUtils.getUsername(inVec);
      inFields = ClientUtils.getFieldsHash(inVec);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Error with incoming data.");
      return res;
    }

    String productID = (String)inFields.get(CSFieldNames.FN_PRODUCT_ID);
    if (productID == null)
    {
      productID = (String)inFields.get("_anProdD");
    }

    if (productID == null)
    {
      return res;
    }

    DepProduct product = CSDataCache.getDepProductManager().getProduct(productID);
    if (product == null)
    {
      res.errCode = 202;
      res.param.add("Unable to load product: " + productID);
      return res;
    }

    String details = getProductDetails(product);

    res.errCode = 200;
    res.param.add(details);
    return res;
  }


  private xResponse opCodeAddOrEditBwr(VectorX inVec, boolean isEdit)
  {
    xResponse res = new xResponse();

    String username = null;
    HashtableX inFields = null;

    try
    {
      username = ClientUtils.getUsername(inVec);
      inFields = ClientUtils.getFieldsHash(inVec);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Error with incoming data.");
      return res;
    }

    String appID = (String)inFields.get(CSFieldNames.FN_APP_ID_HID);
    if (appID == null)
    {
      res.errCode = 202;
      res.param.add("appID not sent in trigger (anIdHid).");
      return res;
    }

    String applicantIndex = null;

    if (isEdit)
    {
      VectorX vec = (VectorX)inFields.get("anBorrowerSmyL");
      if (vec == null)
      {
        applicantIndex = (String)inFields.get("anBwrT");

        if (applicantIndex == null)
        {
          res.errCode = 202;
          res.param.add("Please select an account holder to delete.");
          return res;
        }
      }
      else
      {
        applicantIndex = (String)vec.get(0);
      }
    }

    String anFormHid = (String)inFields.get(CSFieldNames.FN_RETURN_FORM);

    String formName = (anFormHid != null && anFormHid.startsWith("Under")) ? "Add_Borrower_to_Summary.UW.DA" : "Add_Borrower_to_Summary.DA";
    Form form = FormLoader.loadForm(formName);
    if (form == null)
    {
      res.errCode = 202;
      res.param.add("Unable to load form '" + formName + "'");
      return res;
    }

    boolean isCache = SDOUtils.isCache(anFormHid);

    SystemDataObject sdo = null;

    try
    {
      sdo = isCache ? SDODataCache.getSDO(username, appID) : SDOUtils.getSDO(appID);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Unable to load application '" + appID + "': " + e);
      return res;
    }

    if (sdo == null)
    {
      res.errCode = 202;
      res.param.add("Unable to locate application data for ID '" + appID + "'.");
      return res;
    }

    String editMode = (String)inFields.get(CSFieldNames.FN_EDIT_MODE);
    boolean readOnly = editMode != null && editMode.equals("view");

    DataNode appNode = sdo.getNodeData( NodeUtils.APP_DN_TYPE );

    HashtableX fields = new HashtableX();

    if (isEdit)
    {
      // DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);

      DataNode applicantNode = appNode.getReference(NodeUtils.BWR_DN_TYPE, Integer.parseInt(applicantIndex));

      if (applicantNode == null)
      {
        res.errCode = 202;
        res.param.add("Error: unable to locate applicant #" + applicantIndex + " in the data.");
        return res;
      }

      fields.putAll(applicantNode.getFieldData(username));
    }

    fields.put(CSFieldNames.FN_APP_ID_HID, appID);
    fields.put(CSFieldNames.FN_RETURN_FORM, anFormHid);
    fields.put(CSFieldNames.FN_EDIT_MODE, editMode);

    if (applicantIndex != null) fields.put(CSFieldNames.FN_BWR_POS_HID, applicantIndex);

    try
    {
      DepUtils.populateMainForm(username, form, sdo, fields, false);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add(e.getMessage());
      return res;
    }

    HashtableX instHash = new HashtableX();
    if (readOnly)
    {
      DataEntrySupport.setAllVistasReadOnly(form, instHash);
      DepUtils.enableTheseButtonsWhenAppIsLocked(instHash);
    }
    else
    {
      instHash = DataEntrySupport.loadInstructionHash( appNode, instHash, formName );
    }

    HashtableX response = super.createClientResponse( username, form, fields, instHash );

    res.param.add(response);
    return res;
  }


  private xResponse opCodeDelBwr(VectorX inVec)
  {
    xResponse res = new xResponse();

    String username = null;
    HashtableX inFields = null;

    try
    {
      username = ClientUtils.getUsername(inVec);
      inFields = ClientUtils.getFieldsHash(inVec);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Error with incoming data.");
      return res;
    }

    String applicantIndex = null;

    VectorX vec = (VectorX)inFields.get("anBorrowerSmyL");
    if (vec == null)
    {
      applicantIndex = (String)inFields.get("anBwrT");

      if (applicantIndex == null)
      {
        res.errCode = 202;
        res.param.add("Please select an account holder to delete.");
        return res;
      }
    }
    else
    {
      applicantIndex = (String)vec.get(0);
    }

    String appID = (String)inFields.get(CSFieldNames.FN_APP_ID_HID);
    if (appID == null)
    {
      res.errCode = 202;
      res.param.add("appID not sent in trigger (anIdHid).");
      return res;
    }

    String anFormHid = (String)inFields.get(CSFieldNames.FN_RETURN_FORM);
    boolean isCache = SDOUtils.isCache(anFormHid);

    SystemDataObject sdo = null;

    try
    {
      sdo = isCache ? SDODataCache.getSDO(username, appID) : SDOUtils.getSDO(appID);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Unable to load application '" + appID + "': " + e);
      return res;
    }

    if (sdo == null)
    {
      res.errCode = 202;
      res.param.add("Unable to locate application data for ID '" + appID + "'.");
      return res;
    }

    DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);

    // Don't allow removing the Applicant.
    //
    DataNode applicant = appNode.getReference(NodeUtils.BWR_DN_TYPE, Integer.parseInt(applicantIndex));
    if (applicant == null)
    {
      res.errCode = 202;
      res.param.add("Error: Unable to find data for applicant index #" + applicantIndex);
      return res;
    }

    String bwrType = (String)applicant.getFieldData(username, CSFieldNames.FN_BWR_TYPE);
    if (bwrType != null && bwrType.equals(CSFieldValues.FV_APPLICANT))
    {
      res.errCode = 200;
      res.param.add("The Applicant cannot be deleted.");
      return res;
    }

    // Before removing the co-applicant, we need to check the products on the
    // application and make sure the co-applicant is not a part of the product.
    // If so, stop the delete and pop up a message instructing the user to
    // unlink the co-applicant from any products they are tied to.
    //
    StringBuilder productsMsg = new StringBuilder();
    List<DataNode> depAccounts = appNode.getEffectiveReferences(NodeUtils.DEP_ACCOUNT_DN_TYPE);
    for (DataNode depAccount : depAccounts)
    {
      VectorX aah = (VectorX)depAccount.getSystemData(CSFieldNames.FN_SYS_DEP_ADD_ACCT_HLDRS);
      if (aah != null && aah.contains(applicantIndex))
      {
        String productID = (String)depAccount.getFieldData(username, CSFieldNames.FN_DEP_PROD_ID);
        DepProduct product = CSDataCache.getDepProductManager().getProduct(productID);

        // We have a co-applicant on this product.
        //
        productsMsg.append("Product: ").append(product.getName()).append("\n");
      }
    }

    if (productsMsg.length() > 0)
    {
      StringBuilder msg = new StringBuilder();
      msg.append("The co-applicant is a joint party on the following product(s)\n");
      msg.append("Please remove the co-applicant from the products before deleting:\n\n");
      msg.append(productsMsg);

      res.errCode = 202;
      res.param.add(msg.toString());
      return res;
    }

    appNode.deleteReference(NodeUtils.BWR_DN_TYPE, Integer.parseInt(applicantIndex));

    HashtableX fields = new HashtableX();

    if (anFormHid != null && anFormHid.equals("Underwriting_Review.DA"))
    {
      List<String> vistasToRefresh = new ArrayList<String>();
      vistasToRefresh.add("Account_Holders.DA");
      vistasToRefresh.add("Fraud_and_Verification_Reports");

      try
      {
        DepUtils.populateSpecificVistas(username, vistasToRefresh, sdo, fields);
      }
      catch (Exception e)
      {
        String msg = e.getMessage();
        if (msg == null)
        {
          ExceptionLogger.logException(e);
          msg = "Error refreshing the form data: " + e.toString();
        }

        res.errCode = 202;
        res.param.add(msg);
        return res;
      }
    }
    else
    {
      VectorX applicantDescList = DataEntrySupport.buildBorrowerDescriptionsList(appNode);
      fields.put("anBorrowerSmyL", applicantDescList);
    }

    if (isCache)
    {
      SDODataCache.setSDOTable(username, appID, sdo);
    }
    else
    {
      try
      {
        SDOUtils.saveSDO(username, sdo, CSStatusCodes.SDO_LOCK);
      }
      catch (SQLException e)
      {
        res.errCode = 202;
        res.param.add("Unable to save application: "  + e);
        return res;
      }
    }

    HashtableX response = super.createClientResponse((Form)null, fields, null);

    res.param.add(response);
    return res;
  }


  private xResponse opCodeSaveBwr(VectorX inVec)
  {
    xResponse res = new xResponse();

    String username = null;
    HashtableX inFields = null;

    try
    {
      username = ClientUtils.getUsername(inVec);
      inFields = ClientUtils.getFieldsHash(inVec);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Error with incoming data.");
      return res;
    }

    String appID = (String)inFields.get(CSFieldNames.FN_APP_ID_HID);
    if (appID == null)
    {
      res.errCode = 202;
      res.param.add("appID not sent in trigger (anIdHid).");
      return res;
    }
    String dob = (String)inFields.get(CSFieldNames.FN_BIRTH_DT);
    res = DataValidation.validateDate(dob);

    if (res.errCode != 0)
    {
      return res;
    }

    // If there is an applicant index available, then we are editing
    // an applicant.
    //
    String applicantIndexStr = (String)inFields.get(CSFieldNames.FN_BWR_POS_HID);
    int applicantIndex = applicantIndexStr == null ? -1 : Integer.parseInt(applicantIndexStr);

    String editMode = (String)inFields.get(CSFieldNames.FN_EDIT_MODE);
    boolean readOnly = editMode != null && editMode.equals(CSFieldValues.FV_EDIT_MODE_VIEW);
    if (readOnly)
    {
      res.errCode = 202;
      res.param.add("Unable to save application.  The application is in read only mode.");
      return res;
    }

    String anFormHid = (String)inFields.get(CSFieldNames.FN_RETURN_FORM);
    boolean isCache = SDOUtils.isCache(anFormHid);

    SystemDataObject sdo = null;

    try
    {
      sdo = isCache ? SDODataCache.getSDO(username, appID) : SDOUtils.getSDO(appID);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Unable to load application '" + appID + "': " + e);
      return res;
    }

    if (sdo == null)
    {
      res.errCode = 202;
      res.param.add("Unable to locate application data for ID '" + appID + "'.");
      return res;
    }

    DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);

    try
    {
      DepUtils.saveApplicantData(username, applicantIndex, sdo, inFields);
    }
    catch (Exception e)
    {
      ExceptionLogger.logException(e);
      String msg = e.getMessage();
      if (msg == null) msg = e.toString();

      res.errCode = 202;
      res.param.add(msg);
      return res;
    }

    HashtableX fields = new HashtableX();

    if (anFormHid != null && anFormHid.equals("Underwriting_Review.DA"))
    {
      List<String> vistasToRefresh = new ArrayList<String>();
      vistasToRefresh.add("Account_Holders.DA");
      vistasToRefresh.add("Decision_History.DA");
      vistasToRefresh.add("Current_System_Recommended_Decision.DA");
      vistasToRefresh.add("Fraud_and_Verification_Reports");

      try
      {
        DepUtils.populateSpecificVistas(username, vistasToRefresh, sdo, fields);
      }
      catch (Exception e)
      {
        res.errCode = 202;
        res.param.add(e.getMessage());
        return res;
      }
    }
    else
    {
      VectorX applicantDescList = DataEntrySupport.buildBorrowerDescriptionsList(appNode);
      fields.put("anBorrowerSmyL", applicantDescList);
    }

    if (isCache)
    {
      SDODataCache.setSDOTable(username, appID, sdo);
    }
    else
    {
      try
      {
        SDOUtils.saveSDO(username, sdo, CSStatusCodes.SDO_LOCK);
      }
      catch (SQLException e)
      {
        res.errCode = 202;
        res.param.add("Unable to save application: "  + e);
        return res;
      }
    }

    HashtableX response = super.createClientResponse((Form)null, fields, null);

    res.param.add(response);
    return res;
  }




  private xResponse opCodeCancelBwr(VectorX inVec)
  {
    // used in underwriting to refresh vistas
    xResponse res = new xResponse();

    String username = null;
    HashtableX inFields = null;

    try
    {
      username = ClientUtils.getUsername( inVec );
      inFields = ClientUtils.getFieldsHash( inVec );
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add( "Error with incoming data." );
      return res;
    }

    String appID = (String)inFields.get( CSFieldNames.FN_APP_ID_HID );
    if (appID == null)
    {
      res.errCode = 202;
      res.param.add( "appID not sent in trigger (anIdHid)." );
      return res;
    }

    // If there is an applicant index available, then we are editing
    // an applicant.
    //
    String applicantIndexStr = (String)inFields.get( CSFieldNames.FN_BWR_POS_HID );
    int applicantIndex = applicantIndexStr == null ? -1 : Integer.parseInt( applicantIndexStr );

    // 08/27/2012
    //
    if (applicantIndexStr == null)
    {
      applicantIndexStr = Integer.toString( applicantIndex );
    }

    String anFormHid = (String)inFields.get( CSFieldNames.FN_RETURN_FORM );
    boolean isCache = SDOUtils.isCache( anFormHid );

    SystemDataObject sdo = null;

    try
    {
      sdo = isCache ? SDODataCache.getSDO( username, appID ) : SDOUtils.getSDO( appID );
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add( "Unable to load application '" + appID + "': " + e );
      return res;
    }

    if (sdo == null)
    {
      res.errCode = 202;
      res.param.add( "Unable to locate application data for ID '" + appID + "'." );
      return res;
    }

    HashtableX fields = new HashtableX();
    fields.put( CSFieldNames.FN_BWR_POS_HID, applicantIndexStr );

    List<String> vistasToRefresh = new ArrayList<String>();
    vistasToRefresh.add( "Account_Holders.DA" );
    vistasToRefresh.add( "Decision_History.DA" );
    vistasToRefresh.add( "Current_System_Recommended_Decision.DA" );

    try
    {
      DepUtils.populateSpecificVistas( username, vistasToRefresh, sdo, fields );
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add( e.getMessage() );
      return res;
    }

    HashtableX response = super.createClientResponse( (Form)null, fields, null );

    res.param.add( response );

    return( res );

  } // opCodeCancelBwr



/*
  private xResponse opCodeAddPR(VectorX inVec)
  {
    xResponse res = new xResponse();

    String username = null;
    HashtableX inFields = null;

    try
    {
      username = ClientUtils.getUsername(inVec);
      inFields = ClientUtils.getFieldsHash(inVec);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Error with incoming data.");
      return res;
    }

    String appID = (String)inFields.get(CSFieldNames.FN_APP_ID);
    if (appID == null)
    {
      res.errCode = 202;
      res.param.add("appID not sent in trigger (anAppId).");
      return res;
    }

    String productID = (String)inFields.get("_anProdD");
    if (productID == null)
    {
      res.errCode = 202;
      res.param.add("Please select a product to add.");
      return res;
    }

    SystemDataObject sdo = SDODataCache.getSDO(username, appID);
    if (sdo == null)
    {
      res.errCode = 202;
      res.param.add("Unable to locate application data in the cache for ID '" + appID + "'.");
      return res;
    }

    DataNode depAccountNode = sdo.createDataNode(username, NodeUtils.DEP_ACCOUNT_DN_TYPE);
    depAccountNode.setFieldData(username, CSFieldNames.FN_DEP_PROD_ID, productID);

    DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);
    appNode.addReference(depAccountNode);

    TableTransaction tt = DepUtils.generateProductRequestTable(appNode);

    HashtableX fields = new HashtableX();
    fields.put("_anProdT", tt);

    HashtableX response = super.createClientResponse((Form)null, fields, null);

    res.param.add(response);
    return res;
  }
*/


  private xResponse opCodeAddOrEditPR(VectorX inVec, boolean isAdd)
  {
	//log("START opCodeAddOrEditPR(VectorX inVec, boolean isAdd)");  
	//log("boolean isAdd: "+isAdd);  

	XVectorExtractor.saveVector(inVec);
    xResponse res = new xResponse();

    String username = null;
    HashtableX inFields = null;

    try
    {
      username = ClientUtils.getUsername(inVec);
      inFields = ClientUtils.getFieldsHash(inVec);
      //log("inFields: "+inFields);  
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Error with incoming data.");
      return res;
    }

    User user = User.getUser(username);
    if (user == null)
    {
      res.errCode = 202;
      res.param.add("Unable to load user '" + username + "'");
      return res;
    }

    UserSession session = user.getUserSession();

    String appID = (String)inFields.get(CSFieldNames.FN_APP_ID);
    if (appID == null)
    {
      res.errCode = 202;
      res.param.add("appID not sent in trigger (anAppId).");
      return res;
    }

    String editMode = (String)inFields.get(CSFieldNames.FN_EDIT_MODE);
    boolean readOnly = editMode != null && editMode.equals(CSFieldValues.FV_EDIT_MODE_VIEW);

    String anFormHid = (String)inFields.get(CSFieldNames.FN_RETURN_FORM);
    if (anFormHid == null)
    {
      res.errCode = 202;
      res.param.add("Data Error: _anFormHid not sent.");
      return res;
    }

    boolean isCache = SDOUtils.isCache(anFormHid);

    String depAcctIndex = null;
    String productID = null;
    boolean addingProdGroup = false;

    if (isAdd)
    {
      productID = (String)inFields.get("_anProdD");
      if (productID == null)
      {
        res.errCode = 202;
        res.param.add("Please select a product from the dropdown listbox.");
        return res;
      }

      if (productID.startsWith("---"))
      {
        res.errCode = 202;
        res.param.add("Please select a product or a product offer.");
        return res;
      }

      int indexOfColon = productID.indexOf(':');
      String productType = productID.substring(0, indexOfColon);
      productID = productID.substring(indexOfColon + 1);

      // If we are adding a product group, then load a different form and fill the table
      // with the individual products that make up the group.
      //
      if (productType.equals("pg"))
      {
        addingProdGroup = true;
      }
    }
    else
    {
      String keyStr = (String)inFields.get("_anProdT");
      if (keyStr == null || keyStr.length() == 0)
      {
        res.errCode = 202;
        res.param.add("Please select a product in the table.");
        return res;
      }

      String[] keys = keyStr.split(String.valueOf(ClientUtils.TOKEN));
      depAcctIndex = keys[0];
      productID = keys[1];

      session.setAttribute("dep_acct_index", depAcctIndex);
    }

    String formName = addingProdGroup ? "Product_Offer_Details.DA" : "Account_Details.DA";
    Form form = FormLoader.loadForm(formName);
    if (form == null)
    {
      res.errCode = 202;
      res.param.add("Unable to load form '" + formName + "'");
      return res;
    }

    DataNode appNode = null;
    HashtableX fields;

    if (addingProdGroup)
    {
      fields = new HashtableX();

      // Create a list of DataNode's that represent the individual products that need to
      // have information collected for.
      //
      Map<String, String[]> details;
      try
      {
        details = DepUtils.getProductGroupDetails(productID);
      }
      catch (SQLException e)
      {
        res.errCode = 202;
        res.param.add("Unable to get product group details: " + e);
        return res;
      }

      // Setup an empty list for storing the funding data while adding a product.
      // Also setup an empty list for storing the associated account of an overdraft
      // product.
      //
      Set<String> individualProdIDs = details.keySet();
      for (String individualProdID : individualProdIDs)
      {
        List<DataNode> fundingData = new ArrayList<DataNode>();
        session.setAttribute(DepUtils.FUNDING_NODES + ":" + individualProdID, fundingData);

        List<DataNode> feeData = new ArrayList<DataNode>();
        session.setAttribute(DepUtils.FEE_NODES + ":" + individualProdID, feeData);

        List<DataNode> podData = new ArrayList<DataNode>();
        List<DataNode> iraData = new ArrayList<DataNode>();
        session.setAttribute(DepUtils.POD_NODES + ":" + individualProdID, podData);
        session.setAttribute(DepUtils.IRA_NODES + ":" + individualProdID, iraData);

        boolean isOverdraftProduct = false;
        try
        {
          isOverdraftProduct = DepUtils.isOverdraftProduct(individualProdID);
        }
        catch (Exception e)
        {
          ExceptionLogger.logException(e);
          res.errCode = 202;
          res.param.add("Error determining if product '" + individualProdID + "' is an overdraft: " + e);
          return res;
        }

        if (isOverdraftProduct)
        {
          List<DataNode> associatedAccounts = new ArrayList<DataNode>();
          session.setAttribute(DepUtils.OVERDRAFT_ASSOC_ACCT_KEY + ":" + individualProdID, associatedAccounts);
        }
      }

      StringBuilder groupDesc = new StringBuilder();
      List<DataNode> tempDepAcctNodes = createTempDepAcctNodesForGroupRequest(details, groupDesc);

      TableTransaction tt = DepUtils.generateProductGroupRequestTable(tempDepAcctNodes);
      fields.put("_anProdT", tt);
      fields.put("xpgro", groupDesc.toString());
      fields.put("_daPrdGrpId", productID);

      session.setAttribute(DepUtils.PRD_GRP_SESSION_KEY, tempDepAcctNodes);
    }
    else // Adding an individual product.
    {
      SystemDataObject sdo = null;

      try
      {
        sdo = isCache ? SDODataCache.getSDO(username, appID) : SDOUtils.getSDO(appID);
      }
      catch (Exception e)
      {
        res.errCode = 202;
        res.param.add("Unable to load application '" + appID + "'.");
        return res;
      }

      if (sdo == null)
      {
        res.errCode = 202;
        res.param.add("Unable to locate application data in the cache for ID '" + appID + "'.");
        return res;
      }

      appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);

      // Are we adding or editing an overdraft product?
      //
      boolean isOverdraftProd = false;
      try
      {
        isOverdraftProd = DepUtils.isOverdraftProduct(productID);
      }
      catch (Exception e)
      {
        ExceptionLogger.logException(e);
        res.errCode = 202;
        res.param.add("Error determining if product is an overdraft: " + e);
        return res;
      }

      if (isAdd)
      {
        fields = new HashtableX();

        // Setup an empty list for storing the funding data while adding a product.
        //
        List<DataNode> fundingData = new ArrayList<DataNode>();
        session.setAttribute(DepUtils.FUNDING_NODES + ":" + productID, fundingData);

        // Setup an empty list for storing the fee data while adding a product.
        //
        List<DataNode> feeData = new ArrayList<DataNode>();
        session.setAttribute(DepUtils.FEE_NODES + ":" + productID, feeData);

        // Setup an empty list for storing the payable on death data while adding a product.
        //
        List<DataNode> podData = new ArrayList<DataNode>();
        List<DataNode> iraData = new ArrayList<DataNode>();
        session.setAttribute(DepUtils.POD_NODES + ":" + productID, podData);
        session.setAttribute(DepUtils.IRA_NODES + ":" + productID, iraData);

        // Setup an empty list for storing the associated account nodes while adding the overdraft
        // product.  (Do this only if we are adding an overdraft product).
        //
        if (isOverdraftProd)
        {
          List<DataNode> associatedAccounts = new ArrayList<DataNode>();
          session.setAttribute(DepUtils.OVERDRAFT_ASSOC_ACCT_KEY + ":" + productID, associatedAccounts);
        }
      }
      else
      {
        int index = Integer.parseInt(depAcctIndex);
        DataNode depAccountNode = appNode.getReference(NodeUtils.DEP_ACCOUNT_DN_TYPE, index);
        if (depAccountNode == null)
        {
          res.errCode = 202;
          res.param.add("Unable to locate depAccount data node at index '" + index + "'");
          return res;
        }

        // session.setAttribute("dep_acct_index", depAcctIndex);

        fields = depAccountNode.getFieldData(username);
        //log("fields: "+fields);

        // Setup a list of existing funding data nodes for display in the funding table.
        //
        List<DataNode> fundingData = depAccountNode.getEffectiveReferences(NodeUtils.DEP_FUNDING_DN_TYPE);
        List<DataNode> tempFundingData = new ArrayList<DataNode>();

        // Make copies of the data nodes, because any edits are not committed until the user saves the
        // product.  A cancel will abandon any changes.
        //
        for (DataNode fundingNode : fundingData)
        {
          tempFundingData.add(fundingNode.copy());
        }

        session.setAttribute(DepUtils.FUNDING_NODES + ":" + productID, tempFundingData);

        // Setup a list of existing fee data nodes for display in the fee table.
        //
        List<DataNode> feeData = depAccountNode.getEffectiveReferences(NodeUtils.FEE_DN_TYPE);
        List<DataNode> tempfeeData = new ArrayList<DataNode>();

        // Make copies of the data nodes, because any edits are not committed until the user saves the
        // product.  A cancel will abandon any changes.
        //
        for (DataNode feeNode : feeData)
        {
          tempfeeData.add(feeNode.copy());
        }

        session.setAttribute(DepUtils.FEE_NODES + ":" + productID, tempfeeData);

        // Setup a list of existing payable on death data nodes for display in the payable on death table.
        //
        List<DataNode> podData = depAccountNode.getEffectiveReferences(NodeUtils.DEP_POD_DN_TYPE);
        List<DataNode> tempPODData = new ArrayList<DataNode>();

        // Make copies of the data nodes, because any edits are not committed until the user saves the
        // product.  A cancel will abandon any changes.
        //
        for (DataNode podNode : podData)
        {
          tempPODData.add(podNode.copy());
        }

        session.setAttribute(DepUtils.POD_NODES + ":" + productID, tempPODData);

        List<DataNode> iraData = depAccountNode.getEffectiveReferences(NodeUtils.DEP_IRA_DN_TYPE);
        List<DataNode> tempIRAData = new ArrayList<DataNode>();

        // Make copies of the data nodes, because any edits are not committed until the user saves the
        // product.  A cancel will abandon any changes.
        //
        for (DataNode iraNode : iraData)
        {
          tempIRAData.add(iraNode.copy());
        }

        session.setAttribute(DepUtils.IRA_NODES + ":" + productID, tempIRAData);

        // If overdraft product... setup a list of existing overdraft associated account nodes for
        // display in the table.
        //
        if (isOverdraftProd)
        {
          List<DataNode> associatedAccounts = depAccountNode.getEffectiveReferences(NodeUtils.DEP_OD_LINK_DN_TYPE);
          List<DataNode> tempAssociatedAccounts = new ArrayList<DataNode>();

          // Make copies of the data nodes, because any edits are not committed until the user saves the
          // product.  A cancel will abandon any changes.
          //
          for (DataNode associatedAccount : associatedAccounts)
          {
            tempAssociatedAccounts.add(associatedAccount.copy());
          }

          session.setAttribute(DepUtils.OVERDRAFT_ASSOC_ACCT_KEY + ":" + productID, tempAssociatedAccounts);
        }

        // We need to place the additional account holder vector and the relationship map into the
        // user session for the vista populator to work from.  The vista populator for the
        // additional account holder vista looks to the user session to build the table transaction
        // from.
        //
        List<String> aahList = (List<String>)depAccountNode.getSystemData(CSFieldNames.FN_SYS_DEP_ADD_ACCT_HLDRS);
        if (aahList != null)
        {
          // Must make a copy so that the original does not get altered during edits.
          //
          List<String> aahListCopy = new VectorX();
          aahListCopy.addAll(aahList);
          session.setAttribute(DepUtils.ADDL_ACCT_HLDR_LIST_KEY + ":" + productID, aahListCopy);
        }

        Map<String, String> aahTitleMap = (Map<String, String>)depAccountNode.getSystemData(CSFieldNames.FN_SYS_DEP_TITLE_MAP);
        if (aahTitleMap != null)
        {
          // Must make a copy so that the original does not get altered during edits.
          //
          Map<String, String> aahTitleMapCopy = new HashtableX();
          aahTitleMapCopy.putAll(aahTitleMap);
          session.setAttribute(DepUtils.ADDL_ACCT_HLDR_REL_KEY + ":" + productID, aahTitleMapCopy);
        }
      }

      DepProduct product = CSDataCache.getDepProductManager().getProduct(productID);
      if (product == null)
      {
        res.errCode = 202;
        res.param.add("Unable to load product '" + productID + "'");
        return res;
      }

      
      // Don't show the fee vista if we are adding a product.  Default fees cannot
      // be created until a product has been saved.
      //
      if (! isAdd)
      {
        List possibleFees = product.getPsblFeesSel();
        if (possibleFees != null && !possibleFees.isEmpty())
        {
          // Insert the application fees vista under the account detail
          // vista.
          //
          form.getVistas().add(0, "Application_Fees.DA");
        }
      }
      

      // Show the additional account holders vista if there are additional
      // applicants on the app.
      //
      List applicants = appNode.getEffectiveReferences(NodeUtils.BWR_DN_TYPE);
      if (applicants.size() == 1)
      {
        form.getVistas().remove("Additional_Account_Holders.DA");
      }

      String appStatus = SDOUtils.getSDOStatus(sdo);
      if (CSStatusCodes.SC_INCOMPLETE_APP.equals(appStatus) || CSStatusCodes.INCOMPLETE_WEB_APP.equals(appStatus)) {
    	  form.getVistas().remove("Funding.DA");
      }

      // Need to set this system field to tell the vista populator what the current add/edit
      // product ID is.  It will be used to fill the dropdown on the account details vista.
      //
      fields.put("_anProdTypeD", productID);

      if ("Account_Details.DA".equals(formName) && "true".equals(product.isPrdQualC())) {
      	form.getVistas().add("IRA_Beneficiary_Summary");
      } else {
    	form.getVistas().remove("IRA_Beneficiary_Summary");
      }

      if ("Account_Details.DA".equals(formName) && "true".equals(product.isPrdPayOnDeathC())) {
        form.getVistas().add("Payable_On_Death_Summary");
      } else {
  	    form.getVistas().remove("Payable_On_Death_Summary");
      }

      try
      {
    	//log("DepUtils.populateAccountForm(username, form, sdo, product, fields: "+fields);
        DepUtils.populateAccountForm(username, form, sdo, product, fields);
      }
      catch (Exception e)
      {
        ExceptionLogger.logException(e);
        res.errCode = 202;
        res.param.add(e.getMessage());
        return res;
      }
    }

    fields.put(CSFieldNames.FN_RETURN_FORM, anFormHid);
    fields.put(CSFieldNames.FN_BWR_POS_HID, addingProdGroup ? "pg" : isAdd ? "a" : "e");
    fields.put(CSFieldNames.FN_EDIT_MODE, editMode);
    fields.put(CSFieldNames.FN_APP_ID, appID);

    HashtableX instructions = new HashtableX();
    instructions.put(CSFieldNames.FN_DEP_PROD_ID, ClientUtils.readonlyElement());

    if (readOnly)
    {
      DataEntrySupport.setAllVistasReadOnly(form, instructions);
      DepUtils.enableTheseButtonsWhenAppIsLocked(instructions);
    }
    else if (! addingProdGroup)
    {
      instructions = DataEntrySupport.loadInstructionHash(appNode, instructions, formName, productID);
    }

    HashtableX response = super.createClientResponse(form, fields, instructions);
    res.param.add(response);
  
	//log("END opCodeAddOrEditPR(VectorX inVec, boolean isAdd)");  

    return res;
  }


  private xResponse opCodeDelPR(VectorX inVec)
  {
    xResponse res = new xResponse();

    String username = null;
    HashtableX inFields = null;

    try
    {
      username = ClientUtils.getUsername(inVec);
      inFields = ClientUtils.getFieldsHash(inVec);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Error with incoming data.");
      return res;
    }

    String appID = (String)inFields.get(CSFieldNames.FN_APP_ID);
    if (appID == null)
    {
      res.errCode = 202;
      res.param.add("appID not sent in trigger (anAppId).");
      return res;
    }

    String anFormHid = (String)inFields.get(CSFieldNames.FN_RETURN_FORM);
    if (anFormHid == null)
    {
      res.errCode = 202;
      res.param.add("Data Error: _anFormHid not sent.");
      return res;
    }

    boolean isCache = SDOUtils.isCache(anFormHid);

    String keyStr = (String)inFields.get("_anProdT");
    if (keyStr == null || keyStr.length() == 0)
    {
      res.errCode = 202;
      res.param.add("Please select a product in the table.");
      return res;
    }

    boolean confirmDelete = inFields.containsKey("aeButtonConfirm") &&
                            ((String)inFields.get("aeButtonConfirm")).equals("800");

    String[] keys = keyStr.split(String.valueOf(ClientUtils.TOKEN));
    String depAcctIndexStr = keys[0];
    int depAcctIndex = Integer.parseInt(depAcctIndexStr);

    SystemDataObject sdo = null;

    try
    {
      sdo = isCache ? SDODataCache.getSDO(username, appID) : SDOUtils.getSDO(appID);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Unable to load application '" + appID + "'.");
      return res;
    }

    if (sdo == null)
    {
      res.errCode = 202;
      res.param.add("Unable to locate application data in the cache for ID '" + appID + "'.");
      return res;
    }

    DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);

    String incompleteFlag = (String)appNode.getSystemData(CSFieldNames.FN_SYS_DEP_INCOMPLETE_FLAG);
    boolean pastDataEntry = incompleteFlag != null && incompleteFlag.equals(CSFieldValues.FALSE_STRING);

    // Must check to see if the account being deleted is part of a group offer.  If it
    // is, we must delete all associated accounts in the offer.
    //
    boolean okToDelete = true;

    DataNode daToDelete = appNode.getReference(NodeUtils.DEP_ACCOUNT_DN_TYPE, depAcctIndex);
    if (daToDelete == null)
    {
      res.errCode = 202;
      res.param.add("Error: Unable to get account data node for index: " + depAcctIndex);
      return res;
    }

    String daPrdGrpID = (String)daToDelete.getSystemData(CSFieldNames.FN_SYS_DEP_PRD_GRP_ID);
    if (daPrdGrpID != null)
    {
      if (confirmDelete)
      {
        List<DataNode> matchingAccounts = getDepAccountsWithMatchingProductGroupID(daPrdGrpID, appNode);
        for (DataNode depAccount : matchingAccounts)
        {
          depAccount.delete();
        }

        // Set okToDelete to false, because we just deleted all dep accounts matching the
        // group ID (which includes the one selected from the table.
        //
        okToDelete = false;
      }
      else
      {
        // Now scan the other deposit account nodes to find any other that are associated with the
        // same group ID.  It is possible, that someone configured a product group that contains
        // only 1 product, and if that is the case, then we can go ahead and delete the account node.
        // If we find others, we must display a confirmation message informing the user that we
        // will delete all associated accounts.
        //
        int numMatches = getNumDepAccountsWithMatchingProductGroupID(daPrdGrpID, appNode);
        if (numMatches > 1)
        {
          // Deleting a product group.  Check to make sure we aren't deleting all the products
          // on the application.
          //
          if (pastDataEntry)
          {
            List<DataNode> accounts = appNode.getEffectiveReferences(NodeUtils.DEP_ACCOUNT_DN_TYPE);
            if (accounts.size() == numMatches)
            {
              res.errCode = 201;
              res.param.add("Unable to delete product: This product is part of a product offer.\n" +
                            "The other products that are a part of the offer would be deleted, but\n" +
                            "would leave the application with no products.  The application must have\n" +
                            "one or more products.");
              return res;
            }
          }

          // If we only have 1 match, it will be the account that is being deleted, and there
          // are no other accounts that are part of the group. We can go ahead and delete the account.
          // More than 1 match, then we must confirm with the user.
          //
          res.errCode = 800;
          res.param.add("The product being deleted is part of a product offer.\n" +
                        "Deleting this product will also delete all other products\n" +
                        "that are a part of the offer.  Would you like to continue?");
          return res;
        }
      }
    }
    else
    {
      // Not deleting a product belonging to a group offer.  But need to check and make sure that
      // this account being deleted is not tied to an overdraft product.
      //
      DataNode odAccount = null;

      try
      {
        odAccount = findOverdraftAccountTiedToThisAccount(appNode, daToDelete);
      }
      catch (Exception e)
      {
        ExceptionLogger.logException(e);
        res.errCode = 202;
        res.param.add("Error while looking for an overdraft account: " + e);
        return res;
      }

      if (odAccount != null)
      {
        // We found an overdraft account that is tied to the account that is being deleted.
        // If we confirmed the delete, then we can delete the account and the overdraft that
        // is tied to it.
        //
        // If we have not confirmed, then we must display a message.  If there are only 2 products
        // on the app (and we are past data entry), don't let the user delete the products.  We don't
        // want the application to have no products.
        //
        if (confirmDelete)
        {
          // Just delete the overdraft account... the main account will get deleted below.
          //
          odAccount.delete();
        }
        else
        {
          if (pastDataEntry)
          {
            List<DataNode> accounts = appNode.getEffectiveReferences(NodeUtils.DEP_ACCOUNT_DN_TYPE);
            if (accounts.size() == 2)
            {
              res.errCode = 201;
              res.param.add("Unable to delete product: This product is tied to an overdraft product\n" +
                            "which would get deleted as well, but would leave the application with\n" +
                            "no products.  The application must have one or more products.");
              return res;
            }
          }

          res.errCode = 800;
          res.param.add("The product being deleted is linked to an overdraft product.\n" +
                        "Deleting this product will also delete the overdraft product.\n" +
                        "Would you like to continue?");
          return res;
        }
      }
    }

    if (okToDelete)
    {
      // Deleting an individual product.  Check to ensure that if we are beyond the data entry
      // process, we are not deleting the last product.
      //
      if (pastDataEntry)
      {
        List<DataNode> accounts = appNode.getEffectiveReferences(NodeUtils.DEP_ACCOUNT_DN_TYPE);
        if (accounts.size() == 1)
        {
          res.errCode = 201;
          res.param.add("Unable to delete product:  There must be one or more products on the application.");
          return res;
        }
      }

      daToDelete.delete();
    }

    if (pastDataEntry)
    {
      // The highest priority account may have been removed from the product, so we need to
      // re-determine the highest priority account.
      //
      List<DataNode> accounts = appNode.getEffectiveReferences(NodeUtils.DEP_ACCOUNT_DN_TYPE);
      String highestPriorityProductID = null;

      try
      {
        highestPriorityProductID = DepUtils.findHighestPriorityAccount(username, accounts);
      }
      catch (Exception e)
      {
        ExceptionLogger.logException(e);
        res.errCode = 202;
        res.param.add("Error while determining highest priority product: " + e);
        return res;
      }

      appNode.setFieldData(username, CSFieldNames.FN_PRODUCT_ID, highestPriorityProductID);
    }

    if (isCache)
    {
      SDODataCache.setSDOTable(username, appID, sdo);
    }
    else
    {
      try
      {
        SDOUtils.saveSDO(username, sdo, CSStatusCodes.SDO_LOCK);
      }
      catch (SQLException e)
      {
        res.errCode = 202;
        res.param.add("Unable to save application: "  + e);
        return res;
      }
    }

    HashtableX fields = new HashtableX();

    List<String> vistasToPopulate = new ArrayList<String>();
    vistasToPopulate.add("Product_Requests.DA");

    try
    {
      DepUtils.populateSpecificVistas(username, vistasToPopulate, sdo, fields);
    }
    catch (Exception e)
    {
      String msg = e.getMessage();
      if (msg == null) msg = e.toString();

      res.errCode = 202;
      res.param.add(msg);
      return res;
    }

    HashtableX response = super.createClientResponse((Form)null, fields, null);

    res.param.add(response);
    return res;
  }


  private xResponse opCodeSavePR(VectorX inVec)
  {
	//log("START opCodeSavePR(VectorX inVec)");
    XVectorExtractor.saveVector(inVec);
    xResponse res = new xResponse();

    String username = null;
    HashtableX inFields = null;

    try
    {
      username = ClientUtils.getUsername(inVec);
      inFields = ClientUtils.getFieldsHash(inVec);
  	  //log("0 inFields: "+inFields);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Error with incoming data.");
      return res;
    }

    String editMode = (String)inFields.get(CSFieldNames.FN_EDIT_MODE);
    boolean readOnly = editMode != null && editMode.equals(CSFieldValues.FV_EDIT_MODE_VIEW);
    if (readOnly)
    {
      res.errCode = 202;
      res.param.add("Unable to save application.  The application is in read only mode.");
      return res;
    }

    String anFormHid = (String)inFields.get(CSFieldNames.FN_RETURN_FORM);
    if (anFormHid == null)
    {
      res.errCode = 202;
      res.param.add("Data Error: _anFormHid not sent.");
      return res;
    }

    String bwrPosHid = (String)inFields.get(CSFieldNames.FN_BWR_POS_HID);
    if (bwrPosHid == null)
    {
      res.errCode = 202;
      res.param.add("Data Error: _bwrPOSHid not sent.");
      return res;
    }

    boolean isSavingPG = bwrPosHid.equals("pg");
    boolean isAdd = bwrPosHid.equals("a");
    boolean isCache = SDOUtils.isCache(anFormHid);

    // Check the opening amount against the product configuration.
    //
    String productID = (String)inFields.get(CSFieldNames.FN_DEP_PROD_ID);
    DepProduct product = CSDataCache.getDepProductManager().getProduct(productID);
    if (product == null)
    {
      res.errCode = 202;
      res.param.add("Unable to load product ID: " + productID);
      return res;
    }

    String openAmountStr = (String)inFields.get("daOpenAmt");
    //log("openAmountStr: "+openAmountStr);

    double openAmount = StringSupport.strToDouble(openAmountStr);

    double minAmt = product.getPrdMinAmt();
    double maxAmt = product.getPrdMaxAmt();

    if (minAmt != 0 && openAmount < minAmt)
    {
      DecimalFormat df = new DecimalFormat("$#.00");

      res.errCode = 201;
      res.param.add("The opening amount does not meet the product minimum of " + df.format(minAmt));
      return res;
    }

    if (maxAmt != 0 && openAmount > maxAmt)
    {
      DecimalFormat df = new DecimalFormat("$#.00");

      res.errCode = 201;
      res.param.add("The opening amount exceeds the product maximum of " + df.format(maxAmt));
      return res;
    }

    User user = User.getUser(username);
    if (user == null)
    {
      res.errCode = 202;
      res.param.add("Unable to load user '" + username + "'");
      return res;
    }

    UserSession session = user.getUserSession();

    if (!checkIfPrimaryBeneficiariesShareOK(session, productID))
    {
      res.errCode = 202;
      res.param.add("Total Primary Beneficiary Percentage is not exactly 100.000%. Please change Primary Beneficiaries Share % values.");
      return res;
    }
    if (!checkIfContingentBeneficiariesShareOK(session, productID))
    {
      res.errCode = 202;
      res.param.add("Total Contingent Beneficiary Percentage is not fully defined. Please change Contingent Beneficiaries Share % values or remove ALL Contingent Beneficiaries.");
      return res;
    }
    if (!checkIfPodBeneficiariesShareOK(session, productID))
    {
      res.errCode = 202;
      res.param.add("Total POD Percentage is not fully defined. Please change POD Share % values or remove ALL POD Beneficiaries.");
      return res;
    }
    // If we are saving an overdraft product, check to ensure that there is at least one
    // linked account.
    //
    boolean isOverdraftProduct = false;
    try
    {
      isOverdraftProduct = DepUtils.isOverdraftProduct(productID);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Error while determining whether the product is an overdraft: " + e);
      return res;
    }

    if (isOverdraftProduct)
    {
      List<DataNode> associatedAccounts = (List<DataNode>)session.getAttribute(DepUtils.OVERDRAFT_ASSOC_ACCT_KEY + ":" + productID);
      if (associatedAccounts == null || associatedAccounts.isEmpty())
      {
        res.errCode = 201;
        res.param.add("Unable to save product: Please associate at least one account to this\n" +
                      "overdraft product using the Associated Accounts vista.");
        return res;
      }
    }

    int depAcctIndex = -1;
    if (isSavingPG || !isAdd)
    {
      String depAcctIndexStr = (String)session.getAttribute("dep_acct_index");
      if (depAcctIndexStr == null)
      {
        res.errCode = 202;
        res.param.add("Error: data node index for depAccounts type is not in the session.");
        return res;
      }

      depAcctIndex = Integer.parseInt(depAcctIndexStr);

      session.removeAttribute("dep_acct_index");
    }

    List<DataNode> individualProducts = null;
    if (isSavingPG)
    {
      individualProducts = (List<DataNode>)session.getAttribute(DepUtils.PRD_GRP_SESSION_KEY);
      if (individualProducts == null)
      {
        res.errCode = 202;
        res.param.add("Error: Individual product list not in user session.");
        return res;
      }

      // Put the list of individual products in the inFields hash.  DepUtils.saveProductRequestData
      // will update the temp depAccount data node if we are saving a product group offer.
      //
      inFields.put(DepUtils.PRD_GRP_SESSION_KEY, individualProducts);

      // If saving a product that's a part of a group, we can remove the temporary view of the
      // funding nodes.  The edits that were made (if any) are being saved.
      //
      session.removeAttribute(DepUtils.FUNDING_NODES + ".PG:" + productID);
      session.removeAttribute(DepUtils.FEE_NODES + ".PG:" + productID);

      // If saving a product that's a part of a group, we can remove the temporary view of the
      // payable on death nodes.  The edits that were made (if any) are being saved.
      //
      session.removeAttribute(DepUtils.POD_NODES + ".PG:" + productID);
      session.removeAttribute(DepUtils.IRA_NODES + ".PG:" + productID);

      // If saving a product that's a part of a group, we can remove the temporary view of the
      // associated account nodes.  The edits that were made (if any) are being saved.  I'm not
      // going to bother seeing if this is an overdraft product.  If the key isn't in the session
      // there's no harm in trying to remove it.  It won't exist if we are not saving an overdraft
      // product.
      //
      session.removeAttribute(DepUtils.OVERDRAFT_ASSOC_ACCT_KEY + ".PG:" + productID);

      // We can also remove the temporary view of the additional account holder data as the
      // edits are being saved.
      //
      session.removeAttribute(DepUtils.ADDL_ACCT_HLDR_LIST_KEY + ".PG:" + productID);
      session.removeAttribute(DepUtils.ADDL_ACCT_HLDR_REL_KEY + ".PG:" + productID);
    }

    String appID = (String)inFields.get(CSFieldNames.FN_APP_ID);
    if (appID == null)
    {
      res.errCode = 202;
      res.param.add("appID not sent in trigger (anAppId).");
      return res;
    }

    SystemDataObject sdo = null;

    try
    {
      sdo = isCache ? SDODataCache.getSDO(username, appID) : SDOUtils.getSDO(appID);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Unable to load application '" + appID + "'.");
      return res;
    }

    if (sdo == null)
    {
      res.errCode = 202;
      res.param.add("Unable to locate application data in the cache for ID '" + appID + "'.");
      return res;
    }

    try
    {
      //log("inFields: "+inFields);
      DepUtils.saveProductRequestData(username, depAcctIndex, sdo, inFields);
    }
    catch (Exception e)
    {
      ExceptionLogger.logException(e);
      String msg = e.getMessage();
      if (msg == null) msg = "Error saving product request: " + e.toString();

      res.errCode = 202;
      res.param.add(msg);
      return res;
    }

    DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);

    // With new products placed on the application, we may have a higher priority product on the
    // app now.  We need to re-determine the highest priority product and set the main product ID
    // field in the app node.
    //
    String incompleteFlag = (String)appNode.getSystemData(CSFieldNames.FN_SYS_DEP_INCOMPLETE_FLAG);
    boolean pastDataEntry = incompleteFlag != null && incompleteFlag.equals(CSFieldValues.FALSE_STRING);
    if (pastDataEntry && isAdd)
    {
      List<DataNode> accounts = appNode.getEffectiveReferences(NodeUtils.DEP_ACCOUNT_DN_TYPE);
      String highestPriorityProductID = null;

      try
      {
        highestPriorityProductID = DepUtils.findHighestPriorityAccount(username, accounts);
      }
      catch (Exception e)
      {
        ExceptionLogger.logException(e);
        res.errCode = 202;
        res.param.add("Error while determining highest priority product: " + e);
        return res;
      }

      appNode.setFieldData(username, CSFieldNames.FN_PRODUCT_ID, highestPriorityProductID);
    }

    String totalFundingAmt = null;
    String totalFundingAmtStr = null;
    String totalOpeningAmtStr = null;
    
    TableTransaction tt;
    
    if (isSavingPG)
    {
      tt = DepUtils.generateProductGroupRequestTable(individualProducts);
    }
    else
    {
      if (isCache)
      {
        SDODataCache.setSDOTable(username, appID, sdo);
      }
      else
      {
        try
        {
          SDOUtils.saveSDO(username, sdo, CSStatusCodes.SDO_LOCK);
        }
        catch (SQLException e)
        {
          ExceptionLogger.logException(e);	
          res.errCode = 202;
          res.param.add("Unable to save application: "  + e);
          return res;
        }
      }

      // Update the product request table.
      //
      tt = DepUtils.generateProductRequestTable(appNode);

      // Update the total funding amount field.
      //
      DepCalcs depCalcs = new DepCalcs(username, sdo);
      double totalFunding = depCalcs.calculateTotalAmountFunded(appNode);
      totalFundingAmt = String.valueOf(totalFunding);
      
      totalFundingAmtStr = String.valueOf(depCalcs.calculateTotalFundedAmount(appNode));    
  	  //log("totalFundingAmtStr: "+totalFundingAmtStr);
  	
      totalOpeningAmtStr = String.valueOf(depCalcs.calculateTotalOpeningAmount(appNode));
  	  //log("totalOpeningAmtStr: "+totalOpeningAmtStr);
    }

    HashtableX fields = new HashtableX();
    fields.put("_anProdT", tt);
    if (totalFundingAmt    != null) fields.put(CSFieldNames.FN_DEP_FUNDING_TOTAL, totalFundingAmt);    
    if (totalFundingAmtStr != null) fields.put("anTtlFundedAmt", totalFundingAmtStr);       
    if (totalOpeningAmtStr != null) fields.put("anTtlOpenAmt",   totalOpeningAmtStr);


    HashtableX response = super.createClientResponse((Form)null, fields, null);

    res.param.add(response);
  
	//log("END opCodeSavePR(VectorX inVec)");

    return res;
  }

  private boolean checkIfPodBeneficiariesShareOK(UserSession session,
		String productID) {
	  List<DataNode> podNodes = (List<DataNode>) session
				.getAttribute(DepUtils.POD_NODES + ":" + productID);
		String val = DepUtils.calculateTotalPercentInFieldForBeneficiaries(podNodes, CSFieldNames.FN_DEP_POD_BENE_SHARE);
		boolean ok = true;
		if (!podNodes.isEmpty()) {
			ok = Double.parseDouble(val) == 100;
		}
		return ok;
}


private boolean checkIfPrimaryBeneficiariesShareOK(UserSession session, String productId) {
	return checkIfShareOKForBeneficiariesWithDesignation(session, productId, "Primary");
  }

  private boolean checkIfContingentBeneficiariesShareOK(UserSession session, String productId) {
	return checkIfShareOKForBeneficiariesWithDesignation(session, productId, "Contingent");
  }

  private boolean checkIfShareOKForBeneficiariesWithDesignation(
		UserSession session, String productId, String designation) {
	  List<DataNode> iraNodes = (List<DataNode>) session
			.getAttribute(DepUtils.IRA_NODES + ":" + productId);
	int count = DepUtils.countBeneficiariesWithDesignation(iraNodes, designation);
	String val = DepUtils.calculateTotalPercentInFieldForBeneficiariesWithIraDesignation(iraNodes, CSFieldNames.FN_DEP_IRA_BENE_SHARE, designation);
	boolean ok = true;
	if (count > 0) {
		ok = Double.parseDouble(val) == 100;
	}
	return ok;
}


private xResponse opCodeCancelPR(VectorX inVec)
  {
    xResponse res = new xResponse();

    String username = null;
    HashtableX inFields = null;

    try
    {
      username = ClientUtils.getUsername(inVec);
      inFields = ClientUtils.getFieldsHash(inVec);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Error with incoming data.");
      return res;
    }

    // I'm using the _bwrPOSHid field to let me know if we are cancelling a product from a group.
    //
    String bwrPOSHid = (String)inFields.get(CSFieldNames.FN_BWR_POS_HID);
    if (bwrPOSHid == null)
    {
      res.errCode = 202;
      res.param.add("Data Error: _bwrPOSHid not sent.");
      return res;
    }

    User user = User.getUser(username);
    if (user == null)
    {
      res.errCode = 202;
      res.param.add("Unable to load user '" + username + "'");
      return res;
    }

    UserSession session = user.getUserSession();
    String productID = (String)inFields.get(CSFieldNames.FN_DEP_PROD_ID);

    // If we are cancelling a product edit that is part of a product offer, we need to restore the
    // previous view of the funding nodes.
    //
    boolean isCancellingPG = bwrPOSHid.equals("pg");
    if (isCancellingPG)
    {
      List<DataNode> fundingNodes = (List<DataNode>)session.getAttribute(DepUtils.FUNDING_NODES + ".PG:" + productID);
      if (fundingNodes != null)
      {
        session.setAttribute(DepUtils.FUNDING_NODES + ":" + productID, fundingNodes);
        session.removeAttribute(DepUtils.FUNDING_NODES + ".PG:" + productID);
      }

      List<DataNode> feeNodes = (List<DataNode>)session.getAttribute(DepUtils.FEE_NODES + ".PG:" + productID);
      if (feeNodes != null)
      {
        session.setAttribute(DepUtils.FEE_NODES + ":" + productID, feeNodes);
        session.removeAttribute(DepUtils.FEE_NODES + ".PG:" + productID);
      }

      List<DataNode> podNodes = (List<DataNode>)session.getAttribute(DepUtils.POD_NODES + ".PG:" + productID);
      if (podNodes != null)
      {
        session.setAttribute(DepUtils.POD_NODES + ":" + productID, podNodes);
        session.removeAttribute(DepUtils.POD_NODES + ".PG:" + productID);
      }

      List<DataNode> iraNodes = (List<DataNode>)session.getAttribute(DepUtils.IRA_NODES + ".PG:" + productID);
      if (iraNodes != null)
      {
        session.setAttribute(DepUtils.IRA_NODES + ":" + productID, iraNodes);
        session.removeAttribute(DepUtils.IRA_NODES + ".PG:" + productID);
      }

      // Also need to restore the previous view of the associated accounts (for overdraft products only).
      //
      List<DataNode> associatedAccounts = (List<DataNode>)session.getAttribute(DepUtils.OVERDRAFT_ASSOC_ACCT_KEY + ".PG:" + productID);
      if (associatedAccounts != null)
      {
        session.setAttribute(DepUtils.OVERDRAFT_ASSOC_ACCT_KEY + ":" + productID, associatedAccounts);
        session.removeAttribute(DepUtils.OVERDRAFT_ASSOC_ACCT_KEY + ".PG:" + productID);
      }

      // Also need to restore the previous view of the additional account holders.
      //
      List<String> aahList = (List<String>)session.getAttribute(DepUtils.ADDL_ACCT_HLDR_LIST_KEY + ".PG:" + productID);
      if (aahList != null)
      {
        session.setAttribute(DepUtils.ADDL_ACCT_HLDR_LIST_KEY + ":" + productID, aahList);
        session.removeAttribute(DepUtils.ADDL_ACCT_HLDR_LIST_KEY + ".PG:" + productID);
      }
      else
      {
        session.removeAttribute(DepUtils.ADDL_ACCT_HLDR_LIST_KEY + ":" + productID);
      }

      Map<String, String> titleMap = (Map<String, String>)session.getAttribute(DepUtils.ADDL_ACCT_HLDR_REL_KEY +
                                                                               ".PG:" + productID);
      if (titleMap != null)
      {
        session.setAttribute(DepUtils.ADDL_ACCT_HLDR_REL_KEY + ":" + productID, titleMap);
        session.removeAttribute(DepUtils.ADDL_ACCT_HLDR_REL_KEY + ".PG:" + productID);
      }
      else
      {
        session.removeAttribute(DepUtils.ADDL_ACCT_HLDR_REL_KEY + ":" + productID);
      }
    }
    else
    {
      // Remove the temporary funding edits and the additional account holder edits from
      // the user session.
      //
      session.removeAttribute(DepUtils.FUNDING_NODES + ":" + productID);
      session.removeAttribute(DepUtils.POD_NODES + ":" + productID);
      session.removeAttribute(DepUtils.OVERDRAFT_ASSOC_ACCT_KEY + ":" + productID);
      session.removeAttribute(DepUtils.ADDL_ACCT_HLDR_LIST_KEY + ":" + productID);
      session.removeAttribute(DepUtils.ADDL_ACCT_HLDR_REL_KEY + ":" + productID);
      session.removeAttribute(DepUtils.FEE_NODES + ":" + productID);
    }

    return res;
  }


  private xResponse opCodeSaveOrSubmit(VectorX inVec, boolean submit, boolean doNotCloseSave)
  {
  XVectorExtractor.saveVector(inVec);
    xResponse res = new xResponse();

    String username = null;
    HashtableX inFields = null;

    try
    {
      username = ClientUtils.getUsername(inVec);
      inFields = ClientUtils.getFieldsHash(inVec);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Error with incoming data.");
      return res;
    }

    User user = User.getUser(username);
    if (user == null)
    {
      res.errCode = 202;
      res.param.add("Unable to load user '" + username + "'");
      return res;
    }

    String appID = (String)inFields.get(CSFieldNames.FN_APP_ID);
    if (appID == null)
    {
      res.errCode = 202;
      res.param.add("appID not sent in trigger (anAppId).");
      return res;
    }
    String dob = (String)inFields.get(CSFieldNames.FN_BIRTH_DT);
    res = DataValidation.validateDate(dob);

    if (res.errCode != 0)
    {
      return res;
    }

    String editMode = (String)inFields.get(CSFieldNames.FN_EDIT_MODE);
    boolean readOnly = editMode != null && editMode.equals(CSFieldValues.FV_EDIT_MODE_VIEW);
    if (readOnly && !submit)
    {
      res.errCode = 202;
      res.param.add("Unable to save application.  The application is in read only mode.");
      return res;
    }

    String anFormHid = (String)inFields.get(CSFieldNames.FN_RETURN_FORM);
    if (anFormHid == null)
    {
      res.errCode = 202;
      res.param.add("Data Error: _anFormHid not sent.");
      return res;
    }

    boolean isCache = SDOUtils.isCache(anFormHid);

    SystemDataObject sdo = null;

    try
    {
      sdo = isCache ? SDODataCache.getSDO(username, appID) : SDOUtils.getSDO(appID);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Unable to load application '" + appID + "'.");
      return res;
    }


    if (sdo == null)
    {
      res.errCode = 202;
      res.param.add("Unable to locate application data in the cache for ID '" + appID + "'.");
      return res;
    }

    DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);

    // Save the application data.
    //
    DepUtils.saveApplicationData(username, sdo, inFields);

    // If we are in Underwriting, don't attempt to save the primary applicant.
    // Underwriting uses sub-forms for the applicants.
    //
    if (! anFormHid.equals("Underwriting_Review.DA"))
    {
      // Now save the primary depositor information.
      //
      inFields.put(CSFieldNames.FN_BWR_TYPE, CSFieldValues.FV_APPLICANT);

      try
      {
        DepUtils.saveApplicantData(username, 0, sdo, inFields);
      }
      catch (Exception e)
      {
        res.errCode = 202;
        res.param.add(e.getMessage());
        return res;
      }
    }

    if (submit)
    {
      // Do validation routines.
      //
      DataEntryValidator validator = new DataEntryValidator(username, appNode);

      if (! validator.validate())
      {
        StringBuilder sb = new StringBuilder();
        sb.append("Unable to submit application for the following:\n\n");
        sb.append(validator.getMessage());

        res.errCode = 200;
        res.param.add(sb.toString());
        return res;
      }

      appNode.setSystemData(CSStatusCodes.SDO_STATUS,CSStatusCodes.SC_APP_ENTERED);
      appNode.setSystemData("!incomplete", "false");
    }

    String alphaProdID = null;
    if (submit)
    {
      // Find the alpha product (highest priority product out of the group).
      //
      List<DataNode> depAccounts = appNode.getEffectiveReferences(NodeUtils.DEP_ACCOUNT_DN_TYPE);
      try
      {
        alphaProdID = DepUtils.findHighestPriorityAccount(username, depAccounts);
      }
      catch (Exception e)
      {
        ExceptionLogger.logException(e);
        res.errCode = 202;
        res.param.add("Error determining highest priority account: " + e);
        return res;
      }

      // Need to determine the highest priority product and set the productID field in the
      // application.
      //
      appNode.setFieldData(username, CSFieldNames.FN_PRODUCT_ID, alphaProdID);

      //DataEntrySupport.createDefaultFeeNodes(sdo, appNode, username);
    }

    try
    {
      SDOUtils.saveSDO(username, sdo, CSStatusCodes.SDO_UNLOCK);
    }
    catch (SQLException e)
    {
      res.errCode = 202;
      res.param.add("Error saving the application: " + e);
      return res;
    }

    //if (submit && isCache) SDODataCache.removeSDO(username, appID);

    if (submit)
    {
      DepProduct product = CSDataCache.getDepProductManager().getProduct(alphaProdID);
      String milestoneSet = product.getPrdMSSetD();
      AdminGUIManager.displayE("Submitting with MLS: " + milestoneSet);

      // Kick off the app.
      //
      sdo.setSystemData(CSStatusCodes.APP_CAN_CONTINUE, CSFieldValues.TRUE_STRING);

      sdo.setupMilestones(milestoneSet, getName());

      sdo.submit();

      String refID = (String)appNode.getFieldData(CSFieldValues.EMPTY_STRING,
                                                  CSFieldNames.FN_APP_REF_ID);

      String message = "Application " + refID + " has been submitted.";
      NotifyUser nu = new NotifyUser(username, message);
      nu.start();
    }

    recordAppIdForHistory(username, appID);

    if (doNotCloseSave)
      return res;
    else
      return opCodeCancel(inVec, false, true);
  }


  private xResponse opCodeAbandonApp(VectorX inVec)
  {
    xResponse res = new xResponse();

    String username = null;
    HashtableX inFields = null;

    try
    {
      username = ClientUtils.getUsername(inVec);
      inFields = ClientUtils.getFieldsHash(inVec);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Error with incoming data.");
      return res;
    }

    String appID = (String)inFields.get(CSFieldNames.FN_APP_ID);
    if (appID == null)
    {
      res.errCode = 202;
      res.param.add("appID not sent in trigger (anAppId).");
      return res;
    }

    SDOUtils.deleteSDO(appID);

    SDODataCache.removeSDO(username, appID);

    return res;
  }


  private xResponse opCodeOpenApp(VectorX inVec, String formName)
  {
    //log("START opCodeOpenApp(VectorX inVec, String formName)");
    //log("String formName: "+formName );

    xResponse res = new xResponse();

    String username = null;
    HashtableX inFields = null;

    try
    {
      username = ClientUtils.getUsername(inVec);
      inFields = ClientUtils.getFieldsHash(inVec);
      //log( "inFields: "+inFields );
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Error with incoming data.");
      return res;
    }

    String appKey = (String)inFields.get(CSFieldNames.FN_APP_ID_FILTER);
    if (appKey == null)
    {
      res.errCode = 202;
      res.param.add("appID not sent in trigger (afAppT).");
      return res;
    }

    String[] keys = appKey.split(":");
    String appID = keys[0];

    SystemDataObject sdo = null;
    try
    {
      sdo = SDOUtils.getSDO(appID);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Error: Application file not found for " + appID);
      return res;
    }

    if (sdo == null)
    {
      res.errCode = 202;
      res.param.add("Error: Application file not found for " + appID);
      return res;
    }

    boolean confirmReadOnly = inFields.containsKey("aeButtonConfirm") && ((String)inFields.get("aeButtonConfirm")).equals("800");

    boolean canEdit = !confirmReadOnly;

    if (canEdit)
    {
      try
      {
        canEdit = CSUtil.editOrView(username, sdo);
      }
      catch (Exception e)
      {
        res.errCode = 1;
        res.param.add(e.getMessage());
        return res;
      }
    }

    String whoHasItLocked = null;

    if (canEdit)
    {
      try
      {
        boolean success = sdo.lock(username);
        if (! success) whoHasItLocked = sdo.lockedBy();
      }
      catch (SQLException e)
      {
        res.errCode = 202;
        res.param.add("Unable to lock the application: " + e);
        return res;
      }
    }

    if (whoHasItLocked != null && !confirmReadOnly)
    {
      // return warning message
      String msg = "The application is currently locked by " + whoHasItLocked + ".\n Do you want to view it instead?";
      res.errCode = 800;
      res.param.add(msg);
      return res;
    }

    String appStatus = SDOUtils.getSDOStatus(sdo);

    // incomplete application, either imported or never finished.
    // override the form name.
    if ( appStatus.equals(CSStatusCodes.SC_IMPORTED_APP) ||
         appStatus.equals(CSStatusCodes.SC_INCOMPLETE_APP) ||
         appStatus.equals(CSStatusCodes.SC_INCOMPLETE_PREAPV) )
    {
      formName = "Application.DA";
    }

    Form form = FormLoader.loadForm(formName);
    if (form == null)
    {
      res.errCode = 202;
      res.param.add("Unable to load form: " + formName);
      return res;
    }

    HashtableX fields = new HashtableX();

    DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);

    fields.putAll(appNode.getFieldData(username));
    fields.putAll(appNode.getSystemData());

    DataNode bankSecrecyNode = appNode.getReference( NodeUtils.DEP_BANK_SECRECY_DN_TYPE, 0 );
    //log("bankSecrecyNode: "+bankSecrecyNode);
    if (bankSecrecyNode != null)
    {
      //log( "bankSecrecyNode.getFieldData( username ): " + bankSecrecyNode.getFieldData( username ) );
      fields.putAll( bankSecrecyNode.getFieldData( username ) );
    }


    DataNode applicantNode = appNode.getReference(NodeUtils.BWR_DN_TYPE, 0);

    if (applicantNode == null)
    {
      res.errCode = 202;
      res.param.add("Error: unable to locate applicant in the data.");
      return res;
    }

    fields.putAll(applicantNode.getFieldData(username));

    fields.put(CSFieldNames.FN_APP_ID_HID, appID);
    fields.put(CSFieldNames.FN_BWR_POS_HID, "0");
    fields.put(CSFieldNames.FN_EDIT_MODE, canEdit ? CSFieldValues.FV_EDIT_MODE_EDIT : CSFieldValues.FV_EDIT_MODE_VIEW);
    fields.put(CSFieldNames.FN_RETURN_FORM, formName);


    if (SDOUtils.isCache(formName))
    {
      SDODataCache.setSDOTable(username, appID, sdo);
    }
    try
    {
      DepUtils.populateMainForm(username, form, sdo, fields, false);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add(e.getMessage());
      return res;
    }
    HashtableX crossSellProductInfo = XSellUtils.getCrossSellProductInfo(appNode, appID);
    fields.putAll(crossSellProductInfo);
    // HashtableX response = super.createClientResponse(username, form, fields, null);
    //
    String depAcctProdId = null;
    try
    {
      // get deposit account product id
      String depAcctIndexStr = keys[1];
      //log( "depAcctIndexStr: "+depAcctIndexStr );

      int depAcctIndex = Integer.parseInt( depAcctIndexStr );
      //log( "depAcctIndex: " + depAcctIndex );

      DataNode depAcctDN = appNode.getReference( NodeUtils.DEP_ACCOUNT_DN_TYPE, depAcctIndex );
      if( depAcctDN != null && !depAcctDN.isDeleted() )
      {
        depAcctProdId = (String)depAcctDN.getFieldData(username, CSFieldNames.FN_DEP_PROD_ID);
        //log( "1 depAcctProdId: " + depAcctProdId );
        if( depAcctProdId != null && depAcctProdId.trim().length() == 0 )
        {
          depAcctProdId = null;
          //log( "2 depAcctProdId: " + depAcctProdId );
        }
      }
    }
    catch( Exception t)
    {
      t.printStackTrace();
      depAcctProdId = null;
    }

    //log( "Dep Acct Prod ID - depAcctProdId: " + depAcctProdId );

    HashtableX instHash = new HashtableX();
    if (canEdit)
    {
      instHash = DataEntrySupport.loadInstructionHash( appNode, instHash, formName, depAcctProdId );
    }
    else
    {
      DataEntrySupport.setAllVistasReadOnly(form, instHash);
      DepUtils.enableTheseButtonsWhenAppIsLocked(instHash);
    }

    HashtableX response = super.createClientResponse(username, form, fields, instHash);

    //log( "END opCodeOpenApp(VectorX inVec, String formName)" );

    res.param.add(response);
    return res;
  }


  private xResponse opCodeCancel(VectorX inVec, boolean unlock, boolean initActivity)
  {
     xResponse res = new xResponse();

     String username = null;
     HashtableX fieldsHash = null;

     try
     {
       username = ClientUtils.getUsername(inVec);
       fieldsHash = ClientUtils.getFieldsHash(inVec);
     }
     catch (Exception e)
     {
       res.errCode = 202;
       res.param.add("Error with incoming data." + e.toString());
       return res;
     }

     String appID = (String) fieldsHash.get("anIdHid");
     String anFormHid = (String) fieldsHash.get("_anFormHid");

     // unlock the application
     //
     if (appID == null)
     {
       appID = (String) fieldsHash.get("anAppId");
     }

     if (appID != null && appID.trim().length() > 0)
     {
       String anModeHid = (String) fieldsHash.get("_anModeHid");

       if (anModeHid != null && anModeHid.equals(CSFieldValues.FV_EDIT_MODE_EDIT))
       {

         boolean lockedByMe = anModeHid != null && anModeHid.equals(CSFieldValues.FV_EDIT_MODE_EDIT);
         boolean isCache = SDOUtils.isCache(anFormHid);

         SystemDataObject sdo = null;

         if (isCache)
         {
           sdo = SDODataCache.getSDO(username, appID);
         }
         else
         {
           try
           {
             sdo = SDOUtils.getSDO(appID);
           }
           catch (Exception e)
           {
             res.errCode = 1;
             res.param.addElement("Unable to load application.");
             return res;
           }
         }

         if (sdo == null)
         {
           res.errCode = 202;
           res.param.addElement("Unable to locate application data to unlock.");
           return res;
         }

         try
         {
           if (isCache) SDODataCache.removeSDO(username, appID);
           if (lockedByMe && unlock) sdo.unlockIfLockedByMe(username);
         }
         catch (SQLException e)
         {
           ExceptionLogger.logException(e);
           res.errCode = 202;
           res.param.add(e.getMessage());
           return res;
         }
       }
     }

    if (initActivity)
    {
      String activity = translateFormToActivity(anFormHid);
      if (activity != null)
      {
        XCSRequest req = new XCSRequest("Start." + activity);
        req.param.addAll(inVec);

        XCSResponse xcsres = contactSystem(req);

        res.errCode = xcsres.errCode;
        res.param = xcsres.param;
      }
    }

    return res;

  }   // opCodeCancel


  private xResponse opCodeEditPGOffer(VectorX inVec)
  {
    xResponse res = new xResponse();

    String username = null;
    HashtableX inFields = null;

    try
    {
      username = ClientUtils.getUsername(inVec);
      inFields = ClientUtils.getFieldsHash(inVec);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Error with incoming data.");
      return res;
    }

    User user = User.getUser(username);
    if (user == null)
    {
      res.errCode = 202;
      res.param.add("Unable to load user '" + username + "'");
      return res;
    }

    UserSession session = user.getUserSession();

    String appID = (String)inFields.get(CSFieldNames.FN_APP_ID);
    if (appID == null)
    {
      res.errCode = 202;
      res.param.add("appID not sent in trigger (anAppId).");
      return res;
    }

    String anFormHid = (String)inFields.get(CSFieldNames.FN_RETURN_FORM);
    if (anFormHid == null)
    {
      res.errCode = 202;
      res.param.add("Data Error: _anFormHid not sent.");
      return res;
    }

    boolean isCache = SDOUtils.isCache(anFormHid);

    String keyStr = (String)inFields.get("_anProdT");
    if (keyStr == null || keyStr.length() == 0)
    {
      res.errCode = 202;
      res.param.add("Please select a product in the table.");
      return res;
    }

    String[] keys = keyStr.split(String.valueOf(ClientUtils.TOKEN));
    String depAcctIndex = keys[0];
    String productID = keys[1];

    session.setAttribute("dep_acct_index", depAcctIndex);

    List<DataNode> individualProducts = (List<DataNode>)session.getAttribute(DepUtils.PRD_GRP_SESSION_KEY);
    if (individualProducts == null)
    {
      res.errCode = 202;
      res.param.add("Error: Individual product list not in user session.");
      return res;
    }

    DataNode tempProductNode = individualProducts.get(Integer.parseInt(depAcctIndex));

    String formName = "Account_Details.DA";
    Form form = FormLoader.loadForm(formName);
    if (form == null)
    {
      res.errCode = 202;
      res.param.add("Unable to load form '" + formName + "'");
      return res;
    }

    SystemDataObject sdo = null;

    try
    {
      sdo = isCache ? SDODataCache.getSDO(username, appID) : SDOUtils.getSDO(appID);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Unable to load application '" + appID + "'.");
      return res;
    }

    if (sdo == null)
    {
      res.errCode = 202;
      res.param.add("Unable to locate application data in the cache for ID '" + appID + "'.");
      return res;
    }

    DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);

    DepProduct product = CSDataCache.getDepProductManager().getProduct(productID);
    if (product == null)
    {
      res.errCode = 202;
      res.param.add("Unable to load product '" + productID + "'");
      return res;
    }

    // Hide the Funding.DA vista in Data Entry
    if (anFormHid.equals("Application.DA"))
    {
      form.getVistas().remove("Funding.DA");
    }
    
    
    // Make a copy of the temporary funding nodes and the additional account holder data
    // so that if the user cancels on the subform of editing the product offer, we can
    // restore the previous state of the funding details and the additional account details.
    // The copy will be placed in a different key in the session.
    //
    List<DataNode> tempFundingNodes = new ArrayList<DataNode>();
    List<DataNode> fundingNodes = (List<DataNode>)session.getAttribute(DepUtils.FUNDING_NODES + ":" + productID);
    for (DataNode funding : fundingNodes)
    {
      tempFundingNodes.add(funding.copy());
    }
    session.setAttribute(DepUtils.FUNDING_NODES + ".PG:" + productID, tempFundingNodes);

    // Make a copy of the temporary fee nodes and the additional account holder data
    // so that if the user cancels on the subform of editing the product offer, we can
    // restore the previous state of the fee details and the additional account details.
    // The copy will be placed in a different key in the session.
    //
    List<DataNode> tempFeeNodes = new ArrayList<DataNode>();
    List<DataNode> feeNodes = (List<DataNode>)session.getAttribute(DepUtils.FEE_NODES + ":" + productID);
    for (DataNode fee : feeNodes)
    {
      tempFeeNodes.add(fee.copy());
    }
    session.setAttribute(DepUtils.FEE_NODES + ".PG:" + productID, tempFeeNodes);

    List<DataNode> tempPODNodes = new ArrayList<DataNode>();
    List<DataNode> podNodes = (List<DataNode>)session.getAttribute(DepUtils.POD_NODES + ":" + productID);
    for (DataNode pod : podNodes)
    {
      tempPODNodes.add(pod.copy());
    }
    session.setAttribute(DepUtils.POD_NODES + ".PG:" + productID, tempPODNodes);

    List<DataNode> tempIRANodes = new ArrayList<DataNode>();
    List<DataNode> iraNodes = (List<DataNode>)session.getAttribute(DepUtils.IRA_NODES + ":" + productID);
    for (DataNode ira : iraNodes)
    {
    	tempIRANodes.add(ira.copy());
    }
    session.setAttribute(DepUtils.IRA_NODES + ".PG:" + productID, tempIRANodes);

    // Make a copy of the temporary associated account nodes so that if the user cancels on
    // the subform of editing the product offer, we can restore the previous state of the
    // associated account details and the additional account details. The copy will be placed
    // in a different key in the session.
    //
    List<DataNode> assocAccounts = (List<DataNode>)session.getAttribute(DepUtils.OVERDRAFT_ASSOC_ACCT_KEY + ":" + productID);
    if (assocAccounts != null)
    {
      List<DataNode> tempAssocAccounts = new ArrayList<DataNode>();
      for (DataNode assocAcct : assocAccounts)
      {
        tempAssocAccounts.add(assocAcct.copy());
      }
      session.setAttribute(DepUtils.OVERDRAFT_ASSOC_ACCT_KEY + ".PG:" + productID, tempAssocAccounts);
    }

    List<String> aahList = (List<String>)session.getAttribute(DepUtils.ADDL_ACCT_HLDR_LIST_KEY + ":" + productID);
    if (aahList != null)
    {
      List<String> aahListTemp = new VectorX();
      aahListTemp.addAll(aahList);
      session.setAttribute(DepUtils.ADDL_ACCT_HLDR_LIST_KEY + ".PG:" + productID, aahListTemp);

      Map<String, String> titleMap = (Map<String, String>)session.getAttribute(DepUtils.ADDL_ACCT_HLDR_REL_KEY +
                                                                               ":" + productID);
      if (titleMap != null)
      {
        Map<String, String> titleMapTemp = new HashtableX();
        titleMapTemp.putAll(titleMap);
        session.setAttribute(DepUtils.ADDL_ACCT_HLDR_REL_KEY + ".PG:" + productID, titleMapTemp);
      }
    }

    HashtableX fields = tempProductNode.getFieldData(username);

    // Show the additional account holders vista if there are additional
    // applicants on the app.
    //
    List applicants = appNode.getEffectiveReferences(NodeUtils.BWR_DN_TYPE);
    if (applicants.size() == 1)
    {
      form.getVistas().remove("Additional_Account_Holders.DA");
    }

    // Need to set this system field to tell the vista populator what the current add/edit
    // product ID is.  It will be used to fill the dropdown on the account details vista.
    //
    fields.put("_anProdTypeD", productID);

    fields.put(CSFieldNames.FN_RETURN_FORM, anFormHid);
    fields.put(CSFieldNames.FN_BWR_POS_HID, "pg");
    fields.put(CSFieldNames.FN_EDIT_MODE, CSFieldValues.FV_EDIT_MODE_EDIT);
    fields.put(CSFieldNames.FN_APP_ID, appID);

    try
    {
      DepUtils.populateAccountForm(username, form, sdo, product, fields);
    }
    catch (Exception e)
    {
      ExceptionLogger.logException(e);
      res.errCode = 202;
      res.param.add(e.getMessage());
      return res;
    }

    HashtableX instructions = new HashtableX();
    instructions.put(CSFieldNames.FN_DEP_PROD_ID, ClientUtils.readonlyElement());

    instructions = DataEntrySupport.loadInstructionHash(appNode, instructions, formName, productID);

    HashtableX response = super.createClientResponse(form, fields, instructions);

    res.param.add(response);
    return res;
  }


  private xResponse opCodeSavePG(VectorX inVec)
  {
    xResponse res = new xResponse();

    String username = null;
    HashtableX inFields = null;

    try
    {
      username = ClientUtils.getUsername(inVec);
      inFields = ClientUtils.getFieldsHash(inVec);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Error with incoming data.");
      return res;
    }

    User user = User.getUser(username);
    if (user == null)
    {
      res.errCode = 202;
      res.param.add("Unable to load user '" + username + "'");
      return res;
    }

    UserSession session = user.getUserSession();
    List<DataNode> individualProducts = (List<DataNode>)session.getAttribute(DepUtils.PRD_GRP_SESSION_KEY);

    DataEntryValidator validator = new DataEntryValidator(username, null);
    boolean ok = validator.checkForIncompleteProductGroupAccounts(individualProducts);
    if (! ok)
    {
      res.errCode = 202;
      res.param.add(validator.getMessage());
      return res;
    }

    String appID = (String)inFields.get(CSFieldNames.FN_APP_ID);
    if (appID == null)
    {
      res.errCode = 202;
      res.param.add("Data Error: appID not sent in trigger (anAppId).");
      return res;
    }

    String anFormHid = (String)inFields.get(CSFieldNames.FN_RETURN_FORM);
    if (anFormHid == null)
    {
      res.errCode = 202;
      res.param.add("Data Error: _anFormHid not sent.");
      return res;
    }

    String productGroupName = (String)inFields.get("xpgro");
    if (productGroupName == null)
    {
      res.errCode = 202;
      res.param.add("Data Error: Product Group Name (xpgro) not sent.");
      return res;
    }

    String productGroupID = (String)inFields.get("_daPrdGrpId");
    if (productGroupID == null)
    {
      res.errCode = 202;
      res.param.add("Data Error: Product Group ID (_daPrdGrpId) not sent.");
      return res;
    }

    boolean isCache = SDOUtils.isCache(anFormHid);

    SystemDataObject sdo = null;

    try
    {
      sdo = isCache ? SDODataCache.getSDO(username, appID) : SDOUtils.getSDO(appID);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Unable to load application '" + appID + "'.");
      return res;
    }

    if (sdo == null)
    {
      res.errCode = 202;
      res.param.add("Unable to locate application data in the cache for ID '" + appID + "'.");
      return res;
    }

    DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);

    // Take the temporary deposit account nodes that were maintained throughout the
    // entry of the product grouping, and create the real nodes to be added to the
    // application data node.
    //
    for (DataNode tempDepAcct : individualProducts)
    {
      DataNode realDepAcct = sdo.createDataNode(username, NodeUtils.DEP_ACCOUNT_DN_TYPE);
      realDepAcct.setFieldData(username, tempDepAcct.getFieldData(""));
      realDepAcct.setSystemData(tempDepAcct.getSystemData());
      realDepAcct.setSystemData(CSFieldNames.FN_SYS_DEP_PRD_GRP_ID, productGroupID);
      realDepAcct.setSystemData(CSFieldNames.FN_SYS_DEP_PRD_GRP_NAME, productGroupName);

      appNode.addReference(realDepAcct);

      String productID = (String)realDepAcct.getFieldData(username, CSFieldNames.FN_DEP_PROD_ID);

      double totalAmt = 0.0;
      boolean isFunded = false;
      double openingAmt = StringSupport.strToDouble((String)realDepAcct.getFieldData("",CSFieldNames.FN_DEP_OPEN_AMT));

      // Now take the temporary funding nodes that were collected and add them into
      // the deposit account data node as real data nodes.  We'll need to create a
      // data node for each temporary funding node found in the session.
      //
      List<DataNode> fundingNodes = (List<DataNode>)session.getAttribute(DepUtils.FUNDING_NODES + ":" + productID);
      for (DataNode fundingNode : fundingNodes)
      {
        DataNode actualFundingNode = sdo.createDataNode(username, NodeUtils.DEP_FUNDING_DN_TYPE);

        actualFundingNode.setFieldData(username, fundingNode.getFieldData(""));
        actualFundingNode.setSystemData(fundingNode.getSystemData());

        // Sum up the total funded amount.
        //
        String str = (String)actualFundingNode.getFieldData("", CSFieldNames.FN_DEP_FUNDING_AMT);
        totalAmt += StringSupport.strToDouble(str);          
        isFunded = (totalAmt >= openingAmt) ? true : false;
        
        realDepAcct.addReference(actualFundingNode);
      }
      
      realDepAcct.setSystemData(username, CSFieldNames.FN_SYS_DEP_ISFUNDED_FLAG, String.valueOf(isFunded));

      session.removeAttribute(DepUtils.FUNDING_NODES + ":" + productID);

      // Now take the temporary fee nodes that were collected and add them into
      // the deposit account data node as real data nodes.  We'll need to create a
      // data node for each temporary fee node found in the session.
      //
      List<DataNode> feeNodes = (List<DataNode>)session.getAttribute(DepUtils.FEE_NODES + ":" + productID);
      for (DataNode feeNode : feeNodes)
      {
        DataNode actualFeeNode = sdo.createDataNode(username, NodeUtils.FEE_DN_TYPE);

        actualFeeNode.setFieldData(username, feeNode.getFieldData(""));
        actualFeeNode.setSystemData(feeNode.getSystemData());

        realDepAcct.addReference(actualFeeNode);
      }

      session.removeAttribute(DepUtils.FEE_NODES + ":" + productID);

      // Now take the temporary payable on death nodes that were collected and add them into
      // the deposit account data node as real data nodes.  We'll need to create a
      // data node for each temporary payable on death node found in the session.
      //
      List<DataNode> podNodes = (List<DataNode>)session.getAttribute(DepUtils.POD_NODES + ":" + productID);
      for (DataNode podNode : podNodes)
      {
        DataNode actualPODNode = sdo.createDataNode(username, NodeUtils.DEP_POD_DN_TYPE);

        actualPODNode.setFieldData(username, podNode.getFieldData(""));
        actualPODNode.setSystemData(podNode.getSystemData());

        realDepAcct.addReference(actualPODNode);
      }

      session.removeAttribute(DepUtils.POD_NODES + ":" + productID);


      List<DataNode> iraNodes = (List<DataNode>)session.getAttribute(DepUtils.IRA_NODES + ":" + productID);
      for (DataNode iraNode : iraNodes)
      {
        DataNode actualIRANode = sdo.createDataNode(username, NodeUtils.DEP_IRA_DN_TYPE);

        actualIRANode.setFieldData(username, iraNode.getFieldData(""));
        actualIRANode.setSystemData(iraNode.getSystemData());

        realDepAcct.addReference(actualIRANode);
      }

      session.removeAttribute(DepUtils.IRA_NODES + ":" + productID);

      // Now take the temporary associated account nodes that were collected and add them into
      // the deposit account data node as real data nodes.  We'll need to create a
      // data node for each temporary associated account node found in the session.  The
      // associatedAccounts List will only exist for an overdraft product, so we need to null
      // check the List coming out of the session.
      //
      List<DataNode> associatedAccounts = (List<DataNode>)session.getAttribute(DepUtils.OVERDRAFT_ASSOC_ACCT_KEY + ":" + productID);
      if (associatedAccounts != null)
      {
        for (DataNode associatedAccount : associatedAccounts)
        {
          DataNode actualAssociatedAccount = sdo.createDataNode(username, NodeUtils.DEP_OD_LINK_DN_TYPE);

          actualAssociatedAccount.setFieldData(username, associatedAccount.getFieldData(""));
          actualAssociatedAccount.setSystemData(associatedAccount.getSystemData());

          realDepAcct.addReference(actualAssociatedAccount);
        }

        session.removeAttribute(DepUtils.OVERDRAFT_ASSOC_ACCT_KEY + ":" + productID);
      }

      // Store the additional account holder list and title map in the deposit account data node.
      // If no data is in the session, then remove the fields (user may have deleted all account
      // holders on the product).
      //
      List<String> aahList = (List<String>)session.getAttribute(DepUtils.ADDL_ACCT_HLDR_LIST_KEY + ":" + productID);
      if (aahList != null)
      {
        realDepAcct.setSystemData(CSFieldNames.FN_SYS_DEP_ADD_ACCT_HLDRS, aahList);
      }
      else
      {
        realDepAcct.removeSystemData(CSFieldNames.FN_SYS_DEP_ADD_ACCT_HLDRS);
      }

      Map<String, String> aahTitleMap = (Map<String, String>)session.getAttribute(DepUtils.ADDL_ACCT_HLDR_REL_KEY +
                                                                                  ":" + productID);
      if (aahTitleMap != null)
      {
        realDepAcct.setSystemData(CSFieldNames.FN_SYS_DEP_TITLE_MAP, aahTitleMap);
      }
      else
      {
        realDepAcct.removeSystemData(CSFieldNames.FN_SYS_DEP_TITLE_MAP);
      }

      session.removeAttribute(DepUtils.ADDL_ACCT_HLDR_LIST_KEY + ":" + productID);
      session.removeAttribute(DepUtils.ADDL_ACCT_HLDR_REL_KEY + ":" + productID);

    }

    session.removeAttribute(DepUtils.PRD_GRP_SESSION_KEY);

    // With new products placed on the application, we may have a higher priority product on the
    // app now.  We need to re-determine the highest priority product and set the main product ID
    // field in the app node.
    //
    String incompleteFlag = (String)appNode.getSystemData(CSFieldNames.FN_SYS_DEP_INCOMPLETE_FLAG);
    boolean pastDataEntry = incompleteFlag != null && incompleteFlag.equals(CSFieldValues.FALSE_STRING);
    if (pastDataEntry)
    {
      List<DataNode> accounts = appNode.getEffectiveReferences(NodeUtils.DEP_ACCOUNT_DN_TYPE);
      String highestPriorityProductID = null;

      try
      {
        highestPriorityProductID = DepUtils.findHighestPriorityAccount(username, accounts);
      }
      catch (Exception e)
      {
        ExceptionLogger.logException(e);
        res.errCode = 202;
        res.param.add("Error while determining highest priority product: " + e);
        return res;
      }

      appNode.setFieldData(username, CSFieldNames.FN_PRODUCT_ID, highestPriorityProductID);
    }

    if (isCache)
    {
      SDODataCache.setSDOTable(username, appID, sdo);
    }
    else
    {
      try
      {
        SDOUtils.saveSDO(username, sdo, CSStatusCodes.SDO_LOCK);
      }
      catch (SQLException e)
      {
        res.errCode = 202;
        res.param.add("Unable to save application: "  + e);
        return res;
      }
    }

    TableTransaction tt = DepUtils.generateProductRequestTable(appNode);

    // Update the total funding amount field.
    //
    DepCalcs depCalcs = new DepCalcs(username, sdo);
    double totalFunding = depCalcs.calculateTotalAmountFunded(appNode);
    String totalFundingAmt = String.valueOf(totalFunding);

    HashtableX fields = new HashtableX();
    fields.put("_anProdT", tt);
    fields.put("daFundTtl", totalFundingAmt);

    String totalFundingAmtStr = String.valueOf(depCalcs.calculateTotalFundedAmount(appNode));    
    if (totalFundingAmtStr != null) fields.put("anTtlFundedAmt", totalFundingAmtStr);       

    String totalOpeningAmtStr = String.valueOf(depCalcs.calculateTotalOpeningAmount(appNode));
    if (totalOpeningAmtStr != null) fields.put("anTtlOpenAmt",   totalOpeningAmtStr);

    HashtableX response = super.createClientResponse((Form)null, fields, null);

    res.param.add(response);
    return res;
  }


  private xResponse opCodeAddOrEditFunding(VectorX inVec, boolean isAdd)
  {
  XVectorExtractor.saveVector(inVec);
    xResponse res = new xResponse();

    String username = null;
    HashtableX inFields = null;

    try
    {
      username = ClientUtils.getUsername(inVec);
      inFields = ClientUtils.getFieldsHash(inVec);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Error with incoming data.");
      return res;
    }

    User user = User.getUser(username);
    if (user == null)
    {
      res.errCode = 202;
      res.param.add("Unable to load user '" + username + "'");
      return res;
    }

    String appID = (String)inFields.get(CSFieldNames.FN_APP_ID);
    if (appID == null)
    {
      res.errCode = 202;
      res.param.add("Data Error: anAppId not sent in trigger.");
      return res;
    }
    
    String anFormHid = (String)inFields.get(CSFieldNames.FN_RETURN_FORM);
    if (anFormHid == null)
    {
      res.errCode = 202;
      res.param.add("Data Error: _anFormHid not sent.");
      return res;
    }

    UserSession session = user.getUserSession();

    String productID = (String)inFields.get(CSFieldNames.FN_DEP_PROD_ID);

    HashtableX fundingFields = null;
    String fundingType = null;

    if (isAdd)
    {
      fundingType = (String)inFields.get(CSFieldNames.FN_DEP_FUNDING_TYPE);
      if (fundingType == null)
      {
        res.errCode = 202;
        res.param.add("Please choose a funding type from the list.");
        return res;
      }
    }
    else
    {
      String fundingIndex = (String)inFields.get(CSFieldNames.FN_DEP_FUNDING_TBL);
      if (fundingIndex == null || fundingIndex.length() == 0)
      {
        res.errCode = 202;
        res.param.add("Please select a funding method from the table.");
        return res;
      }

      List<DataNode> fundingNodes = (List<DataNode>)session.getAttribute(DepUtils.FUNDING_NODES + ":" + productID);
      if (fundingNodes == null)
      {
        res.errCode = 202;
        res.param.add("Unable to load funding data from user session.");
        return res;
      }

      DataNode fundingNode = fundingNodes.get(Integer.parseInt(fundingIndex));
      fundingFields = fundingNode.getFieldData("");
      fundingType = (String)fundingFields.get(CSFieldNames.FN_DEP_FUNDING_TYPE);

      // This is the index of the data node in the List in memory.  This will get used on the
      // save of the edited funding data.
      //
      fundingFields.put("daFundId", fundingIndex);
    }

    String formName = "Funding_Details.DA";
    Form form = FormLoader.loadForm(formName);
    if (form == null)
    {
      res.errCode = 202;
      res.param.add("Unable to load form '" + formName + "'");
      return res;
    }

    addVistaToFundingForm(fundingType, form);

    HashtableX fields = new HashtableX();
    if (fundingFields != null) fields.putAll(fundingFields);
    fields.put("_anProdTypeD", productID);
    fields.put(CSFieldNames.FN_APP_ID, appID);
    fields.put(CSFieldNames.FN_RETURN_FORM, anFormHid);
    if (isAdd)
    {
      fields.put(CSFieldNames.FN_DEP_FUNDING_TYPE, fundingType);
    }

    
    String where = (String)inFields.get(CSFieldNames.FN_RETURN_FORM);
    String mode = (String)inFields.get(CSFieldNames.FN_EDIT_MODE);
    SystemDataObject sdo = getSDO(appID, where, mode, username);
    
    DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);

    String branchID = (String)appNode.getFieldData("", CSFieldNames.FN_BRANCH_ID);
    int branch = StringSupport.strToInt(branchID);
    

    if (sdo == null)
    {
      res.errCode = 202;
      res.param.add("Unable to load System Data file for application '" + appID + "'");
      return res;
    }
    
    HashtableX instHash = new HashtableX();
    boolean canEdit = true;
    try {
		canEdit = CSUtil.editOrView(username, sdo);
	} catch (Exception e) {
		e.printStackTrace();
	}
    VectorX vistas = form.getVistas();
    for (int i = 0, c = vistas.size(); i < c; ++i)
    {
      if (!canEdit) instHash.put((String)vistas.get(i), ClientUtils.readOnlyVista());
      ClientUtils.populateVistaLists(branch, (String)vistas.get(i), inFields);
    }
    
    
    DataEntrySupport.loadInstructionHash(appNode, instHash, where);
    HashtableX response = super.createClientResponse(form, fields, instHash);

    res.param.add(response);
    return res;
  }


  private xResponse opCodeDelFunding(VectorX inVec)
  {
    xResponse res = new xResponse();

    String username = null;
    HashtableX inFields = null;

    try
    {
      username = ClientUtils.getUsername(inVec);
      inFields = ClientUtils.getFieldsHash(inVec);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Error with incoming data.");
      return res;
    }

    User user = User.getUser(username);
    if (user == null)
    {
      res.errCode = 202;
      res.param.add("Unable to load user '" + username + "'");
      return res;
    }

    String appID = (String)inFields.get(CSFieldNames.FN_APP_ID);
    if (appID == null)
    {
      res.errCode = 202;
      res.param.add("Data Error: appID not sent in trigger (anAppId).");
      return res;
    }

    String anFormHid = (String)inFields.get(CSFieldNames.FN_RETURN_FORM);
    if (anFormHid == null)
    {
      res.errCode = 202;
      res.param.add("Data Error: _anFormHid not sent.");
      return res;
    }

    boolean isCache = SDOUtils.isCache(anFormHid);

    SystemDataObject sdo = null;

    try
    {
      sdo = isCache ? SDODataCache.getSDO(username, appID) : SDOUtils.getSDO(appID);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Unable to load application '" + appID + "'.");
      return res;
    }

    if (sdo == null)
    {
      res.errCode = 202;
      res.param.add("Unable to locate application data in the cache for ID '" + appID + "'.");
      return res;
    }

    String productID = (String)inFields.get(CSFieldNames.FN_DEP_PROD_ID);

    // Have to populate the hidden field because the Funding.DA vista populator uses it.
    //
    inFields.put("_anProdTypeD", productID);

    // Get the list of funding nodes from memory.
    //
    UserSession session = user.getUserSession();
    List<DataNode> fundingNodes = (List<DataNode>)session.getAttribute(DepUtils.FUNDING_NODES + ":" + productID);

    String fundingIndex = (String)inFields.get(CSFieldNames.FN_DEP_FUNDING_TBL);
    if (fundingIndex == null || fundingIndex.length() == 0)
    {
      res.errCode = 202;
      res.param.add("Please select a funding method from the table to delete.");
      return res;
    }

    fundingNodes.remove(Integer.parseInt(fundingIndex));

    // Total up the opening amount.
    //
    double totalAmt = 0.0;
    for (DataNode fundingNode : fundingNodes)
    {
      String str = (String)fundingNode.getFieldData("", CSFieldNames.FN_DEP_FUNDING_AMT);
      totalAmt += StringSupport.strToDouble(str);
    }

    session.setAttribute(DepUtils.FUNDING_NODES + ":" + productID, fundingNodes);

    List<String> vistasToPopulate = new ArrayList<String>();
    vistasToPopulate.add("Funding.DA");

    try
    {
      DepUtils.populateSpecificVistas(username, vistasToPopulate, sdo, inFields);
    }
    catch (Exception e)
    {
      String msg = e.getMessage();
      if (msg == null) msg = e.toString();

      res.errCode = 202;
      res.param.add(msg);
      return res;
    }

    HashtableX response = super.createClientResponse((Form)null, inFields, null);

    res.param.add(response);
    return res;
  }


  private xResponse opCodeSaveFunding(VectorX inVec)
  {
    XVectorExtractor.saveVector(inVec);
    xResponse res = new xResponse();

    String username = null;
    HashtableX inFields = null;

    try
    {
      username = ClientUtils.getUsername(inVec);
      inFields = ClientUtils.getFieldsHash(inVec);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Error with incoming data.");
      return res;
    }

    User user = User.getUser(username);
    if (user == null)
    {
      res.errCode = 202;
      res.param.add("Unable to load user '" + username + "'");
      return res;
    }

    String appID = (String)inFields.get(CSFieldNames.FN_APP_ID);
    if (appID == null)
    {
      res.errCode = 202;
      res.param.add("Data Error: appID not sent in trigger (anAppId).");
      return res;
    }

    String anFormHid = (String)inFields.get(CSFieldNames.FN_RETURN_FORM);
    if (anFormHid == null)
    {
      res.errCode = 202;
      res.param.add("Data Error: _anFormHid not sent.");
      return res;
    }

    boolean isCache = SDOUtils.isCache(anFormHid);

    SystemDataObject sdo = null;

    try
    {
      sdo = isCache ? SDODataCache.getSDO(username, appID) : SDOUtils.getSDO(appID);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Unable to load application '" + appID + "'.");
      return res;
    }

    if (sdo == null)
    {
      res.errCode = 202;
      res.param.add("Unable to locate application data in the cache for ID '" + appID + "'.");
      return res;
    }

    String productID = (String)inFields.get("_anProdTypeD");
    String fundingNodeIndex = (String)inFields.get("daFundId");
    boolean isAdd = fundingNodeIndex == null;

    UserSession session = user.getUserSession();
    List<DataNode> fundingNodes = (List<DataNode>)session.getAttribute(DepUtils.FUNDING_NODES + ":" + productID);

    // Maintain a list of maps to store the funding fields into.  When the product is saved, we will
    // create data nodes for each map in the list and store the data node under the account.
    //
    HashtableX fundingFields = NodeUtils.separateDataHash(NodeUtils.DEP_FUNDING_DN_TYPE, inFields, false);
    fundingFields.put(CSFieldNames.FN_DEP_FUNDING_DATE, DateUtility.formatDateTime(new Date()));

    if (isAdd)
    {
      // Create the temporary data node and add it to the List in memory.
      //
      DataNode tempNode = new DataNode(NodeUtils.DEP_FUNDING_DN_TYPE);
      tempNode.setFieldData(username, fundingFields);
      fundingNodes.add(tempNode);
    }
    else
    {
      // Don't save the fund id (this is the index into the List in memory).
      //
      fundingFields.remove("daFundId");

      DataNode tempNode = fundingNodes.get(Integer.parseInt(fundingNodeIndex));
      tempNode.setFieldData(username, fundingFields);
    }

    session.setAttribute(DepUtils.FUNDING_NODES + ":" + productID, fundingNodes);

    List<String> vistasToPopulate = new ArrayList<String>();
    vistasToPopulate.add("Funding.DA");
    vistasToPopulate.add("Account_Details_-_Checking.DA");

    try
    {
      DepUtils.populateSpecificVistas(username, vistasToPopulate, sdo, inFields);
    }
    catch (Exception e)
    {
      String msg = e.getMessage();
      if (msg == null) msg = e.toString();

      res.errCode = 202;
      res.param.add(msg);
      return res;
    }

    HashtableX response = super.createClientResponse((Form)null, inFields, null);

    res.param.add(response);
    return res;
  }

  private xResponse opCodeAddOrEditPOD(VectorX inVec, boolean isAdd)
  {
  XVectorExtractor.saveVector(inVec);
    xResponse res = new xResponse();

    String username = null;
    HashtableX inFields = null;

    try
    {
      username = ClientUtils.getUsername(inVec);
      inFields = ClientUtils.getFieldsHash(inVec);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Error with incoming data.");
      return res;
    }

    User user = User.getUser(username);
    if (user == null)
    {
      res.errCode = 202;
      res.param.add("Unable to load user '" + username + "'");
      return res;
    }

    String appID = (String)inFields.get(CSFieldNames.FN_APP_ID);
    if (appID == null)
    {
      res.errCode = 202;
      res.param.add("Data Error: anAppId not sent in trigger.");
      return res;
    }

    String anFormHid = (String)inFields.get(CSFieldNames.FN_RETURN_FORM);
    if (anFormHid == null)
    {
      res.errCode = 202;
      res.param.add("Data Error: _anFormHid not sent.");
      return res;
    }

    boolean isCache = SDOUtils.isCache(anFormHid);

    SystemDataObject sdo = null;

    try
    {
      sdo = isCache ? SDODataCache.getSDO(username, appID) : SDOUtils.getSDO(appID);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Unable to load application '" + appID + "'.");
      return res;
    }

    if (sdo == null)
    {
      res.errCode = 202;
      res.param.add("Unable to locate application data in the cache for ID '" + appID + "'.");
      return res;
    }


    UserSession session = user.getUserSession();

    String productID = (String)inFields.get(CSFieldNames.FN_DEP_PROD_ID);
    HashtableX podFields = null;

    if (isAdd)
    {
      // If it is add.
    }
    else
    {
      String podIndex = (String)inFields.get(CSFieldNames.FN_DEP_POD_TBL);
      if (podIndex == null || podIndex.length() == 0)
      {
        res.errCode = 202;
        res.param.add("Please select a payable on death method from the table.");
        return res;
      }

      List<DataNode> podNodes = (List<DataNode>)session.getAttribute(DepUtils.POD_NODES + ":" + productID);
      if (podNodes == null)
      {
        res.errCode = 202;
        res.param.add("Unable to load payable on death data from user session.");
        return res;
      }

      DataNode podNode = podNodes.get(Integer.parseInt(podIndex));
      podFields = podNode.getFieldData("");
      // This is the index of the data node in the List in memory.  This will get used on the
      // save of the edited payable on death data.
      //
      podFields.put("daPODId", podIndex);
    }

    String formName = "Payable_On_Death_Details";
    Form form = FormLoader.loadForm(formName);
    if (form == null)
    {
      res.errCode = 202;
      res.param.add("Unable to load form '" + formName + "'");
      return res;
    }

    HashtableX fields = new HashtableX();
    if (podFields != null) fields.putAll(podFields);
    fields.put("_anProdTypeD", productID);
    fields.put(CSFieldNames.FN_APP_ID, appID);
    fields.put(CSFieldNames.FN_RETURN_FORM, anFormHid);

    try {
      DepUtils.populateSpecificVistas(username, form.getVistas(), sdo, fields);
    } catch (Exception e) {
      String msg = e.getMessage();
      if (msg == null) msg = e.toString();

      res.errCode = 202;
      res.param.add(msg);
      return res;
    }

    
    String where = (String)inFields.get(CSFieldNames.FN_RETURN_FORM);
    String mode = (String)inFields.get(CSFieldNames.FN_EDIT_MODE);
    
    DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);

    String branchID = (String)appNode.getFieldData("", CSFieldNames.FN_BRANCH_ID);
    int branch = StringSupport.strToInt(branchID);
    

    if (sdo == null)
    {
      res.errCode = 202;
      res.param.add("Unable to load System Data file for application '" + appID + "'");
      return res;
    }
    
    HashtableX instHash = new HashtableX();
    boolean canEdit = true;
    try {
		canEdit = CSUtil.editOrView(username, sdo);
	} catch (Exception e) {
		e.printStackTrace();
	}
    VectorX vistas = form.getVistas();
    for (int i = 0, c = vistas.size(); i < c; ++i)
    {
      if (!canEdit) instHash.put((String)vistas.get(i), ClientUtils.readOnlyVista());
      ClientUtils.populateVistaLists(branch, (String)vistas.get(i), inFields);
    }
    
    
    HashtableX response = super.createClientResponse(form, fields, instHash);

    res.param.add(response);
    return res;
  }


  private xResponse opCodeDelPOD(VectorX inVec)
  {
    xResponse res = new xResponse();

    String username = null;
    HashtableX inFields = null;

    try
    {
      username = ClientUtils.getUsername(inVec);
      inFields = ClientUtils.getFieldsHash(inVec);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Error with incoming data.");
      return res;
    }

    User user = User.getUser(username);
    if (user == null)
    {
      res.errCode = 202;
      res.param.add("Unable to load user '" + username + "'");
      return res;
    }

    String appID = (String)inFields.get(CSFieldNames.FN_APP_ID);
    if (appID == null)
    {
      res.errCode = 202;
      res.param.add("Data Error: appID not sent in trigger (anAppId).");
      return res;
    }

    String anFormHid = (String)inFields.get(CSFieldNames.FN_RETURN_FORM);
    if (anFormHid == null)
    {
      res.errCode = 202;
      res.param.add("Data Error: _anFormHid not sent.");
      return res;
    }

    boolean isCache = SDOUtils.isCache(anFormHid);

    SystemDataObject sdo = null;

    try
    {
      sdo = isCache ? SDODataCache.getSDO(username, appID) : SDOUtils.getSDO(appID);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Unable to load application '" + appID + "'.");
      return res;
    }

    if (sdo == null)
    {
      res.errCode = 202;
      res.param.add("Unable to locate application data in the cache for ID '" + appID + "'.");
      return res;
    }

    String productID = (String)inFields.get(CSFieldNames.FN_DEP_PROD_ID);

    // Have to populate the hidden field because the Payable_On_Death_Summary vista populator uses it.
    //
    inFields.put("_anProdTypeD", productID);

    // Get the list of payable on death nodes from memory.
    //
    UserSession session = user.getUserSession();
    List<DataNode> podNodes = (List<DataNode>)session.getAttribute(DepUtils.POD_NODES + ":" + productID);

    String podIndex = (String)inFields.get(CSFieldNames.FN_DEP_POD_TBL);
    if (podIndex == null || podIndex.length() == 0)
    {
      res.errCode = 202;
      res.param.add("Please select a payable on death from the table to delete.");
      return res;
    }

    podNodes.remove(Integer.parseInt(podIndex));

    session.setAttribute(DepUtils.POD_NODES + ":" + productID, podNodes);

    List<String> vistasToPopulate = new ArrayList<String>();
    vistasToPopulate.add("Payable_On_Death_Summary");

    try
    {
      DepUtils.populateSpecificVistas(username, vistasToPopulate, sdo, inFields);
    }
    catch (Exception e)
    {
      String msg = e.getMessage();
      if (msg == null) msg = e.toString();

      res.errCode = 202;
      res.param.add(msg);
      return res;
    }

    HashtableX response = super.createClientResponse((Form)null, inFields, null);

    res.param.add(response);
    return res;
  }


  private xResponse opCodeSavePOD(VectorX inVec)
  {
  XVectorExtractor.saveVector(inVec);
    xResponse res = new xResponse();

    String username = null;
    HashtableX inFields = null;

    try
    {
      username = ClientUtils.getUsername(inVec);
      inFields = ClientUtils.getFieldsHash(inVec);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Error with incoming data.");
      return res;
    }

    User user = User.getUser(username);
    if (user == null)
    {
      res.errCode = 202;
      res.param.add("Unable to load user '" + username + "'");
      return res;
    }

    String appID = (String)inFields.get(CSFieldNames.FN_APP_ID);
    if (appID == null)
    {
      res.errCode = 202;
      res.param.add("Data Error: appID not sent in trigger (anAppId).");
      return res;
    }

    String anFormHid = (String)inFields.get(CSFieldNames.FN_RETURN_FORM);
    if (anFormHid == null)
    {
      res.errCode = 202;
      res.param.add("Data Error: _anFormHid not sent.");
      return res;
    }

    boolean isCache = SDOUtils.isCache(anFormHid);

    SystemDataObject sdo = null;

    try
    {
      sdo = isCache ? SDODataCache.getSDO(username, appID) : SDOUtils.getSDO(appID);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Unable to load application '" + appID + "'.");
      return res;
    }

    if (sdo == null)
    {
      res.errCode = 202;
      res.param.add("Unable to locate application data in the cache for ID '" + appID + "'.");
      return res;
    }

    String productID = (String)inFields.get("_anProdTypeD");
    String podNodeIndex = (String)inFields.get("daPODId");
    boolean isAdd = podNodeIndex == null;

    UserSession session = user.getUserSession();
    List<DataNode> podNodes = (List<DataNode>)session.getAttribute(DepUtils.POD_NODES + ":" + productID);

    // Maintain a list of maps to store the payable on death fields into.  When the product is saved, we will
    // create data nodes for each map in the list and store the data node under the account.
    //
    HashtableX podFields = NodeUtils.separateDataHash(NodeUtils.DEP_POD_DN_TYPE, inFields, false);

    if (isAdd)
    {
      // Create the temporary data node and add it to the List in memory.
      //
      DataNode tempNode = new DataNode(NodeUtils.DEP_POD_DN_TYPE);
      tempNode.setFieldData(username, podFields);
      podNodes.add(tempNode);
    }
    else
    {
      // Don't save the payable on death id (this is the index into the List in memory).
      //
      podFields.remove("daPODId");

      DataNode tempNode = podNodes.get(Integer.parseInt(podNodeIndex));
      tempNode.setFieldData(username, podFields);
    }

    session.setAttribute(DepUtils.POD_NODES + ":" + productID, podNodes);

    List<String> vistasToPopulate = new ArrayList<String>();
    vistasToPopulate.add("Payable_On_Death_Summary");

    try
    {
      DepUtils.populateSpecificVistas(username, vistasToPopulate, sdo, inFields);
    }
    catch (Exception e)
    {
      String msg = e.getMessage();
      if (msg == null) msg = e.toString();

      res.errCode = 202;
      res.param.add(msg);
      return res;
    }

    HashtableX response = super.createClientResponse((Form)null, inFields, null);

    res.param.add(response);
    return res;
  }

  private xResponse opCodeAddOrEditIRA(VectorX inVec, boolean isAdd)
  {
  XVectorExtractor.saveVector(inVec);
    xResponse res = new xResponse();

    String username = null;
    HashtableX inFields = null;

    try
    {
      username = ClientUtils.getUsername(inVec);
      inFields = ClientUtils.getFieldsHash(inVec);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Error with incoming data.");
      return res;
    }

    User user = User.getUser(username);
    if (user == null)
    {
      res.errCode = 202;
      res.param.add("Unable to load user '" + username + "'");
      return res;
    }

    String appID = (String)inFields.get(CSFieldNames.FN_APP_ID);
    if (appID == null)
    {
      res.errCode = 202;
      res.param.add("Data Error: anAppId not sent in trigger.");
      return res;
    }

    String anFormHid = (String)inFields.get(CSFieldNames.FN_RETURN_FORM);
    if (anFormHid == null)
    {
      res.errCode = 202;
      res.param.add("Data Error: _anFormHid not sent.");
      return res;
    }

    boolean isCache = SDOUtils.isCache(anFormHid);

    SystemDataObject sdo = null;

    try
    {
      sdo = isCache ? SDODataCache.getSDO(username, appID) : SDOUtils.getSDO(appID);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Unable to load application '" + appID + "'.");
      return res;
    }

    if (sdo == null)
    {
      res.errCode = 202;
      res.param.add("Unable to locate application data in the cache for ID '" + appID + "'.");
      return res;
    }


    UserSession session = user.getUserSession();

    String productID = (String)inFields.get(CSFieldNames.FN_DEP_PROD_ID);
    HashtableX iraFields = null;

    if (isAdd)
    {
      // If it is add.
    }
    else
    {
      String iraIndex = (String)inFields.get(CSFieldNames.FN_DEP_IRA_TBL);
      if (iraIndex == null || iraIndex.length() == 0)
      {
        res.errCode = 202;
        res.param.add("Please select a beneficiary from the table.");
        return res;
      }

      List<DataNode> iraNodes = (List<DataNode>)session.getAttribute(DepUtils.IRA_NODES + ":" + productID);
      if (iraNodes == null)
      {
        res.errCode = 202;
        res.param.add("Unable to load IRA beneficiary data from user session.");
        return res;
      }

      DataNode iraNode = iraNodes.get(Integer.parseInt(iraIndex));
      iraFields = iraNode.getFieldData("");
      // This is the index of the data node in the List in memory.  This will get used on the
      // save of the edited payable on death data.
      //
      iraFields.put(DA_IRA_ID, iraIndex);
    }

    String formName = "IRA_Beneficiary_Details";
    Form form = FormLoader.loadForm(formName);
    if (form == null)
    {
      res.errCode = 202;
      res.param.add("Unable to load form '" + formName + "'");
      return res;
    }

    HashtableX fields = new HashtableX();
    if (iraFields != null) fields.putAll(iraFields);
    fields.put("_anProdTypeD", productID);
    fields.put(CSFieldNames.FN_APP_ID, appID);
    fields.put(CSFieldNames.FN_RETURN_FORM, anFormHid);

    try {
      DepUtils.populateSpecificVistas(username, form.getVistas(), sdo, fields);
    } catch (Exception e) {
      String msg = e.getMessage();
      if (msg == null) msg = e.toString();

      res.errCode = 202;
      res.param.add(msg);
      return res;
    }

    HashtableX response = super.createClientResponse(form, fields, null);

    res.param.add(response);
    return res;
  }


  private xResponse opCodeDelIRA(VectorX inVec)
  {
    xResponse res = new xResponse();

    String username = null;
    HashtableX inFields = null;

    try
    {
      username = ClientUtils.getUsername(inVec);
      inFields = ClientUtils.getFieldsHash(inVec);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Error with incoming data.");
      return res;
    }

    User user = User.getUser(username);
    if (user == null)
    {
      res.errCode = 202;
      res.param.add("Unable to load user '" + username + "'");
      return res;
    }

    String appID = (String)inFields.get(CSFieldNames.FN_APP_ID);
    if (appID == null)
    {
      res.errCode = 202;
      res.param.add("Data Error: appID not sent in trigger (anAppId).");
      return res;
    }

    String anFormHid = (String)inFields.get(CSFieldNames.FN_RETURN_FORM);
    if (anFormHid == null)
    {
      res.errCode = 202;
      res.param.add("Data Error: _anFormHid not sent.");
      return res;
    }

    boolean isCache = SDOUtils.isCache(anFormHid);

    SystemDataObject sdo = null;

    try
    {
      sdo = isCache ? SDODataCache.getSDO(username, appID) : SDOUtils.getSDO(appID);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Unable to load application '" + appID + "'.");
      return res;
    }

    if (sdo == null)
    {
      res.errCode = 202;
      res.param.add("Unable to locate application data in the cache for ID '" + appID + "'.");
      return res;
    }

    String productID = (String)inFields.get(CSFieldNames.FN_DEP_PROD_ID);

    // Have to populate the hidden field because the IRA_Beneficiary_Summary vista populator uses it.
    //
    inFields.put("_anProdTypeD", productID);

    // Get the list of payable on death nodes from memory.
    //
    UserSession session = user.getUserSession();
    List<DataNode> iraNodes = (List<DataNode>)session.getAttribute(DepUtils.IRA_NODES + ":" + productID);

    String iraIndex = (String)inFields.get(CSFieldNames.FN_DEP_IRA_TBL);
    if (iraIndex == null || iraIndex.length() == 0)
    {
      res.errCode = 202;
      res.param.add("Please select a ira beneficiary from the table to delete.");
      return res;
    }

    iraNodes.remove(Integer.parseInt(iraIndex));

    session.setAttribute(DepUtils.IRA_NODES + ":" + productID, iraNodes);

    List<String> vistasToPopulate = new ArrayList<String>();
    vistasToPopulate.add("IRA_Beneficiary_Summary");

    try
    {
      DepUtils.populateSpecificVistas(username, vistasToPopulate, sdo, inFields);
    }
    catch (Exception e)
    {
      String msg = e.getMessage();
      if (msg == null) msg = e.toString();

      res.errCode = 202;
      res.param.add(msg);
      return res;
    }

    HashtableX response = super.createClientResponse((Form)null, inFields, null);

    res.param.add(response);
    return res;
  }


  private xResponse opCodeSaveIRA(VectorX inVec)
  {
  XVectorExtractor.saveVector(inVec);
    xResponse res = new xResponse();

    String username = null;
    HashtableX inFields = null;

    try
    {
      username = ClientUtils.getUsername(inVec);
      inFields = ClientUtils.getFieldsHash(inVec);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Error with incoming data.");
      return res;
    }

    User user = User.getUser(username);
    if (user == null)
    {
      res.errCode = 202;
      res.param.add("Unable to load user '" + username + "'");
      return res;
    }

    String appID = (String)inFields.get(CSFieldNames.FN_APP_ID);
    if (appID == null)
    {
      res.errCode = 202;
      res.param.add("Data Error: appID not sent in trigger (anAppId).");
      return res;
    }

    String anFormHid = (String)inFields.get(CSFieldNames.FN_RETURN_FORM);
    if (anFormHid == null)
    {
      res.errCode = 202;
      res.param.add("Data Error: _anFormHid not sent.");
      return res;
    }

    boolean isCache = SDOUtils.isCache(anFormHid);

    SystemDataObject sdo = null;

    try
    {
      sdo = isCache ? SDODataCache.getSDO(username, appID) : SDOUtils.getSDO(appID);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Unable to load application '" + appID + "'.");
      return res;
    }

    if (sdo == null)
    {
      res.errCode = 202;
      res.param.add("Unable to locate application data in the cache for ID '" + appID + "'.");
      return res;
    }

    String productID = (String)inFields.get("_anProdTypeD");
    String iraNodeIndex = (String)inFields.get(DA_IRA_ID);
    boolean isAdd = iraNodeIndex == null;

    UserSession session = user.getUserSession();
    List<DataNode> iraNodes = (List<DataNode>)session.getAttribute(DepUtils.IRA_NODES + ":" + productID);

    // Maintain a list of maps to store the payable on death fields into.  When the product is saved, we will
    // create data nodes for each map in the list and store the data node under the account.
    //
    HashtableX iraFields = NodeUtils.separateDataHash(NodeUtils.DEP_IRA_DN_TYPE, inFields, false);

    if (isAdd)
    {
      // Create the temporary data node and add it to the List in memory.
      //
      DataNode tempNode = new DataNode(NodeUtils.DEP_IRA_DN_TYPE);
      tempNode.setFieldData(username, iraFields);
      iraNodes.add(tempNode);
    }
    else
    {
      // Don't save the ira id (this is the index into the List in memory).
      //
      iraFields.remove(DA_IRA_ID);

      DataNode tempNode = iraNodes.get(Integer.parseInt(iraNodeIndex));
      tempNode.setFieldData(username, iraFields);
    }

    session.setAttribute(DepUtils.IRA_NODES + ":" + productID, iraNodes);

    List<String> vistasToPopulate = new ArrayList<String>();
    vistasToPopulate.add("IRA_Beneficiary_Summary");

    try
    {
      DepUtils.populateSpecificVistas(username, vistasToPopulate, sdo, inFields);
    }
    catch (Exception e)
    {
      String msg = e.getMessage();
      if (msg == null) msg = e.toString();

      res.errCode = 202;
      res.param.add(msg);
      return res;
    }

    HashtableX response = super.createClientResponse((Form)null, inFields, null);

    res.param.add(response);
    return res;
  }

  private xResponse opCodeDiscardPG(VectorX inVec)
  {
    xResponse res = new xResponse();

    String username = null;

    try
    {
      username = ClientUtils.getUsername(inVec);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Error with incoming data.");
      return res;
    }

    User user = User.getUser(username);
    if (user == null)
    {
      res.errCode = 202;
      res.param.add("Unable to load user '" + username + "'");
      return res;
    }

    UserSession session = user.getUserSession();

    List<DataNode> tempAcctNodes = (List<DataNode>)session.getAttribute(DepUtils.PRD_GRP_SESSION_KEY);
    if (tempAcctNodes != null)
    {
      session.removeAttribute(DepUtils.PRD_GRP_SESSION_KEY);

      // Now remove the temp deposit account nodes that were stored in the user session
      // when starting the add of a product group.  Also remove any edits to the additional
      // account holders.
      //
      for (DataNode tempAcctNode : tempAcctNodes)
      {
        String individualProdID = (String)tempAcctNode.getFieldData(CSFieldValues.EMPTY_STRING,
                                                                    CSFieldNames.FN_DEP_PROD_ID);

        if (individualProdID != null)
        {
          session.removeAttribute(DepUtils.FUNDING_NODES + ":" + individualProdID);
          session.removeAttribute(DepUtils.POD_NODES + ":" + individualProdID);
          session.removeAttribute(DepUtils.IRA_NODES + ":" + individualProdID);
          session.removeAttribute(DepUtils.OVERDRAFT_ASSOC_ACCT_KEY + ":" + individualProdID);

          session.removeAttribute(DepUtils.ADDL_ACCT_HLDR_LIST_KEY + ":" + individualProdID);
          session.removeAttribute(DepUtils.ADDL_ACCT_HLDR_REL_KEY + ":" + individualProdID);
          session.removeAttribute(DepUtils.FEE_NODES + ":" + individualProdID);
        }
      }
    }

    return res;
  }



  private xResponse opCodeViewDecision(VectorX inVec)
  {
    xResponse res = new xResponse();

    String username = null;
    HashtableX inFields = null;

    try
    {
      username = ClientUtils.getUsername(inVec);
      inFields = ClientUtils.getFieldsHash(inVec);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Error with incoming data.");
      return res;
    }

    String appID = (String)inFields.get(CSFieldNames.FN_APP_ID_HID);
    if (appID == null)
    {
      res.errCode = 202;
      res.param.add("appID not sent in trigger (anIdHid).");
      return res;
    }

    String dcsnIndex = (String)inFields.get("_dcHistT");
    if (dcsnIndex == null)
    {
      res.errCode = 202;
      res.param.add("Please select a decision to view.");
      return res;
    }

    String formName = "View_Decision.DA";
    Form form = FormLoader.loadForm(formName);
    if (form == null)
    {
      res.errCode = 202;
      res.param.add("Unable to load form '" + formName + "'");
      return res;
    }

    String anFormHid = (String)inFields.get(CSFieldNames.FN_RETURN_FORM);
    boolean isCache = SDOUtils.isCache(anFormHid);

    SystemDataObject sdo = null;

    try
    {
      sdo = isCache ? SDODataCache.getSDO(username, appID) : SDOUtils.getSDO(appID);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Unable to load application '" + appID + "': " + e);
      return res;
    }

    if (sdo == null)
    {
      res.errCode = 202;
      res.param.add("Unable to locate application data for ID '" + appID + "'.");
      return res;
    }

    HashtableX fields = new HashtableX();

    DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);
    DataNode dcsnNode = appNode.getReference(NodeUtils.DCSN_DN_TYPE, Integer.parseInt(dcsnIndex));

    if (dcsnNode == null)
    {
      res.errCode = 202;
      res.param.add("Error: unable to locate decision #" + dcsnIndex + " in the data.");
      return res;
    }

    fields.putAll(dcsnNode.getFieldData(username));

    fields.put(CSFieldNames.FN_APP_ID_HID, appID);
    fields.put(CSFieldNames.FN_RETURN_FORM, anFormHid);

    String decision = (String) fields.get(CSFieldNames.FN_DCSN);
    if (decision != null)
    {
      fields.put(CSFieldNames.FN_DCSN_PRVDCSN, decision);

      if (decision.equals("Decline"))
      {
        form.getVistas().add("Decline_Decision_Details.DA");
      }
      else
      {
        form.getVistas().add("Approve_Decision_Details.DA");
      }
    }

    String decDate = (String) fields.get(CSFieldNames.FN_DCSN_DATE);
    String decParty = (String) fields.get(CSFieldNames.FN_DCSN_PARTY);

    if (decision != null) fields.put(CSFieldNames.FN_DCSN_PRVDCSN, decision);
    if (decParty != null) fields.put(CSFieldNames.FN_DCSN_PRV_UNDERWRITER, decParty);
    if (decDate != null) fields.put(CSFieldNames.FN_DCSN_PRVDCSN_DATE, decDate);

    try
    {
      fields.put(CSFieldNames.FN_DCSN_DECLINE_T,
                 DecisionUtils.buildDeclineReasonTable(appNode, dcsnNode, false));
      fields.put(CSFieldNames.FN_DCSN_BASE_T,
                 DecisionUtils.buildBaseTable(appNode, dcsnNode));
    }
    catch (Exception e)
    {
    }

    fields.put(CSFieldNames.FN_DCSN_STATUS, determineApplicationStatus(appNode));

    HashtableX response = super.createClientResponse(form, fields, null);

    res.param.add(response);
    return res;
  }



  private xResponse opCodeReportDetails(VectorX inVec)
  {
    xResponse res = new xResponse();
    HashtableX inFields = null;

    try
    {
      inFields = ClientUtils.getFieldsHash(inVec);
    }
    catch (Exception e)
    {
      res.errCode = 1;
      res.param.add("Error with incoming data.");
      return res;
    }

    String appID = (String) inFields.get(CSFieldNames.FN_APP_ID_HID);
    String borrowerNum = (String) inFields.get(CSFieldNames.FN_BWR_POS_HID);
    String reportNum = (String) inFields.get("cbAtReportT");

    if (appID == null)
    {
      res.errCode = 202;
      res.param.add("anAppId not in fields hash.");
      return res;
    }

AdminGUIManager.displayE("borrowerNum:" + borrowerNum);

    int bwrNum = 0;
    int rptNum = 0;

    try
    {
      bwrNum = Integer.parseInt(borrowerNum);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("_POSHid is invalid: " + bwrNum);
      return res;
    }

    try
    {
      rptNum = Integer.parseInt(reportNum);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("cbAtReportL is invalid: " + reportNum);
      return res;
    }

    SystemDataObject sdo = null;
    try
    {
      sdo = SDOUtils.getSDO(appID);
    }
    catch (SQLException e)
    {
    }

    if (sdo == null)
    {
      res.errCode = 202;
      res.param.addElement("Application file not found for " + appID);
      return res;
    }

    DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);
    if (appNode == null)
    {
      res.errCode = 202;
      res.param.add("Unable to find application data in SDO.");
      return res;
    }

    HashtableX fields = DecisionUtils.getBureauDataAndReport(appNode, bwrNum, rptNum);

    Form form = FormLoader.loadForm("Credit_Report.DA");

    HashtableX response = super.createClientResponse(form, fields, null);
    res.param.add(response);
    return res;
  }



  private xResponse opCodeScoreDetails(VectorX inVec)
  {
    xResponse res = new xResponse();
    HashtableX inFields = null;

    try
    {
      inFields = ClientUtils.getFieldsHash(inVec);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Error with incoming data.");
      return res;
    }

    String appID = (String) inFields.get(CSFieldNames.FN_APP_ID_HID);
    String borrowerNum = (String) inFields.get(CSFieldNames.FN_BWR_POS_HID);
    String scoreChoice = (String) inFields.get("cbAtScoreT");

    if (appID == null)
    {
      res.errCode = 202;
      res.param.add("anAppId not in fields hash.");
      return res;
    }

    int bwrNum = 0;
    try
    {
      bwrNum = Integer.parseInt(borrowerNum);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("_POSHid is invalid: " + borrowerNum);
      return res;
    }

    if (scoreChoice == null)
    {
      res.errCode = 202;
      res.param.add("cbAtScoreT is not in fields hash.");
      return res;
    }

    String scoreCode = scoreChoice;

    StringTokenizer tok = new StringTokenizer(scoreCode, ":");
    int tokCount = tok.countTokens();
    if (tokCount != 2)
    {
      res.errCode = 202;
      res.param.add("Invalid score list box value: " + scoreCode);
      return res;
    }

    String rptNumS = tok.nextToken();
    String scoreNumS = tok.nextToken();

    int rptNum = StringSupport.strToInt(rptNumS);
    int scoreNum = StringSupport.strToInt(scoreNumS);

    SystemDataObject sdo = null;
    try
    {
      sdo = SDOUtils.getSDO(appID);
    }
    catch (SQLException e)
    {
    }

    if (sdo == null)
    {
      res.errCode = 202;
      res.param.addElement("Application file not found for " + appID);
      return res;
    }

    DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);
    if (appNode == null)
    {
      res.errCode = 202;
      res.param.add("Unable to find application data in SDO.");
      return res;
    }

    HashtableX fields = DecisionUtils.getScoreData(appNode, bwrNum, rptNum, scoreNum);

    Form form = FormLoader.loadForm("Credit_Bureau_Score.DA");

    HashtableX response = super.createClientResponse(form, fields, null);
    res.param.add(response);
    return res;
  }


  private xResponse opCodeAddOrDelAcctHolder(VectorX inVec, boolean isAdd)
  {
    xResponse res = new xResponse();

    String username = null;
    HashtableX inFields = null;

    try
    {
      username = ClientUtils.getUsername(inVec);
      inFields = ClientUtils.getFieldsHash(inVec);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Error with incoming data.");
      return res;
    }

    User user = User.getUser(username);
    if (user == null)
    {
      res.errCode = 202;
      res.param.add("Unable to load user '" + username + "'");
      return res;
    }

    String appID = (String)inFields.get(CSFieldNames.FN_APP_ID);
    if (appID == null)
    {
      res.errCode = 202;
      res.param.add("Data Error: appID not sent in trigger (anAppId).");
      return res;
    }

    String anFormHid = (String)inFields.get(CSFieldNames.FN_RETURN_FORM);
    if (anFormHid == null)
    {
      res.errCode = 202;
      res.param.add("Data Error: _anFormHid not sent.");
      return res;
    }

    boolean isCache = SDOUtils.isCache(anFormHid);

    SystemDataObject sdo = null;

    try
    {
      sdo = isCache ? SDODataCache.getSDO(username, appID) : SDOUtils.getSDO(appID);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Unable to load application '" + appID + "'.");
      return res;
    }

    if (sdo == null)
    {
      res.errCode = 202;
      res.param.add("Unable to locate application data in the cache for ID '" + appID + "'.");
      return res;
    }

    String productID = (String)inFields.get(CSFieldNames.FN_DEP_PROD_ID);
    if (productID == null)
    {
      res.errCode = 202;
      res.param.add("Data Error: " + CSFieldNames.FN_DEP_PROD_ID + " not sent.");
      return res;
    }

    // Get the current additional account holder list and title map out of the user session.  If
    // they are not in the user session, then create a new list and map for the data.
    //
    UserSession session = user.getUserSession();

    List<String> aahList = (List<String>)session.getAttribute(DepUtils.ADDL_ACCT_HLDR_LIST_KEY + ":" + productID);
    if (aahList == null) aahList = new VectorX();

    Map<String, String> aahTitleMap = (Map<String, String>)session.getAttribute(DepUtils.ADDL_ACCT_HLDR_REL_KEY +
                                                                                ":" + productID);
    if (aahTitleMap == null) aahTitleMap = new HashtableX();

    if (isAdd)
    {
      String aahD = (String)inFields.get("_aahD");
      if (aahD == null)
      {
        res.errCode = 202;
        res.param.add("Please select an applicant from the dropdown list.");
        return res;
      }

      String relD = (String)inFields.get("_ahRelD");
      if (relD == null)
      {
        res.errCode = 202;
        res.param.add("Please select a relationship from the dropdown list.");
        return res;
      }

      // Now store the added account holder and title to the data within the session.
      //
      aahList.add(aahD);
      aahTitleMap.put(aahD, relD);

      session.setAttribute(DepUtils.ADDL_ACCT_HLDR_LIST_KEY + ":" + productID, aahList);
      session.setAttribute(DepUtils.ADDL_ACCT_HLDR_REL_KEY + ":" + productID, aahTitleMap);
    }
    else
    {
      // Deleting an account holder.
      //
      String applicantToDel = (String)inFields.get("_aahT");
      if (applicantToDel == null || applicantToDel.length() == 0)
      {
        res.errCode = 202;
        res.param.add("Please select an account holder to delete from the table.");
        return res;
      }

      // Remove the account holder from the additional account holder list and the relationship table.
      //
      aahList.remove(applicantToDel);
      aahTitleMap.remove(applicantToDel);

      session.setAttribute(DepUtils.ADDL_ACCT_HLDR_LIST_KEY + ":" + productID, aahList);
      session.setAttribute(DepUtils.ADDL_ACCT_HLDR_REL_KEY + ":" + productID, aahTitleMap);

      if (aahList.isEmpty()) session.removeAttribute(DepUtils.ADDL_ACCT_HLDR_LIST_KEY + ":" + productID);
      if (aahTitleMap.isEmpty()) session.removeAttribute(DepUtils.ADDL_ACCT_HLDR_REL_KEY + ":" + productID);
    }

    // Refresh the form.
    //
    HashtableX fields = new HashtableX();
    fields.put("_anProdTypeD", productID);

    List<String> vistasToRefresh = new ArrayList<String>();
    vistasToRefresh.add("Additional_Account_Holders.DA");

    try
    {
      DepUtils.populateSpecificVistas(username, vistasToRefresh, sdo, fields);
    }
    catch (Exception e)
    {
      String msg = e.getMessage();
      if (msg == null)
      {
        ExceptionLogger.logException(e);
        msg = "Error refreshing the form data: " + e.toString();
      }

      res.errCode = 202;
      res.param.add(msg);
      return res;
    }

    HashtableX response = super.createClientResponse((Form)null, fields, null);
    res.param.add(response);
    return res;
  }


  private xResponse opCodeAddOrDelODAssocAcct(VectorX inVec, boolean isAdd)
  {
    xResponse res = new xResponse();

    String username = null;
    HashtableX inFields = null;

    try
    {
      username = ClientUtils.getUsername(inVec);
      inFields = ClientUtils.getFieldsHash(inVec);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Error with incoming data.");
      return res;
    }

    User user = User.getUser(username);
    if (user == null)
    {
      res.errCode = 202;
      res.param.add("Unable to load user '" + username + "'");
      return res;
    }

    String appID = (String)inFields.get(CSFieldNames.FN_APP_ID);
    if (appID == null)
    {
      res.errCode = 202;
      res.param.add("Data Error: appID not sent in trigger (anAppId).");
      return res;
    }

    String anFormHid = (String)inFields.get(CSFieldNames.FN_RETURN_FORM);
    if (anFormHid == null)
    {
      res.errCode = 202;
      res.param.add("Data Error: _anFormHid not sent.");
      return res;
    }

    // _bwrPOSHid contains "pg" if we are editing a product from a group.  We need this
    // knowledge in the vista populator for the Associated_Accounts vista.
    //
    String bwrPOSHid = (String)inFields.get(CSFieldNames.FN_BWR_POS_HID);

    boolean isCache = SDOUtils.isCache(anFormHid);

    SystemDataObject sdo = null;

    try
    {
      sdo = isCache ? SDODataCache.getSDO(username, appID) : SDOUtils.getSDO(appID);
    }
    catch (Exception e)
    {
      res.errCode = 202;
      res.param.add("Unable to load application '" + appID + "'.");
      return res;
    }

    if (sdo == null)
    {
      res.errCode = 202;
      res.param.add("Unable to locate application data in the cache for ID '" + appID + "'.");
      return res;
    }

    String productID = (String)inFields.get(CSFieldNames.FN_DEP_PROD_ID);
    if (productID == null)
    {
      res.errCode = 202;
      res.param.add("Data Error: " + CSFieldNames.FN_DEP_PROD_ID + " not sent.");
      return res;
    }

    // Get the current additional account holder list and title map out of the user session.  If
    // they are not in the user session, then create a new list and map for the data.
    //
    UserSession session = user.getUserSession();

    List<DataNode> associatedAccounts = (List<DataNode>)session.getAttribute(DepUtils.OVERDRAFT_ASSOC_ACCT_KEY + ":" + productID);

    if (isAdd)
    {
      String depositAccountIndex = (String)inFields.get(CSFieldNames.FN_DEP_OVERDRAFT_ASSOC_ACCT);
      if (depositAccountIndex == null)
      {
        res.errCode = 202;
        res.param.add("Please select an account from the dropdown list to associate with this overdraft account.");
        return res;
      }

      DataNode tempNode = new DataNode(NodeUtils.DEP_OD_LINK_DN_TYPE);
      tempNode.setSystemData(username, CSFieldNames.FN_SYS_DEP_ACCT_INDEX, depositAccountIndex);

      associatedAccounts.add(tempNode);
    }
    else
    {
      String associatedAccountIndex = (String)inFields.get(CSFieldNames.FN_DEP_OVERDRAFT_ASSOC_ACCT_TBL);
      if (associatedAccountIndex == null || associatedAccountIndex.length() == 0)
      {
        res.errCode = 202;
        res.param.add("Please select an account from the table.");
        return res;
      }

      associatedAccounts.remove(Integer.parseInt(associatedAccountIndex));
    }

    // Refresh the form.
    //
    HashtableX fields = new HashtableX();
    fields.put("_anProdTypeD", productID);
    if (bwrPOSHid != null) fields.put(CSFieldNames.FN_BWR_POS_HID, bwrPOSHid);

    List<String> vistasToRefresh = new ArrayList<String>();
    vistasToRefresh.add("Associated_Accounts.DA");

    try
    {
      DepUtils.populateSpecificVistas(username, vistasToRefresh, sdo, fields);
    }
    catch (Exception e)
    {
      String msg = e.getMessage();
      if (msg == null)
      {
        ExceptionLogger.logException(e);
        msg = "Error refreshing the form data: " + e.toString();
      }

      res.errCode = 202;
      res.param.add(msg);
      return res;
    }

    HashtableX response = super.createClientResponse((Form)null, fields, null);
    res.param.add(response);
    return res;
  }


  private xResponse opCodeFinish(VectorX inVec)
  {
    return new xResponse();
  }


  private String getProductDetails(DepProduct prod)
  {
    StringBuilder msg = new StringBuilder();

    String id = CSFieldValues.EMPTY_STRING + prod.getID();
    String prodType = prod.getProductType() + " - " + prod.getLoanType();
    String name = prod.getName();

    String expDate = prod.getPrdExpireDate();
    String effDate = prod.getPrdEffectDate();

    VectorX descVec = prod.getDesc();
    StringBuilder desc = new StringBuilder();
    String nlStr = "\n";

    if (descVec != null && !descVec.isEmpty())
    {
      desc.append(nlStr).append( (String) descVec.firstElement()).append(nlStr);

      for (int i = 1; i < descVec.size(); i++)
      {
        desc.append( (String) descVec.elementAt(i)).append(nlStr);
      }

      desc.append(nlStr);
    }

    VectorX regVec = prod.getPrivateDesc();
    StringBuilder regulations = new StringBuilder();

    if (regVec != null && !regVec.isEmpty())
    {
      regulations.append(nlStr).append( (String) regVec.firstElement()).append(nlStr);

      for (int j = 1; j < regVec.size(); j++)
      {
        regulations.append( (String) regVec.elementAt(j)).append(nlStr);
      }

      regulations.append(nlStr);
    }

    msg.append("Product ID: \t").append( (id == null ?
                                          CSFieldValues.EMPTY_STRING : id)).
        append(nlStr);
    msg.append("Product Type: \t").append( (prodType == null ?
                                            CSFieldValues.EMPTY_STRING :
                                            prodType)).append(nlStr);
    msg.append("Name: \t\t").append( (name == null ? CSFieldValues.EMPTY_STRING :
                                      name)).append(nlStr);
    msg.append("Effective Date: \t").append( (effDate == null ?
                                              CSFieldValues.EMPTY_STRING :
                                              effDate)).append(nlStr);
    msg.append("Expiration Date: ").append( (expDate == null ? "None" : expDate)).
        append(nlStr);
    msg.append("Description: \t").append( (desc.length() == 0 ? nlStr :
                                           desc.toString()));
    msg.append("Definition: \t").append( (regulations.length() == 0 ?
                                          CSFieldValues.EMPTY_STRING :
                                          regulations.toString()));

    desc.delete(0, desc.length());
    regulations.delete(0, desc.length());
    return msg.toString();
  }


  private String translateFormToActivity (String formName)
  {
    if (formName == null)
    {
      return null;
    }

    if (formName.equals("View_Application.DA"))
    {
      return "DepViewApp";
    }

    if (formName.equals("Underwriting_Review.DA"))
    {
      return "DepUnderwriting";
    }

    if (formName.equals("ChangeStatus.DA"))
    {
      return OP_CODE_CHANGE_STATUS;
    }

    return null;
  }


  private void addVistaToFundingForm(String fundingType, Form form)
  {
    if (fundingType.equals(CSFieldValues.FV_DEP_FUND_TYPE_CASH_CHECKS))
    {
      form.getVistas().add(0, "Funding_Cash_Checks.DA");
    }
    else if (fundingType.equals(CSFieldValues.FV_DEP_FUND_TYPE_ONLINE))
    {
      form.getVistas().add(0, "Online_Funding.DA");
    }
    else if (fundingType.equals(CSFieldValues.FV_DEP_FUND_TYPE_OVERDRAFT))
    {
      form.getVistas().add(0, "Funding_Overdraft.DA");
    }
  }


  private List<DataNode> createTempDepAcctNodesForGroupRequest(Map<String, String[]> groupDetails,
                                                               StringBuilder groupDesc)
  {
    List<DataNode> depAcctNodes = new ArrayList<DataNode>();

    boolean filledDesc = false;

    Iterator it = groupDetails.keySet().iterator();
    while (it.hasNext())
    {
      String indivProdID = (String)it.next();
      String[] titleAndDesc = groupDetails.get(indivProdID);

      DataNode daNode = new DataNode(NodeUtils.DEP_ACCOUNT_DN_TYPE);
      daNode.setFieldData("", CSFieldNames.FN_DEP_PROD_ID, indivProdID);

      depAcctNodes.add(daNode);

      if (! filledDesc)
      {
        filledDesc = true;
        groupDesc.append(titleAndDesc[1]);
      }
    }

    return depAcctNodes;
  }


  private int getNumDepAccountsWithMatchingProductGroupID(String productGroupID, DataNode appNode)
  {
    int numMatches = 0;

    List<DataNode> depAccounts = appNode.getEffectiveReferences(NodeUtils.DEP_ACCOUNT_DN_TYPE);
    for (DataNode depAccount : depAccounts)
    {
      String prdGrpID = (String)depAccount.getSystemData(CSFieldNames.FN_SYS_DEP_PRD_GRP_ID);
      if (prdGrpID != null && prdGrpID.equals(productGroupID))
      {
        ++numMatches;
      }
    }

    return numMatches;
  }


  private List<DataNode> getDepAccountsWithMatchingProductGroupID(String productGroupID, DataNode appNode)
  {
    List<DataNode> matches = new ArrayList<DataNode>();

    List<DataNode> depAccounts = appNode.getEffectiveReferences(NodeUtils.DEP_ACCOUNT_DN_TYPE);
    for (DataNode depAccount : depAccounts)
    {
      String prdGrpID = (String)depAccount.getSystemData(CSFieldNames.FN_SYS_DEP_PRD_GRP_ID);
      if (prdGrpID != null && prdGrpID.equals(productGroupID))
      {
        matches.add(depAccount);
      }
    }

    return matches;
  }


  private DataNode findOverdraftAccountTiedToThisAccount(DataNode appNode, DataNode depAccount)
  throws Exception
  {
    DataNode odAccount = null;

    List<DataNode> accounts = appNode.getEffectiveReferences(NodeUtils.DEP_ACCOUNT_DN_TYPE);
    for (DataNode account : accounts)
    {
      if (DepUtils.isOverdraftProduct(account))
      {
        List<DataNode> odLinkAccounts = account.getEffectiveReferences(NodeUtils.DEP_OD_LINK_DN_TYPE);
        for (DataNode linkAccount : odLinkAccounts)
        {
          String linkAccountIndex = (String)linkAccount.getSystemData(CSFieldNames.FN_SYS_DEP_ACCT_INDEX);
          if (Integer.parseInt(linkAccountIndex) == depAccount.getIndex())
          {
            odAccount = account;
            break;
          }
        }
      }

      if (odAccount != null) break;
    }

    return odAccount;
  }


  private String determineApplicationStatus(DataNode appNode)
  {
    String status = (String)appNode.getSystemData(CSStatusCodes.SDO_STATUS);
    String statusDesc = null;

    if (status != null)
    {
      Map statusTable = CSDataCache.getCodeTableManager().getStatusCodes();
      if (statusTable != null)
      {
        statusDesc = (String)statusTable.get(status);
      }
    }

    return statusDesc != null ? statusDesc : CSFieldValues.EMPTY_STRING;
  }



  private void recordAppIdForHistory(String username, String appId)
  {
    User user = User.getUser2(username); // user may or may not be logged in
    if(user != null)
    {
      UserSession session = user.getUserSession();

      VectorX appIdVec = (VectorX) session.getAttribute("appId_History_List");
      if (appIdVec == null)
        appIdVec = new VectorX();

      if (!appIdVec.contains(appId)) {
        appIdVec.add(appId);
        session.setAttribute("appId_History_List", appIdVec);
      }
    }
  }
  private SystemDataObject getSDO (String appID, String where,
          String editMode, String username)
	{
	SystemDataObject sdo = null;
	
	if (SDOUtils.isCache(where, editMode))
	{
	//sdo = SDODataCache.getSDO(appID);
	sdo = SDODataCache.getSDO(username, appID);
	}
	
	else
	{
	try
	{
	sdo = SDOUtils.getSDO(appID);
	}
	catch (SQLException e)
	{
	e.printStackTrace();
	}
	}
	return sdo;
	}
}
