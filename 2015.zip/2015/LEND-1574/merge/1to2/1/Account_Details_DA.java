/**
 * <p>Title: Account_Details__DA</p>
 *
 * <p>Description: This class is the base class for the Deposit Account
 *                 vistas (CD, Checking, Savings).  It populates lists
 *                 for all elements common to the specific vista.  Any
 *                 subclass can provide additional field populations.</p>
 *
 * <p>Copyright: Copyright (c) 2012</p>
 *
 * <p>Company: ACI Corporation</p>
 *
 * @author Len Doerich
 * @version 1.0
 */

package vistaPopulator;

import com.xnai.credisphere.dataCache.CSDataCache;
import com.xnai.credisphere.depProduct.DepProduct;
import com.xnai.credisphere.deposits.DepUtils;
import com.xnai.credisphere.util.CSFieldNames;
import com.xnai.credisphere.vistaPop.VistaPopulator;

import com.xnai.mulder.application.ApplicationHouse;
import com.xnai.mulder.systemObject.DataNode;

import com.xnai.mulder.user.User;
import com.xnai.mulder.user.UserSession;
import com.xnai.mulder.util.ClientUtils;
import com.xnai.mulder.util.DateUtility;
import com.xnai.mulder.util.HashtableX;
import com.xnai.mulder.util.StringChanger;
import com.xnai.mulder.util.StringSupport;
import com.xnai.mulder.util.VectorX;

import java.util.List;
import java.util.Map;


public class Account_Details_DA extends VistaPopulator
{
  public Account_Details_DA(String username, DataNode appNode)
  {
    super(username, appNode);
  }


  @Override
  public void populate(Map fields)
  {
    String prodID = (String)fields.get("_anProdTypeD");
    Map productDescTable = CSDataCache.getDepProductManager().getProductDescMap();
    String productDesc = (String)productDescTable.get(prodID);

    fields.put(CSFieldNames.FN_DEP_PROD_ID, prodID + ClientUtils.TOKEN + productDesc);

    String openDate = (String)fields.get("daAcctOpenDt");
    if (openDate == null) fields.put("daAcctOpenDt", DateUtility.getTodaySlashDate());

    // display opening amount 
    String openAmt = (String)fields.get("daOpenAmt");
    if (openAmt != null) 
    {
    	fields.put(CSFieldNames.FN_DEP_OPEN_AMT, openAmt);
    }

    //add the read only service fee and overdraft fee
    //service fee
    VectorX fees = null;
    String prdServiceFeeD = null, prdOverdraftFeeD = null;
    DepProduct depProd = CSDataCache.getDepProductManager().getProduct(prodID);
    HashtableX productHT = StringChanger.stringToHashtable(StringChanger.getObjectBody(depProd.toString()));

    VectorX[] vec = ApplicationHouse.getListCodesCache().getListCodes("Service Fee", super.getBranchLocation());
    if(vec != null && vec.length == 2)
        fees = ClientUtils.createValLabelList(vec[0], vec[1]);
    else
      fees = null;

    if (productHT.containsKey("prdServiceFeeD"))
      prdServiceFeeD = (String)productHT.get("prdServiceFeeD");

    if(fees != null && fees.size() > 0)
    {
      if(prdServiceFeeD != null && prdServiceFeeD.length() > 0)
        fields.put("prdServiceFeeD", ClientUtils.markListSelection(prdServiceFeeD, fees));
      else
        fields.put("prdServiceFeeD", fees);
    }

    //overdraft fee
    vec = ApplicationHouse.getListCodesCache().getListCodes("Overdraft Fee", super.getBranchLocation());
    if(vec != null && vec.length == 2)
      fees = ClientUtils.createValLabelList(vec[0], vec[1]);
    else
      fees = null;

    if (productHT.containsKey("prdOverdraftFeeD"))
      prdOverdraftFeeD = (String)productHT.get("prdOverdraftFeeD");

    if(fees != null && fees.size() > 0)
    {
      if(prdServiceFeeD != null && prdServiceFeeD.length() > 0)
        fields.put("prdOverdraftFeeD", ClientUtils.markListSelection(prdOverdraftFeeD, fees));
      else
        fields.put("prdOverdraftFeeD", fees);
    }
  }

}
