update xntcomments set ccmt = 'Explanation of employment for Jordan: Jordan enlisted in Air Force right out of high school. Honorably discharged after 6 mos. After returning home Jordan worked for both his father as pay rolled employee and sportsman''s warehouse. Milestone tech offered higher pay with benefits; Jordan accepted his position at Milestone 6 mo. ago. Please refer to application # 102803'
where nappId = '102960' and
cuserid = 'sheltok01' and
cType = 'General'
GO
