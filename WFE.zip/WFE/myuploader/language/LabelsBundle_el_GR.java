/*
 * Copyright 2005-2009 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.language;
 
import java.util.ListResourceBundle;
 
/**
 * Class for the Greece labels.
 *
 * @author Johannes Postma
 */
public class LabelsBundle_el_GR extends ListResourceBundle {
 
      /** the dutch labels */
      static final Object[][] contents = {
            {"files", "Α�?χεία"},
            {"file", "Α�?χείο"},
            {"total_size", "Συνολικό μέγεθος"},
            {"message", "Μήνυμα"},
            {"max_files", "Ο μέγιστος α�?ιθμός α�?χείων μιας αίτησης είναι"},
            {"max_bytes", "Ο μέγιστος α�?ιθμός bytes μιας αίτησης είναι"},
            {"decrease", "Πα�?ακαλώ μειώστε τον α�?ιθμό α�?χείων."},
            {"upload_process", "Διαδικασία αποστολής"},
            {"status", "Κατάσταση"},
            {"connecting", "Συνδέεται"},
            {"time_left", "Απομένει χ�?όνος"},
            {"uploading", "Αποστέλλει"},
            {"bytes_sent", "Bytes εστάλησαν"},
            {"progress", "Π�?όοδος"},
            {"cancel", "Ακ�?�?ωση"},
            {"error_occurred", "Δημιου�?γία σφάλματος."},
            {"waiting_for_response", "Αναμονή για απάντηση"},
            {"error", "Σφάλμα"},
            {"nr", "Α�?"},
            {"size", "Μέγεθος"},
            {"interrupted", "Αδ�?νατη η επικοινωνία με το διακομιστή ή διακοπή σ�?νδεσης."},
            {"of", "από"},
            {"statuscode", "Δημιου�?γία σφάλματος. Κωδικός κατάστασης"},
            {"summary", "Σ�?νοψη"},
         
            {"paste", "Επικόλληση"},
            {"upload_completed", "Αποστολή ολοκλη�?ώθηκε."},
            {"basic_proxy_authentication", "Υποστη�?ίζεται μόνο 'basic' πιστοποίηση."},
            {"authentication_required", "Απαιτείται πιστοποίηση"},
            {"login_incorrect", "Σφάλμα εισόδου"},
            {"username", "Όνομα χ�?ήστη"},
            {"password", "Κωδικός"},
            {"scheme", "Πλάνο"},
            {"technical_error", "Τεχνικό σφάλμα."},
            {"unkown_host", "Άγνωστος κεντ�?ικός υπολογιστής"},
            {"uploadurl", "Εσφαλμένη πα�?άμετ�?ος 'uploadURL' "},
                 
            // JFileChooser
            {"lookInLabelText", "Αναζήτηση σε:"},
            {"filesOfTypeLabelText", "Α�?χεία τ�?που:"},
            {"upFolderToolTipText", "Πάνω ένα επίπεδο"},
            {"fileNameLabelText", "Όνομα α�?χείου:"},
            {"homeFolderToolTipText", "Α�?χή"},
            {"newFolderToolTipText", "Δημιου�?γία νέου φακέλου"},
            {"listViewButtonToolTipText", "Λίστα"},
            {"detailsViewButtonToolTipText", "Λεπτομέ�?ειες"},
            {"saveButtonText", "Αποθήκευση"},
            {"openButtonText", "Άνοιγμα"},
            {"cancelButtonText", "Ακ�?�?ωση"},
            {"updateButtonText", "Αλλαγή"},
            {"helpButtonText", "Βοήθεια"},
            {"saveButtonToolTipText", "Αποθήκευση επιλεγμένου α�?χείου"},
            {"openButtonToolTipText", "Άνοιγμα επιλεγμένου α�?χείου"},
            {"cancelButtonToolTipText", "Ματαίωση α�?χείου"},
            {"updateButtonToolTipText", "Αλλαγή δομής καταλόγου"},
            {"helpButtonToolTipText", "Βοήθεια"},
            {"myDialogTitle", "Άνοιγμα"},
            {"defaultFileFilterText", "όλος α�?χείο"},
            {"refreshActionLabelText", "Refresh"},
    		{"newFolderActionLabelText", "New Folder"},
    		{"listViewActionLabelText", "List"},
    		{"detailsViewActionLabelText", "Details"},
    		{"viewMenuLabelText", "View"},
    		{"fileDateHeaderText", "Modified"},
    		{"fileNameHeaderText", "File"},
    		{"fileSizeHeaderText", "Size"},
    		{"fileAttrHeaderText", "Attributes"},
            
    		{"javaVersion", "Files cannot be uploaded. You will\nneed at least the JavaPlugin 1.5."},		
    		{"dom", "Files cannot be uploaded. Please use another browser."},
    		
    		{"creatingZip", "Creating zip file"},
    		{"resize", "Resizing"},
    		{"checksum", "υπολογίζουν άθ�?οισμα ελέγχου"},
    		{"last_modified", "Last modified:"},
      };
     
      /**
       * Returns an array of Greece labels
       *
       * @return An array of Greece labels
       */
      public Object[][] getContents() {
            return contents;
      }
}

 