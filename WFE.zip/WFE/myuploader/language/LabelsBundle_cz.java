/*
 * Copyright 2005-2009 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.language;

import java.util.ListResourceBundle;

/**
 * Class for the Czech labels.
 * 
 * @author Johannes Postma
 */
public class LabelsBundle_cz extends ListResourceBundle {

	/** the Czech labels */
	static final Object[][] contents = {
		{"upload", "Nahrát"},
		{"add", "Přidat"},
		{"delete", "Ostranit"},
		{"files", "Soubory"},
		{"file", "Soubor"},
		{"total_size", "Celková velikost"},
		{"message", "Zpráva"},
		{"max_bytes", "Maximální velikost souborů v jednom požadavku v bytech je"},
		{"upload_process", "Status nahrávání"},
		{"status", "Status"},
		{"connecting", "Připojování"},
		{"time_left", "Zbývá"},
		{"uploading", "Nahrává se"},
		{"bytes_sent", "bytů odesláno"},
		{"progress", "průběh"},
		{"cancel", "Zrušit"},
		{"error_occurred", "Vyvstala chyba."},
		{"error", "Chyba"},
		{"nr", "Č"},
		{"size", "Velikost"},
		{"interrupted", "Nelze se spojit se serverem, nebo se přerušilo připojení."},
		{"of", "z"},
		{"statuscode", "Vyskytla se chyba. Kód"},
		{"summary", "Souhrn"},		
		{"paste", "Vložit"},
		{"basic_proxy_authentication", "Podporována je jen autentikace typu 'BASIC'."},
		{"authentication_required", "autentikace požadována"},
		{"login_incorrect", "Neplatné přihlašovací údaje"},
		{"username", "Uživatelské jméno"},
		{"password", "Heslo"},
		{"scheme", "Schéma"},
		{"technical_error", "Technická chyba."},
		{"unkown_host", "Neznámí server"},
		{"uploadurl", "Neplatný parametr 'uploadURL'"},
			
		// JFileChooser
		{"lookInLabelText", "Vyhledat v:"},
		{"filesOfTypeLabelText", "Soubory type:"},
		{"upFolderToolTipText", "O adresář zpět"},
		{"fileNameLabelText", "Soubor:"},
		{"homeFolderToolTipText", "Domů"},
		{"newFolderToolTipText", "Vytvořit nový adresář"},
		{"listViewButtonToolTipText", "Seznam"},
		{"detailsViewButtonToolTipText", "Detaily"},
		{"saveButtonText", "Uložit"},
		{"openButtonText", "Otevřít"},
		{"cancelButtonText", "Zrušit"},
		{"updateButtonText", "Wijzigen"}, //-------------------
		{"helpButtonText", "Pomoc"},
		{"saveButtonToolTipText", "Opslaan het geselecteerde bestand"}, //-------------------
		{"openButtonToolTipText", "Otevřít vybraný soubor"},
		{"updateButtonToolTipText", "Wijzig directory structuur"}, //-------------------
		{"helpButtonToolTipText", "Pomocný dialog"},
		{"myDialogTitle", "Otevřít"},
		{"defaultFileFilterText", "Všechny soubory"},
		{"viewMenuLabelText", "Zobrazit"},
		{"newFolderActionLabelText", "Nový adresář"},
		{"listViewActionLabelText", "Seznam"},
		{"detailsViewActionLabelText", "Detaily"},
		{"fileDateHeaderText", "Změněno"},
		{"fileNameHeaderText", "Soubor"},
		{"fileSizeHeaderText", "Velikost"},	
		{"fileAttrHeaderText", "Attributes"},
		
		{"javaVersion", "Soubor(y) nelze nahrát. Musíte mít nejméně JavaPlugin verze 1.5."},		
		
		{"creatingZip", "Vytvářím zip"},
		{"resize", "Mění se velikost fotek"},
		{"checksum", "Calculating checksum"},
		{"last_modified", "Last modified:"},
	};
	
	/**
	 * Returns an array of Czech labels
	 * 
	 * @return An array of Czech labels
	 */
	public Object[][] getContents() {
		return contents;
	}
}
