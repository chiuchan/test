/*
 * Copyright 2005-2008 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader;

import java.util.Vector;

import javaatwork.myuploader.domain.FormFileField;
import javaatwork.myuploader.utils.ByteFormatter;

import javax.swing.table.AbstractTableModel;

/** 
 * A TableModel use for displaying the files in the UploadApplet.
 *
 * @author Johannes Postma
 */
public class FileTableModel extends AbstractTableModel {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 7120915531732606878L;

	/** The collection of the data of the table */
	private Vector files = null;
	
	/** The columnNames */
	private String[] columnNames = null; 
	
	/**
	 * Creates a new FileTableModel.
	 * 
	 * @param files A collection of files.
	 */
	public FileTableModel(Vector files) {
		this.files = files;	
	}
	
	/** 
	 * Returns the position of the column. The first column
	 * has position 0;
	 * 
	 * @return The number of the column.
	 */
	public int getColumnCount() {
		return columnNames.length;
	}

	/** 
	 * Returns the number of rows.
	 * 
	 * @return The number of rows.
	 */
	public int getRowCount() {
		return files.size();
	}

	/**
	 * Returns the Object of a particular cell of the table.
	 * 
	 * @param rowIndex The row index.
	 * @param columnIndex The column index.
	 * @return The Object to be visualized.
	 */
	public Object getValueAt(int rowIndex, int columnIndex) {
		FormFileField fileField = (FormFileField)files.elementAt(rowIndex);
		
		switch(columnIndex) {
			case 0: return String.valueOf(rowIndex + 1) + ".";
			case 1: return fileField.getUploadName();
			case 2: return ByteFormatter.formatToKiloBytes((int)fileField.getFile().length());
		}
		
		return null;
	}
	
	/**
	 * Returns columnName.
	 *
	 * @param col The column.
	 * @return The columnName.
	 */
	public String getColumnName(int col) {
		return columnNames[col];
	}
	
	/**
	 * @param columnNames The columnNames to set.
	 */
	public void setColumnNames(String[] columnNames) {
		this.columnNames = columnNames;
	}
}
