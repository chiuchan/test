/*
 * Copyright 2005-2009 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.language;

import java.util.ListResourceBundle;

/**
 * Class for the Dutch labels.
 * 
 * @author Johannes Postma
 */
public class LabelsBundle_nl extends ListResourceBundle {

	/** the dutch labels */
	static final Object[][] contents = {
		{"upload", "Upload"},
		{"add", "Nieuw"},
		{"delete", "Verwijder"},
		{"files", "Bestanden"},
		{"file", "Bestand"},
		{"total_size", "Totale grootte"},
		{"message", "Bericht"},
		{"max_files", "Het maximale aantal bestanden van een request is"},
		{"max_bytes", "De totale grootte van bestanden overschrijden de upload limiet van"},
		{"decrease", "Verklein het aantal bestanden."},
		{"upload_process", "Upload Proces"},
		{"status", "Status"},
		{"connecting", "Verbinding maken"},
		{"time_left", "Resterende tijd"},
		{"uploading", "Uploaden"},
		{"bytes_sent", "Bytes verzonden"},
		{"progress", "Voortgang"},
		{"cancel", "Annuleer"},
		{"error_occurred", "Fout opgetreden."},
		{"waiting_for_response", "Wachten op antwoord"},
		{"error", "Fout"},
		{"nr", "Nr"},
		{"size", "Grootte"},
		{"interrupted", "Kan geen contact maken met server."},
		{"of", "van"},
		{"statuscode", "Fout opgetreden.  Statuscode"},
		{"summary", "Overzicht"},
		
		{"paste", "Plakken"},
		{"upload_completed", "Het uploaden is voltooid."},
		{"basic_proxy_authentication", "Alleen 'basic' authenticatie wordt ondersteund."},
		{"authentication_required", "Authenticatie verplicht"},
		{"login_incorrect", "Login incorrect"},
		{"username", "Gebruikersnaam"},
		{"password", "Wachtwoord"},
		{"scheme", "Schema"},
		{"technical_error", "Technische fout."},
		{"unkown_host", "Onbekende host"},
		{"uploadurl", "Incorrecte parameter 'uploadURL'"},
			
		// JFileChooser
		{"lookInLabelText", "Zoeken in:"},
		{"filesOfTypeLabelText", "Bestandstype:"},
		{"upFolderToolTipText", "Eén niveau naar boven"},
		{"fileNameLabelText", "Bestandsnaam:"},
		{"homeFolderToolTipText", "Home"},
		{"newFolderToolTipText", "Nieuwe map maken"},
		{"listViewButtonToolTipText", "Lijst"},
		{"detailsViewButtonToolTipText", "Details"},
		{"saveButtonText", "Opslaan"},
		{"openButtonText", "Openen"},
		{"cancelButtonText", "Annuleren"},
		{"updateButtonText", "Wijzigen"},
		{"helpButtonText", "Help"},
		{"saveButtonToolTipText", "Opslaan het geselecteerde bestand"},
		{"openButtonToolTipText", "Open geselecteerde bestand"},
		{"cancelButtonToolTipText", "Verlaat dialoog"},
		{"updateButtonToolTipText", "Wijzig directory structuur"},
		{"helpButtonToolTipText", "Help dialoog"},
		{"myDialogTitle", "Open"},
		{"defaultFileFilterText", "Alle bestanden"},
		{"refreshActionLabelText", "Vernieuwen"},
		{"newFolderActionLabelText", "Nieuwe map"},
		{"listViewActionLabelText", "Lijst"},
		{"detailsViewActionLabelText", "Details"},
		{"viewMenuLabelText", "Overzicht"},
		{"fileDateHeaderText", "Gewijzigd op"},
		{"fileNameHeaderText", "Bestand"},
		{"fileSizeHeaderText", "Grootte"},
		{"fileAttrHeaderText", "Attributen"},
		
		{"javaVersion", "De bestanden kunnen niet worden geupload. De JavaPlugin 1.5 of nieuwer is nodig."},		
		{"dom", "De bestanden kunnen niet worden geupload. Gebruik een andere browser."},
		
		{"creatingZip", "Maken zip bestand"},
		{"resize", "Afbeeldingen verkleinen"},
		{"checksum", "Berekenen checksum"},
		{"last_modified", "Laatst aangepast:"}
	};
	
	/**
	 * Returns an array of Dutch labels
	 * 
	 * @return An array of Dutch labels
	 */
	public Object[][] getContents() {
		return contents;
	}
}
