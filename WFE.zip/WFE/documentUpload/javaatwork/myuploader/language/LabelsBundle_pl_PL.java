/*
 * Copyright 2005-2009 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.language;

import java.util.ListResourceBundle;

/**
 * Class for the Polish labels.
 * 
 * @author Johannes Postma
 */
public class LabelsBundle_pl_PL extends ListResourceBundle {

	/** the polish labels */
	static final Object[][] contents = {
		{"upload", "Załaduj"},
		{"add", "Dodaj"},
		{"delete", "Usuń"},
		{"files", "Pliki"},
		{"file", "Plik"},
		{"total_size", "Całkowity rozmiar"},
		{"message", "Wiadomość"},
		{"max_files", "Maksymalna ilość plików ładowana jednorazowo to"},
		{"max_bytes", "Maksymalna ilość bajtów ładowana jednorazowo to"},
		{"decrease", "Zmniejsz liczbę plików"},
		{"upload_process", "Trwa kopiowanie"},
		{"status", "Status"},
		{"connecting", "Łączenie"},
		{"time_left", "Czas do końca"},
		{"uploading", "Ładowanie"},
		{"bytes_sent", "Wysłano bajtów"},
		{"progress", "Postęp"},
		{"cancel", "Anuluj"},
		{"error_occurred", "Wystąpił błąd."},
		{"waiting_for_response", "Oczekiwanie na odpowiedź"},
		{"error", "Błąd"},
		{"nr", "Nr"},
		{"size", "Rozmiar"},
		{"interrupted", "Nie można się połączyć z serwerem lub połączenie zostało przerwane."},
		{"of", "z"},
		{"statuscode", "Wystąpił błąd. Numer błędu"},
		{"summary", "Podsumowanie"},

		{"paste", "Wklej"},
		{"upload_completed", "Wyślij pliki zakończony."},
		{"basic_proxy_authentication", "Tylko 'basic' uwierzytelniony jest dostawca."},	
		{"authentication_required", "Uwierzytelniony wymagan"},
		{"login_incorrect", "Zgłoś się do systemu niepoprawny"},
		{"username", "Użytkownik wymienić"},
		{"password", "Hasło"},
		{"scheme", "Schemat"},
		{"technical_error", "Techniczny błąd."},
		{"unkown_host", "Nie wiedział zastęp"},
		{"uploadurl", "Niepoprawny parametr 'uploadURL'"},	

		//JFileChooser
		{"lookInLabelText", "Katalog:"},
		{"filesOfTypeLabelText", "Typ plików"},
		{"upFolderToolTipText", "Do góry"},
		{"fileNameLabelText", "Nazwa pliku"},
		{"homeFolderToolTipText", "Pulpit"},
		{"newFolderToolTipText", "Utwórz nowy folder"},
		{"listViewButtonToolTipText", "Lista"},
		{"detailsViewButtonToolTipText", "Detale"},
		{"saveButtonText", "Zapisz"},
		{"openButtonText", "Otwórz"},
		{"cancelButtonText", "Anuluj"},
		{"updateButtonText", "Aktualizuj"},
		{"helpButtonText", "Pomoc"},
		{"saveButtonToolTipText", "Zapisz zaznaczony plik"},
		{"openButtonToolTipText", "Otwórz zaznaczony plik"},
		{"cancelButtonToolTipText", "Anuluj"},
		{"updateButtonToolTipText", "Zaktualizuj listę katalogów"},
		{"helpButtonToolTipText", "Pomoc"},
		{"myDialogTitle", "Otworzyć"},
		{"defaultFileFilterText", "Wszystko pliki"},
		{"refreshActionLabelText", "Odśwież"},
		{"newFolderActionLabelText", "Nowy folder"},
		{"listViewActionLabelText", "Lista"},
		{"detailsViewActionLabelText", "Detale"},
		{"viewMenuLabelText", "Widok"},
		{"fileDateHeaderText", "Zmodyfikowano"},
		{"fileNameHeaderText", "Plik"},
		{"fileSizeHeaderText", "Rozmiar"},	
		{"fileAttrHeaderText", "Attributes"},
		
		{"javaVersion", "Pliki nie mogą być wysłane. Wymagane jest przynajmniej JavaPlugin 1.5."},		
		{"dom", "Pliki nie mogą być wysłane. Użyj innej przeglądarki."},
		
		{"creatingZip", "Creating zip file"},
		{"resize", "Resizing"},
		{"checksum", "Calculating checksum"},
		{"last_modified", "Last modified:"},
	};
	
	/**
	 * Returns an array of Polish labels
	 * 
	 * @return An array of Polish labels
	 */
	public Object[][] getContents() {
		return contents;
	}
}
