/*
 * Copyright 2005-2009 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.language;

import java.util.ListResourceBundle;

/**
 * Class for the Portuguese labels.
 * 
 * @author Johannes Postma
 */
public class LabelsBundle_pt_PT extends ListResourceBundle {

	/** the dutch labels */
	static final Object[][] contents = {
		{"upload", "Upload"},
		{"add", "Adicionar"},
		{"delete", "Apagar"},
		{"files", "Ficheiros"},
		{"file", "Ficheiro"},
		{"total_size", "Tamanho total"},
		{"message", "Mensagem"},
		{"max_files", "O numero máximo de ficheiros por pedido é"},
		{"max_bytes", "O numero máximo de bytes por pedido é"},
		{"decrease", "Por favor reduza o numero de ficheiros."},
		{"upload_process", "Processo de Upload"},
		{"status", "Status"},
		{"connecting", "A conectar"},
		{"time_left", "Tempo restante"},
		{"uploading", "Uploading"},
		{"bytes_sent", "Translated: Bytes enviados"},
		{"progress", "Progresso"},
		{"cancel", "Cancelar"},
		{"error_occurred", "Ocorreu um erro."},
		{"waiting_for_response", "A aguardar por resposta"},
		{"error", "Erro"},
		{"nr", "Nr"},
		{"size", "Tamanho"},
		{"interrupted", "Impossível contactar ao servidor ou a conexão foi interrompida."},
		{"of", "de"},
		{"statuscode", "Ocorreu um erro. Código de Status" },
		{"summary", "Sumário"},
		
		{"paste", "Colar"},
		{"upload_completed", "Upload completo."},
		{"basic_proxy_authentication", "Apenas o metodo de autenticação 'basic' é suportado."},	
		{"authentication_required", "Necessária autenticação"},
		{"login_incorrect", "Login incorrecto"},
		{"username", "Nome de utilizador"},
		{"password", "Senha"},
		{"scheme", "Método"},
		{"technical_error", "Erro técnico."},
		{"unkown_host", "Servidor desconhecido"},
		{"uploadurl", "Parâmetro errado: 'uploadURL'"},
		
		// JFileChooser
		{"lookInLabelText", "Procurar em:"},
		{"filesOfTypeLabelText", "Ficheiros do tipo:"},
		{"upFolderToolTipText", "Subir um nível"},
		{"fileNameLabelText", "Nome do ficheiro:"},
		{"homeFolderToolTipText", "Inicio"},
		{"newFolderToolTipText", "Criar Nova Pasta"},
		{"listViewButtonToolTipText", "Lista"},
		{"detailsViewButtonToolTipText", "Detalhes"},
		{"saveButtonText", "Salvar"},
		{"openButtonText", "Abrir"},
		{"cancelButtonText", "Cancelar"},
		{"updateButtonText", "Actualizar"},
		{"helpButtonText", "Ajuda"},
		{"saveButtonToolTipText", "Salvar o ficheiro seleccionado"},
		{"openButtonToolTipText", "Abrir ficheiro seleccionado"},
		{"cancelButtonToolTipText", "Abortar o dialogo de escolha de ficheiro"},
		{"updateButtonToolTipText", "Actualizar a lista de directórios"},
		{"helpButtonToolTipText", "Ajuda da escolha de ficheiros"},
		{"myDialogTitle", "Abrir"},
		{"defaultFileFilterText", "Todos os ficheiros"},
		{"refreshActionLabelText", "Actualizar"},
		{"newFolderActionLabelText", "Novo directório"},
		{"listViewActionLabelText", "Lista"},
		{"detailsViewActionLabelText", "Detalhes"},
		{"viewMenuLabelText", "Visualizar"},
		{"fileDateHeaderText", "Modificar"},
		{"fileNameHeaderText", "Ficheiro"},
		{"fileSizeHeaderText", "Tamanho"},
		{"fileAttrHeaderText", "Attributes"},
		
		{"javaVersion", "Impossível transferir os ficheiros. Precisa do JavaPlugin 1.5 ou superior."},		
		{"dom", "Não foi possível transferir os ficheiros. Por favor use outro navegador."},
		
		{"creatingZip", "Criar ficheiro zip"},
		{"resize", "Redimensionar imagens"},
		{"checksum", "Calcular checksum"},
		{"last_modified", "Última alteração:"}
	};
	
	/**
	 * Returns an array of Portuguese labels
	 * 
	 * @return An array of Portuguese labels
	 */
	public Object[][] getContents() {
		return contents;
	}
}
