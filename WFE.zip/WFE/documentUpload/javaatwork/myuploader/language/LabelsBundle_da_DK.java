/*
 * Copyright 2005-2009 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.language;

import java.util.ListResourceBundle;

/**
 * Class for the danish labels.
 * 
 * @author Johannes Postma
 */
public class LabelsBundle_da_DK extends ListResourceBundle {

	/** the danish labels */
	static final Object[][] contents = {
		{"upload", "Upload"},
		{"add", "Tilføj"},
		{"delete", "Slet"},
		{"files", "Filer"},
		{"file", "Fil"},
		{"total_size", "Størrelse i alt"},
		{"message", "Besked"},
		{"max_files", "Det maksimale antal filer der kan uploades er"},
		{"max_bytes", "Det maksimale antal bytes der kan uploades er"},
		{"decrease", "Fjern venligst nogle af de valgte filer."},
		{"upload_process", "Upload proces"},
		{"status", "Status"},
		{"connecting", "Forbinder"},
		{"time_left", "Tid tilbage"},
		{"uploading", "Uploader"},
		{"bytes_sent", "Bytes sendt"},
		{"progress", "Upload status"},
		{"cancel", "Annuller"},
		{"error_occurred", "Fejl opstod."},
		{"waiting_for_response", "Venter på svar"},
		{"error", "Fejl"},
		{"nr", "Nr"},
		{"size", "Størrelse"},
		{"interrupted", "Der kunne ikke opnåes forbindelse til serveren, eller forbindelsen blev afbrudt."},
		{"of", "af"},
		{"statuscode", "Der opstod en fejl. Status kode"},
		{"summary", "Opsummering"},

		{"paste", "Sæt ind"},
		{"upload_completed", "Upload er fuldført."},
		{"basic_proxy_authentication", "Kun 'basic' identifikation er understøttet."},	
		{"authentication_required", "Identifikation påkrævet"},
		{"login_incorrect", "Ukorrekt login"},
		{"username", "Brugernavn"},
		{"password", "Adgangskode"},
		{"scheme", "Metode"},
		{"technical_error", "Teknisk fejl."},
		{"unkown_host", "Ukendt host"},
		{"uploadurl", "Ukorrekt parameter 'uploadURL'"},	
		
		//JFileChooser
		{"lookInLabelText", "Søg i:"},
		{"filesOfTypeLabelText", "Filtype"},
		{"upFolderToolTipText", "Et niveau op"},
		{"fileNameLabelText", "Filnavn"},
		{"homeFolderToolTipText", "Home"},
		{"newFolderToolTipText", "Opret ny mappe"},
		{"listViewButtonToolTipText", "Liste"},
		{"detailsViewButtonToolTipText", "Detaljer"},
		{"saveButtonText", "Gem"},
		{"openButtonText", "Åben"},
		{"cancelButtonText", "Annuller"},
		{"updateButtonText", "Opdater"},
		{"helpButtonText", "Hjælå"},
		{"saveButtonToolTipText", "Gem den valgte fil"},
		{"openButtonToolTipText", "Åben den valgte fil"},
		{"cancelButtonToolTipText", "Luk dialog boksen"},
		{"updateButtonToolTipText", "Opdater biblioteks oversigt"},
		{"helpButtonToolTipText", "Hjælp til filvælger"},
		{"myDialogTitle", "Åbne"},
		{"defaultFileFilterText", "Alle filer"},
		{"refreshActionLabelText", "Opdater"},
		{"newFolderActionLabelText", "Ny Mappe"},
		{"listViewActionLabelText", "Liste"},
		{"detailsViewActionLabelText", "Detaljer"},
		{"viewMenuLabelText", "Vis"},
		{"fileDateHeaderText", "Ændret"},
		{"fileNameHeaderText", "Fil"},
		{"fileSizeHeaderText", "Størrelse"},	
		{"fileAttrHeaderText", "Attributes"},
		
		{"javaVersion", "Files cannot be uploaded. You will\nneed at least the JavaPlugin 1.5."},		
		{"dom", "Files cannot be uploaded. Please use another browser."},
		
		{"creatingZip", "Opretter zip fil"},
		{"resize", "Skalere billeder"},
		{"checksum", "Beregne checksum"},
		{"last_modified", "Ændret sidst:"},
		
	};
	
	/**
	 * Returns an array of danish labels
	 * 
	 * @return An array of danish labels
	 */
	public Object[][] getContents() {
		return contents;
	}
}
