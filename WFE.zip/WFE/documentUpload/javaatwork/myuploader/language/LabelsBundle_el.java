/*
 * Copyright 2005-2009 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.language;
 
import java.util.ListResourceBundle;
 
/**
 * Class for the Greece labels.
 *
 * @author Johannes Postma
 */
public class LabelsBundle_el extends ListResourceBundle {
 
      /** the dutch labels */
      static final Object[][] contents = {
            {"upload", "Αποστολή"},
            {"add", "Προσθήκη"},
            {"delete", "Διαγραφή"},
            {"files", "Αρχεία"},
            {"file", "Αρχείο"},
            {"total_size", "Συνολικό μέγεθος"},
            {"message", "Μήνυμα"},
            {"max_files", "Ο μέγιστος αριθμός αρχείων μιας αίτησης είναι"},
            {"max_bytes", "Ο μέγιστος αριθμός bytes μιας αίτησης είναι"},
            {"decrease", "Παρακαλώ μειώστε τον αριθμό αρχείων."},
            {"upload_process", "Διαδικασία αποστολής"},
            {"status", "Κατάσταση"},
            {"connecting", "Συνδέεται"},
            {"time_left", "Απομένει χρόνος"},
            {"uploading", "Αποστέλλει"},
            {"bytes_sent", "Bytes εστάλησαν"},
            {"progress", "Πρόοδος"},
            {"cancel", "Ακύρωση"},
            {"error_occurred", "Δημιουργία σφάλματος."},
            {"waiting_for_response", "Αναμονή για απάντηση"},
            {"error", "Σφάλμα"},
            {"nr", "Αρ"},
            {"size", "Μέγεθος"},
            {"interrupted", "Αδύνατη η επικοινωνία με το διακομιστή ή διακοπή σύνδεσης."},
            {"of", "από"},
            {"statuscode", "Δημιουργία σφάλματος. Κωδικός κατάστασης"},
            {"summary", "Σύνοψη"},
         
            {"paste", "Επικόλληση"},
            {"upload_completed", "Αποστολή ολοκληρώθηκε."},
            {"basic_proxy_authentication", "Υποστηρίζεται μόνο 'basic' πιστοποίηση."},
            {"authentication_required", "Απαιτείται πιστοποίηση"},
            {"login_incorrect", "Σφάλμα εισόδου"},
            {"username", "Όνομα χρήστη"},
            {"password", "Κωδικός"},
            {"scheme", "Πλάνο"},
            {"technical_error", "Τεχνικό σφάλμα."},
            {"unkown_host", "Άγνωστος κεντρικός υπολογιστής"},
            {"uploadurl", "Εσφαλμένη παράμετρος 'uploadURL' "},
                 
            // JFileChooser
            {"lookInLabelText", "Αναζήτηση σε:"},
            {"filesOfTypeLabelText", "Αρχεία τύπου:"},
            {"upFolderToolTipText", "Πάνω ένα επίπεδο"},
            {"fileNameLabelText", "Όνομα αρχείου:"},
            {"homeFolderToolTipText", "Αρχή"},
            {"newFolderToolTipText", "Δημιουργία νέου φακέλου"},
            {"listViewButtonToolTipText", "Λίστα"},
            {"detailsViewButtonToolTipText", "Λεπτομέρειες"},
            {"saveButtonText", "Αποθήκευση"},
            {"openButtonText", "Άνοιγμα"},
            {"cancelButtonText", "Ακύρωση"},
            {"updateButtonText", "Αλλαγή"},
            {"helpButtonText", "Βοήθεια"},
            {"saveButtonToolTipText", "Αποθήκευση επιλεγμένου αρχείου"},
            {"openButtonToolTipText", "Άνοιγμα επιλεγμένου αρχείου"},
            {"cancelButtonToolTipText", "Ματαίωση αρχείου"},
            {"updateButtonToolTipText", "Αλλαγή δομής καταλόγου"},
            {"helpButtonToolTipText", "Βοήθεια"},
            {"myDialogTitle", "Άνοιγμα"},
            {"defaultFileFilterText", "όλος αρχείο"},
            {"refreshActionLabelText", "Refresh"},
    		{"newFolderActionLabelText", "New Folder"},
    		{"listViewActionLabelText", "List"},
    		{"detailsViewActionLabelText", "Details"},
    		{"viewMenuLabelText", "View"},
    		{"fileDateHeaderText", "Modified"},
    		{"fileNameHeaderText", "File"},
    		{"fileSizeHeaderText", "Size"},
    		{"fileAttrHeaderText", "Attributes"},
            
    		{"javaVersion", "Files cannot be uploaded. You will\nneed at least the JavaPlugin 1.5."},		
    		{"dom", "Files cannot be uploaded. Please use another browser."},
    		
    		{"creatingZip", "Creating zip file"},
    		{"resize", "Resizing"},
    		{"checksum", "υπολογίζουν άθροισμα ελέγχου"},
    		{"last_modified", "Last modified:"},
      };
     
      /**
       * Returns an array of Greece labels
       *
       * @return An array of Greece labels
       */
      public Object[][] getContents() {
            return contents;
      }
}

 