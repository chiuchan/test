/*
 * Copyright 2005-2009 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.language;

import java.util.ListResourceBundle;

/**
 * Class for the Norwegian labels.
 * 
 * @author Johannes Postma
 */
public class LabelsBundle_no extends ListResourceBundle {

	/** the norwegian labels */
	static final Object[][] contents = {
		{ "upload", "Last opp" }, 
		{ "add", "Legg til" }, 
		{ "delete", "Slett" },
		{ "files", "Filer" }, 
		{ "file", "Fil" },
		{ "total_size", "Total str." }, 
		{ "message", "Melding" },
		{ "max_files", "Høyeste antall filer tillatt er" },
		{ "max_bytes", "Høyeste antall bytes pr opplasting er" },
		{ "decrease", "Vennligst minsk antall filer." },
		{ "upload_process", "Opplastings prosess" }, 
		{ "status", "Status" },
		{ "connecting", "Kobler til" }, 
		{ "time_left", "Tid igjen" },
		{ "uploading", "Laster opp" }, 
		{ "bytes_sent", "Bytes sendt" },
		{ "progress", "Status" }, 
		{ "cancel", "Avbryt" },
		{ "error_occurred", "Feil oppstod." },
		{ "waiting_for_response", "Venter på respons" },
		{ "error", "Feil" }, 
		{ "nr", "Nr" }, 
		{ "size", "Str" },
		{ "interrupted", "Kunne ikke kontakte server eller koblingen ble avbrutt." },
		{ "of", "av" }, 
		{ "statuscode", "Feil har oppstått.  Feilkode" },
		{ "summary", "Oppsummering" },
		
		{"paste", "Lim inn"},
		{"upload_completed", "Opplasting ferdig."},
		{"basic_proxy_authentication", "Kun 'basic' autentisering er støttet."},	
		{"authentication_required", "Autentisering kreves"},
		{"login_incorrect", "Innlogging ikke korrekt"},
		{"username", "Brukernavn"},
		{"password", "Passord"},
		{"scheme", "Skjema"},
		{"technical_error", "Teknisk feil."},
		{"unkown_host", "Ukjent vert"},
		{"uploadurl", "Feil parameter 'uploadURL'"},	
		
		//JFileChooser
		{"lookInLabelText", "Søk i:"},
		{"filesOfTypeLabelText", "Filtype"},
		{"upFolderToolTipText", "Et niveau op"},
		{"fileNameLabelText", "Filnavn"},
		{"homeFolderToolTipText", "Hjem"},
		{"newFolderToolTipText", "Opprett ny mappe"},
		{"listViewButtonToolTipText", "Liste"},
		{"detailsViewButtonToolTipText", "Detaljer"},
		{"saveButtonText", "Lagre"},
		{"openButtonText", "Åpne"},
		{"cancelButtonText", "Avbryt"},
		{"updateButtonText", "Oppdater"},
		{"helpButtonText", "Hjelp"},
		{"saveButtonToolTipText", "Lagre valgt fil"},
		{"openButtonToolTipText", "Åpne den valgte fil"},
		{"cancelButtonToolTipText", "Lukk dialogboksen"},
		{"updateButtonToolTipText", "Oppdater biblotekets oversikt"},
		{"helpButtonToolTipText", "Hjelp til filvelger"},
		{"myDialogTitle", "Åpne"},
		{"defaultFileFilterText", "Alle Filer"},
		{"refreshActionLabelText", "Oppdater"},
		{"newFolderActionLabelText", "Ny mappe"},
		{"listViewActionLabelText", "Liste"},
		{"detailsViewActionLabelText", "Detaljer"},
		{"viewMenuLabelText", "Vis"},
		{"fileDateHeaderText", "Endret"},
		{"fileNameHeaderText", "Fil"},
		{"fileSizeHeaderText", "Størrelse"},	
		{"fileAttrHeaderText", "Attributes"},
		
		{"javaVersion", "Files cannot be uploaded. You will\nneed at least the JavaPlugin 1.5."},		
		{"dom", "Files cannot be uploaded. Please use another browser."},
		
		{"creatingZip", "Lager ZIP-fil"},
		{"resize", "Omskalerer bildene"},
		{"checksum", "Beregning av checksum"},
		{"last_modified", "Sist endret:"}
	};
	
	/**
	 * Returns an array of Norwegian labels
	 * 
	 * @return An array of Norwegian labels
	 */
	public Object[][] getContents() {
		return contents;
	}
}
