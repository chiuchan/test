/*
 * Copyright 2005-2009 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.language;

import java.util.ListResourceBundle;

/**
 * Class for the Icelandic labels.
 * 
 * @author Johannes Postma
 */
public class LabelsBundle_is_IS extends ListResourceBundle {

	/** the dutch labels */
	static final Object[][] contents = {
		{"upload", "Senda skrár"},
		{"add", "Bæta við"},
		{"delete", "Fjarlægja"},
		{"files", "Skrár"},
		{"file", "Skrá"},
		{"total_size", "Heildarstærð"},
		{"message", " Skilaboð"},
		{"max_files", "Hámarksfjöldi skráa í einni fyrirspurn er"},
		{"max_bytes", "Hámarksfjöldi bæta í einni fyrirspurn"},
		{"decrease", "Vinsamlegast fækkaðu fjölda skráa."},
		{"upload_process", "Sending í vinnslu"},
		{"status", "Staða"},
		{"connecting", "Tengjast"},
		{"time_left", "Tími eftir"},
		{"uploading", "Sending í vinnslu"},
		{"bytes_sent", "Bæti sem búið er að senda"},
		{"progress", "Í vinnslu"},
		{"cancel", "Hætta við"},
		{"error_occurred", "Villa kom upp."},
		{"waiting_for_response", "Bíð eftir svari"},
		{"error", "Villa"},
		{"nr", "Nr"},
		{"size", "Stærð"},
		{"interrupted", "Gat ekki tengst miðlara eða tenging hefur verið rofin."},
		{"of", "af"},
		{"statuscode", "Villa kom upp"},
		{"summary", "Samantekt"},
		
		{"paste", "Líma"},
		{"upload_completed", "Sending kláruð."},
		{"basic_proxy_authentication", "Aðeins 'basic' aðgangsheimild er studd."},
		{"authentication_required", "Innskráningu krafist"},
		{"login_incorrect", "Innskráning mistókst"},
		{"username", "Notendanafn"},
		{"password", "Leyniorð"},
		{"scheme", "Skema"},
		{"technical_error", "Tæknileg villa."},
		{"unkown_host", "Óþekktur vefþjónn"},
		{"uploadurl", "Óþekkt breyta 'uploadURL'"},
			
		// JFileChooser
		{"lookInLabelText", "Líta inn í:"},
		{"filesOfTypeLabelText", "Tegund skráar:"},
		{"upFolderToolTipText", "Upp um eina möppu"},
		{"fileNameLabelText", "Skráarnafn:"},
		{"homeFolderToolTipText", "Heim"},
		{"newFolderToolTipText", "Búa til nýja möppu"},
		{"listViewButtonToolTipText", "Listi"},
		{"detailsViewButtonToolTipText", "Nánar"},
		{"saveButtonText", "Vista"},
		{"openButtonText", "Opna"},
		{"cancelButtonText", "Hætta við"},
		{"updateButtonText", "Breyta"},
		{"helpButtonText", "Hjálp"},
		{"saveButtonToolTipText", "Vista valda skrá"},
		{"openButtonToolTipText", "Opna valda skrá"},
		{"cancelButtonToolTipText", "Hætta við skráargluggann"},
		{"updateButtonToolTipText", "Breyta skráarstrúktur"},
		{"helpButtonToolTipText", "Hjálpargluggi"},
		{"myDialogTitle", "Opna"},
		{"defaultFileFilterText", "Allar skrár"},
		{"refreshActionLabelText", "Uppfæra"},
		{"newFolderActionLabelText", "Ný mappa"},
		{"listViewActionLabelText", "Listi"},
		{"detailsViewActionLabelText", "Nánar"},
		{"viewMenuLabelText", "Skoða"},
		{"fileDateHeaderText", "Breytt"},
		{"fileNameHeaderText", "Skrá"},
		{"fileSizeHeaderText", "Stærð"},	
		{"fileAttrHeaderText", "Attributes"},
		
		{"javaVersion", "Files cannot be uploaded. You will\nneed at least the JavaPlugin 1.5."},		
		{"dom", "Files cannot be uploaded. Please use another browser."},
		
		{"creatingZip", "Creating zip file"},
		{"resize", "Resizing"},
		{"checksum", "Calculating checksum"},
		{"last_modified", "Last modified:"},
	};
	
	/**
	 * Returns an array of Icelandic labels
	 * 
	 * @return An array of Icelandic labels
	 */
	public Object[][] getContents() {
		return contents;
	}
}

