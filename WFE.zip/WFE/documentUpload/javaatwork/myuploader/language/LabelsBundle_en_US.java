/*
 * Copyright 2005-2009 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.language;

import java.util.ListResourceBundle;

/**
 * Class for the english labels.
 * 
 * @author Johannes Postma
 */
public class LabelsBundle_en_US extends ListResourceBundle {

	/** the english labels */
	static final Object[][] contents = {
		{"upload", "Upload"},
		{"add", "Add"},
		{"delete", "Remove"},
		{"files", "Files"},
		{"file", "File"},
		{"total_size", "Total size"},
		{"message", "Message"},
		{"max_files", "The maximum number of files of one request is"},
		{"max_bytes", "The maximum number of bytes of one request is"},
		{"decrease", "Please decrease the number of files."}, 
		{"upload_process", "Upload Process"},  
		{"status", "Status"},
		{"connecting", "Connecting"},
		{"time_left", "Time left"},
		{"uploading", "Uploading"},
		{"bytes_sent", "Bytes sent"},
		{"progress", "Progress"},
		{"cancel", "Cancel"},
		{"error_occurred", "Error occurred."},
		{"waiting_for_response", "Waiting for response"},  
		{"error", "Error"},
		{"nr", "No"},
		{"size","Size"},
		{"interrupted", "Could not contact to server or connection is interrupted."},
		{"of", "of"},
		{"statuscode","Error occurred.  Statuscode"},
		{"summary", "Summary"},
		
		{"paste", "Paste"},
		{"upload_completed", "Upload completed."},
		{"basic_proxy_authentication", "Only 'basic' authentication is supported."},	
		{"authentication_required", "Authentication required"},
		{"login_incorrect", "Login incorrect"},
		{"username", "User name"},
		{"password", "Password"},
		{"scheme", "Scheme"},
		{"technical_error", "Technical error."},
		{"unkown_host", "Unkown host"},
		{"uploadurl", "Incorrect parameter 'uploadURL'"},
		
		{"javaVersion", "Files cannot be uploaded. You will\nneed at least the JavaPlugin 1.5."},		
		{"dom", "Files cannot be uploaded. Please use another browser."},
		
		{"creatingZip", "Creating zip file"},
		{"resize", "Resizing"},
		{"checksum", "Calculating checksum"},
		{"last_modified", "Last modified:"},
	};
	
	/**
	 * Returns an array of english labels
	 * 
	 * @return An array of english labels
	 */
	public Object[][] getContents() {
		return contents;
	}
}
