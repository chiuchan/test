/*
 * Copyright 2005-2009 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.language;

import java.util.ListResourceBundle;

/**
 * Class for the Simplified Chinese labels.
 * 
 * @author Johannes Postma
 */
public class LabelsBundle_zh extends ListResourceBundle {

	/** the Simplified Chinese labels */
	static final Object[][] contents = {
		{"upload", "\u4e0a\u4f20"},
		{"add", "\u589e\u52a0"},
		{"delete", "\u79fb\u9664"},
		{"files", "\u6587\u4ef6\u6570"},
		{"file", "\u6587\u4ef6"},
		{"total_size", "\u603b\u5927\u5c0f"},
		{"message", "\u4fe1\u606f"},
		{"max_files", "\u4e00\u4e2a\u8bf7\u6c42\u7684\u6700\u5927\u6587\u4ef6\u6570\u76ee\u662f"},
		{"max_bytes", "\u4e00\u4e2a\u8bf7\u6c42\u7684\u6700\u5927\u5b57\u8282\u6570\u76ee\u662f"},
		{"decrease", "\u8bf7\u51cf\u5c11\u6587\u4ef6\u7684\u6570\u76ee."},
		{"upload_process", "\u4e0a\u4f20\u8fc7\u7a0b"},
		{"status", "\u72b6\u6001"},
		{"connecting", "\u8fde\u63a5"},
		{"time_left", "\u5269\u4f59\u65f6\u95f4"},
		{"uploading", "\u6b63\u5728\u4e0a\u4f20"},
		{"bytes_sent", "\u5df2\u53d1\u9001\u5b57\u8282"},
		{"progress", "\u8fc7\u7a0b"},
		{"cancel", "\u53d6\u6d88"},
		{"error_occurred", "\u5df2\u53d1\u751f\u9519\u8bef."},
		{"waiting_for_response", "\u7b49\u5f85\u54cd\u5e94"},
		{"error", "\u9519\u8bef"},
		{"nr", "\u6570\u5b57"},
		{"size", "\u5927\u5c0f"},
		{"interrupted", "\u65e0\u6cd5\u8fde\u7edc\u5230\u670d\u52a1\u5668\u6216\u8fde\u63a5\u88ab\u963b\u65ad."},
		{"of", "\u5728"},
		{"statuscode", "\u9519\u8bef\u53d1\u751f. \u72b6\u6001\u7801"},
		{"summary", "\u6458\u8981"},
		
		{"paste", "\u7c98\u8d34"},
		{"upload_completed", "\u4e0a\u4f20\u5b8c\u6210."},
		{"basic_proxy_authentication", "\u53ea\u6709 'basic' \u9274\u522b\u88ab\u652f\u6301."},
		{"authentication_required", "\u5fc5\u9700\u7684\u9274\u522b"},
		{"login_incorrect", "\u4e0d\u6b63\u786e\u7684\u767b\u5f55"},
		{"username", "\u7528\u6237\u540d"},
		{"password", "\u5bc6\u7801"},
		{"scheme", "\u5b89\u6392"},
		{"technical_error", "\u6280\u672f\u4e0a\u7684\u9519\u8bef."},
		{"unkown_host", "\u672a\u77e5\u7684\u4e3b\u673a"},
		{"uploadurl", "\u4e0d\u6b63\u786e\u7684\u53c1\u6570 'uploadURL'"},
			
		// JFileChooser
		{"lookInLabelText", "\u67e5\u770b:"},
		{"filesOfTypeLabelText", "\u6587\u4ef6\u7c7b\u578b:"},
		{"upFolderToolTipText", "\u63d0\u9ad8\u4e00\u4e2a\u5c42\u6b21"},
		{"fileNameLabelText", "\u6587\u4ef6\u540d\u79f0:"},
		{"homeFolderToolTipText", "\u4e3b\u9875"},
		{"newFolderToolTipText", "\u4ea7\u751f\u65b0\u7684\u6587\u4ef6\u5939"},
		{"listViewButtonToolTipText", "\u5217\u8868"},
		{"detailsViewButtonToolTipText", "\u660e\u7ec6"},
		{"saveButtonText", "\u4fdd\u5b58"},
		{"openButtonText", "\u6253\u5f00"},
		{"cancelButtonText", "\u53d6\u6d88"},
		{"updateButtonText", "\u6539\u53d8"},
		{"helpButtonText", "\u5e2e\u52a9"},
		{"saveButtonToolTipText", "\u4fdd\u5b58\u6240\u9009\u6587\u4ef6"},
		{"openButtonToolTipText", "\u6253\u5f00\u6240\u9009\u6587\u4ef6"},
		{"cancelButtonToolTipText", "\u4e2d\u6b62\u6587\u4ef6\u5bf9\u8bdd\u6846"},
		{"updateButtonToolTipText", "\u6539\u53d8\u76ee\u5f55\u7ed3\u6784"},
		{"helpButtonToolTipText", "\u5e2e\u52a9\u5bf9\u8bdd\u6846"},
		{"myDialogTitle", "\u6253\u5f00"},
		{"defaultFileFilterText", "\u6240\u6709\u6587\u4ef6\u6570"},
		{"refreshActionLabelText", "Refresh"},
		{"newFolderActionLabelText", "New Folder"},
		{"listViewActionLabelText", "List"},
		{"detailsViewActionLabelText", "Details"},
		{"viewMenuLabelText", "View"},
		{"fileDateHeaderText", "Modified"},
		{"fileNameHeaderText", "File"},
		{"fileSizeHeaderText", "Size"},
		{"fileAttrHeaderText", "Attributes"},
		
		{"javaVersion", "Files cannot be uploaded. You will\nneed at least the JavaPlugin 1.5."},		
		{"dom", "Files cannot be uploaded. Please use another browser."},
		
		{"creatingZip", "Creating zip file"},
		{"resize", "Resizing"},
		{"checksum", "Calculating checksum"},
		{"last_modified", "Last modified:"},
	};
	
	/**
	 * Returns an array of Simplified Chinese labels
	 * 
	 * @return An array of Simplified Chinese labels
	 */
	public Object[][] getContents() {
		return contents;
	}
}

