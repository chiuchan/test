/*
 * Copyright 2005-2009 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.language;

import java.util.ListResourceBundle;

/**
 * Class for the French labels.
 * 
 * @author Johannes Postma
 */
public class LabelsBundle_fr_FR extends ListResourceBundle {

	/** the french labels */
	static final Object[][] contents = {
		{"upload", "Émission"}, 
		{"add", "Ajouter"},
		{"delete", "Supprimer"},
		{"files", "Fichiers"},
		{"file", "Fichier"},
		{"total_size", "Taille totale"},
		{"message", "Message"},
		{"max_files", "Le nombre maximum de fichier par requête est"},
		{"max_bytes", "Le nombre maximum de bytes par requête est"},
		{"decrease", "Merci de diminuer le nombre de fichiers."}, 
		{"upload_process", "Procédure d’émission"},  
		{"status", "Statut"},
		{"connecting", "Connexion"},
		{"time_left", "Temps restant"},
		{"uploading", "Émission"},
		{"bytes_sent", "Octets Envoyés"},
		{"progress", "Avancement"},
		{"cancel", "Annuler"},
		{"error_occurred", "Erreur survenue."},
		{"waiting_for_response", "En attente d’une réponse"},  
		{"error", "Erreur"},
		{"nr", "Nb"},
		{"size","Taille"},
		{"interrupted", "Impossible de dialoguer avec le serveur ou la connexion a été interrompue"},
		{"of"," sur"},
		{"statuscode","Erreur survenue. Code statut"},
		{"summary", "Sommaire"},
		
		{"paste", "Coller"},
		{"upload_completed", "Transfert terminé."},
		{"basic_proxy_authentication", "Seule l'authentification de 'basic' est supportée."},	
		{"authentication_required", "Authentification exigée"},
		{"login_incorrect", "Identifiant incorrect"},
		{"username", "Nom d’utilisateur"},
		{"password", "Mot de passe"},
		{"scheme", "Méthode"},
		{"technical_error", "Erreur technique."},
		{"unkown_host", "Hote inconnu"},
		{"uploadurl", "Paramètre 'uploadURL' incorrect."},
		
		{"javaVersion", "Files cannot be uploaded. You will\nneed at least the JavaPlugin 1.5."},		
		{"dom", "Files cannot be uploaded. Please use another browser."},
		
		{"creatingZip", "Création de l'archive zip"},
		{"resize", "Réduction des images"},
		{"checksum", "Le calcul de checksum"},
		{"last_modified", "Dernière modification:"}
	};
	
	/**
	 * Returns an array of French labels
	 * 
	 * @return An array of French labels
	 */
	public Object[][] getContents() {
		return contents;
	}

}
