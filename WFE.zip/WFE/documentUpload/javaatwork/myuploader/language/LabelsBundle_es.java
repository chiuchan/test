/*
 * Copyright 2005-2009 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.language;

import java.util.ListResourceBundle;

/**
 * Class for the spanish labels.
 * 
 * @author Johannes Postma
 */
public class LabelsBundle_es extends ListResourceBundle {

	/** the spanish labels */
	static final Object[][] contents = {
		{"upload", "Subir"},
		{"add", "Agregar"},
		{"delete", "Borrar"},
		{"files", "Archivo(s)"},
		{"file", "Archivo"},
		{"total_size", "Tamaño Total"},
		{"message", "Mensaje"},
		{"max_files", "El numero maximo de archivos de una peticion es"},
		{"max_bytes", "El numero maximo de bytes de una peticion es"},
		{"decrease", "Por favor disminuya el numero de archivos."},
		{"upload_process", "Carga en progreso"},
		{"status", "Estado"},
		{"connecting", "Conectando"},
		{"time_left", "Tiempo restante"},
		{"uploading", "Subiendo"},
		{"bytes_sent", "Bytes enviados"},
		{"progress", "Progreso"},
		{"cancel", "Cancelar"},
		{"error_occurred", "Ocurrio un error."},
		{"waiting_for_response", "Esperando una respuesta"},
		{"error", "Error"},
		{"nr", "Nr"},
		{"size", "Tamaño"},
		{"interrupted", "No se puede conectar con el servidor o la conexion ha sido interrumpida."},
		{"of", "de"},
		{"statuscode", "Ocurrio un error. Estado Codigo"},
		{"summary", "Sumario"},

		{"paste", "Pegar"},
		{"upload_completed", "Transferencia completada."},
		{"basic_proxy_authentication", "Sólo se soporta autenticación 'basic'."},	
		{"authentication_required", "Autenticación requerida"},
		{"login_incorrect", "Usuario incorrecto"},
		{"username", "Nombre de usuario"},
		{"password", "Contraseña"},
		{"scheme", "Esquema"},
		{"technical_error", "Error técnico."},
		{"unkown_host", "Servidor desconocido"},
		{"uploadurl", "Parámetro incorrecto 'uploadURL'"},
		
		//JFileChooser
		{"lookInLabelText", "Mirar en:"},
		{"filesOfTypeLabelText", "Archivos del Tipo:"},
		{"upFolderToolTipText", "Subir un nivel"},
		{"fileNameLabelText", "Nombre archivo:"},
		{"homeFolderToolTipText", "Home"},
		{"newFolderToolTipText", "Crear una nueva carpeta"},
		{"listViewButtonToolTipText", "Lista"},
		{"detailsViewButtonToolTipText", "Detalles"},
		{"saveButtonText", "Grabar"},
		{"openButtonText", "Abrir"},
		{"cancelButtonText", "Cancelar"},
		{"updateButtonText", "Actualizar"},
		{"helpButtonText", "Ayuda"},
		{"saveButtonToolTipText", "Grabar archivos Seleccionados"},
		{"openButtonToolTipText", "Abrir archivos seleccionados"},
		{"cancelButtonToolTipText", "Interrumpir dialogo de Archivo"},
		{"updateButtonToolTipText", "Actualizar directorio"},
		{"helpButtonToolTipText", "Seleccionar archivo de ayuda"},
		{"myDialogTitle", "Abrir"},
		{"defaultFileFilterText", "Todos archivos"},
		{"refreshActionLabelText", "Actualizar"},
		{"newFolderActionLabelText", "Nueva Carpeta"},
		{"listViewActionLabelText", "Lista"},
		{"detailsViewActionLabelText", "Detalles"},
		{"viewMenuLabelText", "Vista"},
		{"fileDateHeaderText", "Modificado"},
		{"fileNameHeaderText", "Fichero"},
		{"fileSizeHeaderText", "Tamaño"},
		{"fileAttrHeaderText", "Attributes"},
		
		{"javaVersion", "Los ficheros no pueden ser transferidos. Necesita al menos el Plugin de Java 1.5."},		
		{"dom", "Los ficheros no pueden ser transferidos. Por favor, utilice otro navegador."},
		
		{"creatingZip", "Creating zip file"},
		{"resize", "Reescalando imágenes"},
		{"checksum", "Calcular checksum"},
		{"last_modified", "Última modificación:"},
	};
	
	/**
	 * Returns an array of danish labels
	 * 
	 * @return An array of danish labels
	 */
	public Object[][] getContents() {
		return contents;
	}
}
