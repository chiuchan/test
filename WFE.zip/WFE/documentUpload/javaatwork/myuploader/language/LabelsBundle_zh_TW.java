/*
 * Copyright 2005-2009 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.language;

import java.util.ListResourceBundle;

/**
 * Class for the Traditional Chinese labels.
 * 
 * @author Johannes Postma
 */
public class LabelsBundle_zh_TW extends ListResourceBundle {

	/** the Traditional Chinese labels */
	static final Object[][] contents = {
		{"upload", "\u4e0a\u50b3"},
		{"add", "\u589e\u52a0"},
		{"delete", "\u79fb\u9664"},
		{"files", "\u6587\u4ef6\u6578"},
		{"file", "\u6587\u4ef6"},
		{"total_size", "\u7e3d\u5927\u5c0f"},
		{"message", "\u4fe1\u606f"},
		{"max_files", "\u4e00\u500b\u8acb\u6c42\u7684\u6700\u5927\u6587\u4ef6\u6578\u76ee\u662f"},
		{"max_bytes", "\u4e00\u500b\u8acb\u6c42\u7684\u6700\u5927\u5b57\u7bc0\u6578\u76ee\u662f"},
		{"decrease", "\u8acb\u6e1b\u5c11\u6587\u4ef6\u7684\u6578\u76ee."},
		{"upload_process", "\u4e0a\u50b3\u904e\u7a0b"},
		{"status", "\u72c0\u614b"},
		{"connecting", "\u9023\u63a5"},
		{"time_left", "\u5269\u4f59\u6642\u9593"},
		{"uploading", "\u6b63\u5728\u4e0a\u50b3"},
		{"bytes_sent", "\u5df2\u767c\u9001\u5b57\u7bc0"},
		{"progress", "\u904e\u7a0b"},
		{"cancel", "\u53d6\u6d88"},
		{"error_occurred","\u5df2\u767c\u751f\u932f\u8aa4."},
		{"waiting_for_response", "\u7b49\u5f85\u97ff\u61c9"},
		{"error", "\u932f\u8aa4"},
		{"nr", "\u6578\u5b57"},
		{"size", "\u5927\u5c0f"},
		{"interrupted", "\u7121\u6cd5\u9023\u7d61\u5230\u670d\u52d9\u5668\u6216\u9023\u63a5\u88ab\u963b\u65b7."},
		{"of", "\u5728"},
		{"statuscode", "\u932f\u8aa4\u767c\u751f. \u72c0\u614b\u78bc"},
		{"summary", "\u6458\u8981"},
		
		{"paste", "\u7c98\u8cbc"},
		{"upload_completed", "\u4e0a\u50b3\u5b8c\u6210."},
		{"basic_proxy_authentication", "\u53ea\u6709 'basic' \u9452\u5225\u88ab\u652f\u6301"},
		{"authentication_required", "\u5fc5\u9700\u7684\u9452\u5225"},
		{"login_incorrect", "\u4e0d\u6b63\u786e\u7684\u767b\u9304"},
		{"username", "\u7528\u6236\u540d"},
		{"password", "\u5bc6\u78bc"},
		{"scheme", "\u5b89\u6392"},
		{"technical_error", "\u6280\u8853\u4e0a\u7684\u932f\u8aa4."},
		{"unkown_host", "\u672a\u77e5\u7684\u4e3b\u673a"},
		{"uploadurl", "\u4e0d\u6b63\u786e\u7684\u676c\u6578 'uploadURL'"},
			
		// JFileChooser
		{"lookInLabelText", "\u67e5\u770b:"},
		{"filesOfTypeLabelText", "\u6587\u4ef6\u985e\u578b:"},
		{"upFolderToolTipText", "\u63d0\u9ad8\u4e00\u500b\u5c64\u6b21"},
		{"fileNameLabelText", "\u6587\u4ef6\u540d\u7a31:"},
		{"homeFolderToolTipText", "\u4e3b\u9801"},
		{"newFolderToolTipText", "\u7522\u751f\u65b0\u7684\u6587\u4ef6\u593e"},
		{"listViewButtonToolTipText", "\u5217\u8868"},
		{"detailsViewButtonToolTipText", "\u660e\u7d30"},
		{"saveButtonText", "\u4fdd\u5b58"},
		{"openButtonText", "\u6253\u958b"},
		{"cancelButtonText", "\u53d6\u6d88"},
		{"updateButtonText", "\u6539\u8b8a"},
		{"helpButtonText", "\u5e6b\u52a9"},
		{"saveButtonToolTipText", "\u4fdd\u5b58\u6240\u9078\u6587\u4ef6"},
		{"openButtonToolTipText", "\u6253\u958b\u6240\u9078\u6587\u4ef6"},
		{"cancelButtonToolTipText", "\u4e2d\u6b62\u6587\u4ef6\u5c0d\u8a71\u6846"},
		{"updateButtonToolTipText", "\u6539\u8b8a\u76ee\u9304\u7d50\u6784"},
		{"helpButtonToolTipText", "\u5e6b\u52a9\u5c0d\u8a71\u6846"},
		{"myDialogTitle", "\u6253\u958b"},
		{"defaultFileFilterText", "\u6240\u6709\u6587\u4ef6\u6578"},
		{"refreshActionLabelText", "Refresh"},
		{"newFolderActionLabelText", "New Folder"},
		{"listViewActionLabelText", "List"},
		{"detailsViewActionLabelText", "Details"},
		{"viewMenuLabelText", "View"},
		{"fileDateHeaderText", "Modified"},
		{"fileNameHeaderText", "File"},
		{"fileSizeHeaderText", "Size"},
		{"fileAttrHeaderText", "Attributes"},
		
		{"javaVersion", "Files cannot be uploaded. You will\nneed at least the JavaPlugin 1.5."},		
		{"dom", "Files cannot be uploaded. Please use another browser."},
		
		{"creatingZip", "Creating zip file"},
		{"resize", "Resizing"},
		{"checksum", "Calculating checksum"},
		{"last_modified", "Last modified:"},
	};
	
	/**
	 * Returns an array of Traditional Chinese labels
	 * 
	 * @return An array of Traditional Chinese labels
	 */
	public Object[][] getContents() {
		return contents;
	}
}

