/*
 * Copyright 2005-2009 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.language;

import java.util.ListResourceBundle;

/**
* Class for the Korean labels.
*
* @author Johannes Postma
*/
public class LabelsBundle_ko_KR extends ListResourceBundle {

   /** the Korean labels */
   static final Object[][] contents = {
       {"upload", "\uc5c5\ub85c\ub4dc"},
       {"add", "\ucd94\uac00"},
       {"delete", "\uc0ad\uc81c"},
       {"files", "\ud30c\uc77c\ub4e4"},
       {"file", "\ud30c\uc77c"},
       {"total_size", "\uc804\uccb4\ud06c\uae30"},
       {"message","\uba54\uc2dc\uc9c0"},
       {"max_files", "\uc694\uad6c\ud558\ub294 \uac83 \uc911 \uac00\uc7a5 \ud070 \uc218\uc758 \ud30c\uc77c"},
       {"max_bytes", "\uc694\uad6c\ud558\ub294 \uac83 \uc911 \uac00\uc7a5 \ud070 \uc218\uc758 \ubc14\uc774\ud2b8"},
       {"decrease", "\ud30c\uc77c\uc758 \uac1c\uc218\ub97c \uc904\uc774\uc138\uc694."},
       {"upload_process", "\uc5c5\ub85c\ub4dc\uacfc\uc815"},
       {"status", "\uc0c1\ud0dc"},
       {"connecting", "\uc5f0\uacb0"},
       {"time_left", "\uc794\uc5ec\uc2dc\uac04"},
       {"uploading", "\uc5c5\ub85c\ub4dc \uc911"},
       {"bytes_sent", "\ubcf4\ub0b8 \ubc14\uc774\ud2b8"},
       {"progress", "\uc9c4\ud589 \uc911"},
       {"cancel", "\ucde8\uc18c"},
       {"error_occurred", "\uc624\ub958\ubc1c\uc0dd."},
       {"waiting_for_response", "\ubc18\uc751\uc744 \uae30\ub2e4\ub9ac\ub294 \uc911"},
       {"error", "\uc624\ub958"},
       {"nr", "\uc218"},
       {"size", "\ud06c\uae30"},
       {"interrupted", "\uc11c\ubc84\uc5d0 \uc811\uc18d\ud560 \uc218 \uc5c6\uac70\ub098 \uc5f0\uacb0\uc774 \uc911\ub2e8\ub418\uc5c8\uc2b5\ub2c8\ub2e4."},
       {"of", "\uc5d0"},
       {"statuscode", "\uc624\ub958\ubc1c\uc0dd / \uc0c1\ud0dc\ucf54\ub4dc"},
       {"summary", "\uc694\uc57d"},
       
       {"paste", "\ubd99\uc784"},
       {"upload_completed", "\uc5c5\ub85c\ub4dc\uc644\ub8cc."},
       {"basic_proxy_authentication", "\uae30\ubcf8 \uc778\uc99d\ub9cc \uc9c0\uc6d0\ub429\ub2c8\ub2e4."},
       {"authentication_required", "\uc694\uad6c\ub418\ub294 \uc778\uc99d"},
       {"login_incorrect", "\uc798\ubabb\ub41c \ub85c\uadf8\uc778"},
       {"username", "\uc0ac\uc6a9\uc790\uba85"},
       {"password", "\ube44\ubc00\ubc88\ud638"},
       {"scheme", "\uc2a4\ud0a4\ub9c8"},
       {"technical_error", "\uae30\uc220\uc801\uc778 \uc5d0\ub7ec."},
       {"unkown_host", "\uc54c \uc218 \uc5c6\ub294 \ud638\uc2a4\ud2b8"},
       {"uploadurl", "\uc798\ubabb\ub41c \ud30c\ub77c\uba54\ud130\uc778 'uploadURL'"},
       
       // JFileChooser
       {"lookInLabelText", "\uc5ff\ubcf4\uae30:"},
       {"filesOfTypeLabelText", "\ud30c\uc77c\uc720\ud615:"},
       {"upFolderToolTipText", "\uc5c5\ub85c\ub4dc \ub808\ubca8"},
       {"fileNameLabelText", "\ud30c\uc77c\uba85:"},
       {"homeFolderToolTipText", "\ud648"},
       {"newFolderToolTipText", "\uc0c8\ub85c\uc6b4 \ud3f4\ub354 \ub9cc\ub4e4\uae30"},
       {"listViewButtonToolTipText", "\ubaa9\ub85d"},
       {"detailsViewButtonToolTipText", "\uc0c1\uc138\ud788"},
       {"saveButtonText", "\uc800\uc7a5"},
       {"openButtonText", "\uc5f4\uae30"},
       {"cancelButtonText", "\ucde8\uc18c"},
       {"updateButtonText", "\ubcc0\uacbd"},
       {"helpButtonText", "\ub3c4\uc6c0\ub9d0"},
       {"saveButtonToolTipText", "\uc120\ud0dd\ub41c \ud30c\uc77c\uc800\uc7a5"},
       {"openButtonToolTipText", "\uc120\ud0dd\ub41c \ud30c\uc77c\uc5f4\uae30"},
       {"cancelButtonToolTipText", "\ud30c\uc77c\ub2e4\uc774\uc5bc\ub85c\uadf8 \ubb34\uc2dc\ud558\uae30"},
       {"updateButtonToolTipText", "\uacbd\ub85c\uad6c\uc870\ubcc0\uacbd"},
       {"helpButtonToolTipText", "\ub2e4\uc774\uc5bc\ub85c\uadf8 \ub3c4\uc6c0\ub9d0"},
       {"myDialogTitle", "\uc5f4\uae30"},
       {"defaultFileFilterText", "\ubaa8\ub450\ud30c\uc77c\ub4e4"},
       {"refreshActionLabelText", "Refresh"},
	   {"newFolderActionLabelText", "New Folder"},
	   {"listViewActionLabelText", "List"},
	   {"detailsViewActionLabelText", "Details"},
	   {"viewMenuLabelText", "View"},
	   {"fileDateHeaderText", "Modified"},
	   {"fileNameHeaderText", "File"},
	   {"fileSizeHeaderText", "Size"},
	   {"fileAttrHeaderText", "Attributes"},
       
	   {"javaVersion", "Files cannot be uploaded. You will\nneed at least the JavaPlugin 1.5."},		
	   {"dom", "Files cannot be uploaded. Please use another browser."},
		
	   {"creatingZip", "Creating zip file"},
	   {"resize", "Resizing"},
	   {"checksum", "Calculating checksum"},
	   {"last_modified", "Last modified:"},
   };
     
   /**
    * Returns an array of Korean labels
    *
    * @return An array of Korean labels
    */
   public Object[][] getContents() {
       return contents;
   }
}
