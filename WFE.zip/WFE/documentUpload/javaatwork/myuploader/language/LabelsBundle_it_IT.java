/*
 * Copyright 2005-2009 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.language;

import java.util.ListResourceBundle;

/**
 * Class for the italian labels.
 * 
 * @author Johannes Postma
 */
public class LabelsBundle_it_IT extends ListResourceBundle {

	/** the italian labels */
	static final Object[][] contents = {
		{"upload", "Upload"},
		{"add", "Aggiungi"},
		{"delete", "Elimina"},
		{"files", "Files"},
		{"file", "File"},
		{"total_size", "Dimensione totale"},
		{"message", "Messaggio"},
		{"max_files", "Il numero massimo di file per richiesta é"},		              
		{"max_bytes", "Il numero massimo di bytes per richiesta é"},
		{"decrease", "Diminuisci il numero di file."},
		{"upload_process", "Processo di upload"},
		{"status", "Stato"},
		{"connecting", "Connessione in corso"},
		{"time_left", "Tempo rimasto"},
		{"uploading", "Uploading"},
		{"bytes_sent", "Bytes trasferiti"},
		{"progress", "Progresso"},
		{"cancel", "Cancella"},
		{"error_occurred", "Si é verificato un errore."},
		{"waiting_for_response", "In attesa di risposta"},
		{"error", "Errore"},
		{"nr", "Nr"},
		{"size", "Dimensione"},
		{"interrupted", "Impossibile contattare il server o connessione interrotta."},
		{"of", "di"},
		{"statuscode", "Si é verificato un errore.  Codide di stato"},
		{"summary", "Sommario"},
		
		{"paste", "Incolla"},
		{"upload_completed", "Upload completato."},
		{"basic_proxy_authentication", "Solo l'autenticazione 'basic' è supportata."},	
		{"authentication_required", "Autenticazione richiesta"},
		{"login_incorrect", "Login non corretto"},
		{"username", "Nome utente"},
		{"password", "Password"},
		{"scheme", "Schema"},
		{"technical_error", "Errore di natura tecnica."},
		{"unkown_host", "Host sconosciuto"},
		{"uploadurl", "Parametro 'uploadURL' non corretto."},
		
		{"javaVersion", "Files cannot be uploaded. You will\nneed at least the JavaPlugin 1.5."},		
		{"dom", "Files cannot be uploaded. Please use another browser."},
		
		{"creatingZip", "Sto creando il file zip"},
		{"resize", "Sto ridimensionando le immagini"},
		{"checksum", "Il calcolo del checksum"},
		{"last_modified", "Ultima modifica:"},
	};
	
	/**
	 * Returns an array of italian labels
	 * 
	 * @return An array of italian labels
	 */
	public Object[][] getContents() {
		return contents;
	}
}
