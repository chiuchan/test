/*
 * Copyright 2005-2009 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.language;

import java.util.ListResourceBundle;

/**
 * Class for the german labels.
 * 
 * @author Johannes Postma
 */
public class LabelsBundle_de_DE extends ListResourceBundle {

	static final Object[][] contents = {
		{"upload", "Hochladen"}, 
		{"add", "Hinzufügen"},
		{"delete", "Löschen"},
		{"files", "Dateien"},
		{"file", "Datei"},
		{"total_size", "Gesamtgrösse"},
		{"message", "Nachricht"},
		{"max_files", "Die maximale Anzahl von Dateien einer Anfrage beträgt"},
		{"max_bytes", "Die maximale Grösse in Bytes einer Anfrage beträgt"},
		{"decrease", "Bitte reduzieren Sie die Anzahl der Dateien."}, 
		{"upload_process", "Lade hoch"},  
		{"status", "Status"},
		{"connecting", "Verbinde"},
		{"time_left", "Verbleibende Zeit"},
		{"uploading", "Lade hoch"},
		{"bytes_sent", "Bytes gesendet"},
		{"progress", "Fortschritt"},
		{"cancel", "Abbrechen"},
		{"error_occurred", "Fehler aufgetreten."},
		{"waiting_for_response", "Warte auf Antwort"},  
		{"error", "Fehler"},
		{"nr", "Nr"},
		{"size","Grösse"},
		{"interrupted", "Konnte nicht zum Server verbinden oder die Verbindung ist unterbrochen."},
		{"of","von"},
		{"statuscode","Fehler aufgetreten. Statuscode"},
		{"summary", "Zusammenfassung"},
		
		{"paste", "Einfügen"},
		{"upload_completed", "Upload vollständig."},
		{"basic_proxy_authentication", "Nur die 'basic' Anmeldung wird unterstützt."},	
		{"authentication_required", "Anmeldung erforderlich"},
		{"login_incorrect", "Login inkorrekt"},
		{"username", "Benutzername"},
		{"password", "Passwort"},
		{"scheme", "Schema"},
		{"technical_error", "Technischer Fehler."},
		{"unkown_host", "Unbekannter Host"},
		{"uploadurl", "Ungültiger Parameter 'uploadURL'"},
		
		{"javaVersion", "Files cannot be uploaded. You will\nneed at least the JavaPlugin 1.5."},		
		{"dom", "Files cannot be uploaded. Please use another browser."},
		
		{"creatingZip", "Erstelle ZIP-Datei"},
		{"resize", "Resize Bilder"},
		{"checksum", "Prüfsumme Berechnen"},
		{"last_modified", "Zuletzt geändert:"}
	};
	
	/**
	 * Returns an array of german labels
	 * 
	 * @return An array of german labels
	 */
	public Object[][] getContents() {
		return contents;
	}

}
