/*
 * Copyright 2005-2009 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.language;

import java.util.ListResourceBundle;

/**
 * Class for the Finnish labels.
 * 
 * @author Johannes Postma
 */
public class LabelsBundle_fi extends ListResourceBundle {

	/** the dutch labels */
	static final Object[][] contents = {
		{"upload", "Lähetä tiedosto"},
		{"add", "Lisää"},
		{"delete", "Poista"},
		{"files", "Tiedostot"},
		{"file", "Tiedosto"},
		{"total_size", "Koko"},
		{"message", "Viesti"},
		{"max_files", "Yhden pyynnön maksimitiedostomäärä on"},
		{"max_bytes", "Yhden pyynnön maksimikoko tavuissa on"},
		{"decrease", "Ole hyvä ja vähennä tiedostojen määrää."},
		{"upload_process", "Tiedostonlähetys prosessi"},
		{"status", "Tila"},
		{"connecting", "Yhdistetään"},
		{"time_left", "Aikaa jäljellä"},
		{"uploading", "Lähetetään tiedostoa"},
		{"bytes_sent", "Tavua lähetetty"},
		{"progress", "Edistyminen"},
		{"cancel", "Peruuta"},
		{"error_occurred", "Tapahtui virhe."},
		{"waiting_for_response", "Odotetaan vastausta"},
		{"error", "Virhe"},
		{"nr", "Nr"},
		{"size", "Koko"},
		{"interrupted", "Ei voitu yhdistää palvelimeen tai yhteys on estetty."},
		{"of", "/"},
		{"statuscode", "Tapahtui virhe. Virheen koodi"},
		{"summary", "Yhteenveto"},
		
		{"paste", "Liitä"},
		{"upload_completed", "Tiedoston lähetys valmis."},
		{"basic_proxy_authentication", "Vain ‘basic’ autentikointi on tuettu."},
		{"authentication_required", "Autentikointi on pakollinen"},
		{"login_incorrect", "Virheelliset kirjautumistiedot"},
		{"username", "Käyttäjänimi"},
		{"password", "Salasana"},
		{"scheme", "Suunnitelma"},
		{"technical_error", "Tekninen virhe."},
		{"unkown_host", "Tuntematon isäntä"},
		{"uploadurl", "Virheellinen parametri ‘uploadURL’"},
			
		// JFileChooser
		{"lookInLabelText", "Tarkastele:"},
		{"filesOfTypeLabelText", "Tiedostot tyyppiä:"},
		{"upFolderToolTipText", "Yksi taso ylöspäin"},
		{"fileNameLabelText", "Tiedostonnimi:"},
		{"homeFolderToolTipText", "Koti"},
		{"newFolderToolTipText", "Luo uusi kansio"},
		{"listViewButtonToolTipText", "Lista"},
		{"detailsViewButtonToolTipText", "Detalji"},
		{"saveButtonText", "Tallenna"},
		{"openButtonText", "Avaa"},
		{"cancelButtonText", "Peruuta"},
		{"updateButtonText", "Vaihda"},
		{"helpButtonText", "Ohje"},
		{"saveButtonToolTipText", "Tallenna valittu tiedosto"},
		{"openButtonToolTipText", "Avaa valittu tiedosto"},
		{"cancelButtonToolTipText", "Keskeytä"},
		{"updateButtonToolTipText", "Muuta hakemistorakennetta"},
		{"helpButtonToolTipText", "Ohjeikkuna"},
		{"myDialogTitle", "Avaa"},
		{"defaultFileFilterText", "Aivan Tiedostot"},
		{"refreshActionLabelText", "Päivitä"},
		{"newFolderActionLabelText", "Uusi kansio"},
		{"listViewActionLabelText", "Lista"},
		{"detailsViewActionLabelText", "Detalji"},
		{"viewMenuLabelText", "Näytä"},
		{"fileDateHeaderText", "Muokkaa"},
		{"fileNameHeaderText", "Tiedosto"},
		{"fileSizeHeaderText", "Koko"},	
		{"fileAttrHeaderText", "Attributes"},
		
		{"javaVersion", "Tiedostoja ei voitu ladata. Tarvitset vähintään JavaPlugin 1.5."},		
		{"dom", "Tiedostoja ei voitu ladata. Vaihda selainta."},
		
		{"creatingZip", "Creating zip file"},
		{"resize", "Resizing"},
		{"checksum", "Laskettava tarkistussumma"},
		{"last_modified", "Last modified:"},
	};
	
	/**
	 * Returns an array of dutch labels
	 * 
	 * @return An array of dutch labels
	 */
	public Object[][] getContents() {
		return contents;
	}
}
