/*
 * Copyright 2005-2009 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.language;

import java.util.ListResourceBundle;

/**
 * Class for the Turkish labels.
 * 
 * @author Johannes Postma
 */
public class LabelsBundle_tr_TR extends ListResourceBundle {

	/** the Turkish labels */
	static final Object[][] contents = {
		{"upload", "Yükle"},
		{"add", "Ekle"},
		{"delete", "Sil"},
		{"files", "Dosyalar"},
		{"file", "Dosya"},
		{"total_size", "Toplam boyut"},
		{"message", "İleti"},
		{"max_files", "Bir istekte yer alabilecek en fazla dosya sayısı"},
		{"max_bytes", "Bir istekte yer alabilecek en fazla byte"},
		{"decrease", "Lütfen dosya sayısını azaltın."},
		{"upload_process", "Yükleme işlemi"},
		{"status", "Durum"},
		{"connecting", "Bağlanıyor"},
		{"time_left", "Kalan süre"},
		{"uploading", "Yükleniyor"},
		{"bytes_sent", "Gönderilen byte"},
		{"progress", "İlerleme"},
		{"cancel", "İptal"},
		{"error_occurred", "Hata oluştu."},
		{"waiting_for_response", "Cevap bekleniyor"},
		{"error", "Hata oluştu"},
		{"nr", "No"},
		{"size", "Boyut"},
		{"interrupted", "Sunucuyla iletişim kurulamadı ya da bağlantı kesildi."},
		{"of", "/"},
		{"statuscode", "Hata oluştu. Durum kodu"},
		{"summary", "Özet"},
		
		{"paste", "Yapıştır"},
		{"upload_completed", "Yükleme tamamlandı."},
		{"basic_proxy_authentication", "Sadece 'basic' yetkilendirme desteklenmektedir."},
		{"authentication_required", "Yetkilendirme gerekli"},
		{"login_incorrect", "Kullanıcı girişi hatalı"},
		{"username", "Kullanıcı adı"},
		{"password", "Parola"},
		{"scheme", "Şema"},
		{"technical_error", "Teknik hata."},
		{"unkown_host", "Bilinmeyen sunucu"},
		{"uploadurl", "Hatalı parameter 'uploadURL'"},
			
		// JFileChooser
		{"lookInLabelText", "İçinde ara:"},
		{"filesOfTypeLabelText", "Dosya türleri:"},
		{"upFolderToolTipText", "Bir seviye yukar"},
		{"fileNameLabelText", "Dosya adı:"},
		{"homeFolderToolTipText", "Ana klasör"},
		{"newFolderToolTipText", "Yeni klasör yarat"},
		{"listViewButtonToolTipText", "Listele"},
		{"detailsViewButtonToolTipText", "Detaylar"},
		{"saveButtonText", "Kaydet"},
		{"openButtonText", "Aç"},
		{"cancelButtonText", "İptal"},
		{"updateButtonText", "Değiştir"},
		{"helpButtonText", "Yardım"},
		{"saveButtonToolTipText", "Seçili dosyayı kaydet"},
		{"openButtonToolTipText", "Seçili dosyayı aç"},
		{"cancelButtonToolTipText", "Dosya iptal ekranı"},
		{"updateButtonToolTipText", "Dizin yapısını değiştir"},
		{"helpButtonToolTipText", "Yardım ekranı"},
		{"myDialogTitle", "Aç"},
		{"defaultFileFilterText", "Tüm dosyalar"},
		{"refreshActionLabelText", "Refresh"},
		{"newFolderActionLabelText", "New Folder"},
		{"listViewActionLabelText", "List"},
		{"detailsViewActionLabelText", "Details"},
		{"viewMenuLabelText", "View"},
		{"fileDateHeaderText", "Modified"},
		{"fileNameHeaderText", "File"},
		{"fileSizeHeaderText", "Size"},
		{"fileAttrHeaderText", "Attributes"},
		
		{"javaVersion", "Files cannot be uploaded. You will\nneed at least the JavaPlugin 1.5."},		
		{"dom", "Files cannot be uploaded. Please use another browser."},
		
		{"creatingZip", "Creating zip file"},
		{"resize", "Resizing"},
		{"checksum", "Calculating checksum"},
		{"last_modified", "Last modified:"},
	};
	
	/**
	 * Returns an array of Turkish labels
	 * 
	 * @return An array of Turkish labels
	 */
	public Object[][] getContents() {
		return contents;
	}
}
