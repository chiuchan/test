/*
 * Copyright 2005-2009 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.language;

import java.util.ListResourceBundle;

/**
 * Class for the Swedish labels.
 * 
 * @author Johannes Postma
 */
public class LabelsBundle_sv_SE extends ListResourceBundle {

	/** the Swedish labels */
	static final Object[][] contents = {
		{"upload", "Uppladdning"},
		{"add", "Lägg till"},
		{"delete", "Ta bort"},
		{"files", "Filer"},
		{"file", "Fil"},
		{"total_size", "Total storlek"},
		{"message", "Meddelande"},
		{"max_files", "Det maximala antalet filer för varje förfråga är"},
		{"max_bytes", "Det maximala bytestorlek för varje förfråga är"},
		{"decrease", "Vänligen minska antalet filer."},
		{"upload_process", "Uppladdningsprocess"},
		{"status", "Status"},
		{"connecting", "Kopplar upp"},
		{"time_left", "Tid kvar"},
		{"uploading", "Uppladdning"},
		{"bytes_sent", "Bytes skickade"},
		{"progress", "Förloppsindikator"},
		{"cancel", "Avbryt"},
		{"error_occurred", "Ett fel inträffade."},
		{"waiting_for_response", "Väntar på svar"},
		{"error", "Fel"},
		{"nr", "Nr"},
		{"size", "Storlek"},
		{"interrupted", "Kunde inte kontakta servern eller kopplingen avbröts."},
		{"of", "av"},
		{"statuscode", "Ett fel inträffade. Statuskod"},
		{"summary", "Sammanfattning"},
		
		{"paste", "Klista in"},
		{"upload_completed", "Överföringen klar."},
		{"basic_proxy_authentication", "Enbart 'basic' autentisering är tillgänglig."},	
		{"authentication_required", "Autentisering krävs"},
		{"login_incorrect", "Felaktig inloggning"},
		{"username", "Användarnamn"},
		{"password", "Lösenord"},
		{"scheme", "Metod"},
		{"technical_error", "Tekniskt fel."},
		{"unkown_host", "Okänd host"},
		{"uploadurl", "Felaktig parameter 'uploadURL'"},
		
		//JFileChooser
		{"lookInLabelText", "Titta i:"},
		{"filesOfTypeLabelText", "Typ av filer"},
		{"upFolderToolTipText", "Gå upp en nivå"},
		{"fileNameLabelText", "Filnamn:"},
		{"homeFolderToolTipText", "Hem"},
		{"newFolderToolTipText", "Skapa ny mapp"},
		{"listViewButtonToolTipText", "Lista"},
		{"detailsViewButtonToolTipText", "Detaljer"},
		{"saveButtonText", "Spara"},
		{"openButtonText", "Öppna"},
		{"cancelButtonText", "Avbryt"},
		{"updateButtonText", "Uppdatera"},
		{"helpButtonText", "Hjälp"},
		{"saveButtonToolTipText", "Spara markerad fil"},
		{"openButtonToolTipText", "Öppna markerad fil"},
		{"cancelButtonToolTipText", "Avbryt filväljarens dialogruta"},
		{"updateButtonToolTipText", "Uppdatera kataloglista"},
		{"helpButtonToolTipText", "Filväljarens hjälp"},
		{"myDialogTitle", "Oppnas"},
		{"defaultFileFilterText", "Samtliga filer"},
		{"refreshActionLabelText", "Uppdatera"},
		{"newFolderActionLabelText", "Ny mapp"},
		{"listViewActionLabelText", "Lista"},
		{"detailsViewActionLabelText", "Detaljer"},
		{"viewMenuLabelText", "Visa"},
		{"fileDateHeaderText", "Ändrad"},
		{"fileNameHeaderText", "Fil"},
		{"fileSizeHeaderText", "Storlek"},
		{"fileAttrHeaderText", "Attributes"},
		
		{"javaVersion", "Files cannot be uploaded. You will\nneed at least the JavaPlugin 1.5."},		
		{"dom", "Files cannot be uploaded. Please use another browser."},
		
		{"creatingZip", "Skapar zip fil"},
		{"resize", "Skalar bilderna"},
		{"checksum", "Beräkna kontrollsumma"},
		{"last_modified", "Senast ändrad:"},
	};
	
	/**
	 * Returns an array of Swedish labels
	 * 
	 * @return An array of Swedish labels
	 */
	public Object[][] getContents() {
		return contents;
	}
}
