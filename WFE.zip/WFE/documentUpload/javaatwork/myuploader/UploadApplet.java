/*
 * Copyright 2005-2009 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GraphicsEnvironment;
import java.awt.GridLayout;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.dnd.DropTarget;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Enumeration;
import java.util.List;
import java.util.StringTokenizer;

import javaatwork.myuploader.dialog.ImagePreview;
import javaatwork.myuploader.dialog.MessageDialog;
import javaatwork.myuploader.dialog.UploadDialog;
import javaatwork.myuploader.domain.FormData;
import javaatwork.myuploader.domain.FormInputField;
import javaatwork.myuploader.listeners.BrowseActionListener;
import javaatwork.myuploader.listeners.FileDropTargetListener;
import javaatwork.myuploader.listeners.UploadActionListener;
import javaatwork.myuploader.utils.ByteFormatter;
import javaatwork.myuploader.utils.IconManager;
import javaatwork.myuploader.utils.LocaleManager;
import javaatwork.myuploader.utils.Logger;
import javaatwork.myuploader.utils.Parameters;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;
import javax.swing.ToolTipManager;
import javax.swing.UIDefaults;
import javax.swing.UIManager;

/**
 * The main class for uploading files.
 * 
 * @author Johannes Postma
 */
public class UploadApplet extends JApplet {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 2131742227112464111L;

	// Instance variables
	// --------------------------------------------------------
	private UploadDialog dialog = null;
	private static String copyrightNotice = "MyUploader Source Code Edition version 1.14\n© Copyright JavaAtWork B.V. 2005-2010. All rights reserved.\n\n";
	private Frame frame = null; // needed for the dialogs
	private LocaleManager localeManager = null;
	
	// Swing instance variables
	// ----------------------------------------------------------
	private FileTable table = null;
	private JScrollPane pane = new JScrollPane();
	private JPanel commandPanel = new JPanel();
	private JPanel mainPanel = new JPanel();
	private JPanel helpPanel = new JPanel();
	private JPanel summaryPanel = new JPanel();
	private JPanel summaryHelpPanel = new JPanel();
	private JLabel labelFiles = null;
	private JLabel labelF = null;
	private JLabel labelSize = null;
	private JLabel labelS = null;
	private JButton buttonUpload = null;
	private JButton buttonAdd = null;
	private JButton buttonDelete = null;
	private Color backgroundColor = null;
	private MessageDialog messageDialog = null;
	private int laf = 1;
	
	public static final int METAL_LOOK_AND_FEEL = 1;
	public static final int WINDOWS_LOOK_AND_FEEL = 2;
	public static final int NIMBUS_LOOK_AND_FEEL = 3;
	
	static {
		System.out.println(copyrightNotice);
	}
	
	// the next code is needed for the java preferences in the CenteredFileChooser.
	// this code will set the implementations for parsing xml
	// MyUploader doesn't parse anything but the Java Plugin uses a parser for
	// storing and reading the preferences
	// Without the following code the Java Plugin does a lookup on the server
	// which results in a 404
	static {
		
		if (System.getProperty("java.specification.version").equals("1.4")) {
			
			try {
				// check if the implementation exits, if not a ClassNotFoundException will be thrown
				// and the usual lookup path will be used of the DocumentBuilderFactory
				// see for the lookup path the API of javax.xml.parsers.DocumentBuilderFactory
				Class.forName("org.apache.crimson.jaxp.DocumentBuilderFactoryImpl");
				System.setProperty("javax.xml.parsers.DocumentBuilderFactory", "org.apache.crimson.jaxp.DocumentBuilderFactoryImpl");
			} catch (ClassNotFoundException cnfe) {			
				Logger.log("UploadApplet", "none", cnfe.toString());
			}
		}
		
		else {
			
			try {
				Class.forName("com.sun.org.apache.xerces.internal.jaxp.DocumentBuilderFactoryImpl");
				System.setProperty("javax.xml.parsers.DocumentBuilderFactory", "com.sun.org.apache.xerces.internal.jaxp.DocumentBuilderFactoryImpl");
			} catch (ClassNotFoundException cnfe) {
				Logger.log("UploadApplet", "none", cnfe.toString());
			} 
			
			try {
				Class.forName("com.sun.org.apache.xalan.internal.xsltc.trax.TransformerFactoryImpl");
				System.setProperty("javax.xml.transform.TransformerFactory", "com.sun.org.apache.xalan.internal.xsltc.trax.TransformerFactoryImpl");
			} catch (ClassNotFoundException cnfe) {
				Logger.log("UploadApplet", "none", cnfe.toString());
			}
			
			try {
				Class.forName("com.sun.org.apache.xalan.internal.xsltc.dom.XSLTCDTMManager");				                    
				System.setProperty("com.sun.org.apache.xalan.internal.xsltc.dom.XSLTCDTMManager", "com.sun.org.apache.xalan.internal.xsltc.dom.XSLTCDTMManager");
			} catch (ClassNotFoundException cnfe) {
				Logger.log("UploadApplet", "none", cnfe.toString());
			}
		}		
	}
	
	/**
	 * Constructs a new UploadApplet
	 */
	public UploadApplet() {
	}

	/**
	 * Initialise the applet
	 */
	public void init() {

		// Execute a job on the event-dispatching thread: 
		// creating this applet's GUI.
		try {
			SwingUtilities.invokeAndWait(new Runnable() {
				public void run() {
					createGUI();
				}
			});
		} catch (Exception e) {
			Logger.log("UploadApplet", "init()", e.toString());
		}
	}

	/**
	 * Updates the summary panel.
	 */
	public void updateSummary() {

		labelF.setText(String.valueOf(table.getNumberOfFiles()));
		
		FormData data = new FormData();
		data.addFormFileFields(table.getFormFileFields());
		
		labelS.setText(ByteFormatter.format(data.getTotalByteSizeOfFiles()));
		
		// the size of the contents of the 'size' column can be smaller or larger 
		// therefore pack the column
		table.packColumn(2, 5);
	}

	/**
	 * Show a message.
	 * 
	 * @param message The message
	 * @param messageType The messageType see JOptionPane.
	 */
	public void showMessage(Object message, int messageType) {
		JOptionPane optionPane = new JOptionPane(message, messageType);

		JDialog dial = optionPane.createDialog(this, localeManager.getString("message"));
		dial.setModal(true);
		dial.setVisible(true);
	}

	/**
	 * Show a message.
	 * 
	 * @param message The message.
	 * @param messageType The messageType see JOptionPane.
	 * @return True if the user has click the OK button otherwise false.
	 */
	public boolean showYesNoMessage(Object message, int messageType) {
		JOptionPane optionPane = new JOptionPane(message, messageType, JOptionPane.YES_NO_OPTION);

		JDialog dial = optionPane.createDialog(this, localeManager.getString("message"));
		dial.setModal(true);
		dial.setVisible(true);
		
		int returnValue = ((Integer)optionPane.getValue()).intValue();
		
		if (returnValue == JOptionPane.OK_OPTION) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Creates the GUI.
	 */
	public void createGUI() {

		Parameters.loadParameters(this);
		
		int lookAndFeel = Parameters.getParameter(Parameters.LOOK_AND_FEEL, 1);
		
		if (lookAndFeel == 1) {
			try {
				UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
				laf = METAL_LOOK_AND_FEEL;
			} catch (Throwable t) {
				// do nothing
			}
		} else if (lookAndFeel == 2) {
			try {
				UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
				laf = WINDOWS_LOOK_AND_FEEL;
			} catch (Throwable t) {
				// do nothing
			}
		} else if (lookAndFeel == 3) {
			try {
				UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
				laf = NIMBUS_LOOK_AND_FEEL;
			} catch (Throwable t) {
				// do nothing
			}
		}
				
		localeManager = LocaleManager.getInstance();

		Font defaultFont = new Font("SanSerif", Font.PLAIN, 12);
		boolean chinese = false;
		boolean korean = false;
		boolean japanese = false;
		
		if (Parameters.getParameter(Parameters.LANGUAGE, "en").startsWith("zh")) {
			chinese = true;
		}
		
		if (Parameters.getParameter(Parameters.LANGUAGE, "en").startsWith("ko")) {
			korean = true;
		}
		
		if (Parameters.getParameter(Parameters.LANGUAGE, "en").startsWith("ja")) {
			japanese = true;
		}
		
		// search a Chinese Font
		if (chinese) {
			
			Font [] fonts = GraphicsEnvironment.getLocalGraphicsEnvironment().getAllFonts();
			String chineseString = "\u6280\u672f\u4e0a\u7684\u9519\u8bef";
			 			 
			for (int i = 0; i < fonts.length; i++) {
				if (fonts[i].canDisplayUpTo(chineseString) == -1) {
					defaultFont = fonts[i];
					defaultFont = new Font(defaultFont.getFamily(), Font.PLAIN, 12);
			
					break;
				}
			 }			 
		}
		
		else if (korean) {
			
			Font [] fonts = GraphicsEnvironment.getLocalGraphicsEnvironment().getAllFonts();
			String koreanString = "\uc5c5\ub85c\ub4dc";
			 			 
			for (int i = 0; i < fonts.length; i++) {
				if (fonts[i].canDisplayUpTo(koreanString) == -1) {
					defaultFont = fonts[i];
					defaultFont = new Font(defaultFont.getFamily(), Font.PLAIN, 12);
			
					break;
				}
			 }			 
		}
		
		else if (japanese) {
			
			Font [] fonts = GraphicsEnvironment.getLocalGraphicsEnvironment().getAllFonts();
			String japaneseString = "\u7d4e\ufffd";
			 			 
			for (int i = 0; i < fonts.length; i++) {
				if (fonts[i].canDisplayUpTo(japaneseString) == -1) {
					defaultFont = fonts[i];
					defaultFont = new Font(defaultFont.getFamily(), Font.PLAIN, 12);
			
					break;
				}
			 }			 
		}
		
		UIDefaults ud = UIManager.getDefaults();
		Enumeration enumeration = ud.keys();
		
		while (enumeration.hasMoreElements()) {
			Object o = enumeration.nextElement();

			if (o.toString().endsWith(".font")) {
				UIManager.put(o, defaultFont);
			}
		}
		
		table = new FileTable(this);
		
		buttonUpload = new JButton(localeManager.getString("upload"));
		buttonAdd = new JButton(localeManager.getString("add"));
		buttonDelete = new JButton(localeManager.getString("delete"));
		labelFiles = new JLabel(localeManager.getString("files") + ": ");
		labelF = new JLabel("0");
		labelSize = new JLabel(localeManager.getString("total_size") + ": ");
		labelS = new JLabel("0 Kb");

		String color = Parameters.getParameter(Parameters.BACKGROUND_COLOR, "#FFFFFF");
		backgroundColor = new Color(Integer.parseInt(color.substring(1), 16));

		// create the command panel
		commandPanel.setLayout(new GridLayout(3, 0, 5, 5));
		commandPanel.setBackground(backgroundColor);
		commandPanel.add(buttonAdd);
		commandPanel.add(buttonDelete);
		commandPanel.add(buttonUpload);
		
		// set drop target
		pane.setDropTarget(new DropTarget(table, new FileDropTargetListener(this)));

		URL codeBase = null;
		
		try {
			codeBase = this.getCodeBase();
		} catch (NullPointerException npe) {
			// in case of a stand alone application
		}
		
		ImageIcon iconAdd = IconManager.getImageIcon(Parameters.getParameter(Parameters.ICON_ADD, null), codeBase);
		
		if (iconAdd != null) {
			 buttonAdd.setIcon(iconAdd);
		}
		
		ImageIcon iconRemove = IconManager.getImageIcon(Parameters.getParameter(Parameters.ICON_REMOVE, null), codeBase);
		
		if (iconAdd != null) {
			 buttonDelete.setIcon(iconRemove);
		}
		
		ImageIcon iconUpload = IconManager.getImageIcon(Parameters.getParameter(Parameters.ICON_UPLOAD, null), codeBase);
		
		if (iconUpload != null) {
			 buttonUpload.setIcon(iconUpload);
		}

		// on Windows XP a ScrollPane has a white border with the Windows look and feel.
		String osName = System.getProperty("os.name"); 
		
		if ((osName.equalsIgnoreCase("Windows XP") || osName.equalsIgnoreCase("Windows 2000")) && Parameters.getParameter(Parameters.LOOK_AND_FEEL, 1) == 2) {
			pane.setBorder(BorderFactory.createLineBorder(new Color(102, 102, 102)));
		}
		
		// set properties
		pane.getViewport().setBackground(Color.white);
		pane.getViewport().add(table);

		summaryHelpPanel.setLayout(new GridLayout(0, 2, 5, 5));
		summaryHelpPanel.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));
		summaryHelpPanel.setBackground(backgroundColor);

		JPanel summaryHelpPanel1 = new JPanel();
		summaryHelpPanel1.setLayout(new BorderLayout());
		summaryHelpPanel1.setBackground(backgroundColor);
		summaryHelpPanel1.add(labelFiles, BorderLayout.WEST);
		summaryHelpPanel1.add(labelF, BorderLayout.CENTER);

		JPanel summaryHelpPanel2 = new JPanel();
		summaryHelpPanel2.setLayout(new BorderLayout());
		summaryHelpPanel2.setBackground(backgroundColor);
		summaryHelpPanel2.add(labelSize, BorderLayout.WEST);
		summaryHelpPanel2.add(labelS, BorderLayout.CENTER);

		summaryHelpPanel.add(summaryHelpPanel1);
		summaryHelpPanel.add(summaryHelpPanel2);

		summaryPanel.setLayout(new BorderLayout());
		summaryPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(102, 102, 102)), " " + localeManager.getString("summary") + " "));
		summaryPanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createEmptyBorder(0, 3, 5, 3), summaryPanel.getBorder()));
		summaryPanel.setBackground(backgroundColor);
		summaryPanel.add(summaryHelpPanel, BorderLayout.CENTER);

		helpPanel.setLayout(new BorderLayout());
		helpPanel.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 0));
		helpPanel.setBackground(backgroundColor);
		helpPanel.add(commandPanel, BorderLayout.NORTH);
		
		if (Parameters.getParameter(Parameters.SHOW_THUMBNAILS_IN_APPLET, false)) {
			
			// the imagepreview can be 90 width
			// buttons without images can be smaller
			// therefore set the prefferd width
			buttonAdd.setPreferredSize(new Dimension(100,20));
			helpPanel.add(new ImagePreview(table), BorderLayout.CENTER);
		}		

		mainPanel.setLayout(new BorderLayout());
		mainPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		mainPanel.setBackground(backgroundColor);
		mainPanel.add(pane, BorderLayout.CENTER);
		mainPanel.add(helpPanel, BorderLayout.EAST);

		// add the panels to the applet
		this.getContentPane().setBackground(backgroundColor);
		this.getContentPane().add(mainPanel, BorderLayout.CENTER);
		this.getContentPane().add(summaryPanel, BorderLayout.SOUTH);
		
		frame = JOptionPane.getFrameForComponent(this);
		messageDialog = new MessageDialog(frame);
		
		frame.addWindowListener(new WindowAdapter() {

			public void windowActivated(WindowEvent e) {
				if (dialog != null) {
					dialog.toFront();
				}
			}
		});

		// add the actionlistener needed for the search
		buttonAdd.addActionListener(new BrowseActionListener(this));

		// add the actionlistener needed for removal of files
		buttonDelete.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				table.deleteFiles();
				updateSummary();
			}
		});

		// add the actionlistener needed for the upload
		buttonUpload.addActionListener(new UploadActionListener(this));
		
		// add the mouselistener needed to show the popup
		// if the tablemodel is empty
		pane.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				table.maybeShowPopup(e);
			}

			public void mouseReleased(MouseEvent e) {
				table.maybeShowPopup(e);
			}
		});
		
		// remove the tooltip during scrolling otherwise a current tooltip
		// can be visible outside the applet.
		pane.addMouseWheelListener(new MouseWheelListener(){

			public void mouseWheelMoved(MouseWheelEvent e) {
				ToolTipManager.sharedInstance().setEnabled(false);				
			}
		}); mainPanel.setEnabled(false); commandPanel.setEnabled(false);
	}

	/**
	 * Paste the files of the clipboard to the table.
	 * 
	 * @param flavors The DataFlavor [].
	 * @param transferable The transferable.
	 */
	public void paste(DataFlavor[] flavors, Transferable transferable) {
		table.paste(flavors, transferable);
	}
	
	/** 
	 * Adds the files to the table.
	 * 
	 * @param files The files to be added.
	 */
	public void addFiles(File [] files) {
		
		table.addFiles(files);
		updateSummary();
	}
	
	/**
	 * Returns the frame of the applet. 
	 * 
	 * @return The frame.
	 */
	public Frame getFrame() {
		return frame;
	}
	
	/**
	 * Shows a message after a successful upload. This can be a pop-up
	 * message or the user can be redirected to a success page. This
	 * can be configured with the successURL.
	 */
	public void showSuccessMessage() {
		String uri = Parameters.getParameter(Parameters.SUCCESS_URL, null);
		String target = Parameters.getParameter(Parameters.TARGET, null);

		if (uri != null) {

			URL successURL = null;

			try {
				if (!uri.startsWith("http")) {
					URL codeBase = this.getCodeBase();
					successURL = new URL(codeBase, uri);
				} else {
					successURL = new URL(uri);
				}
				
				if (target != null) {
					table.deleteAllFiles();
					updateSummary();
					this.getAppletContext().showDocument(successURL, target);
				} else { 
					table.deleteAllFiles();
					updateSummary();
					this.getAppletContext().showDocument(successURL, "_self");
				}
			} catch (MalformedURLException mue) {
				table.deleteAllFiles();
				updateSummary();
				messageDialog.showMessageDialog(localeManager.getString("upload_completed"), localeManager.getString("message"), JOptionPane.INFORMATION_MESSAGE);
			}

		} else {
			table.deleteAllFiles();
			updateSummary();
			messageDialog.showMessageDialog(localeManager.getString("upload_completed"), localeManager.getString("message"), JOptionPane.INFORMATION_MESSAGE);			
		}
	}
	
	/**
	 * Returns the data to be uploaded.
	 * 
	 * @return FormData.
	 */
	public FormData getFormData() throws Exception {
		
		FormData formData = new FormData();
		formData.addFormFileFields(table.getFormFileFields());
		
		String directory = Parameters.getParameter(Parameters.DIRECTORY, null);
		
		if (directory != null) {
			formData.addFormInputField(new FormInputField("directory", directory));
		}
		
		// add the post parameters
		String postParameters = Parameters.getParameter(Parameters.POST_PARAMETERS, null);
		
		if (postParameters != null) {
			
			StringTokenizer tokens = new StringTokenizer(postParameters, ",");
			
			while (tokens.hasMoreTokens()) {
				
				String parameter = tokens.nextToken().trim();
				formData.addFormInputField(new FormInputField(parameter, this.getParameter(parameter)));
			}
		}
		
		// retrieve the fields of the HTML Form
		String form = Parameters.getParameter(Parameters.FORM, null);
		
		if (form != null) {
			
			Class clss = Class.forName("com.javaatwork.myuploader.addon.form.FormAddOn");
			Class[] parameterTypes = new Class[] {JApplet.class, String.class};
			Method meth = clss.getMethod("getFormFields", parameterTypes);											  
			Object[] arguments = new Object[] {this, form};
			List list = (List)meth.invoke(clss.newInstance(), arguments);
				
			for (int i = 0; i < list.size(); i++) {
				List lst = (List)list.get(i);
				FormInputField field = new FormInputField(lst.get(0).toString(), lst.get(1).toString());
				formData.addFormInputField(field);
			}
		}
		
		return formData;
	}
	
	/**
	 * Returns the used look-and-feel. Possible values are<br>
	 * 1 Metal look-and-feel<br>
	 * 2 Windows look-and-feel<br>
	 * 3 Nimbus look-and-feel<br>
	 * 
	 * @return the laf
	 */
	public int getLaf() {
		return laf;
	}
}