/*
 * Copyright 2006-2008 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.listeners;

import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import javax.swing.JTextField;

/**
 * Class for selecting the text of a input field when this 
 * field gaines the focus.
 * 
 * @author Johannes Postma
 */ 
public class FieldFocusListener implements FocusListener {
	
	/**
	 * When the field gaines the focus.
	 * 
	 * @param e The FocusEvent.
	 */
	public void focusGained(FocusEvent e) {
		JTextField field = (JTextField)e.getSource();
		field.setSelectionStart(0);
		field.setSelectionEnd(field.getText().length());		
	}

	/**
	 * When the field loses the focus.
	 * 
	 * @param e The FocusEvent.
	 */
	public void focusLost(FocusEvent e) {
		JTextField field = (JTextField)e.getSource();
		field.setSelectionStart(0);
		field.setSelectionEnd(0);			
	}
}