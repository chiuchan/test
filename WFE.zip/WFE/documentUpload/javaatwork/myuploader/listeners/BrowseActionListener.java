/*
 * Copyright 2006-2008 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.listeners;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javaatwork.myuploader.UploadApplet;
import javaatwork.myuploader.dialog.CenteredFileChooser;

import javax.swing.JFileChooser;

/**
 * Class for selecting a file.
 * 
 * @author Johannes Postma
 */ 
public class BrowseActionListener implements ActionListener {

	private UploadApplet uploadApplet = null;
	private CenteredFileChooser chooser = new CenteredFileChooser();
	
	/**
	 * Creates a new BrowseActionListener
	 * 
	 * @param uploadApplet The UploadApplet.
	 */
	public BrowseActionListener(UploadApplet uploadApplet) {
		this.uploadApplet = uploadApplet;
	}
	
	/**
	 * The implemented method of ActionListener.
	 * 
	 * @param event The ActionEvent.
	 */
	public void actionPerformed(ActionEvent event) {
		int returnValue = chooser.showOpenDialog(uploadApplet);
		
		if (returnValue == JFileChooser.APPROVE_OPTION) {
			uploadApplet.addFiles(chooser.getSelectedFiles(uploadApplet));	
		}
	}
}
