/*
 * Copyright 2006-2008 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.listeners;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DropTargetDragEvent;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.dnd.DropTargetEvent;
import java.awt.dnd.DropTargetListener;

import javaatwork.myuploader.UploadApplet;

/**
 * Class needed for drag and drop.
 */
public class FileDropTargetListener implements DropTargetListener {

	private UploadApplet uploader = null;
	
	/**
	 * Creates a new FileDropTargetListener
	 * 
	 * @param uploader The MyLiteFTPUploader applet.
	 */
	public FileDropTargetListener(UploadApplet uploader) {
		this.uploader = uploader;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.dnd.DropTargetListener#dragEnter(java.awt.dnd.DropTargetDragEvent)
	 */
	public void dragEnter(DropTargetDragEvent event) {
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.dnd.DropTargetListener#dragOver(java.awt.dnd.DropTargetDragEvent)
	 */
	public void dragOver(DropTargetDragEvent event) {
		event.acceptDrag(DnDConstants.ACTION_COPY);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.dnd.DropTargetListener#dropActionChanged(java.awt.dnd.DropTargetDragEvent)
	 */
	public void dropActionChanged(DropTargetDragEvent event) {
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.dnd.DropTargetListener#dragExit(java.awt.dnd.DropTargetEvent)
	 */
	public void dragExit(DropTargetEvent event) {
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.dnd.DropTargetListener#drop(java.awt.dnd.DropTargetDropEvent)
	 */
	public void drop(DropTargetDropEvent event) {

		if ((event.getSourceActions() & DnDConstants.ACTION_COPY) != 0) {
			event.acceptDrop(DnDConstants.ACTION_COPY);
		} else {
			event.rejectDrop();
			return;
		}

		Transferable transferable = event.getTransferable();
		DataFlavor[] flavors = event.getCurrentDataFlavors();
		uploader.paste(flavors, transferable);
	}
}
