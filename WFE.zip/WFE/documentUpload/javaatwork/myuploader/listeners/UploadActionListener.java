/*
 * Copyright 2006-2009 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.listeners;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.MalformedURLException;
import java.net.PasswordAuthentication;
import java.net.URL;

import javaatwork.myuploader.UploadApplet;
import javaatwork.myuploader.dialog.MessageDialog;
import javaatwork.myuploader.dialog.ProxyLoginDialog;
import javaatwork.myuploader.dialog.UploadDialog;
import javaatwork.myuploader.domain.FormData;
import javaatwork.myuploader.net.HTTPUploadTask;
import javaatwork.myuploader.net.NetUtils;
import javaatwork.myuploader.net.ProxyAuthenticator;
import javaatwork.myuploader.net.ProxyAuthenticatorException;
import javaatwork.myuploader.utils.LocaleManager;
import javaatwork.myuploader.utils.Logger;
import javaatwork.myuploader.utils.Parameters;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import com.sun.java.browser.dom.DOMAccessException;
import com.sun.java.browser.dom.DOMUnsupportedException;

/**
 * Responsible for uploading the files to the webserver.
 *
 * @author Johannes Postma
 */
public class UploadActionListener implements ActionListener {

        // instance variables
        private int maxFileSize = -1;
        private double maxByteSize = -1;
        private boolean freeEdition = false;
        private boolean demoEdition = false;
        private boolean shownBuyDialog = false;
        private LocaleManager localeManager = null;
        private UploadApplet uploadApplet = null;
        private URL uploadURL = null;
        private HTTPUploadTask task = null;
        private MessageDialog messageDialog = null;

        /**
         * Creates an new UploadManager
         *
         * @param uploadApplet The applet.
         */
        public UploadActionListener(UploadApplet uploadApplet) {
                localeManager = LocaleManager.getInstance();
                this.uploadApplet = uploadApplet;
                messageDialog = new MessageDialog(uploadApplet.getFrame());

                // determine the max file size
                maxFileSize = Parameters.getParameter(Parameters.MAX_FILE_SIZE, -1);
                maxByteSize = Parameters.getParameter(Parameters.MAX_BYTE_SIZE, -1.0);

                if (freeEdition) {

                        if (maxFileSize < 0 || maxFileSize > 3) {
                                maxFileSize = 3;
                        }

                        if (maxByteSize < 0 || maxByteSize > 3) {
                                maxByteSize = 3;
                        }
                }
        }

        /**
         * Uploads the files to the webserver.
         *
         * @param actionEvent The ActionEvent.
         */
        public void actionPerformed(ActionEvent actionEvent) {

                FormData data = null;

                // check if the used plugin is at least JRE1.5 if form fields are enabled
                String form = Parameters.getParameter(Parameters.FORM, null);

                if (form != null) {
                        String javaSpecificationVersion = System.getProperty("java.specification.version");

                        if (javaSpecificationVersion.equals("1.3") ||javaSpecificationVersion.equals("1.4")) {

                                Logger.log("UploadActionListener", "actionPerformed", "Java Specification Version: " + javaSpecificationVersion);

                                uploadApplet.showMessage(localeManager.getString("javaVersion"), JOptionPane.INFORMATION_MESSAGE);

                                return;
                        }
                }

                try {
                        data = uploadApplet.getFormData();
                } catch (Exception ex) {

                        // log
                        Logger.log("UploadActionListener", "actionPerformed", "Exception occurred: " + ex.toString());

                        if (ex instanceof DOMUnsupportedException) {
                                uploadApplet.showMessage(localeManager.getString("dom"), JOptionPane.INFORMATION_MESSAGE);
                        } else if (ex instanceof DOMAccessException) {
                                uploadApplet.showMessage(localeManager.getString("dom"), JOptionPane.INFORMATION_MESSAGE);
                        } else {
                                uploadApplet.showMessage(localeManager.getString("error_occurred"), JOptionPane.INFORMATION_MESSAGE);
                        }

                        return;

                }

                JPanel panel = new JPanel();
                panel.setLayout(new GridLayout(5,0));
                JLabel labelJavaAtWork = new JLabel("JavaAtWork");
                JLabel labelMessage1 = new JLabel("This version can upload a maximum of 3 files or 3 MB.");
                JLabel labelMessage2 = new JLabel("To remove this constraint buy the full version.");
                JLabel labelEmpty1 = new JLabel();
                JButton button = new JButton("www.javaatwork.com");
                JPanel panel1 = new JPanel();
                panel1.setLayout(new BorderLayout());
                panel1.add(button, BorderLayout.WEST);
                panel1.add(panel, BorderLayout.NORTH);
                panel.add(labelJavaAtWork);
                panel.add(labelEmpty1);
                panel.add(labelMessage1);
                panel.add(labelMessage2);

                button.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                                try {
                                        uploadApplet.getAppletContext().showDocument(new URL("http://www.javaatwork.com"), "_blank");
                                } catch (MalformedURLException mue) {
                                        Logger.log("UploadActionListener", "actionPerformed", mue.toString());
                                }
                        }
                });

                if (freeEdition && !demoEdition && !shownBuyDialog) {
                        JOptionPane.showMessageDialog(uploadApplet, panel1);
                        shownBuyDialog = true;
                }

                try {

                        uploadURL = getUploadURL();

                } catch (MalformedURLException mue) {

                        // log
                        Logger.log("UploadActionListener", "actionPerformed", "UploadManager - Incorrect format of uploadURL: " + uploadURL);

                        String message = localeManager.getString("error_occurred") + ".";
                        uploadApplet.showMessage(message, JOptionPane.INFORMATION_MESSAGE);
                        return;

                }

                // check max file size
                if (maxFileSize != -1 && data.getFormFileFields().length > maxFileSize) {

                        String [] message = new String[2];
                        message[0] = localeManager.getString("max_files") + " " + maxFileSize + ".";
                        message[1] = localeManager.getString("decrease");

                        uploadApplet.showMessage(message, JOptionPane.INFORMATION_MESSAGE);
                }

                // check max byte size
                else if (maxByteSize != -1 && data.getTotalByteSizeOfFiles() > (maxByteSize * 1024 * 1024)) {

                        String [] message = new String[2];
                        message[0] = localeManager.getString("max_bytes") + " " + maxByteSize + " MB.";
                        message[1] = localeManager.getString("decrease");

                        uploadApplet.showMessage(message, JOptionPane.INFORMATION_MESSAGE);
                }

                // upload
                else if (data.getFormFileFields().length > 0) {

                        NetUtils netUtils = new NetUtils();
                        PasswordAuthentication passwordAuthentication = null;

                        // check if proxy is used
                        if (netUtils.useProxy(uploadURL)) {

                                ProxyLoginDialog loginDialog = new ProxyLoginDialog(uploadApplet.getFrame());
                                ProxyAuthenticator authenticator = new ProxyAuthenticator(loginDialog, uploadURL);

                                try {
                                        passwordAuthentication = authenticator.getPasswordAuthentication();
                                } catch (ProxyAuthenticatorException pae) {

                                        uploadApplet.showMessage(pae.getMessage(), JOptionPane.INFORMATION_MESSAGE);
                                        return;
                                }

                                // user has pressed on cancel in the dialog box
                                if (loginDialog.getReturnValue() == JOptionPane.CANCEL_OPTION) {
                                        return;
                                }
                        }

                        // create the upload task
                        task = new HTTPUploadTask(uploadURL, data, passwordAuthentication, uploadApplet.getFrame());
                        UploadDialog dialog = new UploadDialog(uploadApplet.getFrame(), this, task);
                        task.start();
                        dialog.start();
                }
        }

        /**
         * This method will be invoked when the upload is finished.
         *
         * @param returnCode The result of the upload process. See UploadTask.
         */
        public void end(int returnCode) {

                if (returnCode == HTTPUploadTask.SUCCESS) {
                        uploadApplet.showSuccessMessage();
                } else if  (returnCode == HTTPUploadTask.CANCELLED) {
                        // do nothing
                } else if  (returnCode == HTTPUploadTask.CUSTOM_ERROR) {
                        showMessageDialog(task.getErrorMessage(), localeManager.getString("error"), JOptionPane.ERROR_MESSAGE);
                } else if  (returnCode == HTTPUploadTask.CONNECTION_REFUSED) {
                        showMessageDialog(localeManager.getString("interrupted"), localeManager.getString("error"), JOptionPane.ERROR_MESSAGE);
                } else {
                        int httpStatusCode = task.getStatusCode();

                        if (httpStatusCode != 0) {
                                showMessageDialog(localeManager.getString("statuscode") + " " + httpStatusCode + ".", localeManager.getString("error"), JOptionPane.ERROR_MESSAGE);
                        } else {
                                showMessageDialog(localeManager.getString("error_occurred"), localeManager.getString("error"), JOptionPane.ERROR_MESSAGE);
                        }
                }
        }

        /**
         * Shows a MessageDialog.
         *
         * @param message The message.
         * @param title The title.
         * @param type The type, see JOptionPane.
         */
        public void showMessageDialog(String message, String title, int type) {
                messageDialog.showMessageDialog(message, title, type);
        }

        /**
         * Returns the upload URL.
         *
         * @return The upload URL.
         * @throws MalformedURLException If the format of the upload URL is not correct.
         */
        private URL getUploadURL() throws MalformedURLException {

                URL uploadURL = null;

                String uri = Parameters.getParameter(Parameters.UPLOAD_URL, null);

                if (uri == null) {
                        throw new MalformedURLException();
                }

                if (!uri.startsWith("http")) {
                        uploadURL = new URL(uploadApplet.getCodeBase(), uri);
                } else {
                        uploadURL = new URL(uri);
                }

                return uploadURL;
        }

}
