/*
 * Copyright 2006-2008 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.dialog;

import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Toolkit;

import javax.swing.JDialog;
import javax.swing.JOptionPane;

/**
 * A centered message dialog.
 * 
 * @author Johannes Postma
 */
public class MessageDialog {

	private Frame frame = null;
	private JDialog dialog = null;
	private JOptionPane pane = null;
	
	/**
	 * Creates a new MessageDialog.
	 * 
	 * @param frame The parent.
	 */
	public MessageDialog(Frame frame) {
		this.frame = frame;
	}

	/**
	 * Show the dialog.
	 * 
	 * @param message The message.
	 * @param title The title.
	 * @param type The type. See JOptionPane.
	 */
	public void showMessageDialog(String message, String title, int type) {
		
		pane = new JOptionPane(message, type);
		dialog = pane.createDialog(frame, title);
	
		//  sets the frame to the center
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = dialog.getSize();

		if (frameSize.height > screenSize.height) {
			frameSize.height = screenSize.height;
		}

		if (frameSize.width > screenSize.width) {
			frameSize.width = screenSize.width;
		}

		dialog.setLocation(
			(screenSize.width - frameSize.width) / 2,
			(screenSize.height - frameSize.height) / 2);
		
		dialog.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
		dialog.setVisible(true);		
	}

	/**
	 * Ensures that the dialog is always visible.
	 */
	public void toFront() {
		if (dialog != null) {
			dialog.toFront();
		}
	}
}
