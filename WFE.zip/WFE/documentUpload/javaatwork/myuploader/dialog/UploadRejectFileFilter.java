/*
 * Copyright 2006-2008 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.dialog;

import java.io.File;
import java.util.HashSet;
import java.util.Set;
import java.util.StringTokenizer;

/**
 * UploadRejectFileFilter is a filefilter for rejecting
 * dangerous files such as bat or exe. The file extensions
 * must be given by a param attribute of the applet tag
 * of MyUploader. The param tag is named rejectfilefilter.
 * The extensions must be seperated with a ','. e.g.
 * <param name="rejectFileFilter" value="bat, exe"> 
 *  
 * is created.
 * 
 * @author Johannes Postma
 */
public class UploadRejectFileFilter {

	/** Collection for storing the extensions */
	private Set extensions = new HashSet();
	
	/**
	 * Creates a new UploadRejectFileFilter.
	 * 
	 * @param exts The extensions seperated with a ','
	 * @throws FileFilterException If the format of the extensions is incorrect.
	 */
	public UploadRejectFileFilter(String exts) throws FileFilterException {
		
		try {
			StringTokenizer token = new StringTokenizer(exts, ",");
			
			while (token.hasMoreTokens()) {
				Object o = token.nextToken();
				extensions.add(o.toString().trim());
			}
			
		} catch (Exception ex) {
						
			throw new FileFilterException("incorrect rejectfilefilter format: " + exts +" --> " + "see documentation on website");
		}
	}

	/**
	 * Checks if the file must be rejected.
	 * 
	 * @param file The file to check.
	 * @return True if the file must be rejected.
	 */
	public boolean rejectFile(File file) {
		String ext = getExtension(file);
		
		// file has no extension
		if (ext == null) {
			return true;
		}
		
		return extensions.contains(ext);
	}
	
	/** 
	 * Returns the description of the filefilter.
	 * 
	 * @param file File.
	 * @return Description of the filefilter.
	 */
	private String getExtension(File file) {
		
        String ext = null;
        String s = file.getName();
        
        int i = s.lastIndexOf('.');

        if (i > 0 &&  i < s.length() - 1) {
            ext = s.substring(i+1).toLowerCase();
        }
        
        return ext;
    }
}
