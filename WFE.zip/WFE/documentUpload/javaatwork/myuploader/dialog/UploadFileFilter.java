/*
 * Copyright 2005-2008 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.dialog;

import java.io.File;
import java.util.StringTokenizer;
import java.util.Vector;


import javax.swing.filechooser.FileFilter;

/**
 * FileFilter for the FileUploadApplet. Based on the
 * fileFilter parameter of the applet the filefilter 
 * is created.
 * 
 * @author Johannes Postma
 */
public class UploadFileFilter extends FileFilter {

	/** Collection for storing the extensions */
	private Vector extensions = new Vector();
	
	/** Discription that will be displayed in the filefilter */
	private String description = ""; 
	
	/**
	 * Creates a new UploadFileFilter. 
	 * 
	 * @param ext A String containing the description and the extensions.
	 *            The format must be: "Image files (*.jpg, *.gif): jpg, gif".
	 * @throws FileFilterException Thrown if the input has an incorrect format.
	 */
	public UploadFileFilter(String ext) throws FileFilterException {
		
		try {
			description = ext.substring(0, ext.indexOf(":"));
			String exts = ext.substring(ext.indexOf(":") + 1);
			
			StringTokenizer token = new StringTokenizer(exts, ",");
			
			while (token.hasMoreTokens()) {
				Object o = token.nextToken();
				extensions.add(o.toString().trim());
			}
			
		} catch (Exception ex) {
						
			throw new FileFilterException("incorrect filefilter format: " + ext +" --> " + "see documentation on website");
		}
	}
	
	/**
	 * Determines if the file corresponds to one of the extensions
	 * of the filefilter.
	 * 
	 * @param file The file to be checked.
	 * @return True if the file corresponds to one of the extensions.
	 */
	public boolean accept(File file) {
		
		if (file.isDirectory()) {
			return true;
		}  
		
		else { 
			String ext = getExtension(file);
			
			// file has no extension
			if (ext == null) {
				return false;
			}
			
			for (int i = 0; i < extensions.size(); i++) {
				if (ext.equalsIgnoreCase(extensions.elementAt(i).toString())) {
					return true;
				}
			}			
		}
		
		return false;
	}

	/** 
	 * Returns the description of the filefilter.
	 * 
	 * @return Description of the filefilter.
	 */
	public String getDescription() {
		return description;
	}
	
	/** 
	 * Returns the description of the filefilter.
	 * 
	 * @param file File.
	 * @return Description of the filefilter.
	 */
	public String getExtension(File file) {
		
        String ext = null;
        String s = file.getName();
        
        int i = s.lastIndexOf('.');

        if (i > 0 &&  i < s.length() - 1) {
            ext = s.substring(i+1).toLowerCase();
        }
        
        return ext;
    }
}
