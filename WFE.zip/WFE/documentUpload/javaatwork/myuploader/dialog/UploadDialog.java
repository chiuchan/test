/*
 * Copyright 2005-2008 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.dialog;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javaatwork.myuploader.listeners.UploadActionListener;
import javaatwork.myuploader.net.HTTPUploadTask;
import javaatwork.myuploader.utils.ByteFormatter;
import javaatwork.myuploader.utils.LocaleManager;
import javaatwork.myuploader.utils.TimeFormatter;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.Timer;

/**
 * Dialog for showing the upload process.
 * 
 * @author Johannes Postma
 */
public class UploadDialog extends JDialog {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -8876193655461167673L;
	
	private JLabel labelStatus = null;
	private JLabel labelStat = new JLabel("");
	private JLabel labelTimeLeft = null;
	private JLabel labelTimeL = new JLabel("");
	private JLabel labelFile = null;
	private JLabel labelBytesSent = null;
	private JLabel labelBytesS = new JLabel("");
	private JLabel labelU = new JLabel("                     ");
	private JLabel labelFiles = null;
	private JLabel labelF = new JLabel("");
	private JLabel labelProgress = null;
	private JProgressBar progressBar = new JProgressBar(0,100);
	private Timer timer;
	private LocaleManager localeManager = null;  
		
	private JButton buttonCancel = null;
	private JPanel commandPanel = new JPanel();
	private JPanel commandHelpPanel = new JPanel();
	private JPanel mainPanel = new JPanel();
	private HTTPUploadTask task = null;
	private UploadActionListener controller = null;
	
	/**
	 * Creates a new UploadDialog.
	 * 
	 * @param frame The parent frame.
	 * @param controller The UploadActionListener.
	 * @param task A particular task.
	 */
	public UploadDialog(Frame frame, UploadActionListener controller, final HTTPUploadTask task) {
		super(frame);
		
		setModal(true);
		
		this.controller = controller;
		this.task = task;
		localeManager = LocaleManager.getInstance();
				
		setTitle(localeManager.getString("upload_process"));
		
		labelStatus = new JLabel(localeManager.getString("status") + ":");
		labelTimeLeft = new JLabel(localeManager.getString("time_left") + ":");
		labelFile = new JLabel(localeManager.getString("file") + ":");
		labelBytesSent = new JLabel(localeManager.getString("bytes_sent") + ":");
		labelFiles = new JLabel(localeManager.getString("files") + ":");
		labelProgress = new JLabel(localeManager.getString("progress") + ":");
		buttonCancel = new JButton(localeManager.getString("cancel"));
		
		commandHelpPanel.setLayout(new GridLayout(0,1,5,5));
		commandHelpPanel.add(buttonCancel);
		commandPanel.add(commandHelpPanel);
		
		mainPanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createEmptyBorder(5,5,5,5), BorderFactory.createEtchedBorder()));
		mainPanel.setBorder(BorderFactory.createCompoundBorder(mainPanel.getBorder(), BorderFactory.createEmptyBorder(5,5,5,5)));
		mainPanel.setLayout(new GridLayout(6,2,5,5));
		mainPanel.add(labelStatus);
		mainPanel.add(labelStat);
		mainPanel.add(labelFile);
		mainPanel.add(labelU);
		mainPanel.add(labelFiles);
		mainPanel.add(labelF);
		mainPanel.add(labelProgress);
		mainPanel.add(progressBar);
		mainPanel.add(labelBytesSent);
		mainPanel.add(labelBytesS);
		mainPanel.add(labelTimeLeft);
		mainPanel.add(labelTimeL);
		this.getContentPane().add(mainPanel, BorderLayout.CENTER);
		this.getContentPane().add(commandPanel, BorderLayout.SOUTH);
		pack();
		
		buttonCancel.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				
				task.stop();
				setVisible(false);
			}
		});
		
		// sets the frame to the center
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = this.getSize();

		if (frameSize.height > screenSize.height) {
			frameSize.height = screenSize.height;
		}

		if (frameSize.width > screenSize.width) {
			frameSize.width = screenSize.width;
		}

		setLocation(
			(screenSize.width - frameSize.width) / 2,
			(screenSize.height - frameSize.height) / 2);
		
			
	}
	
	/**
	 * Start showing the progress.
	 */
	public void start() {
	
		progressBar.setStringPainted(true);
		
		//	Create a timer.
		timer = new Timer(500, new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				
				labelStat.setText(task.getProcessMessage());
				
				if (task.getBytesProcessed() > 0) {
					labelStat.setText(task.getProcessMessage());
				    int percent = task.getPercentCompleted();
					progressBar.setValue(percent);
					progressBar.setString(task.getPercentCompleted() + "%");
					labelU.setText(task.getCurrentFileName());
					labelTimeL.setText(TimeFormatter.getFormattedTime(task.getTimeLeft()));
					labelF.setText(task.getFilesProcessed() + " " + localeManager.getString("of") + " " + task.getFiles());
					
					// show only the bytes sent if the files are sent to the server
					if (task.isUploading()) {
						labelBytesS.setText(ByteFormatter.format(task.getBytesProcessed()));
					}
				}
					
				if (task.finished()) {
					timer.stop();
					close();
				}
			}
		});		
	
		timer.start();
		setVisible(true);
	}
	
	
	/**
	 * Closes the dialog and informs the controller about the status.
	 */
	public void close() {
		this.setVisible(false);
		controller.end(task.getReturnCode());
	}
}
