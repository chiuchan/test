/*
 * Copyright 2005-2008 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.dialog;

import java.applet.Applet;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.HeadlessException;
import java.awt.Toolkit;
import java.awt.event.MouseListener;
import java.io.File;
import java.util.prefs.BackingStoreException;
import java.util.prefs.Preferences;

import javaatwork.myuploader.UploadApplet;
import javaatwork.myuploader.utils.LocaleManager;
import javaatwork.myuploader.utils.Logger;
import javaatwork.myuploader.utils.Parameters;

import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JList;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/**
 * A JFileChooser that is in the center of the screen. 
 * 
 * @author Johannes Postma
 */ 
public class CenteredFileChooser extends JFileChooser {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -5006688261460210335L;

	/**
	 * Creates a new CenteredFileChooser
	 */
	public CenteredFileChooser() {
		super();
		
		UIManager.put("FileChooser.readOnly", Boolean.TRUE);
		this.setMultiSelectionEnabled(true);
		
		if (Parameters.getParameter(Parameters.UPLOAD_DIRECTORIES, true)) {
			this.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);	
		} else {
			this.setFileSelectionMode(JFileChooser.FILES_ONLY);
		}
		
		if (Parameters.getParameter(Parameters.SHOW_THUMBNAILS_IN_FILEDIALOG, false)) {
			this.setAccessory(new ImagePreview(this));
		}
		
		if (Parameters.getParameter(Parameters.SHOW_HIDDEN_FILES_IN_FILEDIALOG, false) == true) {
			this.setFileHidingEnabled(false);
		}
		
		// remove the file rename functionality in the JFileChooser
		// this is done for JDK 1.4 and less
		// the preferred way is UIManager.put("FileChooser.readOnly", Boolean.TRUE) (JDK 1.5) see above;
		JList list = searchJList(this);
		if (list != null) {
			String listenerClassName;
			MouseListener[] listeners = list.getMouseListeners();
			for (int i = 0; i < listeners.length; i++) {
				listenerClassName = listeners[i].getClass().getName();
				if (listenerClassName.indexOf("SingleClick") != -1) {
					list.removeMouseListener(listeners[i]);
					break;
				}
			}
		}
		
		final String dialogTitle = LocaleManager.getInstance().getDialogTitle();

		// the dialogtitle must come from a resourcebundle
		// the title is not given in the english resourcebundle
		// and therefore the return dialogtitle is null
		// the default dialogtitle will be used.
		if (dialogTitle != null) {

			try {
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						setDialogTitle(dialogTitle);
					}
				});
			} catch (Exception e) {
				Logger.log("CenteredFileChooser", "CenteredFileChooser()", e.toString());
			}
		}
		
		if (Parameters.getParameter(Parameters.DISABLE_DEFAULT_FILEFILTER, false)) {
			this.removeChoosableFileFilter(this.getFileFilter());
		}

		// determine fileFilter
		String fileFilter = Parameters.getParameter(Parameters.FILEFILTER, null);
		
		if (fileFilter != null) {

			try {
				this.setFileFilter(new UploadFileFilter(fileFilter));
			} catch (FileFilterException ffe) {
				Logger.log("CenteredFileChooser", "CenteredFileChooser()", ffe.toString());
			}
		}

	}

	/** 
	 * Creates a JDialog.
	 * 
	 * @param parent The parent component.
	 * @throws HeadlessException If an error occurred.
	 */
	protected JDialog createDialog(Component parent) throws HeadlessException {
		JDialog dialog = super.createDialog(parent);
		
		// the jfilechoosser of the windows look-and-feel has a correct size
		if (!UIManager.getLookAndFeel().getClass().getName().equals("com.sun.java.swing.plaf.windows.WindowsLookAndFeel")) {
			dialog.setSize(580, 460);			
		}
				
		//  sets the frame to the center
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = dialog.getSize();

		if (frameSize.height > screenSize.height) {
			frameSize.height = screenSize.height;
		}

		if (frameSize.width > screenSize.width) {
			frameSize.width = screenSize.width;
		}

		dialog.setLocation(
			(screenSize.width - frameSize.width) / 2,
			(screenSize.height - frameSize.height) / 2);
		
		return dialog;
	}
	
	/**
	 * Returns the JList of a JFileChooser.
	 * 
	 * @param fileChooser The JFileChooser.
	 * @return JList
	 */
	private JList searchJList(Container fileChooser) {
		
		JList ret = null;
		
		if (fileChooser instanceof JList) {
			ret = (JList) fileChooser;
		}
	
		else {
			Component[] children = fileChooser.getComponents();
			
			for (int i = children.length - 1; i >= 0; i--) {
				if (children[i] instanceof Container) {
					ret = searchJList((Container) children[i]);
					if (ret != null) {
						break;
					}
				}
			}
		}

		return ret;
	}
	
	/**
	 * Returns the selected files.
	 * 
	 * @param applet The parent applet.
	 * @return The selected files.
	 */
	public File[] getSelectedFiles(Applet applet) {
		
		String currentDirectory = this.getCurrentDirectory().toString();
	
		// be sure that the preference is stored
		try {
			Preferences preferences = Preferences.userNodeForPackage(getClass());
			preferences.put("local_directory", currentDirectory);
			preferences.flush();
		} catch (BackingStoreException e) {
			Logger.log("CenteredFileChooser", "getSelectedFiles()", e.toString());			
		} catch (IllegalStateException e) {
			// this exception can occur on the mac
			Logger.log("CenteredFileChooser", "getSelectedFiles()", e.toString());
		}
		
		return super.getSelectedFiles();		
	}
	
	/**
	 * Shows an open file dialog.
	 * 
	 * @param applet The parent applet.
	 * @return See JFileChooser.
	 */
	public int showOpenDialog(UploadApplet applet) {
		
		// if the current directory is set in the applet parameters use this one
		String currentDirectory = Parameters.getParameter(Parameters.CURRENT_DIRECTORY, null);
		boolean currentDirectorySet = false;
		
		if (currentDirectory != null) {
			File d = new File(currentDirectory);
			
			if (d.exists() && d.canRead()) {
				this.setCurrentDirectory(d);
				currentDirectorySet = true;
			}
		}
		
		// otherwise use the directory that is stored in the local preferences
		if (!currentDirectorySet) {
			Preferences preferences = Preferences.userNodeForPackage(getClass());
			String dir = preferences.get("local_directory", null);
		
			if (dir != null) {
				this.setCurrentDirectory(new File(dir));
			}
		}
		
		return super.showOpenDialog(applet);
	}
}
