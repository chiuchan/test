/*
 * Copyright 2005-2008 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.dialog;

/**
 * Thrown when a FileFilter could not be created.
 * 
 * @author Johannes Postma
 */ 
public class FileFilterException extends Exception {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -7729842168842523304L;

	/**
	 * Creates a new FileFilterException.
	 */
	public FileFilterException() {
		super();
	}

	/**
	 * Creates a new FileFilterException with a message.
	 * 
	 * @param message The message.
	 */
	public FileFilterException(String message) {
		super(message);
	}
}
