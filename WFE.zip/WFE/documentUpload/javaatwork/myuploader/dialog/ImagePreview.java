/*
 * Copyright 2006-2008 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.dialog;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;

import javaatwork.myuploader.FileTable;
import javaatwork.myuploader.domain.FormFileField;

import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/**
 * Class for displaying a thumbnail.
 * 
 * @author Johannes Postma
 */
public class ImagePreview extends JComponent implements PropertyChangeListener, ListSelectionListener {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -1228147931360116788L;

	private ImageIcon thumbnail = null;
	private WorkerThread thread = null;
	private Object lock = new Object();
	private File thumbFile = null;
	private FileTable table = null;
	private ListSelectionModel rowSM = null;

	/**
	 * Creates ImagePreview
	 * 
	 * @param fileChooser
	 *            The JFileChooser
	 */
	public ImagePreview(JFileChooser fileChooser) {
		setPreferredSize(new Dimension(100, 50));
		fileChooser.addPropertyChangeListener(this);

		thread = new WorkerThread();
		thread.setPriority(Thread.MIN_PRIORITY);
		thread.start();
	}

	public ImagePreview(FileTable table) {
		this.table = table;

		rowSM = table.getSelectionModel();
		rowSM.addListSelectionListener(this);

		thread = new WorkerThread();
		thread.setPriority(Thread.MIN_PRIORITY);
		thread.start();

	}

	/**
	 * Will be invoked when the property is changed of the filechooser.
	 * 
	 * @param e  PropertyChangeEvent
	 */
	public void propertyChange(PropertyChangeEvent e) {

		String prop = e.getPropertyName();

		// If the directory changed, don't show an image.
		if (JFileChooser.DIRECTORY_CHANGED_PROPERTY.equals(prop)) {

			synchronized (lock) {
				thumbFile = null;
				lock.notifyAll();
			}

			// If a file became selected, find out which one.
		} else if (JFileChooser.SELECTED_FILE_CHANGED_PROPERTY.equals(prop)) {

			File file = (File) e.getNewValue();

			if (file != null) {
				synchronized (lock) {
					thumbFile = file;
					lock.notifyAll();
				}
			}
		}

	}

	/**
	 * Will be invoked when the value of ListSelectionEvent is changed.
	 * 
	 * @param e ListSelectionEvent
	 */
	public void valueChanged(ListSelectionEvent e) {

		ListSelectionModel lsm = (ListSelectionModel) e.getSource();

		if (lsm.isSelectionEmpty()) {
			synchronized (lock) {				
				thumbFile = null;
				lock.notifyAll();
			}
			
		} else {

			int selectedRow = lsm.getMinSelectionIndex();
			int selectedMaxRow = lsm.getMaxSelectionIndex();

			if (selectedRow == selectedMaxRow) {

				FormFileField[] fileFields = table.getFormFileFields();
				File file = fileFields[selectedRow].getFile();

				if (file != null) {
					synchronized (lock) {
						thumbFile = file;
						lock.notifyAll();
					}
				} else {
					synchronized (lock) {
						thumbFile = null;
						lock.notifyAll();						
					}
				}

				// multiple selection -> remove icon
			} else {
				synchronized (lock) {
					thumbFile = null;
					lock.notifyAll();
				}
			}

		}
	}

	/**
	 * Paints the component.
	 * 
	 * @param g  Graphics
	 */
	protected void paintComponent(Graphics g) {

		if (thumbnail != null) {
			int x = getWidth() / 2 - thumbnail.getIconWidth() / 2;
			int y = getHeight() / 2 - thumbnail.getIconHeight() / 2;

			if (y < 0) {
				y = 0;
			}

			if (x < 5) {
				x = 5;
			}

			thumbnail.paintIcon(this, g, x, y);
		}
	}

	/**
	 * A thread for reading the images and creating the thumbnails.
	 */
	class WorkerThread extends Thread {

		String path = null;

		public void run() {

			images: while (true) {

				try {
					
					synchronized (lock) {

						if (thumbFile == null) {

							thumbnail = null;
							repaint();
							
							lock.wait();
							
							continue images;
							
						} else {
							
							// the thumbfile must be read in an not synchronized block otherwise the normal thread will hang
							// therefore a copy must be made of the original thumbfile
							path = thumbFile.getPath();
						}
						
					}
					
					ImageIcon tmpIcon = new ImageIcon(path);
					
					// check if the thumbFile has changed
					synchronized (lock) {
						
						if (thumbFile == null || !path.equals(thumbFile.getPath())) {
							
							thumbnail = null;
							repaint();
							
							continue images;
						}
					}					
					
					// create thumbnail
					if (tmpIcon.getIconWidth() > 90) {
						thumbnail = new ImageIcon(tmpIcon.getImage().getScaledInstance(90, -1, Image.SCALE_AREA_AVERAGING));
					} else { // no need to miniaturize
						thumbnail = tmpIcon;
					}
					
					synchronized (lock) {
					
						// check if the thumbFile has changed
						if (thumbFile == null || !path.equals(thumbFile.getPath())) {
						
							thumbnail = null;
							repaint();
							
						} 
						
						// paint the thumbnail
						else {
							repaint();
							lock.wait();
						}	
					}
				} catch (Exception exc) {
					// do nothing
				}
			}
		}
	}
}
