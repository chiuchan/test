/*
 * Copyright 2006-2008 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.dialog;

import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.net.PasswordAuthentication;

import javaatwork.myuploader.listeners.FieldFocusListener;
import javaatwork.myuploader.utils.LocaleManager;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;


/**
 * A login dialog for retrieving the PasswordAuthentication of the
 * proxy server.
 * 
 * @author Johannes Postma
 */ 
public class ProxyLoginDialog {

	private JLabel hostLabel = null;
	private JLabel userLabel = null;
	private JLabel passwordLabel = null;
	private JLabel realmLabel = null;
	private JLabel schemeLabel = null;
	private JLabel proxyLabel = null;
	private JLabel proxyRealmLabel = null;
	private JLabel proxySchemeLabel = null;
	private JTextField userField = new JTextField("");
	private JPasswordField passwordField = new JPasswordField("");
	private int returnValue = 0;
	private JDialog dialog = null;
	private JOptionPane pane = null;
	private Frame parent = null;
	private LocaleManager localeManager = null;
	
	/**
	 * Creates a new LoginDialog.
	 * 
	 * @param parent The parent frame
	 */
	public ProxyLoginDialog(Frame parent) {

		this.parent = parent;
		localeManager = LocaleManager.getInstance();

		hostLabel = new JLabel("Proxy: ");
		userLabel = new JLabel(localeManager.getString("username") + ": ");
		passwordLabel = new JLabel(localeManager.getString("password") + ":        ");
		realmLabel = new JLabel("Realm: ");
		schemeLabel = new JLabel(localeManager.getString("scheme") + ": ");
		proxyLabel = new JLabel("");
		proxyRealmLabel = new JLabel("");
		proxySchemeLabel = new JLabel("Basic");
		
		passwordField.setColumns(20);
		passwordField.setMargin(new Insets(3,0,3,0));
		userField.setMargin(new Insets(3,0,3,0));

		JPanel helpPanel = new JPanel();
		helpPanel.setLayout(new GridBagLayout());
		
		GridBagConstraints c = new GridBagConstraints();
		c.gridx = 0;
		c.gridy = 0;
		c.weightx = 1;
		c.insets = new Insets(0,0,3,0);
		c.fill = GridBagConstraints.BOTH;
		helpPanel.add(hostLabel, c);

		c.gridx = 1;
		helpPanel.add(proxyLabel, c);
		
		c.gridx = 0;
		c.gridy = 1;
		helpPanel.add(realmLabel, c);
		
		c.gridx = 1;
		c.gridy = 1;
		helpPanel.add(proxyRealmLabel, c);
		
		c.gridx = 0;
		c.gridy = 2;
		c.insets = new Insets(0,0,15,0);
		helpPanel.add(schemeLabel, c);
		
		c.gridx = 1;
		c.gridy = 2;
		c.insets = new Insets(0,0,15,0);
		helpPanel.add(proxySchemeLabel, c);
		
		c.gridx = 0;
		c.gridy = 3;
		c.insets = new Insets(0,0,10,0);
		helpPanel.add(userLabel, c);
		
		c.gridx = 1;
		c.gridy = 3;
		c.insets = new Insets(0,0,10,0);
		helpPanel.add(userField, c);
	
		c.gridx = 0;
		c.gridy = 4;
		c.insets = new Insets(0,0,10,0);
		helpPanel.add(passwordLabel, c);
		
		c.gridx = 1;
		c.gridy = 4;
		c.insets = new Insets(0,0,10,0);
		helpPanel.add(passwordField, c);
	
		userField.setText("");
		passwordField.setText("");
	
		pane = new JOptionPane(helpPanel, JOptionPane.QUESTION_MESSAGE, JOptionPane.OK_CANCEL_OPTION, null, new String[] { "OK", localeManager.getString("cancel") }, "OK");
				
		userField.addFocusListener(new FieldFocusListener());
		passwordField.addFocusListener(new FieldFocusListener());
	}

	/**
	 * Shows the login dialog.
	 * 
	 * @param proxyServer The proxy server.
	 * @param realm The realm.
	 * @param loginIncorrect If the dialog must be shown for the second time.
	 * @return JOptionPane.OK_OPTION or JOptionPane.CANCEL_OPTION
	 */
	public int showLoginDialog(String proxyServer, String realm, boolean loginIncorrect) {
		
		// add the proxyServer and realm
		proxyLabel.setText(proxyServer);
		proxyRealmLabel.setText(realm);
			 
		if (loginIncorrect) {
			dialog = pane.createDialog(parent, localeManager.getString("login_incorrect"));
		} else {
			dialog = pane.createDialog(parent, localeManager.getString("authentication_required"));
			
		}
		
		
		dialog.addComponentListener(new ComponentAdapter() {
			public void componentShown(final ComponentEvent ce) {
				
				Runnable r = new Runnable() {

					public void run() {
						
						if (ce.getSource() == passwordField) {
							passwordField.requestFocusInWindow();
							passwordField.setSelectionStart(0);
							passwordField.setSelectionEnd(userField.getText().length());
						} else {
							userField.requestFocusInWindow();
							userField.setSelectionStart(0);
							userField.setSelectionEnd(userField.getText().length());	
						}
					}
				};
				
				SwingUtilities.invokeLater(r);								
			}
		});

		//  sets the frame to the center
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = dialog.getSize();

		if (frameSize.height > screenSize.height) {
			frameSize.height = screenSize.height;
		}

		if (frameSize.width > screenSize.width) {
			frameSize.width = screenSize.width;
		}

		dialog.setLocation(
			(screenSize.width - frameSize.width) / 2,
			(screenSize.height - frameSize.height) / 2);
		
		dialog.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
		dialog.setVisible(true);
		
		
		Object value = pane.getValue();
		
		return returnValue = value.toString().equals("OK") ? JOptionPane.OK_OPTION : JOptionPane.CANCEL_OPTION;
	}

	/**
	 * Closes the LoginDialog.
	 */
	public void closeLoginDialog() {
		dialog.setVisible(false);
	}
	
	/**
	 * Sets the user name for this dialog.
	 * 
	 * @param user The user name.
	 */
	public void setUserName(String user) {
		userField.setText(user);
	}

	/**
	 * Sets the password for this dialog.
	 * 
	 * @param password The password.
	 */
	public void setPassword(String password) {
		passwordField.setText(password);
	}

	/**
	 * Returns the return value of this dialog.
	 * Possible options:
	 * JOptionPane.OK_OPTION
	 * JOptionPane.CANCEL_OPTION
	 * 
	 * @return JOptionPane.OK_OPTION / JOptionPane.CANCEL_OPTION
	 */
	public int getReturnValue() {
		return returnValue;
	}

	/**
	 * Ensures that the dialog is always visible.
	 */
	public void toFront() {
		if (dialog != null) {
			dialog.toFront();
		}
	}

	
	/**
	 * Returns the PasswordAuthentication for the proxy server.
	 * 
	 * @return PasswordAuthentication
	 */
	public PasswordAuthentication getPasswordAuthentication() {

		return new PasswordAuthentication(userField.getText(), passwordField.getPassword());		
		
	}
}
