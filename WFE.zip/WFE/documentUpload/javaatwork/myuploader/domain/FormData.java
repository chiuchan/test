/*
 * Copyright 2006-2008 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.domain;

import java.util.Vector;

/**
 * A holder class for HTML form variables.
 * 
 * @author Johannes Postma - JavaAtWork - http://www.javaatwork.com
 */
public class FormData {

	private Vector formInputFields = new Vector();
	private Vector formFileFields = new Vector();
	
	/**
	 * Creates a new FormData.
	 */
	public FormData() {		
	}
	
	/**
	 * Adds a FormInputField.
	 * 
	 * @param formInputField The FormInputField.
	 */
	public void addFormInputField(FormInputField formInputField) {
		formInputFields.add(formInputField);
	}
	
	/**
	 * Adds a FormFileField.
	 * 
	 * @param formFileField The FormFileField.
	 */
	public void addFormFileField(FormFileField formFileField) {
		formFileFields.add(formFileField);
	}
	
	/**
	 * Adds a FormFileField.
	 * 
	 * @param fileFields The FormFileField.
	 */
	public void addFormFileFields(FormFileField [] fileFields) {
		for (int i = 0; i < fileFields.length; i++) {
			formFileFields.add(fileFields[i]);	
		}		
	}
	
	/**
	 * Returns an array of FormInputField.
	 * 
	 * @return An array of FormInputField.
	 */
	public FormInputField[] getFormInputFields() {
		return (FormInputField[])formInputFields.toArray(new FormInputField[formInputFields.size()]);
	}
	
	/**
	 * Returns an array of FormFileField.
	 * 
	 * @return An array of FormFileField.
	 */
	public FormFileField[] getFormFileFields() {
		return (FormFileField[])formFileFields.toArray(new FormFileField[formFileFields.size()]);
	}
	
	/**
	 * Returns the number of FormInputFields.
	 * 
	 * @return The number of FormInputFields.
	 */
	public int getNumberOfFormInputFields() {
		return formInputFields.size();
	}
	
	/**
	 * Returns the number of FormFileFields.
	 * 
	 * @return The number of FormFileFields.
	 */
	public int getNumberOfFormFileFields() {
		return formFileFields.size();
	}
	
	/**
	 * Returns the number of bytes of all files.
	 * 
	 * @return The number of bytes of all files.
	 */
	public long getTotalByteSizeOfFiles() {
		
		long totalSize = 0L;
		
		for (int i = 0; i < formFileFields.size(); i++) {
			
			FormFileField formFile = (FormFileField)formFileFields.elementAt(i);
			totalSize += formFile.getFile().length();
		}
		
		return totalSize;
	}
	
	/**
	 * Remove all formFileFields.
	 */
	public void removeAllFormFileFields() {
		formFileFields.removeAllElements();
	}
	
	/**
	 * Returns a String representation.
	 * 
	 * @return A String representation.
	 */
	public String toString() {
		
		StringBuffer buf = new StringBuffer();
		
		for (int i = 0; i < formInputFields.size(); i++) {
			
			FormInputField field = (FormInputField)formInputFields.elementAt(i);
			buf.append(field.getName());
			buf.append(" - ");
			buf.append(field.getValue());
			buf.append("\r\n");
		}		
		
		return buf.toString();		
	}
}
