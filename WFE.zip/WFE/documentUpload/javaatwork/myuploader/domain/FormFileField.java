/*
 * Copyright 2006-2008 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.domain;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import javaatwork.myuploader.utils.Parameters;

/**
 * Class that represents a form file field of an HTML form.
 * 
 * @author Johannes Postma - JavaAtWork - http://www.javaatwork.com
 */
public class FormFileField {

	private String name = null;
	private File file = null;
	private String contentType = null;
	private String uploadDirectory = null;
	
	/**
	 * Creates a new FormFileField.
	 * 
	 * @param name The name of the file field.
	 * @param file The selected file of the field.
	 * @param uploadDirectory The upload directory on the server.
	 * @param contentType The content type of the file.
	 */
	public FormFileField(String name, File file, String uploadDirectory, String contentType) {
		this.name = name;
		this.file = file;
		this.uploadDirectory = uploadDirectory;
		this.contentType = contentType;
	}
	
	/**
	 * Returns the file of the field.
	 * 
	 * @return The file of the field.
	 */
	public File getFile() {
		return file;
	}

	/**
	 * Returns the name of the field.
	 * 
	 * @return The name of the field.
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the file of the field.
	 * 
	 * @param file The file of the field.
	 */
	public void setFile(File file) {
		this.file = file;
	}

	/**
	 * Sets the name of the field.
	 * 
	 * @param name The name of the field.
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Returns the content-type.
	 * 
	 * @return The content-type.
	 */
	public String getContentType() {
		return contentType;
	}

	/**
	 * Set the content-type.
	 * 
	 * @param contentType The content-type.
	 */
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}
	
	/**
	 * Returns the upload directory.
	 * 
	 * @return The upload directory.
	 */
	public String getUploadDirectory() {
		return uploadDirectory;
	}
	
	/**
	 * Returns the upload name. The upload name is the
	 * name of the folder + the file to be uploaded.
	 * e.g. images/pic001.jpg.
	 * 
	 * @return The upload name.
	 */
	public String getUploadName() {
		return uploadDirectory + file.getName();
	}
	
	/**
	 * Returns the url encoded upload name. The encoding is based
	 * on the applet parameter 'charsetForURLEncoding'. If the parameter
	 * is -1 than the file will not be urlencoded, if the parameter
	 * is not present UTF-8 is used.
	 * 
	 * @return The encoded upload name.
	 */
	public String getURLEncodedUploadName() {
		
		String charSet = Parameters.getParameter(Parameters.CHARSET_FOR_URLENCODING, "UTF-8");
		
		// if charSet = -1 than the filename will not be urlencoded
		if (charSet.equals("-1")) {
			return uploadDirectory + file.getName();
		} else {
			try {
				return URLEncoder.encode(uploadDirectory + file.getName(), charSet);
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
				return URLEncoder.encode(uploadDirectory + file.getName());
			}
		}
	}
}
