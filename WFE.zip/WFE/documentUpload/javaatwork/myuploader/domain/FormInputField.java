/*
 * Copyright 2006-2008 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.domain;

/**
 * Class that represents a form input field of an HTML form. This can
 * be for example a field of type: text, radio, checkbox, textarea or
 * select.
 * 
 * @author Johannes Postma - JavaAtWork - http://www.javaatwork.com
 */
public class FormInputField  {

	private String name = null;
	private String value = null;

	/**
	 * Creates a new FormInputField.
	 * 
	 * @param name The name of the input field.
	 * @param value The value of the input field.
	 */
	public FormInputField(String name, String value) {
		this.name = name;
		this.value = value;
	}

	/**
	 * Returns the name of the input field.
	 * 
	 * @return The name of the input field.
	 */
	public String getName() {
		return name;
	}

	/**
	 * Returns the value of the input field.
	 * 
	 * @return The value of the input field.
	 */
	public String getValue() {
		return value;
	}

	/**
	 * Sets the name of the input field.
	 * 
	 * @param name The name of the input field.
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Sets the value of the input field.
	 * 
	 * @param value The value of the input field.
	 */
	public void setValue(String value) {
		this.value = value;
	}

}
