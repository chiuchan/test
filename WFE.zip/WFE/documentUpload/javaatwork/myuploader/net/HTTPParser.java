/*
 * Copyright 2005-2008 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.net;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;

import javaatwork.myuploader.utils.Parameters;

/**
 * The purpose of this class is to return the correct status code and the
 * body in the right charset of an http response of an http/1.0 request.
 * 
 * @author Johannes Postma
 */
public class HTTPParser {

	/* the status code of the http response */
	private int statusCode = -1;
	
	/* the contentLength of the body of the http response */
	private int contentLength = -1;
	
	/* the body of the http response */
	private String body = null;
	
	/* the charset of the body of the http response default: ISO-8859-1*/
	private String charSet = "ISO-8859-1";
	
	/* the first line of the http response */
	private String statusLine = null;
	
	/**
	 * Creates a new HTTPParser and parset the http response.
	 * 
	 * @param in The inputstream of the http response.
	 * @param charSetName The charset of the http headers.
	 * @throws IOException If an error occurred.
	 */
	public HTTPParser(InputStream in, String charSetName) throws IOException {

		processStatusLine(in, charSetName);
		processHeaders(in, charSetName);
		processBody(in);
	}

	/**
	 * Parses the headers of the http response.
	 * 
	 * @param in The inputstream of the http response.
	 * @param charSetName The charset for parsing the headerline.
	 * @throws IOException If an IO error occurs.
	 */
	private void processHeaders(InputStream in, String charSetName) throws IOException {
		
		String header = null;
		
		do {
			header = new String(readLine(in), charSetName).trim();
			
			if (header.toLowerCase().indexOf("content-length:") != -1) {
				
				String length = header.substring(header.indexOf(" ") + 1);
				contentLength = Integer.parseInt(length);
				
			} else if (header.indexOf("charset=") != -1) {
				charSet = header.substring(header.indexOf("charset=") + "charset=".length());				
			}
						
		} while (!header.equals(""));
	}
	
	/**
	 * Parses the first line of the http response.
	 * 
	 * @param in The inputstream of the http response.
	 * @param charSetName The charset for parsing the statusline.
	 * @throws UnsupportedEncodingException If the charSet is unkown.
	 * @throws IOException If an IO error occurs.
	 */
	private void processStatusLine(InputStream in, String charSetName) throws UnsupportedEncodingException, IOException {

		statusLine = new String(readLine(in), charSetName);
		
		int start = statusLine.indexOf(" ") + 1;
		int end = statusLine.indexOf(" ", start);

		String code = statusLine.substring(start, end);
		statusCode = Integer.parseInt(code);		
	}
	
	/**
	 * Parses the body of the http response. If the contentLength is -1 the body is read
	 * till the end of the stream.
	 * 
	 * @param in The inputstream of the http response.
	 * @return The body of the http response.
	 * @throws IOException If an error occurred.
	 */
	private void processBody(InputStream in) throws IOException {

		ByteArrayOutputStream buf = new ByteArrayOutputStream();
		byte[] b = new byte[1024];
		
		int read = 0;
		int total = 0;
		
		while ((read = in.read(b)) != -1) {
			buf.write(b, 0, read);
			total += read;
			
			if (total > contentLength && contentLength != -1) {
				break;
			}
		}
		
		body = new String(buf.toByteArray(), charSet);
		
		if (Parameters.getParameter(Parameters.SHOW_HTTP_RESPONSE, false)) {
			System.out.print(body);			
		}
	}

	/**
	 * Reads one line of an inputstream. The line ends with a newline ('\n').
	 * 
	 * @param in The inputstream.
	 * @return The line.
	 * @throws IOException If an error has occurred.
	 */
	private byte[] readLine(InputStream in) throws IOException {

		ByteArrayOutputStream buf = new ByteArrayOutputStream();

		int ch = 0;

		while ((ch = in.read()) >= 0) {
			buf.write(ch);
			if (ch == '\n') {
				break;
			}
		}

		if (buf.size() == 0) {
			return null;
		}
		
		if (Parameters.getParameter(Parameters.SHOW_HTTP_RESPONSE, false)) {
			System.out.print(new String(buf.toByteArray()));			
		}
		
		return buf.toByteArray();
	}

	/**
	 * Returns the status code of the http response.
	 * 
	 * @return The status code.
	 */
	public int getStatusCode() {
		return statusCode;
	}

	/**
	 * Returns the body from the http response.
	 * 
	 * @return The body.
	 */
	public String getBody() {
		return body;
	}
	
	/**
	 * Returns the status line of the http response.
	 * 
	 * @return the status line.
	 */
	public String getStatusLine() {
		return statusLine;
	}

}
