/*
 * Copyright 2006-2008 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.net;

/**
 * If an error occurred with the ProxyAuthenticator.
 * 
 * @author Johannes Postma
 */
public class ProxyAuthenticatorException extends Exception {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Creates a new ProxyAuthenticatorException.
	 * 
	 * @param message The message.
	 */
	public ProxyAuthenticatorException(String message) {
		super(message);
	}
}
