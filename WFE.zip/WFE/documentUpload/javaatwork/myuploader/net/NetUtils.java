/*
 * Copyright 2006-2008 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.net;

import java.io.IOException;
import java.lang.reflect.Method;
import java.net.InetSocketAddress;
import java.net.PasswordAuthentication;
import java.net.Socket;
import java.net.URI;
import java.net.URL;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.List;

import javaatwork.myuploader.utils.Logger;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import com.sun.java.browser.net.ProxyInfo;
import com.sun.java.browser.net.ProxyService;

/**
 * Utility class for network connections.
 * 
 * @author Johannes Postma
 */
public class NetUtils {

	/**
	 * Returns the port number of an url. If the url contains no port number
	 * port 80 is returned.
	 * 
	 * @param url  The url.
	 * @return The port number.
	 */
	public int getPort(URL url) {

		int port = url.getPort();

		if (port == -1) {
			if (url.getProtocol().equalsIgnoreCase("https")) {
				return 443;
			} else {
				return 80;
			}
		} else {
			return port;
		}
	}

	/**
	 * Creates the Socket. The Socket could be a normal Socket or an SSLSocket.
	 * 
	 * @param url The URL.
	 * @param passwordAuthentication The login data for the proxy server or null.
	 * @throws ProxyAuthenticatorException If the user can not be authenticated.
	 * @throws Exception If an error occurred.
	 */
	public Socket createSocket(URL url, PasswordAuthentication passwordAuthentication) throws ProxyAuthenticatorException, Exception {

		Socket socket = null;
		String proxy = detectProxyForUrl(url);

		// HTTPS
		if (url.getProtocol().equalsIgnoreCase("https")) {

			// Create a trust manager that does not validate certificate chains
			TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() { public X509Certificate[] getAcceptedIssuers() { return null;
					}

					public void checkClientTrusted(X509Certificate[] certs, String authType) {
					}

					public void checkServerTrusted(X509Certificate[] certs, String authType) {
					}
				}
			};

			SSLContext sc = SSLContext.getInstance("SSL");
			sc.init(null, trustAllCerts, new SecureRandom());

			// DIRECT
			if (proxy == null) {
				SSLSocketFactory socketFactory = sc.getSocketFactory();
				socket = socketFactory.createSocket(url.getHost(), this.getPort(url));
			}

			// PROXY
			else {

				String proxyHost = proxy.substring(0, proxy.indexOf(":"));
				String proxyPort = proxy.substring(proxy.indexOf(":") + 1);

				SSLTunnelSocketFactory socketFactory = new SSLTunnelSocketFactory(proxyHost, proxyPort, sc);
				socket = socketFactory.createSocket(url.getHost(), this.getPort(url), passwordAuthentication);				
			}

			// HTTP
		} else {

			// DIRECT
			if (proxy == null) {
				socket = new Socket(url.getHost(), this.getPort(url));
			}

			// PROXY
			else {

				String host = proxy.substring(0, proxy.indexOf(":"));
				String port = proxy.substring(proxy.indexOf(":") + 1);
				socket = new Socket(host, Integer.parseInt(port));				
			}
		}

		return socket;
	}

	/**
	 * Returns the proxy for the specified URL.
	 * 	 
	 * @param url The URL.
	 * @return null if no proxy can be found otherwise host:port
	 */
	public String detectProxyForUrl(URL url) {

		
		try {
			
			String javaSpecificationVersion = System.getProperty("java.specification.version");
			
			if (javaSpecificationVersion.equals("1.4")) {
				return getProxyForJRE14(url);
			} else {
				return getProxyForJRE15AndFurther(url);
			}
			
		} catch (Throwable t) {
			t.printStackTrace();
			// no proxy found -> do nothing
		}

		return null;
	}

	/**
	 * Returns the proxy setting in the form host:port for JRE 1.4.
	 * 
	 * @param url The url that a connection is required to.
	 * @return The proxy
	 * @throws IOException In case the url is invalid.
	 */
	public String getProxyForJRE14(URL url) throws IOException {
				
		ProxyInfo[] proxyInfo = ProxyService.getProxyInfo(url);

		if (proxyInfo == null || proxyInfo.length == 0) {				
			return null;
		} else {
			Logger.log("NetUtils", "detectProxyForUrl()", "ProxyService returned proxy " + proxyInfo[0].getHost() + ":" + proxyInfo[0].getPort() + ".");
				
			String host = proxyInfo[0].getHost();
			int port = proxyInfo[0].getPort();
			return host + ":" + port;
		}
	}
	
	/**
	 * Returns the proxy setting in the form host:port for JRE 1.5 and newer.
	 * 
	 * @param url url The url that a connection is required to.
	 * @return The proxy.
	 * @throws Exception If an exception has occurred.
	 */
	public String getProxyForJRE15AndFurther(URL url) throws Exception {
		String proxy = null;
		
		URI uri = new URI(url.toExternalForm());
		
		Class cls = Class.forName("java.net.ProxySelector");
     	
        // define the method 
        Method getDefault = cls.getMethod("getDefault", null);
        
        // create the proxyselector
        Object proxySelector = getDefault.invoke(null, null);
        
        // define the class types for the input variables for the select method
        Class clsTypes[] = new Class[1];
        clsTypes[0] = uri.getClass();
        
        // define the method
        Method select = cls.getMethod("select", clsTypes);
        
        // create a list of parameters
        Object argList[] = new Object[1];
        argList[0] = uri;
        
        // call the method
        Object ob = select.invoke(proxySelector, argList);
        List list = (List)ob;
        
        for (int i = 0; i < list.size(); i++) {
            Object obj = list.get(i);
            
            Method address = obj.getClass().getMethod("address", null);
            InetSocketAddress sAddress = (InetSocketAddress)address.invoke(obj,null);
        
            if (sAddress != null) {
            	proxy = sAddress.getHostName() + ":" + sAddress.getPort();
            	Logger.log("NetUtils", "detectProxyForUrl()", "ProxySelector returned proxy " + proxy + ".");            	
            }
        }           
		
		return proxy;
	}
	
	/**
	 * True if a proxy is used for the specified URL.
	 * 
	 * @param url The URL.
	 * @return True if a proxy is used for the specified URL.
	 */
	public boolean useProxy(URL url) {
		
		String proxy = detectProxyForUrl(url);
		
		if (proxy != null) { 
			return true;
		} else {
			return false;
		}
	}
}
