/*
 * Copyright 2005-2008 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.net;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.ConnectException;
import java.net.PasswordAuthentication;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javaatwork.myuploader.domain.FormData;
import javaatwork.myuploader.domain.FormFileField;
import javaatwork.myuploader.domain.FormInputField;
import javaatwork.myuploader.utils.FileInfoManager;
import javaatwork.myuploader.utils.LocaleManager;
import javaatwork.myuploader.utils.Logger;
import javaatwork.myuploader.utils.Parameters;
import javaatwork.myuploader.utils.ResizeManager;
import javaatwork.myuploader.utils.SwingWorker;
import javax.swing.JOptionPane;
import javaatwork.myuploader.dialog.MessageDialog;
import java.awt.Frame;

/**
 * Task for sending files to a Web Server. The protocol used is http/https.
 *
 * @author Johannes Postma
 */
public class HTTPUploadTask  {

        private DataOutputStream out = null;
        private Socket socket = null;
        private int filesProcessed = 0;
        private long totalBytes = 0L;
        private long bytesProcessed = 0L;
        private String currentFileName = "";
        private long begin = 0L;
        private SwingWorker worker = null;
        private boolean finished = false;
        private String boundary = null;
        private URL uploadURL = null;
        private final static String NEWLINE = "\r\n";
        private LocaleManager localeManager = null;
        private String processMessage = "";
        private PasswordAuthentication proxyPasswordAuthentication = null;
        private NetUtils netUtils = null;
        private FormData data = null;
        private boolean abort = false;
        private boolean uploading = false;
        private File zipFile = null;
        private ResizeManager resizer = null;
        private String errorMessage = null;
        private Frame frame = null;

        private int returnCode = 0;
        private int statusCode = 0;

        public static final int SUCCESS = 0;
        public static final int CANCELLED = 1;
        public static final int CONNECTION_REFUSED = 2;
        public static final int CUSTOM_ERROR = 3;
        public static final int TECHNICAL_ERROR = 9;

        /**
         * The boundary prefix.
         */
        private final String PREFIX = "--";

        /**
         * Creates a new HTTPUploadTask with a AppletContext.
         *
         * @param uploadURL The upload url of the server.
         * @param formData The FormData, the data to be uploaded.
         * @param proxyPasswordAuthentication PasswordAuthentication.
         */
        public HTTPUploadTask(URL uploadURL, FormData formData, PasswordAuthentication proxyPasswordAuthentication, Frame theFrame) {
                super();
                localeManager = LocaleManager.getInstance();
                this.netUtils = new NetUtils();
                this.proxyPasswordAuthentication = proxyPasswordAuthentication;
                this.uploadURL = uploadURL;
                this.data = formData;
                this.frame = theFrame;

                boundary = "--------------------" + Long.toString(System.currentTimeMillis(), 16);
        }

        /**
         * Returns the number of processed bytes.
         *
         * @return The number of processed bytes.
         */
        public synchronized long getBytesProcessed() {
                return bytesProcessed;
        }

        /**
         * Returns the number of bytes of the files to be sent.
         *
         * @return The number of bytes of the files to be sent.
         */
        public synchronized long getTotalBytes() {
                return totalBytes;
        }

        /**
         * Return the number of files to be sent.
         *
         * @return The number of files to be sent.
         */
        public synchronized int getFiles() {
                return data.getNumberOfFormFileFields();
        }

        /**
         * Returns the number of processed files.
         *
         * @return The number of processed files.
         */
        public synchronized int getFilesProcessed() {
                return filesProcessed;
        }

        /**
         * Returns the elapsed time in ms.
         *
         * @return The elapsed time ms.
         */
        public synchronized int getElapsedTime() {

                return (int) (System.currentTimeMillis() - begin);
        }

        /**
         * Returns the rest time in ms.
         *
         * @return The elapsed time in ms.
         */
        public synchronized int getTimeLeft() {
                return (int) ((totalBytes - getBytesProcessed()) / (double) getBytesProcessed() * getElapsedTime());
        }

        /**
         * Returns the percentcompleted of the task.
         *
         * @return The percentcompleted.
         */
        public synchronized int getPercentCompleted() {
                return (int) (getBytesProcessed() / (double) totalBytes * 100);
        }

        /**
         * Returns the filename of the file that is currently be uploaded.
         *
         * @return The name of the currently uploaded file.
         */
        public synchronized String getCurrentFileName() {
                return currentFileName;
        }

        /**
         * Returns the status of the upload process.
         *
         * @return The status.
         */
        public synchronized String getProcessMessage() {
                return processMessage;
        }

        /**
         * Starts the task (upload).
         */
        public void start() {
                worker = new SwingWorker() {

                        public Object construct() {
                                upload();
                                return null;

                        }
                };

                worker.start();
        }

        /**
         * Interrupts the task.
         */
        public void stop() {

                // if no connection is available (e.g. the client is connecting)
                // pressing
                // the cancel button generates otherwise a NullPointerException
                if (socket != null) {

                        try {
                                socket.close();
                        } catch (IOException e) {
                        }
                }

                abort = true;
                returnCode = CANCELLED;
        }

        /**
         * Returns true if the task is finished.
         *
         * @return True if the task is finished.
         */
        public boolean finished() {
                return finished;
        }

        /**
         * Does the real upload.
         */
        public void upload() {

                begin = System.currentTimeMillis();

                try {

                        int maxImageSize = Parameters.getParameter(Parameters.MAX_IMAGE_SIZE, -1);
                        int maxWidth = maxImageSize;
                        int maxHeight =  maxImageSize;

                        // maxImageSize was not specified
                        if (maxImageSize == -1) {
                                maxWidth = Parameters.getParameter(Parameters.MAX_IMAGE_WIDTH, -1);
                                maxHeight = Parameters.getParameter(Parameters.MAX_IMAGE_HEIGHT, -1);
                        }

                        // resize
                        if (maxWidth != -1 || maxHeight != -1) {
                                resizer = new ResizeManager(this);
                                if (!resizeImages(maxWidth, maxHeight)) {
                                        return;
                                }
                        }

                        String zipFileName = Parameters.getParameter(Parameters.ZIP_FILE, null);

                        if (zipFileName != null)
                        {
                                if (!createZipFile(zipFileName)) {
                                        return;
                                }
                        }

                        String uploadFileInfo = Parameters.getParameter(Parameters.UPLOAD_FILE_INFO, null);

                        if (uploadFileInfo != null) {
                                if (!createFileInfo(uploadFileInfo)) {
                                        return;
                                }
                        }

                        //	sets the default values to 0
                        init();

                        // needed for the progress dialog
                        uploading = true;

                        processMessage = localeManager.getString("connecting") + "....";

                        socket = netUtils.createSocket(uploadURL, proxyPasswordAuthentication);

                        out = new DataOutputStream(new BufferedOutputStream(socket.getOutputStream()));

                        // write the headers to the outputstream
                        writeHeaders();
                        writeFormInputFields(data.getFormInputFields());

                        processMessage = localeManager.getString("uploading") + "....";

                        writeFormFileFields(data.getFormFileFields());
                        writeFooters();

                        processMessage = localeManager.getString("waiting_for_response") + "....";

                        HTTPParser httpParser = new HTTPParser(socket.getInputStream(), "ISO-8859-1");

                        Logger.log("HTTPUploadTask", "upload()", httpParser.getStatusLine());

                        if (httpParser.getStatusCode() == 200) {
                                returnCode = SUCCESS;
                                statusCode = 200;

                                if (Parameters.getParameter(Parameters.SHOW_CUSTOM_ERROR_MESSAGES, false)) {
                                        errorMessage = httpParser.getBody();

                                        if (errorMessage != null && !errorMessage.trim().equals("")) {
                                                returnCode = CUSTOM_ERROR;
                                        }
                                }

                        } else {
                                returnCode = TECHNICAL_ERROR;
                                statusCode = httpParser.getStatusCode();
                        }

                } catch (UnknownHostException uhe) {

                        Logger.log("HTTPUploadTask", "upload()", uhe.toString());

                        if (!abort) {
                                returnCode = TECHNICAL_ERROR;
                        }

                        finished = true;
                        worker.interrupt();

                } catch (ConnectException ce) {

                        Logger.log("HTTPUploadTask", "upload()", ce.toString());

                        if (!abort) {
                                returnCode = CONNECTION_REFUSED;
                        }

                        finished = true;
                        worker.interrupt();

                } catch (IOException ioe) {

                        Logger.log("HTTPUploadTask", "upload()", ioe.toString());

                        if (!abort) {
                                returnCode = TECHNICAL_ERROR;
                        }

                        finished = true;
                        worker.interrupt();

                } catch (Throwable t) {

                        Logger.log("HTTPUploadTask", "upload()", t.toString());
                        returnCode = TECHNICAL_ERROR;

                        finished = true;
                        worker.interrupt();

                } finally {

                        if (resizer != null) {
                                resizer.deleteTempDirectory();
                        }

                        if (out != null) {
                                try {
                                        out.close();
                                } catch (IOException ioe) {
                                }
                        }

                        if (socket != null) {
                                try {
                                        socket.close();
                                } catch (IOException ioe) {
                                }
                        }

                        // if a zip has been created delete it
                        if (zipFile != null) {
                                zipFile.delete();
                        }

                        finished = true;
                }
        }

        /**
         * Writes the headers to the outputstream.
         *
         * @throws IOException If an IO error occurred.
         */
        private void writeHeaders() throws IOException {

                // in case a proxy server is used the full URL is required in the request line
                if (netUtils.useProxy(uploadURL)) {
                        out.writeBytes("POST " + uploadURL.toString() + " HTTP/1.0" + NEWLINE);
                } else {

                        // useFullURL is added for backwards compatibility
                        if (Parameters.getParameter(Parameters.USE_FULL_URL, false)) {
                                out.writeBytes("POST " + uploadURL.toString() + " HTTP/1.0" + NEWLINE);
                        } else {
                                out.writeBytes("POST " + uploadURL.getFile() + " HTTP/1.0" + NEWLINE);
                        }
                }

                out.writeBytes("Accept: */*" + NEWLINE);
                out.writeBytes("User-Agent: MyUploader/1.13" + NEWLINE);
                out.writeBytes("Content-type: " + "multipart/form-data; boundary=" + boundary + NEWLINE);

                String cookie =  Parameters.getParameter(Parameters.COOKIE, null);

                if (cookie != null && !cookie.trim().equalsIgnoreCase("")) {
                        out.writeBytes("Cookie: " + cookie + NEWLINE);
                }

                if (proxyPasswordAuthentication != null) {

                        String loginData = new sun.misc.BASE64Encoder().encode ((proxyPasswordAuthentication.getUserName() + ":" + new String(proxyPasswordAuthentication.getPassword())).getBytes());

                        out.writeBytes("Proxy-Authorization: Basic " + loginData + NEWLINE);
                }

                out.writeBytes("Cache-Control: no-cache" + NEWLINE);
                out.writeBytes("Pragma: no-cache" + NEWLINE);
                out.writeBytes("Host: " + uploadURL.getHost() + NEWLINE);
                out.writeBytes("Content-Length: " + new HTTPContentLengthCalculator().calculateContentLength(data, boundary.length() + 2) + NEWLINE + NEWLINE);
        }

        /**
         * Writes an array of form input fields to the outputstream.
         *
         * @param formInputFields An array of FormInputField.
         * @throws IOException If an error occurred.
         */
        private void writeFormInputFields(FormInputField [] formInputFields) throws IOException {

                for (int i = 0; i < formInputFields.length; i++) {
                        writeFormInputField(formInputFields[i]);
                }
        }

        /**
         * Writes a single form input field to the outputstream.
         *
         * @param formInputField The FormInputField.
         * @throws IOException If an error occurred.
         */
        private void writeFormInputField(FormInputField formInputField) throws IOException {

                // write boundary
                out.writeBytes(PREFIX);
                out.writeBytes(boundary);
                out.writeBytes(NEWLINE);

                // write content header
                out.writeBytes("Content-Disposition: form-data; name=\"" + formInputField.getName() + "\"" + NEWLINE);
                out.writeBytes(NEWLINE);
                out.writeBytes(formInputField.getValue());
                out.writeBytes(NEWLINE);
        }

        /**
         * Writes an array of form file fields to the outputstream.
         *
         * @param formFileFields An array of FormFileField.
         * @throws IOException If an error occurred.
         */
        private void writeFormFileFields(FormFileField [] formFileFields) throws IOException {

                for (int i = 0; i < formFileFields.length; i++) {
                        filesProcessed++;
                        writeFormFile(formFileFields[i]);
                }
        }

        /**
         * Writes a FormFileField to the outputstream.
         *
         * @param formFile The FormFileField.
         * @throws IOException If an IO error occurred.
         */
        private void writeFormFile(FormFileField formFile) throws IOException {

                File file = formFile.getFile();

                // create inputstream
                currentFileName = file.getName();
                BufferedInputStream in = new BufferedInputStream(new FileInputStream(file));

                // write boundary
                out.writeBytes(PREFIX);
                out.writeBytes(boundary);
                out.writeBytes(NEWLINE);

                // write content header
                out.writeBytes("Content-Disposition: form-data; name=\"" + formFile.getName() + "\"; filename=\"" + formFile.getURLEncodedUploadName() + "\"" + NEWLINE);
                out.writeBytes("Content-Type: " + formFile.getContentType() + NEWLINE);
                out.writeBytes(NEWLINE);

                // write content
                byte[] data = new byte[1024];
                int len = 0;

                while ((len = in.read(data, 0, data.length)) != -1) {
                        out.write(data, 0, len);

                        // update properties
                        bytesProcessed = bytesProcessed + len;
                }

                out.writeBytes(NEWLINE);
                out.flush();
                in.close();
        }

        /**
         * Writes the last lines of the body to the outputstream.
         *
         * @throws IOException If an IO error occurred.
         */
        public void writeFooters() throws IOException {

                out.writeBytes(PREFIX);
                out.writeBytes(boundary);
                out.writeBytes(PREFIX);
                out.writeBytes(NEWLINE);
                out.flush();
        }

        /**
         * Returns the return code (SUCCESS, CANCELLED, TECHNICAL_ERROR, CONNECTION_REFUSED).
         *
         * @return The return code.
         */
        public int getReturnCode() {
                return returnCode;
        }

        /**
         * Returns the http status code from the server.
         *
         * @return The http status code from the server.
         */
        public int getStatusCode() {
                return statusCode;
        }

        /**
         * Creates a zipfile and stores the zipfile in the temp directory
         *
         * @return True if zip file is created false is process is cancelled
         * @throws IOException If an error occurred.
         */
        private boolean createZipFile(String zipFileName) throws IOException {

                processMessage = localeManager.getString("creatingZip") + "....";

                FormFileField [] fileFields = data.getFormFileFields();

                // sets the default values to 0
                init();

                // Create a buffer for reading the files
            byte[] buf = new byte[1024];

            try {

                    // Create the ZIP file
                    //include the underscore in the appId for the file name
                String appIdStr = zipFileName.substring(0, zipFileName.indexOf("_") + 1),
                  validFormats = ".pdf.tif.tiff.jpg.jpeg.png.gif.bmp.txt.doc.docx.wpd.wps",
                  validFormatsErrorMsg = ".pdf, .tif, .tiff, .jpg, .jpeg, .png, .gif, .bmp, .txt, .doc, .docx, .wpd, .wps",
                  fileExtension = "",
                  periodStr = ".";
                zipFile = new File(System.getProperty("java.io.tmpdir") + File.separator + zipFileName);
                ZipOutputStream out = new ZipOutputStream(new FileOutputStream(zipFile));

                // Compress the files
                for (int i=0; i < fileFields.length & !abort; i++) {
                    FileInputStream in = new FileInputStream(fileFields[i].getFile());
                    fileExtension = fileFields[i].getFile().getName().substring(fileFields[i].getFile().getName().lastIndexOf(periodStr));
                    if(validFormats.indexOf(fileExtension.toLowerCase()) == -1)
                    {
                      MessageDialog md = new MessageDialog(this.frame);

                      md.showMessageDialog("Invalid file format found: " + fileExtension + ".  Valid file formats are: " + validFormatsErrorMsg, "File Formate Error", JOptionPane.ERROR_MESSAGE);
                      throw new IOException("Invalid file format found: " + fileExtension + ".  Valid file formats are: " + validFormatsErrorMsg);
                    }

                    //verify file size is under 10mb
                    if(fileFields[i].getFile().length() > 10485760)
                    {
                        MessageDialog md = new MessageDialog(this.frame);
                        md.showMessageDialog("Error! File size is over 10mb. Please only select files that are 10mb or less in size.", "File Size Error", JOptionPane.ERROR_MESSAGE);
                        throw new IOException("Error! File size is over 10mb. Please only select files that are 10mb or less in size.");
                    }

                    filesProcessed++;
                    currentFileName = fileFields[i].getFile().getName();

                    // Add ZIP entry to output stream.
                    out.putNextEntry(new ZipEntry(appIdStr + fileFields[i].getUploadName()));

                    // Transfer bytes from the file to the ZIP file
                    int len = 0;

                    while ((len = in.read(buf)) > 0 && !abort) {
                            out.write(buf, 0, len);
                            bytesProcessed += len;
                    }

                    // Complete the entry
                    out.closeEntry();
                    in.close();
                }

                // Complete the ZIP file
                out.close();

                if (!abort) {

                        // create a new form field and put it in the formdata
                        FormFileField fff = new FormFileField("userfile", zipFile, "", ContentTypeMapper.getInstance().getContentType(zipFile));
                        data.removeAllFormFileFields();
                        data.addFormFileField(fff);
                }

                return !abort;

            } catch (IOException e) {

                    Logger.log("HTTPUploadTask", "createZipFile()", e.toString());
                    throw e;
            }
        }

        /**
         * Checks if the files are currently uploaded.
         *
         * @return True if the files are being uploaded to the server.
         */
        public synchronized boolean isUploading() {
                return uploading;
        }

        /**
         * Sets the default values to 0
         */
        private void init() {

                bytesProcessed = 0;
                totalBytes = data.getTotalByteSizeOfFiles();
                filesProcessed = 0;
        }

        /**
         * Resizes images.
         *
         * @param maxWidth The max width of the resized image.
         * @param maxHeight The max height of the resized image
         * @return True if the image is created, false with an abort
         * @throws Exception If the image cannot be resized.
         */
        private boolean resizeImages(int maxWidth, int maxHeight) throws Exception {

                processMessage = localeManager.getString("resize") + "....";

                FormFileField [] fileFields = data.getFormFileFields();

                int compressionQuality = Parameters.getParameter(Parameters.COMPRESSION_QUALITY, 75);

                if (compressionQuality < 0 || compressionQuality > 100) {
                        compressionQuality = 75;
                }

                int imageInterpolation = Parameters.getParameter(Parameters.IMAGE_INTERPOLATION, 1);

                // sets the default values to 0
                init();

            // Compress the files
                for (int i=0; i < fileFields.length & !abort; i++) {
                filesProcessed++;
                currentFileName = fileFields[i].getFile().getName();

                if (fileFields[i].getFile().getName().toLowerCase().endsWith("jpg") || fileFields[i].getFile().getName().toLowerCase().endsWith("jpeg") || fileFields[i].getFile().getName().toLowerCase().endsWith("png")) {

                        File f = resizer.getScaledImageFile(fileFields[i].getFile(), fileFields[i].getUploadDirectory(), maxWidth, maxHeight, ((float)compressionQuality/100), imageInterpolation);
                        fileFields[i].setFile(new File(f.getAbsolutePath()));
                }
        }

                return !abort;
        }

        /**
         * Creates the fileinfo. The fileinfo is xml that contains information about the files, for example
         * the localpath, datemodified and the md5 hash.
         *
         * @param uploadFileInfo A comma separated string with parameters e.g. 1,2,3
         *                       1 = md5, 2 = LastModified, 3 = localpath
         * @return false if the user has aborted.
         */
        private boolean createFileInfo(String uploadFileInfo) {

                init();

                // show only a message in the progress dialog when a checksum must be created
                // this can take some time
                if (uploadFileInfo.indexOf("1") != -1) {
                        processMessage = localeManager.getString("checksum") + "....";
                }

                FileInfoManager fileInfoManager = new FileInfoManager(this, uploadFileInfo);
                String fileInfo = fileInfoManager.createFileInfo(data.getFormFileFields());

                //user has aborted
                if (fileInfo == null) {
                        return false;
                } else {
                        FormInputField inputField = new FormInputField("fileinfo", fileInfo);
                        data.addFormInputField(inputField);

                        return true;
                }
        }

        /**
         * This method will be invoked by the FileInfoManager. The method is called
         * when a new file will be processed. This method is necessary for updating
         * the progress dialog.
         *
         * @param file The file currently processing.
         * @param index The index of the file in the sum of all files.
         * @param size The total of all files.
         * @return false if the user has aborted.
         */
        public boolean processingFileInfo(File file, int index, int size) {

                filesProcessed = index + 1;
        currentFileName = file.getName();
        bytesProcessed += file.length();

        if (abort) {
                return false;
        } else {
                return true;
        }
        }

        /**
         * Add the bytes who are processed.
         *
         * @param bytes The bytes processed.
         */
        public void addBytesProcessed (int bytes) {
                bytesProcessed += bytes;
        }

        /**
         * Returns the custom error message.
         *
         * @return the custom error message.
         */
        public String getErrorMessage() {
                return errorMessage;
        }
}
