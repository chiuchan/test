/*
 * Copyright 2006-2009 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader;

import java.awt.Component;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DropTargetDragEvent;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.dnd.DropTargetEvent;
import java.awt.dnd.DropTargetListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.io.File;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Vector;

import javaatwork.myuploader.dialog.FileFilterException;
import javaatwork.myuploader.dialog.UploadFileFilter;
import javaatwork.myuploader.dialog.UploadRejectFileFilter;
import javaatwork.myuploader.domain.FormFileField;
import javaatwork.myuploader.icons.DownIcon;
import javaatwork.myuploader.icons.UpIcon;
import javaatwork.myuploader.net.ContentTypeMapper;
import javaatwork.myuploader.utils.ByteFormatter;
import javaatwork.myuploader.utils.LocaleManager;
import javaatwork.myuploader.utils.Logger;
import javaatwork.myuploader.utils.Parameters;

import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.JTable;
import javax.swing.ToolTipManager;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

/**
 * Class for showing the files in a table.
 *
 * @author Johannes Postma
 */
public class FileTable extends JTable implements MouseMotionListener {

        /**
         * serialVersionUID
         */
        private static final long serialVersionUID = -7046734930044670655L;

        private boolean sortOnFile = true;
        private boolean sortDown = true;
        private LocaleManager localeManager = null;
        private UploadApplet uploadApplet = null;
        private Vector files = new Vector();
        private FileTableModel model = new FileTableModel(files);
        private JMenuItem itemPaste = null;
        private JPopupMenu popup = new JPopupMenu();
        private UploadRejectFileFilter rejectFileFilter = null;

        /**
         * Creates a new FileTable.
         *
         * @param uploadApplet The applet.
         */
        public FileTable(UploadApplet uploadApplet) {

                this.uploadApplet = uploadApplet;
                localeManager = LocaleManager.getInstance();

                // check if the rejected filefilter must be created
                String rejectedExtensions = Parameters.getParameter(Parameters.REJECT_FILEFILTER, "");

                if (rejectedExtensions != null && !rejectedExtensions.trim().equalsIgnoreCase("")) {
                        try {
                                rejectFileFilter = new UploadRejectFileFilter(rejectedExtensions);
                        } catch (FileFilterException e) {
                                Logger.log("FileTable", "FileTable()", e.getMessage());
                        }
                }

                // sets the table properties
                DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();

                // determine the columnames
                String columnNames[] = new String[3];
                columnNames[0] = localeManager.getString("nr") + ".";
                columnNames[1] = localeManager.getString("file");
                columnNames[2] = localeManager.getString("size");

                model.setColumnNames(columnNames);
                setModel(model);

                // create popup
                itemPaste = new JMenuItem(localeManager.getString("paste"));
                popup.add(itemPaste);
                add(popup);

                rightRenderer.setHorizontalAlignment(JLabel.RIGHT);

                getTableHeader().addMouseListener(new TableMouseAdapter());

                //	don't move the columns
                getTableHeader().setReorderingAllowed(false);

                getColumnModel().getColumn(0).setCellRenderer(rightRenderer);
                getColumnModel().getColumn(2).setCellRenderer(rightRenderer);
                getColumnModel().getColumn(0).setMaxWidth(38);
                getColumnModel().getColumn(0).setMinWidth(38);

                if (Parameters.getParameter(Parameters.SHOW_TOOLTIP, true)) {
                        getColumnModel().getColumn(1).setCellRenderer(new ToolTipRenderer());
                }

                // A custom header renderer doesn't work with the Windows or Nimbus
                // look-and-feel. Therefore with these look-and-feels no up or down
                // icon will be displayed.
                if (uploadApplet.getLaf() == UploadApplet.METAL_LOOK_AND_FEEL) {
                        getColumnModel().getColumn(2).setHeaderRenderer(new TableHeaderRenderer());
                        getColumnModel().getColumn(1).setHeaderRenderer(new TableHeaderRenderer());
                }

                packColumn(2, 5);

                // add the mouselistener needed to show the popup
                // if the tablemodel is full
                addMouseListener(new MouseAdapter() {
                        public void mousePressed(MouseEvent e) {
                                maybeShowPopup(e);
                        }

                        public void mouseReleased(MouseEvent e) {
                                maybeShowPopup(e);
                        }
                });

                //	 add the actionlistener needed for the paste
                itemPaste.addActionListener(new ActionListener() {

                        public void actionPerformed(ActionEvent e) {
                                 Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
                         Transferable content = clipboard.getContents(this);
                 DataFlavor[] flavors = content.getTransferDataFlavors();
                 paste(flavors, content);
                        }
                });

                this.addMouseMotionListener(this);
        }

        /**
         * Paste the files of the clipboard to the table.
         *
         * @param flavors The DataFlavor [].
         * @param transferable The transferable.
         */
        public void paste(DataFlavor[] flavors, Transferable transferable) {

                for (int i = 0; i < flavors.length; i++)   {
                        DataFlavor dataFlavor = flavors[i];

                        try  {
                                if (dataFlavor.equals(DataFlavor.javaFileListFlavor)) {
                                        List fileList = (List) transferable.getTransferData(dataFlavor);
                                        File [] file = (File[])fileList.toArray(new File[fileList.size()]);
                                        addFiles(file);
                                        uploadApplet.updateSummary();
                                        break;
                                } else if (dataFlavor.isMimeTypeEqual("text/uri-list")) { // this mime-type is used in Linux GNOME, KDE is not supported
                                        Object object = transferable.getTransferData(dataFlavor);

                                        if (object instanceof java.lang.String) {
                                                String fileList = (String)object;
                                                String fileNames [] = fileList.split("\r\n");
                                                File file [] = new File[fileNames.length];

                                                for (int j = 0; j < fileNames.length; j++) {

                                                        String fileName = new java.net.URL(fileNames[j]).getFile();
                                                        String decFileName = URLDecoder.decode(fileName, "UTF-8");
                                                        file[j] = new File(decFileName);
                                                }

                                                addFiles(file);
                                                uploadApplet.updateSummary();
                                                break;
                                        }
                                }

                        } catch(Exception e)  {
                                Logger.log("FileTable", "paste()", e.getMessage());
                        }
                }
        }

        /**
         * Returns a list of allowed files. The rules are
         * described in the filefilter
         * With drag and drop all kind of files could be added to the list
         * if the param fileFilter exists and disableDefaultFileFilter is true only
         * files of the fileFilter could be added to the list.
         *
         * @param files The unallowed files.
         * @return The array of allowed files.
         */
        private File[] getFilteredFiles(File [] files) {

                try {
                        boolean disable = Parameters.getParameter(Parameters.DISABLE_DEFAULT_FILEFILTER, false);
                        String fileFilter = Parameters.getParameter(Parameters.FILEFILTER, "");

                        if (disable && fileFilter !=null) {

                                List fileList = new ArrayList();

                                UploadFileFilter filter = new UploadFileFilter(fileFilter);

                                for (int j = 0; j < files.length; j++) {

                                        if (filter.accept(files[j])) {
                                                fileList.add(files[j]);
                                        }
                                }

                                // return the changed array of files
                                File [] file = (File[])fileList.toArray(new File[fileList.size()]);

                                return file;
                        }
                } catch (FileFilterException ffe) {
                        Logger.log("FileTable", "getFilteredFiles()", ffe.toString());
                }

                // nothing is changed return the original array of files
                return files;
        }

        /**
         * Sort the files.
         *
         * @param tableColumn The tablecolumn.
         * @param down Ascending.
         */
        public void sort(final int tableColumn, final boolean down) {

                Collections.sort(files, new Comparator() {

                        public int compare(Object arg0, Object arg1) {
                                FormFileField fileField1 = (FormFileField)arg0;
                                FormFileField fileField2 = (FormFileField)arg1;

                                if (tableColumn == 1) {
                                        if (down) {
                                                return (fileField1.getUploadName().toLowerCase().compareTo(fileField2.getUploadName().toLowerCase()));
                                        } else {
                                                return (fileField2.getUploadName().toLowerCase().compareTo(fileField1.getUploadName().toLowerCase()));
                                        }
                                } else {
                                        if (down) {
                                                if (fileField1.getFile().length() > fileField2.getFile().length()) {
                                                        return 1;
                                                } else if (fileField1.getFile().length() < fileField2.getFile().length()) {
                                                        return -1;
                                                } else {
                                                        return (fileField1.getUploadName().toLowerCase().compareTo(fileField2.getUploadName().toLowerCase()));
                                                }
                                        } else {
                                                if (fileField1.getFile().length() > fileField2.getFile().length()) {
                                                        return -1;
                                                } else if (fileField1.getFile().length() < fileField2.getFile().length()) {
                                                        return 1;
                                                } else {
                                                        return (fileField1.getUploadName().toLowerCase().compareTo(fileField2.getUploadName().toLowerCase()));
                                                }
                                        }
                                }
                        }

                });
        }

        /**
         * Deletes the selected files of the table.
         */
        public void deleteFiles() {
                if (!getSelectionModel().isSelectionEmpty()) {
                        int[] rows = getSelectedRows();

                        for (int i = rows.length; i > 0; i--) {
                                files.removeElementAt(rows[i - 1]);
                        }

                        //if (Parameters.getParameter(Parameters.COLDFUSION, false)) {
                                changeNames();
                        //}

                        model.fireTableDataChanged();

                        // the table header must be updated to remove the down/upicon
                        // in case of 1 files or 0 files
                        updateTableHeader();

                        packColumn(2, 5);
                }
        }

        /**
         * Deletes all files in the table.
         */
        public void deleteAllFiles() {

                files.removeAllElements();
                model.fireTableDataChanged();

                // the table header must be updated to remove the down/upicon
                // in case of 1 files or 0 files
                updateTableHeader();

                packColumn(2, 5);
        }

        /**
         * Add a directory to the internal collection.
         *
         * @param formFileField The FormFileField
         */
        public void addDirectory(FormFileField formFileField) {

                ContentTypeMapper contentTypeMapper = ContentTypeMapper.getInstance();

                // retrieve the allowed files
                File [] list = getFilteredFiles(formFileField.getFile().listFiles());

                for (int i = 0; i < list.length; i++) {

                        if (list[i].isDirectory()) {
                                FormFileField fileField = new FormFileField("userfile", list[i], formFileField.getUploadDirectory() + list[i].getName() + "/", contentTypeMapper.getContentType(list[i]));
                                addDirectory(fileField);
                        } else {
                                FormFileField fileField = new FormFileField("userfile", list[i], formFileField.getUploadDirectory(), contentTypeMapper.getContentType(list[i]));
                                addFile(fileField);
                        }
                }
        }


        /**
         * Add a file to the internal collection.
         *
         * @param fileField The FormFileField.
         */
        public void addFile(FormFileField fileField) {

                //	 check if file already exists
                String absolutePath = fileField.getFile().getAbsolutePath();

                boolean found = false;

                for (int j = 0; j < files.size(); j++) {
                        FormFileField formFileField = (FormFileField)files.elementAt(j);

                        if (formFileField.getFile().getAbsolutePath().equalsIgnoreCase(absolutePath)) {
                                found = true;
                                break;
                        }
                }

                if (!found) {

                        // check if the extension must not be rejected
                        if (rejectFileFilter != null) {
                                if (!rejectFileFilter.rejectFile(fileField.getFile())) {
                                        files.add(fileField);
                                }
                        } else {
                                files.add(fileField);
                        }
                }
        }

        /**
         * Add a list of files to the internal collection.
         * The internal collection is the list to be uploaded.
         *
         * @param list The files to be added.
         */
        public void addFiles (File [] list) {

                ContentTypeMapper contentTypeMapper = ContentTypeMapper.getInstance();

                // retrieve the allowed files
                File [] file = getFilteredFiles(list);

                for (int i = 0; i < file.length; i++) {

                        // ensure that no directories are dropped
                        if (file[i].isDirectory()) {

                                if (Parameters.getParameter(Parameters.UPLOAD_DIRECTORIES, true)) {
                                        FormFileField formFileField = new FormFileField("userfile", file[i], file[i].getName() + "/", contentTypeMapper.getContentType(file[i]));
                                        addDirectory(formFileField);
                                }

                        } else {
                                FormFileField formFileField = new FormFileField("userfile", file[i], "", contentTypeMapper.getContentType(file[i]));
                                addFile(formFileField);
                        }
                }

                sort(1, true);

                //if (Parameters.getParameter(Parameters.COLDFUSION, false)) {
                        changeNames();
                //}

                // update the table
                model.fireTableDataChanged();

                sortDown = true;
                sortOnFile = true;

                // the table header must be updated to remove the down/upicon
                // in case of 1 files or 0 files
                updateTableHeader();
        }

        /**
         * Change the form names of the files to be uploaded. The first form name
         * is f1 the second f2 and so an.
         */
        public void changeNames() {

                for (int i = 0; i < files.size(); i++) {
                        FormFileField fileField = (FormFileField)files.elementAt(i);
                        fileField.setName("file_" + (i + 1));
                }
        }

        /**
         * The to be uploaded files.
         *
         * @return The files to be uploaded.
         */
        public FormFileField [] getFormFileFields() {

                // clone the formfilefields
                // when the resized images are created the formfilefield will be updated
                // in case of a cancel during the upload the resized images will be resized
                // again when no clone will be used
                Vector clone = new Vector();

                // clone
                for (int i = 0; i < files.size(); i++) {
                        FormFileField fileField = (FormFileField)files.elementAt(i);
                        FormFileField clonedFileField = new FormFileField(new String(fileField.getName()), new File(fileField.getFile().getPath()), new String(fileField.getUploadDirectory()), new String(fileField.getContentType()));
                        clone.add(clonedFileField);
                }

                return (FormFileField [])clone.toArray(new FormFileField[clone.size()]);
        }

        /**
         * Returns the number of files.
         *
         * @return The number of files.
         */
        public int getNumberOfFiles() {
                return files.size();
        }

        /**
         * Shows the popup.
         *
         * @param e The MouseEvent.
         */
        public void maybeShowPopup(MouseEvent e) {
                if (e.isPopupTrigger()) {
                        popup.show(e.getComponent(), e.getX(), e.getY());
                }
        }

        /**
         * Class for encapsulating the mouse events. This class is needed
         * for the sort of the table.
         */
        class TableMouseAdapter extends MouseAdapter {

                public void mouseReleased(MouseEvent me) {

                        int clickCount = me.getClickCount();

                        if(clickCount == 1) {

                                // determine the column
                                int tableColumn = columnAtPoint(me.getPoint());

                                if (tableColumn == 1) {
                                        if (sortOnFile == true) {
                                                if (sortDown == true) {
                                                        sort(tableColumn, false);
                                                        model.fireTableDataChanged();
                                                        sortDown = false;
                                                } else {
                                                        sort(tableColumn, true);
                                                        model.fireTableDataChanged();
                                                        sortDown = true;
                                                }
                                        } else {
                                                sort(tableColumn, true);
                                                model.fireTableDataChanged();
                                                sortDown = true;
                                                sortOnFile = true;
                                        }
                                } else if (tableColumn == 2) {
                                        if (sortOnFile == true) {
                                                sort(tableColumn, true);
                                                model.fireTableDataChanged();
                                                sortDown = true;
                                                sortOnFile = false;
                                        } else {
                                                if (sortDown == true) {
                                                        sort(tableColumn, false);
                                                        model.fireTableDataChanged();
                                                        sortDown = false;
                                                } else {
                                                        sort(tableColumn, true);
                                                        model.fireTableDataChanged();
                                                        sortDown = true;
                                                }
                                        }

                                        packColumn(2, 5);
                                }
                                getTableHeader().repaint();
                        }
                }
        }

        /**
         * Renderer for showing a tooltip on a cell of the JTable.
         * The tooltip will be shown in the cell of the filename.
         */
        public class ToolTipRenderer extends DefaultTableCellRenderer {

                private SimpleDateFormat formatter = new SimpleDateFormat();

                private static final long serialVersionUID = 7934892888279120680L;

                /*
                 * (non-Javadoc)
                 * @see javax.swing.table.DefaultTableCellRenderer#getTableCellRendererComponent(javax.swing.JTable, java.lang.Object, boolean, boolean, int, int)
                 */
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int rowIndex, int colIndex) {

                super.getTableCellRendererComponent(table, value, isSelected, hasFocus, rowIndex, colIndex);

                FormFileField uploadFile = (FormFileField)files.elementAt(rowIndex);

                StringBuffer buffer = new StringBuffer();
                buffer.append("<html>");
                buffer.append(uploadFile.getFile().getName());
                buffer.append("<br>");
                buffer.append(LocaleManager.getInstance().getString("size"));
                buffer.append(": ");
                buffer.append(ByteFormatter.format(uploadFile.getFile().length()));
                buffer.append("<br>");
                buffer.append(LocaleManager.getInstance().getString("last_modified"));
                buffer.append(" ");
                buffer.append(formatter.format(new Date(uploadFile.getFile().lastModified())));

                setToolTipText(buffer.toString());

                return this;
        }
        }

        /**
         * Class for showing a table header.
         */
        class TableHeaderRenderer extends DefaultTableCellRenderer implements TableCellRenderer {


                private static final long serialVersionUID = -4402478739497433510L;

                // This method is called each time a column header
        // using this renderer needs to be rendered.
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int rowIndex, int colIndex) {

                // Inherit the colors and font from the header component
            if (table != null) {
                JTableHeader header = table.getTableHeader();

                if (header != null) {
                   setForeground(header.getForeground());
                   setBackground(header.getBackground());
                   setFont(header.getFont());
                }
            }

            if (colIndex == 1) {
                    setText(localeManager.getString("file") + " ");
            } else {
                    setText(localeManager.getString("size") + " ");
            }

            if (files.size() > 1) { // was 0
                if (colIndex == 1) {
                        if (sortOnFile == true) {
                                if (sortDown) {
                                        setIcon(new DownIcon());
                                } else {
                                        setIcon(new UpIcon());
                                }
                        } else {
                                setIcon(null);
                        }
                } else {

                        if (sortOnFile == false) {
                                if (sortDown) {
                                        setIcon(new DownIcon());
                                } else {
                                        setIcon(new UpIcon());
                                }
                        } else {
                                setIcon(null);
                        }
                }
            } else {
                    setIcon(null); // toegevoegd
            }

            setBorder(UIManager.getBorder("TableHeader.cellBorder"));
            setHorizontalAlignment(JLabel.CENTER);
            setHorizontalTextPosition(JLabel.LEFT);

            return this;
        }
    }

        /**
         * Class needed for drag and drop.
         */
        class FileDropTargetListener implements DropTargetListener {

                /* (non-Javadoc)
                 * @see java.awt.dnd.DropTargetListener#dragEnter(java.awt.dnd.DropTargetDragEvent)
                 */
                public void dragEnter(DropTargetDragEvent event) {

                        event.acceptDrag (DnDConstants.ACTION_COPY);
                }

                /* (non-Javadoc)
                 * @see java.awt.dnd.DropTargetListener#dragOver(java.awt.dnd.DropTargetDragEvent)
                 */
                public void dragOver(DropTargetDragEvent event) {

                        event.acceptDrag(DnDConstants.ACTION_COPY);
                }

                /* (non-Javadoc)
                 * @see java.awt.dnd.DropTargetListener#dropActionChanged(java.awt.dnd.DropTargetDragEvent)
                 */
                public void dropActionChanged(DropTargetDragEvent event) {}

                /* (non-Javadoc)
                 * @see java.awt.dnd.DropTargetListener#dragExit(java.awt.dnd.DropTargetEvent)
                 */
                public void dragExit(DropTargetEvent event) {}

                /* (non-Javadoc)
                 * @see java.awt.dnd.DropTargetListener#drop(java.awt.dnd.DropTargetDropEvent)
                 */
                public void drop(DropTargetDropEvent event) {

                        if ((event.getSourceActions() & DnDConstants.ACTION_COPY) != 0) {
                                event.acceptDrop(DnDConstants.ACTION_COPY);
                        } else {
                                event.rejectDrop();
                                return;
                        }

                        Transferable transferable = event.getTransferable();
                        DataFlavor[] flavors = event.getCurrentDataFlavors();
                        paste(flavors, transferable);
                        event.dropComplete(true);
                }
        }

        /**
         * Updates the table header. This is need to remove the up or down button
         * in case the applet contains no files or 1 file. The icon are only
         * visible with the Metal look-and-feel. With the Windows or Nimbus look-and-feel
         * no custom HeaderRenderer can be created.
         */
        public void updateTableHeader(){

                if (uploadApplet.getLaf() == UploadApplet.METAL_LOOK_AND_FEEL) {
                        getTableHeader().updateUI();
                }
        }

        /*
         * (non-Javadoc)
         * @see java.awt.event.MouseMotionListener#mouseDragged(java.awt.event.MouseEvent)
         */
        public void mouseDragged(MouseEvent e) {
        }

        /*
         * (non-Javadoc)
         * @see java.awt.event.MouseMotionListener#mouseMoved(java.awt.event.MouseEvent)
         */
        public void mouseMoved(MouseEvent e) {
                ToolTipManager.sharedInstance().setEnabled(true);
        }

        /**
         * Sets the size of the column based on the contents of the cells.
         *
         * @param colIndex The column.
         * @param margin The margin.
         */
        public void packColumn(int colIndex, int margin) {

        TableColumn col = getColumnModel().getColumn(colIndex);

        // Get width of column header
        TableCellRenderer renderer = col.getHeaderRenderer();

        if (renderer == null) {
            renderer = getTableHeader().getDefaultRenderer();
        }

        Component comp = renderer.getTableCellRendererComponent(this, col.getHeaderValue(), false, false, 0, 0);

        int width = comp.getPreferredSize().width;

        // Get maximum width of column data
        for (int i = 0; i < getRowCount(); i++) {
            renderer = getCellRenderer(i, colIndex);

            comp = renderer.getTableCellRendererComponent(this, getValueAt(i, colIndex), false, false, i, colIndex);
            width = Math.max(width, comp.getPreferredSize().width);
        }

        // Add margin
        width += 2 * margin;

        // minimum column width
        if (colIndex == 2 && width < 80) {
                width = 80;
        }

        col.setMaxWidth(width);
                col.setMinWidth(width);
        }
}
