/*
 * Copyright 2005-2008 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.icons;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;

import javax.swing.Icon;
import javax.swing.SwingConstants;

/**
 * Class for creating a down-arrow-icon.
 * 
 * @author Johannes Postma
 */
public class DownIcon implements Icon, SwingConstants {
  
	private int width = 11;
    private int height = 5;

    private int[] xPoints = new int[3];
    private int[] yPoints = new int[3];

    /**
     * Constructs a new DownIcon.
     */
    public DownIcon() {
        
            xPoints[0] = 1;
            yPoints[0] = 0;
            
            xPoints[1] = width/2;
            yPoints[1] = height;
            
            xPoints[2] = width-1;
            yPoints[2] = 0;
    }

    /**
     * Gets the height of the icon.
     *
     * @return The height in pixels of this icon
     */
    public int getIconHeight() {
        return height;
    }

    /**
     * Gets the width of the icon.
     *
     * @return The width in pixels of this icon
     */
    public int getIconWidth() {
    	return width;
    }

    /**
     * Paints the icon.
     * The top-left corner of the icon is drawn at 
     * the point (<code>x</code>, <code>y</code>)
     * in the coordinate space of the graphics context <code>g</code>.
     * If this icon has no image observer,
     * this method uses the <code>c</code> component
     * as the observer.
     *
     * @param c the component to be used as the observer
     *          if this icon has no image observer
     * @param g the graphics context 
     * @param x the X coordinate of the icon's top-left corner
     * @param y the Y coordinate of the icon's top-left corner
     */
     public void paintIcon(Component c, Graphics g, int x, int y) {
        int length = xPoints.length;
        int adjustedXPoints[] = new int[length];
        int adjustedYPoints[] = new int[length];

        for (int i = 0; i < length; i++) {
            adjustedXPoints[i] = xPoints[i] + x;
            adjustedYPoints[i] = yPoints[i] + y;
        }

        g.setColor(Color.gray);
        g.fillPolygon(adjustedXPoints, adjustedYPoints, length);
    }
}
