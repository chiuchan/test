/*
 * Copyright 2006-2009 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.utils;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.PixelGrabber;
import java.io.File;
import java.io.IOException;

import javaatwork.myuploader.net.HTTPUploadTask;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.swing.ImageIcon;

/**
 * Class who is responsible for creating a scaled instance in a 
 * temp directory. The temp directory is the System property
 * "java.io.tmpdir".
 * 
 * @author Johannes Postma
 */
public class ResizeManager {

	private File tempDirectory = null;
	private HTTPUploadTask task = null;
	
	/**
	 * Creates a new Resizer.
	 * 
	 * @throws Exception If an error occurred.
	 */
	public ResizeManager(HTTPUploadTask task) throws Exception {
		this.task = task;
		createTempDirectory();
	}
	
	/**
	 * Creates the temp directory.
	 * 
	 * @throws Exception If the temp directory cannot be created.
	 */
	private void createTempDirectory() throws Exception {
		
		File dir = new File(System.getProperty("java.io.tmpdir"));
		tempDirectory = new File(dir, "myuploader-" + System.currentTimeMillis());
		
		if (tempDirectory.exists()) {
			return;
		}
		
		boolean created = tempDirectory.mkdir();
		
		if (created == false) {
			throw new Exception ("Temp directory could not be created");
		}
	}
	
	/**
	 * Deletes the temp directory.
	 */
	public void deleteTempDirectory() {
		deleteDirectory(tempDirectory);
	}
	
	/**
	 * Deletes a directory with all the files and subdirectories.
	 * 
	 * @param file The directory.
	 */
	private void deleteDirectory(File file) {
		
		File [] files = file.listFiles();
		
		for (int i = 0; i < files.length; i++) {
			
			if (files[i].isDirectory()) {
				deleteDirectory(files[i]);				
			} else {
				files[i].delete();
			}
		}
		
		file.delete();
	}
	
	/**
	 * Returns a File of a scaled image.
	 * 
	 * @param file The file of the original image.
	 * @param uploadPath
	 * @param maxWidth The maximum width of the scaled instance.
	 * @param maxHeight The maximum height of the scaled instance.
	 * @param compressionQuality The compression quality for storing jpg files. The compression quality is a float between 0 and 1.
	 * @param imageInterpolation The applet parameter 'imageInterpolation'.	Possible values are:<br>
	 *                           1 awt (default, more sharp than 3 and more smooth than 5, requires low memory, slow)<br>
	 *                           2 one-step bilinear (poor quality, requires more memory than 1, very fast)<br>
	 *                           3 multiple-step bilinear (smooth images, requires more memory than 1, 2 and 4)<br>
	 *                           4 one step bicubic (poor quality, requires more memory than 1, very fast)<br>
	 *                           5 multiple-step bicubic (sharp images, requires more memory than 1, 2 and 4)<br>
	 * @return The File of the resized image.
	 * @throws IOException Thrown if the resized image cannot be saved.
	 */
	public File getScaledImageFile(File file, String uploadPath, int maxWidth, int maxHeight, float compressionQuality, int imageInterpolation) throws IOException {
	
		// needed for the progressbar
		int fileSize = (int)file.length();
		int partOne = fileSize / 3;
		int partTwo = partOne;
		int partThree = fileSize - partOne - partTwo;
	
		int imageType = -1;
		Image image = null;
		
		// read the image
		try {
			image = ImageIO.read(file);
			
			if (image instanceof BufferedImage) {
				imageType = ((BufferedImage)image).getType();
			} else {
				imageType = hasAlpha(image) ? BufferedImage.TYPE_4BYTE_ABGR : BufferedImage.TYPE_3BYTE_BGR;
			}
			
			// with some images and especially on the MAC a OutOfMemoryError can occur with the method 
			// ImageIO.read(), in that case try to read with an alternative method the image: new ImageIcon
			// With this last method an Image is created in stead of a BufferedImage, and therefore the
			// image typ cannot be directly be determined. A solution is to check it with the hasAlpha().
		} catch (OutOfMemoryError oome) {
			
			image = new ImageIcon(file.getPath()).getImage();
			imageType = hasAlpha(image) ? BufferedImage.TYPE_4BYTE_ABGR : BufferedImage.TYPE_3BYTE_BGR;
		}
			
		// png images have a type BufferedImage.TYPE_CUSTOM, the build image resize functionality cannot handle
		// this type, and there the type must be changed.
		if (imageType == BufferedImage.TYPE_CUSTOM) {
			imageType = BufferedImage.TYPE_4BYTE_ABGR;
		}
		
		// needed for the progressbar
		task.addBytesProcessed(partOne);

		// scale file
		int thumbHeight = 0;
		int thumbWidth = 0;
		
		int imageWidth = image.getWidth(null);
		int imageHeight = image.getHeight(null);
		double imageRatio = (double) imageWidth / (double) imageHeight;
		
		if (imageWidth > imageHeight){
			if (maxWidth != -1) {
				thumbWidth = maxWidth;
				thumbHeight = (int)(maxWidth / imageRatio);
			} else {
				thumbHeight = maxHeight;
				thumbWidth = (int)(maxHeight * imageRatio);
			}
		} else {
			if (maxHeight != -1) {
				thumbHeight = maxHeight;
				thumbWidth = (int)(maxHeight * imageRatio);
			} else {
				thumbWidth = maxWidth;
				thumbHeight = (int)(maxWidth / imageRatio);
			}
		}

		// check if the new size is not larger than the original one.
		if (thumbWidth > imageWidth) {
			thumbWidth = imageWidth;
			thumbHeight = imageHeight;
		}
		
		BufferedImage bImage = null;
		
		if (imageInterpolation == 1) {
			bImage = getScaledAWTInstance(image, thumbWidth, thumbHeight, imageType);	  
		} else if (imageInterpolation == 2) {
			bImage = getScaledInstance(image, thumbWidth, thumbHeight, RenderingHints.VALUE_INTERPOLATION_BILINEAR, false, imageType);
		} else if (imageInterpolation == 3) {
			bImage = getScaledInstance(image, thumbWidth, thumbHeight, RenderingHints.VALUE_INTERPOLATION_BILINEAR, true, imageType);
		} else if (imageInterpolation == 4) {
			bImage = getScaledInstance(image, thumbWidth, thumbHeight, RenderingHints.VALUE_INTERPOLATION_BICUBIC, false, imageType);
		} else if (imageInterpolation == 5) {
			bImage = getScaledInstance(image, thumbWidth, thumbHeight, RenderingHints.VALUE_INTERPOLATION_BICUBIC, true, imageType);
		} 
		
		// needed for the progressbar
		task.addBytesProcessed(partTwo);
		
		// store file
		File scaledInstance = writeImage(bImage, uploadPath, file.getName(), compressionQuality);
		
		// needed for the progressbar
		task.addBytesProcessed(partThree);

		return scaledInstance;
	}
	
	/**
	 * Creates a scaled image base on AWT and the RenderingHint Image.SCALE_SMOOTH;
	 * 
	 * @param image The original image.
	 * @param width The width of the scaled image.
	 * @param height The height of the scaled image.
	 * @param type The image type.
	 * @return The scaled image.
	 */
	private BufferedImage getScaledAWTInstance(Image image, int width, int height, int type) {
		
		Image imag = image.getScaledInstance(width, height, Image.SCALE_SMOOTH);
		
		BufferedImage bi = toBufferedImage(imag, type);
		BufferedImage bImage = new BufferedImage(width, height, type);
		Graphics g = bImage.getGraphics();
		g.drawImage(bi, 0, 0, null);
	    g.dispose();
	    
	    return bImage;
	}
		
	/**
	 * Creates a scaled instance.
	 * 
	 * @param img The original image.
	 * @param targetWidth The width of the scaled instance.
	 * @param targetHeight The height of the scaled instance.
	 * @param hint The RenderingHint.
	 * @param higherQuality If true intermediate images are in memory created for a higher quality. The scaling algorithm will use
	 *                      multiple steps.
	 * @param type The image type.                     
	 * @return BufferedImage
	 */
	private  BufferedImage getScaledInstance(Image img, int targetWidth, int targetHeight, Object hint, boolean higherQuality, int type) {
		
		boolean firstTime = true;

		BufferedImage ret = null;
		int width = 0;
		int height = 0;
		
		if (higherQuality) {
		
			// Use multi-step technique: start with original size, then
			// scale down in multiple passes with drawImage()
			// until the target size is reached
			width = img.getWidth(null);
			height = img.getHeight(null);
		} else {
			
			// Use one-step technique: scale directly from original
			// size to target size with a single drawImage() call
			width = targetWidth;
			height = targetHeight;
		}

		do {
			if (higherQuality && width > targetWidth) {
				width /= 2;
				if (width < targetWidth) {
					width = targetWidth;
				}
			}

			if (higherQuality && height > targetHeight) {
				height /= 2;
				if (height < targetHeight) {
					height = targetHeight;
				}
			}
			
			BufferedImage tmp = new BufferedImage(width, height, type);
			Graphics2D g2 = tmp.createGraphics();
			g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, hint);
			
			if (firstTime) {
				g2.drawImage(img, 0, 0, width, height, null);
			} else {
				g2.drawImage(ret, 0, 0, width, height, null);
			}
			g2.dispose();
			
			ret = tmp;
			
			firstTime = false;
			
		} while (width != targetWidth || height != targetHeight);

		return ret;
	}
	
	/**
	 * Stores a resized image.
	 * 
	 * @param image The BufferedImage to be saved.
	 * @param uploadPath Additional folders.
	 * @param fileName The name of the BufferedImage.
	 * @param compressionQuality The jpg compression quality.
	 * @return The file of the stored resized image.
	 * @throws IOException If the image couldn't be saved.
	 */
	private File writeImage(BufferedImage image, String uploadPath, String fileName, float compressionQuality) throws IOException {
		
		ImageWriter writer = null;
		
		File scaledInstance = new File(tempDirectory, uploadPath);
		scaledInstance.mkdirs();
		scaledInstance = new File(scaledInstance, fileName);
		
		if (fileName.toLowerCase().endsWith("png")) {
			writer = (ImageWriter) ImageIO.getImageWritersByFormatName("PNG").next();
			writer.setOutput(ImageIO.createImageOutputStream(scaledInstance));
			writer.write(null, new IIOImage(image, null, null), null);				
		} else {
			writer = (ImageWriter) ImageIO.getImageWritersByFormatName("JPEG").next();
			ImageWriteParam param = writer.getDefaultWriteParam();
		    param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
		    param.setCompressionQuality(compressionQuality);
		    writer.setOutput(ImageIO.createImageOutputStream(scaledInstance));
	    	writer.write(null, new IIOImage(image, null, null), param);
		}
		
		return scaledInstance;
	}

	/**
	 * Converts an java.awt.Image to a BufferedImage.
	 * 
	 * @param image The java.awt.Image.
	 * @param type The image type.
	 * @return The BufferedImage.
	 */
	public BufferedImage toBufferedImage(Image image, int type) {
        
		// important otherwise the line when the buffered image is created will generate an error
		image = new ImageIcon(image).getImage();
	    
	    BufferedImage bufferedImage = new BufferedImage(image.getWidth(null), image.getHeight(null), type);
        Graphics g = bufferedImage.createGraphics();
        g.drawImage(image, 0, 0, null);
        g.dispose();        
        
        return bufferedImage;
    }
	

	/**
	 * Checks if the image is transparent.
	 * 
	 * @param image The image.
	 * @return True if the image is transparent.
	 */
	public boolean hasAlpha(Image image) {
        
		// If BufferedImage, the color model is already available
        if (image instanceof BufferedImage) {
            BufferedImage bimage = (BufferedImage)image;
            return bimage.getColorModel().hasAlpha();
        }
    
        // Use a pixel grabber to retrieve the image's color model;
        // grabbing a single pixel is usually sufficient
        PixelGrabber pixelGrabber = new PixelGrabber(image, 0, 0, 1, 1, false);
        
        try {
        	pixelGrabber.grabPixels();
        } catch (InterruptedException e) {
        	// do nothing
        }
    
        // Get the image's color model
        ColorModel colorModel = pixelGrabber.getColorModel();
        
        return colorModel.hasAlpha();
    }
}
