/*
 * Copyright 2005-2008 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.StringTokenizer;

import javaatwork.myuploader.domain.FormFileField;
import javaatwork.myuploader.net.HTTPUploadTask;

/**
 * Class for returning the FileInfo. FileInfo is an XML String of data about the uploaded files.
 * See for an example the Java source code. 
 * 
 * @author Johannes Postma
 */
public class FileInfoManager {

	// Example of the FileInfo
	/*
	   <FileInfo>
    	<File>
        	<Name><![CDATA[folder%2Ftest.txt]]></Name>                       // urlencoded name, this field will be used as the key in the server code
        	<MD5>683f7548052375929176fed651b389d4</MD5>                      // the md5 hash of the file, this field is optional
        	<LastModified>2008-12-10T21:40:22.000+00:00</LastModified>       // the date when the file is last modified, format: ISO8601, this field is optional
        	<Path><![CDATA[/home/johannes/tmp/folder/test1.txt]]></Path>     // the local path on the computer, this field is optional
   		</File>
    	<File>
        	<Name><![CDATA[test.txt]]></Name>
        	<MD5>d8e8fca2dc0f896fd7cb4cb0031ba249</MD5>
        	<LastModified>2008-09-27T07:35:14.000+00:00</LastModified>
        	<Path><![CDATA[/home/johannes/tmp/test.txt]]></Path>
    	</File>
	   </FileInfo>
	 */
	
	
    private static final String NEWLINE = "\r\n";

    private static final String TAB = "    ";

    private static SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");

    private HTTPUploadTask uploadTask = null;
    
    private boolean uploadLastModified = false;
    private boolean uploadMD5 = false;
    private boolean uploadLocalPath = false;
    
    /**
     * Creates a new FileInfoManager.
     * 
     * @param uploadTask The HTTPUploadTask
     * @param uploadFileInfo The value of the fileinfo applet parameter.
     */
    public FileInfoManager(HTTPUploadTask uploadTask, String uploadFileInfo) {
    	this.uploadTask = uploadTask;
    	
    	StringTokenizer tokens = new StringTokenizer(uploadFileInfo, ",");
    	
    	while (tokens.hasMoreTokens()) {
    		String token = tokens.nextToken();
    		
    		if (token.equals("1")) {
    			uploadMD5 = true;
    		}
    		
    		if (token.equals("2")) {
    			uploadLastModified = true;
    		} 
    		
    		if (token.equals("3")) {
    			uploadLocalPath = true;
    		}
    	}
    }

    /**
     * Creates the FileInfo. The FileInfo is an XML string that returns information
     * of the uploaded files.
     * 
     * @param fileFields The files to be uploaded. 
     * @return The XML FileInfo.
     */
    public String createFileInfo(FormFileField [] fileFields) {

    	boolean abort = false;
    	
        StringBuffer buf = new StringBuffer("<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>");
        buf.append(NEWLINE);
        buf.append("<FileInfo>");
        buf.append(NEWLINE);

        for (int i = 0; i < fileFields.length && !abort; i++) {
        	
        	abort = !uploadTask.processingFileInfo(fileFields[i].getFile(), i, fileFields.length);
        	
            buf.append(TAB);
            buf.append("<File>");
            buf.append(NEWLINE);

            // add name
            buf.append(TAB);
            buf.append(TAB);
            buf.append("<Name><![CDATA[");
            buf.append(fileFields[i].getURLEncodedUploadName());
            buf.append("]]></Name>");
            buf.append(NEWLINE);

            // add md5
            if (uploadMD5) {
	            buf.append(TAB);
	            buf.append(TAB);
	            buf.append("<MD5>");
	            buf.append(calculateMD5(fileFields[i].getFile()));
	            buf.append("</MD5>");
	            buf.append(NEWLINE);
            }
            
         // add modified
            if (uploadLastModified) {
	            buf.append(TAB);
	            buf.append(TAB);
	            buf.append("<LastModified>");
	            String date = formatter.format(new Date(fileFields[i].getFile().lastModified()));
	            String iso8601Date = date.substring(0, 26) + ":" + date.substring(26);
	            buf.append(iso8601Date);
	            buf.append("</LastModified>");
	            buf.append(NEWLINE);
            }
            
            // add path
            if (uploadLocalPath) {

	            buf.append(TAB);
	            buf.append(TAB);
	            buf.append("<Path><![CDATA[");
	            buf.append(fileFields[i].getFile().getPath());
	            buf.append("]]></Path>");
	            buf.append(NEWLINE);
            }
            
            buf.append(TAB);
            buf.append("</File>");
            buf.append(NEWLINE);
        }

        buf.append("</FileInfo>");

        if (abort) {
        	return null;
        }
        
        return buf.toString();
    }

    /**
     * Returns the MD5 hash of a file in hexadecimal. If the MD5 hash cannot be calculated
     * an empty String is returned.
     *  
     * @param file The file.
     * @return The MD5 hash.
     */
    public String calculateMD5(File file) {

        try {
            MessageDigest md5 = MessageDigest.getInstance("MD5");

            InputStream is = new FileInputStream(file);
            byte[] buffer = new byte[8192];
            int read = 0;

            while ((read = is.read(buffer)) > 0) {
                md5.update(buffer, 0, read);
            }

            return toHexString(md5.digest());

        } catch (Exception e) {
           // do nothing
        }

        return "";
    }

    /**
     * Formats a byte array to a hexidecimal string.
     * 
     * @param bytes The byte array.
     * @return A hexidecimal string.
     */
    public static String toHexString(byte bytes[]) {
    	
		StringBuffer retString = new StringBuffer();
		
		for (int i = 0; i < bytes.length; ++i)
		{
			retString.append(Integer.toHexString(0x0100 + (bytes[i] & 0x00FF)).substring(1));
		}
		
		return retString.toString();
	}
}




