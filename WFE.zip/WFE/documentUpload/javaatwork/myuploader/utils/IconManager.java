/*
 * Copyright 2006-2008 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.utils;

import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.ImageIcon;

/**
 * Class for creating an ImageIcon.
 * 
 * @author Johannes Postma
 */
public class IconManager {

	/**
	 * Creates a new ImageIcon.
	 * 
	 * @param value The name of the icon.
	 * @param codeBase The codebase of the applet.
	 * @return The ImageIcon.
	 */
	public synchronized static ImageIcon getImageIcon(String value, URL codeBase) {
		
		if (value == null) {
			return null;
		}
		
		URL iconURL = null;
		
		try {
			if (!value.startsWith("http")) {
				iconURL = new URL(codeBase, value);
			} else {
				iconURL = new URL(value);
			}
			
		} catch (MalformedURLException e) {
			Logger.log("IconManager", "getImageIcon()", "Incorrect URL format: " + value + " " + e.toString());
		}
		
		return iconURL == null ? null : new ImageIcon(iconURL);
	}
}
