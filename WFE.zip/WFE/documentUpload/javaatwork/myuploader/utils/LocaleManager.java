/*
 * Copyright 2006-2008 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.utils;

import java.util.Locale;
import java.util.ResourceBundle;

import javax.swing.JComponent;
import javax.swing.UIManager;

import javaatwork.myuploader.utils.Parameters;

/**
 * This class is responsible for retrieving the locale parameters
 * of the html page for a particular Applet.
 * 
 * @author Johannes Postma
 */
public class LocaleManager {

	private ResourceBundle labels = null;
	private String dialogTitle = null;
	private static LocaleManager manager = null;	
	
	/**
	 * Constructs a new LocaleManager
	 */
	private LocaleManager() {
		
		String language = Parameters.getParameter(Parameters.LANGUAGE, "en");
		
		if (language != null) {
			if (language.equalsIgnoreCase("da")) {
				Locale.setDefault(new Locale("da", "DK"));
				labels = ResourceBundle.getBundle("javaatwork.myuploader.language.LabelsBundle");
				
				try {
					dialogTitle = labels.getString("myDialogTitle");
					initJFileChooser();
				} catch (Exception ex) {
					Logger.log("LocaleManager", "LocaleManager()", "Using default properties file: English.");
				}
							
			} else if (language.equalsIgnoreCase("is")) {
				Locale.setDefault(new Locale("is", "IS"));
				labels = ResourceBundle.getBundle("javaatwork.myuploader.language.LabelsBundle");
				
				try {
					dialogTitle = labels.getString("myDialogTitle");
					initJFileChooser();
				} catch (Exception ex) {
					Logger.log("LocaleManager", "LocaleManager()", "Using default properties file: English.");
				}
			} else if (language.equalsIgnoreCase("ja")) {
				Locale.setDefault(new Locale("ja", "JP"));
				labels = ResourceBundle.getBundle("javaatwork.myuploader.language.LabelsBundle");
				
				try {
					dialogTitle = labels.getString("myDialogTitle");
					initJFileChooser();
				} catch (Exception ex) {
					Logger.log("LocaleManager", "LocaleManager()", "Using default properties file: English.");
				}
				
			} else if (language.equalsIgnoreCase("el")) {
				Locale.setDefault(new Locale("el", "GR"));
				labels = ResourceBundle.getBundle("javaatwork.myuploader.language.LabelsBundle");
				
				try {
					dialogTitle = labels.getString("myDialogTitle");
					initJFileChooser();
				} catch (Exception ex) {
					Logger.log("LocaleManager", "LocaleManager()", "Using default properties file: English.");
				}
				
			} else if (language.equalsIgnoreCase("zh_CN")) {
				Locale.setDefault(new Locale("zh", "CN"));
				labels = ResourceBundle.getBundle("javaatwork.myuploader.language.LabelsBundle");
				
				try {
					dialogTitle = labels.getString("myDialogTitle");
					initJFileChooser();
				} catch (Exception ex) {
					Logger.log("LocaleManager", "LocaleManager()", "Using default properties file: English.");
				}
				
			} else if (language.equalsIgnoreCase("zh_TW")) {
				Locale.setDefault(new Locale("zh", "TW"));
				labels = ResourceBundle.getBundle("javaatwork.myuploader.language.LabelsBundle");
				
				try {
					dialogTitle = labels.getString("myDialogTitle");
					initJFileChooser();
				} catch (Exception ex) {
					Logger.log("LocaleManager", "LocaleManager()", "Using default properties file: English.");
				}
				
			} else if (language.equalsIgnoreCase("nl")) {
				Locale.setDefault(new Locale("nl", "NL"));
				labels = ResourceBundle.getBundle("javaatwork.myuploader.language.LabelsBundle");
				
				try {
					dialogTitle = labels.getString("myDialogTitle");
					initJFileChooser();
				} catch (Exception ex) {
					Logger.log("LocaleManager", "LocaleManager()", "Using default properties file: English.");
				}
				
			} else if (language.equalsIgnoreCase("ko")) {
				Locale.setDefault(new Locale("ko", "KR"));
				labels = ResourceBundle.getBundle("javaatwork.myuploader.language.LabelsBundle");
				
				try {
					dialogTitle = labels.getString("myDialogTitle");
					initJFileChooser();
				} catch (Exception ex) {
					Logger.log("LocaleManager", "LocaleManager()", "Using default properties file: English.");
				}
				
			} else if (language.equalsIgnoreCase("tr")) {
				Locale.setDefault(new Locale("tr", "TR"));
				labels = ResourceBundle.getBundle("javaatwork.myuploader.language.LabelsBundle");
				
				try {
					dialogTitle = labels.getString("myDialogTitle");
					initJFileChooser();
				} catch (Exception ex) {
					Logger.log("LocaleManager", "LocaleManager()", "Using default properties file: English.");
				}
				
			} else if (language.equalsIgnoreCase("fi")) {
				Locale.setDefault(new Locale("fi", "FI"));
				labels = ResourceBundle.getBundle("javaatwork.myuploader.language.LabelsBundle");
				
				try {
					dialogTitle = labels.getString("myDialogTitle");
					initJFileChooser();
				} catch (Exception ex) {
					Logger.log("LocaleManager", "LocaleManager()", "Using default properties file: English.");
				}
				
			} else if (language.equalsIgnoreCase("cz")) {
				Locale.setDefault(new Locale("cz", "CZ"));
				labels = ResourceBundle.getBundle("javaatwork.myuploader.language.LabelsBundle");
				
				try {
					dialogTitle = labels.getString("myDialogTitle");
					initJFileChooser();
				} catch (Exception ex) {
					Logger.log("LocaleManager", "LocaleManager()", "Using default properties file: English.");
				}
				
			} else if (language.equalsIgnoreCase("no")) {
				Locale.setDefault(new Locale("no", "NO"));
				labels = ResourceBundle.getBundle("javaatwork.myuploader.language.LabelsBundle");
				
				try {
					dialogTitle = labels.getString("myDialogTitle");
					initJFileChooser();
				} catch (Exception ex) {
					Logger.log("LocaleManager", "LocaleManager()", "Using default properties file: English.");
				}
				
			} else if (language.equalsIgnoreCase("sv")) {
				Locale.setDefault(new Locale("sv", "SE"));
				labels = ResourceBundle.getBundle("javaatwork.myuploader.language.LabelsBundle");
				
				try {
					dialogTitle = labels.getString("myDialogTitle");
					initJFileChooser();
				} catch (Exception ex) {
					Logger.log("LocaleManager", "LocaleManager()", "Using default properties file: English.");
				}
				
			} else if (language.equalsIgnoreCase("es")) {
				Locale.setDefault(new Locale("es", "ES"));
				labels = ResourceBundle.getBundle("javaatwork.myuploader.language.LabelsBundle");
				
				try {
					dialogTitle = labels.getString("myDialogTitle");
					initJFileChooser();
				} catch (Exception ex) {
					Logger.log("LocaleManager", "LocaleManager()", "Using default properties file: English.");
				}
				
			} else if (language.equalsIgnoreCase("pt")) {
				Locale.setDefault(new Locale("pt", "PT"));
				labels = ResourceBundle.getBundle("javaatwork.myuploader.language.LabelsBundle");
				
				try {
					dialogTitle = labels.getString("myDialogTitle");
					initJFileChooser();
				} catch (Exception ex) {
					Logger.log("LocaleManager", "LocaleManager()", "Using default properties file: English.");
				}
				
			} else if (language.equalsIgnoreCase("pl")) {
				Locale.setDefault(new Locale("pl", "PL"));
				labels = ResourceBundle.getBundle("javaatwork.myuploader.language.LabelsBundle");
				
				try {
					dialogTitle = labels.getString("myDialogTitle");
					initJFileChooser();
				} catch (Exception ex) {
					Logger.log("LocaleManager", "LocaleManager()", "Using default properties file: English.");
				}
				
			} else if (language.equalsIgnoreCase("en")) {
				Locale.setDefault(new Locale("en", "US"));
				JComponent.setDefaultLocale(Locale.ENGLISH);
				labels = ResourceBundle.getBundle("javaatwork.myuploader.language.LabelsBundle");
				UIManager.put("FileChooser.acceptAllFileFilterText", "All files");
			} else if (language.equalsIgnoreCase("it")) {
				Locale.setDefault(new Locale("it", "IT"));
				JComponent.setDefaultLocale(Locale.ITALIAN);
				labels = ResourceBundle.getBundle("javaatwork.myuploader.language.LabelsBundle");
				UIManager.put("FileChooser.acceptAllFileFilterText", "Tutti i file");
			} else if (language.equalsIgnoreCase("de")) {
				Locale.setDefault(new Locale("de", "DE"));
				JComponent.setDefaultLocale(Locale.GERMAN);
				labels = ResourceBundle.getBundle("javaatwork.myuploader.language.LabelsBundle");
				UIManager.put("FileChooser.acceptAllFileFilterText", "Alle Dateien");
			} else if (language.equalsIgnoreCase("fr")) {
				Locale.setDefault(new Locale("fr", "FR"));
				JComponent.setDefaultLocale(Locale.FRENCH);
				labels = ResourceBundle.getBundle("javaatwork.myuploader.language.LabelsBundle"); 
				UIManager.put("FileChooser.acceptAllFileFilterText", "Tous les fichiers");
			} else {
				labels = ResourceBundle.getBundle("javaatwork.myuploader.language.LabelsBundle");
				UIManager.put("FileChooser.acceptAllFileFilterText", "All files");
			}
		} else {
			labels = ResourceBundle.getBundle("javaatwork.myuploader.language.LabelsBundle");
			UIManager.put("FileChooser.acceptAllFileFilterText", "All files");
		}
	}
	
	/**
	 * Determines the locale name for the JFileChooser.
	 */
	public void initJFileChooser() {
		
		UIManager.put("FileChooser.lookInLabelText", labels.getString("lookInLabelText"));
		UIManager.put("FileChooser.filesOfTypeLabelText", labels.getString("filesOfTypeLabelText"));
		UIManager.put("FileChooser.upFolderToolTipText", labels.getString("upFolderToolTipText"));
		UIManager.put("FileChooser.fileNameLabelText", labels.getString("fileNameLabelText"));
		UIManager.put("FileChooser.homeFolderToolTipText", labels.getString("homeFolderToolTipText"));

		UIManager.put("FileChooser.newFolderToolTipText", labels.getString("newFolderToolTipText"));
		UIManager.put("FileChooser.listViewButtonToolTipText", labels.getString("listViewButtonToolTipText"));
		UIManager.put("FileChooser.detailsViewButtonToolTipText", labels.getString("detailsViewButtonToolTipText"));
		UIManager.put("FileChooser.saveButtonText", labels.getString("saveButtonText"));
		UIManager.put("FileChooser.openButtonText", labels.getString("openButtonText"));

		UIManager.put("FileChooser.cancelButtonText", labels.getString("cancelButtonText"));
		UIManager.put("FileChooser.updateButtonText", labels.getString("updateButtonText"));
		UIManager.put("FileChooser.helpButtonText", labels.getString("updateButtonText"));
		UIManager.put("FileChooser.saveButtonToolTipText", labels.getString("saveButtonToolTipText"));
		UIManager.put("FileChooser.openButtonToolTipText", labels.getString("openButtonToolTipText"));

		UIManager.put("FileChooser.cancelButtonToolTipText", labels.getString("cancelButtonToolTipText"));
		UIManager.put("FileChooser.updateButtonToolTipText", labels.getString("updateButtonToolTipText"));
		UIManager.put("FileChooser.helpButtonToolTipText", labels.getString("helpButtonToolTipText"));
		UIManager.put("FileChooser.myDialogTitle", labels.getString("myDialogTitle"));	
		UIManager.put("FileChooser.acceptAllFileFilterText", labels.getString("defaultFileFilterText"));
		
		UIManager.put("FileChooser.viewMenuLabelText", labels.getString("viewMenuLabelText"));
		UIManager.put("FileChooser.refreshActionLabelText", labels.getString("refreshActionLabelText"));
		UIManager.put("FileChooser.newFolderActionLabelText", labels.getString("newFolderActionLabelText"));
		UIManager.put("FileChooser.listViewActionLabelText", labels.getString("listViewActionLabelText"));
		UIManager.put("FileChooser.detailsViewActionLabelText", labels.getString("detailsViewActionLabelText"));
		
		UIManager.put("FileChooser.fileDateHeaderText", labels.getString("fileDateHeaderText"));
		UIManager.put("FileChooser.fileNameHeaderText", labels.getString("fileNameHeaderText"));
		UIManager.put("FileChooser.fileSizeHeaderText", labels.getString("fileSizeHeaderText"));
		UIManager.put("FileChooser.fileAttrHeaderText", labels.getString("fileAttrHeaderText"));
		
		
	}
	
	/**
	 * Returns the unique instance of the LocaleManager.
	 * 
	 * @return LocaleManager
	 */
	public static LocaleManager getInstance() {
		
	//	if (manager == null) {
			
		//	synchronized (LocaleManager.class) {
			//	if (manager == null) {
					manager = new LocaleManager();
			//	}
			//}
	//	}
		
		return manager;
	}
	
	/**
	 * Returns a String from a resourcebundle.
	 * 
	 * @param key The Key.
	 * @return The String from a resourcebundle.
	 */
	public String getString(String key) {
		return labels.getString(key);
	}
	
	/**
	 * Returns the dialogtitle of JFileChooser.
	 * 
	 * @return The dialogtitle of JFileChooser.
	 */
	public String getDialogTitle() {
		return dialogTitle;
	}
}
