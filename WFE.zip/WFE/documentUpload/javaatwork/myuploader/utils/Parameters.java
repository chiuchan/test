/*
 * Copyright 2006-2009 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.utils;

import java.applet.Applet;
import java.util.HashMap;

/**
 * Class for retrieving the applet parameters.
 * 
 * @author Johannes Postma
 */
public class Parameters {

	public final static String BACKGROUND_COLOR = "backgroundColor";
	public final static String CHARSET_FOR_URLENCODING = "charsetForURLEncoding";
	public final static String COLDFUSION = "coldfusion";
	public final static String COMPRESSION_QUALITY = "compressionQuality";
	public final static String COOKIE = "cookie";	
	public final static String CURRENT_DIRECTORY = "currentDirectory";
	public final static String DIRECTORY = "directory";
	public final static String DISABLE_DEFAULT_FILEFILTER = "disableDefaultFileFilter";
	public final static String FILEFILTER = "fileFilter";
	public final static String FORM = "form";
	public final static String FORM_NAME = "formName";
	public final static String ICON_ADD = "iconAdd";
	public final static String ICON_REMOVE = "iconDelete";
	public final static String ICON_UPLOAD = "iconUpload";
	public final static String IMAGE_INTERPOLATION = "imageInterpolation";
	public final static String LANGUAGE = "language";
	public final static String LOG_COOKIES = "logCookies";
	public final static String LOOK_AND_FEEL = "lookAndFeel";
	public final static String MAX_FILE_SIZE = "maxFileSize";
	public final static String MAX_BYTE_SIZE = "maxByteSize";
	public final static String MAX_IMAGE_HEIGHT = "maxImageHeight";
	public final static String MAX_IMAGE_SIZE = "maxImageSize";
	public final static String MAX_IMAGE_WIDTH = "maxImageWidth";	
	public final static String POST_PARAMETERS = "postParameters";
	public final static String REJECT_FILEFILTER = "rejectFileFilter";
	public final static String SHOW_CUSTOM_ERROR_MESSAGES = "showCustomErrorMessages";
	public final static String SHOW_HIDDEN_FILES_IN_FILEDIALOG = "showHiddenFilesInFileDialog";
	public final static String SHOW_HTTP_RESPONSE = "showHTTPResponse";
	public final static String SHOW_THUMBNAILS_IN_FILEDIALOG = "showThumbNailsInFileDialog";
	public final static String SHOW_THUMBNAILS_IN_APPLET = "showThumbNailsInApplet";
	public final static String SHOW_TOOLTIP = "showToolTip";
	public final static String SUCCESS_URL = "successURL";
	public final static String TARGET = "target";
	public final static String UPLOAD_DIRECTORIES = "uploadDirectories";
	public final static String UPLOAD_FILE_INFO = "uploadFileInfo";
	public final static String UPLOAD_URL = "uploadURL";
	public final static String USE_FULL_URL = "useFullURL";
	public final static String ZIP_FILE = "zipFile";
	
	private static HashMap parameters = null;

	/**
	 * Loads all parameters of an applet.
	 * 
	 * @param applet The applet.
	 */
	public static void loadParameters(Applet applet) {

		parameters = new HashMap();
		loadParameter(applet, Parameters.BACKGROUND_COLOR);
		loadParameter(applet, Parameters.CHARSET_FOR_URLENCODING);
		loadParameter(applet, Parameters.COLDFUSION);
		loadParameter(applet, Parameters.COOKIE);		
		loadParameter(applet, Parameters.COMPRESSION_QUALITY);
		loadParameter(applet, Parameters.CURRENT_DIRECTORY);
		loadParameter(applet, Parameters.DIRECTORY);
		loadParameter(applet, Parameters.DISABLE_DEFAULT_FILEFILTER);
		loadParameter(applet, Parameters.FILEFILTER);
		loadParameter(applet, Parameters.FORM);
		loadParameter(applet, Parameters.FORM_NAME);
		loadParameter(applet, Parameters.ICON_ADD);
		loadParameter(applet, Parameters.ICON_REMOVE);
		loadParameter(applet, Parameters.ICON_UPLOAD);
		loadParameter(applet, Parameters.IMAGE_INTERPOLATION);
		loadParameter(applet, Parameters.LANGUAGE);
		loadParameter(applet, Parameters.LOG_COOKIES);
		loadParameter(applet, Parameters.LOOK_AND_FEEL);
		loadParameter(applet, Parameters.MAX_FILE_SIZE);
		loadParameter(applet, Parameters.MAX_BYTE_SIZE);
		loadParameter(applet, Parameters.MAX_IMAGE_HEIGHT);
		loadParameter(applet, Parameters.MAX_IMAGE_SIZE);
		loadParameter(applet, Parameters.MAX_IMAGE_WIDTH);
		loadParameter(applet, Parameters.POST_PARAMETERS);
		loadParameter(applet, Parameters.REJECT_FILEFILTER);
		loadParameter(applet, Parameters.SHOW_CUSTOM_ERROR_MESSAGES);
		loadParameter(applet, Parameters.SHOW_HIDDEN_FILES_IN_FILEDIALOG);
		loadParameter(applet, Parameters.SHOW_HTTP_RESPONSE);
		loadParameter(applet, Parameters.SHOW_THUMBNAILS_IN_FILEDIALOG);
		loadParameter(applet, Parameters.SHOW_THUMBNAILS_IN_APPLET);
		loadParameter(applet, Parameters.SHOW_TOOLTIP);
		loadParameter(applet, Parameters.SUCCESS_URL);
		loadParameter(applet, Parameters.TARGET);
		loadParameter(applet, Parameters.UPLOAD_DIRECTORIES);
		loadParameter(applet, Parameters.UPLOAD_FILE_INFO);
		loadParameter(applet, Parameters.UPLOAD_URL);
		loadParameter(applet, Parameters.USE_FULL_URL);
		loadParameter(applet, Parameters.ZIP_FILE);
	}

	/**
	 * Load a parameter from an applet tag.
	 * 
	 * @param applet The applet.
	 * @param parameter The name of the parameter.
	 */
	private static void loadParameter(Applet applet, String parameter) {

		try {
			parameters.put(parameter, applet.getParameter(parameter));

			// occurs in case of a stand alone application
		} catch (NullPointerException npe) {
			parameters.put(parameter, null);
		}
	}

	/**
	 * Returns the value of an applet parameter.
	 * 
	 * @param name The name of the variable.
	 * @param defaultValue The default value.
	 * @return The String value
	 */
	public static synchronized String getParameter(Object name, String defaultValue) {
		Object value = parameters.get(name);
		return value == null ? defaultValue : value.toString();
	}

	/**
	 * Returns the value of an applet parameter.
	 * 
	 * @param name The name of the variable.
	 * @param defaultValue The default value.
	 * @return The boolean value
	 */
	public static synchronized boolean getParameter(Object name, boolean defaultValue) {
		String param = Parameters.getParameter(name, Boolean.toString(defaultValue));
		return Boolean.valueOf(param).booleanValue();
	}

	/**
	 * Returns the value of an applet parameter.
	 * 
	 * @param name The name of the variable.
	 * @param defaultValue The default value.
	 * @return The int value
	 */
	public static synchronized int getParameter(Object name, int defaultValue) {
		
		String param = Parameters.getParameter(name, Integer.toString(defaultValue));
		int intParam = 0;
		
		try {
			intParam = Integer.parseInt(param);
		} catch (NumberFormatException nfe) {
			Logger.log("Parameters", "getParameter(name, int)",  "incorrect " + name + " format: " + param);
		}
		
		return intParam;
	}
	
	/**
	 * Returns the value of an applet parameter.
	 * 
	 * @param name The name of the variable.
	 * @param defaultValue The default value.
	 * @return The double value
	 */
	public static synchronized double getParameter(Object name, double defaultValue) {
		
		String param = Parameters.getParameter(name, Double.toString(defaultValue));
		double doubleParam = 0.0;
		
		try {
			doubleParam = Double.parseDouble(param);
		} catch (NumberFormatException nfe) {
			Logger.log("Parameters", "getParameter(name, double)",  "incorrect " + name + " format: " + param);
		}
		
		return doubleParam;
	}
}
