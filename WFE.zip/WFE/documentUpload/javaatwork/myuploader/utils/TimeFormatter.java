/*
 * Copyright 2006-2008 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.utils;

/**
 * Class for formatting a time in milli seconds.
 * 
 * @author Johannes Postma
 */
public class TimeFormatter {

	/**
	 * Formats a time in the format hh:mm:ss.
	 * 
	 * @param timeInMilliseconds The time in milliseconds.
	 * @return The formatted time.
	 */
	public static String getFormattedTime(int timeInMilliseconds) {

		int totalSeconds = timeInMilliseconds / 1000;

		if (timeInMilliseconds % 1000 > 0) {
			totalSeconds = totalSeconds + 1;
		}

		int seconds = totalSeconds % 60;
		int minutes = (totalSeconds / 60) % 60;
		int hours = totalSeconds / 3600;

		String stringHours = String.valueOf(hours);

		if (stringHours.length() == 1) {
			stringHours = "0" + stringHours;
		}

		String stringMinutes = String.valueOf(minutes);

		if (stringMinutes.length() == 1) {
			stringMinutes = "0" + stringMinutes;
		}

		String stringSeconds = String.valueOf(seconds);

		if (stringSeconds.length() == 1) {
			stringSeconds = "0" + stringSeconds;
		}

		return stringHours + ":" + stringMinutes + ":" + stringSeconds;
	}
}
