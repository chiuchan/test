/*
 * Copyright 2005-2009 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.utils;

import java.text.DecimalFormat;

/**
 * Class for formatting bytes to a String representation (b, Kb, Mb).
 * 
 * @author Johannes Postma
 */
public class ByteFormatter {

	private static DecimalFormat formatter = new DecimalFormat("#.00");

	/** 
	 * Formats bytes in a String representation in b, Kb, Mb or Gb.
	 * When the format is MB or Gb the format has two decimals. 
	 * 
	 * @param bytes The bytes.
	 * @return The String representation.
	 */
	public static String format(long bytes) {

		// bytes
		if (bytes < 1024) {
			return Long.toString(bytes) + " bytes ";
		}

		// kilo bytes
		else if (bytes < (1024 * 1024)) {
			double bytesSent = bytes / 1024.0;
			return Math.round(bytesSent) + " KB ";
		}

		// mega bytes
		else if (bytes < (1024 * 1024 * 1024)) {

			double bytesSent = bytes / (1024.0 * 1024.0);
			return formatter.format(bytesSent) + " MB ";
		}

		// giga bytes
		else {
			double bytesSent = bytes / (1024.0 * 1024.0 * 1024.0);
			return formatter.format(bytesSent) + " GB ";
		}
	}
	
	/**
	 * Formats bytes in a String representation in Kb. 
	 * 
	 * @param bytes The bytes.
	 * @return The String representation.
	 */
	public static String formatToKiloBytes(int bytes) {
		double bytesSent = bytes / 1024.0;
		
		if (bytesSent == 0) {
			return "0 KB";
		} else if (bytesSent < 1.0) {
			return "1 KB";
		} else {
			return Long.toString(Math.round(bytesSent)) + " KB";
		}
	}
}