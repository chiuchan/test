/*
 * Copyright 2007-2008 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.utils;

import java.lang.reflect.Method;
import java.net.URL;
import java.util.StringTokenizer;

/**
 * Class for storing and retrieving browser cookies.
 * 
 * @author Johannes Postma
 */
public class CookieManager {

	/**
	 * Returns the cookie information.This method is based on best effort because the method doesn't
	 * work in all browsers, e.g. Opera.
	 * 
	 * @param codebase The url.
	 * @return List of all defined cookies.
	 */
	public static String getCookieInfo(URL codebase) {

		String cookies = null;
		
		// retrieve the cookies
		// cookies will be retrieve by the use of the java plugin
		// unfortunately this doesn't work in Opera.
		// For Opera the Javascript solution will work.
		String cookieHandler = null;
		
		String javaSpecificationVersion = System.getProperty("java.specification.version");
			
		// the cookies of version 1.6 cannot be retrieved dynamically
		if (javaSpecificationVersion.equals("1.4") || javaSpecificationVersion.equals("1.5")) {
			if (javaSpecificationVersion.equalsIgnoreCase("1.4")) {
				cookieHandler = "sun.plugin.net.cookie.PluginCookieManager";
			} else {
				cookieHandler = "com.sun.deploy.net.cookie.DeployCookieManager";
			}
			
			try {
				Class clss = Class.forName(cookieHandler);
				Class[] parameterTypes = new Class[] {URL.class};
				Method meth = clss.getMethod("getCookieInfo", parameterTypes);	
				Object[] arguments = new Object[] {codebase};
				cookies = (String)meth.invoke(clss.newInstance(), arguments);
			} catch (Throwable t) {
				// be sure that no runtime error will occur
				// if for some reason the ClassLoader cannot find the class he will search on the server
				// if the server respond with a 302 Found (redirect) in stead of a 402 Not found a runtime error
				// can occur.
				// in Opera the classes cannot be found an exception will be thrown.
			}
		}
		
		if (cookies != null && !cookies.trim().equalsIgnoreCase("")) {
			
			if (Parameters.getParameter(Parameters.LOG_COOKIES, false)) {
				Logger.log("CookieManager", "getCookieInfo()", "CookieInfo: " + cookies);
			}			
			
			return cookies;
		}
		
		// cookies cannot be retrieve by the use of the java plugin 
		else {
			cookies = Parameters.getParameter(Parameters.COOKIE, null);
			
			if (cookies != null) {
				
				if (Parameters.getParameter(Parameters.LOG_COOKIES, false)) {
					Logger.log("CookieManager", "getCookieInfo()", "CookieInfo: " + cookies);
				}
				
				return cookies;
			}
			
			return null;
		}
	}
	
	/**
	 * Sets a cookie. This method is based on best effort because the method doesn't
	 * work in all browsers, e.g. Opera.
	 * 
	 * @param codebase The url.
	 * @param cookieInfo The cookie e.g. "name=value;expires=Sunday, 08-Jul-07 23:59:00 GMT"
	 */
	public static void setCookie(URL codebase, String cookieInfo) {
		
		// retrieve the cookies
		// cookies will be retrieve by the use of the java plugin
		// unfortunately this doesn't work in Opera.
		// For Opera the Javascript solution will work.
		String cookieHandler = null;
		
		String javaSpecificationVersion = System.getProperty("java.specification.version");
		
		// cookies of JRE version 1.6 cannot be set
		if (javaSpecificationVersion.equals("1.4") || javaSpecificationVersion.equals("1.5")) {
		
			if (System.getProperty("java.specification.version").equalsIgnoreCase("1.4")) {
				cookieHandler = "sun.plugin.net.cookie.PluginCookieManager";
			} else {
				cookieHandler = "com.sun.deploy.net.cookie.DeployCookieManager";
			}
			
			try {
				Class clss = Class.forName(cookieHandler);
				Class[] parameterTypes = new Class[] {URL.class, String.class};
				Method meth = clss.getMethod("setCookieInfo", parameterTypes);	
				Object[] arguments = new Object[] {codebase, cookieInfo};
				meth.invoke(clss.newInstance(), arguments);
			} catch (Throwable t) {			
				// be sure that no runtime error will occur
				// if for some reason the ClassLoader cannot find the class he will search on the server
				// if the server respond with a 302 Found (redirect) in stead of a 402 Not found a runtime error
				// can occur.
				// in Opera the classes cannot be found an exception will be thrown.
			}
		}
	}
	
	/**
	 * Returns the value of a specific cookie. This method is based on best effort because the method doesn't
	 * work in all browsers, e.g. Opera.
	 * 
	 * @param codebase The url.
	 * @param name The name of the cookie
	 * @return The value or null in case the cookie doesn't exists.
	 */
	public static String getCookieValue(URL codebase, String name) {
		
		String cookieInfo = CookieManager.getCookieInfo(codebase);
		
		if (cookieInfo == null || cookieInfo.equals("")) {
			return null;
		}
		
		StringTokenizer tokenizer = new StringTokenizer(cookieInfo, ";");
		
		while (tokenizer.hasMoreElements()) {
			String token = tokenizer.nextToken().trim();
			
			if (token.startsWith(name + "=")) {
				return token.substring((name + "=").length());
			}
		}
		
		return null;
	}
}
