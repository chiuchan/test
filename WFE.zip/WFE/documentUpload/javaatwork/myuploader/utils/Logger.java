/*
 * Copyright 2006-2008 JavaAtWork B.V. All rights reserved.
 * Use is subject to license terms.
 */
package javaatwork.myuploader.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * A logger class.
 * 
 * @author Johannes Postma
 */
public class Logger {

	private static DateFormat formatter = SimpleDateFormat.getDateTimeInstance();
	
	/**
	 * Logs a message.
	 * 
	 * @param clss The class.
	 * @param method The method.
	 * @param message The message to be logged.
	 */
	public static synchronized void log(String clss, String method, String message) {
		System.out.println(formatter.format(new Date()) + " - " + clss + " - " + method + " - " + message);		
	}

}
