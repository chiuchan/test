// For non SVG browsers
svgeezy.init('nocheck', 'png');


 //disable the backspace and enter keys
if (typeof window.event != 'undefined')
    document.onkeydown = function()
    {
        if (event.srcElement.tagName.toUpperCase() != 'INPUT' && 
            event.srcElement.tagName.toUpperCase() != 'TEXTAREA' )
        {
            return (event.keyCode != 8 && event.keyCode != 13);
        }
        else
            return (event.keyCode != 13);
    }
else
    document.onkeypress = function(e)
    {
        if (e.target.nodeName.toUpperCase() != 'INPUT' && 
            e.target.nodeName.toUpperCase() != 'TEXTAREA' )
        {
            return (e.keyCode != 8 && e.keyCode != 13);
        }
        else
            return (e.keyCode != 13);
   }

function isAlien(a) { return isObject(a) && typeof a.constructor != 'function'; }
function isArray(a) { return isObject(a) && a.constructor == Array; }
function isBoolean(a) { return typeof a == 'boolean'; }
function isEmpty(o) {
    var i, v;
    if (isObject(o)) {
        for (i in o) {
            v = o[i];
            if (isUndefined(v) && isFunction(v)) { return false; }
        }
    }
    return true;
}
function isFunction(a) { return typeof a == 'function';}
function isNull(a) { return typeof a == 'object' && !a;}
function isNumber(a) { return typeof a == 'number' && isFinite(a);}
function isObject(a) { return (a && typeof a == 'object') || isFunction(a);}
function isString(a) { return typeof a == 'string';}
function isUndefined(a) { return typeof a == 'undefined'; } 

var isIE5Mac = (navigator.userAgent.indexOf('MSIE 5') != -1	&&	navigator.userAgent.indexOf('Mac') != -1);
var W3CDOM = (!isIE5Mac && 	document.getElementsByTagName && document.createElement);
var DHTML = (document.getElementById || document.all || document.layers);

function IsValidDate(fld)
{
    var theMonth = fld.value.substring(0, 2);
    var theDay = fld.value.substring(3, 5);
    var theYear = fld.value.substring(fld.value.length - 4, fld.value.length);

    var dt = new Date(fld.value);

    if(dt.getDate() != theDay){
        alert('Invalid Day');
        return(false);
        }
    else if(dt.getMonth() != theMonth - 1){
    //this is for the purpose JavaScript starts the month from 0
        alert('Invalid Month');
        return(false);
        }
    else if(dt.getFullYear() != theYear){
        alert('Invalid Year');
        return(false);
        }
    
    return(true);
 }

function isNumeric(fld, e) {     
    var key = '';
    var strCheck = '0123456789';
    
    // set whichCode to code of key pressed (key code)
    var whichCode = e.which;
    if(whichCode == null || whichCode.length == 0)
        whichCode = e.keyCode;
    
    // Enter, backspace and arrow keys are OK
    if (whichCode == 13 || whichCode == 8 || 
        whichCode == 0)
        return true;  

    // Get key value from key code (sets 'key' to character rep'd by key code)
    key = String.fromCharCode(whichCode);  

    if ((strCheck.indexOf(key) == -1)) 
    {
        // Not a valid key
        alert('Use numbers only.');
        fld.focus();
        return false;
    }

    return true;
}

function isCurrency(fld, e) {     
    var key = '';
    var strCheck = '0123456789.';
    
    // set whichCode to code of key pressed (key code)
    var whichCode = e.which;
    if(whichCode == null || whichCode.length == 0)
        whichCode = e.keyCode;
    
    // Enter, backspace and arrow keys are OK
    if (whichCode == 13 || whichCode == 8 || 
        whichCode == 0) 
        return true;  

    // Get key value from key code (sets 'key' to character rep'd by key code)
    key = String.fromCharCode(whichCode);  

    if ((strCheck.indexOf(key) == -1)) 
    {
        // Not a valid key
        alert('Use numbers only.');
        fld.focus();
        return false;
    }

    return true;
}

function verifyCurrency(field)
{ 
    var amount = field.value;

    //look for more than 1 decimal
    if(amount.indexOf(".") != amount.lastIndexOf("."))
    {
        alert("Only 1 decimal point is allowed");
        field.focus();
    }
}

function verifyCurrencyAmount(field, minAmount)
{ 
    var amount = field.value;

    //verify the amount entered is greater then the min amount
    if(amount <= minAmount)
    {
        alert("Please enter an amount greater then $" + minAmount);
        field.focus();
    }
}

function verifyOtherInc(field)
{
    var othIncAmt = field.value;
    
    if(othIncAmt.length > 0 && othIncAmt < 1000)
    {
        alert("You have entered $" + othIncAmt + " as other income.  Press Continue if this is the correct amount.");
    }
}

function verifySalary(field)
{
    var theSalary = field.value;
    
    if(theSalary != "")
    {
        if(theSalary < 2000)
        {
            alert("You have indicated that your salary is $" + theSalary + ".  Please verify that your annual gross salary was correctly entered.");
        }
        else if(theSalary < 3000)
        {
            alert("You have indicated that you make $" + theSalary + " per year.  If this is correct, " +
                "press Continue at the bottom of the page to proceed.  If this amount is incorrect please enter your income as x,xxx.xx.");
        }
    }
}

function verifyAdvanceAmount(field)
{
    var advanceMin = 500;
    var advanceAmount = parseFloat(field.value);
    var loanAmount = 0.00;

    if(getObj("anLoanAmt").value != "")
        loanAmount = parseFloat(getObj("anLoanAmt").value);

    if(advanceAmount > loanAmount)
    {
        alert("You have entered an advance amount that is greater than your requested loan amount.  " + 
            "Please enter a new advance amount");
        field.focus();
    }
    else if(advanceAmount < advanceMin)
    {
        alert("According to PSECU policy, the minimum amount for an advance is $500.  " + 
            "Please enter a new advance amount.");
        field.focus();
    }
}

function verifyMaxLoanAmount(field)
{ 
    var maxAmount = 1000000;
    var maxAmountStr = "";
    var validSigReFiAmount = 10000;
    var loanAmount = parseFloat(field.value);
    var loanAmountTemp = loanAmount;
    var ltv = 0;
    var theScen = QString("scen");
    var errorStr = null;
    
    if(theScen == "heloc2" || theScen == "homeeq2" || theScen == "preapp2")
    {
        maxAmountStr = getObj("homeEqMaxLoanlbl").innerHTML;
        //remove the comma if it exist
        maxAmountStr = maxAmountStr.replace(/,/g, "");
        maxAmount = parseFloat(maxAmountStr);
        

        //calculate the ltv        
		loanAmountTemp += parseFloat(getObj("phyXstgLienTemp").innerHTML);

		var estVal = parseFloat(getObj("phyValEstTemp").innerHTML);
		if(estVal > 0)
		{
			ltv = (loanAmountTemp / estVal) * 100;
		}
    }
    else if(theScen == "busRESecTerm2" || theScen == "busRESecLOC2")
    {
        maxAmountStr = getObj("homeEqMaxLoanlbl").innerHTML;
        //remove the comma if it exist
        maxAmountStr = maxAmountStr.replace(/,/g, "");
        maxAmount = parseFloat(maxAmountStr);
    }
    else if(theScen == "busUnsecTerm")
    {
        maxAmount = 50000.00;
    }
    else if(theScen == "sig")
    {
        var el = getObj("radSigType1");
        if(el.checked)
        {
            maxAmount = parseFloat(getObj("newSigLoanMax").innerHTML);
        }
        else
            maxAmount = 10000;
    }
    else if(theScen == "equipment")
    {
        maxAmount = 100000;
    }
   
    if(loanAmount > maxAmount)
    {
        if(theScen == "sig")
         {
            errorStr = "PSECU Signature Loans are only available in amounts up to $10,000.00.  "  + 
            "Please enter a requested loan amount less than $" + maxAmount.toFixed(2);
            //field.focus();
        }
        else if(theScen == "heloc2" || theScen == "homeeq2" || theScen == "preapp2")
        {
            errorStr = "Based upon the information you entered, you can apply for a loan up to $" + 
                maxAmount.toFixed(2) + ".  You entered an amount requested that is greater than this " + 
                "limit.  Please enter an amount requested that is equal to or less than this limit.";
            //field.focus();
        }
        else if(theScen == "busRESecTerm2" || theScen == "busRESecLOC2")
        {
            errorStr = "Based upon the information you entered, you can apply for a loan up to $" + 
                maxAmount.toFixed(2) + ".  You entered an amount requested that is greater than this " + 
                "limit.  Please enter an amount requested that is equal to or less than this limit.";
            //field.focus();
        }
        else if(theScen == "equipment")
        {
            errorStr = "You have requested a $" + loanAmount.toFixed(2) + " Equipment Loan. if this is correct press Continue at the bottom of the page.  " + 
                "If this is incorrect, please update the requested loan amount.";
            //field.focus();
        }
        else if(theScen == "busUnsecTerm")
        {
            errorStr = "You have requested a $" + loanAmount.toFixed(2) + " Unsecured Term Loan. if this is correct press Continue at the bottom of the page.  " + 
                "If this is incorrect, please update the requested loan amount.";
            //field.focus();
        }   
        else
            alert("You have requested a $" + loanAmount.toFixed(2) + " Auto Loan, if this is correct press Continue at the bottom of the page.  " + 
                "If this is incorrect, please update the requested loan amount.");
    }
    else if(theScen == "sig" && loanAmount < 1000)
    {
        errorStr = "The minimum Signature Loan amount is $1,000.00.  " +
            "Please enter a requested loan amount greater than $1,000.00";
        //field.focus();
    }
    else if(theScen == "heloc2" && ltv > 90)
    {
        errorStr = "According to PSECU policy, the maximum amount for an equity loan application is up to 90% " + 
            "of the LTV calculation.  With the current requested loan amount, the LTV is: " + ltv.toFixed(2) + "%  " +
            "Please reduce the requested loan amount";
        //field.focus();
    }
    else if((theScen == "busRESecTerm2" || theScen == "busRESecLOC2") && ltv > 80)
    {
        errorStr = "According to PSECU policy, the maximum amount for a loan application is up to 80% " + 
            "of the LTV calculation.  With the current requested loan amount, the LTV is: " + ltv.toFixed(2) + "%  " +
            "Please reduce the requested loan amount";
        //field.focus();
    }
    else if((theScen == "heloc2" || theScen == "homeeq2" || theScen == "preapp2") && loanAmount < 5000)
    {
        errorStr = "According to PSECU policy, the minimum amount for an equity loan application is $5,000.  " + 
            "You requested a loan amount less than this.  Please enter an amount you want to apply for " + 
            "that is at least $5,000.";
        //field.focus();
    }
    else if((theScen == "busRESecTerm2" || theScen == "busRESecLOC2") && loanAmount < 5000)
    {
        errorStr = "According to PSECU policy, the minimum amount for a loan application is $5,000.  " + 
            "You requested a loan amount less than this.  Please enter an amount you want to apply for " + 
            "that is at least $5,000.";
        //field.focus();
    }
    else if(theScen == "auto" || theScen == "busVehicle" || theScen == "equipment")
    {
        if(loanAmount >= 1000 && loanAmount < 3000)
        {
            alert("You have requested an amount less than $3,000.  Please be advised that the vehicle you " + 
                "intend to purchase must have a retail value of at least $3,000.  If the vehicle does not " + 
                "have a retail value of at least $3,000, PSECU will not finance the vehicle as an Auto Loan.  " + 
                "PSECU values vehicles using Kelley Blue Book as well as other authorized guides.  To obtain " + 
                "a retail value for the vehicle you intend to purchase, please visit the Auto Buying Center " + 
                "at PSECU.com or contact the Loan Dept at 800-LOAN-555. If the requested amount is correct, " + 
                "press Continueat at the bottom of the page.  If the requested amount is incorrect please enter a new requested loan amount.");
        }
        else if(loanAmount < 1000)
        {
            alert("You have requested a loan amount less than $1,000.  The minimum Auto Loan at PSECU is " + 
                "$1,000.  Please be advised that the vehicle you intend to purchase must have a retail " + 
                "value of at least $3,000.  If the vehicle does not have a retail value of at least $3,000, " + 
                "PSECU will not finance the vehicle as an Auto Loan.  PSECU values vehicles using Kelley " + 
                "Blue Book as well as other authorized guides.  To obtain a retail value for the vehicle " + 
                "you intend to purchase, please visit the Auto Buying Center at PSECU.com or contact the " + 
                "Loan Dept at 800-LOAN-555. Press Return and enter a new requested loan amount.");

        }
    }
    else if(theScen == "rec")
    {
        if(loanAmount >= 3000 && loanAmount < 3333)
        {
            alert("You have requested an amount less than $3,333.00.  Please be advised that the " + 
                "recreational vehicle you intend to purchase must have a retail value of at least " + 
                "$3,333.00.  If the vehicle does not have a retail value of at least $3,333.00, PSECU " + 
                "will not finance the vehicle as a Recreational Vehicle Loan.  PSECU values vehicles " + 
                "using Kelley Blue Book as well as other authorized guides.  To obtain a retail value " + 
                "for the recreational vehicle you intend to purchase, contact the Loan Dept at " + 
                "800-LOAN-555. If the requested amount is correct, press Continue at the bottom of the page.  If the requested " + 
                "amount is incorrect please enter a new requested loan amount.");
        }
        else if(loanAmount < 3000)
        {
            alert("You have requested a loan amount less than $3000.  The minimum Recreational Vehicle " + 
                "Loan at PSECU is $3,000.  Please be advised that the recreational vehicle you intend to " + 
                "purchase must have a retail value of at least $3,333.00.  If the vehicle does not have a " + 
                "retail value of at least $3,333, PSECU will not finance the vehicle as a recreational " + 
                "vehicle loan.  PSECU values vehicles using Kelley Blue Book as well as other authorized " + 
                "guides.  To obtain a retail value for the vehicle you intend to purchase, please contact " + 
                "the Loan Dept at 800-LOAN-555. Please enter a new requested loan amount.");
        }
    }

    if(errorStr != null)
    {
        getObj("anLoanAmtError").value = errorStr;
        alert(errorStr);
        field.focus();
    }
    else
        getObj("anLoanAmtError").value = "";
}

function setTerm(field)
{
    var theScen = QString("scen");
    var loanAmount = parseFloat(field.value);

    getObj("selTerm").options.length = 0;
    addOption("selTerm", "", "");
    addOption("selTerm", "2 years", "2");
    addOption("selTerm", "3 years", "3");

    if(theScen == "auto" || theScen == "busVehicle")
    {
        if(loanAmount >= 6000)
            addOption("selTerm", "4 years", "4");
        if(loanAmount >= 8000)
            addOption("selTerm", "5 years", "5");
        if(loanAmount >= 12000)
            addOption("selTerm", "6 years", "6");
        if(loanAmount >= 20000)
            addOption("selTerm", "7 years", "7");
        if(loanAmount >= 40000 && theScen == "auto")
        {
            addOption("selTerm", "8 years", "8");
            addOption("selTerm", "9 years", "9");
            addOption("selTerm", "10 years", "10");
        }
    }
    else if(theScen == "rec")
    {
        if(loanAmount >= 5000)
            addOption("selTerm", "4 years", "4");
        if(loanAmount >= 8000)
            addOption("selTerm", "5 years", "5");
        if(loanAmount >= 15000)
        {
            addOption("selTerm", "6 years", "6");
            addOption("selTerm", "7 years", "7");
        }
    }
    else if(theScen == "equipment")
    {
        if(loanAmount >= 5000)
            addOption("selTerm", "4 years", "4");
        if(loanAmount >= 8000)
            addOption("selTerm", "5 years", "5");
    }
    else if(theScen == "busUnsecTerm")
    {
        getObj("selTerm").options.length = 0;
        addOption("selTerm", "", "");
        addOption("selTerm", "5 years", "5");
    }
    else if(theScen == "busRESecTerm2")
    {
        getObj("anTerm").options.length = 0;
        addOption("anTerm", "", "");
        addOption("anTerm", "5 years", "5");
        if(loanAmount >= 50000)
            addOption("anTerm", "10 years", "10");

        changeLabel("pnlHomeEqTerm", "Loan Term: <span class='required'>*</span>");
        getObj("anTerm").errorText = "Loan Term";
    }
}

function reselectTerm()
{
    var termTemp = getObj("selTerm").selectedIndex;
    termTemp = getObj("selTerm").options[termTemp].value;
    setTerm(getObj("anLoanAmt"));
    
    for (var x = 0; x < getObj("selTerm").options.length; x++) 
    {   
        if (getObj("selTerm").options[x].value == termTemp) 
            getObj("selTerm").options[x].selected = true;   
    } 
}

function reselectHETerm()
{
    var termTemp = getObj("anTerm").selectedIndex;
    termTemp = getObj("anTerm").options[termTemp].value;
    setTerm(getObj("anLoanAmt"));
    
    for (var x = 0; x < getObj("anTerm").options.length; x++) 
    {   
        if (getObj("anTerm").options[x].value == termTemp) 
            getObj("anTerm").options[x].selected = true;   
    } 
}

function resetReplaymentDDL()
{
    var temp = getObj("anRePmtMth").selectedIndex;
    temp = getObj("anRePmtMth").options[temp].value;
    getObj("anRePmtMth").remove(5);
    getObj("anRePmtMth").remove(4);
    getObj("anRePmtMth").remove(3);
    getObj("anRePmtMth").remove(2);
    
    addOption("anRePmtMth", "Cash", "Cash");
    
    for (var x = 0; x < getObj("anRePmtMth").options.length; x++) 
    {   
        if (getObj("anRePmtMth").options[x].value == temp) 
            getObj("anRePmtMth").options[x].selected = true;   
    } 
}

function resetHEReplaymentDDL(loanType)
{
    var temp = getObj("anRePmtMthEq").selectedIndex;
    temp = getObj("anRePmtMthEq").options[temp].value;
    
    if(loanType != "busRESecTerm2" && loanType != "busRESecLOC2")
        getObj("anRePmtMthEq").remove(3);
    
    for (var x = 0; x < getObj("anRePmtMthEq").options.length; x++) 
    {   
        if (getObj("anRePmtMthEq").options[x].value == temp) 
            getObj("anRePmtMthEq").options[x].selected = true;   
    } 
}

function resetLoanPurposeDDL(loanType)
{
    var temp = getObj("anLoanPur").selectedIndex;
    temp = getObj("anLoanPur").options[temp].value;
    getObj("anLoanPur").options.length = 0;
    addOption("anLoanPur", "", "");

    if(loanType == "busRESecTerm2" || loanType == "busRESecLOC2")
    {
        addOption("anLoanPur", "Refinance", "3");
        addOption("anLoanPur", "Repairs", "35");
        addOption("anLoanPur", "Working Capital", "37");
        addOption("anLoanPur", "Purchases", "38");
        addOption("anLoanPur", "Other", "27");
    }
    else
    {
        addOption("anLoanPur", "Home Improvement", "2");
        addOption("anLoanPur", "Refinance", "3");
        addOption("anLoanPur", "Debt Consolidation", "34");
        addOption("anLoanPur", "Other", "27");
    }
     
    for (var x = 0; x < getObj("anLoanPur").options.length; x++) 
    {   
        if (getObj("anLoanPur").options[x].value == temp) 
            getObj("anLoanPur").options[x].selected = true;   
    } 
}


function verifyMaxCreditLimit(field)
{ 
    var theScen = QString("scen");
    var maxAmount = 0.00;
    var currentLoc = 0.00;

    if(theScen == "busUnsecLOC")
    {
        maxAmount = 50000.00;
        //this needs to be a string here so that the 'replace' method below will not throw an exception
        currentLoc = "5000.00";
    }
    else
    {
        maxAmount = 20000.00;
        currentLoc = getObj("maxLoanAmtLbl").innerHTML;
    }

    //remove the comma if it exist
    currentLoc = currentLoc.replace(/,/g, "");    

    var loanAmount = parseFloat(field.value);
    
    if((theScen == "psl" || theScen == "visa" || theScen == "combo") && getObj("totalCreditLimitLbl").innerHTML.length > 0)
    {
        var totalCredLimit = parseFloat(getObj("totalCreditLimitLbl").innerHTML);
        if(totalCredLimit + (loanAmount - currentLoc) > 20000)
        {
            alert("The maximum Credit Limit allowed between all PSECU accounts is: $20,000");
        }
    }
    
    if(loanAmount > maxAmount)
    {
        if(theScen == "psl")
        {
            alert("You have requested an Personal Service Loan limit greater than $20,000.00.  " +
                "PSECU offers Personal Service Loan Credit Limits up to $20,000.00.  " + 
                "Please enter a new requested loan amount.");
        }
        else if(theScen == "visa" || theScen == "busVisa")
        {
            alert("You have requested a Visa limit greater than $20,000.00.  PSECU offers Visa Loan " + 
                "Credit Limits up to $20,000.00.  Please enter a new requested loan amount.");
        }
        else
            alert("The maximum Credit Limit allowed is: $" + maxAmount.toString());

        field.focus();
    }
    else if(loanAmount < currentLoc)
    {
        if(theScen == "psl")
        {
            alert("You have requested a Personal Service Loan (PSL) Line of Credit that is less than your " + 
                "existing PSL Line of Credit.  You must apply for a line of credit that is greater than " + 
                "your existing line of credit. Please enter a new requested loan amount");
        }
        else if(theScen == "visa" || theScen == "busVisa")
        {
            alert("You have requested a Visa Line of Credit that is less than your existing Visa Line of " + 
                "Credit.  You must apply for a line of credit that is greater than your existing line of " + 
                "credit.  Please enter a new requested loan amount.");
        }
        else
            alert("The minimum Credit Limit allowed is: $" + currentLoc.toString());
        
        field.focus();
    }
    else if(loanAmount == currentLoc)
    {
        if(theScen == "psl")
        {
            alert("You have requested a Personal Service Loan (PSL) Line of Credit that is the same as " + 
                "your existing PSL Line of Credit.  Please enter a new requested loan amount.");
        }
        else if(theScen == "visa" || theScen == "busVisa")
        {
            alert("You have requested a Visa Line of Credit that is the same as your existing Visa Line of " + 
                "Credit.  Please enter a new requested loan amount.");
        }
        else
        {
            alert("You have requested a Personal Service Loan (PSL)/Visa Line of Credit that is the same as your existing PSL/Visa Line of Credit. Please enter a new requested loan amount.");
            field.focus();
        }
    }
    else if(loanAmount < 500.00)
    {
        if(theScen == "psl")
        {
            alert("You have requested a Personal Service Loan (PSL) Line of Credit that is less than $500.00.  " +
                "You must apply for a line of credit that is greater than " + 
                "$500.00. Please enter a new requested loan amount");
        }
        else if(theScen == "visa" || theScen == "busVisa")
        {
            alert("You have requested a Visa Line of Credit that is less than $500.00.  " + 
                "You must apply for a line of credit that is greater than $500.00.  " + 
                "Please enter a new requested loan amount.");
        }
        else
            alert("The minimum Credit Limit allowed is: $500.00");

        field.focus();
    }
    
}

function verifyFieldLength(field, theLength)
{ 
    var theField = field.value;

    if(theField.length > 0 && theField.length < theLength)
    {
        alert(" Field length must be " + theLength + " digits long");
        field.focus();
    }
}

function verifyYear(field)
{ 
    var year = field.value;
    var theDate = Date();

    if(year.length < 4)
    {
        alert(" Year must be 4 digits long");
        field.focus();
        return false;
    }

    theDate = theDate.substring(theDate.length - 4, theDate.length);
    if(year > theDate)
    {
        alert(" Invalid Year.");
        field.focus();
        return false;
    }

    return true;
}

function verifyPhoneNumber(field)
{ 
    //check for 555
    if(field.value == "555")
    {
        alert(" 555 is an invalid phone number");
        field.focus();
        return false;
    }

    return true;
}

function formatDate(field, e)
{
    var key = '';
    var strCheck = '0123456789';
    
    // set whichCode to code of key pressed (key code)
    var whichCode = e.which;
    if(whichCode == null || whichCode.length == 0)
        whichCode = e.keyCode;
        
    // Enter (13) is OK, added tab (0) and backspace (8) for firefox compatibility
    if (whichCode == 13 || whichCode == 0 || whichCode == 8) 
        return true;  

    // Get key value from key code (sets 'key' to character rep'd by key code)
    key = String.fromCharCode(whichCode);  
    if ((strCheck.indexOf(key) == -1)) 
    {
        // Not a valid key
        alert('Use numbers only.');
        field.focus();
        return false;
    }
    else
    {
        var dateStr = field.value;
        if(dateStr.length == 1 || dateStr.length == 4)
        {
            field.value = dateStr + key + "/";
            return false;
        }
    }

    return true;
}

// Updated to include uppercase suffix checking 04/24/03
function checkEmail(field)
{
  var emailPattern = new RegExp("[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?");
  eaddr=field.value;
  
  if(eaddr.length > 0)
  {	  
	  if (!emailPattern.test(eaddr)) {
           alert("       Invalid email address." 
           +"\rPlease verify username and '@' sign.");
           field.focus();		  
	  }
   }
 }


function showSaveSuccessAlert()
{
    alert("The loan application has been successfully saved.");
}

function getInternetExplorerVersion()
{
  var browserVersion = -1; // Return value assumes failure.
  if (navigator.appName == 'Microsoft Internet Explorer')
  {
    var ua = navigator.userAgent;
    var re  = new RegExp("MSIE ([0-9]{1,}[\.0-9]{0,})");
    if (re.exec(ua) != null)
      browserVersion = parseFloat( RegExp.$1 );
  }
  
  return browserVersion;
}

// Checks all fields on a form for 'empty string'.
//
function checkAll()
{
	return true;
    var pa = document.body;
    var A = null;
    var L = null;
    var emptyStr = "";
    var genericError = " is a required field<br/>";
    var errorFound = false;
    var errorStr = "";
    var brStr = "<br/>";
    var pnl = null;
    var lbl = null;
    var lblId = null;
    var lblFound = false;
    var labelStr = "label";
    var errorLabelClassStr = 'errorLabel';
    var trueStr = "true";
    var mieStr = "Microsoft Internet Explorer";
    var inputStr = 'input';
    var selectStr = 'select'
    var verifyStr = 'verify';
    var isRequiredStr = 'isRequired';
    var divNameStr = 'divName';
    var errorTextStr = 'errorText';
    var errorClassStr = 'errorClass';
    var classStr = 'class';
    var multiPartStr = 'multiPart';
    var defaultClassStr = 'defaultClass';
    var errorArray = new Array();
    var browserVersion = getInternetExplorerVersion();

    for (var x = 0; x <= 1; x++)
    {
        if (x == 0)
        {
            A = pa.getElementsByTagName(inputStr);
            L = A.length;
        }
        else
        {
            A = pa.getElementsByTagName(selectStr);
            L = A.length;
        }

        //loop through all of the elements
        for (var i = 0; i < L; i++)
        {
            lblFound = false;
            
            if(browserVersion > -1 && browserVersion < 9)
            {
                if (A[i].verify && A[i].isRequired == trueStr && 
                    A[i].value.length == 0)
                {
                    errorFound = true;
                    
                    //set the label to a red color
                    if(A[i].divName != null)
                    {
                        if (isString(A[i].divName)) 
	                       pnl = getObj(A[i].divName);
                    	
	                    lbl = pnl.getElementsByTagName(labelStr);
	                    if (lbl.length > 0)
		                    lbl = lbl[0];
                    	
	                    if(A[i].errorClass != null)
	                        lbl.className = A[i].errorClass;
	                    else
	                        lbl.className = errorLabelClassStr;
	                    
	                    if(lbl.multiPart != null)
	                        errorArray.push(lbl.id);
	                }
	                
	                if (A[i].errorText != null && A[i].errorText.length > 0)
                        errorStr += A[i].errorText + brStr;
                    else
                        errorStr += A[i].id + genericError;
                }
                else 
                {
                    //set the label back to normal
                    if(A[i].divName != null)
                    {
                        if (isString(A[i].divName)) 
	                       pnl = getObj(A[i].divName);
                    	
	                    lbl = pnl.getElementsByTagName(labelStr);
	                    if (lbl.length > 0)
		                    lbl = lbl[0];
                    	
                    	if(lbl.multiPart == null)
                    	{
	                        if(A[i].defaultClass != null)
	                            lbl.className = A[i].defaultClass;
	                        else
	                            lbl.className = emptyStr;
                        }
                        else
                        {
                            for(var index = 0; index < errorArray.length && !lblFound; index++)
                            {
                                lblId = errorArray[index];
                                if(lblId == lbl.id)
                                    lblFound = true;                            
                            }
                            
                            if(!lblFound)
                            {
                                if(A[i].defaultClass != null)
	                                lbl.className = A[i].defaultClass;
	                            else
	                                lbl.className = emptyStr;
                            }
                        }
	                }
                }
            }
            else
            {
               if (A[i].getAttribute(verifyStr) == trueStr && A[i].getAttribute(isRequiredStr) == trueStr && 
                    A[i].value.length == 0)
                {
                    errorFound = true;
                    
                    //set the label to a red color
                    if(A[i].getAttribute(divNameStr) != null)
                    {
                        if (isString(A[i].getAttribute(divNameStr))) 
	                       pnl = getObj(A[i].getAttribute(divNameStr));
                    	
	                    lbl = pnl.getElementsByTagName(labelStr);
	                    if (lbl.length > 0)
		                    lbl = lbl[0];

                        if(A[i].getAttribute(errorClassStr) != null)
        					lbl.className = A[i].getAttribute(errorClassStr);
	                    else
                            lbl.className = errorLabelClassStr;
    	                    
    	                if(lbl.getAttribute(multiPartStr) != null)
	                        errorArray.push(lbl.id);
	                }
                    
                    if (A[i].getAttribute(errorTextStr) != null && A[i].getAttribute(errorTextStr).length > 0)
                        errorStr += A[i].getAttribute(errorTextStr) + brStr;
                    else
                        errorStr += A[i].id + genericError;
                }
                else
                {
                    //set the label to normal
                    if(A[i].getAttribute(divNameStr) != null)
                    {
                        if (isString(A[i].getAttribute(divNameStr))) 
	                       pnl = getObj(A[i].getAttribute(divNameStr));
                    	
	                    lbl = pnl.getElementsByTagName(labelStr);
	                    if (lbl.length > 0)
		                    lbl = lbl[0];
                    	
                    	if(lbl.getAttribute(multiPartStr) == null)
                    	{
	                        if(A[i].getAttribute(defaultClassStr) != null)
	                            lbl.className = A[i].getAttribute(defaultClassStr);
	                        else
	                            lbl.className = emptyStr;
                        }
                        else
                        {
                            for(var index = 0; index < errorArray.length && !lblFound; index++)
                            {
                                lblId = errorArray[index];
                                if(lblId == lbl.id)
                                    lblFound = true;                            
                            }
                            
                            if(!lblFound)
                            {
                                if(A[i].defaultClass != null)
	                                lbl.className = A[i].getAttribute(defaultClassStr);
	                            else
	                                lbl.className = emptyStr;
                            }
                        }
	                }
                } 
            }//
        }
    }

    errorArray = null;
    
    if (errorFound)
    {
        errorStr = "<font size='3'>Missing \\ Incomplete Required Fields</font><br/><br/>" + errorStr;
        getObj("pnlError").innerHTML = errorStr;
        show("pnlError");
        scroll(0,0);
    }
    else
        hide("pnlError");
    
    return !errorFound;
}

function disableAllFields()
{
    var pa = document.body;
    var A = null;
    var L = null;
    var browser = navigator.appName;

    for(var x = 0; x <= 1; x++)
    {
        if(x == 0)
        {
            A = pa.getElementsByTagName('input');
            L = A.length;
        }
        else
        {
            A = pa.getElementsByTagName('select');
            L = A.length;
        }
        
        //loop through all of the elements
        for(var i = 0; i < L; i++)
        {
            if (browser == "Microsoft Internet Explorer")
            {
                if(A[i].type != "submit")
                    A[i].disabled = true;
            }
            else
            {
                if(A[i].getAttribute('type') != "submit")
                    A[i].getAttribute('disabled') = true;
            }
        }
    }
}

/*  Micro API to return an object */
function getObj(name) {     
  if (document.getElementById)  {
    if (document.getElementById(name))
  	    return document.getElementById(name);
  }
  else if (document.all)  {
	if (document.all[name])
	    return document.all[name];
  }
  else if (document.layers)  {
    if (document.layers[name]) {
        this.style = document.layers[name];
   	    return document.layers[name]; } 	    
  }
}

function getObjByElements(name) {     
	var theForm = document.forms[0];

	return theForm.elements[name]; 
}

/*
    Add click, blur etc events
    usage: addEvent(object, event type [no 'on'], function, use Capture)
*/    
function addEvent(obj, evType, fn, useCapture){
  if (isString(obj)) obj = getObj(obj);
  if (obj.addEventListener){
    obj.addEventListener(evType, fn, useCapture);
    return true;
  } else if (obj.attachEvent){
    var r = obj.attachEvent("on"+evType, fn);
    return r;
  } else {
    alert("Handler could not be attached");
  }
}


function removeEvent(obj, evType, fn, useCapture){
  if (obj.removeEventListener){
    obj.removeEventListener(evType, fn, useCapture);
    return true;
  } else if (obj.detachEvent){
    var r = obj.detachEvent("on"+evType, fn);
    return r;
  } else {
    alert("Handler could not be removed");
  }
}

function returnActiveElement(e) {
    var el;
    if (window.event && window.event.srcElement)
        el = window.event.srcElement;
    if (e && e.target)
        el = e.target;  
    return el;
}



function QString(qsParam) {
  nvString = "&" + location.search.substring(1, location.search.length) + "&"
  paramBegin = nvString.indexOf("&" + qsParam + "=")
  if (paramBegin != -1) {
    valBegin = (paramBegin*-1-qsParam.length-2)*-1
    qsVal = nvString.substring(valBegin, nvString.indexOf("&", valBegin))
    if (qsVal != "") {return unescape(qsVal)}
     else {return ""}
  }
  else {return ""}
}

function toggleVerifyAttribute(fieldName, theValue)
{
    var browserVersion = getInternetExplorerVersion();
    if(browserVersion > -1 && browserVersion < 9)
    {
        getObj(fieldName).verify = theValue;
    }
    else
    {
        getObj(fieldName).setAttribute('verify', theValue);
    }
}


// If the radio (obj) is checked, show the panels
function radToggle(obj, panels) {
	if (isString(obj)) 
	        obj = getObjByElements(obj);
	
	
	if (obj != null && obj.checked)
		show(panels);
	else
		hide(panels);	
}

// If the selectedIndex matches sIndex, show the panels
function cboToggle(obj, panels, sIndex) {
	
	// This will take arrays of objects, but they all need to match the same sIndex

	var match = true;
	var optSel;

	if (isArray(obj)) {	
		
		var tarLen = obj.length;
		
		for (var i = 0; i < tarLen; i++ ) {
			if (isString(obj[i])) obj[i] = getObj(obj[i]);
			optSel = obj[i].options.selectedIndex;
			if (optSel != sIndex) match = false;
		}
		
	}
	else {
		if (isString(obj)) obj = getObj(obj);
		optSel = obj.options.selectedIndex;
		if (optSel != sIndex) match = false;
	}
	
	if (match) {	
		show(panels); }
	else {
		hide(panels);
	}
	

}

/* START: NavGlobalPod */
function navglobalpod() {
	
	var pnlNavGlobalPod = getObj('navglobalpod');
	
	if (pnlNavGlobalPod) {
		pnlNavGlobalPod.innerHTML = "<form action='/search/index.asp' method='GET' name='searchResults1'><ul><li><a href='#'>contact us</a></li><li><input type='text' name='tx0' id='search' value='' />&nbsp;<input type='submit' name='submit' class='small' value='Search' /></li></ul></form>";
	}	
}
/* END: NavGlobalPod */



/* START: Expand and contract */




function toggle(target) {
	if (isString(target)) target = getObj(target);
    if (!target) { return false; } 
	if (isArray(target)) {
		var tarLen = target.length;
		for (var i = 0; i < tarLen; i++ ) {
			toggle(target[i]);
		}
	} else {	
    	target.style.display = (target.style.display == "none") ? "" : "none";
	}
}

function show(target) {
	if (isString(target))
    {
        targetStr = target;
        target = getObj(target);
    }
	
    var t;
	if (isArray(target)) {
		var tarLen = target.length;
		for (var i = 0; i < tarLen; i++ ) {
			show(target[i]);
		}
	} else {
	    if (t = target) {   	    		
    		t.style.display = "";
            enableDisableRequiredFields(targetStr, true);
		    return true;    }
		else {
		    return false; }
	}
}

function hide(target) {
	if (isString(target)) 
    {
        targetStr = target;
        target = getObj(target);
    }

    var t;
	if (isArray(target)) {
		var tarLen = target.length;
		for (var i = 0; i < tarLen; i++ ) {
			hide(target[i]);
		}
	} else {
        if (t = target) {
                
			t.style.display = "none";
            enableDisableRequiredFields(targetStr, false);
		    return true; }
		else {
		    return false;	}
	}
}

//disables input and select fields within the given panel\div element
function enableDisableRequiredFields(pa, enableRF){
    var pa = document.getElementById(pa);
    if(!pa)
        pa = document.body;

    var A = null;
    var L = null;

    for(var x = 0; x <= 1; x++)
    {
        if(x == 0)
        {
            A = pa.getElementsByTagName('input');
            L = A.length;
        }
        else
        {
            A = pa.getElementsByTagName('select');
            L = A.length;
        }

        //loop through all of the elements
        for(var i = 0; i < L; i++)
        {
            if(A[i].getAttribute('isRequired'))
            {
                if(enableRF)
                    doEnable(A[i].id);
                else
                    doDisable(A[i].id);
            }
        }
    }

}

function doEnable(target) 
{
	if (isString(target)) 
        target = getObj(target);
	
    var t;
    var browserVersion = getInternetExplorerVersion();
	if (isArray(target)) 
	{
		var tarLen = target.length;
		for (var i = 0; i < tarLen; i++ ) {
			doEnable(target[i]);
		}
	} 
    else {
	    if (t = target) 
	    {
            if(browserVersion > -1 && browserVersion < 9)
                t.verify = true;
            else
        		t.setAttribute('verify', true);
            
		    return true;    
        }
		else {
		    return false; 
		}
	}
}

function doDisable(target) 
{
	if (isString(target)) 
        target = getObj(target);

    var t;
    var browserVersion = getInternetExplorerVersion();
	if (isArray(target)) 
    {
		var tarLen = target.length;
		for (var i = 0; i < tarLen; i++ ) {
			doDisable(target[i]);
		}
	} 
    else {
        if (t = target) 
        {
            if(browserVersion > -1 && browserVersion < 9)
                t.verify = false;
            else
			    t.setAttribute('verify', false);
		    return true; 
        }
		else {
		    return false;	
		}
	}
}

function toggleHeader(e) {
	var el = returnActiveElement(e);
	if (!el) return;

	// Actually grab the header div, not any child elements that might have actually
	// captured the event.
	while (el.className.indexOf("tabsc") < 0) { el = el.parentNode };

	
	nextSib = el.nextSibling;	
	while (nextSib.nodeType != 1) nextSib = nextSib.nextSibling;
	//alert(nextSib.getAttribute("id"));

	el.className = (el.className == "tabsc") ? "tabsc_expanded" : "tabsc"; 
	nextSib.className = "tabsc_content";
	toggle(nextSib);
}
/* END: Expand and contract */


function grayOutScreen() {
	if (!getObj("pnlGrayOut")) {
		bod = document.getElementsByTagName('body')[0];
		overlay = document.createElement('div');
		overlay.id = 'pnlGrayOut';
		bod.appendChild(overlay);
	}
	else {
		show("pnlGrayOut");	
	}
}

function addOption(selectbox,text,value )
{
	if (isString(selectbox)) selectbox = getObj(selectbox);
	var optn = document.createElement("OPTION");
	optn.text = text;
	optn.value = value;
	selectbox.options.add(optn);
}


/* START: Tool tips */
function doTooltip(e, msg) {

  if ( typeof Tooltip == "undefined" || !Tooltip.ready ) return;
  Tooltip.show(e, msg);
}

function hideTip() {
  if ( typeof Tooltip == "undefined" || !Tooltip.ready ) return;
  Tooltip.hide();
}
/* END: Tool tips */




// Validation - Thanks W3Schools.

function validate_required(field)
{
	with (field)
	{
		if (value==null||value=="")
			{return false}
		else
			{return true}
	}
}

function validate_email(field)
{
	with (field)
	{
		apos=value.indexOf("@")
		dotpos=value.lastIndexOf(".")
		if (apos<1||dotpos-apos<2) {return false}
		else {return true}
	}
}

// End Validation



function setError(txt) {
	document.location += "&error=" + txt;
}

function hideError() {
	hide("pnlError");	
}


function changeLabel(pnl, txt) {
	if (isString(pnl)) pnl = getObj(pnl);
	var lbl = pnl.getElementsByTagName("label");
	
	if (lbl.length > 0) {
		lbl = lbl[0];
	}
	
	lbl.innerHTML = txt;
}

/* START: Initialize Function to Replace document.write */
addEvent(window, 'load', InitializeMain);

function InitializeMain() {
	
	if (QString("error")) {
		getObj("pnlError").innerHTML = QString("error");
		show("pnlError");
	}
}