var TrackedLinks = function() { 

	var rightClick = false;
	
	var ERROR_CHECK = "You must view and agree to the Terms and Conditions below.";
	var LINK_CLASS = "TermLink";

	var _container = null;
	var _trackedLinks = new Array();
	
	//private	
	this.addEvents = function(LinkObject, index) {
		LinkObject.oncontextmenu = function() { return false; };
		
		// we have to use click to get the keyboard users.  the event runs twice (with no ill effects) and I am unable to stop it
		addEvent(LinkObject, "mouseup", TrackedLinkOnClick);
		addEvent(LinkObject, "click", TrackedLinkOnClick); 
	}
	
	this.TrackedLinkOnClick = function(e) {
		

		if (e.which) {
			rightClick = (e.which === 3);
		} else if (e.button) {
			 rightClick = (e.button === 2);	
		}
	
		if (!rightClick) {
			var el = returnActiveElement(e);
			if (!el) return;
			
			while (el.tagName != "A") el = el.parentNode;
				
			if (el.className.indexOf(" checked") < 0) el.className += " checked";
			el.rel = true;	
		}
			
		
	}
	

	
	this.loadLinks = function() {
		return getElementsByClassName(LINK_CLASS, "A", _container);
	}	
	
	
	// Constructor	
	return function(container) {
		
		if (isString(container)) container = getObj(container);
		
		if (!container) {
			throw "Unable to find container.";
		}
		
		
		
		_container = container;	
	
		// Load links and attach events / default values
		var _trackedLinks = loadLinks();		
		
		for (var i = 0; i < _trackedLinks.length; i++) {
			var lnk = _trackedLinks[i];
			
			
			
			if (lnk.className === LINK_CLASS) {				
				lnk.rel = false;
				addEvents(lnk);
			}
		}
		
		
		// public events		
		this.OnSubmit = function() {
		
			if (this.checkLinks() === false) {
				return false;
			}
			
			return true;
			
		}	
		
		this.checkLinks = function() {
			for (i in _trackedLinks) {
				if (_trackedLinks[i].rel === "false") {
					return false;
				}
			}
			
			return true;
		}		
		
		
	}
}();



function getElementsByClassName(className, tag, elm) {

	var testClass = new RegExp("(^|\\\\s)" + className + "(\\\\s|$)");
	var tag = tag || "*";
	var elm = elm || document;
	var elements = (tag == "*" && elm.all)? elm.all : elm.getElementsByTagName(tag);
	
	var returnElements = [];
	var current;
	var length = elements.length;
	
	for(var i=0; i<length; i++) {

		current = elements[i];		
		var classes = current.className.split(" ");		

		for (var j = 0; j<classes.length; j++) {
			if(testClass.test(classes[j])){
				returnElements.push(current);
			}
		}

	}
	
	return returnElements;
}

