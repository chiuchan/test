package jdbc;
import java.sql.*;
import javax.sql.rowset.*;
import com.sun.rowset.*;
import java.math.BigDecimal;

public class JdbcRowSetSample {
	public static void main(String args[]) {
		String strUrl = "jdbc:datadirect:oracle://"
				+ "localhost:1521;SID=test";
		String strUserId = "scott";
		String strPassword = "tiger";
		String className = "com.jdbc.oracle.OracleDriver";
		JdbcRowSet jdbcRs;
		ResultSet rs;
		Statement stmt;
		Connection con;
		BigDecimal b;
		try {
			Class.forName(className);
		} catch (java.lang.ClassNotFoundException e) {
			System.err.print("ClassNotFoundException: ");
			System.err.println(e.getMessage());
		}
		try {
			con = DriverManager.getConnection(strUrl, strUserId, strPassword);
			con.setAutoCommit(false);
			stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_UPDATABLE);
			stmt.addBatch("drop table COFFEES");
			stmt.addBatch("create table COFFEES(COF_ID INTEGER, "
					+ "COF_NAME VARCHAR(20), SUP_ID INTEGER, "
					+ "PRICE DECIMAL(6,2))");
			b = new BigDecimal("7.99");
			stmt.addBatch("insert into COFFEES values "
					+ "(1250, �Colombian�, 101, " + b + ")");
			b = new BigDecimal("8.99");
			stmt.addBatch("insert into COFFEES values "
					+ "(1300, �French_Roast�, 49, " + b + ")");
			b = new BigDecimal("9.99");
			stmt.addBatch("insert into COFFEES values "
					+ "(1800, �Espresso�, 150, " + b + ")");
			b = new BigDecimal("8.99");
			stmt.addBatch("insert into COFFEES values " +

			"(2250, �Colombian_Decaf�, 101, " + b + ")");
			stmt.executeBatch();
			rs = stmt.executeQuery("select * from COFFEES");
			jdbcRs = new JdbcRowSetImpl(rs);
			jdbcRs.absolute(3);
			jdbcRs.updateBigDecimal("PRICE", new BigDecimal("9.99"));
			jdbcRs.updateRow();
			jdbcRs.first();
			jdbcRs.moveToInsertRow();
			jdbcRs.updateString("COF_NAME", "House_Blend");
			jdbcRs.updateInt("SUP_ID", 49);
			jdbcRs.updateBigDecimal("PRICE", new BigDecimal("7.99"));
			jdbcRs.insertRow();
			jdbcRs.moveToCurrentRow();
			jdbcRs.moveToInsertRow();
			jdbcRs.updateString("COF_NAME", "House_Blend_Decaf");
			jdbcRs.updateInt("SUP_ID", 49);
			jdbcRs.updateBigDecimal("PRICE", new BigDecimal("8.99"));
			jdbcRs.insertRow();
			jdbcRs.moveToCurrentRow();
			jdbcRs.last();
			jdbcRs.deleteRow();
			con.close();
			jdbcRs.close();
		} catch (SQLException sqle) {
			System.out.println("SQL Exception encountered: "
					+ sqle.getMessage());
		}
	}
}