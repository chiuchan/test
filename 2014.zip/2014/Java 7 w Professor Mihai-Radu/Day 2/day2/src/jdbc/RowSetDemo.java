package jdbc;
import javax.sql.rowset.*;
import java.sql.*;

/**
 * Java Program to illustrate how to use RowSet, RowSetProvider, and RowSetFactory in JDBC
 * In this example, RowSet is used to retrieve data from database instead of ResultSet. 
 */
public class RowSetDemo {
	public static void main(String[] args) {
		String url = "jdbc:mysql://localhost:3306/addressBook";
		String userName = "root";
		String password = "mysql123";
		try { // first, create a factory object for rowset
			RowSetFactory rowSetFactory = RowSetProvider.newFactory();
			// create a JDBC rowset from the factory
			JdbcRowSet rowSet = rowSetFactory.createJdbcRowSet();
			// Set connection properties
			rowSet.setUrl(url);
			rowSet.setUsername(userName);
			rowSet.setPassword(password);
			// Set SQL Query to execute
			rowSet.setCommand("SELECT * FROM contact");
			rowSet.execute();
			System.out.println("id Name Department Email Salary");
			// Iterating over RowSet
			while (rowSet.next()) {
				System.out.println(rowSet.getInt("id") + "\t"
						+ rowSet.getString("name") + "\t"
						+ rowSet.getString("department") + "\t"
						+ rowSet.getString("email") + "\t"
						+ rowSet.getString("salary"));
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
	}
}
