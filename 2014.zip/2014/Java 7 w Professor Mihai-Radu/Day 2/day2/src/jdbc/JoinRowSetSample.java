package jdbc;
import java.sql.*;
import javax.sql.rowset.*;
import com.sun.rowset.*;
import java.math.BigDecimal;

public class JoinRowSetSample {
	public static void main(String[] args) {
		String strUrl = "jdbc:datadirect:oracle://"
				+ "localhost:1521;SID=ORCL9";
		String strUserId = "scott";
		String strPassword = "tiger";
		String className = "yourDriver";
		BigDecimal b;
		try {
			Class.forName(className);
		} catch (java.lang.ClassNotFoundException e) {
			System.err.print("ClassNotFoundException: ");
			System.err.println(e.getMessage());
		}
		try {
			Connection con = DriverManager.getConnection(strUrl, strUserId,
					strPassword);
			con.setAutoCommit(false);
			Statement stmt = con.createStatement();
			stmt.addBatch("drop table COFFEES");
			stmt.addBatch("drop table SUPPLIERS");
			stmt.addBatch("create table COFFEES(COF_ID INTEGER, "
					+ "COF_NAME VARCHAR(20), SUP_ID INTEGER, "
					+ "PRICE DECIMAL(6,2))");
			b = new BigDecimal("7.99");
			stmt.addBatch("insert into COFFEES values "
					+ "(1250, �Colombian�, 101, " + b + ")");
			b = new BigDecimal("8.99");
			stmt.addBatch("insert into COFFEES values "
					+ "(1300, �French_Roast�, 49, " + b + ")");
			b = new BigDecimal("10.99");
			stmt.addBatch("insert into COFFEES values "
					+ "(1800, �Espresso�, 150, " + b + ")");
			b = new BigDecimal("8.99");
			stmt.addBatch("insert into COFFEES values "
					+ "(2250, �Colombian_Decaf�, 101, " + b + ")");
			b = new BigDecimal("7.99");
			stmt.addBatch("insert into COFFEES values "
					+ "(1000, �House_Blend�, 491, " + b + ")");
			b = new BigDecimal("8.99");
			stmt.addBatch("insert into COFFEES values "
					+ "(2000, �House_Blend_Decaf�, 49, " + b + "");
			stmt.addBatch("create table SUPPLIERS"
					+ "(SUP_ID INTEGER, SUP_NAME VARCHAR(40), "
					+ "ADDRESS VARCHAR(60))");
			stmt.addBatch("insert into SUPPLIERS values "
					+ "(101, �Acme, Inc.�, �Groundsville, CA 95199�");
			stmt.addBatch("insert into SUPPLIERS values "
					+ "(49, �Superior Coffee�, �Mendocino, CA 95460�");
			stmt.addBatch("insert into SUPPLIERS values "
					+ "(150, �The High Ground�, �Meadows, CA 93966�");
			stmt.executeBatch();
			con.commit();
			ResultSet rs1 = stmt.executeQuery("select * from COFFEES");
			ResultSet rs2 = stmt.executeQuery("select * from SUPPLIERS");
			// Populate two CachedRowSet objects and add them to a JoinRowSet
			// object
			CachedRowSet coffees = new CachedRowSetImpl();
			coffees.populate(rs1);
			System.out.print("First CachedRowSet size: ");
			System.out.println(coffees.size());
			CachedRowSet suppliers = new CachedRowSetImpl();
			suppliers.populate(rs2);
			System.out.print("Second CachedRowSet size: ");
			System.out.println(suppliers.size());
			con.close();
			JoinRowSet jrs = new JoinRowSetImpl();
			jrs.addRowSet(coffees, "SUP_ID");
			jrs.addRowSet(suppliers, "SUP_ID");
			System.out.print("Size of the JoinRowSet is: ");
			System.out.println(jrs.size());
			System.out.println("Contents are ");
			while (jrs.next()) {
				System.out.print("COF_ID: ");
				System.out.println(jrs.getInt("COF_ID"));
				System.out.print("COF_NAME: ");
				System.out.println(jrs.getString("COF_NAME"));
				System.out.print("PRICE: ");
				System.out.println(jrs.getBigDecimal("PRICE"));
				System.out.print("SUP_ID: ");
				System.out.println(jrs.getInt("SUP_ID"));
				System.out.print("SUP_NAME: ");
				System.out.println(jrs.getString("SUP_NAME"));
				System.out.print("ADDRESS: ");
				System.out.println(jrs.getString("ADDRESS"));
			}
			jrs.close();
		} catch (SQLException sqle) {
			System.out.println("Caught SQLException: "

			+ sqle.getMessage());
		}
	}
}