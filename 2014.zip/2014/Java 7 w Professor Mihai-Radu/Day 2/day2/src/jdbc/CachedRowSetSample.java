package jdbc;
import java.sql.*;
import javax.sql.rowset.*;
import java.math.BigDecimal;
import com.sun.rowset.*;

public class CachedRowSetSample {
	public static void main(String[] args) {
		String strUrl = "jdbc:datadirect:oracle://"
				+ "localhost:1521;SID=ORCL9";
		String strUserId = "scott";
		String strPassword = "tiger";
		String className = "yourDriver";
		CachedRowSet crs;
		int i = 1;
		try {
			Class.forName(className);
		} catch (java.lang.ClassNotFoundException e) {
			System.err.print("ClassNotFoundException: ");
			System.err.println(e.getMessage());
		}
		try {
			Connection con = DriverManager.getConnection(strUrl, strUserId,
					strPassword);
			con.setAutoCommit(false);
			Statement stmt = con.createStatement();
			stmt.executeUpdate("drop table MERCH_INVENTORY");
			stmt.executeUpdate("create table MERCH_INVENTORY( "
					+ "ITEM_ID INTEGER, ITEM_NAME VARCHAR(20), "
					+ "SUP_ID INTEGER, PRICE DECIMAL(6,2))");
			PreparedStatement pStmt = con
					.prepareStatement("insert into MERCH_INVENTORY values(?, ?, ?, ?)");
			// inserting values for 12 rows
			pStmt.setInt(1, 1234);
			pStmt.setString(2, "Cup_Large");
			pStmt.setInt(3, 456);
			pStmt.setBigDecimal(4, new BigDecimal("5.99"));
			pStmt.executeUpdate();
			pStmt.setInt(1, 1235);
			pStmt.setString(2, "Cup_Small");
			pStmt.setInt(3, 456);
			pStmt.setBigDecimal(4, new BigDecimal("2.99"));
			pStmt.executeUpdate();
			pStmt.setInt(1, 1236);
			pStmt.setString(2, "Saucer");
			pStmt.setInt(3, 456);
			pStmt.setBigDecimal(4, new BigDecimal("2.99"));
			pStmt.executeUpdate();
			pStmt.setInt(1, 1287);
			pStmt.setString(2, "Carafe");
			pStmt.setInt(3, 456);
			pStmt.setBigDecimal(4, new BigDecimal("25.99"));
			pStmt.executeUpdate();
			pStmt.setInt(1, 6931);
			pStmt.setString(2, "Carafe");
			pStmt.setInt(3, 927);
			pStmt.setBigDecimal(4, new BigDecimal("44.99"));
			pStmt.executeUpdate();
			pStmt.setInt(1, 6935);
			pStmt.setString(2, "PotHolder");
			pStmt.setInt(3, 927);
			pStmt.setBigDecimal(4, new BigDecimal("3.50"));
			pStmt.executeUpdate();
			pStmt.setInt(1, 6977);
			pStmt.setString(2, "Napkin");
			pStmt.setInt(3, 927);
			pStmt.setBigDecimal(4, new BigDecimal("3.99"));
			pStmt.executeUpdate();
			pStmt.setInt(1, 6979);
			pStmt.setString(2, "Towel");
			pStmt.setInt(3, 927);
			pStmt.setBigDecimal(4, new BigDecimal("4.99"));
			pStmt.executeUpdate();
			pStmt.setInt(1, 4488);
			pStmt.setString(2, "CofMaker");
			pStmt.setInt(3, 8372);
			pStmt.setBigDecimal(4, new BigDecimal("89.99"));
			pStmt.executeUpdate();
			pStmt.setInt(1, 4490);
			pStmt.setString(2, "CofGrinder");
			pStmt.setInt(3, 8732);
			pStmt.setBigDecimal(4, new BigDecimal("59.99"));
			pStmt.executeUpdate();
			pStmt.setInt(1, 4495);
			pStmt.setString(2, "EspMaker");
			pStmt.setInt(3, 8732);
			pStmt.setBigDecimal(4, new BigDecimal("79.99"));
			pStmt.executeUpdate();
			pStmt.setInt(1, 6914);
			pStmt.setString(2, "Cookbook");
			pStmt.setInt(3, 927);
			pStmt.setBigDecimal(4, new BigDecimal("15.00"));
			pStmt.executeUpdate();
			con.commit();
			con.close();
			crs = new CachedRowSetImpl();
			crs.setUrl(strUrl);
			crs.setUsername(strUserId);
			crs.setPassword(strPassword);
			crs.setCommand("select * from MERCH_CATALOG");
			// Setting the page size to 4, such that we get the data
			// in chunks of 4 rows at a time
			crs.setPageSize(4);
			// Get the first set of data
			crs.execute();
			while (crs.next()) {
				if (crs.getInt("ITEM_ID") == 1235) {
					System.out.println("PRICE value: "
							+ crs.getBigDecimal("PRICE"));
					crs.updateBigDecimal("PRICE", new BigDecimal("3.50"));
					crs.updateRow();
					System.out.print("New PRICE value: ");
					System.out.println(crs.getBigDecimal("PRICE"));
				}
			}
			// Keep on getting data in chunks until done
			while (crs.nextPage()) {
				System.out.println("Page number: " + i);
				while (crs.next()) {
					if (crs.getInt("ITEM_ID") == 1235) {
						System.out.print("PRICE value: ");
						System.out.println(crs.getBigDecimal("PRICE"));
						crs.updateBigDecimal("PRICE", new BigDecimal("3.50"));
						crs.updateRow();
						System.out.print("New PRICE value: ");
						System.out.println(crs.getBigDecimal("PRICE"));
					}
				} // End of inner while
				i++;
			} // End of outer while
				// Inserting a new row
			// Calling previousPage to come back to the last page
			// as we�ll be after the last page.
			crs.previousPage();
			crs.moveToInsertRow();
			crs.updateInt("ITEM_ID", 6922);
			crs.updateString("ITEM_NAME", "TableCloth");
			crs.updateInt("SUP_ID", 927);
			crs.updateBigDecimal("PRICE", new BigDecimal("19.99"));
			crs.insertRow();
			crs.moveToCurrentRow();
			// Synchronizing the update and new row back to the database
			crs.acceptChanges();
			crs.close();
		} catch (SQLException sqle) {
			System.out.println("SQLException caught: " + sqle.getMessage());
		}
	} // End of main
} // End of class
