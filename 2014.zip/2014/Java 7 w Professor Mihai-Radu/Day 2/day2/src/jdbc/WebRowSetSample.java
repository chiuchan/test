package jdbc;
import java.sql.*;
import java.io.*;
import java.math.BigDecimal;
import javax.sql.rowset.*;
import com.sun.rowset.*;

public class WebRowSetSample {
	public static void main(String[] args) throws Exception {
		String strUrl = "jdbc:datadirect:oracle://"
				+ "localhost:1521;SID=ORCL9";
		String strUserId = "scott";
		String strPassword = "tiger";
		String className = "yourDriver";
		BigDecimal b;
		int[] keyCols = { 1 };
		FileReader fReader;
		FileWriter fWriter;
		try {
			Class.forName(className);
		} catch (java.lang.ClassNotFoundException e) {
			System.err.print("ClassNotFoundException: ");
			System.err.println(e.getMessage());
		}
		try {
			Connection con = DriverManager.getConnection(strUrl, strUserId,
					strPassword);
			con.setAutoCommit(false);
			Statement stmt = con.createStatement();
			stmt.addBatch("drop table priceList");
			stmt.addBatch("create table priceList("
					+ "cof_name varchar(30), price decimal(6,2))");
			b = new BigDecimal("7.99");
			stmt.addBatch("insert into priceList values(" + " Colombian , " + b
					+ ")");
			b = new BigDecimal("8.99");
			stmt.addBatch("insert into priceList values(" + " French_Roast , "
					+ b + ")");
			b = new BigDecimal("9.99");
			stmt.addBatch("insert into priceList values(" + " Espresso , " + b
					+ ")");
			b = new BigDecimal("8.99");
			stmt.addBatch("insert into priceList values("
					+ " Colombian_Decaf , " + b + ")");
			b = new BigDecimal("9.99");
			stmt.addBatch("insert into priceList values("
					+ " French_Roast_Decaf , " + b + ")");
			stmt.executeBatch();
			con.commit();
			con.close();
			// Create a WebRowSet and set its properties.
			WebRowSet sender = new WebRowSetImpl();
			sender.setUrl(strUrl);
			sender.setUsername(strUserId);
			sender.setPassword(strPassword);
			sender.setCommand("select * from priceList");
			sender.setKeyColumns(keyCols);
			// Populate the WebRowSet
			sender.execute();
			System.out.print("WebRowSet size is: ");
			System.out.println(sender.size());
			// Delete the row with "Espresso"
			sender.beforeFirst();
			while (sender.next()) {
				if (sender.getString(1).equals("Espresso")) {
					System.out.print("Deleting row with ");
					System.out.println(" Espresso");
					sender.deleteRow();
					break;
				}
			}
			// Update price of Colombian
			sender.beforeFirst();
			while (sender.next()) {
				if (sender.getString(1).equals("Colombian")) {
					System.out.print("Updating row with ");
					System.out.println("Colombian");
					sender.updateBigDecimal(2, new BigDecimal("6.99"));
					sender.updateRow();
					break;
				}
			}
			int size1 = sender.size();
			fWriter = new FileWriter("priceList.xml");
			sender.writeXml(fWriter);
			fWriter.flush();
			fWriter.close();
			// Create the receiving WebRowSet object
			WebRowSet receiver = new WebRowSetImpl();
			receiver.setUrl(strUrl);
			receiver.setUsername(strUserId);
			receiver.setPassword(strPassword);
			// Now read the XML file.
			fReader = new FileReader("priceList.xml");
			receiver.readXml(fReader);
			int size2 = receiver.size();
			if (size1 == size2) {
				System.out.print("WebRowSet serialized and ");
				System.out.println("deserialized properly");
			} else {
				System.out.print("Error....serializing/");
				System.out.println("deserializing the WebRowSet");
			}
		} catch (SQLException sqle) {
			System.err.print("SQL Exception: "+sqle.getMessage());
			sqle.printStackTrace();
		}
	}
}