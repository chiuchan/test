package objects;

import java.util.Objects;

public class Bar {
	private Foo foo;
	private Bar parent;

	public void setFoo(Foo foo) {
		this.foo = Objects.requireNonNull(foo);
	}

	public void setBar(Bar bar) {
		this.parent = Objects.requireNonNull(bar, "bar cannot be null");
	}

	@Override
	public String toString() {
		return "Bar {foo = " + Objects.toString(foo) + ", parent = "
				+ Objects.toString(parent, "no parent, orphan") + "}";
		// return "Bar {foo = " + (foo == null ? "null" : foo.toString()) +
		// ", parent = " + (parent == null ? "o parent, orphan" :
		// parent.toString()) + "}";
	}

	// @Override
	// public int hashCode(){
	// int result = 17;
	//
	// result = 31 * result + (foo == null ? 0 : foo.hashCode());
	// result = 31 * result + (parent == null ? 0 : parent.hashCode());
	//
	// return result;
	// }

	@Override
	public int hashCode() {
		return Objects.hash(foo, parent);
	}

	// @Override
	// public boolean equals(Object obj){
	// if (obj == this) {
	// return true;
	// }
	//
	// if (obj instanceof Bar) {
	// Bar other = (Bar) obj;
	//
	// if (foo != other.foo) {
	// if (foo == null || !foo.equals(other.foo)) {
	// return false;
	// }
	// }
	//
	// if (parent != other.parent) {
	// if (parent == null || !parent.equals(other.parent)) {
	// return false;
	// }
	// }
	//
	// return true;
	// }
	//
	// return false;
	// }

	@Override
	    public boolean equals(Object obj){
	        if (obj == this) {
	            return true;
	        }

	        if (obj instanceof Bar) {
	            Bar other = (Bar) obj;

	            return Objects.equals(foo, other.foo) && Objects.equals(parent, other.parent);
	        }

	        return false;
	    }

	public static void main(String[] args) {
		Bar b = new Bar();
		System.out.println("bar instance" + b);
		Foo f = null;
		b.setFoo(f);
	}
}
