package objects;

public class Foo {
	private Object foo;

	public Object getFoo() {
		return foo;
	}

	public void setFoo(Object foo) {
		this.foo = foo;
	}
}
