package collect;
import java.util.concurrent.LinkedTransferQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TransferQueue;

/*
 �* Code provided by www.java7examples.com
 �* This example shows the use of new feature in Java7 regarding the Collections.
 �* New Interface TransferQueue extends the old BlockingQueue Interface and has 5 new Methods explained in the example below
 �* New Class LinkedTransferQueue Introduced in Java7 implements TransferQueue. This is a FIFO(First In First Out Unbounded Queue) and 
 �* this class implements the 5 methods of the interface which we will see in the example below.
 �* These 5 methods were not present in the BlockingQueue Interface
 �*/

public class Java7CollectionFeatureExample {
	public static void main(String[] args) {
		// New Instance of LinkedTransferQueue is created
		TransferQueue<String> queue = new LinkedTransferQueue<>();

		// Producers and Consumers will be putting and taking out the Contents
		// into queue
		Producer firstProducer = new Producer(queue);
		Consumer firstConsumer = new Consumer(queue);
		Consumer secondConsumer = new Consumer(queue);
		Consumer thirdConsumer = new Consumer(queue);
		Consumer fourthConsumer = new Consumer(queue);

		// One Producer and Two Consumer Threads
		new Thread(firstProducer, "firstProducer").start();
		new Thread(firstConsumer, "firstConsumer").start();
		new Thread(secondConsumer, "secondConsumer").start();
		new Thread(thirdConsumer, "thirdConsumer").start();
		new Thread(fourthConsumer, "fourthConsumer").start();

	}
}

class Producer implements Runnable {
	private final TransferQueue<String> queue;
	static int counter;

	Producer(TransferQueue<String> q) {
		queue = q;
	}

	public void run() {
		try {

			for (int i = 0; i < 5; i++) {
				queue.put(produce());
				// Check if is there any Consumer Waiting to consume
				System.out.println("Is there any Customer Waiting: "
						+ queue.hasWaitingConsumer());
				// Print the number of waiting Consumers who want to receive the
				// element
				System.out.println("Waiting Consumer Count: "
						+ queue.getWaitingConsumerCount());
			}

			/*
			 * Transfers the specified element immediately if there exists a
			 * consumer already waiting to receive it and if there is no
			 * consumer waiting � *then INSERT the element at the tail of the
			 * queue AND WAIT until the consumer receives it. �
			 */
			queue.transfer("1000");
			/*
			 * Transfers the specified element immediately if there exists a
			 * consumer already waiting to receive it, or else returns FALSE
			 * WITHOUT adding � *the element to the queue �
			 */
			System.out
					.println("Will transfer 1001 immediately if there exists a consumer already waiting to receive it:"
							+ queue.tryTransfer("1001"));

			/*
			 * Transfers the specified element immediately if there exists a
			 * consumer already waiting to receive it, else INSERTS the
			 * specified element at � * the tail of this queue and WAITS until
			 * the element is received by a consumer, � * It returns FALSE if
			 * the the SPECIFIED TIME elapses before the element gets
			 * transferred �
			 */
			System.out
					.println("Will transfer 10002 immediately if there exists a consumer already waiting to receive it for a specified time of 200ms:"
							+ queue.tryTransfer("10002", 200,
									TimeUnit.MILLISECONDS));

		} catch (InterruptedException ex) {
			ex.printStackTrace();
		}
	}

	String produce() {
		String toBeProduced = "" + ++counter;
		try {
			Thread.sleep(5);
		} catch (InterruptedException ex) {
			ex.printStackTrace();
		}
		System.out.println(Thread.currentThread().getName() + " Producing "
				+ toBeProduced);
		return "" + toBeProduced;
	}
}

class Consumer implements Runnable {
	private final TransferQueue<String> queue;

	Consumer(TransferQueue<String> q) {
		queue = q;
	}

	public void run() {
		try {
			while (true) {
				consume(queue.take());
			}
		} catch (InterruptedException ex) {
			ex.printStackTrace();
		}
	}

	void consume(String x) {
		try {
			Thread.sleep(10000);
		} catch (InterruptedException ex) {
			ex.printStackTrace();
		}

		System.out.println(Thread.currentThread().getName() + " Consuming: "
				+ x);
	}
}
