package othher.swing.nimbus;

import java.awt.Color;
import java.awt.FlowLayout;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;

public class Ex2 extends JFrame {

	Ex2(String name) {
		super(name);

		UIManager.put("nimbusBlueGrey", new Color(200,100,100));
		UIManager.put("nimbusBase", new Color(100,250,100));
		UIManager.put("control", new Color(250,150,100));

		
		// set nimbus L&F
		try {
			for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
				if ("Nimbus".equals(info.getName())) {
					UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
		} catch (Exception e) {
			// If Nimbus is not available, you can set the GUI to another look
			// and feel.
		}

		initGUI();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		pack();
		setVisible(true);
	}

	private void initGUI() {
		setLayout(new FlowLayout());

		JPanel p1 = new JPanel();
		p1.setLayout(new BoxLayout(p1, BoxLayout.Y_AXIS));
		final JButton b1 = new JButton("ButtonMini");
		b1.putClientProperty("JComponent.sizeVariant", "mini");
		p1.add(b1);
		JComboBox<String> cb1 = new JComboBox<String>(new String[] { "option1",
				"option2", "option3" });
		cb1.putClientProperty("JComponent.sizeVariant", "mini");
		p1.add(cb1);
		JRadioButton rb1 = new JRadioButton("Select Me");
		p1.add(rb1);
		rb1.putClientProperty("JComponent.sizeVariant", "mini");

		JPanel p2 = new JPanel();
		p2.setLayout(new BoxLayout(p2, BoxLayout.Y_AXIS));
		final JButton b2 = new JButton("ButtonLarge");
		b2.putClientProperty("JComponent.sizeVariant", "large");
		p2.add(b2);
		JComboBox<String> cb2 = new JComboBox<String>(new String[] { "option1",
				"option2", "option3" });
		cb2.putClientProperty("JComponent.sizeVariant", "large");
		p2.add(cb2);
		JRadioButton rb2 = new JRadioButton("Select Me");
		p2.add(rb2);
		rb2.putClientProperty("JComponent.sizeVariant", "large");

		JPanel p3 = new JPanel();
		p3.setLayout(new BoxLayout(p3, BoxLayout.Y_AXIS));
		final JButton b3 = new JButton("ButtonSmall");
		b3.putClientProperty("JComponent.sizeVariant", "small");
		p3.add(b3);
		JComboBox<String> cb3 = new JComboBox<String>(new String[] { "option1",
				"option2", "option3" });
		cb3.putClientProperty("JComponent.sizeVariant", "small");
		p3.add(cb3);
		JRadioButton rb3 = new JRadioButton("Select Me");
		p3.add(rb3);
		rb3.putClientProperty("JComponent.sizeVariant", "small");

		// p1.putClientProperty("JComponent.sizeVariant", "mini");
		add(p1);
		// p3.putClientProperty("JComponent.sizeVariant", "small");
		add(p3);
		// p2.putClientProperty("JComponent.sizeVariant", "large");
		add(p2);
	}

	public static void main(String[] args) {
		new Ex2("Color change");
	}
}
