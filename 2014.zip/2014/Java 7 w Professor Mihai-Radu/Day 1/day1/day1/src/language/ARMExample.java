package language;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class ARMExample {
	public static void main(String[] args) {
		beforeJava7();
		inJava7();
	}

	public static void beforeJava7() {
		FileInputStream fileReader = null;
		FileOutputStream fileWriter = null;
		try {

			fileReader = new FileInputStream("testFileIn.txt");
			fileWriter = new FileOutputStream("testFileOut.txt");
			int var;
			while ((var = fileReader.read()) != -1)
				fileWriter.write(var);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {

			try {
				fileReader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}

			try {
				fileWriter.close();
			} catch (IOException e) {

				e.printStackTrace();
			}
		}
	}

	public static void inJava7() {

		try (FileInputStream fileReader = new FileInputStream("testFileIn.txt");
				FileOutputStream fileWriter = new FileOutputStream(
						"testFileOut.txt")) {

			int var;
			while ((var = fileReader.read()) != -1)
				fileWriter.write(var);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
