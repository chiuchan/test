package language;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;

public class ShortExamples {
	public static void main(String[] args) {

		diamondOperator();
		underline();
	}

	public static void bynaryNumbers() {
		// An 8-bit 'byte' value:
		byte aByte = (byte) 0b00100001;

		// A 16-bit 'short' value:
		short aShort = (short) 0b1010000101000101;

		// Some 32-bit 'int' values:
		int anInt1 = 0b10100001010001011010000101000101;
		int anInt2 = 0b101;
		int anInt3 = 0B101; // The B can be upper or lower case.

		// A 64-bit 'long' value. Note the "L" suffix:
		long aLong = 0b1010000101000101101000010100010110100001010001011010000101000101L;
	}

	public static void underline() {
		// stilul vechi
		int oldBillion = 1000000000;

		// noul stil
		int newBillion = 1_000_000_000;

		System.out.println(oldBillion);
		System.out.println(newBillion);

		// float pi1 = 3_.1415F; // Invalid; cannot put underscores adjacent to
		// a decimal point
		// float pi2 = 3._1415F; // Invalid; cannot put underscores adjacent to
		// a decimal point
		// long socialSecurityNumber1 = 999_99_9999_L; // Invalid; cannot put
		// underscores prior to an L suffix

		//int x1 = _52; // This is an identifier, not a numeric literal
		int x2 = 5_2; // OK (decimal literal)
		// int x3 = 52_; // Invalid; cannot put underscores at the end of a
		// literal
		int x4 = 5_______2; // OK (decimal literal)

		// int x5 = 0_x52; // Invalid; cannot put underscores in the 0x radix
		// prefix
		// int x6 = 0x_52; // Invalid; cannot put underscores at the beginning
		// of a number
		int x7 = 0x5_2; // OK (hexadecimal literal)
		// int x8 = 0x52_; // Invalid; cannot put underscores at the end of a
		// number

		int x9 = 0_52; // OK (octal literal)
		int x10 = 05_2; // OK (octal literal)
		// int x11 = 052_; // Invalid; cannot put underscores at the end of a
		// number
	}

	public static void diamondOperator() {
		Map<String, List<String>> map = new HashMap<>();
		// List l = new ArrayList<>();
		// new ArrayList<>().addAll(new ArrayList<>());
		// new ArrayList<>().addAll(new ArrayList<String>());
		// new ArrayList<String>().addAll(new ArrayList<>());
	}

}
