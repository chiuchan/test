package language;


public class SwitchExample {
	public static void main(String[] args) {
		String name = "Mary";

		switch (name) {
		case "Mary":
			System.out.println("Hi " + name);
			break;
		case "John":
			System.out.println("Hello " + name);
			break;
		default:
			System.out.println("Dear Ms./Sir");
			break;
		}
	}

}
