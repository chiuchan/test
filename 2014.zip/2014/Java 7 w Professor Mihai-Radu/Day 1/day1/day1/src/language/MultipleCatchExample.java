package language;

import java.util.Scanner;

public class MultipleCatchExample {
	public static void main(String[] args) {
		System.out.println("Write a number:");
		Scanner scnr = new Scanner(System.in);
		String number = scnr.next();
		try {
			if (number.length() > 5) {
				throw new MyException("To long argument");
			}
			Integer.parseInt(number);

		} catch (  NumberFormatException | MyException e ) {
			e.printStackTrace();
		}
	}
	
	static class MyException extends Exception{
		public MyException (String message){
			super(message);
		}
	}
}
