package language;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;

public class VarargsExample {
	public static void main(String[] args) {
		List<String> stringListA = new ArrayList<String>();
		List<String> stringListB = new ArrayList<String>();

		addToList(stringListA, "Seven", "Eight", "Nine");
		addToList(stringListA, "Ten", "Eleven", "Twelve");
		List<List<String>> listOfStringLists = new ArrayList<List<String>>();

		addToList(listOfStringLists, stringListA, stringListB);
		addToList2(listOfStringLists, stringListA, stringListB);
		addToList3(listOfStringLists, stringListA, stringListB);

		Callable<String> t = null;
		List<Callable<String>> merged = asList(t);
		System.out.println(merged);

	}

	private static <T> List<T> asList(T... elements) {
		return Arrays.asList(elements);
	}

	public static <T> void addToList(List<T> listArg, T... elements) {
		for (T x : elements) {
			listArg.add(x);
		}
	}

//	@SuppressWarnings({ "unchecked", "varargs" })
	public static <T> void addToList2(List<T> listArg, T... elements) {
		for (T x : elements) {
			listArg.add(x);
		}
	}

	@SafeVarargs
	public static <T> void addToList3(List<T> listArg, T... elements) {
		for (T x : elements) {
			listArg.add(x);
		}
	}

}
