package language;

public class Exceptii {

	public class MyException1 extends Exception {
	}

	public class MyException2 extends Exception {
	}

	void testMyException1()throws MyException1{
		throw new MyException1();
	}

	void testMyException2()throws MyException2{
		throw new MyException2();
	}

	void testFunction() throws MyException1, MyException2{
		try{
			testMyException1();
			testMyException2();
		}catch (Exception e) {
			System.out.println("Type of exception: " + e.getClass());
			throw e;
		}
	}

	public static void main(String[] args) {
		 Exceptii obj = new Exceptii();

		try {
			obj.testFunction();
		} catch (MyException1 | MyException2 e) {
			System.out.println("Type of exception: " + e.getClass());
		}
	}
}
