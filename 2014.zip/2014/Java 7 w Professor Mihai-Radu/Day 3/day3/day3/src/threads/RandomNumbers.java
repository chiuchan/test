package threads;

import java.util.concurrent.ThreadLocalRandom;

public class RandomNumbers {
	public static void main(String[] args) {
		// ThreadLocalRandom.current().setSeed(System.currentTimeMillis());
		// 3 threads
		for (int i = 0; i < 3; i++) {
			final Thread thread = new Thread() {
				@Override
				public void run() {
					System.out.print(Thread.currentThread().getName() + ":");
					// ThreadLocalRandom.current().setSeed(System.currentTimeMillis());

					// each thread prints 3 random numbers
					for (int j = 0; j < 3; j++) {
						final int random = ThreadLocalRandom.current().nextInt(
								1, 50);
						System.out.print(random + ",");
					}
					System.out.println();
				}
			};

			try {
				thread.start();
				thread.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
