package threads;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinPool;

public class FibonaciTest {
	public static void main(String[] args) throws InterruptedException, ExecutionException {
		// Check the number of available processors
		int processors = Runtime.getRuntime().availableProcessors();
		System.out.println("No of processors: " + processors);

		FibonacciTask task = new FibonacciTask(20);
		ForkJoinPool pool = new ForkJoinPool(processors);
		pool.invoke(task);

		long result = task.get();
		System.out.println("Computed Result: " + result);

	}
}
