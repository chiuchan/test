package threads;

import java.util.concurrent.RecursiveTask;

public class FibonacciTask extends RecursiveTask<Long> {
	private final int number;

	public FibonacciTask(int n) {
		number = n;
	}

	@Override
	protected Long compute() {
		switch (number) {
		case 0:
			return (0L);
		case 1:
			return (1L);
		default:
			FibonacciTask f1 = new FibonacciTask(number - 1);
			FibonacciTask f2 = new FibonacciTask(number - 2);
			f1.fork();
			f2.fork();
			return (f1.join() + f2.join());
		}
	}

}
