package nioIO;

import java.io.IOException;
import java.nio.file.DirectoryNotEmptyException;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;

public class ExFileOp {
	public static void main(String[] args) {
		fileAtr();
	}

	private static void delete(String path) {
		Path p = Paths.get(path);

		try {
			Files.deleteIfExists(p);
			// Files.delete(p);
		} catch (DirectoryNotEmptyException x) {
			System.err.format("%s not empty%n", path);
		} catch (IOException x) {
			// File permission problems
			// are caught here.
			System.err.println(x);
		}
	}

	public static void copyMove() {
		FileSystem _default = FileSystems.getDefault();
		Path charm = _default.getPath("cats/charm.txt");
		Path pets = _default.getPath("pets/charm_harold.xml");

		try {
			Files.copy(charm, pets);
			Files.move(charm, pets);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static void fileAtr() {
		Path file = Paths.get("newFile.txt");
		BasicFileAttributes attr;
		try {
			attr = Files.readAttributes(file, BasicFileAttributes.class);

			System.out.println("creationTime: " + attr.creationTime());
			System.out.println("lastAccessTime: " + attr.lastAccessTime());
			System.out.println("lastModifiedTime: " + attr.lastModifiedTime());

			System.out.println("isDirectory: " + attr.isDirectory());
			System.out.println("isOther: " + attr.isOther());
			System.out.println("isRegularFile: " + attr.isRegularFile());
			System.out.println("isSymbolicLink: " + attr.isSymbolicLink());
			System.out.println("size: " + attr.size());
		} catch (IOException e) {

			e.printStackTrace();
		}
	}
}
