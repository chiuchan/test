package nioIO;

import java.io.File;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.Paths;

public class ExPath {
	public static void main(String[] args) {

		FileSystem local = FileSystems.getDefault();
		System.out.println("File System: " + local);

		// create Path
		Path workspace = local.getPath("Documents and Settings", "rafa",
				"workspace");
		System.out.println("Path: " + workspace);

		Path java7 = workspace.resolve("java7Ex/src");
		System.out.println("resolve: " + java7);

		Path relativePath = java7.relativize(workspace);
		// Convert to old File Format for your legacy apps
		File file = relativePath.toFile();

		System.out.println("File:" + file);

		// Make a reference to a File
		Path src = Paths.get("/home/fred/readme.txt");
		Path dst = Paths.get("/home/fred/copy_readme.txt");
		System.out.println("src -> dest: " + src + " -> " + dst);

		// Make a reference to a path
		Path src1 = Paths.get("/home/fredSRC/");
		Path dst1 = Paths.get("/home/fredDST/");
		System.out.println("src -> dest1: " + src + " -> " + dst1);

		// Navigation /home/fredSRC -> /home/fredSRC/tmp
		Path tmpPath = src.resolve("tmp");
		System.out.println("navigation: " + tmpPath);

		// Create a relative path from src -> ..
		Path relativePath1 = tmpPath.relativize(src1);
		System.out.println("relative: " + relativePath1);
	}

}
