package nioIO;

import java.io.File;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.FileSystemException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Afisare toate fisierele cu extensile .txt si .log din directoarele radacina
 *
 *
 */
public class ExDirectory {

	public static void main(String[] args) throws IOException {

		for (Path root : FileSystems.getDefault().getRootDirectories()) {

			System.out.println("Root directory: " + root);
			try {
				DirectoryStream<Path> txtFiles = Files.newDirectoryStream(root,
						"*.{txt,log}");

				for (Path textFile : txtFiles) {
					System.out.println(textFile.getFileName());
				}

				txtFiles.close();
			} catch (FileSystemException e) {
				System.out.println("Error: " + e.getMessage());
			}
		}
		System.out.println("--------------------Before Java 7");
		afisareBefore7();
		System.out.println("--------------------After Java 7");
		afisareAfter7();

		customFilter();
	}

	public static void customFilter() {

		for (Path root : FileSystems.getDefault().getRootDirectories()) {

			System.out.println("------Root directory: " + root);
			try {
				DirectoryStream.Filter<Path> filter = new DirectoryStream.Filter<Path>() {
					public boolean accept(Path file) throws IOException {

						return (Files.isDirectory(file));

					}
				};

				DirectoryStream<Path> txtFiles = Files.newDirectoryStream(root,
						filter);

				for (Path textFile : txtFiles) {
					System.out.println(textFile.getFileName());
				}

				txtFiles.close();
			} catch (IOException e) {
				System.out.println("Error: " + e.getMessage());
			}
		}
	}

	public static void afisareBefore7() {
		File f = new File("c:/java7-trial");
		String[] names = f.list();

		// At this point Java listed all files in c:/tmp and loaded their names
		// into an array of Strings
		for (String name : names) {
			System.out.println(name);
		}
	}

	// iterate over a directory without preloading its content into memory.
	public static void afisareAfter7() {

		// Creating a DirectoryStream inside a try-with-resource block
		try (DirectoryStream<Path> ds = Files.newDirectoryStream(FileSystems
				.getDefault().getPath("c:/java7-trial"))) {
			for (Path p : ds) {

				// Iterate over the paths in the directory and print filenames
				System.out.println(p.getFileName());
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
