package nioIO;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.nio.file.attribute.BasicFileAttributeView;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.List;

public class Test {
	public static void main(String[] args) {
		String name = "testFileIn.txt";
		Path path = FileSystems.getDefault().getPath(".", name);

		try {
			// read all bytes
			byte[] filearray = Files.readAllBytes(path);

			// read lines
			System.out.println("---- Read all lines into a list ----");
			List<String> lines = Files.readAllLines(path,
					Charset.defaultCharset());
			
			for (String string : lines) {
				System.out.println("line: " + string);
			}

			// large files
			System.out.println("---- Read using buffer ----");
			BufferedReader reader = Files.newBufferedReader(path,
					Charset.defaultCharset());
			String line = null;
			while ((line = reader.readLine()) != null) {
				System.out.println(line);
			}
			
			// create new, overwrite if exists
			path = FileSystems.getDefault().getPath(".", "newFile.txt");
			String content = "abcd efg \n eee";
			
			System.out.println("---- Parsing path ----");
			path = new File("c:/Program Files/Java").toPath(); 
			int t=1;
			for (Path subPath : path) {
			  System.out.format("%"+t+"s%s%n", ' ', subPath);
			  t+=2;
			}
			 
			
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}
