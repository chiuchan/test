package nioIO;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileVisitOption;
import java.nio.file.FileVisitResult;
import java.nio.file.FileVisitor;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.EnumSet;

class Search implements FileVisitor {

	private final Path searchedFile;
	public boolean found = false;

	public Search(Path searchedFile) {
		this.searchedFile = searchedFile;
	}

	boolean search(Path file) throws IOException {
		if (file.getFileName().equals(searchedFile)) {
			System.out.println("Searched file was found: " + searchedFile
					+ " in " + file.toString());
			found = true;
			return true;
		}

		return false;
	}

	@Override
	public FileVisitResult postVisitDirectory(Object dir, IOException exc)
			throws IOException {
		System.out.println("Visited: " + (Path) dir);
		return FileVisitResult.CONTINUE;
	}

	@Override
	public FileVisitResult preVisitDirectory(Object dir,
			BasicFileAttributes attrs) throws IOException {
		return FileVisitResult.CONTINUE;
	}

	@Override
	public FileVisitResult visitFile(Object file, BasicFileAttributes attrs)
			throws IOException {
		boolean success = search((Path) file);
		if (!success) {
			return FileVisitResult.CONTINUE;
		} else {
			return FileVisitResult.TERMINATE;
		}
	}

	@Override
	public FileVisitResult visitFileFailed(Object file, IOException exc)
			throws IOException {
		return FileVisitResult.CONTINUE;
	}




	public static void main(String[] args) throws IOException {

		Path searchDir = null;
		File[] roots = File.listRoots();
		Path searchFile = Paths.get("InJava.java"); // this is the searched file
		Search go = new Search(searchFile);
		EnumSet opts = EnumSet.of(FileVisitOption.FOLLOW_LINKS);

		for (File root : roots) {
			if (!go.found) {
				searchDir = Paths.get(root.getPath());
				Files.walkFileTree(searchDir, opts, Integer.MAX_VALUE, go);
			}
		}

		if (!go.found) {
			System.out.println("The file " + searchFile + " was not found!");
		}
	}
}
