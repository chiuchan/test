// WebTrends SmartSource Data Collector Tag v10.2.36
// Copyright (c) 2012 Webtrends Inc.  All rights reserved.
// Tag Builder Version: 4.1.0.33
// Created: 2012.08.24
window.webtrendsAsyncInit=function(){
    var dcs=new Webtrends.dcs().init({
        dcsid:"dcs4r7e0x7dv0h4vbp80fwve5_8i8t",
        domain:"statse.webtrendslive.com",
        timezone:-5,
        i18n:true,
        adimpressions:true,
        adsparam:"WT.ac",
        offsite:true,
        download:true,
        downloadtypes:"xls,doc,pdf,txt,csv,zip,docx,xlsx,rar,gzip",
        javascript: true,
        onsitedoms:"psecu.com, www.psecu.com, apply.psecu.com",
        fpcdom:".psecu.com",
        plugins:{
            hm:{src:"//s.webtrends.com/js/webtrends.hm.js"}
        }
        }).track();
};
(function(){
    var s=document.createElement("script"); s.async=true; s.src="https://www.psecu.com/lib/js/webtrends/webtrends.min.js";    
    var s2=document.getElementsByTagName("script")[0]; s2.parentNode.insertBefore(s,s2);
}());


//disable the backspace and enter keys
if (typeof window.event != 'undefined')
    document.onkeydown = function()
    {
        if (event.srcElement.tagName.toUpperCase() != 'INPUT' && 
            event.srcElement.tagName.toUpperCase() != 'TEXTAREA' )
        {
            return (event.keyCode != 8 && event.keyCode != 13);
        }
        else
            return (event.keyCode != 13);
    }
else
    document.onkeypress = function(e)
    {
        if (e.target.nodeName.toUpperCase() != 'INPUT' && 
            e.target.nodeName.toUpperCase() != 'TEXTAREA' )
        {
            return (e.keyCode != 8 && e.keyCode != 13);
        }
        else
            return (e.keyCode != 13);
   }

function isAlien(a) { return isObject(a) && typeof a.constructor != 'function'; }
function isArray(a) { return isObject(a) && a.constructor == Array; }
function isBoolean(a) { return typeof a == 'boolean'; }
function isEmpty(o) {
    var i, v;
    if (isObject(o)) {
        for (i in o) {
            v = o[i];
            if (isUndefined(v) && isFunction(v)) { return false; }
        }
    }
    return true;
}
function isFunction(a) { return typeof a == 'function';}
function isNull(a) { return typeof a == 'object' && !a;}
function isNumber(a) { return typeof a == 'number' && isFinite(a);}
function isObject(a) { return (a && typeof a == 'object') || isFunction(a);}
function isString(a) { return typeof a == 'string';}
function isUndefined(a) { return typeof a == 'undefined'; } 

var isIE5Mac = (navigator.userAgent.indexOf('MSIE 5') != -1	&&	navigator.userAgent.indexOf('Mac') != -1);
var W3CDOM = (!isIE5Mac && 	document.getElementsByTagName && document.createElement);
var DHTML = (document.getElementById || document.all || document.layers);

function IsValidDate(fld)
{
    var theMonth = fld.value.substring(0, 2);
    var theDay = fld.value.substring(3, 5);
    var theYear = fld.value.substring(fld.value.length - 4, fld.value.length);

    var dt = new Date(fld.value);

    if(dt.getDate() != theDay){
        alert('Invalid Day');
        return(false);
        }
    else if(dt.getMonth() != theMonth - 1){
    //this is for the purpose JavaScript starts the month from 0
        alert('Invalid Month');
        return(false);
        }
    else if(dt.getFullYear() != theYear){
        alert('Invalid Year');
        return(false);
        }
    
    return(true);
 }

function isNumeric(fld, e) {     
    var key = '';
    var strCheck = '0123456789';
    
    // set whichCode to code of key pressed (key code)
    var whichCode = e.which;
    if(whichCode == null || whichCode.length == 0)
        whichCode = e.keyCode;
    
    // Enter, backspace and arrow keys are OK
    if (whichCode == 13 || whichCode == 8 || 
        whichCode == 0)
        return true;  

    // Get key value from key code (sets 'key' to character rep'd by key code)
    key = String.fromCharCode(whichCode);  

    if ((strCheck.indexOf(key) == -1)) 
    {
        // Not a valid key
        alert('Use numbers only.');
        fld.focus();
        return false;
    }

    return true;
}

function isCurrency(fld, e) {     
    var key = '';
    var strCheck = '0123456789.';
    
    // set whichCode to code of key pressed (key code)
    var whichCode = e.which;
    if(whichCode == null || whichCode.length == 0)
        whichCode = e.keyCode;
    
    // Enter, backspace and arrow keys are OK
    if (whichCode == 13 || whichCode == 8 || 
        whichCode == 0) 
        return true;  

    // Get key value from key code (sets 'key' to character rep'd by key code)
    key = String.fromCharCode(whichCode);  

    if ((strCheck.indexOf(key) == -1)) 
    {
        // Not a valid key
        alert('Use numbers only.');
        fld.focus();
        return false;
    }

    return true;
}

function verifyCurrency(field)
{ 
    var amount = field.value;

    //look for more than 1 decimal
    if(amount.indexOf(".") != amount.lastIndexOf("."))
    {
        alert("Only 1 decimal point is allowed");
        field.focus();
    }
}

function verifyCurrencyAmount(field, minAmount)
{ 
    var amount = field.value;

    //verify the amount entered is greater than the min amount
    if(amount <= minAmount)
    {
        alert("Please enter an amount greater than $" + minAmount);
        field.focus();
    }
}

function verifyOtherInc(field)
{
    var othIncAmt = field.value;
    
    if(othIncAmt.length > 0 && othIncAmt < 1000)
    {
        alert("You have entered $" + othIncAmt + " as other income.  Press Continue if this is the correct amount.");
    }
}

function verifySalary(field)
{
    var theSalary = field.value;
    
    if(theSalary != "")
    {
        if(theSalary < 2000)
        {
            alert("You have indicated that your salary is $" + theSalary + ".  Please verify that your annual gross salary was correctly entered.");
        }
        else if(theSalary < 3000)
        {
            alert("You have indicated that you make $" + theSalary + " per year.  If this is correct, " +
                "press Continue at the bottom of the page to proceed.  If this amount is incorrect please enter your income as x,xxx.xx.");
        }
    }
}

function verifyAdvanceAmount(field)
{
    var advanceMin = 500;
    var advanceAmount = parseFloat(field.value);
    var loanAmount = 0.00;

    if(getObj("anLoanAmt").value != "")
        loanAmount = parseFloat(getObj("anLoanAmt").value);

    if(advanceAmount > loanAmount)
    {
        alert("You have entered an advance amount that is greater than your requested loan amount.  " + 
            "Please enter a new advance amount");
        field.focus();
    }
    else if(advanceAmount < advanceMin)
    {
        alert("According to PSECU policy, the minimum amount for an advance is $500.  " + 
            "Please enter a new advance amount.");
        field.focus();
    }
}

function verifyRetiredFields(pensionIdStr, disabilityIdStr, othIncTableIdStr)
{
    var pension = getObj(pensionIdStr);
    var disability = getObj(disabilityIdStr);
    var othIncTable = getObj(othIncTableIdStr);
    var success = true;

    if (pension.value.length == 0 && disability.value.length == 0)
        success = confirm("You have not entered any income.  If this is correct, press Ok, otherwise press Cancel to enter any income you may have.");
    else
    {
        var total = 0.00;
        if (pension.value.length > 0)
            total += parseFloat(pension.value);
        if (disability.value.length > 0)
            total += parseFloat(disability.value);

        if (total < 3000.00)
        {
            success = confirm("You have indicated that you make $" + total.toFixed(2) + " per year.  If this is correct, press Ok, otherwise press Cancel to enter any more income you may have.");
        }
    }

    return success;
}

function verifyMaxLoanAmount(field)
{ 
    var maxAmount = 1000000;
    var maxAmountStr = "";
    var validSigReFiAmount = 20000;
    var loanAmount = parseFloat(field.value);
    var loanAmountTemp = loanAmount;
    var ltv = 0;
    var theScen = QString("scen");
    var errorStr = null;
    
    if(theScen == "heloc2" || theScen == "homeeq2" || theScen == "preapp2")
    {
        maxAmountStr = getObj("homeEqMaxLoanlbl").innerHTML;
        //remove the comma if it exist
        maxAmountStr = maxAmountStr.replace(/,/g, "");
        maxAmount = parseFloat(maxAmountStr);
        

        //calculate the ltv        
		loanAmountTemp += parseFloat(getObj("phyXstgLienTemp").innerHTML);

		var estVal = parseFloat(getObj("phyValEstTemp").innerHTML);
		if(estVal > 0)
		{
			ltv = (loanAmountTemp / estVal) * 100;
		}
    }
    else if(theScen == "busRESecTerm2" || theScen == "busRESecLOC2")
    {
        maxAmountStr = getObj("homeEqMaxLoanlbl").innerHTML;
        //remove the comma if it exist
        maxAmountStr = maxAmountStr.replace(/,/g, "");
        maxAmount = parseFloat(maxAmountStr);
    }
    else if(theScen == "busUnsecTerm")
    {
        maxAmount = 50000.00;
    }
    else if(theScen == "sig")
    {
        var el = getObj("radSigType1");
        if(el.checked)
        {
            maxAmount = parseFloat(getObj("newSigLoanMax").innerHTML);
        }
        else
            maxAmount = 20000;
    }
    else if(theScen == "equipment")
    {
        maxAmount = 200000;
    }
   
    if(loanAmount > maxAmount)
    {
        if(theScen == "sig")
         {
            errorStr = "PSECU Signature Loans are only available in amounts up to $20,000.00.  "  + 
            "Please enter a requested loan amount less than $" + maxAmount.toFixed(2);
            //field.focus();
        }
        else if(theScen == "heloc2" || theScen == "homeeq2" || theScen == "preapp2")
        {
            errorStr = "Based upon the information you entered, you can apply for a loan up to $" + 
                maxAmount.toFixed(2) + ".  You entered an amount requested that is greater than this " + 
                "limit.  Please enter an amount requested that is equal to or less than this limit.";
            //field.focus();
        }
        else if(theScen == "busRESecTerm2" || theScen == "busRESecLOC2")
        {
            errorStr = "Based upon the information you entered, you can apply for a loan up to $" + 
                maxAmount.toFixed(2) + ".  You entered an amount requested that is greater than this " + 
                "limit.  Please enter an amount requested that is equal to or less than this limit.";
            //field.focus();
        }
        else if(theScen == "equipment")
        {
            errorStr = "You have requested a $" + loanAmount.toFixed(2) + " Equipment Loan. Equipment Loans are only available in amounts up to $200,000.00. " + 
                "Please update the requested loan amount.";
            //field.focus();
        }
        else if(theScen == "busUnsecTerm")
        {
            errorStr = "You have requested a $" + loanAmount.toFixed(2) + " Unsecured Term Loan. Unsecured Term Loans are only available in amounts up to $50,000.00." + 
                "Please update the requested loan amount.";
            //field.focus();
        }   
        else
            alert("You have requested a $" + loanAmount.toFixed(2) + " Auto Loan. Auto Loans are only available in amounts up to $100,000.00." + 
                "Please update the requested loan amount.");
    }
    else if(theScen == "sig" && loanAmount < 1000)
    {
        errorStr = "The minimum Signature Loan amount is $1,000.00.  " +
            "Please enter a requested loan amount greater than $1,000.00";
        //field.focus();
    }
    else if(theScen == "heloc2" && ltv > 90)
    {
        errorStr = "According to PSECU policy, the maximum amount for an equity loan application is up to 90% " + 
            "of the LTV calculation.  With the current requested loan amount, the LTV is: " + ltv.toFixed(2) + "%  " +
            "Please reduce the requested loan amount";
        //field.focus();
    }
    else if((theScen == "busRESecTerm2" || theScen == "busRESecLOC2") && ltv > 80)
    {
        errorStr = "According to PSECU policy, the maximum amount for a loan application is up to 80% " + 
            "of the LTV calculation.  With the current requested loan amount, the LTV is: " + ltv.toFixed(2) + "%  " +
            "Please reduce the requested loan amount";
        //field.focus();
    }
    else if((theScen == "heloc2" || theScen == "homeeq2" || theScen == "preapp2") && loanAmount < 5000)
    {
        errorStr = "According to PSECU policy, the minimum amount for an equity loan application is $5,000.  " + 
            "You requested a loan amount less than this.  Please enter an amount you want to apply for " + 
            "that is at least $5,000.";
        //field.focus();
    }
    else if((theScen == "busRESecTerm2" || theScen == "busRESecLOC2") && loanAmount < 5000)
    {
        errorStr = "According to PSECU policy, the minimum amount for a loan application is $5,000.  " + 
            "You requested a loan amount less than this.  Please enter an amount you want to apply for " + 
            "that is at least $5,000.";
        //field.focus();
    }
    else if(theScen == "auto" || theScen == "busVehicle")
    {
        if (loanAmount >= 1000 && loanAmount < 3000) 
        {
            show("kelleyTrademark");
            if(theScen == "busVehicle")
            {
                alert("You have requested an amount less than $3,000.  Please be advised that the vehicle you " + 
                    "intend to purchase must have a retail value of at least $3,000.  If the vehicle does not " + 
                    "have a retail value of at least $3,000, PSECU will not finance the vehicle as an Auto Loan.  " +
                    "PSECU values vehicles using Kelley Blue Book\u00AE as well as other authorized guides.  To obtain " + 
                    "a retail value for the vehicle you intend to purchase, please visit the Auto Buying Center " + 
                    "at PSECU.com or contact the Business Services Department at 1-800-237-7328, option 6, extension 3875. If the requested amount is correct, " +
                    "press Continue at the bottom of the page.  If the requested amount is incorrect please enter a new requested loan amount.");
            }
            else
            {
                    alert("You have requested an amount less than $3,000.  Please be advised that the vehicle you " + 
                        "intend to purchase must have a retail value of at least $3,000.  If the vehicle does not " + 
                        "have a retail value of at least $3,000, PSECU will not finance the vehicle as an Auto Loan.  " +
                        "PSECU values vehicles using Kelley Blue Book\u00AE as well as other authorized guides.  To obtain " + 
                        "a retail value for the vehicle you intend to purchase, please visit the Auto Buying Center " + 
                        "at PSECU.com or contact the Loan Dept at 800-LOAN-555. If the requested amount is correct, " + 
                        "press Continue at the bottom of the page.  If the requested amount is incorrect please enter a new requested loan amount.");
            }
        }
        else if (loanAmount < 1000) 
        {
            show("kelleyTrademark");
            if(theScen == "busVehicle")
            {
                alert("You have requested a loan amount less than $1,000.  The minimum Business Auto Loan at PSECU is " + 
                    "$1,000.  Please be advised that the business vehicle you intend to purchase must have a retail " + 
                    "value of at least $3,000.  If the vehicle does not have a retail value of at least $3,000, " + 
                    "PSECU will not finance the vehicle as a Business Auto Loan.  PSECU values vehicles using Kelley " +
                    "Blue Book\u00AE as well as other authorized guides.  To obtain a retail value for the vehicle " + 
                    "you intend to purchase, please visit the Auto Buying Center at PSECU.com or contact the " + 
                    "Business Services Dept at 800-LOAN-555. Press Return and enter a new requested loan amount.");
           }
           else
           {
                alert("You have requested a loan amount less than $1,000.  The minimum Auto Loan at PSECU is " + 
                    "$1,000.  Please be advised that the vehicle you intend to purchase must have a retail " + 
                    "value of at least $3,000.  If the vehicle does not have a retail value of at least $3,000, " + 
                    "PSECU will not finance the vehicle as an Auto Loan.  PSECU values vehicles using Kelley " +
                    "Blue Book\u00AE as well as other authorized guides.  To obtain a retail value for the vehicle " + 
                    "you intend to purchase, please visit the Auto Buying Center at PSECU.com or contact the " + 
                    "Loan Dept at 800-LOAN-555. Press Return and enter a new requested loan amount.");
           }

        }
    }
    else if (theScen == "rec") 
    {
        show("kelleyTrademark");
        if(loanAmount >= 3000 && loanAmount < 3333)
        {
            alert("You have requested an amount less than $3,333.00.  Please be advised that the " + 
                "recreational vehicle you intend to purchase must have a retail value of at least " + 
                "$3,333.00.  If the vehicle does not have a retail value of at least $3,333.00, PSECU " + 
                "will not finance the vehicle as a Recreational Vehicle Loan.  PSECU values vehicles " +
                "using Kelley Blue Book\u00AE as well as other authorized guides.  To obtain a retail value " + 
                "for the recreational vehicle you intend to purchase, contact the Loan Dept at " + 
                "800-LOAN-555. If the requested amount is correct, press Continue at the bottom of the page.  If the requested " + 
                "amount is incorrect please enter a new requested loan amount.");
        }
        else if(loanAmount < 3000)
        {
            alert("You have requested a loan amount less than $3000.  The minimum Recreational Vehicle " + 
                "Loan at PSECU is $3,000.  Please be advised that the recreational vehicle you intend to " + 
                "purchase must have a retail value of at least $3,333.00.  If the vehicle does not have a " + 
                "retail value of at least $3,333, PSECU will not finance the vehicle as a recreational " +
                "vehicle loan.  PSECU values vehicles using Kelley Blue Book\u00AE as well as other authorized " + 
                "guides.  To obtain a retail value for the vehicle you intend to purchase, please contact " + 
                "the Loan Dept at 800-LOAN-555. Please enter a new requested loan amount.");
        }
    }

    if(errorStr != null)
    {
        getObj("anLoanAmtError").value = errorStr;
        alert(errorStr);
        field.focus();
    }
    else
        getObj("anLoanAmtError").value = "";
}

function setTerm(field)
{
    var theScen = QString("scen");
    var loanAmount = parseFloat(field.value);

    cloneDropDown("selTerm");
    getObj("fake_selTerm").options.length = 0;
    addOption("fake_selTerm", "", "");
    if (theScen != "auto" && theScen != "rec" && theScen != "busVehicle" && theScen != "equipment")
        addOption("fake_selTerm", "1 year", "1");

    addOption("fake_selTerm", "2 years", "2");
    addOption("fake_selTerm", "3 years", "3");

    if (theScen == "auto" || theScen == "busVehicle") {
        if (loanAmount >= 6000)
            addOption("fake_selTerm", "4 years", "4");
        if (loanAmount >= 8000)
            addOption("fake_selTerm", "5 years", "5");
        if (loanAmount >= 12000)
            addOption("fake_selTerm", "6 years", "6");
        if (loanAmount >= 20000)
            addOption("fake_selTerm", "7 years", "7");
        if (loanAmount >= 40000 && theScen == "auto") {
            addOption("fake_selTerm", "8 years", "8");
            addOption("fake_selTerm", "9 years", "9");
            addOption("fake_selTerm", "10 years", "10");
        }
    }
    else if (theScen == "rec") {
        if (loanAmount >= 5000)
            addOption("fake_selTerm", "4 years", "4");
        if (loanAmount >= 8000)
            addOption("fake_selTerm", "5 years", "5");
        if (loanAmount >= 15000) {
            addOption("fake_selTerm", "6 years", "6");
            addOption("fake_selTerm", "7 years", "7");
        }
    }
    else if (theScen == "equipment") {
        if (loanAmount >= 6000)
            addOption("fake_selTerm", "4 years", "4");
        if (loanAmount >= 8000)
            addOption("fake_selTerm", "5 years", "5");
        if (loanAmount >= 12000)
            addOption("fake_selTerm", "6 years", "6");
        if (loanAmount >= 20000)
            addOption("fake_selTerm", "7 years", "7");
    }
    else if (theScen == "busUnsecTerm") {
        getObj("fake_selTerm").options.length = 0;
        addOption("fake_selTerm", "", "");
        addOption("fake_selTerm", "5 years", "5");
    }
    else if (theScen == "busRESecTerm2") {
        getObj("fake_selTerm").options.length = 0;
        addOption("fake_selTerm", "", "");
        addOption("fake_selTerm", "5 years", "5");
        if (loanAmount >= 50000)
            addOption("fake_selTerm", "10 years", "10");

        changeLabel("pnlHomeEqTerm", "Loan Term: <span class='required'>*</span>");
        getObj("anTerm").errorText = "Loan Term";
    }

}

function reselectTerm()
{
    var termTemp = getObj("selTerm").selectedIndex;
    termTemp = getObj("selTerm").options[termTemp].value;
    setTerm(getObj("anLoanAmt"));
    
    for (var x = 0; x < getObj("selTerm").options.length; x++) 
    {   
        if (getObj("selTerm").options[x].value == termTemp) 
            getObj("selTerm").options[x].selected = true;   
    } 
}

function reselectHETerm()
{
    var termTemp = getObj("anTerm").selectedIndex;
    termTemp = getObj("anTerm").options[termTemp].value;
    setTerm(getObj("anLoanAmt"));
    
    for (var x = 0; x < getObj("anTerm").options.length; x++) 
    {   
        if (getObj("anTerm").options[x].value == termTemp) 
            getObj("anTerm").options[x].selected = true;   
    }
}


function syncDDSelection(dd1Id, dd2Id) {
    var dd1 = getObj(dd1Id);
    var dd2 = getObj(dd2Id); 
    var dd1Length = dd1.length;
    var dd2Length = dd2.length;
    for (var i = 0; i < dd1Length; i++) {
        if (dd1.options[i].selected == true) {
            for (var j = 0; j < dd2Length; j++) {
                if (dd2.options[j].value == dd1.options[i].value) {
                    dd2.options[j].selected = true;
                }
            }
        }
    }
}


function cloneDropDown(ddl) {
    var orgDropDownList = getObj(ddl);
    if (orgDropDownList) {
        if (document.getElementById("fake_" + orgDropDownList.id) == null) {
            var fakeDropDownList = orgDropDownList.cloneNode(true);
            fakeDropDownList.id = "fake_" + orgDropDownList.id
            orgDropDownList.style.display = "none";
            orgDropDownList.parentNode.appendChild(fakeDropDownList);

            addEvent(fakeDropDownList, "change", function () {
                syncDDSelection(fakeDropDownList.id, orgDropDownList.id);
                if (document.createEvent) {
                    var changeEvent = document.createEvent("HTMLEvents");
                    changeEvent.initEvent('change', true, false);
                    orgDropDownList.dispatchEvent(changeEvent);
                }
                else {
                    orgDropDownList.fireEvent("onchange");
                }
            }, false);
        }
    }
}




function populateOthIncDDL(empStatIdStr, othIncSoruceIdStr) 
{
    getObj(othIncSoruceIdStr).options.length = 0;
    addOption(othIncSoruceIdStr, "", "");
    addOption(othIncSoruceIdStr, "Alimony/Child Support Income", "F7");
    addOption(othIncSoruceIdStr, "Automobile/Expense Account Income", "M2");
    addOption(othIncSoruceIdStr, "Bonuses", "08");
    addOption(othIncSoruceIdStr, "Commission", "10");
    addOption(othIncSoruceIdStr, "Dividends/Interest", "17");
    addOption(othIncSoruceIdStr, "Foster Care", "M3");
    addOption(othIncSoruceIdStr, "Other Income", "45");
    addOption(othIncSoruceIdStr, "Overtime", "09");
    addOption(othIncSoruceIdStr, "Part Time/Second Job", "P/T OR SECOND JOB");

    var el = getObj(empStatIdStr);

    //retired
    if (el.options[el.selectedIndex].value == "Retired")
    {
        addOption(othIncSoruceIdStr, "Rental Income", "Rental Income");
        addOption(othIncSoruceIdStr, "Trust Income", "F9");
        addOption(othIncSoruceIdStr, "VA Benefits (non-educational)", "M4");
    }
    else
    {
        addOption(othIncSoruceIdStr, "Pension/Retirement Income", "41");
        addOption(othIncSoruceIdStr, "Rental Income", "Rental Income");
        addOption(othIncSoruceIdStr, "Social Security/Disability Income", "42");
        addOption(othIncSoruceIdStr, "Trust Income", "F9");
        addOption(othIncSoruceIdStr, "VA Benefits (non-educational)", "M4");
    }

}

function populateMortgageOthIncDDL(empStatIdStr, othIncSoruceIdStr)
{
    getObj(othIncSoruceIdStr).options.length = 0;
    addOption(othIncSoruceIdStr, "", "");
    addOption(othIncSoruceIdStr, "Alimony/Child Support Income", "F7");
    addOption(othIncSoruceIdStr, "Automobile/Expense Account Income", "M2");
    addOption(othIncSoruceIdStr, "Bonuses", "08");
    addOption(othIncSoruceIdStr, "Commission", "10");
    addOption(othIncSoruceIdStr, "Dividends/Interest", "17");
    addOption(othIncSoruceIdStr, "Employment Related Assets", "EA");
    addOption(othIncSoruceIdStr, "Foreign Income", "FI");
    addOption(othIncSoruceIdStr, "Foster Care", "M3");
    addOption(othIncSoruceIdStr, "Military Base Pay", "F1");
    addOption(othIncSoruceIdStr, "Military Clothing Allowance", "02");
    addOption(othIncSoruceIdStr, "Military Combat Pay", "F5");
    addOption(othIncSoruceIdStr, "Military Flight Pay", "F2");
    addOption(othIncSoruceIdStr, "Military Hazard Pay", "F3");
    addOption(othIncSoruceIdStr, "Military Overseas Pay", "F4");
    addOption(othIncSoruceIdStr, "Military Prop Pay", "03");
    addOption(othIncSoruceIdStr, "Military Quarters Allowance", "04");
    addOption(othIncSoruceIdStr, "Military Rations Allowance", "07");
    addOption(othIncSoruceIdStr, "Military Variable Housing Allowance", "F6");
    addOption(othIncSoruceIdStr, "Notes Receivable/Installment", "F8");
    addOption(othIncSoruceIdStr, "Other Income", "45");
    addOption(othIncSoruceIdStr, "Overtime", "09");
    addOption(othIncSoruceIdStr, "Part Time/Second Job", "P/T OR SECOND JOB");

    var el = getObj(empStatIdStr);

    //retired
    if (el.options[el.selectedIndex].value == "Retired")
    {
        addOption(othIncSoruceIdStr, "Real Estate/Mortgage Differential", "30");
        addOption(othIncSoruceIdStr, "Royalty Payment", "RP");
        addOption(othIncSoruceIdStr, "Seasonal Income", "SE");
        addOption(othIncSoruceIdStr, "Subject Property Net Cash Flow", "SI");
        addOption(othIncSoruceIdStr, "Temporary Leave", "TL");
        addOption(othIncSoruceIdStr, "Tip Income", "TI");
        addOption(othIncSoruceIdStr, "Trust Income", "F9");
        addOption(othIncSoruceIdStr, "Unemployment/Welfare", "M1");
        addOption(othIncSoruceIdStr, "VA Benefits (non-educational)", "M4");
    }
    else
    {
        addOption(othIncSoruceIdStr, "Pension/Retirement Income", "41");
        addOption(othIncSoruceIdStr, "Real Estate/Mortgage Differential", "30");
        addOption(othIncSoruceIdStr, "Royalty Payment", "RP");
        addOption(othIncSoruceIdStr, "Seasonal Income", "SE");
        addOption(othIncSoruceIdStr, "Social Security/Disability Income", "42");
        addOption(othIncSoruceIdStr, "Subject Property Net Cash Flow", "SI");
        addOption(othIncSoruceIdStr, "Temporary Leave", "TL");
        addOption(othIncSoruceIdStr, "Tip Income", "TI");
        addOption(othIncSoruceIdStr, "Trust Income", "F9");
        addOption(othIncSoruceIdStr, "Unemployment/Welfare", "M1");
        addOption(othIncSoruceIdStr, "VA Benefits (non-educational)", "M4");
    }
}

function resetHEReplaymentDDL(loanType)
{
    var temp = getObj("anRePmtMthEq").selectedIndex;
    temp = getObj("anRePmtMthEq").options[temp].value;
    
    if(loanType != "busRESecTerm2" && loanType != "busRESecLOC2")
        getObj("anRePmtMthEq").remove(3);
    
    for (var x = 0; x < getObj("anRePmtMthEq").options.length; x++) 
    {   
        if (getObj("anRePmtMthEq").options[x].value == temp) 
            getObj("anRePmtMthEq").options[x].selected = true;   
    } 
}

function resetLoanPurposeDDL(loanType) {

    var temp = getObj("anLoanPur").selectedIndex;
    temp = getObj("anLoanPur").options[temp].value;

    cloneDropDown("anLoanPur");

    getObj("fake_anLoanPur").options.length = 0;
    addOption("fake_anLoanPur", "", "");

    if(loanType == "busRESecTerm2" || loanType == "busRESecLOC2")
    {
        addOption("fake_anLoanPur", "Refinance", "3");
        addOption("fake_anLoanPur", "Repairs", "35");
        addOption("fake_anLoanPur", "Working Capital", "37");
        addOption("fake_anLoanPur", "Purchases", "38");
        addOption("fake_anLoanPur", "Other", "27");
    }
    else
    {
        addOption("fake_anLoanPur", "Home Improvement", "2");
        addOption("fake_anLoanPur", "Refinance", "3");
        addOption("fake_anLoanPur", "Debt Consolidation", "34");
        addOption("fake_anLoanPur", "Other", "27");
    }

    for (var x = 0; x < getObj("fake_anLoanPur").options.length; x++) 
    {
        if (getObj("fake_anLoanPur").options[x].value == temp)
            getObj("fake_anLoanPur").options[x].selected = true;   
    } 
}


function verifyMaxCreditLimit(field)
{ 
    var theScen = QString("scen");
    var maxAmount = 0.00;
    var currentLoc = 0.00;

    if(theScen == "busUnsecLOC")
    {
        maxAmount = 50000.00;
        //this needs to be a string here so that the 'replace' method below will not throw an exception
        currentLoc = "5000.00";
    }
    else
    {
        maxAmount = 20000.00;
        currentLoc = getObj("maxLoanAmtLbl").innerHTML;
    }

    //remove the comma if it exist
    currentLoc = currentLoc.replace(/,/g, "");    

    var loanAmount = parseFloat(field.value);
    
    if((theScen == "psl" || theScen == "visa" || theScen == "combo") && getObj("totalCreditLimitLbl").innerHTML.length > 0)
    {
        var totalCredLimit = parseFloat(getObj("totalCreditLimitLbl").innerHTML);
        if(totalCredLimit + (loanAmount - currentLoc) > 20000)
        {
            alert("The maximum Credit Limit allowed between all PSECU accounts is: $20,000");
        }
    }
    
    if(loanAmount > maxAmount)
    {
        if(theScen == "psl")
        {
            alert("You have requested an Personal Service Loan limit greater than $20,000.00.  " +
                "PSECU offers Personal Service Loan Credit Limits up to $20,000.00.  " + 
                "Please enter a new requested loan amount.");
        }
        else if(theScen == "visa" || theScen == "busVisa")
        {
            alert("You have requested a Visa limit greater than $20,000.00.  PSECU offers Visa Loan " + 
                "Credit Limits up to $20,000.00.  Please enter a new requested loan amount.");
        }
        else
            alert("The maximum Credit Limit allowed is: $" + maxAmount.toString());

        field.focus();
    }
    else if(loanAmount < currentLoc)
    {
        if(theScen == "psl")
        {
            alert("You have requested a Personal Service Loan (PSL) Line of Credit that is less than your " + 
                "existing PSL Line of Credit.  You must apply for a line of credit that is greater than " + 
                "your existing line of credit. Please enter a new requested loan amount");
        }
        else if(theScen == "visa" || theScen == "busVisa")
        {
            alert("You have requested a Visa Line of Credit that is less than your existing Visa Line of " + 
                "Credit.  You must apply for a line of credit that is greater than your existing line of " + 
                "credit.  Please enter a new requested loan amount.");
        }
        else
            alert("The minimum Credit Limit allowed is: $" + currentLoc.toString());
        
        field.focus();
    }
    else if(loanAmount == currentLoc)
    {
        if(theScen == "psl")
        {
            alert("You have requested a Personal Service Loan (PSL) Line of Credit that is the same as " + 
                "your existing PSL Line of Credit.  Please enter a new requested loan amount.");
        }
        else if(theScen == "visa" || theScen == "busVisa")
        {
            alert("You have requested a Visa Line of Credit that is the same as your existing Visa Line of " + 
                "Credit.  Please enter a new requested loan amount.");
        }
        else
        {
            alert("You have requested a Personal Service Loan (PSL)/Visa Line of Credit that is the same as your existing PSL/Visa Line of Credit. Please enter a new requested loan amount.");
            field.focus();
        }
    }
    else if(loanAmount < 500.00)
    {
        if(theScen == "psl")
        {
            alert("You have requested a Personal Service Loan (PSL) Line of Credit that is less than $500.00.  " +
                "You must apply for a line of credit that is greater than " + 
                "$500.00. Please enter a new requested loan amount");
        }
        else if(theScen == "visa" || theScen == "busVisa")
        {
            alert("You have requested a Visa Line of Credit that is less than $500.00.  " + 
                "You must apply for a line of credit that is greater than $500.00.  " + 
                "Please enter a new requested loan amount.");
        }
        else
            alert("The minimum Credit Limit allowed is: $500.00");

        field.focus();
    }
    
}

function verifyFieldLength(field, theLength)
{ 
    var theField = field.value;

    if(theField.length > 0 && theField.length < theLength)
    {
        alert(" Field length must be " + theLength + " digits long");
        field.focus();
    }
}

function verifyYear(field)
{ 
    var year = field.value;
    var theDate = Date();

    if(year.length < 4)
    {
        alert(" Year must be 4 digits long");
        field.focus();
        return false;
    }

    theDate = theDate.substring(theDate.length - 4, theDate.length);
    if(year > theDate)
    {
        alert(" Invalid Year.");
        field.focus();
        return false;
    }

    return true;
}

function verifyPhoneNumber(field)
{ 
    //check for 555
    if(field.value == "555")
    {
        alert(" 555 is an invalid phone number");
        field.focus();
        return false;
    }

    return true;
}

function formatDate(field, e)
{
    var key = '';
    var strCheck = '0123456789';
    
    // set whichCode to code of key pressed (key code)
    var whichCode = e.which;
    if(whichCode == null || whichCode.length == 0)
        whichCode = e.keyCode;
        
    // Enter (13) is OK, added tab (0) and backspace (8) for firefox compatibility
    if (whichCode == 13 || whichCode == 0 || whichCode == 8) 
        return true;  

    // Get key value from key code (sets 'key' to character rep'd by key code)
    key = String.fromCharCode(whichCode);  
    if ((strCheck.indexOf(key) == -1)) 
    {
        // Not a valid key
        alert('Use numbers only.');
        field.focus();
        return false;
    }
    else
    {
        var dateStr = field.value;
        if(dateStr.length == 1 || dateStr.length == 4)
        {
            field.value = dateStr + key + "/";
            return false;
        }
    }

    return true;
}

function checkEmail(field) {
    var eaddr = (field.value).toUpperCase();
    if (eaddr.length > 0) {
        if (eaddr.indexOf("@") < 1) {
            alert("       Invalid email address."
           + "\rPlease verify username and '@' sign.");
        }
        else if ((eaddr.indexOf(".COM") < 3) && (eaddr.indexOf(".ORG") < 3)
          && (eaddr.indexOf(".GOV") < 3) && (eaddr.indexOf(".NET") < 3)
          && (eaddr.indexOf(".US") < 3) && (eaddr.indexOf(".MIL") < 3)
          && (eaddr.indexOf(".EDU") < 3) && (eaddr.indexOf(".BIZ") < 3)
          && (eaddr.indexOf(".CA") < 3) && (eaddr.indexOf(".INFO") < 3) && (eaddr.indexOf("@STATE.PA.US")<3)) {
            alert("                Invalid email address."
           + "\r        Please verify domain name & suffix."
           + "\r(For example: *.com, *.net, *.org, *.gov, *.mil, .edu, .biz, .ca, .info or state.pa.us)");
            field.focus();
        }
    }
}
 
function showSaveSuccessAlert()
{
    alert("The loan application has been successfully saved.");
}

function getInternetExplorerVersion()
{
  var browserVersion = -1; // Return value assumes failure.
  if (navigator.appName == 'Microsoft Internet Explorer')
  {
    var ua = navigator.userAgent;
    var re  = new RegExp("MSIE ([0-9]{1,}[\.0-9]{0,})");
    if (re.exec(ua) != null)
      browserVersion = parseFloat( RegExp.$1 );
  }
  
  return browserVersion;
}

// Checks all fields on a form for 'empty string'.
//
function checkAll()
{
    var pa = document.body;
    var A = null;
    var L = null;
    var emptyStr = "";
    var genericError = " is a required field<br/>";
    var errorFound = false;
    var errorStr = "";
    var brStr = "<br/>";
    var pnl = null;
    var lbl = null;
    var lblId = null;
    var lblFound = false;
    var labelStr = "label";
    var errorLabelClassStr = 'errorLabel';
    var trueStr = "true";
    var mieStr = "Microsoft Internet Explorer";
    var inputStr = 'input';
    var selectStr = 'select'
    var verifyStr = 'verify';
    var isRequiredStr = 'isRequired';
    var divNameStr = 'divName';
    var errorTextStr = 'errorText';
    var errorClassStr = 'errorClass';
    var classStr = 'class';
    var multiPartStr = 'multiPart';
    var defaultClassStr = 'defaultClass';
    var errorArray = new Array();
    var browserVersion = getInternetExplorerVersion();

    for (var x = 0; x <= 1; x++)
    {
        if (x == 0)
        {
            A = pa.getElementsByTagName(inputStr);
            L = A.length;
        }
        else
        {
            A = pa.getElementsByTagName(selectStr);
            L = A.length;
        }

        //loop through all of the elements
        for (var i = 0; i < L; i++)
        {
            lblFound = false;
            
            if(browserVersion > -1 && browserVersion < 9)
            {
                if (A[i].verify && A[i].isRequired == trueStr && 
                    A[i].value.length == 0)
                {
                    errorFound = true;
                    
                    //set the label to a red color
                    if(A[i].divName != null)
                    {
                        if (isString(A[i].divName)) 
	                       pnl = getObj(A[i].divName);
                    	
	                    lbl = pnl.getElementsByTagName(labelStr);
	                    if (lbl.length > 0)
		                    lbl = lbl[0];
                    	
	                    if(A[i].errorClass != null)
	                        lbl.className = A[i].errorClass;
	                    else
	                        lbl.className = errorLabelClassStr;
	                    
	                    if(lbl.multiPart != null)
	                        errorArray.push(lbl.id);
	                }

	                if (A[i].errorText != null && A[i].errorText.length > 0) {
////	                    focusStr = "onclick=\"+document.getElementById('" + A[i].id + "').focus();\"";
////	                    errorStr += "<li style='margin:0px;'" + focusStr + ">" + A[i].errorText + "</li>";
	                    errorStr += A[i].errorText + brStr;
	                }
	                else {
////	                    errorStr += "<li style='margin:0px;'>" + A[i].id + genericError + "</li>";
	                    errorStr += A[i].id + genericError;
	                }
                }
                else 
                {
                    //set the label back to normal
                    if(A[i].divName != null)
                    {
                        if (isString(A[i].divName)) 
	                       pnl = getObj(A[i].divName);
                    	
	                    lbl = pnl.getElementsByTagName(labelStr);
	                    if (lbl.length > 0)
		                    lbl = lbl[0];
                    	
                    	if(lbl.multiPart == null)
                    	{
	                        if(A[i].defaultClass != null)
	                            lbl.className = A[i].defaultClass;
	                        else
	                            lbl.className = emptyStr;
                        }
                        else
                        {
                            for(var index = 0; index < errorArray.length && !lblFound; index++)
                            {
                                lblId = errorArray[index];
                                if(lblId == lbl.id)
                                    lblFound = true;                            
                            }
                            
                            if(!lblFound)
                            {
                                if(A[i].defaultClass != null)
	                                lbl.className = A[i].defaultClass;
	                            else
	                                lbl.className = emptyStr;
                            }
                        }
	                }
                }
            }
            else
            {
               if (A[i].getAttribute(verifyStr) == trueStr && A[i].getAttribute(isRequiredStr) == trueStr && 
                    A[i].value.length == 0)
                {
                    errorFound = true;
                    
                    //set the label to a red color
                    if(A[i].getAttribute(divNameStr) != null)
                    {
                        if (isString(A[i].getAttribute(divNameStr))) 
	                       pnl = getObj(A[i].getAttribute(divNameStr));
                    	
	                    lbl = pnl.getElementsByTagName(labelStr);
	                    if (lbl.length > 0)
		                    lbl = lbl[0];

                        if(A[i].getAttribute(errorClassStr) != null)
        					lbl.className = A[i].getAttribute(errorClassStr);
	                    else
                            lbl.className = errorLabelClassStr;
    	                    
    	                if(lbl.getAttribute(multiPartStr) != null)
	                        errorArray.push(lbl.id);
	                }


    	            if (A[i].getAttribute(errorTextStr) != null && A[i].getAttribute(errorTextStr).length > 0) {
////    	                focusStr = "onclick=\"+document.getElementById('" + A[i].id + "').focus();\"";
////    	                errorStr += "<li style='margin:0px;'" + focusStr + ">" + A[i].getAttribute(errorTextStr) + "</li>";
	                    errorStr += A[i].getAttribute(errorTextStr) + brStr;
	                }
    	            else {
////    	                errorStr += "<li style='margin:0px;'>" + A[i].id + genericError + "</li>";
	                    errorStr += A[i].id + genericError;
	                }
                }
                else
                {
                    //set the label to normal
                    if(A[i].getAttribute(divNameStr) != null)
                    {
                        if (isString(A[i].getAttribute(divNameStr))) 
	                       pnl = getObj(A[i].getAttribute(divNameStr));
                    	
	                    lbl = pnl.getElementsByTagName(labelStr);
	                    if (lbl.length > 0)
		                    lbl = lbl[0];
                    	
                    	if(lbl.getAttribute(multiPartStr) == null)
                    	{
	                        if(A[i].getAttribute(defaultClassStr) != null)
	                            lbl.className = A[i].getAttribute(defaultClassStr);
	                        else
	                            lbl.className = emptyStr;
                        }
                        else
                        {
                            for(var index = 0; index < errorArray.length && !lblFound; index++)
                            {
                                lblId = errorArray[index];
                                if(lblId == lbl.id)
                                    lblFound = true;                            
                            }
                            
                            if(!lblFound)
                            {
                                if(A[i].defaultClass != null)
	                                lbl.className = A[i].getAttribute(defaultClassStr);
	                            else
	                                lbl.className = emptyStr;
                            }
                        }
	                }
                } 
            }//
        }
    }

    errorArray = null;
    
    if (errorFound)
    {
        //errorStr = "<font size='3'>Missing \\ Incomplete Required Fields</font><br/><br/>" + errorStr;
        errorStr = "<font size='3'>Missing \\ Incomplete Required Fields</font><br/><br/><ui>" + errorStr + "</ui>";
        getObj("pnlError").innerHTML = errorStr;
        show("pnlError");
        scroll(0,0);
    }
    else
        hide("pnlError");
    
    return !errorFound;
}

function disableAllFields()
{
    var pa = document.body;
    var A = null;
    var L = null;
    var browser = navigator.appName;

    for(var x = 0; x <= 1; x++)
    {
        if(x == 0)
        {
            A = pa.getElementsByTagName('input');
            L = A.length;
        }
        else
        {
            A = pa.getElementsByTagName('select');
            L = A.length;
        }
        
        //loop through all of the elements
        for(var i = 0; i < L; i++)
        {
            if (browser == "Microsoft Internet Explorer")
            {
                if(A[i].type != "submit")
                    A[i].disabled = true;
            }
            else
            {
                if(A[i].getAttribute('type') != "submit")
                    A[i].getAttribute('disabled') = true;
            }
        }
    }
}

/*  Micro API to return an object */
function getObj(name) {     
  if (document.getElementById)  {
    if (document.getElementById(name))
  	    return document.getElementById(name);
  }
  else if (document.all)  {
	if (document.all[name])
	    return document.all[name];
  }
  else if (document.layers)  {
    if (document.layers[name]) {
        this.style = document.layers[name];
   	    return document.layers[name]; } 	    
  }
}

function getObjByElements(name) {     
	var theForm = document.forms[0];

	return theForm.elements[name]; 
}

/*
    Add click, blur etc events
    usage: addEvent(object, event type [no 'on'], function, use Capture)
*/    
function addEvent(obj, evType, fn, useCapture){
    if (isString(obj)) obj = getObj(obj);
    if (typeof obj !== "undefined") {
        if (obj.addEventListener) {
            obj.addEventListener(evType, fn, useCapture);
            return true;
        } else if (obj.attachEvent) {
            var r = obj.attachEvent("on" + evType, fn);
            return r;
        } else {
            alert("Handler could not be attached");
        } 
    }
}


function removeEvent(obj, evType, fn, useCapture){
  if (obj.removeEventListener){
    obj.removeEventListener(evType, fn, useCapture);
    return true;
  } else if (obj.detachEvent){
    var r = obj.detachEvent("on"+evType, fn);
    return r;
  } else {
    alert("Handler could not be removed");
  }
}

function returnActiveElement(e) {
    var el;
    if (window.event && window.event.srcElement)
        el = window.event.srcElement;
    if (e && e.target)
        el = e.target;  
    return el;
}



function QString(qsParam) {
  nvString = "&" + location.search.substring(1, location.search.length) + "&"
  paramBegin = nvString.indexOf("&" + qsParam + "=")
  if (paramBegin != -1) {
    valBegin = (paramBegin*-1-qsParam.length-2)*-1
    qsVal = nvString.substring(valBegin, nvString.indexOf("&", valBegin))
    if (qsVal != "") {return unescape(qsVal)}
     else {return ""}
  }
  else {return ""}
}

function toggleVerifyAttribute(fieldName, theValue)
{
    var browserVersion = getInternetExplorerVersion();
    if(browserVersion > -1 && browserVersion < 9)
    {
        getObj(fieldName).verify = theValue;
    }
    else
    {
        getObj(fieldName).setAttribute('verify', theValue);
    }
}


// If the radio (obj) is checked, show the panels
function radToggle(obj, panels) {
	if (isString(obj)) 
	        obj = getObjByElements(obj);
	
	
	if (obj != null && obj.checked)
		show(panels);
	else
		hide(panels);	
}

// If the selectedIndex matches sIndex, show the panels
function cboToggle(obj, panels, sIndex) {
	
	// This will take arrays of objects, but they all need to match the same sIndex

	var match = true;
	var optSel;

	if (isArray(obj)) {	
		
		var tarLen = obj.length;
		
		for (var i = 0; i < tarLen; i++ ) {
			if (isString(obj[i])) obj[i] = getObj(obj[i]);
			optSel = obj[i].options.selectedIndex;
			if (optSel != sIndex) match = false;
		}
		
	}
	else {
		if (isString(obj)) obj = getObj(obj);
		optSel = obj.options.selectedIndex;
		if (optSel != sIndex) match = false;
	}
	
	if (match) {	
		show(panels); }
	else {
		hide(panels);
	}
	

}

/* START: NavGlobalPod */
function navglobalpod() {
	
	var pnlNavGlobalPod = getObj('navglobalpod');
	
	if (pnlNavGlobalPod) {
		pnlNavGlobalPod.innerHTML = "<form action='/search/index.asp' method='GET' name='searchResults1'><ul><li><a href='#'>contact us</a></li><li><input type='text' name='tx0' id='search' value='' />&nbsp;<input type='submit' name='submit' class='small' value='Search' /></li></ul></form>";
	}	
}
/* END: NavGlobalPod */

/* START: NavFooter */
function navfooter() {
	
	var pnlNavFooter = getObj('navfooter');
	
	if (pnlNavFooter) {
		pnlNavFooter.innerHTML = "<ul><li><a href='#'>about us</a></li><li><a href='#'>legal</a></li><li><a href='#'>privacy</a></li><li><a href='#'>security</a></li><li><a href='#'>site map</a></li></ul>";
	}	
}
/* END: NavFooter */

/* START: Footer */
function footer() {
	//document.write("This credit union is federally insured by the National Credit Union Administration.<br />");
	//document.write("PSECU is an Equal Opportunity Lender. Copyright &copy; 2005 PSECU. All rights reserved.");
	var pnlFooter = getObj('footer');
	
	if (pnlFooter) {
		pnlFooter.innerHTML = "This credit union is federally insured by the <a href='http://www.ncua.gov/NewsPublications/Publications/PDF/brochures/insured_funds/funds.pdf' target='_blank'>National Credit Union Administration</a>.<br />PSECU is an Equal Opportunity Lender. Copyright &copy; 2006 PSECU. All rights reserved.";
	}
}
/* END: Footer */

/* START: Expand and contract */




function toggle(target) {
    if (isString(target)) {
        target = getObj(target);
    }
    if (!target) {
        return false; 
    }
    if (isArray(target)) {
        var tarLen = target.length;
        for (var i = 0; i < tarLen; i++) {
            toggle(target[i]);
        }
    } 
    else {
        if (target.className != "undefined" && target.className.indexOf("hidden") != "-1") {
            if ((target.style.display == "") || (target.style.display == "none")) {
                target.style.display = "block";
            }
            else {
                target.style.display = "none";
            }
        }
        else {
            if ((target.style.display == "none")) {
                target.style.display = "block";
            }
            else {
                target.style.display = "none";
            }
        }
        //target.style.display = (target.style.display == "none") ? "" : "none";
	}
}


function hide(target) {
    if (isString(target)) {
        targetStr = target;
        target = getObj(target);
    }

    var t;
    if (isArray(target)) {
        var tarLen = target.length;
        for (var i = 0; i < tarLen; i++) {
            hide(target[i]);
        }
    } else {
        if (t = target) {

            t.style.display = "none";
            enableDisableRequiredFields(targetStr, false);
            return true;
        }
        else {
            return false;
        }
    }
}


function show(target) {
	if (isString(target))
    {
        targetStr = target;
        target = getObj(target);
    }
	
    var t;
    if (isArray(target)) {
        var tarLen = target.length;
        for (var i = 0; i < tarLen; i++) {
            show(target[i]);
        }
    } else {
        if (t = target) {
            ////if (t.id == "pnlError") {
            ////    t.style.display = "block";
           //// }
           //// else {
                t.style.display = "block";
           //// }
            enableDisableRequiredFields(targetStr, true);
            return true;
        }
        else {
            return false;
        }
    }
}

function hide(target) {
    if (isString(target)) {
        targetStr = target;
        target = getObj(target);
    }

    var t;
    if (isArray(target)) {
        var tarLen = target.length;
        for (var i = 0; i < tarLen; i++) {
            hide(target[i]);
        }
    } else {
        if (t = target) {

            t.style.display = "none";
            enableDisableRequiredFields(targetStr, false);
            return true;
        }
        else {
            return false;
        }
    }
}

//disables input and select fields within the given panel\div element
function enableDisableRequiredFields(pa, enableRF){
    var pa = document.getElementById(pa);
    if(!pa)
        pa = document.body;

    var A = null;
    var L = null;

    for(var x = 0; x <= 1; x++)
    {
        if(x == 0)
        {
            A = pa.getElementsByTagName('input');
            L = A.length;
        }
        else
        {
            A = pa.getElementsByTagName('select');
            L = A.length;
        }

        //loop through all of the elements
        for(var i = 0; i < L; i++)
        {
            if(A[i].getAttribute('isRequired'))
            {
                if(enableRF)
                    doEnable(A[i].id);
                else
                    doDisable(A[i].id);
            }
        }
    }

}

function doEnable(target) 
{
	if (isString(target)) 
        target = getObj(target);
	
    var t;
    var browserVersion = getInternetExplorerVersion();
	if (isArray(target)) 
	{
		var tarLen = target.length;
		for (var i = 0; i < tarLen; i++ ) {
			doEnable(target[i]);
		}
	} 
    else {
	    if (t = target) 
	    {
            if(browserVersion > -1 && browserVersion < 9)
                t.verify = true;
            else
        		t.setAttribute('verify', true);
            
		    return true;    
        }
		else {
		    return false; 
		}
	}
}

function doDisable(target) 
{
	if (isString(target)) 
        target = getObj(target);

    var t;
    var browserVersion = getInternetExplorerVersion();
	if (isArray(target)) 
    {
		var tarLen = target.length;
		for (var i = 0; i < tarLen; i++ ) {
			doDisable(target[i]);
		}
	} 
    else {
        if (t = target) 
        {
            if(browserVersion > -1 && browserVersion < 9)
                t.verify = false;
            else
			    t.setAttribute('verify', false);
		    return true; 
        }
		else {
		    return false;	
		}
	}
}

function toggleHeader(e) {
	var el = returnActiveElement(e);
	if (!el) return;

	// Actually grab the header div, not any child elements that might have actually
	// captured the event.
	while (el.className.indexOf("tabsc") < 0) { el = el.parentNode };

	
	nextSib = el.nextSibling;	
	while (nextSib.nodeType != 1) nextSib = nextSib.nextSibling;
	//alert(nextSib.getAttribute("id"));

	el.className = (el.className == "tabsc") ? "tabsc_expanded" : "tabsc"; 
	nextSib.className = "tabsc_content";
	toggle(nextSib);
}
/* END: Expand and contract */


function grayOutScreen() {
	if (!getObj("pnlGrayOut")) {
		bod = document.getElementsByTagName('body')[0];
		overlay = document.createElement('div');
		overlay.id = 'pnlGrayOut';
		bod.appendChild(overlay);
	}
	else {
		show("pnlGrayOut");	
	}
}

function addOption(selectbox,text,value )
{
	if (isString(selectbox)) selectbox = getObj(selectbox);
	var optn = document.createElement("OPTION");
	optn.text = text;
	optn.value = value;
	selectbox.options.add(optn);
}


/* START: Tool tips */
function doTooltip(e, msg) {

  if ( typeof Tooltip == "undefined" || !Tooltip.ready ) return;
  Tooltip.show(e, msg);
}

function hideTip() {
  if ( typeof Tooltip == "undefined" || !Tooltip.ready ) return;
  Tooltip.hide();
}
/* END: Tool tips */




// Validation - Thanks W3Schools.

function validate_required(field)
{
	with (field)
	{
		if (value==null||value=="")
			{return false}
		else
			{return true}
	}
}

function validate_email(field)
{
	with (field)
	{
		apos=value.indexOf("@")
		dotpos=value.lastIndexOf(".")
		if (apos<1||dotpos-apos<2) {return false}
		else {return true}
	}
}

// End Validation



function setError(txt) {
	document.location += "&error=" + txt;
}

function hideError() {
	hide("pnlError");	
}


function changeLabel(pnl, txt) {
	if (isString(pnl)) pnl = getObj(pnl);
	var lbl = pnl.getElementsByTagName("label");
	
	if (lbl.length > 0) {
		lbl = lbl[0];
	}
	
	lbl.innerHTML = txt;
}

function highlightNavsub(currentSubId) {
    var navsub = document.getElementById("navsub");
    var menus = navsub.getElementsByTagName("li");
    for (var i = 0; i < menus.length; i++) {
        if (menus[i].id == currentSubId) {
            menus[i].className = "current";
        }
        else {
            menus[i].className = "";
        }
    }
}


function blockBack() {
    if (history.length > 0) {
        history.go(+1);
    }
}

function initShow() {
    var contentDiv = document.getElementById("content");
    var sideColumnDiv = document.getElementById("SideColumn");
    if (contentDiv) {
        contentDiv.style.visibility = "visible";
    }
    if (sideColumnDiv) {
        sideColumnDiv.style.visibility = "visible";
    }
}

var getKeys = function (obj) {
    var keys = [];
    for (var key in obj) {
        keys.push(key);
    }
    return keys;
}
function fireActionButtonEvent(obj) {
    if (typeof obj == "string") {
        obj = document.getElementById(obj);
    }
    if (obj.fireEvent) {
        if (obj.fireEvent('onclick') != false) {
            __doPostBack(obj.name, '');
        }
    }
    else {
        obj.dispatchEvent(new Event("click"));
        __doPostBack(obj.name, '');
    }
}

function highlightStep(selectedStep) {
    var stepsContainer = document.getElementById("steps");
    if (stepsContainer) {

        var steps = stepsContainer.getElementsByTagName("li")

        for (var i = 0; i < steps.length; i++) {
            if (steps[i].id == selectedStep) {

                steps[i].className = "current";
            }
            else {
                steps[i].className = "";
            }
        }
    }
}

function loadPageSettings() {

    var url = window.location.pathname;
    var filename = url.substring(url.lastIndexOf('/') + 1);

    if (typeof pagesConfig != "undefined") {
        if (typeof pagesConfig[filename] != "undefined") {
            highlightNavsub(pagesConfig[filename].leftMenu);
            highlightStep(pagesConfig[filename].step);
        }
    }
}

function saveMortgageApp() {
    fireActionButtonEvent("Save");
}

function getOfferDetails() {
    fireActionButtonEvent("OfferDetails");
}

function displaySpeicalOffersLinkAndPanel() {

    var showRollover = false;
    var showCrossSell = false;
    var savingsAmount = getObj("savingsAmount").innerHTML;
    var offersPanel = getObj("OffersPanel");
    var crossSellPanel = getObj("crossSellPanel");

    if (savingsAmount.innerHTML != "-1") {
        var url = window.location.pathname;
        var filename = url.substring(url.lastIndexOf('/') + 1);

        if (Number(savingsAmount) > 0) {
            showRollover = true;
        }
        else if (Number(savingsAmount) == 0) {
            showCrossSell = true;
        }
    }

    if ((filename == "appStatus.aspx") || (filename == "rolloverDetails.aspx")) {
        showRollover = false;
        showCrossSell = false;
    }

    // show or hide offers panel
    if (offersPanel != null) {
        if (showRollover) {
            savingsAmount = Number(savingsAmount).toFixed(2);
            offersPanel.innerHTML = offersPanel.innerHTML.replace(/\[SavingsAmount\]/g, "$" + savingsAmount);
            show("OffersPanel");
        }
        else {
            hide("OffersPanel");
        }
    }

    // show or hide crosssell panel
    if (crossSellPanel != null) {
        if (showCrossSell) {
            show("crossSellPanel");
        }
        else {
            hide("crossSellPanel");
        }
    }

    // show or hide offers link
    if (getObj("navsubSpecialOffer") != null) {
        if (showRollover || showCrossSell) {
            show("navsubSpecialOffer");
        }
        else {
            hide("navsubSpecialOffer");
        }
    }
}

function focusElement(obj) {
    if (obj) {
        // make sure the object is not invisable
        if (obj.offsetWidth > 0) {
            obj.focus();
        }
    }
}

addEvent(window, 'load', InitializeMain);

/* START: Initialize Function to Replace document.write */
function InitializeMain() {
    displaySpeicalOffersLinkAndPanel();
    blockBack();
    loadPageSettings();
    navfooter();
    //footer();

    if (QString("error")) {
        getObj("pnlError").innerHTML = QString("error");
        show("pnlError");
    }

    initShow();
}
