addEvent(window, "load", Init);

var checkRetiredIncome = true;

function Init() {

	var theScen = QString("scen");
	var isEdit = QString("editApp");
	var isBack = QString("isBack");
	var trueStr = "True";
	var isError = getObj("pnlError").innerHTML;
	
	scroll(0, 0);
	switch (theScen) {
		case "auto":
		case "rec":
		case "visa":
		case "psl":
		case "combo":
		case "sig":
		case "sigPromo":
			hide(new Array("pnlStudentFullTime",
							"pnlPrintStudent",
							"pnlBusAddress",
							"pnlOwnerName",
							"pnlMaritalStatus",
							"pnlAddressType",
							"pnlHaveSchoolAddress",
							"pnlHaveHomeAddress",
							"pnlSchoolAddress",
							"pnlHomeAddress",
							"pnlFutureStartDate",
							"pnlLawsuits",
							"atLawSuit",
							"pnlPastDue",
							"radPastDue",
							"pnlHome",
							"pnlOtherEmployerName",
							"pnlSpouse"));

			if (isEdit == trueStr || isBack == trueStr || isError.length > 0) {
				checkAppType();
				checkResStat();
				toggleEmployment();
				toggleFutureStartDate();
			}

			break;

		case "student":
			hide(new Array("pnlSchoolNameYear",
							"pnlBusAddress",
							"pnlAddressInfo",
							"pnlEmploymentInfo",
							"pnlAddIncome",
							"pnlQuestions",
							"pnlAppType",
							"pnlSchoolAddress",
							"pnlHomeAddress",
							"pnlHome",
							"pnlPageNav"));

			if (isEdit == trueStr || isBack == trueStr || isError.length > 0) {
				checkAppType();
				//checkFullTime();
				checkAddressType();
				toggleSchoolAddressPanels();
				toggleHomeAddressPanels();
            }

            checkFullTime();

			break;

		case "homeeq":
		case "preapp":
		case "heloc":
			hide(new Array("pnlStudentFullTime",
							"pnlPrintStudent",
							"pnlBusAddress",
							"pnlOwnerName",
							"pnlAddressType",
							"pnlHaveSchoolAddress",
							"pnlHaveHomeAddress",
							"pnlSchoolAddress",
							"pnlHomeAddress",
							"pnlFutureStartDate",
							"pnlLawsuits",
							"atLawSuit",
							"pnlPastDue",
							"radPastDue",
							"pnlOtherEmployerName",
							"pnlSpouse"));

			if (theScen == "heloc")
				hide("pnlHome");

			if (isEdit == trueStr || isBack == trueStr || isError.length > 0) {
				checkAppType();
				checkPersonalDetails();
				checkResStat();
				toggleEmployment();
				toggleFutureStartDate();
			}

			break;

		case "busVehicle":
		case "equipment":
		case "busVisa":
		case "busUnsecTerm":
		case "busUnsecLOC":
		case "busRESecLOC":
		case "busRESecTerm":
			getObj("atPos").value = "Business owner / partner";
			changeLabel("pnlSalary", "Salary from Business: <span class='required'>*</span>");
			changeLabel("pnlTimeEmployed", "Time with Business: <span class='required'>*</span>");
			getObj("atTimeEmpYr").remove(1);
			hide(new Array("pnlStudentFullTime",
							"pnlAtMName",
							"pnlPrintStudent",
							"pnlMaritalStatus",
							"pnlAddressType",
							"pnlHaveSchoolAddress",
							"pnlHaveHomeAddress",
							"pnlSchoolAddress",
							"pnlHomeAddress",
							"pnlFutureStartDate",
							"pnlOtherEmployerName",
							"pnlSpouse",
							"pnlHome"));

			if (isEdit == trueStr || isBack == trueStr || isError.length > 0) {
				checkAppType();
				checkResStat();
				toggleEmployment();
			}

			break;
	}

	//student
	addEvent("radFullTime1", "click", checkFullTime);
	addEvent("radFullTime2", "click", checkFullTime);

	//future start date
	addEvent("atTimeEmpYr", "change", toggleFutureStartDate);
	addEvent("atTimeEmpYr", "keyup", toggleFutureStartDate);

	//correct address
	addEvent("correctAddr", "change", checkCorrectAddress);
	addEvent("correctAddr", "keyup", checkCorrectAddress);
	addEvent("correctBusAddr", "change", checkCorrectAddress);
	addEvent("correctBusAddr", "keyup", checkCorrectAddress);

	//home or school address
	addEvent("homeSchoolAddr", "change", checkAddressType);
	addEvent("homeSchoolAddr", "keyup", checkAddressType);

	//residential status
	addEvent("atResStat", "change", checkResStat);
	addEvent("atResStat", "keyup", checkResStat);

	//employment
	addEvent("selOccupation", "change", checkEmployment);
	addEvent("selOccupation", "keyup", checkEmployment);

	//have school address
	addEvent("haveSchoolAddr", "change", toggleSchoolAddressPanels);
	addEvent("haveSchoolAddr", "keyup", toggleSchoolAddressPanels);

	//have home address
	addEvent("haveHomeAddr", "change", toggleHomeAddressPanels);
	addEvent("haveHomeAddr", "keyup", toggleHomeAddressPanels);

	//other income
	addEvent("atOthIncAvail1", "click", function () { show("AddIncomePanel"); });
	addEvent("atOthIncAvail2", "click", function () { hide("AddIncomePanel"); });
	addEvent("atOthIncSrc1", "change", checkIncomeSource);
	addEvent("atOthIncSrc1", "keyup", checkIncomeSource);

	//application type
	addEvent("anRegbType", "change", checkAppType);
	addEvent("anRegbType", "keyup", checkAppType);

	addEvent("correctEmailAddr", "change", checkCorrectEmail);
	addEvent("correctEmailAddr", "keyup", checkCorrectEmail);

	//personal details
	addEvent("hmPersonalDetails", "click", checkPersonalDetails);

	toggleAdditionalFields();
	if (getObj("pageFocusLbl").innerHTML.length > 0) {
	    focusElement(getObj(getObj("pageFocusLbl").innerHTML));
	}

	checkEmployment();
	toggleCorrectEmail();
	toggleRetiredFields();
}




function checkCorrectAddress(e) {
	var el = returnActiveElement(e);
	if (el.options.selectedIndex == 2) {
		getObj("pnlError").innerHTML = "You have indicated that your address is incorrect.  Please contact PSECU at 800-237-7328 to update your home address.";
		show("pnlError");
	}
	else {
		getObj("pnlError").innerHTML = "";
		hide("pnlError");
	}
}

function checkAppType() {
	var el = getObj("anRegbType");

	if (el.options.selectedIndex > 1)
		show("pnlSpouse");
	else {
		//hide the panel and clear the field
		hide("pnlSpouse");
		getObj("atSpouse").value = "";
	}
}

function checkFullTime() {
    var el = getObj("radFullTime1");
	if (el.checked) {
		getObj("pnlError").innerHTML = "";
		hide(new Array("pnlSpacer2",
			"pnlAddressType",
			"pnlError"));
		show(new Array("pnlSchoolNameYear",
			"pnlAddressInfo",
			"pnlAddressType",
			"pnlPageNav"));
		hide(new Array("pnlOwnerName",
			"pnlMaritalStatus",
			"pnlHaveSchoolAddress",
			"pnlHaveHomeAddress",
			"pnlResStatus",
			"pnlHousePayments"));
	}
	else {
		getObj("pnlError").innerHTML = "You must be a full-time student to apply for a Student VISA.";
		hide(new Array("pnlSchoolNameYear",
			"pnlBusAddress",
			"pnlAddressInfo",
			"pnlEmploymentInfo",
			"pnlAddIncome",
			"pnlQuestions",
			"pnlAppType",
			"pnlSchoolAddress",
			"pnlHomeAddress",
			"pnlHome",
			"pnlPageNav"));
		show(new Array("pnlError",
			"pnlSpacer2"));
	}
}

function checkResStat() {
	var el = getObj("atResStat");
	if (el.options.selectedIndex == 2 || el.options.selectedIndex == 4 ||
		el.options.selectedIndex == 5) {
		toggleVerifyAttribute("atCrdtrHousePmt", false);
		getObj("atCrdtrHousePmtSpan").innerHTML = "";
	}
	else {
		toggleVerifyAttribute("atCrdtrHousePmt", true);
		getObj("atCrdtrHousePmtSpan").innerHTML = "*";
	}
}

function toggleEmployment() {
	var el = getObj("selOccupation");
	if (el.options.selectedIndex == 2 || el.options.selectedIndex == 3 ||
		el.options.selectedIndex == 5 ||
		el.options.selectedIndex == 6 || el.options.selectedIndex == 7) {
		hide("pnlEmp");
	}
	else
		show("pnlEmp");

	toggleFutureStartDate();
}

function checkEmployment() {
	var el = getObj("selOccupation");
	if (el.options.selectedIndex == 2 || el.options.selectedIndex == 3 ||
		el.options.selectedIndex == 5 ||
		el.options.selectedIndex == 6 || el.options.selectedIndex == 7) {
		hide("pnlEmp");
	}
	else
		show("pnlEmp");

	toggleRetiredFields();

	toggleFutureStartDate();
}

function checkAddressType() {
	var el = getObj("homeSchoolAddr");
	var isEdit = QString("editApp");
	var isBack = QString("isBack");

	//reset both drop down list if not an edit
	if (!isEdit == "True" || !isBack == "True") {
		var haveAddrDDL = getObj("haveHomeAddr");
		haveAddrDDL.options.selectedIndex = 0;

		haveAddrDDL = getObj("haveSchoolAddr");
		haveAddrDDL.options.selectedIndex = 0;
	}

	//show the correct panel
	if (el.options.selectedIndex == 1) {
		hide(new Array("pnlHomeAddress", "pnlHaveHomeAddress"));
		show("pnlHaveSchoolAddress");
	}
	else if (el.options.selectedIndex == 2) {
		hide(new Array("pnlSchoolAddress", "pnlHaveSchoolAddress"));
		show("pnlHaveHomeAddress");
	}
	else
		hide(new Array("pnlHomeAddress", "pnlHaveHomeAddress", "pnlSchoolAddress", "pnlHaveSchoolAddress"));
}

function toggleFutureStartDate() {
	var loanType = QString("scen");

	var el = getObj("atTimeEmpYr");

	if (el.options.selectedIndex == 1)
		show("pnlFutureStartDate");
	else {
		//hide the panel and clear the field
		hide("pnlFutureStartDate");
		getObj("txtFutureStartDate").value = "";
	}
}

function toggleSchoolAddressPanels(e) {
	var el = getObj("haveSchoolAddr");

	if (el.options.selectedIndex == 1) {
		hide("pnlHomeAddress");
		show("pnlSchoolAddress");
	}
	else
		hide("pnlSchoolAddress");
}

function toggleHomeAddressPanels(e) {
	var el = getObj("haveHomeAddr");

	if (el.options.selectedIndex == 1) {
		hide("pnlSchoolAddress");
		show("pnlHomeAddress");
	}
	else
		hide("pnlHomeAddress");
}

function checkPersonalDetails() {
	var el = getObj("hmPersonalDetails");

	if (el.checked)
		hide(new Array("pnlPersonalDetails1",
				"pnlPersonalDetails2",
				"pnlPersonalDetails3"));
	else
		show(new Array("pnlPersonalDetails1",
				"pnlPersonalDetails2",
				"pnlPersonalDetails3"));
}

function toggleCorrectEmail() {
	if (getObj("atEmail").value.length > 0) {
		getObj("atEmail").readOnly = true;
		show("pnlCorrectEmailAddr");
	}
	else {
		hide("pnlCorrectEmailAddr");
	}
}

function toggleRetiredFields() {
	var el = getObj("selOccupation");

	//retired
	if (el.options[el.selectedIndex].value == "Retired") {
		show("pnlRetired");
	}
	else {
		getObj("atPensionRetirement").value = "";
		getObj("atSSDisability").value = "";
		hide("pnlRetired");
	}

    cloneDropDown("atOthIncSrc1");
    populateOthIncDDL("selOccupation", "fake_atOthIncSrc1");

    //addEvent("atOthIncSrc1", "change", checkIncomeSource);
    //addEvent("atOthIncSrc1", "keyup", checkIncomeSource);
}

function checkCorrectEmail() {
	if (getObj("correctEmailAddr").value == "No") {
		getObj("atEmail").readOnly = false;
		getObj("atEmail").focus();
	}
	else {
		getObj("atEmail").readOnly = true;
	}
}

function toggleAdditionalFields() {
	if (getObj("atOthIncAvail1").checked)
		show("AddIncomePanel");
}

function checkIncomeSource() {

	// If it's a part-time or second job, show additional fields
	var el = getObj("atOthIncSrc1");
	if (el.options[el.selectedIndex].value == "P/T OR SECOND JOB") {
	    show("atOthInc1ExtraFields");
	}
	else {
	    hide("atOthInc1ExtraFields");
	}
}

function checkFieldsOnPage() {
	var success = checkAll();

	var el = getObj("selOccupation");

	//retired
	if (el.options[el.selectedIndex].value == "Retired" && checkRetiredIncome) {
		var successTemp = verifyRetiredFields("atPensionRetirement", "atSSDisability", "otherIncomeTable");
		//only check the retired income once
		if (successTemp)
			checkRetiredIncome = false;
		success = successTemp && success;
	}

	return success;
}