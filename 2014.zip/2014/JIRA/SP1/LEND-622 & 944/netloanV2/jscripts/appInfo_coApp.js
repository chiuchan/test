addEvent(window, "load", Init);
var checkRetiredIncome = true;

function Init() {
	var theScen = QString("scen");
	var trueStr = "True";

	switch (theScen) {
		case "auto":
		case "rec":
		case "visa":
		case "psl":
		case "combo":
		case "sig":
		case "busVehicle":
		case "busVisa":
		case "equipment":
		case "busUnsecTerm":
		case "busUnsecLOC":
			hide(new Array("pnlHmda",
						"pnlMaritalStatus",
						"pnlFutureStartDate",
						"pnlOtherEmployerName"));

			checkResStat();
			break;

		case "preapp":
			hide(new Array("pnlMaritalStatus",
						"pnlFutureStartDate",
						"pnlOtherEmployerName"));

			checkResStat();
			break;

		case "homeeq":
		case "heloc":
		case "busRESecLOC":
		case "busRESecTerm":
			hide(new Array("pnlFutureStartDate",
						"pnlOtherEmployerName"));

			if (theScen != "homeeq")
				hide("pnlHmda");

			if (theScen == "busRESecLOC" || theScen == "busRESecTerm") {
				hide("pnlMaritalStatus");
			}

			checkResStat();
			break;
	}

	setupEditPage();

	//other income
	addEvent("coAppOthIncAvail1", "click", function () { show("coAppAddIncomePanel"); });
	addEvent("coAppOthIncAvail2", "click", function () { hide("coAppAddIncomePanel"); });

	addEvent("coAppOthIncSrc1", "change", checkIncomeSource);
	addEvent("coAppOthIncSrc1", "keyup", checkIncomeSource);

	//residential status
	addEvent("coAppResStat", "change", checkResStat);
	addEvent("coAppResStat", "keyup", checkResStat);

	//employment
	addEvent("coAppOccupation", "change", checkEmployment);
	addEvent("coAppOccupation", "keyup", checkEmployment);

	//future start date
	addEvent("coAppTimeEmpYr", "change", function () { cboToggle("coAppTimeEmpYr", "pnlFutureStartDate", 1) });
	addEvent("coAppTimeEmpYr", "keyup", function () { cboToggle("coAppTimeEmpYr", "pnlFutureStartDate", 1) });

	addEvent("coAppCorrectEmailAddr", "change", checkCorrectEmail);
	addEvent("coAppCorrectEmailAddr", "keyup", checkCorrectEmail);

	//application type
	addEvent("coAppPersonalDetails", "click", checkPersonalDetails);

	toggleAdditionalFields();
	if (getObj("pageFocusLbl").innerHTML.length > 0) {
	    focusElement(getObj(getObj("pageFocusLbl").innerHTML));
	}

	checkEmployment();
	checkIncomeSource();
	toggleCorrectEmail();
	toggleRetiredFields();
}

function setupEditPage() {
	var isEdit = QString("editApp");
	var isBack = QString("isBack");
	var isError = getObj("pnlError").innerHTML;
	var trueStr = "True";

	if (isEdit == trueStr || isBack == trueStr || isError.length > 0) {
		//dl
		//toggleOtherIncomeSourceEmployer();
		checkPersonalDetails();
		checkResStat();
		toggleEmployment();
		cboToggle("coAppTimeEmpYr", "pnlFutureStartDate", 1);
	}
}

function checkResStat(target) {
	var el = getObj("coAppResStat");
	if (el.options.selectedIndex == 2 || el.options.selectedIndex == 4 ||
		el.options.selectedIndex == 5) {
		toggleVerifyAttribute("coAppCrdtrHousePmt", false);
		getObj("coAppCrdtrHousePmtSpan").innerHTML = "";
	}
	else {
		toggleVerifyAttribute("coAppCrdtrHousePmt", true);
		getObj("coAppCrdtrHousePmtSpan").innerHTML = "*";
	}
}

function toggleEmployment() {
	var el = getObj("coAppOccupation");
	if (el.options.selectedIndex == 2 || el.options.selectedIndex == 3 ||
		el.options.selectedIndex == 5 ||
		el.options.selectedIndex == 6 || el.options.selectedIndex == 7) {
		hide("pnlCoAppEmp");
	}
	else
		show("pnlCoAppEmp");

	cboToggle("coAppTimeEmpYr", "pnlFutureStartDate", 1);
}

function checkEmployment() {
	var el = getObj("coAppOccupation");
	if (el.options.selectedIndex == 2 || el.options.selectedIndex == 3 ||
		el.options.selectedIndex == 5 ||
		el.options.selectedIndex == 6 || el.options.selectedIndex == 7) {
		hide("pnlCoAppEmp");
	}
	else
		show("pnlCoAppEmp");

	toggleRetiredFields();

	cboToggle("coAppTimeEmpYr", "pnlFutureStartDate", 1);
}

function checkPersonalDetails(e) {
	var el = getObj("coAppPersonalDetails");

	if (el.checked)
		hide("pnlPersonalDetails1");
	else
		show("pnlPersonalDetails1");
}

function toggleCorrectEmail() {
	if (getObj("coAppEmail").value.length > 0) {
		getObj("coAppEmail").readOnly = true;
		show("pnlCoAppCorrectEmailAddr");
	}
	else {
		hide("pnlCoAppCorrectEmailAddr");
	}
}

function toggleRetiredFields() {
	var el = getObj("coAppOccupation");

	//retired
	if (el.options[el.selectedIndex].value == "Retired") {
		show("pnlCoAppRetired");
	}
	else {
		getObj("coAppPensionRetirement").value = "";
		getObj("coAppSSDisability").value = "";
		hide("pnlCoAppRetired");
	}

    cloneDropDown("coAppOthIncSrc1");
    populateOthIncDDL("coAppOccupation", "fake_coAppOthIncSrc1");
}

function checkCorrectEmail() {
	if (getObj("pnlCoAppCorrectEmailAddr").style.display == "block") {
		if (getObj("coAppCorrectEmailAddr").value == "No") {
			getObj("coAppEmail").readOnly = false;
			getObj("coAppEmail").focus();
		}
		else {
			getObj("coAppEmail").readOnly = true;
		}
	}
}

function toggleAdditionalFields() {
	if (getObj("coAppOthIncAvail1").checked)
		show("coAppAddIncomePanel");
}

function checkIncomeSource(e) {
	// If it's a part-time or second job, show additional fields
	var el = getObj("coAppOthIncSrc1");
	if (el.options[el.selectedIndex].value == "P/T OR SECOND JOB")
		show("coAppOthInc1ExtraFields");
	else
		hide("coAppOthInc1ExtraFields");
}

function checkFieldsOnPage() {
	var success = checkAll();

	var el = getObj("coAppOccupation");

	//retired
	if (el.options[el.selectedIndex].value == "Retired" && checkRetiredIncome) {
		var successTemp = verifyRetiredFields("coAppPensionRetirement", "coAppSSDisability", "coAppOtherIncomeTable");
		//only check the retired income once
		if (successTemp)
			checkRetiredIncome = false;
		success = successTemp && success;
	}

	return success;
}
