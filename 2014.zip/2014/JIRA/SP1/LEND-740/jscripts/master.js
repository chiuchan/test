//
// Master.js - Master file containing JavaScript methods
//
function isAlien(a) { return isObject(a) && typeof a.constructor != 'function'; }
function isArray(a) { return isObject(a) && a.constructor == Array; }
function isBoolean(a) { return typeof a == 'boolean'; }
function isEmpty(o) {
    var i, v;
    if (isObject(o)) {
        for (i in o) {
            v = o[i];
            if (isUndefined(v) && isFunction(v)) { return false; }
        }
    }
    return true;
}
function isFunction(a) { return typeof a == 'function';}
function isNull(a) { return typeof a == 'object' && !a;}
function isNumber(a) { return typeof a == 'number' && isFinite(a);}
function isObject(a) { return (a && typeof a == 'object') || isFunction(a);}
function isString(a) { return typeof a == 'string';}
function isUndefined(a) { return typeof a == 'undefined'; } 

var isIE5Mac = (navigator.userAgent.indexOf('MSIE 5') != -1	&&	navigator.userAgent.indexOf('Mac') != -1);
var W3CDOM = (!isIE5Mac && 	document.getElementsByTagName && document.createElement);
var DHTML = (document.getElementById || document.all || document.layers);

// Disable the [Backspace] and [Enter] keys
//
if (typeof window.event != 'undefined')
    document.onkeydown = function()
    {
        if (event.srcElement.tagName.toUpperCase() != 'INPUT' && 
            event.srcElement.tagName.toUpperCase() != 'TEXTAREA' )
        {
            return (event.keyCode != 8 && event.keyCode != 13);
        }
        else
            return (event.keyCode != 13);
    }
else
    document.onkeypress = function(e)
    {
        if (e.target.nodeName.toUpperCase() != 'INPUT' && 
            e.target.nodeName.toUpperCase() != 'TEXTAREA' )
        {
            return (e.keyCode != 8 && e.keyCode != 13);
        }
        else
            return (e.keyCode != 13);
   }

function isNumeric(fld, e) 
{
    var key = '';
    var strCheck = '0123456789';
    
    // Set whichCode to code of key pressed (key code)
    var whichCode = e.which;
    if(whichCode == null || whichCode.length == 0)
        whichCode = e.keyCode;

    // [Enter] is OK "13" as is TAB "0" and (Backspace "8" fails in newest firfox version)
    if (whichCode == 13 || whichCode == 0 || whichCode == 8) 
        return true;  

    // Get key value from key code (sets 'key' to character rep'd by key code)
    key = String.fromCharCode(whichCode);  
    if ((strCheck.indexOf(key) == -1)) 
    {
        // Not a valid key
        alert('Use numbers only.');
        fld.focus();
        return false;
    }

    return true;
}

function isCurrency(fld, e) 
{
    var key = '';
    var strCheck = '0123456789.';
    
    // Set whichCode to code of key pressed (key code)
    var whichCode = e.which;
    if(whichCode == null || whichCode.length == 0)
        whichCode = e.keyCode;

    // [Enter] is OK "13" as is TAB "0" and (Backspace "8" fails in newest firfox version)
    if (whichCode == 13 || whichCode == 0 || whichCode == 8)
        return true;  

    // Get key value from key code (sets 'key' to character rep'd by key code)
    key = String.fromCharCode(whichCode);  
    if ((strCheck.indexOf(key) == -1)) 
    {
        // Not a valid key
        alert('Use numbers only.');
        fld.focus();
        return false;
    }

    return true;
}

function isRate(fld, e) 
{
    var key = '';
    var strCheck = '-0123456789.';
    
    // Set whichCode to code of key pressed (key code)
    var whichCode = e.which;
    if(whichCode == null || whichCode.length == 0)
        whichCode = e.keyCode;

    // [Enter] is OK "13", as is TAB "0"
    if (whichCode == 13 || whichCode == 0) 
        return true;  

    // Get key value from key code (sets 'key' to character rep'd by key code)
    key = String.fromCharCode(whichCode);  
    if ((strCheck.indexOf(key) == -1)) 
    {
        // Not a valid key
        alert('Use numbers only.');
        fld.focus();
        return false;
    }

    return true;
}

function verifyCurrency(field)
{ 
    var amount = field.value;

    //look for more than 1 decimal
    if (amount.indexOf(".") != amount.lastIndexOf("."))
    {
        alert(" Only 1 decimal point is allowed");
        field.focus();
    }
}

function verifyMinLoanAmount(field)
{ 
    if(getObj("minLoanAmtLbl").innerHTML.length > 0)
    {
        var minAmount = parseFloat(getObj("minLoanAmtLbl").innerHTML);
        if(minAmount > 0.00)
        {
            var loanAmount = parseFloat(field.value);
            if(loanAmount < minAmount)
            {
                alert("The minimum amount allowed is: $" + minAmount.toFixed(2));
                field.focus();
            }
        }
    }    
}

function verifyMaxLoanAmount(field)
{ 
    if(getObj("maxLoanAmtLbl").innerHTML.length > 0)
    {
        var maxAmount = parseFloat(getObj("maxLoanAmtLbl").innerHTML);
        if(maxAmount > 0.00)
        {
            var loanAmount = parseFloat(field.value);

            if(loanAmount > maxAmount)
            {
                alert("The maximum amount allowed is: $" + maxAmount.toFixed(2));
                field.focus();
            }
        }
    }
}

function verifyLTV()
{ 
    if(getObj("verifyLTVLbl").innerHTML == "true" &&
       getObj("anLoanAmt").value.length > 0 && getObj("clVal").value.length > 0)
    {
        var loanAmount = parseFloat(getObj("anLoanAmt").value);
        var clAmount = parseFloat(getObj("clVal").value);
        var maxAmount = (clAmount * 1.2) + clAmount;
        if(loanAmount > maxAmount)
            alert("The Loan Amount is 120% greater then the Value of the Vehicle.");
    }
}

function setTerm(field)
{
    var theScen = QString("scen");
    var loanAmount = parseFloat(field.value);

    getObj("selTerm").options.length = 0;
    addOption("selTerm", "", "");
    addOption("selTerm", "2 years", "2");
    addOption("selTerm", "3 years", "3");

    if(theScen == "vehicle" || theScen == "busVehicle" || theScen == "equipment")
    {
        if (loanAmount >= 6000)
            addOption("selTerm", "4 years", "4");
        if (loanAmount >= 8000)
            addOption("selTerm", "5 years", "5");
        if (loanAmount >= 12000)
            addOption("selTerm", "6 years", "6");
        if (loanAmount >= 20000)
            addOption("selTerm", "7 years", "7");
        if (loanAmount >= 40000)
        {
            addOption("selTerm", "8 years", "8");
            addOption("selTerm", "9 years", "9");
            addOption("selTerm", "10 years", "10");
        }
    }
    else if(theScen == "rec")
    {
        if (loanAmount >= 5000)
            addOption("selTerm", "4 years", "4");
        if (loanAmount >= 8000)
            addOption("selTerm", "5 years", "5");
        if (loanAmount >= 15000)
        {
            addOption("selTerm", "6 years", "6");
            addOption("selTerm", "7 years", "7");
        }
    }
}


function verifyMaxCreditLimit(field)
{ 
    // Set max to $20,000.00
    //
    var maxAmount = 20000.00;
    var loanAmount = parseFloat(field.value);
    var theScen = QString("scen");

    if (loanAmount > maxAmount)
    {
        alert(" The maximum Credit Limit allowed is: $" + maxAmount.toString());
        field.focus();
    }
}

function defaultMinRent(field, resStat)
{
    if(getObj("defaultRentLbl").innerHTML != "" && 
      (getObj(resStat).options[getObj(resStat).selectedIndex].value == "Rents" || 
       getObj(resStat).options[getObj(resStat).selectedIndex].value == "Lives w/ relative"))
    {
        var amount = parseFloat(field.value);
        var minAmount = parseFloat(getObj("defaultRentLbl").innerHTML);
        if(amount < minAmount)
            field.value = getObj("defaultRentLbl").innerHTML;
    }
}

function maxSalaryWarning(field)
{
    if(getObj("maxSalaryLbl").innerHTML != "")
    {
        var salary = parseFloat(field.value);
        var maxAmount = parseFloat(getObj("maxSalaryLbl").innerHTML);
        if(salary >= maxAmount)
            alert("Warning! Salary exceeds $" + getObj("maxSalaryLbl").innerHTML);
    }
}

function verifyFieldLength(field, theLength)
{ 
    var theField = field.value;

    if (theField.length > 0 && theField.length < theLength)
    {
        alert("Field length must be " + theLength + " digits long");
        field.focus();
    }
}

function moveToNextField(field, theLength, nextField)
{ 
    var theField = field.value;

    if (theField.length == theLength)
        getObj(nextField).focus();
}

function verifyYear(field)
{ 
    var year = field.value;
    var theDate = Date();

    // look for more than 1 decimal
    if (year.length < 4)
    {
        alert(" Year must be 4 digits long");
        field.focus();
        return false;
    }

    theDate = theDate.substring(theDate.length - 4, theDate.length);
    if (year > theDate)
    {
        alert(" Invalid Year.");
        field.focus();
        return false;
    }

    return true;
}

function verifyPhoneNumber(field)
{ 
    // check for 555
    if (field.value == "555")
    {
        alert(" 555 is an invalid phone number");
        field.focus();
        return false;
    }

    return true;
}

function formatDate(field, e)
{
    var key = '';
    var strCheck = '0123456789';
    
    // Set whichCode to code of key pressed (key code)
    var whichCode = e.which;
    if(whichCode == null || whichCode.length == 0)
        whichCode = e.keyCode;

    // [Enter] is OK "13" as is TAB "0" and (Backspace "8" fails in newest firfox version)
    if (whichCode == 13 || whichCode == 0 || whichCode == 8) 
        return true;  

    // Get key value from key code (sets 'key' to character rep'd by key code)
    key = String.fromCharCode(whichCode);  
    if ((strCheck.indexOf(key) == -1)) 
    {
        // Not a valid key
        alert('Use numbers only.');
        field.focus();
        return false;
    }
    else
    {
        var dateStr = field.value;
        if(dateStr.length == 1 || dateStr.length == 4)
        {
            field.value = dateStr + key + "/";
            return false;
        }
    }

    return true;
}

function checkEmail(field) {
    var eaddr = (field.value).toUpperCase();
    if (eaddr.length > 0) {
        if (eaddr.indexOf("@") < 1) {
            alert("       Invalid email address."
           + "\rPlease verify username and '@' sign.");
            field.focus();
        }
        else if ((eaddr.indexOf(".COM") < 3) && (eaddr.indexOf(".ORG") < 3)
          && (eaddr.indexOf(".GOV") < 3) && (eaddr.indexOf(".NET") < 3)
          && (eaddr.indexOf(".US") < 3) && (eaddr.indexOf(".MIL") < 3)
          && (eaddr.indexOf(".INFO") < 3) && (eaddr.indexOf(".CA") < 3)
          && (eaddr.indexOf(".EDU") < 3) && (eaddr.indexOf(".BIZ") < 3)) {
            alert("                Invalid email address."
           + "\r        Please verify domain name & suffix."
           + "\r(For example: *.com, *.net, *.org, *.gov, *.biz or *.mil)");
            field.focus();
        }
    }
}

 
 function showSaveSuccessAlert()
 {
    alert("The loan application has been successfully saved.");
 }
 
 function verifyTextAreaMaxLength(field)
{
    var maxLength = parseInt(field.getAttribute("maxLength"));
    if (field.value.length > maxLength)
        field.value = field.value.substring(0, maxLength);
}

function getInternetExplorerVersion()
{
  var browserVersion = -1; // Return value assumes failure.
  if (navigator.appName == 'Microsoft Internet Explorer')
  {
    var ua = navigator.userAgent;
    var re  = new RegExp("MSIE ([0-9]{1,}[\.0-9]{0,})");
    if (re.exec(ua) != null)
      browserVersion = parseFloat( RegExp.$1 );
  }
  
  return browserVersion;
}

// Checks all fields on a form for 'empty string'.
//
function checkAll()
{
    var pa = document.body;
    var A = null;
    var L = null;
    var emptyStr = "";
    var genericError = " is a required field<br/>";
    var errorFound = false;
    var errorStr = "";
    var brStr = "<br/>";
    var pnl = null;
    var lbl = null;
    var lblId = null;
    var lblFound = false;
    var labelStr = "label";
    var errorLabelClassStr = 'errorLabel';
    var trueStr = "true";
    var mieStr = "Microsoft Internet Explorer";
    var inputStr = 'input';
    var selectStr = 'select'
    var verifyStr = 'verify';
    var isRequiredStr = 'isRequired';
    var divNameStr = 'divName';
    var errorTextStr = 'errorText';
    var errorClassStr = 'errorClass';
    var classStr = 'class';
    var multiPartStr = 'multiPart';
    var defaultClassStr = 'defaultClass';
    var errorArray = new Array();
    var browserVersion = getInternetExplorerVersion();

    for (var x = 0; x <= 1; x++)
    {
        if (x == 0)
        {
            A = pa.getElementsByTagName(inputStr);
            L = A.length;
        }
        else
        {
            A = pa.getElementsByTagName(selectStr);
            L = A.length;
        }

        //loop through all of the elements
        for (var i = 0; i < L; i++)
        {
            lblFound = false;
            
            if(browserVersion > -1 && browserVersion < 9)
            {
                if (A[i].verify && A[i].isRequired == trueStr && 
                    A[i].value.length == 0)
                {
                    errorFound = true;
                    
                    //set the label to a red color
                    if(A[i].divName != null)
                    {
                        if (isString(A[i].divName)) 
	                       pnl = getObj(A[i].divName);
                    	
	                    lbl = pnl.getElementsByTagName(labelStr);
	                    if (lbl.length > 0)
		                    lbl = lbl[0];
                    	
	                    if(A[i].errorClass != null)
	                        lbl.className = A[i].errorClass;
	                    else
	                        lbl.className = errorLabelClassStr;
	                    
	                    if(lbl.multiPart != null)
	                        errorArray.push(lbl.id);
	                }
	                
	                if (A[i].errorText != null && A[i].errorText.length > 0)
                        errorStr += A[i].errorText + brStr;
                    else
                        errorStr += A[i].id + genericError;
                }
                else 
                {
                    //set the label back to normal
                    if(A[i].divName != null)
                    {
                        if (isString(A[i].divName)) 
	                       pnl = getObj(A[i].divName);
                    	
	                    lbl = pnl.getElementsByTagName(labelStr);
	                    if (lbl.length > 0)
		                    lbl = lbl[0];
                    	
                    	if(lbl.multiPart == null)
                    	{
	                        if(A[i].defaultClass != null)
	                            lbl.className = A[i].defaultClass;
	                        else
	                            lbl.className = emptyStr;
                        }
                        else
                        {
                            for(var index = 0; index < errorArray.length && !lblFound; index++)
                            {
                                lblId = errorArray[index];
                                if(lblId == lbl.id)
                                    lblFound = true;                            
                            }
                            
                            if(!lblFound)
                            {
                                if(A[i].defaultClass != null)
	                                lbl.className = A[i].defaultClass;
	                            else
	                                lbl.className = emptyStr;
                            }
                        }
	                }
                }
            }
            else
            {
               if (A[i].getAttribute(verifyStr) == trueStr && A[i].getAttribute(isRequiredStr) == trueStr && 
                    A[i].value.length == 0)
                {
                    errorFound = true;
                    
                    //set the label to a red color
                    if(A[i].getAttribute(divNameStr) != null)
                    {
                        if (isString(A[i].getAttribute(divNameStr))) 
	                       pnl = getObj(A[i].getAttribute(divNameStr));
                    	
	                    lbl = pnl.getElementsByTagName(labelStr);
	                    if (lbl.length > 0)
		                    lbl = lbl[0];

                        if(A[i].getAttribute(errorClassStr) != null)
        					lbl.className = A[i].getAttribute(errorClassStr);
	                    else
                            lbl.className = errorLabelClassStr;
    	                    
    	                if(lbl.getAttribute(multiPartStr) != null)
	                        errorArray.push(lbl.id);
	                }
                    
                    if (A[i].getAttribute(errorTextStr) != null && A[i].getAttribute(errorTextStr).length > 0)
                        errorStr += A[i].getAttribute(errorTextStr) + brStr;
                    else
                        errorStr += A[i].id + genericError;
                }
                else
                {
                    //set the label to normal
                    if(A[i].getAttribute(divNameStr) != null)
                    {
                        if (isString(A[i].getAttribute(divNameStr))) 
	                       pnl = getObj(A[i].getAttribute(divNameStr));
                    	
	                    lbl = pnl.getElementsByTagName(labelStr);
	                    if (lbl.length > 0)
		                    lbl = lbl[0];
                    	
                    	if(lbl.getAttribute(multiPartStr) == null)
                    	{
	                        if(A[i].getAttribute(defaultClassStr) != null)
	                            lbl.className = A[i].getAttribute(defaultClassStr);
	                        else
	                            lbl.className = emptyStr;
                        }
                        else
                        {
                            for(var index = 0; index < errorArray.length && !lblFound; index++)
                            {
                                lblId = errorArray[index];
                                if(lblId == lbl.id)
                                    lblFound = true;                            
                            }
                            
                            if(!lblFound)
                            {
                                if(A[i].defaultClass != null)
	                                lbl.className = A[i].getAttribute(defaultClassStr);
	                            else
	                                lbl.className = emptyStr;
                            }
                        }
	                }
                } 
            }//
        }
    }

    errorArray = null;
    
    if (errorFound)
    {
        errorStr = "<font size='3'>Missing \\ Incomplete Required Fields</font><br/><br/>" + errorStr;
        getObj("pnlError").innerHTML = errorStr;
        show("pnlError");
        scroll(0,0);
    }
    else
        hide("pnlError");
    
    return !errorFound;
}

function toggleVerifyAttribute(fieldName, theValue)
{
    var browserVersion = getInternetExplorerVersion();
    if(browserVersion > -1 && browserVersion < 9)
    {
        getObj(fieldName).verify = theValue;
    }
    else
    {
        getObj(fieldName).setAttribute('verify', theValue);
    }
}


function checkCalcInsFields()
{
    var genericError = " is a required field<br/>";
    var errorStr = "";
    var brStr = "<br/>";
    var theScen = QString("scen");
    var errorFound = false;

    //anLoanAmt
    if (getObj("pnlAmount").style.display == "")
    {
        if (getObj("anLoanAmt").value.length == 0)
        {
            if (getObj("anLoanAmt").errorText != null && getObj("anLoanAmt").errorText.length > 0)
                errorStr += getObj("anLoanAmt").errorText + brStr;
            else
                errorStr += getObj("anLoanAmt").id + genericError;
        }
    }
    else if (getObj("pnlAmount_Visa").style.display == "")
    {
        //credit amount
        if (getObj("anCredAmt").value.length == 0)
        {
            if (getObj("anCredAmt").errorText != null && getObj("anCredAmt").errorText.length > 0)
                errorStr += getObj("anCredAmt").errorText + brStr;
            else
                errorStr += getObj("anCredAmt").id + genericError;
        }
    }

    //int rate
    if(getObj("ignoreIntRateForPaymentCalc").innerHTML.length == 0)
    {
        if (getObj("anReqIntRate").value.length == 0)
        {
            if (getObj("anReqIntRate").errorText != null && getObj("anReqIntRate").errorText.length > 0)
                errorStr += getObj("anReqIntRate").errorText + brStr;
            else
                errorStr += getObj("anReqIntRate").id + genericError;
        }
    }

    //payment period
    if (getObj("anPmtPrd").options[getObj("anPmtPrd").options.selectedIndex].value.length == 0)
    {
        if(getObj("anPmtPrd").errorText != null && getObj("anPmtPrd").errorText.length > 0)
            errorStr += getObj("anPmtPrd").errorText + brStr;
        else
            errorStr += getObj("anPmtPrd").id + genericError;
    }

    //term
    if (getObj("anTerm").options[getObj("anTerm").options.selectedIndex].value.length == 0)
    {
        if (getObj("anTerm").errorText != null && getObj("anTerm").errorText.length > 0)
            errorStr += getObj("anTerm").errorText + brStr;
        else
            errorStr += getObj("anTerm").id + genericError;
    }
    
    if (errorStr.length > 0)
    {
        errorFound = true;
        errorStr = "<font size='3'>Missing \\ Incomplete Required Fields</font><br/><br/>" + errorStr;
        getObj("pnlError").innerHTML = errorStr;
        show("pnlError");
        scroll(0,0);
    }
    else
        hide("pnlError");
    
    return !errorFound;
}

//
//  Micro API to return an object 
//
function getObj(name) 
{     
  if (document.getElementById)  
  {
    if (document.getElementById(name))
  	    return document.getElementById(name);
  }
  else if (document.all)  
  {
	if (document.all[name])
	    return document.all[name];
  }
  else if (document.layers)  
  {
    if (document.layers[name]) 
    {
        this.style = document.layers[name];
   	    return document.layers[name]; 
   	}
  }
}

function getObjByElements(name) 
{
	var theForm = document.forms[0];

	return theForm.elements[name]; 
}

/*
    Add click, blur etc events
    usage: addEvent(object, event type [no 'on'], function, use Capture)
*/    
function addEvent(obj, evType, fn, useCapture)
{
  if (isString(obj)) obj = getObj(obj);
  
  if (obj.addEventListener)
  {
    obj.addEventListener(evType, fn, useCapture);
    return true;
  } 
  else if (obj.attachEvent) {
    var r = obj.attachEvent("on" + evType, fn);
    return r;
  } 
  else 
  {
    alert("Handler could not be attached");
  }
}


function removeEvent(obj, evType, fn, useCapture)
{
  if (obj.removeEventListener)
  {
    obj.removeEventListener(evType, fn, useCapture);
    return true;
  } 
  else if (obj.detachEvent) {
    var r = obj.detachEvent("on" + evType, fn);
    return r;
  } 
  else 
  {
    alert("Handler could not be removed");
  }
}

function returnActiveElement(e) 
{
    var el;
    if (window.event && window.event.srcElement)
        el = window.event.srcElement;
    if (e && e.target)
        el = e.target;  
    return el;
}



function QString(qsParam) 
{
  nvString = "&" + location.search.substring(1, location.search.length) + "&"
  paramBegin = nvString.indexOf("&" + qsParam + "=")
  if (paramBegin != -1) {
    valBegin = (paramBegin*-1-qsParam.length-2)*-1
    qsVal = nvString.substring(valBegin, nvString.indexOf("&", valBegin))
    if (qsVal != "") {return unescape(qsVal)}
     else {
        return ""
     }
  }
  else {
     return ""
  }
}


// If the radio (obj) is checked, show the panels
//
function radToggle(obj, panels) 
{
	if (isString(obj)) 
        obj = getObjByElements(obj);
	
	
	if (obj != null && obj.checked)
		show(panels);
	else
		hide(panels);	
}

// If the selectedIndex matches sIndex, show the panels
//
function cboToggle(obj, panels, sIndex) 
{	
	// This will take arrays of objects, but they all need to match the same sIndex

	var match = true;
	var optSel;

	if (isArray(obj)) 
	{		
		var tarLen = obj.length;
		
		for (var i = 0; i < tarLen; i++ ) {
			if (isString(obj[i])) obj[i] = getObj(obj[i]);
			optSel = obj[i].options.selectedIndex;
			if (optSel != sIndex) match = false;
		}		
	}
	else 
	{
		if (isString(obj)) 
		   obj = getObj(obj);
		
		optSel = obj.options.selectedIndex;
		
		if (optSel != sIndex) 
		   match = false;
	}
	
	if (match) {	
		show(panels); 
	}
	else {
		hide(panels);
	}
	

}

//
// START: NavGlobalPod 
//
function navglobalpod() 
{	
	var pnlNavGlobalPod = getObj('navglobalpod');
	
	if (pnlNavGlobalPod) {
		pnlNavGlobalPod.innerHTML = "<form action='/search/index.asp' method='GET' name='searchResults1'><ul><li><a href='#'>contact us</a></li><li><input type='text' name='tx0' id='search' value='' />&nbsp;<input type='submit' name='submit' class='small' value='Search' /></li></ul></form>";
	}	
}
/* END: NavGlobalPod */

//
// START: NavFooter 
//
function navfooter() 
{	
	var pnlNavFooter = getObj('navfooter');
	
	if (pnlNavFooter) {
		pnlNavFooter.innerHTML = "<ul><li><a href='#'>about us</a></li><li><a href='#'>legal</a></li><li><a href='#'>privacy</a></li><li><a href='#'>security</a></li><li><a href='#'>site map</a></li></ul>";
	}	
}
/* END: NavFooter */

//
// START: Footer 
//
function footer() 
{
//	var pnlFooter = getObj('footer');
//	
//	if (pnlFooter) {
//		pnlFooter.innerHTML = "These screens are intended for demonstration purposes only.<br/>" +
//            "Printing these screens for distribution " +
//            "to customers is prohibited.<br/> Copyright &copy; 2007 S1 Corporation. All rights reserved.";
//	}
}
/* END: Footer */

/* START: Expand and contract */


function toggle(target) 
{
	if (isString(target)) 
	   target = getObj(target);
	
    if (!target) 
    { 
       return false; 
    }
    
	if (isArray(target)) 
	{
		var tarLen = target.length;
		for (var i = 0; i < tarLen; i++ ) {
			toggle(target[i]);
		}
	} 
	else {	
    	target.style.display = (target.style.display == "none") ? "" : "none";
	}
}

function show(target) 
{
	if (isString(target))
    {
        targetStr = target;
        target = getObj(target);
    }
	
    var t;
	if (isArray(target)) 
	{
		var tarLen = target.length;
		for (var i = 0; i < tarLen; i++ ) {
			show(target[i]);
		}
	} 
	else {
	    if (t = target) {   	    		
    		t.style.display = "";
            enableDisableRequiredFields(targetStr, true);
		    return true;    
		}
		else {
		    return false; 
		}
	}
}

function hide(target) 
{
	if (isString(target)) 
    {
        targetStr = target;
        target = getObj(target);
    }

    var t;
	if (isArray(target)) 
	{
		var tarLen = target.length;
		for (var i = 0; i < tarLen; i++ ) {
			hide(target[i]);
		}
	} 
	else {
        if (t = target)
        {
            var browserVersion = getInternetExplorerVersion();
            if (browserVersion > -1 && browserVersion == 9)
                window.focus();

			t.style.display = "none";
            enableDisableRequiredFields(targetStr, false);
		    return true; 
		}
		else {
		    return false;	
		}
	}
}

//disables input and select fields within the given panel\div element
//
function enableDisableRequiredFields(pa, enableRF)
{
    var pa = document.getElementById(pa);

    if (!pa)
        pa = document.body;

    var A = null;
    var L = null;

    for (var x = 0; x <= 1; x++)
    {
        if (x == 0)
        {
            A = pa.getElementsByTagName('input');
            L = A.length;
        }
        else
        {
            A = pa.getElementsByTagName('select');
            L = A.length;
        }

        // loop through all of the elements
        for (var i = 0; i < L; i++)
        {
            if (A[i].isRequired || A[i].getAttribute('isRequired') == "true")
            {
                if (enableRF)
                    doEnable(A[i].id);
                else
                    doDisable(A[i].id);
            }
        }
    }
}

function doEnable(target) 
{
	if (isString(target)) 
        target = getObj(target);
	
    var t;
    var browserVersion = getInternetExplorerVersion();
	if (isArray(target)) 
	{
		var tarLen = target.length;
		for (var i = 0; i < tarLen; i++ ) {
			doEnable(target[i]);
		}
	} 
    else {
	    if (t = target) 
	    {
            if(browserVersion > -1 && browserVersion < 9)
                t.verify = true;
            else
        		t.setAttribute('verify', true);
            
		    return true;    
        }
		else {
		    return false; 
		}
	}
}

function doDisable(target) 
{
	if (isString(target)) 
        target = getObj(target);

    var t;
    var browserVersion = getInternetExplorerVersion();
	if (isArray(target)) 
    {
		var tarLen = target.length;
		for (var i = 0; i < tarLen; i++ ) {
			doDisable(target[i]);
		}
	} 
    else {
        if (t = target) 
        {
            if(browserVersion > -1 && browserVersion < 9)
                t.verify = false;
            else
			    t.setAttribute('verify', false);
		    return true; 
        }
		else {
		    return false;	
		}
	}
}

function toggleHeader(e) 
{
	var el = returnActiveElement(e);
	if (!el) 
	   return;

	// Actually grab the header div, not any child elements that might have actually
	// captured the event.
	//
	while (el.className.indexOf("tabsc") < 0) { 
	   el = el.parentNode 
	};

	
	nextSib = el.nextSibling;	
	while (nextSib.nodeType != 1) 
	   nextSib = nextSib.nextSibling;
	   
	//alert(nextSib.getAttribute("id"));

	el.className = (el.className == "tabsc") ? "tabsc_expanded" : "tabsc"; 
	nextSib.className = "tabsc_content";
	toggle(nextSib);
}
/* END: Expand and contract */


function grayOutScreen() 
{
	if (!getObj("pnlGrayOut")) 
	{
		bod = document.getElementsByTagName('body')[0];
		overlay = document.createElement('div');
		overlay.id = 'pnlGrayOut';
		bod.appendChild(overlay);
	}
	else {
		show("pnlGrayOut");	
	}
}

function addOption(selectbox,text,value )
{
	if (isString(selectbox)) 
	   selectbox = getObj(selectbox);
	   
	var optn = document.createElement("OPTION");
	optn.text = text;
	optn.value = value;
	selectbox.options.add(optn);
}


/* START: Tool tips */
function doTooltip(e, msg) 
{
  if ( typeof Tooltip == "undefined" || !Tooltip.ready ) 
     return;
     
  Tooltip.show(e, msg);
}

function hideTip() 
{
  if ( typeof Tooltip == "undefined" || !Tooltip.ready ) 
     return;
  
  Tooltip.hide();
}
/* END: Tool tips */




// Validation - Thanks W3Schools.

function validate_required(field)
{
	with (field)
	{
		if (value == null || value == "")
			{return false}
		else
			{return true}
	}
}

function validate_email(field)
{
	with (field)
	{
		apos = value.indexOf("@")
		dotpos = value.lastIndexOf(".")
		if (apos < 1 || dotpos-apos < 2) {return false}
		else {return true}
	}
}

// End Validation



function setError(txt) 
{
	document.location += "&error=" + txt;
}

function hideError() 
{
	hide("pnlError");	
}


function changeLabel(pnl, txt) 
{
	if (isString(pnl)) 
	   pnl = getObj(pnl);
	
	var lbl = pnl.getElementsByTagName("label");
	
	if (lbl.length > 0) {
		lbl = lbl[0];
	}
	
	lbl.innerHTML = txt;
}

/* START: Initialize Function to Replace document.write */
addEvent(window, 'load', InitializeMain);

function InitializeMain() 
{
	navfooter();
//    footer();
	
	if (QString("error")) {
		getObj("pnlError").innerHTML = QString("error");
		show("pnlError");
	}
}

// End - Master.js
