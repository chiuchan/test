/**
 * Title:        Credisphere
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      X/Net Associates
 * @author
 * @version 1.0
 */

package com.xnai.credisphere.appImport;
import org.jdom.Element;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import java.util.StringTokenizer;
import java.util.TreeMap;

import com.xnai.net.xResponse;

import com.xnai.credisphere.businessConfig.BusinessConfig;
import com.xnai.credisphere.calcs.FeeCalcs;
import com.xnai.credisphere.calcs.FinCalcs;
import com.xnai.credisphere.calcs.MGCalcEstimator;
import com.xnai.credisphere.calcs.PmtCalcs;
import com.xnai.credisphere.collateralEditor.Collateral;
import com.xnai.credisphere.dataCache.CSDataCache;
import com.xnai.credisphere.db.DBAccess;
import com.xnai.credisphere.db.DBLogger;
import com.xnai.credisphere.db.DBQueries;
import com.xnai.credisphere.db.DBUtils;
import com.xnai.credisphere.eDocArch.EDocArchSupport;
import com.xnai.credisphere.indexRateEditor.IndexRate;
import com.xnai.credisphere.locations.Location;
import com.xnai.credisphere.mtgProduct.MtgProduct;
import com.xnai.credisphere.productEditor.GenericProduct;
import com.xnai.credisphere.productEditor.Product;
import com.xnai.credisphere.productEditor.ProductPricing;
import com.xnai.credisphere.program.Program;
import com.xnai.credisphere.SBProductEditor.SBProduct;
import com.xnai.credisphere.util.CSDataCollection;
import com.xnai.credisphere.util.CSFieldNames;
import com.xnai.credisphere.util.CSFieldValues;
import com.xnai.credisphere.util.CSStatusCodes;
import com.xnai.credisphere.util.CSUtil;
import com.xnai.credisphere.util.DataCollection;
import com.xnai.credisphere.util.DataEntrySupport;
import com.xnai.credisphere.util.DecisionUtils;
import com.xnai.credisphere.deposits.DepUtils;
import com.xnai.credisphere.util.MGUtils;
import com.xnai.credisphere.util.NodeUtils;
import com.xnai.credisphere.util.SDOUtils;
import com.xnai.mulder.application.ApplicationHouse;
import com.xnai.mulder.application.ListAssignments;
import com.xnai.mulder.application.ListCodeAssignments;
import com.xnai.mulder.application.ListCodes;
import com.xnai.mulder.dbInterface.DbElements;
import com.xnai.mulder.dbInterface.DbHelper;
import com.xnai.mulder.dbInterface.DBErrorLogger;
import com.xnai.mulder.dbInterface.DBConnPool;

import com.xnai.mulder.mail.MailMessage;
import com.xnai.mulder.systemCore.FileManager;
import com.xnai.mulder.systemCore.SystemProperties;
import com.xnai.mulder.systemObject.DataNode;
import com.xnai.mulder.systemObject.SystemDataObject;
import com.xnai.mulder.util.ClientUtils;
import com.xnai.mulder.util.Configuration;
import com.xnai.mulder.util.DataFile;
import com.xnai.mulder.util.DateUtility;
import com.xnai.mulder.util.ExceptionLogger;
import com.xnai.mulder.util.GeneralToolkit;
import com.xnai.mulder.util.HashtableX;
import com.xnai.mulder.util.S1Log;
import com.xnai.mulder.util.StringChanger;
import com.xnai.mulder.util.StringSupport;
import com.xnai.mulder.util.VectorX;
import com.xnai.mulder.visual.TableRecord;
import com.xnai.mulder.visual.TableTransaction;
import com.xnai.mulder.util.CmdEvaluator;
import com.xnai.mulder.util.FileTemplate;


public class AppImportUtils extends S1Log
{
  private static boolean LOG = true;

  private static final String  AIU = "AppImportUtils.log";
  private static final String US_DR_LIC = "US Driver License";

  private static final String SECTION_NAME = "Asset And Liability Sub Types";
  /*
  [Asset And Liability Sub Types]
  !!_BLANK=!!_BLANK
  AstCash=Cash, Savings and CD's
  AstStkBd=Stocks and Bonds
  AstNtRcv=Notes Receivable
  AstLI=Life Insurance Policies
  AstVh=Vehicles
  AstRE=Real Estate Properties
  AstBs=Business Assets
  AstBsActRcv=Business Accounts Receivable
  AstOth=Other Assets
  LbNtPy=Notes Payable Banks
  LbOthNtPy=Other Notes Payable
  LbMtg=Mortgage
  LbCC=Credit Cards
  LbTx=Taxes Payable
  LbOth=Other Liabilities
  */

  private static final String ASSET_SUB_TYPES = "Asset Sub Types";
  /*
  [Asset Sub Types]
  !!_BLANK=!!_BLANK
  AstCash=Cash, Savings and CD's
  AstStkBd=Stocks and Bonds
  AstLI=Life Insurance Policies
  AstRE=Real Estate Properties
  AstRF=Retirement Funds
  AstBs=Business Assets
  AstVh=Vehicles
  AstOth=Other Assets
  */

  private static final String LIABILITY_SUB_TYPES = "Liability Sub Types";
  /*
  [Liability Sub Types]
  !!_BLANK=!!_BLANK
  LbGen=Liability
  LbACS=Alimony Child Support
  LbJRE=Job Related Expense
  */


  private static final GeneralToolkit general = new GeneralToolkit();

  private static final ListCodes listCodesCache        = ApplicationHouse.getListCodesCache();
  private static final ListAssignments listAssignCache = ApplicationHouse.getListAssignmentCache();
  private static final ListCodeAssignments listCodeAssignCache = ApplicationHouse.getListCodeAssignmentCache();

  private static final String AST_SUB_TYPE_PREFIX = "Ast";
  private static final String LB_SUB_TYPE_PREFIX = "Lb";

  private static DataFile LOG_FILE = null;

  static
  {
    try
    {
      createLogFile();
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }


  private AppImportUtils()
  {
    // fall through
  }

  // # 1
  //
  // no collateral to be processed
  //
  public static void processApplicationData( Map inHash,   Map appData,  Map bwr0Data,
                                             Map bwr1Data )
  {
    String fieldName = null;
    String fieldVal  = null;

    Iterator it = inHash.keySet().iterator();

    while (it.hasNext())
    {
      fieldName = (String)it.next();

      Object obj = inHash.get(fieldName);

      if( obj instanceof String )
          {
          fieldVal  = (String)inHash.get(fieldName);
          }
      else if( obj instanceof VectorX )
          {
          fieldVal  = ( (VectorX)inHash.get(fieldName) ).toString();
          }
      else
          {
          continue;
          }

      if( fieldName.startsWith("an") )
      {
        appData.put(fieldName, fieldVal);
      }
      else if (fieldName.startsWith("at"))
      {
        // We need to remove the index from the end of the field name.  We
        // will not need this when building the data node structure.
        //
        if (fieldName.endsWith("_0"))
        {
          bwr0Data.put(fieldName.substring(0, fieldName.length() - 2), fieldVal);
        }
        else if (fieldName.endsWith("_1"))
        {
          bwr1Data.put(fieldName.substring(0, fieldName.length() - 2), fieldVal);
        }
      }
    }
  }


  // # 2
  //
  // no multiple collaterals or disbursement
  //
  public static void processApplicationData( Map inHash,   Map appData,  Map bwr0Data,
                                             Map bwr1Data, Map collData )
  {
    String fieldName = null;
    String fieldVal  = null;

    Iterator it = inHash.keySet().iterator();

    while (it.hasNext())
    {
      fieldName = (String)it.next();

      Object obj = inHash.get(fieldName);

      if( obj instanceof String )
          {
          fieldVal  = (String)inHash.get(fieldName);
          }
      else if( obj instanceof VectorX )
          {
          fieldVal  = ( (VectorX)inHash.get(fieldName) ).toString();
          }
      else
          {
          continue;
          }

      if (fieldName.startsWith("an") || fieldName.startsWith("www") )
      {
        appData.put(fieldName, fieldVal);
      }
      else if (fieldName.startsWith("at"))
      {
        // We need to remove the index from the end of the field name.  We
        // will not need this when building the data node structure.
        //
        if (fieldName.endsWith("_0"))
        {
          bwr0Data.put(fieldName.substring(0, fieldName.length() - 2), fieldVal);
        }
        else if (fieldName.endsWith("_1"))
        {
          bwr1Data.put(fieldName.substring(0, fieldName.length() - 2), fieldVal);
        }
      }
      else if (fieldName.startsWith("cl"))
      {
        collData.put(fieldName, fieldVal);
      }
      else if (fieldName.startsWith("phy"))
      {
        collData.put(fieldName, fieldVal);
      }
    }
  }


  // # 3
  //
  // overload method to process disbursement data for psecu
  //
  public static void processApplicationData( Map inHash,    Map appData,
                                             Map bwr0Data,  Map bwr1Data,
                                             Map coll0Data, Map coll1Data, Map disbData )
  {
    String fieldName = null;
    String fieldVal  = null;

    Iterator it = inHash.keySet().iterator();

    while (it.hasNext())
      {
      fieldName = (String)it.next();

      Object obj = inHash.get(fieldName);

      if( obj instanceof String )
          {
          fieldVal  = (String)inHash.get(fieldName);
          }
      else if( obj instanceof VectorX )
          {
          fieldVal  = ( (VectorX)inHash.get(fieldName) ).toString();
          }
      else if( obj instanceof HashtableX )
          {
          fieldVal  = ( (HashtableX)inHash.get(fieldName) ).toString();
          }
      else
          {
          continue;
          }

      // application data
      //
      if( fieldName.startsWith("an") || fieldName.startsWith("www") || fieldName.startsWith("hm") )
          {
          appData.put(fieldName, fieldVal);
          }

      // applicant / borrower data
      //
      else if (fieldName.startsWith("at"))
          {
          // We need to remove the index from the end of the field name.  We
          // will not need this when building the data node structure.
          //
          if (fieldName.endsWith("_0"))
              {
              bwr0Data.put(fieldName.substring(0, fieldName.length() - 2), fieldVal);
              }
          else if (fieldName.endsWith("_1"))
              {
              bwr1Data.put(fieldName.substring(0, fieldName.length() - 2), fieldVal);
              }
          }

      // auto collateral
      //
      // data table for multiple collateral "clCollData_1"
      //
      else if ( fieldName.startsWith("cl") )
          {
          if( fieldName.endsWith("_0") )
              {
                // coll0Data.put(fieldName.substring(0, fieldName.length() - 2), fieldVal);
                //
                // process the insurance fields, remove the prefix cl_
                //
                //errorLog("",AIU);errorLog("if( fieldName.startsWith(clCollData_0) ): "+( fieldName.startsWith("clCollData_0") ),AIU);errorLog("",AIU);

                if( fieldName.startsWith("clCollData_0") )
                {
                  coll0Data.put(fieldName.substring(0, fieldName.length() - 2), fieldVal);
                }
                else if( fieldName.startsWith("cl_inComp") || fieldName.startsWith("cl_inPlcyNo") )
                {
                  coll0Data.put(fieldName.substring(3, fieldName.length() - 2), fieldVal);
                }
                else
                {
                  coll0Data.put(fieldName.substring(0, fieldName.length() - 2), fieldVal);
                }
              }
          else if (fieldName.endsWith("_1"))
              {
                // process the insurance fields, remove the prefix cl_
                //
                if( fieldName.startsWith("clCollData_1") )
                {
                  coll1Data.put(fieldName.substring(0, fieldName.length() - 2), fieldVal);
                }
                else if( fieldName.startsWith("cl_inComp") || fieldName.startsWith("cl_inPlcyNo") )
                {
                  coll1Data.put(fieldName.substring(3, fieldName.length() - 2), fieldVal);
                }
                else
                {
                  coll1Data.put(fieldName.substring(0, fieldName.length() - 2), fieldVal);
                }
              }
          } // else if ( fieldName.startsWith("cl") )

      // real estate collateral
      //
      else if ( fieldName.startsWith("phy") || fieldName.startsWith("lw") )
          {
          if( fieldName.endsWith("_0") )
              {
              coll0Data.put(fieldName.substring(0, fieldName.length() - 2), fieldVal);
              }
          else if (fieldName.endsWith("_1"))
              {
              coll1Data.put(fieldName.substring(0, fieldName.length() - 2), fieldVal);
              }

          } // if/ else/if stmts

      // generic collateral
      //
      else if ( fieldName.startsWith("ucc") )
          {
          if( fieldName.endsWith("_0") )
              {
              coll0Data.put(fieldName.substring(0, fieldName.length() - 2), fieldVal);
              }
          else if (fieldName.endsWith("_1"))
              {
              coll1Data.put(fieldName.substring(0, fieldName.length() - 2), fieldVal);
              }

          } // if/ else/if stmts

      // disbursement data
      //
      else if (fieldName.startsWith("dsb"))
          {
          disbData.put(fieldName, fieldVal);
          }

      } // while (it.hasNext())

     //errorLog("# END 3 processApplicationData(...)",AIU);

  } // public static void processApplicationData( PSECU )

  // # 3.5
  //
  // method for ESL
  //
  public static void processApplicationDataESL( Map inHash,    Map appData,
                                                Map bwr0Data,  List coAppDataVec,
                                                Map coll0Data, Map coll1Data, Map disbData )
  {
   //errorLog("# 3 processApplicationData(...)",AIU);
   //errorLog("inHash: "+inHash,AIU);

    HashtableX bwr1Data = new HashtableX();
    HashtableX bwr2Data = new HashtableX();
    HashtableX bwr3Data = new HashtableX();
    HashtableX bwr4Data = new HashtableX();

    String fieldName = null;
    String fieldVal  = null;

    Iterator it = inHash.keySet().iterator();

    while (it.hasNext())
    {
      fieldName = (String)it.next();
     //errorLog("fieldName: "+fieldName,AIU);

      Object obj = inHash.get(fieldName);

     //errorLog("obj: "+obj,AIU);
     //errorLog("CLASS obj: "+obj.getClass(),AIU);

      if( obj instanceof String )
          {
          fieldVal  = (String)inHash.get(fieldName);
          }
      else if( obj instanceof VectorX )
          {
          fieldVal  = ( (VectorX)inHash.get(fieldName) ).toString();
          }
      else if( obj instanceof HashtableX )
          {
          fieldVal  = ( (HashtableX)inHash.get(fieldName) ).toString();
          }
      else
          {
          continue;
          }

     //errorLog("",AIU);errorLog("fieldVal: "+fieldVal,AIU);errorLog("",AIU);
     //errorLog("",AIU);errorLog("CLASS fieldVal: "+fieldVal.getClass(),AIU);errorLog("",AIU);

      // application data
      //
      if( fieldName.startsWith("an") || fieldName.startsWith("www") || fieldName.startsWith("hm") )
          {
          appData.put(fieldName, fieldVal);
          }

      // applicant / borrower data
      //
      else if (fieldName.startsWith("at"))
          {
          // We need to remove the index from the end of the field name.  We
          // will not need this when building the data node structure.
          //
          if (fieldName.endsWith("_0"))
              {
              bwr0Data.put(fieldName.substring(0, fieldName.length() - 2), fieldVal);
              }
          else if (fieldName.endsWith("_1") )
              {
              bwr1Data.put(fieldName.substring(0, fieldName.length() - 2), fieldVal);
              }
          else if (fieldName.endsWith("_2") )
              {
              bwr2Data.put(fieldName.substring(0, fieldName.length() - 2), fieldVal);
              }
          else if (fieldName.endsWith("_3") )
              {
              bwr3Data.put(fieldName.substring(0, fieldName.length() - 2), fieldVal);
              }
          else if (fieldName.endsWith("_4") )
              {
              bwr4Data.put(fieldName.substring(0, fieldName.length() - 2), fieldVal);
              }
          }

      // auto collateral
      //
      // data table for multiple collateral "clCollData_1"
      //
      else if ( fieldName.startsWith("cl") )
          {
          if( fieldName.endsWith("_0") )
              {
                // coll0Data.put(fieldName.substring(0, fieldName.length() - 2), fieldVal);
                //
                // process the insurance fields, remove the prefix cl_
                //
               //errorLog("",AIU);errorLog("if( fieldName.startsWith(clCollData_0) ): "+( fieldName.startsWith("clCollData_0") ),AIU);errorLog("",AIU);

                if( fieldName.startsWith("clCollData_0") )
                {
                 //errorLog("",AIU);errorLog("PROCES fieldName: "+fieldName,AIU);errorLog("",AIU);
                 //errorLog("",AIU);errorLog("PUT fieldName: "+fieldName.substring(3, fieldName.length() - 2),AIU);errorLog("",AIU);
                 //errorLog("",AIU);errorLog("PUT fieldVal: "+fieldVal,AIU);errorLog("",AIU);
                  coll0Data.put(fieldName.substring(0, fieldName.length() - 2), fieldVal);
                }
                else if( fieldName.startsWith("cl_inComp") || fieldName.startsWith("cl_inPlcyNo") )
                {
                  coll0Data.put(fieldName.substring(3, fieldName.length() - 2), fieldVal);
                }
                else
                {
                  coll0Data.put(fieldName.substring(0, fieldName.length() - 2), fieldVal);
                }
              }
          else if (fieldName.endsWith("_1"))
              {
                // coll1Data.put(fieldName.substring(0, fieldName.length() - 2), fieldVal);
                //
                // process the insurance fields, remove the prefix cl_
                //
               //errorLog("",AIU);errorLog("if( fieldName.startsWith(clCollData_1) ): "+( fieldName.startsWith("clCollData_1") ),AIU);errorLog("",AIU);

                if( fieldName.startsWith("clCollData_1") )
                {
                  coll1Data.put(fieldName.substring(0, fieldName.length() - 2), fieldVal);
                }
                else if( fieldName.startsWith("cl_inComp") || fieldName.startsWith("cl_inPlcyNo") )
                {
                  coll1Data.put(fieldName.substring(3, fieldName.length() - 2), fieldVal);
                }
                else
                {
                  coll1Data.put(fieldName.substring(0, fieldName.length() - 2), fieldVal);
                }
              }
          } // else if ( fieldName.startsWith("cl") )

      // real estate collateral
      //
      else if ( fieldName.startsWith("phy") || fieldName.startsWith("lw") )
          {
          if( fieldName.endsWith("_0") )
              {
              coll0Data.put(fieldName.substring(0, fieldName.length() - 2), fieldVal);
              }
          else if (fieldName.endsWith("_1"))
              {
              coll1Data.put(fieldName.substring(0, fieldName.length() - 2), fieldVal);
              }

          } // if/ else/if stmts

      // generic collateral
      //
      else if ( fieldName.startsWith("ucc") )
          {
          if( fieldName.endsWith("_0") )
              {
              coll0Data.put(fieldName.substring(0, fieldName.length() - 2), fieldVal);
              }
          else if (fieldName.endsWith("_1"))
              {
              coll1Data.put(fieldName.substring(0, fieldName.length() - 2), fieldVal);
              }

          } // if/ else/if stmts

      // disbursement data
      //
      else if (fieldName.startsWith("dsb"))
          {
          disbData.put(fieldName, fieldVal);
          }

    } // while (it.hasNext())

    // load co app bwr vec for multiple co apps
    //
    if( bwr1Data != null && ! bwr1Data.isEmpty() ) { coAppDataVec.add( bwr1Data ); }
    if( bwr2Data != null && ! bwr2Data.isEmpty() ) { coAppDataVec.add( bwr2Data ); }
    if( bwr3Data != null && ! bwr3Data.isEmpty() ) { coAppDataVec.add( bwr3Data ); }
    if( bwr4Data != null && ! bwr4Data.isEmpty() ) { coAppDataVec.add( bwr4Data ); }

  } // public static void processApplicationDataESL( ESL )

  // # 4
  //
  // overload method to process business data
  //
  public static void processApplicationData( Map inHash,    Map appData,
                                             Map busInfoData, Map busDepAcctData, Map busObData,
                                             Map bwr0Data,  Map bwr1Data,
                                             Map coll0Data, Map coll1Data, Map disbData )
  {
    //general.errLog("# 4 START processApplicationData(...)",AIU);
    //general.errLog("inHash: "+inHash,AIU);

    String fieldName = null;
    String fieldVal  = null;

    Iterator it = inHash.keySet().iterator();

    while (it.hasNext())
      {
      fieldName = (String)it.next();
      //general.errLog("fieldName: "+fieldName,AIU);

      Object obj = inHash.get(fieldName);

      //general.errLog("obj: "+obj,AIU);
      //general.errLog("CLASS obj: "+obj.getClass(),AIU);

      if( obj instanceof String )
          {
          fieldVal  = (String)inHash.get(fieldName);
          }
      else if( obj instanceof VectorX )
          {
          fieldVal  = ( (VectorX)inHash.get(fieldName) ).toString();
          }
      else if( obj instanceof HashtableX )
          {
          fieldVal  = ( (HashtableX)inHash.get(fieldName) ).toString();
          }
      else
          {
          continue;
          }

      //general.errLog("",AIU);//general.errLog("fieldVal: "+fieldVal,AIU);//general.errLog("",AIU);
      //general.errLog("",AIU);//general.errLog("CLASS fieldVal: "+fieldVal.getClass(),AIU);//general.errLog("",AIU);

      // application data
      //
      if( fieldName.startsWith("an") || fieldName.startsWith("www") || fieldName.startsWith("hm") )
          {
            appData.put(fieldName, fieldVal );
          }

      // business data
      //
      if( fieldName.startsWith("be") )
          {
            //general.errLog("be fieldName: "+fieldName,AIU);
            //general.errLog("be fieldVal: "+fieldVal,AIU);

            busInfoData.put(fieldName, fieldVal);
          }

      if( fieldName.startsWith("bda") )
          {
            //general.errLog("bda fieldName: "+fieldName,AIU);
            //general.errLog("bda fieldVal: "+fieldVal,AIU);

            busDepAcctData.put(fieldName, fieldVal);
          }

      //general.errLog("busDepAcctData: "+busDepAcctData,AIU);

      if( fieldName.startsWith("bo") )
          {
            //general.errLog("bo fieldName: "+fieldName,AIU);
            //general.errLog("bo fieldVal: "+fieldVal,AIU);

            busObData.put(fieldName, fieldVal);
          }

      //general.errLog("busObData: "+busObData,AIU);

      // applicant / borrower data
      //
      if (fieldName.startsWith("at"))
          {
          // We need to remove the index from the end of the field name.  We
          // will not need this when building the data node structure.
          //
          if (fieldName.endsWith("_0"))
              {
                bwr0Data.put(fieldName.substring(0, fieldName.length() - 2), fieldVal);
              }
          else if (fieldName.endsWith("_1"))
              {
                bwr1Data.put(fieldName.substring(0, fieldName.length() - 2), fieldVal);
              }
          }

      // auto collateral
      //
      else if ( fieldName.startsWith("cl") )
          {
          if( fieldName.endsWith("_0") )
              {
                // process the insurance fields, remove the prefix cl_
                //
                if( fieldName.startsWith("cl_inComp") || fieldName.startsWith("cl_inPlcyNo") )
                {
                  coll0Data.put(fieldName.substring(3, fieldName.length() - 2), fieldVal);
                }
                else
                {
                  coll0Data.put(fieldName.substring(0, fieldName.length() - 2), fieldVal);
                }
              }
          else if (fieldName.endsWith("_1"))
              {
                  // process the insurance fields, remove the prefix cl_
                  //
                  if( fieldName.startsWith("cl_inComp") || fieldName.startsWith("cl_inPlcyNo") )
                  {
                    coll1Data.put(fieldName.substring(3, fieldName.length() - 2), fieldVal);
                  }
                  else
                  {
                    coll1Data.put(fieldName.substring(0, fieldName.length() - 2), fieldVal);
                  }
              }
          }

      // real estate collateral
      //
      else if ( fieldName.startsWith("phy") || fieldName.startsWith("lw") )
          {
          if( fieldName.endsWith("_0") )
              {
                coll0Data.put(fieldName.substring(0, fieldName.length() - 2), fieldVal);
              }
          else if (fieldName.endsWith("_1"))
              {
                coll1Data.put(fieldName.substring(0, fieldName.length() - 2), fieldVal);
              }

          } // if/ else/if stmts

      // disbursement data
      //
      else if (fieldName.startsWith("dsb"))
          {
            disbData.put(fieldName, fieldVal);
          }

      } // while (it.hasNext())

    //general.errLog("# 4 END processApplicationData(...)",AIU);

  } // public static void processApplicationData( BUSINESS )


  // gets the first internet id also *******************************************
  //
  public static String getInternetBranchID() throws SQLException
      {
      return getFirstInternetBranchID();
      }

  public static String getFirstInternetBranchID() throws SQLException
      {
      return getFirstInternetBranchID( new ArrayList() );
      }

  // returns branch id entry whose column cInternet is set true
  //
  public static String getFirstInternetBranchID( List branchList ) throws SQLException
      {
      //general.errLog("getFirstInternetBranchID( List branchList "+branchList+")");

      String whereClause = Location.create_SQL_WHERE_Clause( branchList );

      //general.errLog("whereClause: "+whereClause);

      String sql = "SET ROWCOUNT 1 SELECT * FROM xntLocations " + whereClause +
                   "AND nLevelId = 500 AND cInternet = '"+CSFieldNames.TRUE_STRING+"' SET ROWCOUNT 0";

      //general.errLog("sql: "+sql);

      Statement stmt  = null;
      String branchID = null;

      try
        {
        Connection con = DBAccess.getConnection();
        stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery(sql);

        if (rs.next())
            {
            branchID = rs.getString("nLocId");
            }
        }
      catch (SQLException e)
          {
          DBLogger.log("Executing " + sql + ": " + e);
          throw e;
          }
      finally
          {
          DBAccess.closeConnection(stmt);
          }

      //general.errLog("branchID: "+branchID);

      return branchID;
      }



  public static String getDealerLocationID(String dealerID) throws SQLException
  {
    String sql = "SELECT cLoc FROM xntDealers WHERE nDealerId = " + dealerID;

    Statement stmt    = null;
    String locationID = null;

    try
    {
      Connection con = DBAccess.getConnection();
      stmt = con.createStatement();
      ResultSet rs = stmt.executeQuery(sql);

      if (rs.next())
      {
        locationID = rs.getString("nLocId");
      }
    }
    catch (SQLException e)
    {
      DBLogger.log("Executing " + sql + ": " + e);
      throw e;
    }
    finally
    {
      DBAccess.closeConnection(stmt);
    }

    return locationID;
  }

  // compare incoming dealer id to cLoc first for safe. if match get dealer Id and branchId.
  // else compare dealer id to nBranchId. if match get dealer Id and branchId.
  //
  public static List getDealerBranchID(String xmlDealerID) throws SQLException
  {
    //general.errLog("START getDealerBranchID(String dealerID): ",AIU);
    //general.errLog("dealerID: "+xmlDealerID,AIU);

    // String sql = "SELECT nBranchId FROM xntDealers WHERE nDealerId = " + dealerID;
    //
    String sql = "SELECT nBranchId, nDealerId FROM xntDealers WHERE cLoc = '" + xmlDealerID +"'";
    //general.errLog("sql 1: "+sql,AIU);

    Statement stmt  = null;
    String branchID = null;
    String dealerID = null;
    List idList = new ArrayList();

    try
    {
      Connection con = DBAccess.getConnection();
      stmt = con.createStatement();
      ResultSet rs = stmt.executeQuery(sql);

      if (rs.next())
      {
        branchID = String.valueOf( rs.getInt("nBranchId") );
        //general.errLog("branchID 1: "+branchID,AIU);

        idList.add( isValidString( branchID ) ? branchID : CSFieldValues.EMPTY_STRING );

        dealerID = String.valueOf( rs.getInt("nDealerId") );
        //general.errLog("dealerID 1: "+dealerID,AIU);

        idList.add( isValidString( dealerID ) ? dealerID : CSFieldValues.EMPTY_STRING );
      }
      else
      {
        sql = "SELECT nBranchId FROM xntDealers WHERE nDealerId = " + xmlDealerID;
        //general.errLog("sql 2: "+sql,AIU);

        rs = stmt.executeQuery(sql);
        if (rs.next())
        {
          branchID = rs.getString("nBranchId");

          //general.errLog("branchID 2: "+branchID,AIU);
          //general.errLog("dealerID 2: "+xmlDealerID,AIU);

          idList.add( isValidString( branchID )    ? branchID    : CSFieldValues.EMPTY_STRING );
          idList.add( isValidString( xmlDealerID ) ? xmlDealerID : CSFieldValues.EMPTY_STRING );
        }
      }
    }
    catch (SQLException e)
    {
      DBLogger.log("Executing " + sql + ": " + e);
      throw e;
    }
    finally
    {
      DBAccess.closeConnection(stmt);
    }

    //general.errLog("Return idList: "+idList,AIU);

    return idList;
  }


  public static void reformatBorrowerData(Map data)
  {
    /*
    String ssn1 = (String)data.remove("atSSN_1");
    String ssn2 = (String)data.remove("atSSN_2");
    String ssn3 = (String)data.remove("atSSN_3");

    if (ssn1 == null) ssn1 = "000";
    if (ssn2 == null) ssn2 = "00";
    if (ssn3 == null) ssn3 = "0000";

    data.put("atSSN", ssn1 + "-" + ssn2 + "-" + ssn3);

    String bdM = (String)data.remove("atBirthDtMo");
    String bdD = (String)data.remove("atBirthDtDy");
    String bdY = (String)data.remove("atBirthDtYr");

    if (bdM == null) bdM = "00";
    if (bdD == null) bdD = "00";
    if (bdY == null) bdY = "0000";

    data.put("atBirthDt", bdM + "/" + bdD + "/" + bdY);
    */

    // Build applicant phone number.
    //
    String phone = (String)data.remove("atPh");
    if (phone != null) data.put("atPh", reformatPhone(phone));

    // Build relative phone number.
    //
    phone = (String)data.remove("atRelPh");
    if (phone != null) data.put("atRelPh", reformatPhone(phone));

    // Build employee phone number.
    //
    phone = (String)data.remove("atEmpPh");
    if (phone != null) data.put("atEmpPh", reformatPhone(phone));

    // Determine address type.
    //
    int addr = 0;
    String addrType = (String)data.remove("at_addr_std");

    if (addrType == null || ! addrType.equals("true"))
    {
      addrType = (String)data.remove("at_addr_rte");

      if (addrType != null && addrType.equals("true"))
      {
        addr = 1;
      }
      else
      {
        addrType = (String)data.remove("at_addr_pob");

        if (addrType != null && addrType.equals("true"))
        {
          addr = 2;
        }
      }
    }

    data.put("atAddrTypR", CSFieldValues.EMPTY_STRING + addr);

    // Determine previous address type.
    //
    addr = 0;
    addrType = (String)data.remove("at_prvaddr_std");

    if (addrType == null || ! addrType.equals("true"))
    {
      addrType = (String)data.remove("at_prvaddr_rte");

      if (addrType != null && addrType.equals("true"))
      {
        addr = 1;
      }
      else
      {
        addrType = (String)data.remove("at_prvaddr_pob");

        if (addrType != null && addrType.equals("true"))
        {
          addr = 2;
        }
      }
    }

    data.put("atPrvAddrTypR", CSFieldValues.EMPTY_STRING + addr);

    // Parse address line into it's parts (as best as possible).
    //
    String addrLine = (String)data.remove("atAddrOne");

    if (addrLine != null)
    {
      parseAddressLine(addrLine, data, true);
    }

    addrLine = (String)data.remove("atPrvAddrOne");

    if (addrLine != null)
    {
      parseAddressLine(addrLine, data, false);
    }

    // Have to translate the street suffix to it's abbreviation... the
    // data enterer might have typed in the full suffix name.
    //
    String strSuffix = (String)data.get("atStrSuffixD");

    if (strSuffix != null)
    {
      String abbrev = null;

      try
      {
        abbrev = translateStreetSuffix(strSuffix.toUpperCase());
      }
      catch (SQLException e)
      {
      }

      // Couldn't find an abbreviation.. so we'll just take the first 2
      // characters of the suffix, and call that the abbreviation.
      //
      if (abbrev == null)
      {
        abbrev = strSuffix.length() > 2 ? strSuffix.substring(0, 2) : strSuffix;
      }

      data.put("atStrSuffixD", abbrev);
    }
  }


  public static String reformatPhone(String in)
  {
    String phone = null;

    int dashIndex = in.indexOf('-');

    if (dashIndex > 0)
    {
      String ac = in.substring(0, dashIndex);
      String remainder = in.substring(dashIndex + 1);

      phone = "(" + ac + ") " + remainder;
    }

    if (phone == null) phone = "(000) 000-0000";

    return phone;
  }

  public static String parsePhone(String fieldName, String str)
  {
   //S1Log.getLogInstance().log("START parsePhone(String fieldName, String str)", LOG_FILE);
   //S1Log.getLogInstance().log("String fieldName: "+fieldName, LOG_FILE);
   //S1Log.getLogInstance().log("String str: "+str, LOG_FILE);

    String formattedPhoneNumber = null;

    if(str != null && str.trim().length() > 0 )
    {
      int cnt = 0;
      char[] number = new char[10];

      // pull out the digits and put them into number[]
      //
      for (int i = 0; i < str.length(); i++)
      {
        if (Character.isDigit(str.charAt(i)))
        {
          number[cnt] = str.charAt(i);
          cnt++;
        }
      }

      if (cnt == 10)
      {
        // format the phone number
        //
        StringBuffer strBuf = new StringBuffer();

        for (int i = 0; i < number.length; i++)
        {
          strBuf.append(number[i]);
        }

        // reformat the phone number
        //
        String strPh = strBuf.toString();
        formattedPhoneNumber = "(" + strPh.substring(0, 3) + ") " + strPh.substring(3, 6) + "-" + strPh.substring(6);
      }
      else
      {
        formattedPhoneNumber = null;
      }
    }

   //S1Log.getLogInstance().log("return formattedPhoneNumber: "+formattedPhoneNumber, LOG_FILE);
   //S1Log.getLogInstance().log("END parsePhone(String fieldName, String str)", LOG_FILE);

    return formattedPhoneNumber;
  }


  private static String stripBldgType(String addrLine, Map data, boolean current)
  {

    StringTokenizer tok = new StringTokenizer(addrLine, " ");
    StringBuffer sb = new StringBuffer();

    String str = null;

    while (tok.hasMoreTokens())
    {
      str = tok.nextToken();

      if (isValidBldgType(str))
      {
        data.put(current ? "atSecAddrTypeD" : "atPrvSecAddrTypeD", str);

        if (tok.hasMoreTokens())
        {
          str = tok.nextToken();
          data.put(current ? "atSecAddrRge" : "atPrvSecAddrRge", str);
        }
      }
      else
      {
        if (sb.length() > 0)
        {
          sb.append(" ").append(str);
        }
        else
        {
          sb.append(str);
        }
      }
    }

    return sb.toString();
  }


  public static void parseAddressLine(String addrLine, Map data, boolean current)
  {
    int tokCount = 0;

    if( addrLine != null )
    {
      // strip off building type and number
      addrLine = StringSupport.removeEmbeddedString(addrLine, ".");
      addrLine = StringSupport.removeEmbeddedString(addrLine, ",");

      addrLine = stripBldgType(addrLine, data, current);

      StringTokenizer tok = new StringTokenizer(addrLine, " ");

      if( tok != null )
        tokCount = tok.countTokens();

      String strNumber   = null;
      String strPreDir   = null;
      String strName     = null;
      String strPostDir  = null;
      String strSuffix   = null;
      String strBldgType = null;
      String strBldgNum  = null;

      switch (tokCount)
      {
        case 1:
          strName = tok.nextToken();
          data.put(current ? "atStrName" : "atPrvStrName", strName);
          break;

        case 2:
          strNumber = tok.nextToken();
          data.put(current ? "atStrNum" : "atPrvStrNum", strNumber);

          strName = tok.nextToken();
          data.put(current ? "atStrName" : "atPrvStrName", strName);
          break;

        case 3:
          strNumber = tok.nextToken();
          data.put(current ? "atStrNum" : "atPrvStrNum", strNumber);

          strName = tok.nextToken();
          data.put(current ? "atStrName" : "atPrvStrName", strName);

          strSuffix = tok.nextToken();

          if( isValidSuffix( strSuffix ) )
              {
              data.put(current ? "atStrSuffixD" : "atPrvStrSuffix", strSuffix);
              }
          else
              {
              data.put(current ? "atStrName" : "atPrvStrName", strName +" "+ strSuffix);
              }

          break;

        case 4:
          strNumber = tok.nextToken();
          data.put(current ? "atStrNum" : "atPrvStrNum", strNumber);

          strPreDir = tok.nextToken();
          strName   = tok.nextToken();
          strSuffix = tok.nextToken();

          if( isValidDirection( strPreDir ) && isValidSuffix( strSuffix ) )
              {
              data.put(current ? "atStrPreDirD" : "atPrvStrPreDirD", translateValidDirection(strPreDir) );
              data.put(current ? "atStrName" : "atPrvStrName", strName);
              data.put(current ? "atStrSuffixD" : "atPrvStrSuffix", strSuffix);
              }
          else if( !isValidDirection( strPreDir ) && !isValidSuffix( strSuffix ) )
              {
              data.put(current ? "atStrName" : "atPrvStrName", strPreDir+" "+strName+" "+strSuffix);
              }
          else if( isValidDirection( strPreDir ) && !isValidSuffix( strSuffix ) )
              {
              data.put(current ? "atStrPreDirD" : "atPrvStrPreDirD", translateValidDirection(strPreDir) );
              data.put(current ? "atStrName" : "atPrvStrName", strName+" "+strSuffix);
              }
          else if( !isValidDirection( strPreDir ) && isValidSuffix( strSuffix ) )
              {
              data.put(current ? "atStrName" : "atPrvStrName", strPreDir+" "+strName);
              data.put(current ? "atStrSuffixD" : "atPrvStrSuffix", strSuffix);
              }

          break;

        case 5:
          strNumber = tok.nextToken();
          data.put(current ? "atStrNum" : "atPrvStrNum", strNumber);

          strPreDir = tok.nextToken();
          strName   = tok.nextToken();

          if( isValidDirection( strPreDir ) )
              {
              data.put(current ? "atStrPreDirD" : "atPrvStrPreDirD", translateValidDirection(strPreDir) );
              data.put(current ? "atStrName" : "atPrvStrName", strName);
              }
          else
              {
              strName = strPreDir+" "+strName;
              data.put(current ? "atStrName" : "atPrvStrName", strName);
              }

          strPostDir = tok.nextToken();
          if( isValidDirection( strPostDir ) )
              {
              data.put(current ? "atStrPostDirD" : "atPrvStrPostDirD", translateValidDirection(strPostDir) );
              }
          else
              {
              strName = strName+" "+strPostDir;
              data.put(current ? "atStrName" : "atPrvStrName", strName);
              }

          strSuffix = tok.nextToken();
          if( isValidSuffix( strSuffix ) )
              {
              data.put(current ? "atStrSuffixD" : "atPrvStrSuffix", strSuffix);
              }
          else
              {
              strName = strName+" "+strSuffix;
              data.put(current ? "atStrName" : "atPrvStrName", strName);
              }
          break;


        case 7:
          strNumber = tok.nextToken();
          data.put(current ? "atStrNum" : "atPrvStrNum", strNumber);

          strPreDir = tok.nextToken();
          strName   = tok.nextToken();

          if( isValidDirection( strPreDir ) )
              {
              data.put(current ? "atStrPreDirD" : "atPrvStrPreDirD", translateValidDirection(strPreDir) );
              data.put(current ? "atStrName" : "atPrvStrName", strName);
              }
          else
              {
              strName = strPreDir+" "+strName;
              data.put(current ? "atStrName" : "atPrvStrName", strName);
              }

          strPostDir = tok.nextToken();
          if( isValidDirection( strPostDir ) )
              {
              data.put(current ? "atStrPostDirD" : "atPrvStrPostDirD", translateValidDirection(strPostDir) );
              }
          else
              {
              strName = strName+" "+strPostDir;
              data.put(current ? "atStrName" : "atPrvStrName", strName);
              }

          strSuffix = tok.nextToken();
          if( isValidSuffix( strSuffix ) )
              {
              data.put(current ? "atStrSuffixD" : "atPrvStrSuffix", strSuffix);
              }
          else
              {
              strName = strName+" "+strSuffix;
              data.put(current ? "atStrName" : "atPrvStrName", strName);
              }


          strBldgType = tok.nextToken();
          strBldgNum  = tok.nextToken();

          if( isValidBldgType( strBldgType ) )
              {
              data.put(current ? "atSecAddrTypeD" : "atPrvSecAddrTypeD", strBldgType);
              data.put(current ? "atSecAddrRge"   : "atPrvSecAddrRge",   strBldgNum);
              }
          else
              {
              strName = strName+" "+strBldgType+" "+strBldgNum;
              data.put(current ? "atStrName" : "atPrvStrName", strName);
              }
          break;

        default:
          break;
      } // switch (tokCount)

    } // if( addrLine != null )

  } // public static void parseAddressLine(String addrLine, Map data, boolean current)


  public static HashMap parseAddressLineXML(String addrLine, boolean current)
  {
  //errorLog("",AIU);
  //errorLog("parseAddressLineXML",AIU);
  //errorLog("",AIU);
  //errorLog("addrLine: "+addrLine,AIU);
  //errorLog("",AIU);

    int tokCount = 0;

    HashMap data = new HashMap();

    if( addrLine != null )
    {
      addrLine = addrLine.trim();

      String poBoxAndRRCheck = removeSpacesAndPeriodsAndPound(addrLine);

      if( poBoxAndRRCheck != null )
          {
          //errorLog("poBoxAndRRCheck: "+poBoxAndRRCheck,AIU);

          if( poBoxAndRRCheck.toLowerCase().startsWith("pobox") )
              {
              if (poBoxAndRRCheck.length() > 5)
                  {
                  String box       = null;
                  String remainder = null;

                  int index = addrLine.toLowerCase().indexOf("box");

                  //errorLog("index: "+index,AIU);

                  if (index != -1)
                      {
                      String temp = addrLine.substring(index + 3).trim();

                      //errorLog("temp: "+temp,AIU);

                      index = temp.indexOf(' ');

                      //errorLog("2 index: "+index,AIU);

                      if (index != -1)
                          {
                          box = temp.substring(0, index);

                          //errorLog("box: "+box,AIU);

                          remainder = temp.substring(index + 1);

                          //errorLog("remainder: "+remainder,AIU);
                          }
                      else
                          {
                          box = temp;

                          //errorLog("box = temp: "+box);
                          }

                      } // if (index != -1)
                  else
                      {
                      data.put("atStrName", addrLine);
                      return data;
                      }

                  if( box.length() > 6 )
                      {
                      data.put("atStrName", addrLine);
                      return data;
                      }

                  if( box != null )
                      {
                      data.put("atPOBox",    box);
                      data.put("atAddrTypR", "2");
                      }

                  if( remainder != null && remainder.length() > 0 )
                      {
                      data.put("atAddrTwo", remainder);
                      }

                  return data;
                  } // if (temp.length() > 5)

              } // if( poBoxAndRRCheck.toLowerCase().startsWith("pobox") )

          // route / military address
          //
          else if ( poBoxAndRRCheck.toUpperCase().startsWith("RR")  || poBoxAndRRCheck.toUpperCase().startsWith("HC")   ||
                    poBoxAndRRCheck.toUpperCase().startsWith("HCR") || poBoxAndRRCheck.toUpperCase().startsWith("CMR")  ||
                    poBoxAndRRCheck.toUpperCase().startsWith("RT")  || poBoxAndRRCheck.toUpperCase().startsWith("PSC")  ||
                    poBoxAndRRCheck.toUpperCase().startsWith("RTE") || poBoxAndRRCheck.toUpperCase().startsWith("UNIT") ||
                    poBoxAndRRCheck.toUpperCase().startsWith("ROUTE") )

              {
              //errorLog("",AIU);errorLog("0 ROURAL ROUTE:  poBoxAndRRCheck: "+poBoxAndRRCheck,AIU);errorLog("",AIU);

              if( poBoxAndRRCheck.length() > 6 )
                  {
                  String routeType = null;
                  String routeNum  = null;
                  String boxNum    = null;
                  String remainder = null;

                  //
                  // RR 1 BOX 1111
                  //
                  if( poBoxAndRRCheck.toUpperCase().startsWith("RR")  || poBoxAndRRCheck.toUpperCase().startsWith("HC")  || poBoxAndRRCheck.toUpperCase().startsWith("RT") )
                      {
                      routeType = poBoxAndRRCheck.substring(0, 2);
                      poBoxAndRRCheck = addrLine.trim().substring(2);
                      }
                  else if( poBoxAndRRCheck.toUpperCase().startsWith("HCR")  || poBoxAndRRCheck.toUpperCase().startsWith("CMR")  ||
                           poBoxAndRRCheck.toUpperCase().startsWith("PSC")  || poBoxAndRRCheck.toUpperCase().startsWith("RTE"))
                      {
                      routeType = poBoxAndRRCheck.substring(0, 3);
                      poBoxAndRRCheck = addrLine.trim().substring(3);
                      }
                  else if( poBoxAndRRCheck.toUpperCase().startsWith("UNIT") )
                      {
                      routeType = poBoxAndRRCheck.substring(0, 4);
                      poBoxAndRRCheck = addrLine.trim().substring(4);
                      }
                  else if( poBoxAndRRCheck.toUpperCase().startsWith("ROUTE") )
                      {
                      routeType = "RTE";
                      poBoxAndRRCheck = addrLine.trim().substring(5);
                      }
                  else
                      {
                      data.put("atStrName", addrLine);
                      return data;
                      }

                  //errorLog("poBoxAndRRCheck: "+poBoxAndRRCheck,AIU);

                  int index = poBoxAndRRCheck.toUpperCase().indexOf("BOX");

                  //errorLog("index: "+index,AIU);

                  if( index != -1 )
                      {
                      routeNum = poBoxAndRRCheck.substring(0, index).trim();

                      //errorLog("routeNum: "+routeNum,AIU);

                      if( routeNum.length() > 5 )
                          {
                          data.put("atStrName", addrLine);
                          return data;
                          }
                      else
                          {
                          String boxNumStr = poBoxAndRRCheck.trim().substring( index + 3 );

                          //errorLog("boxNumStr: "+boxNumStr,AIU);

                          index = boxNumStr.indexOf(' ');

                          //errorLog("index: "+index,AIU);

                          if (index != -1)
                              {
                              boxNum    = boxNumStr.substring(0, index);
                              remainder = boxNumStr.substring(index + 1).trim();
                              }
                          else
                              {
                              boxNum = boxNumStr.trim();
                              }

                          if( boxNum.length() > 6 )
                              {
                              data.put("atStrName", addrLine);
                              return data;
                              }
                          } // if / else

                      }
                  else
                      {
                      data.put("atStrName", addrLine);
                      return data;
                      } // if / else

                  if( routeType != null ) data.put("atRtTypeD", routeType);
                  if( routeNum  != null ) data.put("atRtNum",   routeNum);
                  if( boxNum    != null ) data.put("atBxNum",   boxNum);
                  if( remainder != null ) data.put("atAddrTwo", remainder);
                  data.put("atAddrTypR", "1");

                  return data;
                  } // if( poBoxAndRRCheck.length() > 6 )

              } // End else if ( poBoxAndRRCheck.toUpperCase().startsWith("RR ")

          } // if( poBoxAndRRCheck != null )


      StringTokenizer tok = new StringTokenizer(addrLine, " ");

      if( tok != null )
        tokCount = tok.countTokens();

      String strNumber   = null;
      String strPreDir   = null;
      String strName     = null;
      String strPostDir  = null;
      String strSuffix   = null;
      String strBldgType = null;
      String strBldgNum  = null;

      switch (tokCount)
      {
        case 1:
          strName = tok.nextToken();
          data.put(current ? "atStrName" : "atPrvStrName", strName);
          break;

        case 2:
          strNumber = tok.nextToken();
          data.put(current ? "atStrNum" : "atPrvStrNum", strNumber);

          strName = tok.nextToken();
          data.put(current ? "atStrName" : "atPrvStrName", strName);
          break;

        case 3:
          strNumber = tok.nextToken();
          data.put(current ? "atStrNum" : "atPrvStrNum", strNumber);

          strName = tok.nextToken();
          data.put(current ? "atStrName" : "atPrvStrName", strName);

          strSuffix = tok.nextToken();

          if( isValidSuffix( strSuffix ) )
              {
              data.put(current ? "atStrSuffixD" : "atPrvStrSuffix", strSuffix);
              }
          else
              {
              data.put(current ? "atStrName" : "atPrvStrName", strName +" "+ strSuffix);
              }

          break;

        case 4:
          strNumber = tok.nextToken();
          data.put(current ? "atStrNum" : "atPrvStrNum", strNumber);

          strPreDir = tok.nextToken();
          strName   = tok.nextToken();
          strSuffix = tok.nextToken();

          // both good
          //
          if( isValidDirection( strPreDir ) && isValidSuffix( strSuffix ) )
              {
              data.put(current ? "atStrPreDirD" : "atPrvStrPreDirD", translateValidDirection(strPreDir) );
              data.put(current ? "atStrName"    : "atPrvStrName",    strName);
              data.put(current ? "atStrSuffixD" : "atPrvStrSuffix",  strSuffix);
              }

          // both bad
          //
          else if( !isValidDirection( strPreDir ) && !isValidSuffix( strSuffix ) )
              {
              data.put(current ? "atStrName" : "atPrvStrName", strPreDir+" "+strName+" "+strSuffix);
              }

          else if( isValidDirection( strPreDir ) && !isValidSuffix( strSuffix ) )
              {
              data.put(current ? "atStrPreDirD" : "atPrvStrPreDirD", translateValidDirection(strPreDir) );
              data.put(current ? "atStrName" : "atPrvStrName", strName+" "+strSuffix);
              }

          else if( !isValidDirection( strPreDir ) && isValidSuffix( strSuffix ) )
              {
              data.put(current ? "atStrName" : "atPrvStrName", strPreDir+" "+strName);
              data.put(current ? "atStrSuffixD" : "atPrvStrSuffix", strSuffix);
              }
          break;

        case 5:
          strNumber = tok.nextToken();
          data.put(current ? "atStrNum" : "atPrvStrNum", strNumber);

          strPreDir = tok.nextToken();
          strName   = tok.nextToken();

          if( isValidDirection( strPreDir ) )
              {
              data.put(current ? "atStrPreDirD" : "atPrvStrPreDirD", translateValidDirection(strPreDir) );
              data.put(current ? "atStrName" : "atPrvStrName", strName);
              }
          else
              {
              strName = strPreDir+" "+strName;
              data.put(current ? "atStrName" : "atPrvStrName", strName);
              }

          strPostDir = tok.nextToken();
          if( isValidDirection( strPostDir ) )
              {
              data.put(current ? "atStrPostDirD" : "atPrvStrPostDirD", translateValidDirection(strPostDir) );
              }
          else
              {
              strName = strName+" "+strPostDir;
              data.put(current ? "atStrName" : "atPrvStrName", strName);
              }

          strSuffix = tok.nextToken();
          if( isValidSuffix( strSuffix ) )
              {
              data.put(current ? "atStrSuffixD" : "atPrvStrSuffix", strSuffix);
              }
          else
              {
              strName = strName+" "+strSuffix;
              data.put(current ? "atStrName" : "atPrvStrName", strName);
              }
          break;


        case 7:
          strNumber = tok.nextToken();
          data.put(current ? "atStrNum" : "atPrvStrNum", strNumber);

          strPreDir = tok.nextToken();
          strName   = tok.nextToken();

          if( isValidDirection( strPreDir ) )
              {
              data.put(current ? "atStrPreDirD" : "atPrvStrPreDirD", translateValidDirection(strPreDir) );
              data.put(current ? "atStrName" : "atPrvStrName", strName);
              }
          else
              {
              strName = strPreDir+" "+strName;
              data.put(current ? "atStrName" : "atPrvStrName", strName);
              }

          strPostDir = tok.nextToken();
          if( isValidDirection( strPostDir ) )
              {
              data.put(current ? "atStrPostDirD" : "atPrvStrPostDirD", translateValidDirection(strPostDir) );
              }
          else
              {
              strName = strName+" "+strPostDir;
              data.put(current ? "atStrName" : "atPrvStrName", strName);
              }

          strSuffix = tok.nextToken();
          if( isValidSuffix( strSuffix ) )
              {
              data.put(current ? "atStrSuffixD" : "atPrvStrSuffix", strSuffix);
              }
          else
              {
              strName = strName+" "+strSuffix;
              data.put(current ? "atStrName" : "atPrvStrName", strName);
              }


          strBldgType = tok.nextToken();
          strBldgNum  = tok.nextToken();

          if( isValidBldgType( strBldgType ) )
              {
              data.put(current ? "atSecAddrTypeD" : "atPrvSecAddrTypeD", strBldgType);
              data.put(current ? "atSecAddrRge"   : "atPrvSecAddrRge",   strBldgNum);
              }
          else
              {
              strName = strName+" "+strBldgType+" "+strBldgNum;
              data.put(current ? "atStrName" : "atPrvStrName", strName);
              }
          break;

        default:
          break;
      } // switch (tokCount)

    } // if( addrLine != null )

  return data;
  } // public static void parseAddressLine(String addrLine, Map data, boolean current)





  public static HashMap parseAddressLineRE( String addressLine, boolean current )
    {
    //errorLog("",AIU);errorLog("parseAddressLineRE( String "+addressLine+", boolean "+current+" )",AIU);errorLog("",AIU);

    HashMap data = new HashMap();

    int tokCount = 0;

    if( addressLine != null )
        {
        StringTokenizer tok = new StringTokenizer(addressLine, " ");
        //errorLog("",AIU);errorLog("tok: "+tok,AIU);errorLog("",AIU);

        if( tok != null )
            {
            tokCount = tok.countTokens();
            //errorLog("",AIU);errorLog("if( tok != null ): tokCount: "+tokCount,AIU);errorLog("",AIU);
            }

        //errorLog("",AIU);errorLog("tokCount: "+tokCount,AIU);errorLog("",AIU);

        String str = null;

        switch (tokCount)
            {
            case 1:
            str = tok.nextToken();
            data.put(current ? "atStrName" : "atPrvStrName", str);
            break;

            case 2:
            str = tok.nextToken();
            data.put(current ? "atStrNum"  : "atPrvStrNum",  str);
            str = tok.nextToken();
            data.put(current ? "atStrName" : "atPrvStrName", str);
            break;

            case 3:
            str = tok.nextToken();
            data.put(current ? "atStrNum"     : "atPrvStrNum",    str);
            str = tok.nextToken();
            data.put(current ? "atStrName"    : "atPrvStrName",   str);
            str = tok.nextToken();
            data.put(current ? "atStrSuffixD" : "atPrvStrSuffix", str);
            break;

            case 4:
            str = tok.nextToken();
            data.put(current ? "atStrNum"     : "atPrvStrNum",     str);
            str = tok.nextToken();
            data.put(current ? "atStrPreDirD" : "atPrvStrPreDirD", translateValidDirection(str) );
            str = tok.nextToken();
            data.put(current ? "atStrName"    : "atPrvStrName",    str);
            str = tok.nextToken();
            data.put(current ? "atStrSuffixD" : "atPrvStrSuffix",  str);
            break;

            case 5:
            str = tok.nextToken();
            data.put(current ? "atStrNum"      : "atPrvStrNum",      str);
            str = tok.nextToken();
            data.put(current ? "atStrPreDirD"  : "atPrvStrPreDirD",  translateValidDirection(str) );
            str = tok.nextToken();
            data.put(current ? "atStrName"     : "atPrvStrName",     str);
            str = tok.nextToken();
            data.put(current ? "atStrPostDirD" : "atPrvStrPostDirD", translateValidDirection(str) );
            str = tok.nextToken();
            data.put(current ? "atStrSuffixD"  : "atPrvStrSuffix",   str);
            break;

            default:
            break;
            }

        } // if( addressLine != null )

    return data;
    }

  // query database for suffix abreviations
  //
  public static String translateStreetSuffix(String suffix) throws SQLException
  {
    //errorLog("",AIU);errorLog("translateStreetSuffix(String suffix: "+suffix+")",AIU);errorLog("",AIU);

    if( suffix != null && suffix.length() > 0 )
        {
        suffix = suffix.trim().toUpperCase();
        }


    String sql = "SELECT cStdSfx FROM xntStreetAbbr WHERE cStreet='" + suffix + "'";

    Statement stmt = null;
    String abbrev = null;

    try
    {
      Connection con = DBAccess.getConnection();
      stmt = con.createStatement();
      ResultSet rs = stmt.executeQuery(sql);

      if (rs.next())
      {
        abbrev = rs.getString("cStdSfx");
        //errorLog("abbrev: "+abbrev,AIU);
      }
    }
    catch (SQLException e)
    {
      DBLogger.log("Executing " + sql + ": " + e);
      throw e;
    }
    finally
    {
      DBAccess.closeConnection(stmt);
    }

    //errorLog("",AIU);errorLog("RETURN: "+abbrev,AIU);errorLog("",AIU);

    return abbrev;
  }


  // it is called:      xntUnitAbbr
  // with the columns:	cUnit	cStdAbv
  //
  // all cUnits are entered in uppercase
  //
  // The table is in the FABCrediSphere database on .83 and on the PSECU database on .83
  //
  // It would be put out with a script.
  //
  // query data base for secondary unit designators abbreviations
  //
  public static String translateUnitAbbr( String unit ) throws SQLException
  {
    //errorLog("",AIU);errorLog("translateUnitAbbr( String unit: "+unit+" )",AIU);errorLog("",AIU);

    if( unit != null && unit.length() > 0 )
        {
        unit = unit.trim().toUpperCase();
        }

    String sql = "SELECT cStdAbv FROM xntUnitAbbr WHERE cUnit='" + unit + "'";

    Statement stmt = null;
    String abbrev  = null;

    try
    {
      Connection con = DBAccess.getConnection();
      stmt = con.createStatement();
      ResultSet rs = stmt.executeQuery(sql);

      if (rs.next())
      {
        abbrev = rs.getString("cStdAbv");
        //errorLog("abbrev: "+abbrev,AIU);
      }
    }
    catch (SQLException e)
    {
      DBLogger.log("Executing " + sql + ": " + e);
      throw e;
    }
    finally
    {
      DBAccess.closeConnection(stmt);
    }

    //errorLog("",AIU);errorLog("RETURN: "+abbrev,AIU);errorLog("",AIU);

    return abbrev;
  }

  /**
   * Creates a physical address to be used by the collateral node. The new field names
   * are collateral node specific
   *
   * @param appData HashMap
   * @param appSuffix String
   * @return HashMap
   */
  public static HashMap setupPhysicalAddress( HashMap appData, String appSuffix)
  {
    HashMap reFields = new HashMap();

    String appType = null;

    if( appSuffix.endsWith("_0") )
        {
        appType = "_0";
        }
    else if( appSuffix.endsWith("_1") )
        {
        appType = "_1";
        }
    else
        {
        appType = CSFieldValues.EMPTY_STRING;
        }

    String str = (String)appData.get("atStrNum"+appType);
    if (str != null) reFields.put("phyStrNum", str);

    str = (String)appData.get("atStrPreDirD"+appType);
    if (str != null) reFields.put("phyStrPreDirD", str);

    str = (String)appData.get("atStrName"+appType);
    if (str != null) reFields.put("phyStrName", str);

    str = (String)appData.get("atStrPostDirD"+appType);
    if (str != null) reFields.put("phyStrPostDirD", str);

    str = (String)appData.get("atStrSuffixD"+appType);
    if (str != null) reFields.put("phyStrSuffixD", str);


    // you may have to attach the suffix to the street name and put the bldg type in the
    // suffix ddl because the vista does not match the normal address vista
    //
    String str2 = (String)appData.get("atSecAddrTypeD"+appType);

    //errorLog("str2: "+str2,AIU);

    if (str2 != null)
        {
        String name   = (String)reFields.get("phyStrName");
        //errorLog("name: "+name,AIU);

        String suffix = (String)reFields.get("phyStrSuffixD");
        //errorLog("suffix: "+suffix,AIU);

        if( name != null )
            {
            if( suffix != null )
                {
                reFields.put("phyStrName",    name+" "+suffix);
                reFields.put("phyStrSuffixD", str2);
                }
            else
                {
                reFields.put("phyStrName",    name);
                reFields.put("phyStrSuffixD", str2);
                }
            }
        }


    str = (String)appData.get("atSecAddrRge"+appType);
    if (str != null) reFields.put("phySecAddrRge", str);

    return reFields;
  }

  /**
   *  this is the method used by XML2MetaSage to create a collateral node. the assumption is
   *  that the collateral specification table in the product is set up correctly
   *
   * @param sdo SystemDataObject
   * @param appNode DataNode
   * @param collData HashtableX
   * @param prodID String
   * @param username String
   */
  public static void setupBusinessCollateralNode( SystemDataObject sdo, DataNode appNode,
                                                  HashtableX collData,  String prodID, String username)
  {
    //errorLog("setupCollateralNode(...)",AIU);errorLog("collData: "+collData,AIU);

    String collFlag = null;

    if( collData.containsKey("clTypeFlag") )
        {
        collFlag = (String)collData.remove("clTypeFlag"); // automobile
        }
    else if( collData.containsKey("phyTypeFlag") )
        {
        collFlag = (String)collData.remove("phyTypeFlag"); // real estate
        }
    else if( collData.containsKey("lwTypeFlag") )
        {
        collFlag = (String)collData.remove("lwTypeFlag"); // mobile home
        }

    //errorLog("",AIU);errorLog("0 collFlag: "+collFlag,AIU);errorLog("",AIU);

    if( collFlag != null )
    {
    //errorLog("",AIU);errorLog("0.1 prodID: "+prodID,AIU);errorLog("",AIU);

    // Fetch the product.
    //
    SBProduct product = CSDataCache.getSBProductManager().getProduct(prodID);

    //errorLog("",AIU);errorLog("0.2 product: "+product,AIU);errorLog("",AIU);

    if( product != null )
      {
      //errorLog("",AIU);errorLog("1 INSIDE if (product != null)",AIU);errorLog("",AIU);

      // get collateral specification table
      //
      String str = product.getCollatSumTbl();

      //errorLog("",AIU);errorLog("2 Prd Collat Sum Tbl Str: "+str,AIU);errorLog("",AIU);

      if( str != null )
        {
        //errorLog("",AIU);errorLog("3 INSIDE if (str != null)",AIU);errorLog("",AIU);

        str = StringChanger.getObjectBody(str);

        TableTransaction tt = TableTransaction.stringToObject(str);

        //errorLog("",AIU);errorLog("3.1 tt: "+tt,AIU);errorLog("",AIU);

        List recs = tt.getRecords();

        //errorLog("",AIU);errorLog("3.2 recs required: "+recs,AIU);errorLog("",AIU);

        // no records means no collateral node to set up, there are not any accepatable
        // collateral specifications set up for this product move on...
        //
        if( recs != null && !recs.isEmpty() )
          {
          //errorLog("",AIU);errorLog("4 INSIDE if (recs != null && ! recs.isEmpty())",AIU);errorLog("",AIU);

          String collID   = null;
          String collType =  null;

          // loop through records in the product's collateral summary table to find a
          // match for collateral description and then get the associated id number.
          // use the id to load the collateral object
          //
          // if multiple records and no match is found use the first record
          //
          //
          for( int i=0, c=recs.size(); i<c; i++ )
            {
            String temp = (String)recs.get(i); //  used to get first record

            //errorLog("",AIU);errorLog("5 temp: "+temp,AIU);errorLog("",AIU);

            temp = StringChanger.getObjectBody( temp );

            TableRecord tr = TableRecord.stringToObject( temp );

            // column names from the product editor collateral summary table which are also table keys
            //
            // public static final String idLabel = "ID Number";
            //
            // need to get the id number and then load the collateral object
            //
            // set the default to the first acceptable collateral specification
            //
            if( i == 0 )
                {
                collID = tr.getField("ID Number");
                //errorLog("",AIU);errorLog("6 collID: "+collID,AIU);errorLog("",AIU);
                }

            String tempCollID = tr.getField("ID Number");

            //errorLog("",AIU);errorLog("6.1 tempCollID: "+tempCollID,AIU);errorLog("",AIU);

            if(tempCollID != null)
              {
              // load the collateral object
              //
              Collateral collateral = CSDataCache.getCollateralManager().getCollateral(tempCollID);

              if (collateral != null)
                {
                //errorLog("",AIU);errorLog("7 if (collateral != null)",AIU);errorLog("",AIU);

                // set the default to the first acceptable collateral specification
                //
                if( i == 0 )
                    {
                    collType = collateral.getClTypD();
                    //errorLog("",AIU);errorLog("7.1 collType: "+collType,AIU);errorLog("",AIU);
                    }

                String tempCollType = collateral.getClTypD();
                //errorLog("",AIU);errorLog("7.2 tempCollType: "+tempCollType,AIU);errorLog("",AIU);

                if( tempCollType != null && tempCollType.length() > 0 )
                  {
                  // String collFlag = collType
                  //
                  if( collFlag.trim().equals( tempCollType.trim() ) )
                    {
                    //errorLog("",AIU);errorLog("8 collFlag = collDescFromSumTbl",AIU);errorLog("",AIU);
                    //errorLog("",AIU);errorLog("8.0 tempCollType: "+tempCollType,AIU);errorLog("",AIU);

                    collType = tempCollType;
                    collID   = tempCollID;

                    //errorLog("",AIU);errorLog("8.1 collID: "+collID,AIU);errorLog("",AIU);
                    //errorLog("",AIU);errorLog("8.2 collType: "+collType,AIU);errorLog("",AIU);

                    //
                    // break from loop just grab first one
                    //
                    break;
                    }

                  }

                } // if (collateral != null)

              } // if (collID != null)

            } // for( int i=0; i<recs.size(); i++; )

          // now that you have the acceptable collateral type because it is in the
          // product specification table create the node
          //
          //
          //errorLog("",AIU);errorLog("9 collType: "+collType,AIU);errorLog("",AIU);
          //errorLog("",AIU);errorLog("9.1 collID: "+collID,AIU);errorLog("",AIU);

          DataNode collNode = appNode.getReference(NodeUtils.COLL_DN_TYPE, 0);

          if( collNode == null )
            {
            //errorLog("",AIU);errorLog("10 if (collNode== null)",AIU);errorLog("",AIU);

            // Create collateral container node.
            //
            collNode = sdo.createDataNode(username, NodeUtils.COLL_DN_TYPE);
            collNode.setSystemData("!container", "true");
            appNode.addReference(collNode);
            }  // if collNode == null


          // create and add the collateral owner list to the collateral data map
          //
          VectorX bwrVec = appNode.getReferences( NodeUtils.BWR_DN_TYPE );

          //errorLog("",AIU);errorLog("10.1 bwrVec: "+bwrVec,AIU);errorLog("",AIU);

          if( bwrVec != null && bwrVec.size() > 1 )
            {
            VectorX onrBwrList = new VectorX();
            //errorLog("",AIU);errorLog("10.1.0 onrBwrList: "+onrBwrList,AIU);errorLog("",AIU);

            for( int i=0, b=bwrVec.size(); i<b; i++ )
              {
              DataNode onrBwrDN = (DataNode)bwrVec.get(i);
              //errorLog("",AIU);errorLog("10.1.1 onrBwrDN: "+onrBwrDN,AIU);errorLog("",AIU);

              if( onrBwrDN != null && !onrBwrDN.isDeleted() )
                {
                int nodePosition = onrBwrDN.getIndex();

                //errorLog("",AIU);errorLog("10.2 nodePosition: "+nodePosition,AIU);errorLog("",AIU);

                if( nodePosition >= 0 )
                  {
                  onrBwrList.addElement( CSFieldValues.EMPTY_STRING + nodePosition );
                  }

                }

              } // for( int i=1; i<bwrVec; i++ )

            //errorLog("",AIU);errorLog("10.3 onrBwrList: "+onrBwrList,AIU);errorLog("",AIU);

            if( onrBwrList != null && !onrBwrList.isEmpty() )
              {
              collData.put("_OnrBwrList", onrBwrList);
              }
            } // if( bwrVec != null && bwrVec.size() > 1 )


          //errorLog("",AIU);errorLog("10.3.1 collID: "+collID,AIU);errorLog("",AIU);
          //errorLog("",AIU);errorLog("10.3.2 collType: "+collType,AIU);errorLog("",AIU);
          // add the collater data to the collateral node

          //
          if( collType != null && collID != null )
            {
            String propLienListStr = (String)collData.remove("phyLienList");
            //errorLog("17 propLienListStr: "+propLienListStr,AIU);


            // add data to the collData hash before adding it to the coll data node
            //
            collData.put(CSFieldNames.FN_COLLATERAL_ID,   collID);
            collData.put(CSFieldNames.FN_COLLATERAL_DESC, collType);

            // load the data node
            //
            DataNode collSubNodeByType = sdo.createDataNode(username, collType);

            //
            // translate real estate field names in mobile home field names
            //

            //errorLog("",AIU);errorLog("10.3.3 setFieldData: collData: "+collData,AIU);errorLog("",AIU);

            collSubNodeByType.setFieldData(username, collData);
            collSubNodeByType.setSystemData(CSFieldNames.FN_COLLATERAL_ID, collID);

            //errorLog("",AIU);errorLog("11 collNode: "+collNode,AIU);errorLog("",AIU);

            DataNode bwrNode = appNode.getReference( NodeUtils.BWR_DN_TYPE, 0 );

            //errorLog("",AIU);errorLog("11.1 collSubNodeByType: "+ collSubNodeByType,AIU);errorLog("",AIU);
            //errorLog("",AIU);errorLog("12 bwrNode: "+bwrNode,AIU);errorLog("",AIU);

            if( bwrNode != null && !bwrNode.isDeleted() )
              {
              HashtableX bwrHash = bwrNode.getFieldData(CSFieldValues.EMPTY_STRING);

              //errorLog("",AIU);errorLog("13 bwrHash: "+bwrHash,AIU);errorLog("",AIU);

              if( bwrHash != null && !bwrHash.isEmpty() )
                {
                HashtableX onrHash = CSDataCollection.getOnrHT( bwrHash );

                if( onrHash != null && !onrHash.isEmpty() )
                  {
                  //errorLog("",AIU);errorLog("14 onrHash: "+onrHash,AIU);errorLog("",AIU);

                  onrHash.put("_onrBwrPOSHid", "0");

                  DataNode onrNode = new DataNode( NodeUtils.ONR_DN_TYPE );

                  onrNode.setDescription( NodeUtils.getNodeDescription( NodeUtils.ONR_DN_TYPE ) );
                  onrNode.setFieldData( username, onrHash );

                  DataNode newOnrNode = sdo.createDataNode( username, "Owner" );

                  if( newOnrNode != null )
                    {
                    newOnrNode.setFieldData( username, onrNode.getFieldData( getName() ) );

                    //errorLog("",AIU);errorLog("15 newOnrNode: "+ newOnrNode,AIU);errorLog("",AIU);

                    collSubNodeByType.addReference( newOnrNode );

                    //errorLog("",AIU);errorLog("16 collNode: "+ collNode,AIU);errorLog("",AIU);
                    }

                  } // if( onrHash != null && !onrHash.isEmpty() )

                } // if( bwrHash != null && !bwrHash.isEmpty() )

              } // if( bwrNode != null && !bwrNode.isDeleted() )

            // add the new node that contains the collateral data to the collater
            // node container
            //
            //collNode.addReference( collSubNodeByType );
            //errorLog("",AIU);errorLog("17 add newNode to collNode: "+ collNode,AIU);errorLog("",AIU);

            //
            // add lien node
            //

            // 12-18-01, ccl
            // Add the Lien nodes into collateral node.
            //
            //VectorX lienVec = (VectorX)tempLiens.get(appID);

            List propertyLienList = null;
            //String propLienListStr = (String)collData.get("phyLienList");
            //errorLog("17 propLienListStr: "+propLienListStr,AIU);

            if( propLienListStr != null && propLienListStr.length() > 0 )
                {
                propertyLienList = StringChanger.stringToVector( propLienListStr );
                }

            //errorLog("17.1 propertyLienList: "+propertyLienList,AIU);
            //errorLog("",AIU);errorLog("17.2 collSubNodeByType: "+ collSubNodeByType,AIU);errorLog("",AIU);

            if( propertyLienList != null && !propertyLienList.isEmpty() )
                {
                for (int i=0; i<propertyLienList.size(); i++)
                  {
                  // DataNode lnDN = (DataNode)lienVec.elementAt(i);
                  //
                  // HashtableX lienData = (HashtableX)propertyLienList.get( i );
                  //
                  // HashtableX lienData =
                  // StringChanger.stringToHashtableX( propertyLienList.get(i).toString() );
                  //
                  Object objLien = propertyLienList.get( i );

                  //errorLog("objLien: "+objLien,AIU);
                  //errorLog("CLASS objLien: "+objLien.getClass(),AIU);

                  HashtableX lienData = null;

                  if( objLien instanceof String )
                  {
                    lienData = StringChanger.stringToHashtableX( propertyLienList.get(i).toString() );
                  }
                  else if( objLien instanceof HashtableX )
                  {
                    lienData = (HashtableX)propertyLienList.get(i);
                  }

                  //errorLog("18 lienData: "+lienData,AIU);

                  if( lienData != null && !lienData.isEmpty() )
                    {
                    DataNode newLnDN = sdo.createDataNode( username, "Lien" );
                    newLnDN.setFieldData( username, lienData );

                    //errorLog("19 newLnDN: "+newLnDN,AIU);

                    collSubNodeByType.addReference( newLnDN );
                    }
                  }
                }

            // add the new node that contains the collateral data to the collater
            // node container
            //
            //errorLog("",AIU);errorLog("19.1 collSubNodeByType: "+ collSubNodeByType,AIU);errorLog("",AIU);

            collNode.addReference( collSubNodeByType );

            //errorLog("",AIU);errorLog("20 add newNode to collNode: "+ collNode,AIU);errorLog("",AIU);
            } // if( collType != null && collID != null )

          } // if (recs != null && !recs.isEmpty())

        } // if( str != null )

      } // if (product != null)

    } // if( collFlag != null )

  } // setupCollateralNode(...)

  public static String getName()
  {
    //return "AppImport";
    //
    return "xml2ms";
  }


  public static boolean validateEMailAddress( String emailAddress )
      {
      boolean validAddress = false;

      int atIndex = emailAddress.indexOf("@");
      int lastDot = emailAddress.lastIndexOf(".");

      if( atIndex != -1 && lastDot != -1 && atIndex < lastDot )
              {
              validAddress = true;
              }

      return validAddress;
      } // validateEMailAddress(String csKey, String fmValue)





  public static String translateDisbursementType( String type )
    {
    VectorX[] disbTypes = ApplicationHouse.getListCodesCache().getListCodes("Disbursement Types");

    int index = disbTypes[0].indexOf(type);

    if ( (index != -1) &&
         (disbTypes[1].size() > index) )
    {
      type = (String)disbTypes[1].get(index);
    }

    return type;
  }


  /*
  [Street Suffix]
   !!_BLANK
   St
   Ave
   Dr
   Blvd
   Cir
   Ct
   Ln
   Rd
   Pkwy
   Hwy
  */
  public static boolean isValidSuffix( String strSuffix )
    {
    boolean valid = false;
    String suffix = null;

    if (strSuffix != null)
    {
      suffix = strSuffix.toUpperCase().trim();

      // If the suffix ends with '.', remove it.
      // St. --> St
      //
      if (suffix.endsWith("."))
      {
        suffix = suffix.substring(0, suffix.length() - 1);
      }

      if( suffix.equals("ST")   || suffix.equals("AVE") ||
          suffix.equals("DR")   || suffix.equals("CT")  ||
          suffix.equals("LN")   || suffix.equals("CIR") ||
          suffix.equals("RD")   || suffix.equals("WAY") ||
          suffix.equals("PKWY") || suffix.equals("HWY") ||
          suffix.equals("BLVD") || suffix.equals("COVE") )
      {
         valid = true;
      }
    }

    return valid;

  } // isValidSuffix( String strSuffix )



  // queries to the data base
  //
  public static boolean isValidSuffixDB( String strSuffix )
    {
    boolean valid = false;
    String suffix = null;

    if( strSuffix != null && strSuffix.length() > 0 )
        {
        try
          {
          suffix = translateStreetSuffix( strSuffix.trim() );

          if( suffix != null && suffix.length() > 0 )
              {
              valid = true;
              }
          }
        catch( SQLException e )
            {
            e.printStackTrace();
            }

        } // End if( strSuffix != null )

    return valid;
    } // isValidSuffix( String strSuffix )



  public static boolean isValidBldgTypeDB( String unit )
    {
    boolean valid = false;
    String  abbrv = null;

    if( unit != null && unit.length() > 0 )
        {
        unit = unit.trim().toUpperCase();

        try
          {
          abbrv = translateUnitAbbr( unit );

          if( abbrv != null && abbrv.length() > 0 )
              {
              valid = true;
              }

          }
        catch( SQLException e )
            {
            e.printStackTrace();
            }


       } // End if( unit != null && unit.length() > 0 )

    return valid;
    } // isValidSuffix( String strSuffix )


  public static String processToken( String token )
    {
    String tokenValue = null;

    if( isValidDirection( token ) )
        {
        tokenValue = "1";
        }
    else if( isValidSuffixDB( token ) )
        {
        tokenValue = "2";
        }
    else if( isValidBldgTypeDB( token ) )
        {
        tokenValue = "3";
        }
    else
        {
        tokenValue = "0";
        }

    return tokenValue;
    } // processToken( String strSuffix )


  public static boolean isValidDirection( String strSuffix )
    {
    boolean valid = false;
    String suffix = null;

    if( strSuffix != null )
        {
        suffix = strSuffix.trim();
        }

    if( suffix != null )
       {
       if( suffix.toUpperCase().equals("N")  || suffix.toUpperCase().equals("S")  || suffix.toUpperCase().equals("E") ||
           suffix.toUpperCase().equals("W")  || suffix.toUpperCase().equals("NE") || suffix.toUpperCase().equals("SE")||
           suffix.toUpperCase().equals("NW") || suffix.toUpperCase().equals("SW") ||
           suffix.toUpperCase().equals("SOUTH") || suffix.toUpperCase().equals("EAST") ||
           suffix.toUpperCase().equals("NORTH") || suffix.toUpperCase().equals("WEST"))
              {
              valid = true;
              }

       } // End if( suffix != null )

    return valid;
    } // isValidDirection( String strSuffix )


/* FROM USPS: VALID UNIT DESIGNATORS

  APT
  BSMT**
  BLDG
  DEPT
  FL
  FRNT**
HNGR
  LBBY**
LOT
  LOWR**
OFC**
PH**
  PIER
  REAR**
  RM
SIDE**
SLIP
SPC
STOP
  STE
  TRLR
  UNIT
  UPPR**

*/


  public static boolean isValidBldgType( String strSuffix )
    {
    boolean valid = false;
    String suffix = null;

    if( strSuffix != null )
        {
        suffix = strSuffix.trim();
        }

    if( suffix != null )
       {
       if( suffix.toUpperCase().equals("FL")   || suffix.toUpperCase().equals("APT")  || suffix.toUpperCase().equals("BLDG") ||
           suffix.toUpperCase().equals("RM")   || suffix.toUpperCase().equals("STE")  || suffix.toUpperCase().equals("UNIT") ||
           suffix.toUpperCase().equals("UPPR") || suffix.toUpperCase().equals("LOWR") || suffix.toUpperCase().equals("LBBY") ||
           suffix.toUpperCase().equals("BSMT") || suffix.toUpperCase().equals("REAR") || suffix.toUpperCase().equals("FRNT") ||
           suffix.toUpperCase().equals("DEPT") || suffix.toUpperCase().equals("TRLR") || suffix.toUpperCase().equals("PIER") ||
           suffix.toUpperCase().equals("LOT") )
              {
              valid = true;
              }

       } // End if( suffix != null )

    return valid;
    } // isValidSuffix( String strSuffix )



  public static String removeSpacesAndPeriodsAndPound(String str)
      {
      StringBuffer sb = new StringBuffer();
      char[] chArray = str.toCharArray();
      for (int i = 0; i < chArray.length; ++i)
          {
          if (chArray[i] != ' ' && chArray[i] != '.' && chArray[i] != '#')
              {
              sb.append(chArray[i]);
              }
          }

      return sb.toString();
      }


  // if the address line is over 24 characters long cut the address
  // and place the remainder in line 2
  //
  private static HashMap addressFormatError(String fmValue, String appType,
                                            String prefix)
      {
      HashMap dataMap = new HashMap();

      String address = fmValue;

      if (address != null && appType != null && address.length() <= 24)
          {
            dataMap.put(prefix + "StrName"+appType, address);
          }
      else if (address != null && appType != null && address.length() > 24)
          {
          String addr1 = address.substring(0, 24);
          String addr2 = address.substring(24);

          if(addr1 != null)
            {
            dataMap.put(prefix + "StrName"+appType, addr1);
            }

          if(addr2 != null)
              {
              if(addr2.length() < 40)
                  {
                  dataMap.put(prefix + "AddrTwo"+appType, addr2);
                  }
              else
                  {
                  dataMap.put(prefix + "AddrTwo"+appType, addr2.substring(0, 40) );
                  }
              }
          }

      dataMap.put("atAddrTypR"+appType, "0");

      return dataMap;
      }


  public static HashMap parseAddressLineFiserv(String addrLine)
  {
  //errorLog("",AIU);
  //errorLog("parseAddressLineXML",AIU);
  //errorLog("",AIU);
  //errorLog("addrLine: "+addrLine,AIU);
  //errorLog("",AIU);

    HashMap data = new HashMap();

    if( addrLine != null )
    {
      addrLine = addrLine.trim();

      String poBoxAndRRCheck = removeSpacesAndPeriodsAndPound(addrLine);

      if( poBoxAndRRCheck != null )
          {
          //errorLog("poBoxAndRRCheck: "+poBoxAndRRCheck,AIU);

          if( poBoxAndRRCheck.toLowerCase().startsWith("pobox") )
              {
              if (poBoxAndRRCheck.length() > 5)
                  {
                  String box       = null;
                  String remainder = null;

                  int index = addrLine.toLowerCase().indexOf("box");

                  //errorLog("index: "+index,AIU);

                  if (index != -1)
                      {
                      String temp = addrLine.substring(index + 3).trim();

                      //errorLog("temp: "+temp,AIU);

                      index = temp.indexOf(' ');

                      //errorLog("2 index: "+index,AIU);

                      if (index != -1)
                          {
                          box = temp.substring(0, index);

                          //errorLog("box: "+box,AIU);

                          remainder = temp.substring(index + 1);

                          //errorLog("remainder: "+remainder,AIU);
                          }
                      else
                          {
                          box = temp;

                          //errorLog("box = temp: "+box);
                          }

                      } // if (index != -1)
                  else
                      {
                      data.put("atStrName", addrLine);
                      data.put("atAddrTypR", "0");
                      return data;
                      }

                  if( box.length() > 6 )
                      {
                      data.put("atStrName", addrLine);
                      data.put("atAddrTypR", "0");
                      return data;
                      }

                  if( box != null )
                      {
                      data.put("atPOBox",    box);
                      data.put("atAddrTypR", "2");
                      }

                  if( remainder != null && remainder.length() > 0 )
                      {
                      data.put("atAddrTwo", remainder);
                      }

                  return data;
                  } // if (temp.length() > 5)

              } // if( poBoxAndRRCheck.toLowerCase().startsWith("pobox") )

          // route / military address
          //
          else if ( poBoxAndRRCheck.toUpperCase().startsWith("RR")  || poBoxAndRRCheck.toUpperCase().startsWith("HC")   ||
                    poBoxAndRRCheck.toUpperCase().startsWith("HCR") || poBoxAndRRCheck.toUpperCase().startsWith("CMR")  ||
                    poBoxAndRRCheck.toUpperCase().startsWith("RT")  || poBoxAndRRCheck.toUpperCase().startsWith("PSC")  ||
                    poBoxAndRRCheck.toUpperCase().startsWith("RTE") || poBoxAndRRCheck.toUpperCase().startsWith("UNIT") ||
                    poBoxAndRRCheck.toUpperCase().startsWith("ROUTE") )

              {
              //errorLog("",AIU);errorLog("0 ROURAL ROUTE:  poBoxAndRRCheck: "+poBoxAndRRCheck,AIU);errorLog("",AIU);

              if( poBoxAndRRCheck.length() > 6 )
                  {
                  String routeType = null;
                  String routeNum  = null;
                  String boxNum    = null;
                  String remainder = null;

                  //
                  // RR 1 BOX 1111
                  //
                  if( poBoxAndRRCheck.toUpperCase().startsWith("RR")  || poBoxAndRRCheck.toUpperCase().startsWith("HC")  || poBoxAndRRCheck.toUpperCase().startsWith("RT") )
                      {
                      routeType = poBoxAndRRCheck.substring(0, 2);
                      poBoxAndRRCheck = addrLine.trim().substring(2);
                      }
                  else if( poBoxAndRRCheck.toUpperCase().startsWith("HCR")  || poBoxAndRRCheck.toUpperCase().startsWith("CMR")  ||
                           poBoxAndRRCheck.toUpperCase().startsWith("PSC")  || poBoxAndRRCheck.toUpperCase().startsWith("RTE"))
                      {
                      routeType = poBoxAndRRCheck.substring(0, 3);
                      poBoxAndRRCheck = addrLine.trim().substring(3);
                      }
                  else if( poBoxAndRRCheck.toUpperCase().startsWith("UNIT") )
                      {
                      routeType = poBoxAndRRCheck.substring(0, 4);
                      poBoxAndRRCheck = addrLine.trim().substring(4);
                      }
                  else if( poBoxAndRRCheck.toUpperCase().startsWith("ROUTE") )
                      {
                      routeType = "RTE";
                      poBoxAndRRCheck = addrLine.trim().substring(5);
                      }
                  else
                      {
                      data.put("atStrName", addrLine);
                      data.put("atAddrTypR", "0");
                      return data;
                      }

                  //errorLog("poBoxAndRRCheck: "+poBoxAndRRCheck,AIU);

                  int index = poBoxAndRRCheck.toUpperCase().indexOf("BOX");

                  //errorLog("index: "+index,AIU);

                  if( index != -1 )
                      {
                      routeNum = poBoxAndRRCheck.substring(0, index).trim();

                      //errorLog("routeNum: "+routeNum,AIU);

                      if( routeNum.length() > 5 )
                          {
                          data.put("atStrName", addrLine);
                          data.put("atAddrTypR", "0");
                          return data;
                          }
                      else
                          {
                          String boxNumStr = poBoxAndRRCheck.trim().substring( index + 3 );

                          //errorLog("boxNumStr: "+boxNumStr,AIU);

                          index = boxNumStr.indexOf(' ');

                          //errorLog("index: "+index,AIU);

                          if (index != -1)
                              {
                              boxNum    = boxNumStr.substring(0, index);
                              remainder = boxNumStr.substring(index + 1).trim();
                              }
                          else
                              {
                              boxNum = boxNumStr.trim();
                              }

                          if( boxNum.length() > 6 )
                              {
                              data.put("atStrName", addrLine);
                              data.put("atAddrTypR", "0");
                              return data;
                              }
                          } // if / else

                      }
                  else
                      {
                      data.put("atStrName", addrLine);
                      data.put("atAddrTypR", "0");
                      return data;
                      } // if / else

                  if( routeType != null ) data.put("atRtTypeD", routeType);
                  if( routeNum  != null ) data.put("atRtNum",   routeNum);
                  if( boxNum    != null ) data.put("atBxNum",   boxNum);
                  if( remainder != null ) data.put("atAddrTwo", remainder);
                  data.put("atAddrTypR", "1");

                  return data;
                  } // if( poBoxAndRRCheck.length() > 6 )

              } // End else if ( poBoxAndRRCheck.toUpperCase().startsWith("RR ")

          } // if( poBoxAndRRCheck != null )


      // remove the period from the address
      //
      String temp2 = StringSupport.removeEmbeddedString( addrLine.trim(), ".");

      //errorLog("");errorLog("temp2: "+temp2);errorLog("");

      // remove the pound sign from the address replace it with a space
      //
      temp2 = StringSupport.replaceEmbeddedString(temp2, "#", " ");

      String strNum         = null;
      String atStrPreDirD   = null;
      String strName        = null;
      String atStrPostDirD  = null;
      String strSuffix      = null;
      String atSecAddrTypeD = null;
      String atSecAddrRge   = null;

      boolean spaceFlag    = false;
      boolean preDirFlag   = false;
      boolean postDirFlag  = false;
      boolean suffixFlag   = false;
      boolean bldgTypeFlag = false;

    StringTokenizer tok = new StringTokenizer( temp2, " " );
    int tokCount = tok.countTokens();

    String[] addrFields = null;
    addrFields = new String[tok.countTokens()];

    int i = 0;
    while (tok.hasMoreTokens())
        {
        addrFields[i] = tok.nextToken();
        ++i;
        }

    //errorLog("");errorLog("temp2: "+temp2);errorLog("");

    for( int j=0; j < addrFields.length; j++ )
        {
        String s = processToken( addrFields[j] );

        //errorLog("");
        //errorLog("s: "+s); // token value
        //errorLog("j: "+j); // token number
        //errorLog("");
        //errorLog("addrFields[j]: "+addrFields[j]); // token being processed from array
        //errorLog("");
        //errorLog("spaceFlag:    "+spaceFlag);
        //errorLog("preDirFlag:   "+preDirFlag);
        //errorLog("postDirFlag:  "+postDirFlag);
        //errorLog("suffixFlag:   "+suffixFlag);
        //errorLog("bldgTypeFlag: "+bldgTypeFlag);
        //errorLog("");

        if( s.equals("0") )
            {
            // street number
            //
            if(j==0)
                {
                strNum = addrFields[j];
                if( strNum.length() > 6 )
                    {
                    data.put("atStrName", addrLine);
                    data.put("atAddrTypR", "0");
                    return data;
                    }
                }

            // street name
            //
            if(j==1)
                {
                strName = addrFields[j];
                spaceFlag = true;
                }

            // processing begins
            //
            if(j > 1)
                {
                if( bldgTypeFlag )
                    {
                    atSecAddrRge = addrFields[j];
                    if( atSecAddrRge.length() > 6 )
                        {
                        data.put("atStrName", addrLine);
                        data.put("atAddrTypR", "0");
                        return data;
                        }
                    }
                else
                    {
                    if(spaceFlag)
                      strName += " "+addrFields[j];
                    else
                      strName = addrFields[j];
                      spaceFlag = true;
                    }
                }
            } // 0

        // direction
        //
        if( s.equals("1") )
            {
            if(j==1)
                {
                atStrPreDirD = addrFields[j];
                preDirFlag = true;
                }
            if(j > 1)
                {
                if(preDirFlag || spaceFlag)
                    {
                    atStrPostDirD = addrFields[j];
                    postDirFlag = true;
                    }
                }
            } // 1

        // suffix
        //
        if( s.equals("2") )
            {
            if(j==2)
                {
                strSuffix  = addrFields[j];
                suffixFlag = true;
                }
            if(j > 2)
                {
                if(!suffixFlag && spaceFlag)
                    {
                    strSuffix  = addrFields[j];
                    suffixFlag = true;
                    }
                }
            } // 2

        // building type
        //
        if( s.equals("3") )
            {
            if(j==2)
                {
                atSecAddrTypeD = addrFields[j];
                bldgTypeFlag   = true;
                }
            if(j > 2)
                {
                if(!bldgTypeFlag && spaceFlag)
                    {
                    atSecAddrTypeD = addrFields[j];
                    bldgTypeFlag   = true;
                    }
                }
            } // 3
        } // for loop

    if (strNum         != null ) data.put("atStrNum",       strNum        );
    if (atStrPreDirD   != null ) data.put("atStrPreDirD",   translateValidDirection(atStrPreDirD));
    if (strName        != null ) data.put("atStrName",      strName       );
    if (atStrPostDirD  != null ) data.put("atStrPostDirD",  translateValidDirection(atStrPostDirD));
    if (strSuffix      != null ) data.put("atStrSuffixD",   strSuffix     );
    if (atSecAddrTypeD != null ) data.put("atSecAddrTypeD", atSecAddrTypeD);
    if (atSecAddrRge   != null ) data.put("atSecAddrRge",   atSecAddrRge  );
    data.put("atAddrTypR", "0");

    } // if( addrLine != null )

  return data;
  } // public static void parseAddressLineFiserv(String addrLine, Map data, boolean current)


  // str = AppImportUtils.processEmploymentPosition( position );
  //
  // check formatting for the four cases listed below and then return the position.
  //
  public static String processEmploymentPosition( String position )
  {
  //errorLog("START: processEmploymentPosition( String "+position+" )",AIU);

    String reformattedStr = null;

    if( position != null )
    {
    position = position.trim();

    if( position.toLowerCase().equals( "retired" ) )
        {
        reformattedStr = "Retired";
        }
    else if( position.toLowerCase().equals( "homemaker" ) )
        {
        reformattedStr = "Homemaker";
        }
    else if( position.toLowerCase().equals( "student" ) )
        {
        reformattedStr = "Student";
        }
    else if( position.toLowerCase().equals( "unemployed" ) )
        {
        reformattedStr = "Unemployed";
        }
    else if( position.toLowerCase().equals( "disability" ) )
        {
        reformattedStr = "Disability";
        }
    else
        {
        reformattedStr = position;
        }
    }

  //errorLog("END: return "+reformattedStr+" )",AIU);

  return reformattedStr;
  }

  /**
   * Check emplyment position because the duration of emplyment may not be required
   *
   * @param applicantPosition String
   * @return boolean
   */
  public static boolean employmentInformationRequired( String applicantPosition )
  {
    //errorLog("START: processEmploymentPosition( String "+position+" )",AIU);

    boolean required = true;

    if(applicantPosition != null && applicantPosition.trim().length() > 0 )
    {
      String position = applicantPosition.toLowerCase().trim();

      if( position.toLowerCase().equals( "retired" ) )
          {
          required = false;
          }
      else if( position.toLowerCase().equals( "homemaker" ) )
          {
          required = false;
          }
      else if( position.toLowerCase().equals( "student" ) )
          {
          required = false;
          }
      else if( position.toLowerCase().equals( "unemployed" ) )
          {
          required = false;
          }
      else if( position.toLowerCase().equals( "disability" ) )
          {
          required = false;
          }
      else if( position.toLowerCase().equals( "rental" ) )
          {
          required = false;
          }
    }

    //errorLog("END: return "+reformattedStr+" )",AIU);

    return required;
  }


  public static void setupCommentsNode( SystemDataObject sdo, DataNode appNode,
                                        HashtableX appData ) throws Exception

  {
    setupCommentsNode( sdo, appNode, appData, CSFieldValues.EMPTY_STRING );
    //errorLog("END setupCommentsNode(...)",AIU);
  } // setupCommentsNode(...)

  // Overloaded method that uses the incoming username
  //
  //
  public static void setupCommentsNode( SystemDataObject sdo, DataNode appNode,
                                        HashtableX appData, String username ) throws Exception
  {
  //S1Log.getLogInstance().log("setupCommentsNode(...)",LOG_FILE);

  HashtableX commentHash = new HashtableX();

  String todaysDateTime = DateUtility.generateDateTimeStampMilitary("/", ":", "MDY");
  //S1Log.getLogInstance().log("0 todaysDateTime: "+todaysDateTime,LOG_FILE);
  if( todaysDateTime == null && todaysDateTime.length() <= 0 )
      {
      // throw error
      //
      throw new Exception("Invalid Time Stamp: "+todaysDateTime);
      }

  String type = (String)appData.get("cmtTypD");
  //S1Log.getLogInstance().log("1 type: "+type,LOG_FILE);

  if( type == null && type.length() <= 0 )
      {
      // throw error
      //
      throw new Exception("Invalid Comment Type: "+type);
      }

  VectorX commentVec = (VectorX)appData.get("cmtA");
  //S1Log.getLogInstance().log("2 commentVec: "+commentVec,LOG_FILE);

  if( commentVec != null && ! commentVec.isEmpty() )
      {
      int cmtLength = checkCommentLength( commentVec );
      if( cmtLength > 2000 )
          {
          throw new Exception( "Invalid Comment Length: "+cmtLength+". The comment length must not be greater than 2000 characters." );
          }
      }
  else
      {
      // throw error
      //
      throw new Exception("Invalid Comment: "+commentVec);
      }

  //S1Log.getLogInstance().log("3 cmtDt:   "+todaysDateTime, LOG_FILE);
  //S1Log.getLogInstance().log("4 cmtTypD: "+type,           LOG_FILE);
  //S1Log.getLogInstance().log("5 cmtUser: "+getName(),      LOG_FILE);
  //S1Log.getLogInstance().log("6 cmtA:    "+commentVec,     LOG_FILE);
  //S1Log.getLogInstance().log("6.1 cmtA:    "+commentVec.size(),     LOG_FILE);

  // DataNode cmtNode = sdo.createDataNode( getName(), NodeUtils.CMT_DN_TYPE );
  //
  DataNode cmtNode = sdo.createDataNode( username==null||username.trim().length()==0 ? getName():username, NodeUtils.CMT_DN_TYPE );
  //S1Log.getLogInstance().log("7 cmtNode: "+cmtNode,LOG_FILE);

  if( cmtNode != null )
      {
      commentHash.put("cmtDt",   todaysDateTime );
      commentHash.put("cmtTypD", type           );
      commentHash.put("cmtUser", username==null||username.trim().length()==0 ? getName():username);

      // need to put the comments from each element of the vector into a new
      // vector that has one element. this will get rid of the non printable
      // characters that are visible when displayed by the front end
      //
      // public static VectorX createCommentVectorForDisplay( VectorX commentVec )
      //
      // commentHash.put("cmtA",    commentVec     );
      //
      VectorX displayVec = createCommentVectorForDisplay( commentVec );
      //S1Log.getLogInstance().log("7.1 displayVec: "+displayVec,LOG_FILE);
      //S1Log.getLogInstance().log("7.2 displayVec: "+displayVec.size(),LOG_FILE);

      if( displayVec != null && ! displayVec.isEmpty() )
      {
        commentHash.put("cmtA", displayVec);
      }
      else
      {
        displayVec = new VectorX();
        commentHash.put("cmtA", displayVec);
      }

      //S1Log.getLogInstance().log("8 Set Node Data: commentHash: "+commentHash,LOG_FILE);

      cmtNode.setFieldData( username==null||username.trim().length()==0 ? getName():username, commentHash );
      //S1Log.getLogInstance().log("9 Set Node Data: node: "+cmtNode,LOG_FILE);

      if( cmtNode != null )
          {
          appNode.addReference( cmtNode );
          //S1Log.getLogInstance().log("10 Set Node Data: appNode: HAS BEEN SET",LOG_FILE);
          }
      }

  //S1Log.getLogInstance().log("END setupCommentsNode(...)",LOG_FILE);
  } // setupCommentsNode(... WITH USERNAME)

  /**
   * Create authorized user node default user "AppImport"
   *
   * @param sdo SystemDataObject
   * @param appNode DataNode
   * @param nameHash HashtableX
   * @throws Exception
   */
  /*
  public static void setupAuthorizedUsersNode( SystemDataObject sdo, DataNode appNode,
                                               HashtableX nameHash ) throws Exception
  {
  //errorLog("setupAuthorizedUsersNode(...)",AIU);

  DataNode auNode = sdo.createDataNode( getName(), NodeUtils.AUTH_USER_DN_TYPE );
  //errorLog("1/4 auNode: "+auNode,AIU);

  if( auNode != null )
      {
      //errorLog("2/4 Set Node Data: nameHash: "+nameHash,AIU);

      auNode.setFieldData( getName(), nameHash );
      //errorLog("3/4 Set Node Data: node: "+auNode,AIU);

      if( auNode != null )
          {
          appNode.addReference( auNode );
          //errorLog("4/4 Set Node Data: appNode: HAS BEEN SET",AIU);
          }
      }

  //errorLog("END setupAuthorizedUsersNode(...)",AIU);
  } // setupAuthorizedUsersNode(...)
  */
  public static void setupAuthorizedUsersNode( SystemDataObject sdo, DataNode appNode, HashtableX nameHash ) throws Exception
  {
    //S1Log.getLogInstance().log("1 START setupAuthorizedUsersNode(...)",LOG_FILE);
    setupAuthorizedUsersNode( sdo, appNode, nameHash, null );
    //S1Log.getLogInstance().log("1 END setupAuthorizedUsersNode(...)",LOG_FILE);
  }
  /**
   * Create the authorized user node with username
   *
   * @param sdo SystemDataObject
   * @param appNode DataNode
   * @param nameHash HashtableX
   * @param username String
   * @throws Exception
   */
  public static void setupAuthorizedUsersNode( SystemDataObject sdo, DataNode appNode,
                                               HashtableX nameHash,  String username )
  throws Exception
  {
  //S1Log.getLogInstance().log("2 START setupAuthorizedUsersNode(...)",LOG_FILE);

  DataNode auNode = sdo.createDataNode( username==null||username.trim().length()==0 ? getName():username, NodeUtils.AUTH_USER_DN_TYPE );
  //S1Log.getLogInstance().log("1/4 auNode: "+auNode,LOG_FILE);

  if( auNode != null )
      {
      //S1Log.getLogInstance().log("2/4 Set Node Data: nameHash: "+nameHash,LOG_FILE);

      CSUtil.defaultAuthorizedUserName(nameHash);
      
      auNode.setFieldData( username==null||username.trim().length()==0 ? getName():username, nameHash );
      //S1Log.getLogInstance().log("3/4 Set Node Data: node: "+auNode,LOG_FILE);

      if( auNode != null )
          {
          appNode.addReference( auNode );
          //S1Log.getLogInstance().log("4/4 Set Node Data: appNode: HAS BEEN SET",LOG_FILE);
          }
      }

  //S1Log.getLogInstance().log("2 END setupAuthorizedUsersNode(...)",LOG_FILE);
  } // setupAuthorizedUsersNode(...)

  // code for method from CSGenUtils.opCodeSaveCmt(...)
  //
  public static int checkCommentLength( VectorX commentVec )
      {
      int cmtLength = 0;

      for ( int i = 0; i < commentVec.size(); i++ )
          {
          String lineText = (String) commentVec.elementAt(i);

          if( lineText == null )
              {
              lineText = CSFieldValues.EMPTY_STRING;
              }

          cmtLength += lineText.length() + 1;
          }

      cmtLength = cmtLength - 1;
      return cmtLength;
      }

  public static VectorX createCommentVectorForDisplay( VectorX commentVec )
  {
      VectorX returnVec = new VectorX();
      StringBuffer sb = null;

      if(commentVec != null && !commentVec.isEmpty())
      {
        sb = new StringBuffer();
        String lineText = null,
          tempStr = null,
          nl = "\n";
        StringTokenizer st = null;

        for (int i = 0, c = commentVec.size(); i < c; i++)
        {
          lineText = (String) commentVec.elementAt(i);
          if (lineText != null && lineText.trim().length() > 0)
          {
            //each new line character should be a node in the return vector
            if(lineText.indexOf(nl) > 0)
            {
              st = new StringTokenizer(lineText, nl);
              while(st.hasMoreTokens())
              {
                tempStr = st.nextToken();
                returnVec.add(tempStr);
              }
            }
            else
            {
              if (i == 0)
              {
                sb.append(lineText);
              }
              else
              {
                sb.append("  ");
                sb.append(lineText);
              }
            }
          }//if
        }//for

        if(sb != null && sb.length() > 0)
        {
          returnVec.add(sb.toString());
        }
      }

      return returnVec;
  }


  public static HashtableX parseName( String nameStr )
    {
    HashtableX data = new HashtableX();

    int tokCount = 0;

    if( nameStr != null )
        {
        StringTokenizer tok = new StringTokenizer( nameStr, " ");

        if( tok != null )
            {
            tokCount = tok.countTokens();

            if( tokCount > 1 && tokCount < 4 )
                {
                String strNameF     = null;
                String strNameM     = null;
                String strNameL     = null;

                switch (tokCount)
                    {
                    //case 1:
                    //  strNameL = tok.nextToken();
                    //  data.put( "auLName", strNameL != null && strNameL.length()>0 ?  strNameL : "");
                    //  break;

                    case 2:
                      strNameF = tok.nextToken();
                      data.put( "auFName", strNameF != null && strNameF.length()>0 ?  strNameF : CSFieldValues.EMPTY_STRING);

                      strNameL = tok.nextToken();
                      data.put( "auLName", strNameL != null && strNameL.length()>0 ?  strNameL : CSFieldValues.EMPTY_STRING);
                      break;

                    case 3:
                      strNameF = tok.nextToken();
                      data.put( "auFName", strNameF != null && strNameF.length()>0 ?  strNameF : CSFieldValues.EMPTY_STRING);

                      strNameM = tok.nextToken();
                      data.put( "auMInit", strNameM != null && strNameM.length()>0 ?
                                strNameM.substring(0,1).toUpperCase() : CSFieldValues.EMPTY_STRING);

                      strNameL = tok.nextToken();
                      data.put( "auLName", strNameL != null && strNameL.length()>0 ?  strNameL : CSFieldValues.EMPTY_STRING);
                      break;
                    }
                }
            }
        }

    return data;
    }


  public static String checkIdentificationTypeString( String type )
      {
      //errorLog("checkIdentificationTypeString( String type ): "+type,AIU);

      String idTypeStr = type.trim();

      try
        {
        boolean isInt   = false;
        boolean useText = false;
        boolean useCode = false;

        Map assMap = listAssignCache.getListAssignment( "Identification_Details" );
        //errorLog("assMap: "+assMap,AIU);

        if( assMap != null && !assMap.isEmpty() && assMap.containsKey( "atIdTypD" ))
            {
            useText = true;
            }

        Map codeMap = listCodeAssignCache.getListCodeAssignment( "Identification_Details" );
        //errorLog("codeMap: "+codeMap,AIU);

        if( codeMap != null && !codeMap.isEmpty() && codeMap.containsKey( "atIdTypD" ))
            {
            useCode = true;
            }

        try
          {
          int codeNum = Integer.parseInt( idTypeStr );
          isInt = true;
          }
        catch( Exception e )
            {
            }

        //errorLog("useText: "+useText,AIU);
        //errorLog("useCode: "+useCode,AIU);
        //errorLog("isInt  : "+isInt,  AIU);

        // return text value from list code if possible
        //
        if( useText && !useCode && isInt )
            {
            VectorX[] codes = listCodesCache.getListCodes( "Identification Type" );

            if( codes != null && codes.length > 0 )
                {
                String listCodeLabel = listCodesCache.getListCodeLabel( "Identification Type", idTypeStr );

                if( listCodeLabel != null && listCodeLabel.length() > 0 )
                    {
                    idTypeStr = listCodeLabel;
                    }
                }
            }

        if( useCode && !useText && !isInt )
            {
            VectorX[] codes = listCodesCache.getListCodes( "Identification Type" );
            if( codes != null && codes.length > 0 )
                {
                List codeKeys = (List)codes[0].clone();
                List codeLbls = (List)codes[1].clone();

                int index = codeLbls.indexOf( idTypeStr );

                if (index >= 0 && index < codeLbls.size())
                    {
                    String key = (String)codeKeys.get( index );

                    if( key != null && key.length() > 0 )
                        {
                        idTypeStr = key;
                        }
                    }
                }
            }
        }
      catch( Exception e )
          {
          }

      //errorLog("END checkIdentificationTypeString( String type ): return: "+idTypeStr,AIU);

      return idTypeStr;
      }


  public static String[] lookupCityState(String city, String zipcode,
                                         int numCharsToMatch)
  throws SQLException
  {
    String cityState[] = null;

    List results = DBQueries.executeCityStateLookupQuery(zipcode);

    if (! results.isEmpty())
    {
      if (results.size() == 1)
      {
        cityState = (String[])results.get(0);
      }
      else if (numCharsToMatch > 0)
      {
        boolean match = false;

        // Multiple matches on the zipcode... attempt to choose a city based
        // on the first few characters of the city that was entered.
        //
        if (city.length() > numCharsToMatch)
        {
          city = city.substring(0, numCharsToMatch);
        }

        city = city.toLowerCase();

        String dbCity;
        for (int i = 0, c = results.size(); i < c; ++i)
        {
          cityState = (String[])results.get(i);

          dbCity = cityState[0].toLowerCase();

          if (dbCity.startsWith(city))
          {
            match = true;
            break;
          }
        }

        if (! match) cityState = null;
      }
    }

    return cityState;
  }


  private static void errorLog( String s, String fileName )
      {
      if( LOG )
          {
          //general.errLog(CSFieldValues.EMPTY_STRING,fileName);//general.errLog(s,fileName);//general.errLog(CSFieldValues.EMPTY_STRING,fileName);
          }
      }

  private static void errorLog( String s, String fileName, boolean log )
      {
      if( log )
          {
          //general.errLog(CSFieldValues.EMPTY_STRING,fileName);//general.errLog(s,fileName);//general.errLog(CSFieldValues.EMPTY_STRING,fileName);
          }
      }

  // addrMap = AppImportUtils.reformatAddress( fieldName, str, true );

  public static HashMap reformatAddress(String csKey, String fmValue, boolean regularAddress)
  throws Exception
  {
    String prefix = null;

    if (regularAddress)
    {
      prefix = "at";
    }
    else
    {
      prefix = "atPrv";
    }

    return reformatAddress(csKey, fmValue, prefix);
  }


  //
  // new address formatting method and supporting methods, 9-9-04, mrl
  //
  public static HashMap reformatAddress(String csKey, String fmValue, String prefix )
  throws Exception
  {
  //errorLog("reformatAddressCKD(String "+csKey+", String "+fmValue+", String "+prefix+" )",AIU);

  Map streetMap = loadAbbrieviations(true );
  //errorLog("streetMap: "+streetMap,AIU);

  Map unitMap   = loadAbbrieviations(false);
  //errorLog("unitMap: "+unitMap,AIU);

  HashMap dataMap  = new HashMap();

  //errorLog("",AIU);//errorLog("csKey:   "+csKey,AIU);//errorLog("",AIU);
  //errorLog("",AIU);//errorLog("fmValue: "+fmValue,AIU);//errorLog("",AIU);
  //errorLog("",AIU);//errorLog("prefix: "+prefix,AIU);//errorLog("",AIU);

  // determine if primary applicant( _0 )or co-app( _1)
  //
  String appType = null;

  if( csKey != null && csKey.endsWith("_0") )
      {
      appType = "_0";
      }
  else if( csKey != null && csKey.endsWith("_1") )
      {
      appType = "_1";
      }
  else
      {
      appType = CSFieldValues.EMPTY_STRING;
      }

  //errorLog("",AIU);//errorLog("appType: "+appType,AIU);//errorLog("",AIU);

   if( fmValue != null && fmValue.length() > 0 )
   {
   try
      {
      // remove immediately
      //
      if (fmValue.startsWith("#"))
          {
          fmValue = fmValue.substring(1);
          }

      // Remove spaces and periods for po box and rural routes and replace pound
      //  signs with blank spaces
      //
      String temp  = null;
      String temp2 = null;

      // po boxes and rural routes
      //
      temp = removeSpacesAndPeriodsAndPound( fmValue );
      //errorLog("1 temp: "+temp,AIU);

      temp = replacePOorRR( temp );
      //errorLog("2 temp: "+temp,AIU);

      if( temp != null ) temp = temp.toUpperCase();
      //errorLog("",AIU);//errorLog("temp: "+temp,AIU);//errorLog("",AIU);

      // RR 1 Box 108
      // 40 nw 76 ave

      // po box address
      //
      if (temp.toUpperCase().startsWith("POBOX") ||
          temp.toUpperCase().startsWith("BOX"))
          {
          if (temp.length() > 3)
              {
              dataMap = processPostOfficeBox( fmValue, appType, prefix );
              } // if (temp.length() > 3)
          else
              {
              return addressFormatError(fmValue, appType, prefix);
              //throw new Exception("Unable to process the address PO BOX: "+temp);
              }

          } // if (temp.toLowerCase().startsWith("pobox"))


      // route / military address
      //
      else if ( temp.toUpperCase().startsWith("RR")  || temp.toUpperCase().startsWith("HC")   ||
                temp.toUpperCase().startsWith("HCR") || temp.toUpperCase().startsWith("CMR")  ||
                temp.toUpperCase().startsWith("RT")  || temp.toUpperCase().startsWith("PSC")  ||
                temp.toUpperCase().startsWith("RTE") || temp.toUpperCase().startsWith("UNIT") ||
                temp.toUpperCase().startsWith("ROUTE") )

          {
          //errorLog("",AIU);//errorLog("0 ROURAL ROUTE:  temp: "+temp,AIU);//errorLog("",AIU);

          if( temp.length() > 2 )
              {
              dataMap = processRuralRoute( temp, fmValue, appType, prefix );
              }
          else
              {
              return addressFormatError(fmValue, appType, prefix);
              }

          } // End else if ( temp.toUpperCase().startsWith("RR ")


      // normal address
      //
      else
          {
          //errorLog("",AIU);//errorLog("1 normal address temp2: "+temp2,AIU);//errorLog("",AIU);

          String strNum         = null;
          String atStrPreDirD   = null;
          String strName        = null;
          String atStrPostDirD  = null;
          String strSuffix      = null;
          String atSecAddrTypeD = null;
          String atSecAddrRge   = null;
          String atAddrTwo      = null;

          boolean spaceFlag    = false;
          boolean preDirFlag   = false;
          boolean postDirFlag  = false;
          boolean suffixFlag   = false;
          boolean bldgTypeFlag = false;
          boolean secRangeFlag = false;

          Map suffixMap = new HashMap();

          // residential address
          //
          // 1450 Colliers Creek Rd
          //

          // ckd use pound sign
          //
          temp2 = replaceEmbeddedString(fmValue, "#", "# ");
          temp2 = replaceEmbeddedString(temp2, ".", CSFieldValues.EMPTY_STRING);
          temp2 = replaceEmbeddedString(temp2, ",", CSFieldValues.EMPTY_STRING);
          temp2 = replaceTwoWordDirectionals(temp2);

          //errorLog("Start: temp2: " + temp2,AIU);

          StringTokenizer tok = new StringTokenizer( temp2, " " );
          //int tokCount = tok.countTokens();

          String[] addrFields = null;
          addrFields = new String[tok.countTokens()];

          int i = 0;

          while (tok.hasMoreTokens())
              {
              addrFields[i] = tok.nextToken();
              ++i;
              }

          // if address fields length greater than one begin looping
          //
          if( addrFields.length > 1 )
              {
              for( int j=0, k=addrFields.length; j < k; j++ )
                  {
                  String s = processToken( addrFields[j], streetMap, unitMap );

                  //errorLog("Start: J: " + j,AIU);

                  //errorLog("",AIU);
                  //errorLog("j: "+j,AIU);
                  //errorLog("s: "+s,AIU);
                  //errorLog("",AIU);//errorLog("addrFields[j]: "+addrFields[j],AIU);//errorLog("",AIU);
                  //errorLog("spaceFlag:    "+spaceFlag,AIU);
                  //errorLog("preDirFlag:   "+preDirFlag,AIU);
                  //errorLog("postDirFlag:  "+postDirFlag,AIU);
                  //errorLog("suffixFlag:   "+suffixFlag,AIU);
                  //errorLog("bldgTypeFlag: "+bldgTypeFlag,AIU);
                  //errorLog("secRangeFlag: "+secRangeFlag,AIU);
                  //errorLog("",AIU);

                  // address
                  //
                  if( s.equals("0") )
                      {
                      if(j==0) // street number
                          {
                          strNum = addrFields[j];

                          if( strNum.length() > 6 )
                              {
                              return addressFormatError(fmValue, appType, prefix);
                              }
                          }
                      else if(j==1) // street name
                          {
                          strName = addrFields[j];
                          spaceFlag = true;

                          //errorLog(" strName: " + strName,AIU);
                          //errorLog(" spaceFlag: " + spaceFlag,AIU);
                          }
                      else if(j > 1)
                          {
                          //errorLog(addrFields[j] + " bldgTypeFlag: " + bldgTypeFlag,AIU);

                          if( bldgTypeFlag )
                              {
                              if(!secRangeFlag)
                                {
                                atSecAddrRge = addrFields[j];
                                secRangeFlag = true;
                                }
                             else
                                {
                                if( atAddrTwo == null )
                                    {
                                    atAddrTwo = addrFields[j];
                                    }
                                else
                                    {
                                   atAddrTwo += " "+addrFields[j];
                                    }
                                }

                              //errorLog(addrFields[j] + " atSecAddrRge: " + atSecAddrRge,AIU);

                              if( atSecAddrRge != null && atSecAddrRge.length() > 6 )
                                  {
                                  return addressFormatError(fmValue, appType, prefix);
                                  }
                              }
                          else
                              {
                              //errorLog("if(spaceFlag) = " + spaceFlag,AIU);

                              if( spaceFlag )
                                  {
                                    if ( atSecAddrRge == null &&
                                       ( (atStrPostDirD != null && atStrPostDirD.length() > 0) ||
                                         (strSuffix != null && strSuffix.length() > 0) ) )
                                            {
                                      if( bldgTypeFlag )
                                          {
                                          atSecAddrRge = addrFields[j];
                                          secRangeFlag = true;
                                          }
                                      else
                                          {
                                          if( suffixFlag )
                                              {
                                              if( atAddrTwo == null )
                                                  {
                                                  atAddrTwo = addrFields[j];
                                                  }
                                              else
                                                  {
                                                 atAddrTwo += " "+addrFields[j];
                                                  }
                                              }
                                          else
                                              {
                                              strName += " "+addrFields[j];
                                              }
                                          }
                                    }
                                    else if (strSuffix != null && strSuffix.length() > 0)
                                    {
                                    //strName += tempSuffix+" "+addrFields[j];
                                    //
                                    strName += " "+addrFields[j];

                                    //errorLog("strName = " + strName,AIU);
                                    //strSuffix = null;
                                    }
                                    else
                                    {
                                    strName += " "+addrFields[j];
                                    }

                                  }
                              else
                                  {
                                  //errorLog("if (strSuffix != null && strSuffix.length() > 0) = " +(strSuffix != null && strSuffix.length() > 0),AIU);

                                  if (strSuffix != null && strSuffix.length() > 0)
                                      {
                                      strName += " "+addrFields[j];
                                      }
                                  else
                                      {
                                      strName = addrFields[j];
                                      spaceFlag = true;
                                      }
                                  }
                              }
                          }
                      } // 0

                  // direction
                  //
                  if( s.equals("1") )
                      {
                      if(j==1)
                          {
                          atStrPreDirD = addrFields[j];

                          if (atStrPreDirD.length() > 2)
                              {
                              atStrPreDirD = atStrPreDirD.substring(0,1).toUpperCase();
                              }

                          preDirFlag = true;
                          }
                      else if(j > 1)
                          {
                          if( preDirFlag || spaceFlag )
                              {
                              if( strName != null && !postDirFlag )
                                  {
                                  atStrPostDirD = addrFields[j];

                                  if (atStrPostDirD.length() > 2)
                                      {
                                        atStrPostDirD = atStrPostDirD.substring(0,1).toUpperCase();
                                      }

                                  postDirFlag = true;
                                  }
                              else
                                  {
                                  if( !suffixFlag )
                                      {
                                      if( !spaceFlag )
                                          {
                                          strName = addrFields[j];
                                          spaceFlag = true;
                                          }
                                      else
                                          {
                                          strName += " "+addrFields[j];
                                          }
                                      }
                                  else
                                      {
                                      if( atAddrTwo == null || atAddrTwo.length() == 0 )
                                          {
                                          atAddrTwo = addrFields[j];
                                          }
                                      else
                                          {
                                          atAddrTwo += " "+addrFields[j];
                                          }
                                      } //if( !suffixFlag )
                                  } // if( strName != null && !postDirFlag && !suffixFlag  )
                              } // if( preDirFlag || spaceFlag )
                          } // else if(j > 1)
                      } // 1

                  // suffix
                  //
                  if( s.equals("2") )
                      {
                      if(j==1)
                          {
                          strName = addrFields[j];
                          spaceFlag = true;
                          }
                      else if( j == 2)
                          {
                          if( spaceFlag )
                              {
                              strSuffix  = addrFields[j];
                              }
                          else
                              {
                              strName = addrFields[j];
                              spaceFlag = true;
                              //errorLog("0 Suffix: strName: " + strName,AIU);
                              }

                          //errorLog("1 strSuffix: " + strSuffix,AIU);

                          if( strSuffix != null && strSuffix.length() > 0 )
                              {
                              strSuffix = (String)streetMap.get( strSuffix.toUpperCase() );
                              suffixMap.put( strSuffix, addrFields[j] );
                              suffixFlag = true;
                              }

                          //errorLog("2 strSuffix: " + strSuffix,AIU);
                          }
                      else if(j > 2)
                          {
                          //errorLog("3 if(!suffixFlag && spaceFlag): " + (!suffixFlag && spaceFlag),AIU);

                          if(!suffixFlag && spaceFlag)
                              {
                              strSuffix  = addrFields[j];

                              if( strSuffix != null && strSuffix.length() > 0 )
                                  {
                                  strSuffix = (String)streetMap.get( strSuffix.toUpperCase() );
                                  suffixMap.put(strSuffix, addrFields[j]);
                                  suffixFlag = true;
                                  }
                              }
                          else
                              {
                              if( spaceFlag && suffixFlag )
                                  {
                                  // need to use original word not suffix so we need to set a temp variable
                                  //                                
                                  // strName += " "+strSuffix;
                                  //
                                  if( suffixMap.containsKey(strSuffix) )
                                    strName += " " + suffixMap.remove(strSuffix);
                                  else
                                    strName += " " + strSuffix;
                                  }

                              strSuffix  = addrFields[j];

                              if( strSuffix != null && strSuffix.length() > 0 )
                                  {
                                  strSuffix = (String)streetMap.get( strSuffix.toUpperCase() );
                                  suffixMap.put(strSuffix, addrFields[j]);
                                  suffixFlag = true;
                                  }
                              else
                                  {
                                  strName = addrFields[j];
                                  spaceFlag = true;
                                  }

                              //errorLog("4 Suffix: strName: " + strName,AIU);
                              }
                          } // else if(j > 2)
                      } // 2

                  // building type
                  //
                  if( s.equals("3") )
                      {
                      //errorLog("J: " + j + bldgTypeFlag +" " +spaceFlag,AIU);

                      if(j==1)
                          {
                          strName = addrFields[j];
                          spaceFlag = true;
                          }
                      else if(!bldgTypeFlag) // FIRST RUN
                          {
                          atSecAddrTypeD = addrFields[j];

                          //errorLog("atSecAddrTypeD: " + atSecAddrTypeD,AIU);

                          if( atSecAddrTypeD != null && atSecAddrTypeD.length() > 0 )
                              {
                              atSecAddrTypeD = (String)unitMap.get( atSecAddrTypeD.toUpperCase() );
                              bldgTypeFlag   = true;
                              }
                          }
                      else if(bldgTypeFlag) // SECOND RUN
                          {
                          if( atAddrTwo == null )
                              {
                              atAddrTwo = addrFields[j];
                              //errorLog("if: atAddrTwo: " +atAddrTwo,AIU);
                              }
                          else
                              {
                              atAddrTwo += " "+addrFields[j];
                            
                              //errorLog("else: atAddrTwo: " +atAddrTwo,AIU);
                              }
                          }
                      } // 3
                  } // for loop

              } // if( addrFields.length > 1 )
          else
              {
              strName = addrFields[0];
              }

          if (strNum       != null && appType != null) dataMap.put(prefix + "StrNum"+appType,     strNum);
          if (atStrPreDirD != null && appType != null) dataMap.put(prefix + "StrPreDirD"+appType, atStrPreDirD);

          if (strName != null && appType != null)
              {
              // string length to long for field split into two fields
              //
              if( strName.length() <= 24 )
                  {
                    dataMap.put(prefix + "StrName"+appType, strName);
                  }
             else
                  {
                  String addr1 = strName.substring(0, 24);
                  String addr2 = strName.substring(24);

                  dataMap.put(prefix + "StrName"+appType, addr1);
                  if( atAddrTwo == null || atAddrTwo.length() == 0 )
                      {
                      dataMap.put(prefix + "AddrTwo"+appType, addr2);
                      }
                  else
                      {
                      atAddrTwo = addr2 + "  " + atAddrTwo;
                      }
                  }
              }

          if (atStrPostDirD  != null && appType != null) dataMap.put(prefix + "StrPostDirD"+appType, atStrPostDirD);
          if (strSuffix      != null && appType != null) dataMap.put(prefix + "StrSuffixD"+appType, strSuffix);
          if (atSecAddrTypeD != null && appType != null) dataMap.put(prefix + "SecAddrTypeD"+appType, atSecAddrTypeD);
          if (atSecAddrRge   != null && appType != null) dataMap.put(prefix + "SecAddrRge"+appType, atSecAddrRge);
          if (atAddrTwo      != null && appType != null) dataMap.put(prefix + "AddrTwo"+appType, atAddrTwo);
          if (appType != null) dataMap.put(prefix + "AddrTypR"+appType, "0");
          if (appType != null && prefix.equals("atPrv"))
          {
            dataMap.put("atPrvAddrVsC"+appType, "true");
          }

          } // else

      } // try
    catch( Exception e )
        {
        e.printStackTrace();
        //
        String errMsg = "An error occurred while processing the applicant's address information. Error: "+e.getMessage() ;
        //
        //errorLog( errMsg,AIU );
        //
        throw new Exception( errMsg );
        } // try / catch

    } // if( fmValue != null && fmValue.length() > 0 )
  else
      {
      String errMsg = "Invalid address. The applicant's address information cannot be processed. Address: "+fmValue ;
      //
      //errorLog( errMsg,AIU );
      //
      throw new Exception( errMsg );
      }

  //errorLog("return dataMap "+dataMap,AIU);

  //writeHash(dataMap, "ReformatAddressCKD.txt" );

  return dataMap;
  } // reformatAddressCKD(String csKey, String fmValue, Map fieldMap )


  // query database for suffix and unit abreviations
  //
  public static Map loadAbbrieviations( boolean streetAbbrv ) throws SQLException
  {
    Map abbrvMap = new HashMap();

    String sql = null;

    // street or unit
    //
    if( streetAbbrv )
        {
        sql = "SELECT * FROM xntStreetAbbr";
        }
    else
        {
        sql = "SELECT * FROM xntUnitAbbr";
        }


    if( sql != null && sql.length() > 0 )
        {
        Statement stmt = null;

        try
          {
          Connection con = DBAccess.getConnection();
          stmt = con.createStatement();
          ResultSet rs = stmt.executeQuery(sql);

          while( rs.next() )
              {
              String key   = null;
              String value = null;


              if( streetAbbrv )
                  {
                  // cStreet, cStdSfx
                  //
                  key   = rs.getString("cStreet");
                  value = rs.getString("cStdSfx");
                  }
              else
                  {
                  // cUnit, cStdAbv
                  //
                  key   = rs.getString("cUnit"  );
                  value = rs.getString("cStdAbv");
                  }

              if( key != null && key.length() > 0 && value != null && value.length() > 0)
                  {
                  abbrvMap.put( key, value );
                  }

              } // while (rs.next())

          }
        catch (SQLException e)
            {
            DBLogger.log( "AppImportUtils: loadAbbrieviations(...): Executing " + sql + ": " + e.getMessage() );
            throw e;
            }

        finally
            {
            DBAccess.closeConnection(stmt);
            }
        }

    return abbrvMap;
  }

  public static String replaceTwoWordDirectionals(String fmValue)
      {
      String newAddress = null;

      newAddress = replaceEmbeddedString(fmValue.toUpperCase(),    "NORTH EAST", "NE");
      newAddress = replaceEmbeddedString(newAddress.toUpperCase(), "NORTH WEST", "NW");
      newAddress = replaceEmbeddedString(newAddress.toUpperCase(), "N EAST",     "NE");
      newAddress = replaceEmbeddedString(newAddress.toUpperCase(), "N WEST",     "NW");
      newAddress = replaceEmbeddedString(newAddress.toUpperCase(), "NORTH E",    "NE");
      newAddress = replaceEmbeddedString(newAddress.toUpperCase(), "NORTH W",    "NW");
      newAddress = replaceEmbeddedString(newAddress.toUpperCase(), "SOUTH EAST", "SE");
      newAddress = replaceEmbeddedString(newAddress.toUpperCase(), "SOUTH WEST", "SW");
      newAddress = replaceEmbeddedString(newAddress.toUpperCase(), "SOUTH E",    "SE");
      newAddress = replaceEmbeddedString(newAddress.toUpperCase(), "SOUTH W",    "SW");
      newAddress = replaceEmbeddedString(newAddress.toUpperCase(), "S EAST",     "SE");
      newAddress = replaceEmbeddedString(newAddress.toUpperCase(), "S WEST",     "SW");

      return newAddress;
      }


  public static String replacePOorRR(String temp)
      {
      String newAddress = null;

      newAddress = replaceEmbeddedString(temp.toUpperCase(),       "POSTOFFICE", "PO");
      newAddress = replaceEmbeddedString(temp.toUpperCase(),       "POSTOFCE",   "PO");
      newAddress = replaceEmbeddedString(temp.toUpperCase(),       "POSTOFFC",   "PO");
      newAddress = replaceEmbeddedString(temp.toUpperCase(),       "POSTOFC",    "PO");
      newAddress = replaceEmbeddedString(temp.toUpperCase(),       "POSTOFF",    "PO");
      newAddress = replaceEmbeddedString(newAddress.toUpperCase(), "RURALROUTE", "RR");
      newAddress = replaceEmbeddedString(newAddress.toUpperCase(), "RURALRTE",   "RR");
      newAddress = replaceEmbeddedString(newAddress.toUpperCase(), "RURALRT",    "RR");
      newAddress = replaceEmbeddedString(newAddress.toUpperCase(), "RURROUTE",   "RR");
      newAddress = replaceEmbeddedString(newAddress.toUpperCase(), "RURRT",      "RR");
      newAddress = replaceEmbeddedString(newAddress.toUpperCase(), "RURRTE",     "RR");

      return newAddress;
      }


  public static String processToken( String token, Map streetAbbrMap, Map unitAbbrMap )
    {
    String tokenValue = null;

    if( isValidDirection( token ) )
        {
        tokenValue = "1";
        }
    else if( streetAbbrMap.containsKey(token.toUpperCase() ))
        {
        tokenValue = "2";
        }
    else if( unitAbbrMap.containsKey(token.toUpperCase() ))
        {
        tokenValue = "3";
        }
    else
        {
        tokenValue = "0";
        }

    //general.errLog("Proc Tok: "+token + " Val: " + tokenValue);

    return tokenValue;
    } // processToken( String strSuffix )


  public static String replaceEmbeddedString(String stringToEdit,
                                             String stringToRemove,
                                             String stringToReplaceWith)
  {
    // 1. Find the index of the first occurrence of the string.
    // 2. Extract all the characters before the index and after
    //    index plus the length of the stringToRemove.
    // 3. Combine the extracted strings and repeat.

    StringBuffer sb = new StringBuffer(stringToEdit);

    int index = stringToEdit.indexOf(stringToRemove);

    int prevIndex = 0;

    while (index > 0)
    {
      sb.replace(index + prevIndex, index + prevIndex + stringToRemove.length(), stringToReplaceWith);
      prevIndex += index + stringToReplaceWith.length();

      stringToEdit = sb.substring(prevIndex, sb.length());
      index = stringToEdit.indexOf(stringToRemove);
    }

    return sb.toString();
  }

  private static HashMap processPostOfficeBox( String fmValue, String appType,
                                               String prefix )
      {
      HashMap dataMap = new HashMap();

      String address   = fmValue;
      String box       = null;
      String temp      = null;
      String remainder = null;

      int index = address.toUpperCase().indexOf("BOX");

      if (index != -1)
          {
          temp = address.substring(index + 3).trim();

          index = temp.indexOf(' ');

          if (index != -1)
              {
              box = temp.substring(0, index);
              remainder = temp.substring(index + 1);
              }
          else
              {
              box = temp;
              }

          } // if (index != -1)
      else
          {
          box = address;
          }

      if( box.length() > 6 )
          {
          return addressFormatError(fmValue, appType, prefix);
          //throw new Exception("Invalid PO BOX number: Length > 6 "+box);
          }

      // regular or previous address
      //
      if( box != null && appType != null) dataMap.put(prefix + "POBox"+appType, box);

      if( remainder != null && remainder.length() > 0 && appType != null)
          {
            dataMap.put(prefix + "AddrTwo"+appType, remainder);
          }

      if( appType != null ) dataMap.put(prefix + "AddrTypR"+appType, "2");
      if (appType != null && prefix.equals("atPrv"))
      {
        dataMap.put("atPrvAddrVsC"+appType, "true");
      }

      return dataMap;
      } // processPOBox(...)


  private static HashMap processRuralRoute( String temp, String fmValue,
                                            String appType, String prefix )
      {
      //errorLog("",AIU);errorLog("processRuralRoute( String "+temp+", String "+fmValue+", String "+appType+", String "+prefix+" ): "+temp,AIU);errorLog("",AIU);

      HashMap dataMap = new HashMap();

      String address   = fmValue;

      String routeType = null;
      String routeNum  = null;
      String boxNum    = null;
      String remainder = null;

      //
      // RR 1 BOX 1111
      //

      if( temp.toUpperCase().startsWith("HCR")  || temp.toUpperCase().startsWith("CMR")  ||
               temp.toUpperCase().startsWith("PSC")  || temp.toUpperCase().startsWith("RTE"))
          {
          routeType = temp.substring(0, 3);
          temp = address.trim().substring(3);
          }
      else if( temp.toUpperCase().startsWith("RR")  || temp.toUpperCase().startsWith("HC")  || temp.toUpperCase().startsWith("RT") )
          {
          //
          // RT 209 - 534 INTERSECTION
          //

          routeType = temp.substring(0, 2);
          temp = address.trim().substring(2);
          }
      else if( temp.toUpperCase().startsWith("UNIT") )
          {
          routeType = temp.substring(0, 4);
          temp = address.trim().substring(4);
          }
      else if( temp.toUpperCase().startsWith("ROUTE") )
          {
          routeType = "RTE";
          temp = address.trim().substring(5);
          }
      else
          {
          return addressFormatError(fmValue, appType, prefix);
          }

      //errorLog("1 temp: "+temp,AIU);

      int index = temp.toUpperCase().indexOf("BOX");

      if( index != -1 )
          {
          routeNum = temp.substring(0, index).trim();

          if (routeNum.toUpperCase().endsWith("PO"))
          {
            routeNum = routeNum.substring(0, routeNum.length() - 2);
          }

          //errorLog("2 temp: "+temp,AIU);

          if( routeNum.length() > 5 )
              {
              return addressFormatError(fmValue, appType, prefix);
              }
          else
              {
              String boxNumStr = temp.substring( index + 3 ).trim();

              //errorLog("2 boxNumStr: "+boxNumStr,AIU);

              index = boxNumStr.indexOf(' ');

              //errorLog("2.1 index: "+index,AIU);

              if (index != -1)
                  {
                  boxNum    = boxNumStr.substring(0, index);

                  //errorLog("3 boxNum: "+boxNum,AIU);

                  remainder = boxNumStr.substring(index + 1).trim();

                  //errorLog("3 remainder: "+remainder,AIU);
                  }
              else
                  {
                  boxNum = boxNumStr.trim();
                  }

              if( boxNum.length() > 6 )
                  {
                  return addressFormatError(fmValue, appType, prefix);
                  }
              } // if / else

          }
      else
          {
          // dump the rest in the route number field
          //
          routeNum = temp.trim();

          //errorLog("NO BOX routeNum: "+routeNum,AIU);
          //return addressFormatErrorCKD(fmValue, appType, regularAddress, streetMap, unitMap);
          } // if / else

      if( routeType != null && appType != null) dataMap.put(prefix + "RtTypeD"+appType, routeType);
      if( routeNum  != null && appType != null )
      {
        //errorLog("PROCESS routeNum: "+routeNum,AIU);
        //
        // RT 209 - 534 INTERSECTION
        //

        // route num field size 5
        if( routeNum.length() < 6 )
        {
          dataMap.put(prefix + "RtNum" + appType, routeNum);
        }
        else
        {
          int rtIdx = routeNum.indexOf(' ');

          if( rtIdx != -1 )
          {
            // try and find a route number
            //
            String rtNum = routeNum.substring(0,rtIdx);
            //errorLog("",AIU);errorLog("rtNum: "+rtNum,AIU);errorLog("",AIU);

            if( rtNum.length() < 6 )
            {
              // parse out route number
              //
              dataMap.put(prefix + "RtNum" + appType, rtNum);
              remainder = routeNum.substring( rtIdx + 1 );
              //errorLog("",AIU);errorLog("rtNum 1 remainder: "+remainder,AIU);errorLog("",AIU);

            }
            else
            {
              remainder = routeNum;
              //errorLog("",AIU);errorLog("rtNum 2 remainder: "+remainder,AIU);errorLog("",AIU);
            }
          }
          else
          {
            remainder = routeNum;
            //errorLog("",AIU);errorLog("rtNum 3 remainder: "+remainder,AIU);errorLog("",AIU);
          }
        }
      }

      if( boxNum != null && appType != null) dataMap.put(prefix + "BxNum"+appType,   boxNum);

      if( remainder != null && appType != null)
          {
            dataMap.put(prefix + "AddrTwo"+appType, remainder);
          }

      if (appType != null) dataMap.put(prefix + "AddrTypR"+appType, "1");
      if (appType != null && prefix.equals("atPrv"))
      {
        dataMap.put("atPrvAddrVsC"+appType, "true");
      }

      return dataMap;
      }


  private static void writeHash( HashMap giantHash, String fileName)
      {
      try
        {
        FileWriter fw = new FileWriter( "extfiles" + File.separator + fileName, true);

        TreeMap tm = new TreeMap();
        tm.putAll(giantHash);

        //fw.write( tm.toString() + "\r\n");

        Iterator it = tm.keySet().iterator();
        String k = null;
        Object v = null;

        while (it.hasNext())
          {
          k = (String)it.next();
          v = tm.get(k);

          fw.write(k + " = " + v.toString().toUpperCase() + "\r\n");
          }


        fw.close();
        }
      catch (Exception e)
          {
          e.printStackTrace();
          String errMsg = "Method:Write Hash: Error: "+e.getMessage();
          //eLog(errMsg);
          }
      } // writeHash(Hashtable giantHash, String fileName)


  public static VectorX transUnionReportToVectors(String reportStr)
  {
    //errorLog("transUnionReportToVector", "creditRptToVec", true);

    if (reportStr == null) return null;

    VectorX report           = new VectorX(); // parsed with *
    VectorX bothReports      = new VectorX(); // container for both reports
    VectorX humRdblReport    = new VectorX(); // parsed with *
    VectorX humRdblCrdReport = new VectorX(); // parsed without *

    //errorLog("reportStr: "+reportStr, "creditRptToVec", true);

    String delimiter = "ENDS010"; // end of machine code begining of human readable

    int index = reportStr.indexOf( delimiter );
    //errorLog("index: "+index, "creditRptToVec", true);

    int endMachCode = index +10;
    //errorLog("endMachCode: "+endMachCode, "creditRptToVec", true);

    String machCodeStr = reportStr.substring( 0, endMachCode );
    //errorLog("machCodeStr: "+machCodeStr, "creditRptToVec", true);

    VectorX machCodeVec = creditReportToVector( machCodeStr, false );
    //errorLog("machCodeVec: "+machCodeVec, "creditRptToVec", true);

    if( machCodeVec != null && ! machCodeVec.isEmpty() )
    {
      report.addAll( machCodeVec );
    }

    String humRdblStr = reportStr.substring( endMachCode );
    //errorLog("humRdblStr: "+humRdblStr, "creditRptToVec", true);

    VectorX humRdblVec = transUnionHumanReadableReportToVector( humRdblStr );
    //errorLog("humRdblVec: "+humRdblVec, "creditRptToVec", true);

    if( humRdblVec != null && humRdblVec.size() == 2 )
    {
      humRdblReport = (VectorX)humRdblVec.firstElement();

      if( humRdblReport != null && ! humRdblReport.isEmpty() )
      {
        report.addAll( humRdblReport );
        bothReports.add( report );
      }

      humRdblCrdReport = (VectorX)humRdblVec.lastElement();

      if( humRdblCrdReport != null && ! humRdblCrdReport.isEmpty() )
      {
        bothReports.add( humRdblCrdReport );
      }
    }

    //errorLog("report: "+report, "creditRptToVec", true);

    return bothReports;
  }


  public static VectorX transUnionHumanReadableReportToVector(String reportStr)
  {
    //errorLog("transUnionHumanReadableReportToVector", "creditRptToVec", true);
    //errorLog("transUnionHumanReadableReportToVector", "creditRptToVec", true);

    if (reportStr == null) return null;

    // remove line feeds and carriage returns from report string
    //
    reportStr = StringSupport.removeEmbeddedString( reportStr, "\r" );
    reportStr = StringSupport.removeEmbeddedString( reportStr, "\n" );

    String newRptStr = null;

    VectorX report      = new VectorX(); // for complete credit report with *
    VectorX humRdblRpt  = new VectorX(); // human readable report for node no *
    VectorX bothReports = new VectorX(); // container for both reports

    report.add("****TU-HRF***");

    StringBuffer sb = new StringBuffer(77);

    for (int i = 0, c = reportStr.length(); i < c; ++i)
    {
      sb.append(reportStr.charAt(i));

      if ((i + 1) % 77 == 0)
      {
        newRptStr = "*"+sb.toString();

        report.add( newRptStr );
        humRdblRpt.add( sb.toString() );

        sb = new StringBuffer(77);
      }
    }

    if( sb.length() > 0 )
    {
      newRptStr = "*"+sb.toString();

      report.add( newRptStr );
      humRdblRpt.add( sb.toString() );
    }

    bothReports.add( report );
    bothReports.add( humRdblRpt );

    return bothReports;
  }


  private static VectorX creditReportToVector(String reportStr, boolean insertSpaceInFront)
  {
    //general.errLog("START creditReportToVector", "CrdtRptToVec.log");

    if (reportStr == null) return null;

    //general.errLog("if( reportStr != null && ! reportStr.startsWith( BLANK ) ): "+( reportStr != null && ! reportStr.startsWith(" ") ), "CrdtRptToVec.log");
    //general.errLog("1 reportStr.length(): "+reportStr.length(), "CrdtRptToVec.log");

    // TransUnion reports will not map properly through the CBMapper with a leading space.
    // The boolean (insertSpaceInFront) was added to allow the method "transUnionReportToVectors"
    // to call this and not have the space inserted.  The space was causing an issue with SAFE CU's
    // NAOP application imports (where the app contains a TU report on import).
    //
    // This block of code was added sometime in v2011 but not exactly sure why.  It is not
    // compatible with the TU reports though.
    //
    if( insertSpaceInFront && reportStr != null && ! reportStr.startsWith(" ") )
    {
      reportStr = " "+reportStr;
    }

    //general.errLog("2 reportStr.length(): "+reportStr.length(), "CrdtRptToVec.log");

    String newRptStr = null;

    VectorX report = new VectorX();

    StringBuffer sb = new StringBuffer(80);

    for (int i = 0, c = reportStr.length(); i < c; ++i)
    {
      sb.append( reportStr.charAt(i) );

      if ( (i + 1) % 80 == 0 )
      {
        newRptStr = "*"+sb.toString();

        //errorLog("newRptStr: "+newRptStr, "creditRptToVec", true);
        //errorLog("newRptStr.length(): "+newRptStr.length(), "creditRptToVec", true);

        report.add(newRptStr);
        sb = new StringBuffer(80);
      }
    }

    if( sb.length() > 0 )
    {
      newRptStr = "*"+sb.toString();

      //errorLog("DONE newRptStr: "+newRptStr, "creditRptToVec", true);
      //errorLog("DONE newRptStr.length(): "+newRptStr.length(), "creditRptToVec", true);

      report.add(newRptStr);
    }

    //general.errLog("END reportVec: "+report, "CrdtRptToVec.log");
    return report;
  }
  

  public static VectorX creditReportToVector(String reportStr)
  {
    return creditReportToVector(reportStr, true);
  }

  /**
   * creates a node for a disbursement and adds it to the app node
   *
   * @param sdo SystemDataObject
   * @param appNode DataNode
   * @param disbData HashtableX
   */
  public static void setupDisbursementNode( SystemDataObject sdo, DataNode appNode, HashtableX disbData )
  {
  //errorLog("",AIU);errorLog("setupDisbursementNode(...)",AIU);errorLog("",AIU);
  //String type = (String)disbData.get("dsbTypD");
  //errorLog("",AIU);errorLog("1 type: "+type,AIU);errorLog("",AIU);
  //String translation = translateDisbursementType( type );
  //errorLog("",AIU);errorLog("2 translation: "+translation,AIU);errorLog("",AIU);
  //disbData.put("dsbType", translation);
  //errorLog("",AIU);errorLog("3 disbData: "+disbData,AIU);errorLog("",AIU);
  //DataNode  disbNode = sdo.createDataNode(getName(), NodeUtils.DISB_DN_TYPE);
  //disbNode.setFieldData(getName(), disbData);
  //appNode.addReference(disbNode);
  //errorLog("",AIU);errorLog("END setupDisbursementNode(...)",AIU);errorLog("",AIU);

  List disbNodesList = new ArrayList();
  disbNodesList.add(disbData);

  // setupDisbursementNode( sdo, appNode, disbData, CSFieldValues.EMPTY_STRING );
  //
  setupDisbursementNode( sdo, appNode, disbNodesList, CSFieldValues.EMPTY_STRING );

} // setupDisbursementNode(...)

  /**
   * creates a node for a disbursement and adds it to the app node
   *
   * @param sdo SystemDataObject
   * @param appNode DataNode
   * @param disbData HashtableX
   * @param username String
   */
  public static void setupDisbursementNode( SystemDataObject sdo, DataNode appNode,
                                            HashtableX disbData,  String username )
  {
  //errorLog("",AIU);errorLog("setupDisbursementNode(...)",AIU);errorLog("",AIU);

  String type = (String)disbData.get("dsbTypD");

  //errorLog("",AIU);errorLog("1 type: "+type,AIU);errorLog("",AIU);

  String translation = translateDisbursementType( type );

  //errorLog("",AIU);errorLog("2 translation: "+translation,AIU);errorLog("",AIU);

  disbData.put("dsbType", translation);

  //errorLog("",AIU);errorLog("3 disbData: "+disbData,AIU);errorLog("",AIU);

  DataNode  disbNode = sdo.createDataNode(username==null||username.trim().length()==0 ? getName():username, NodeUtils.DISB_DN_TYPE);
  disbNode.setFieldData(username==null||username.trim().length()==0 ? getName():username, disbData);
  appNode.addReference(disbNode);

  //errorLog("",AIU);errorLog("END setupDisbursementNode(...)",AIU);errorLog("",AIU);
  } // setupDisbursementNode(...)


  /**
   * processes multiple disbursements. creates a node for each disbursement and adds the
   * disbursement nodes to the application node
   *
   * total disbursements, loan and non-loan 6-15-07
   *
   * @param sdo SystemDataObject
   * @param appNode DataNode
   * @param disbNodesList List
   */
  public static void setupDisbursementNode( SystemDataObject sdo, DataNode appNode,
                                             List disbNodesList, String username )
  {
   //errorLog("setupDisbursementNode(...)",AIU);

    if( disbNodesList != null && ! disbNodesList.isEmpty() )
    {
      double disbTtl = 0.0;
      double nonLoanDisbTtl = 0.0;
      double unsecDisbTtl = 0.0;

      // get the disb node data hash
      //
      for( int i=0, c=disbNodesList.size(); i<c; i++ )
      {
        Object obj = disbNodesList.get(i);

       //errorLog("obj: "+obj,AIU);
       //errorLog("CLASS obj: "+obj.getClass(),AIU);

        HashtableX disbData = null;

        if( obj instanceof String )
        {
          disbData = StringChanger.stringToHashtableX( disbNodesList.get(i).toString() );
        }
        else if( obj instanceof HashtableX )
        {
          disbData = (HashtableX)disbNodesList.get(i);
        }

        if( disbData != null && ! disbData.isEmpty() )
        {
          // String type = (String)disbData.get("dsbTypD");
          //
          String type = (String)disbData.get(CSFieldNames.FN_DSB_TYPE_DDL);

         //errorLog("1 type: "+type,AIU);

          String translation = translateDisbursementType( type );

         //errorLog("2 translation: "+translation,AIU);

          disbData.put("dsbType", translation);

         //errorLog("3 disbData: "+disbData,AIU);

          String amount = (String)disbData.get(CSFieldNames.FN_DSB_AMT);
          disbTtl += StringSupport.strToDouble( amount );

          // public static final String FV_DSB_NONLOAN = "0";
          //
          if (type != null && type.trim().equals(CSFieldValues.FV_DSB_NONLOAN))
          {
            nonLoanDisbTtl += StringSupport.strToDouble( amount );
          }

          if (type != null && type.trim().equals(CSFieldValues.FV_DSB_TYPE_UNSEC_BWR))
          {
            unsecDisbTtl += StringSupport.strToDouble( amount );
          }

          DataNode  disbNode = sdo.createDataNode(username, NodeUtils.DISB_DN_TYPE);
          disbNode.setFieldData(username, disbData);
          appNode.addReference(disbNode);
        }
      } // for( int i=0, c=disbNodesList.size(); i<c; i++ )

      //  collDN.setFieldData(CSFieldValues.EMPTY_STRING, CSFieldNames.FN_LIEN_TOTAL_AMT, String.valueOf( lnTtl ));
      //
      appNode.setFieldData( username, CSFieldNames.FN_DSB_TTL, String.valueOf( disbTtl ) );
      appNode.setFieldData( username, CSFieldNames.FN_DSB_NON_LOAN, String.valueOf( nonLoanDisbTtl ) );
      appNode.setFieldData( username, CSFieldNames.FN_DSB_UNSEC, String.valueOf( unsecDisbTtl ));
    }

   //errorLog("END setupDisbursementNode(...)",AIU);
  } // setupDisbursementNode(...)


  public static boolean isValidSSN( String str )
  {
    boolean isValid = false;

    int cnt = 0;

    // pull out the digits and put them into number[]
    //
    for (int i=0, c=str.length(); i < c; i++)
    {
        if (Character.isDigit(str.charAt(i)))
        {
            cnt++;
        }
    }

    if (cnt == 9)
    {
      isValid = true;
    }

    return isValid;
  }


  public static boolean isValidZip( String str )
  {
    boolean isValid = false;

    int cnt = 0;

    if( str != null && str.trim().length() == 5 )
    {
      // pull out the digits and put them into number[]
      //
      for (int i=0, c=str.length(); i < c; i++)
      {
          if (Character.isDigit(str.charAt(i)))
          {
              cnt++;
          }
      }
    }

    if ( cnt == 5)
    {
      isValid = true;
    }

    return isValid;
  }


  public static boolean isValidZipPlusFour( String str )
  {
    boolean isValid = false;

    int cnt = 0;

    if( str != null && str.trim().length() == 4 )
    {
      // pull out the digits and put them into number[]
      //
      for (int i=0, c=str.length(); i < c; i++)
      {
          if (Character.isDigit(str.charAt(i)))
          {
              cnt++;
          }
      }
    }

    if ( cnt == 4)
    {
      isValid = true;
    }

    return isValid;
  }


  /**
   * A method that given a string, returns the value in pennies.
   *
   * AppImportUtils.toPennies("12.50"); = 1250
   *
   * @param str String
   * @return String
   */
  public static String toPennies(String str)
  {
    double d = StringSupport.strToDouble(str);

    return String.valueOf((int)(d * 100.0));
  }


  /**
  *   A method that given a string, rounds the amount to the nearest dollar.
  *   If the str is not a valid double, the string returned will be 0
  *
  *   AppImportUtils.toDollars(1239.98000001); = 1240
  *
  *   @param   str  the string amount
  *   @return  the string amount in dollars
  */
  public static String toDollars(String str)
  {
    double d = StringSupport.strToDouble(str);

    return String.valueOf((int)FinCalcs.round(d, 0));
  }

  /**
   * Creates a single address line
   *
   * @param data HashtableX
   * @return String
   */
  public static String createAddressLine( HashtableX data )
  {
    StringBuffer addressLine = new StringBuffer();

    String str = (String)data.get("atStrNum");
    //if (str != null ) addressLine.append( str );
    addressLine.append( str != null && str.length() > 0  ? str : CSFieldValues.EMPTY_STRING );

    str = (String)data.get("atStrPreDirD");
    addressLine.append( str != null && str.length() > 0 ? " "+str : CSFieldValues.EMPTY_STRING );

    str = (String)data.get("atStrName");
    addressLine.append( str != null && str.length() > 0  ? " "+str : CSFieldValues.EMPTY_STRING );

    str = (String)data.get("atStrPostDirD");
    addressLine.append( str != null && str.length() > 0  ? " "+str : CSFieldValues.EMPTY_STRING );

    str = (String)data.get("atStrSuffixD");
    addressLine.append( str != null && str.length() > 0  ? " "+str : CSFieldValues.EMPTY_STRING );

    str = (String)data.get("atSecAddrTypeD");
    addressLine.append( str != null && str.length() > 0  ? " "+str : CSFieldValues.EMPTY_STRING );

    str = (String)data.get("atSecAddrRge");
    addressLine.append( str != null && str.length() > 0  ? " "+str : CSFieldValues.EMPTY_STRING );

    if( addressLine == null ) addressLine = new StringBuffer();

    return addressLine.toString().trim();

  } //   public static String createAddressLine( HashtableX data )


  /**
   * Creates a single address line for previous address
   *
   * @param data HashtableX
   * @return String
   */
  public static String createPreviousAddressLine( HashtableX data )
  {
    StringBuffer addressLine = new StringBuffer();

    String str = (String)data.get("atPrvStrNum");
    if (str != null ) addressLine.append( str );
    addressLine.append( str != null && str.length() > 0  ? str : CSFieldValues.EMPTY_STRING );

    str = (String)data.get("atPrvStrPreDirD");
    addressLine.append( str != null && str.length() > 0 ? " "+str : CSFieldValues.EMPTY_STRING );

    str = (String)data.get("atPrvStrName");
    addressLine.append( str != null && str.length() > 0  ? " "+str : CSFieldValues.EMPTY_STRING );

    str = (String)data.get("atPrvStrPostDirD");
    addressLine.append( str != null && str.length() > 0  ? " "+str : CSFieldValues.EMPTY_STRING );

    str = (String)data.get("atPrvStrSuffixD");
    addressLine.append( str != null && str.length() > 0  ? " "+str : CSFieldValues.EMPTY_STRING );

    str = (String)data.get("atPrvSecAddrTypeD");
    addressLine.append( str != null && str.length() > 0  ? " "+str : CSFieldValues.EMPTY_STRING );

    str = (String)data.get("atPrvSecAddrRge");
    addressLine.append( str != null && str.length() > 0  ? " "+str : CSFieldValues.EMPTY_STRING );

    if( addressLine == null ) addressLine = new StringBuffer();

    return addressLine.toString().trim();

  } // public static String createPreviousAddressLine( HashtableX data )

  /**
   * Creates a vector of the borrowers dependents from the existing vector of vectors
   *
   * @param depVec VectorX
   * @return VectorX
   */
  public static VectorX createOneDependentVec( VectorX depVec )
  {
    VectorX newVec = new VectorX();

    if( depVec != null && ! depVec.isEmpty() && depVec.size() == 2 )
    {
      for( int i=0; i<2; i++ )
      {
        VectorX vecOfVec = (VectorX)depVec.get(i);

        for( int j=0,k=vecOfVec.size(); j<k; j++)
        {
          String age = (String)vecOfVec.get(j);

          if( age != null && age.trim().length() > 0 )
          {
            try
            {
              Integer.parseInt( age );
            }
            catch( Exception e)
            {
              continue;
            }

            newVec.add( age.trim() );
          }
        } // for( int j=0,k=vecOfVec.size(); j<k; j++)
      }
    } // if( depVec != null && ! depVec.isEmpty() && depVec.size() == 2 )

    return newVec;

  } // public static VectorX createOneDependentVec( VectorX depVec )

  /**
   * Returns the sdo's last borrower's node index
   *
   * @param sdo SystemDataObject
   * @return int
   */
  public static int getLastBwrNodeIndexFromSDO( SystemDataObject sdo )
  {
    int bwrIndex = -1;

    if( sdo != null )
    {
      DataNode appDN = sdo.getNodeData( NodeUtils.APP_DN_TYPE );

      List bwrList = appDN.getEffectiveReferences( NodeUtils.BWR_DN_TYPE );

      for( int i=0,c=bwrList.size(); i<c; i++ )
      {
        DataNode bwrDN = (DataNode)bwrList.get(i);
        bwrIndex = bwrDN.getIndex();
      }
    }

    return bwrIndex;
  } // public static DataNode getPrimaryBwrNodeFromSDO( SystemDataObject sdo )

  /**
   * Returns the primary borrower node.
   *
   * @param sdo SystemDataObject
   * @return DataNode
   */
  public static DataNode getPrimaryBwrNodeFromSDO( SystemDataObject sdo )
  {
    DataNode bwrDN = null;

    if( sdo != null )
    {
      DataNode appDN = sdo.getNodeData( NodeUtils.APP_DN_TYPE );
      bwrDN = appDN.getReference( NodeUtils.BWR_DN_TYPE, 0 );
    }

    return bwrDN;
  } // public static DataNode getPrimaryBwrNodeFromSDO( SystemDataObject sdo )


  /**
   * Return borrowers full name in a single string.
   *
   * @param sdo SystemDataObject
   * @return DataNode
   */
  public static String getPrimaryBwrNameFromSDO( SystemDataObject sdo )
  {
    String name = null;
    DataNode bwrDN = null;

    if( sdo != null )
    {
      DataNode appDN = sdo.getNodeData( NodeUtils.APP_DN_TYPE );
      bwrDN = appDN.getReference( NodeUtils.BWR_DN_TYPE, 0 );
      name = DataEntrySupport.getBorrowerName(bwrDN);
    }

    return name;
  } // public static DataNode getPrimaryBwrNodeFromSDO( SystemDataObject sdo )


  /**
   * Returns the product name in a formatted string.
   *
   * @param sdo SystemDataObject
   * @return String
   */
  public static  String getProductNameFromSDO( SystemDataObject sdo )
      {
      // The format for a product name is as such:
      // <product type> - <loan type> - <free form name> (id)
      // Example: RV - Credit Card - Gold (16)
      //
      String prodName = null;
      DataNode bwrDN = null;

      if( sdo != null )
      {
        DataNode appDN = sdo.getNodeData( NodeUtils.APP_DN_TYPE );
        String prodID = (String)appDN.getFieldData(CSFieldValues.EMPTY_STRING, "anProdTypeD");
        prodName = CSDataCache.getProductManager().getProduct(prodID).getName() +" ("+prodID+")";
      }
      return prodName;
      } // extractProductTypeFromProductName


  /** set drivers license fields for the borrower data map prior to be added to the
   *  borrower node
   *
   * @param bwrData Map
   */
  public static void updateDriversLicenseData( Map bwrData ) throws Exception
  {
    if( bwrData.containsKey(CSFieldNames.FN_ID_TYPE) )
        {
        String idType = (String)bwrData.get(CSFieldNames.FN_ID_TYPE);
        if( idType != null && (idType.equals(US_DR_LIC) || idType.equals("1")) )
            {
            String idNum  = (String)bwrData.get(CSFieldNames.FN_ID_NUM);
            String licSt  = (String)bwrData.get(CSFieldNames.FN_DRVR_LIC_ST);

            if ( idType != null && (idType.equals(US_DR_LIC) || idType.equals("1")) )
                {
                // copy atIdNum to atLicNum, and atLicStD to atIdIssByD.
                //
                if ( idNum != null )
                    {
                    bwrData.put(CSFieldNames.FN_DRVR_LIC_NUM, idNum);
                    }
                if ( licSt != null )
                    {
                    bwrData.put(CSFieldNames.FN_ID_ISSUED_BY, licSt);
                    }
                }
            }
        }

    if( bwrData.containsKey("atIdTyp2D") )
        {
        String idType2 = (String)bwrData.get("atIdTyp2D");
        if( idType2 != null && (idType2.equals(US_DR_LIC) || idType2.equals("1")) )
            {
            String idNum2  = (String)bwrData.get("atIdNum2");
            String licSt2  = (String)bwrData.get("atLicSt2D");

            if( idType2 != null && (idType2.equals(US_DR_LIC) || idType2.equals("1")) )
                {
                // copy atIdNum to atLicNum, and atLicStD to atIdIssByD.
                //
                if ( idNum2 != null )
                    {
                    bwrData.put("atLicNum2", idNum2);
                    }
                if ( licSt2 != null )
                    {
                    bwrData.put("atIdIssBy2D", licSt2);
                    }
                }
            }
        }

  } // public void updateDriversLicenseData( Map bwrData)

  /**
   * checks a list for processing
   *
   * @param list List
   * @return boolean
   */
  public static boolean isValidList( List list )
  {
    boolean valid = false;

    if( list != null && ! list.isEmpty() )
    {
      valid = true;
    }

    return valid;
  }


  /**
   * checks a list for processing
   *
   * @param list List
   * @return boolean
   */
  public static boolean isValidVectorX( VectorX list )
  {
    boolean valid = false;

    if( list != null && ! list.isEmpty() )
    {
      valid = true;
    }

    return valid;
  }


  /**
   * Checks a table, list, set etc... to see if contains an element and is not null
   *
   * @param list Collection
   * @return boolean
   */
  public static boolean isValidTable( HashtableX table )
  {
    boolean valid = false;

    if( table != null && ! table.isEmpty() )
    {
      valid = true;
    }

    return valid;
  }

  /**
   * checks a string for processing
   *
   * @param string String
   * @return boolean
   */
  public static boolean isValidString( String string )
  {
    boolean valid = false;

    if( string != null && string.trim().length() > 0  )
    {
      valid = true;
    }

    return valid;
  }


  // translate yes or no value to true or false for credisphere check boxes
  //
  public static String translateYesNo(String str)
  {
  //debugMsg("1 translateYesNo(String str): "+str);

      if(str != null && str.trim().length() > 0 )
          {
          str = str.trim();

          //debugMsg("2 translateYesNo(String str): "+str);

          if ( str.toUpperCase().equals("YES") )
              {
              str = "true";
              }
          else if( str.toUpperCase().equals("NO") )
              {
              str = "false";
              }
          }
      else
          {
            str = "false";
          }

      //debugMsg("3 translateYesNo(String str): "+str);
      return str;
  }


  private static VectorX getNodeBwrIndexes (Element node)
  {

      // get bwr index and net wrth multi select list box
      //
      // application:Asset.0:Retirement Funds.0:!bwrIndex = 0 1
      // application:Asset.0:Retirement Funds.0:_NtWrthBwrM = 0 1
      //
      // - <BwrIndexList>
      //        <BwrIndex>0</BwrIndex>
      //   </BwrIndexList>
      // - <BwrIndexList>
      //        <BwrIndex>1</BwrIndex>
      //   </BwrIndexList>
      //
      /*
               - <BwrIndexList>
                          <BwrIndex>0</BwrIndex>
                          <BwrIndex>1</BwrIndex>
               </BwrIndexList>
        */
    VectorX bwrIndxVec = new VectorX();

    Element bwrIndxElement = node.getChild("BwrIndexList");
    if( bwrIndxElement != null )
    {
     List bwrIndxList = bwrIndxElement.getChildren("BwrIndex");

     for( int f=0, g=bwrIndxList.size(); f<g; f++ )
     {
       Element bwrIndx = (Element)bwrIndxList.get(f);

       if( bwrIndx != null )
       {
         String indx = bwrIndx.getText();
         if (indx != null) bwrIndxVec.add( indx );
       }
     }
    }

    if (bwrIndxVec.isEmpty())
    {
     // set primary borrower as defaul
     //
     bwrIndxVec.add( "0" );
    }

    return bwrIndxVec;
  }


  /*
    <CashSavingsCDs>
            <Type>Cash</Type>
            <AccountNumber>112233</AccountNumber>
            <Amount>1000.00</Amount>
            <Name>Banc One</Name>
            <Address>Banc One Plaza</Address>
            <AddressLineTwo>Attn: Loan Dept.</AddressLineTwo>
            <City>New York</City>
            <State>NY</State>
            <Zip>14555</Zip>
            <ZipPlus>4555</ZipPlus>
    </CashSavingsCDs>

  */
  public static void processCashAsset( List assetList, List assets )
  {
    for( int i=0, c=assets.size(); i<c; i++ )
    {
      Element asset = (Element)assets.get(i);

      if( asset != null )
      {
        String astAction  = (String)asset.getChildText("Action");
        String astSubNodeIndex  = (String)asset.getChildText("SubNodeIndex");

        String astTypD    = (String)asset.getChildText("Type");
        String astAcctNum = (String)asset.getChildText("AccountNumber");
        String astVal     = (String)asset.getChildText("Amount");
        String astName    = (String)asset.getChildText("Name");
        String astAddr    = (String)asset.getChildText("Address");
        String astAddrTwo = (String)asset.getChildText("AddressLineTwo");
        String astCity    = (String)asset.getChildText("City");
        String astStD     = (String)asset.getChildText("State");
        String astZip     = (String)asset.getChildText("Zip");
        String astZipPlus = (String)asset.getChildText("ZipPlus");

        HashMap assetHash = new HashMap();
        assetHash.put("astAction", astAction != null && astAction.trim().length() > 0 ? astAction : "EDIT" );
        assetHash.put("astSubNodeIndex", astSubNodeIndex != null && astSubNodeIndex.trim().length() > 0 ? astSubNodeIndex : CSFieldValues.EMPTY_STRING );

        assetHash.put("_NtWrthTypD",    "Asset"  );
        assetHash.put("_NtWrthSubTypD", "AstCash");
        assetHash.put("astTypD",    isValidString(astTypD)    ? astTypD    : CSFieldValues.EMPTY_STRING );
        assetHash.put("astAcctNum", isValidString(astAcctNum) ? astAcctNum : CSFieldValues.EMPTY_STRING );
        assetHash.put("astVal",     isValidString(astVal)     ? astVal     : CSFieldValues.EMPTY_STRING );
        assetHash.put("astName",    isValidString(astName)    ? astName    : CSFieldValues.EMPTY_STRING );
        assetHash.put("astAddr",    isValidString(astAddr)    ? astAddr    : CSFieldValues.EMPTY_STRING );
        assetHash.put("astAddrTwo", isValidString(astAddrTwo) ? astAddrTwo : CSFieldValues.EMPTY_STRING );
        assetHash.put("astCity",    isValidString(astCity)    ? astCity    : CSFieldValues.EMPTY_STRING );
        assetHash.put("astStD",     isValidString(astStD)     ? astStD     : CSFieldValues.EMPTY_STRING );
        assetHash.put("astZip",     isValidString(astZip)     ? astZip     : CSFieldValues.EMPTY_STRING );
        assetHash.put("astZipPlus", isValidString(astZipPlus) ? astZipPlus : CSFieldValues.EMPTY_STRING );

        assetHash.put( "_NtWrthBwrM", getNodeBwrIndexes(asset) );

        // add hash to the list
        //
        assetList.add( assetHash );

      } // if( asset != null )

    } // for( int i=0, c=cashAssets.size(); i<c; i++ )

  } // public static void processCashAsset( List assetList, List cashAssets )

/*
         <StocksBonds>
                 <SecurityName>US Savings Bond</SecurityName>
                 <WhereTraded>NASDAQ</WhereTraded>
                 <RegisteredInNameOf>Eve A Amacommon</RegisteredInNameOf>
                 <Pledged>No</Pledged>
                 <NumberOfShares>1</NumberOfShares>
                 <MarketValueShare>10000.00</MarketValue>
                 <TotalValueShare>10000.00</TotalValue>
         </StocksBonds>

*/
  public static void processStockBondAsset( List assetList, List assets )
  {
    for( int i=0, c=assets.size(); i<c; i++ )
    {
      Element asset = (Element)assets.get(i);

      if( asset != null )
      {
        String astAction  = (String)asset.getChildText("Action");
        String astSubNodeIndex  = (String)asset.getChildText("SubNodeIndex");

        String astName   = (String)asset.getChildText("SecurityName");

        if( astName == null || astName.trim().length() == 0 )
        {
          astName = (String)asset.getChildText("Name");
        }

        String astLoc    = (String)asset.getChildText("WhereTraded");
        String astOnr    = (String)asset.getChildText("RegisteredInNameOf");
        String astPlgD   = (String)asset.getChildText("Pledged");
        String astNum    = (String)asset.getChildText("NumberOfShares");
        String astValPer = (String)asset.getChildText("MarketValueShare");
        String astVal    = (String)asset.getChildText("TotalValue");
        String astTypD   = (String)asset.getChildText("Type");

        HashMap assetHash = new HashMap();
        assetHash.put("astAction", astAction != null && astAction.trim().length() > 0 ? astAction : "EDIT" );
        assetHash.put("astSubNodeIndex", astSubNodeIndex != null && astSubNodeIndex.trim().length() > 0 ? astSubNodeIndex : CSFieldValues.EMPTY_STRING );

        assetHash.put("_NtWrthTypD",    "Asset"  );
        assetHash.put("_NtWrthSubTypD", "AstStkBd");
        assetHash.put("astName",   isValidString(astName)   ? astName   : CSFieldValues.EMPTY_STRING );
        assetHash.put("astLoc",    isValidString(astLoc)    ? astLoc    : CSFieldValues.EMPTY_STRING );
        assetHash.put("astOnr",    isValidString(astOnr)    ? astOnr    : CSFieldValues.EMPTY_STRING );
        assetHash.put("astPlgD",   isValidString(astPlgD)   ? translateYesNo(astPlgD) : CSFieldValues.EMPTY_STRING );
        assetHash.put("astNum",    isValidString(astNum)    ? astNum    : CSFieldValues.EMPTY_STRING );
        assetHash.put("astValPer", isValidString(astValPer) ? astValPer : CSFieldValues.EMPTY_STRING );
        assetHash.put("astVal",    isValidString(astVal)    ? astVal    : CSFieldValues.EMPTY_STRING );
        assetHash.put("astTypD",   isValidString(astTypD)   ? astTypD   : CSFieldValues.EMPTY_STRING );

        assetHash.put( "_NtWrthBwrM", getNodeBwrIndexes(asset) );

        // add hash to the list
        //
        assetList.add( assetHash );

      } // if( asset != null )

    } // for( int i=0, c=cashAssets.size(); i<c; i++ )

  } // public static void processStockBondAsset( List assetList, List cashAssets )

  /*
       <NotesReceivable>
               <Maker>Bob Jones</Maker>
               <Description>Personal Loan</Description>
               <MaturityDate>05/05/2006</MaturityDate>
               <Pledged>Yes</Pledged>
               <OriginalAmount>10000.00</OriginalAmount>
               <MonthlyPayment>100.00</MonthlyPayment>
               <CurrentBalance>1000.00</CurrentBalance>
       </NotesReceivable>
  */
  public static void processNotesReceivableAsset( List assetList, List assets )
  {
    for( int i=0, c=assets.size(); i<c; i++ )
    {
      Element asset = (Element)assets.get(i);

      if( asset != null )
      {
        String astAction  = (String)asset.getChildText("Action");
        String astSubNodeIndex  = (String)asset.getChildText("SubNodeIndex");

        String astName = (String)asset.getChildText("Maker");
        String astDesc = (String)asset.getChildText("Description");
        String astDt   = (String)asset.getChildText("MaturityDate");
        String astPlgD = (String)asset.getChildText("Pledged");
        String astAmt  = (String)asset.getChildText("OriginalAmount");
        String astPmt  = (String)asset.getChildText("MonthlyPayment");
        String astVal  = (String)asset.getChildText("CurrentBalance");

        HashMap assetHash = new HashMap();
        assetHash.put("astAction", astAction != null && astAction.trim().length() > 0 ? astAction : "EDIT" );
        assetHash.put("astSubNodeIndex", astSubNodeIndex != null && astSubNodeIndex.trim().length() > 0 ? astSubNodeIndex : CSFieldValues.EMPTY_STRING );

        assetHash.put("_NtWrthTypD",    "Asset"  );
        assetHash.put("_NtWrthSubTypD", "AstNtRcv");
        assetHash.put("astName", isValidString(astName)  ? astName : CSFieldValues.EMPTY_STRING );
        assetHash.put("astDesc", isValidString(astDesc)  ? astDesc : CSFieldValues.EMPTY_STRING );
        assetHash.put("astDt",   isValidString(astDt)    ? astDt   : CSFieldValues.EMPTY_STRING );
        assetHash.put("astPlgD", isValidString(astPlgD)  ? translateYesNo(astPlgD) : CSFieldValues.EMPTY_STRING );
        assetHash.put("astAmt",  isValidString(astAmt)   ? astAmt : CSFieldValues.EMPTY_STRING );
        assetHash.put("astPmt",  isValidString(astPmt)   ? astPmt : CSFieldValues.EMPTY_STRING );
        assetHash.put("astVal",  isValidString(astVal)   ? astVal : CSFieldValues.EMPTY_STRING );


        assetHash.put( "_NtWrthBwrM", getNodeBwrIndexes(asset) );

        // add hash to the list
        //
        assetList.add( assetHash );

      } // if( asset != null )

    } // for( int i=0, c=cashAssets.size(); i<c; i++ )

  } // public static void processNotesReceivableAsset( List assetList, List cashAssets )

  /*
     <LifeInsurance>
             <Company>State Farm</Company>
             <PolicyNumber>1243123</PolicyNumber>
             <Beneficiary>Paul Amacommon</Beneficiary>
             <Pledged>No</Pledged>
             <FaceAmount>1000000.00</FaceAmount>
             <LoanAmount>0.00</LoanAmount>
             <CashValue>25000.00</CashValue>
     </LifeInsurance>
  */
  public static void processLifeInsuranceAsset( List assetList, List assets )
  {
    for( int i=0, c=assets.size(); i<c; i++ )
    {
      Element asset = (Element)assets.get(i);

      if( asset != null )
      {
        String astAction  = (String)asset.getChildText("Action");
        String astSubNodeIndex  = (String)asset.getChildText("SubNodeIndex");

        String astName = (String)asset.getChildText("Company");
        String astDesc = (String)asset.getChildText("PolicyNumber");
        String astOnr  = (String)asset.getChildText("Beneficiary");
        String astPlgD = (String)asset.getChildText("Pledged");
        String astAmt  = (String)asset.getChildText("FaceAmount");
        String astLn   = (String)asset.getChildText("LoanAmount");
        String astVal  = (String)asset.getChildText("CashValue");

        HashMap assetHash = new HashMap();
        assetHash.put("astAction", astAction != null && astAction.trim().length() > 0 ? astAction : "EDIT" );
        assetHash.put("astSubNodeIndex", astSubNodeIndex != null && astSubNodeIndex.trim().length() > 0 ? astSubNodeIndex : CSFieldValues.EMPTY_STRING );

        assetHash.put("_NtWrthTypD",    "Asset"  );
        assetHash.put("_NtWrthSubTypD", "AstLI");
        assetHash.put("astName",   isValidString(astName)   ? astName : CSFieldValues.EMPTY_STRING );
        assetHash.put("astDesc",   isValidString(astDesc)   ? astDesc : CSFieldValues.EMPTY_STRING );
        assetHash.put("astOnr",    isValidString(astOnr)    ? astOnr  : CSFieldValues.EMPTY_STRING );
        assetHash.put("astPlgD",   isValidString(astPlgD)   ? translateYesNo(astPlgD) : CSFieldValues.EMPTY_STRING );
        assetHash.put("astAmt",    isValidString(astAmt)    ? astAmt : CSFieldValues.EMPTY_STRING );

        // assetHash.put("astLn",     isValidString(astLn)     ? astLn  : CSFieldValues.EMPTY_STRING );
        //
        assetHash.put("astLn",     isValidString(astLn)     ? astLn  : "0.00" );
        assetHash.put("astVal",    isValidString(astVal)    ? astVal : CSFieldValues.EMPTY_STRING );

        assetHash.put( "_NtWrthBwrM", getNodeBwrIndexes(asset) );

        // add hash to the list
        //
        assetList.add( assetHash );

      } // if( asset != null )

    } // for( int i=0, c=cashAssets.size(); i<c; i++ )

  } // public static void processLifeInsuranceAsset( List assetList, List cashAssets )


  /*
       <Vehicles>
               <Make>Ford</Make>
               <Model>Mustang</Model>
               <Year>2004</Year>
               <Value>13000.00</Value>
       </Vehicles>

  */
  public static void processVehiclesAsset( List assetList, List assets )
  {
    for( int i=0, c=assets.size(); i<c; i++ )
    {
      Element asset = (Element)assets.get(i);

      if( asset != null )
      {
        String astAction  = (String)asset.getChildText("Action");
        String astSubNodeIndex  = (String)asset.getChildText("SubNodeIndex");

        String astName = (String)asset.getChildText("Make");
        String astDesc = (String)asset.getChildText("Model");
        String astYr   = (String)asset.getChildText("Year");
        String astVal  = (String)asset.getChildText("Value");

        HashMap assetHash = new HashMap();
        assetHash.put("astAction", astAction != null && astAction.trim().length() > 0 ? astAction : "EDIT" );
        assetHash.put("astSubNodeIndex", astSubNodeIndex != null && astSubNodeIndex.trim().length() > 0 ? astSubNodeIndex : CSFieldValues.EMPTY_STRING );

        assetHash.put("_NtWrthTypD",    "Asset"  );
        assetHash.put("_NtWrthSubTypD", "AstVh");
        assetHash.put("astName",   isValidString(astName) ? astName : CSFieldValues.EMPTY_STRING );
        assetHash.put("astDesc",   isValidString(astDesc) ? astDesc : CSFieldValues.EMPTY_STRING );
        assetHash.put("astYr",     isValidString(astYr)   ? astYr   : CSFieldValues.EMPTY_STRING );
        assetHash.put("astVal",    isValidString(astVal)  ? astVal  : CSFieldValues.EMPTY_STRING );

        assetHash.put( "_NtWrthBwrM", getNodeBwrIndexes(asset) );

        // add hash to the list
        //
        assetList.add( assetHash );

      } // if( asset != null )

    } // for( int i=0, c=cashAssets.size(); i<c; i++ )

  } // public static void processVehiclesAsset( List assetList, List cashAssets )

  /*
           <RealEstateProperties>
                   <DescriptionAndLocation>Rental Property</DescriptionAndLocation>
                   <TitleName>Eve A Amacommon</TitleName>
                   <LienHolder>None</LienHolder>
                   <MonthlyIncome>1000.00</MonthlyIncome>
                   <CurrentBalance>20000.00</CurrentBalance>
                   <PresentValue>100000.00</PresentValue>
           </RealEstateProperties>

  */
  public static void processRealEstateAsset( List assetList, List assets )
  {
    for( int i=0, c=assets.size(); i<c; i++ )
    {
      Element asset = (Element)assets.get(i);

/*
         - <RealEstateProperties>
        <PropertyStatus>Sold</PropertyStatus>
        <PropertyType>Single Family</PropertyType>
        <Action>ADD</Action>
        <SubNodeIndex />
        <Address>123 test</Address>
        <AddressLineTwo />
        <City>rochester</City>
        <State>NY</State>
        <Zip>14580</Zip>
        <County>OTHER</County>
        <PresentValue>130000</PresentValue>
        <AnnualGrossRentalIncome />
        <MortgageLienAmount />
        <InsMaintTaxes>0.00</InsMaintTaxes>
        <MonthlyPayments />
        </RealEstateProperties>

 New tag: If <TaxAndInsEntered /> present calculate school and property taxes
 and hazard insurance.

*/
      if( asset != null )
      {
        String astAction  = (String)asset.getChildText("Action");
        String astSubNodeIndex  = (String)asset.getChildText("SubNodeIndex");

        String astDesc = (String)asset.getChildText("DescriptionAndLocation");
        String astOnr  = (String)asset.getChildText("TitleName");
        String astLien = (String)asset.getChildText("LienHolder");

        String astPmt  = (String)asset.getChildText("MonthlyPayments");
        if( astPmt == null || astPmt.trim().length() == 0 )
        {
          astPmt = (String) asset.getChildText("MonthlyIncome");
        }

        String astLn   = (String)asset.getChildText("MortgageLienAmount");

        //  <PresentValue>300000</PresentValue>
        //
        String astVal  = (String)asset.getChildText("PresentValue");

        // mtg fields
        String astStatD    = (String)asset.getChildText("PropertyStatus");
        String astTypD     = (String)asset.getChildText("PropertyType");
        String astAddr     = (String)asset.getChildText("Address");
        String astAddrTwo  = (String)asset.getChildText("AddressLineTwo");
        String astCity     = (String)asset.getChildText("City");
        String astStD      = (String)asset.getChildText("State");
        String astZip      = (String)asset.getChildText("Zip");
        String astZipPlus  = (String)asset.getChildText("ZipPlus");
        String astCntyD    = (String)asset.getChildText("County");
        String astGrInc    = (String)asset.getChildText("AnnualGrossRentalIncome");
        String astTax      = (String)asset.getChildText("InsMaintTaxes");

        String astCurrResC = (String)asset.getChildText("CurrentResidence");
        String astSubPropC = (String)asset.getChildText("SubjectProperty");

        /*
           <MortgageIns>0.00</MortgageIns>
           <HazardIns>83.33</HazardIns>
           <SchoolTax>166.67</SchoolTax>
           <PropertyTax>250.00</PropertyTax>
           <HOADues>83.25</HOADues>
        */
        String astMtgIns = (String)asset.getChildText("MortgageIns");
        String astIns = (String)asset.getChildText("HazardIns");
        String astSchTax = (String)asset.getChildText("SchoolTax");
        String astPropTax = (String)asset.getChildText("PropertyTax");
        String astHOA = (String)asset.getChildText("HOADues");

        double insTaxTtl = 0.0;

        //  <TaxAndInsEntered>No</TaxAndInsEntered>
        //
        String calcTaxAndIns  = (String)asset.getChildText("TaxAndInsEntered");


        if( calcTaxAndIns != null && calcTaxAndIns.trim().toLowerCase().equals("no") &&
            astVal != null && astVal.trim().length() > 0 )
        {
          try
          {
            double propValue = StringSupport.strToDouble( astVal );

            if( propValue > 0 )
            {
              double schlTax = MGCalcEstimator.getSchoolTaxesMonthlyCharge(propValue, astStD, astCntyD);
              astSchTax =  String.valueOf(schlTax);
              insTaxTtl += schlTax;

              double propTax = MGCalcEstimator.getPropertyTaxesMonthlyCharge(propValue, astStD, astCntyD);              
              astPropTax = String.valueOf(propTax);
              insTaxTtl += propTax;

              double hzrdIns = MGCalcEstimator.getHazardInsuranceMonthlyCharge(propValue, astStD, astCntyD);
              astIns = String.valueOf(hzrdIns);
              insTaxTtl += hzrdIns;
              
            }
          }
          catch( Exception d )
          {
            d.printStackTrace();
          }
        }

        HashMap assetHash = new HashMap();
        assetHash.put("astAction", astAction != null && astAction.trim().length() > 0 ? astAction : "EDIT" );
        assetHash.put("astSubNodeIndex", astSubNodeIndex != null && astSubNodeIndex.trim().length() > 0 ? astSubNodeIndex : CSFieldValues.EMPTY_STRING );

        assetHash.put("_NtWrthTypD",    "Asset"  );
        assetHash.put("_NtWrthSubTypD", "AstRE");

        if(isValidString(astDesc))
          assetHash.put("astDesc", astDesc);
        if(isValidString(astOnr))
          assetHash.put("astOnr", astOnr);
        if(isValidString(astLien))
          assetHash.put("astLien", astLien);
        if(isValidString(astPmt))
          assetHash.put("astPmt", astPmt);

        if(isValidString(astLn))
          assetHash.put("astLn", astLn);
        else
          assetHash.put("astLn", "0.00");

        if(isValidString(astVal))
          assetHash.put("astVal", astVal);

        // mtg fields
        if(isValidString(astStatD))
          assetHash.put("astStatD", astStatD);
        if(isValidString(astTypD))
          assetHash.put("astTypD", astTypD);
        if(isValidString(astAddr))
          assetHash.put("astAddr", astAddr);
        if(isValidString(astAddrTwo))
          assetHash.put("astAddrTwo", astAddrTwo);
        if(isValidString(astCity))
          assetHash.put("astCity", astCity);
        if(isValidString(astStD))
          assetHash.put("astStD",  astStD);
        if(isValidString(astZip))
          assetHash.put("astZip", astZip);
        if(isValidString(astZipPlus))
          assetHash.put("astZipPlus", astZipPlus);

        // add county - astCntyD
        //
        if(isValidString(astCntyD))
        assetHash.put("astCntyD", astCntyD);


        double astPITI = 0.0;

        astPITI += StringSupport.strToDouble(astPmt);
        astPITI += StringSupport.strToDouble(astMtgIns);
        astPITI += StringSupport.strToDouble(astIns);
        astPITI += StringSupport.strToDouble(astSchTax);
        astPITI += StringSupport.strToDouble(astPropTax);
        astPITI += StringSupport.strToDouble(astHOA);

        assetHash.put("astPITI", String.valueOf(astPITI));

        if( isValidString(astGrInc) )
        {
          double astGrIncDbl = StringSupport.strToDouble(astGrInc);

          if( astGrIncDbl != 0 )
          {
            // Annual Gross Rental Income needs to be stored in a new field for use by the WFE.
        	//  
        	assetHash.put("astAnnlGrIncWFE", astGrInc);

        	// DataEntrySupport hard codes the rental income frequency field (CSFieldNames.FN_BWR_NT_RNTL_INC_PRD) to monthly.  
            //        	  
        	assetHash.put("astGrInc", String.valueOf(FinCalcs.round( (astGrIncDbl/12), 2)));
            assetHash.put("astRntlIncFactor", "75");
            assetHash.put("astNtInc", String.valueOf(FinCalcs.round(astGrIncDbl * .75 - astPITI, 2)));
          }
        }

        // if( isValidString(astVal) && isValidString(astLn) )  REMOVE CKD
        //
        if( isValidString(astVal) )
        {
          double astValDbl = StringSupport.strToDouble(astVal);
          double astLnDbl  = StringSupport.strToDouble(astLn);

          assetHash.put("astTransPct", "10.0");
          assetHash.put("astValNet", String.valueOf(FinCalcs.round( ((astValDbl - (astValDbl * 0.1)) - astLnDbl), 2)));
        }

        assetHash.put("astCurrResC", isValidString(astCurrResC)? astCurrResC: CSFieldValues.FALSE_STRING );
        assetHash.put("astSubPropC", isValidString(astSubPropC)? astSubPropC: CSFieldValues.FALSE_STRING );

        // new escrow fields for RE from WFE
        //
        if(isValidString(astMtgIns))
          assetHash.put("astMtgIns", astMtgIns);
        if(isValidString(astIns))
          assetHash.put("astIns", astIns);
        if(isValidString(astSchTax))
          assetHash.put("astSchTax", astSchTax);
        if(isValidString(astPropTax))
          assetHash.put("astPropTax", astPropTax);
        if(isValidString(astHOA))
          assetHash.put("astHOA", astHOA);

        if( insTaxTtl > 0.0 )
        {
          assetHash.put("astTax", String.valueOf( FinCalcs.round(insTaxTtl,2) ) );
        }
        else
        {
          assetHash.put("astTax", isValidString(astTax) ? astTax : CSFieldValues.EMPTY_STRING);
        }

        assetHash.put( "_NtWrthBwrM", getNodeBwrIndexes(asset) );

        // add hash to the list
        //
        assetList.add( assetHash );

      } // if( asset != null )

    } // for( int i=0, c=cashAssets.size(); i<c; i++ )

  } // public static void processRealEstateAsset( List assetList, List cashAssets )

  /*
           <BusinessAssets>
                   <Company>Franks Landscaping</Company>
                   <Ownership>50.0</Ownership>
                   <NetWorth>25000.00</NetWorth>
           </BusinessAssets>

  */
  public static void processBusinessAsset( List assetList, List assets )
  {
    for( int i=0, c=assets.size(); i<c; i++ )
    {
      Element asset = (Element)assets.get(i);

      if( asset != null )
      {
        String astAction  = (String)asset.getChildText("Action");
        String astSubNodeIndex  = (String)asset.getChildText("SubNodeIndex");

        String astName   = (String)asset.getChildText("Company");
        if( astName == null || astName.trim().length() == 0 )
        {
          astName   = (String)asset.getChildText("Name");
        }

        String astValPer = (String)asset.getChildText("Ownership");
        String astVal    = (String)asset.getChildText("NetWorth");
        if( astVal == null || astVal.trim().length() == 0 )
        {
          astVal   = (String)asset.getChildText("Amount");
        }

        HashMap assetHash = new HashMap();
        assetHash.put("astAction", astAction != null && astAction.trim().length() > 0 ? astAction : "EDIT" );
        assetHash.put("astSubNodeIndex", astSubNodeIndex != null && astSubNodeIndex.trim().length() > 0 ? astSubNodeIndex : CSFieldValues.EMPTY_STRING );

        assetHash.put("_NtWrthTypD",    "Asset"  );
        assetHash.put("_NtWrthSubTypD", "AstBs");
        assetHash.put("astName",   isValidString(astName)   ? astName   : CSFieldValues.EMPTY_STRING );
        assetHash.put("astValPer", isValidString(astValPer) ? astValPer : CSFieldValues.EMPTY_STRING );
        assetHash.put("astVal",    isValidString(astVal)    ? astVal    : CSFieldValues.EMPTY_STRING );

        String astTypD   = (String)asset.getChildText("Type");
        assetHash.put("astTypD",   isValidString(astTypD) ? astTypD : CSFieldValues.EMPTY_STRING );

        assetHash.put( "_NtWrthBwrM", getNodeBwrIndexes(asset) );

        // add hash to the list
        //
        assetList.add( assetHash );

      } // if( asset != null )

    } // for( int i=0, c=cashAssets.size(); i<c; i++ )

  } // public static void processBusinessAsset( List assetList, List cashAssets )

  /*
     <BusinessAccountsReceivable>
             <Name>Thompson Ltd.</Name>
             <Amount>1000.00</Amount>
             <Age>90</Age>
     </BusinessAccountsReceivable>
  */
  public static void processBusinessAccountsReceivableAsset( List assetList, List assets )
  {
    for( int i=0, c=assets.size(); i<c; i++ )
    {
      Element asset = (Element)assets.get(i);

      if( asset != null )
      {
        String astAction  = (String)asset.getChildText("Action");
        String astSubNodeIndex  = (String)asset.getChildText("SubNodeIndex");

        String astName = (String)asset.getChildText("Name");
        String astAge  = (String)asset.getChildText("Age");
        String astVal  = (String)asset.getChildText("Amount");

        HashMap assetHash = new HashMap();
        assetHash.put("astAction", astAction != null && astAction.trim().length() > 0 ? astAction : "EDIT" );
        assetHash.put("astSubNodeIndex", astSubNodeIndex != null && astSubNodeIndex.trim().length() > 0 ? astSubNodeIndex : CSFieldValues.EMPTY_STRING );

        assetHash.put("_NtWrthTypD",    "Asset"  );
        assetHash.put("_NtWrthSubTypD", "AstBsActRcv");
        assetHash.put("astName",   isValidString(astName) ? astName : CSFieldValues.EMPTY_STRING );
        assetHash.put("astAge",    isValidString(astAge)  ? astAge  : CSFieldValues.EMPTY_STRING );
        assetHash.put("astVal",    isValidString(astVal)  ? astVal  : CSFieldValues.EMPTY_STRING );

        assetHash.put( "_NtWrthBwrM", getNodeBwrIndexes(asset) );

        // add hash to the list
        //
        assetList.add( assetHash );

      } // if( asset != null )

    } // for( int i=0, c=cashAssets.size(); i<c; i++ )

  } // public static void processBusinessAccountsReceivableAsset( List assetList, List cashAssets )

/*
   <OtherAssets>
           <Description>Race Horse</Description>
           <Amount>1000.00</Amount>
   </OtherAssets>

*/
public static void processOtherAsset( List assetList, List assets )
{
  for( int i=0, c=assets.size(); i<c; i++ )
  {
    Element asset = (Element)assets.get(i);

    if( asset != null )
    {
      String astAction  = (String)asset.getChildText("Action");
      String astSubNodeIndex  = (String)asset.getChildText("SubNodeIndex");

      String astDesc    = (String)asset.getChildText("Description");
      if( astDesc == null || astDesc.trim().length() == 0 )
      {
        astDesc = (String)asset.getChildText("Name");
      }

      String astVal     = (String)asset.getChildText("Amount");

      HashMap assetHash = new HashMap();
      assetHash.put("astAction", astAction != null && astAction.trim().length() > 0 ? astAction : "EDIT" );
      assetHash.put("astSubNodeIndex", astSubNodeIndex != null && astSubNodeIndex.trim().length() > 0 ? astSubNodeIndex : CSFieldValues.EMPTY_STRING );

      assetHash.put("_NtWrthTypD",    "Asset"  );
      assetHash.put("_NtWrthSubTypD", "AstOth");
      assetHash.put("astDesc",   isValidString(astDesc) ? astDesc : CSFieldValues.EMPTY_STRING );
      assetHash.put("astVal",    isValidString(astVal)  ? astVal  : CSFieldValues.EMPTY_STRING );

      String astTypD   = (String)asset.getChildText("Type");
      assetHash.put("astTypD",   isValidString(astTypD) ? astTypD : CSFieldValues.EMPTY_STRING );

      assetHash.put( "_NtWrthBwrM", getNodeBwrIndexes(asset) );

      // add hash to the list
      //
      assetList.add( assetHash );

    } // if( asset != null )

  } // for( int i=0, c=cashAssets.size(); i<c; i++ )

} // public static void processOtherAsset( List assetList, List cashAssets )

/*
   <OtherAssets>
           <Description>Race Horse</Description>
           <Amount>1000.00</Amount>
   </OtherAssets>

*/
public static void processRetirementFundAsset( List assetList, List assets )
{
  for( int i=0, c=assets.size(); i<c; i++ )
  {
    Element asset = (Element)assets.get(i);

    if( asset != null )
    {
      String astAction  = (String)asset.getChildText("Action");
      String astSubNodeIndex  = (String)asset.getChildText("SubNodeIndex");

      String astDesc = (String)asset.getChildText("Description");
      if( astDesc == null || astDesc.trim().length() == 0 )
      {
        astDesc = (String)asset.getChildText("Name");
      }

      String astVal  = (String)asset.getChildText("Amount");

      HashMap assetHash = new HashMap();
      assetHash.put("astAction", astAction != null && astAction.trim().length() > 0 ? astAction : "EDIT" );
      assetHash.put("astSubNodeIndex", astSubNodeIndex != null && astSubNodeIndex.trim().length() > 0 ? astSubNodeIndex : CSFieldValues.EMPTY_STRING );

      assetHash.put("_NtWrthTypD",    "Asset"  );
      assetHash.put("_NtWrthSubTypD", "AstRF");
      assetHash.put("astDesc",   isValidString(astDesc) ? astDesc : CSFieldValues.EMPTY_STRING );
      assetHash.put("astVal",    isValidString(astVal)  ? astVal  : CSFieldValues.EMPTY_STRING );

      String astTypD   = (String)asset.getChildText("Type");
      assetHash.put("astTypD",   isValidString(astTypD) ? astTypD : CSFieldValues.EMPTY_STRING );

      assetHash.put( "_NtWrthBwrM", getNodeBwrIndexes(asset) );

      // add hash to the list
      //
      assetList.add( assetHash );

    } // if( asset != null )

  } // for( int i=0, c=cashAssets.size(); i<c; i++ )

} // public static void processOtherAsset( List assetList, List cashAssets )


// old way that was implemeted for business
//
public static void processLiability( List liabilityList, List liabilities, String subType )
 {
   for( int i=0, c=liabilities.size(); i<c; i++ )
   {
     Element liability = (Element)liabilities.get(i);

     if( liability != null )
     {

       String liTypD = (String)liability.getChildText("Type");
       String liName = (String)liability.getChildText("InstitutionName");
       String liDesc = (String)liability.getChildText("Description");
       String liDt   = (String)liability.getChildText("MaturityDate");
       String liPlgD = (String)liability.getChildText("Secured");
       String liRt  =  (String)liability.getChildText("InterestRate");
       String liAmt  = (String)liability.getChildText("OriginalAmount");
       String liPmt  = (String)liability.getChildText("MonthlyPayment");
       String liVal  = (String)liability.getChildText("CurrentBalance");

       HashMap liabilityHash = new HashMap();
       liabilityHash.put("_NtWrthTypD",    "Liability" );
       liabilityHash.put("_NtWrthSubTypD", subType );
       if( isValidString(liTypD) ) liabilityHash.put("liTypD", liTypD );
       if( isValidString(liName) ) liabilityHash.put("liName", liName );
       if( isValidString(liDesc) ) liabilityHash.put("liDesc", liDesc );
       if( isValidString(liDt  ) ) liabilityHash.put("liDt",   liDt   );
       if( isValidString(liPlgD) ) liabilityHash.put("liPlgD", translateYesNo(liPlgD) );
       if( isValidString(liRt  ) ) liabilityHash.put("liRt",   liRt   );
       if( isValidString(liAmt ) ) liabilityHash.put("liAmt",  liAmt  );
       if( isValidString(liPmt ) ) liabilityHash.put("liPmt",  liPmt  );
       if( isValidString(liVal ) ) liabilityHash.put("liVal",  liVal  );

       // add hash to the list
       //
       liabilityList.add( liabilityHash );

     } // if( asset != null )

   } // for( int i=0, c=cashAssets.size(); i<c; i++ )

 } // public static void processNotesReceivableAsset( List assetList, List cashAssets )


  /*
  <NotesPayableBanks>

         <InstitutionName>Franklin Jewelers</InstitutionName>
         <Description>Engagement Ring</Description>
         <MaturityDate>05/05/2010</MaturityDate>
         <Secured>Yes</Secured>
         <InterestRate>7.25</InterestRate>
         <OriginalAmount>5000.00</OriginalAmount>
         <MonthlyPayment>500.00</MonthlyPayment>
         <PresentBalance>1000.00</PresentBalance>

  </NotesPayableBanks>

  <OtherNotesPayable>

          <InstitutionName>Matlack Dodge</InstitutionName>
          <Description>Car Loan</Description>
          <MaturityDate>05/05/2010</MaturityDate>
          <Secured>Yes</Secured>
          <InterestRate>7.25</InterestRate>
          <OriginalAmount>15000.00</OriginalAmount>
          <MonthlyPayment>150.00</MonthlyPayment>
          <PresentBalance>1000.00</PresentBalance>

  </OtherNotesPayable>

  <CreditCards>
          <Lender>Visa</Lender>
          <Secured>No</Secured>
          <CreditLimit>50000.00</CreditLimit>
          <CurrentBalance>1000.00</CurrentBalance>

  </CreditCards>

  <TaxesPayable>
          <Type>Property</Type>
          <Secured>No</Secured>
          <Amount>1000.00</Amount>

  </TaxesPayable>

  <OtherLiabilities>
          <Description>Personal Loan</Description>
          <Secured>No</Secured>
          <Amount>1000.00</Amount>
  </OtherLiabilities>

  */
  // overload method for mortgage
  //
  public static void processLiability( VectorX liabilityList, List liabilities, String subType )
  {
    //general.errLog("START processLiability( VectorX liabilityList, List liabilities, String subType )","LiabSetUpDN.log");
    //general.errLog("VectorX liabilityList: "+liabilityList,"LiabSetUpDN.log");
    //general.errLog("List liabilities: "+liabilities,"LiabSetUpDN.log");
    //general.errLog("String subType: "+subType,"LiabSetUpDN.log");

    for( int i=0, c=liabilities.size(); i<c; i++ )
    {
      Element liability = (Element)liabilities.get(i);

      if( liability != null )
      {
        String liAction  = (String)liability.getChildText("Action");
        //general.errLog("liAction: "+liAction,"LiabSetUpDN.log");

        String liSubNodeIndex  = (String)liability.getChildText("SubNodeIndex");
        //general.errLog("liSubNodeIndex: "+liSubNodeIndex,"LiabSetUpDN.log");

        String liTypD = (String)liability.getChildText("Type");
        if( liTypD == null || liTypD.trim().length() == 0 )
        {
          //AppImportUtils.processLiability( liabilityList, AlimonyChildSupportList, "LbACS" );
          //AppImportUtils.processLiability( liabilityList, JobRelatedExpenseList, "LbJRE" );

          if( subType.equals("LbACS") )
          {
            liTypD = "Alimony Child Support";
          }
          else if( subType.equals("LbJRE") )
          {
            liTypD = "Job Related Expense";
          }
        }

        //general.errLog("liTypD: "+liTypD,"LiabSetUpDN.log");

        String liAcctNum = (String)liability.getChildText("AccountNumber");
        //general.errLog("liAcctNum: "+liAcctNum,"LiabSetUpDN.log");

        String liName    = (String)liability.getChildText("InstitutionName");
        if( liName == null || liName.trim().length() == 0 )
        {
          liName  = (String)liability.getChildText("Lender");

          if( liName == null || liName.trim().length() == 0 )
          {
            liName = (String) liability.getChildText("Creditor");

            if( liName == null || liName.trim().length() == 0 )
            {
              liName = (String) liability.getChildText("Expense");
            }
          }
        }

        //general.errLog("liName: "+liName,"LiabSetUpDN.log");

        String liDesc    = (String)liability.getChildText("Description");
        //general.errLog("liDesc: "+liDesc,"LiabSetUpDN.log");
        String liDt      = (String)liability.getChildText("MaturityDate");
        //general.errLog("liDt: "+liDt,"LiabSetUpDN.log");
        String liPlgD    = (String)liability.getChildText("Secured");
        //general.errLog("liPlgD: "+liPlgD,"LiabSetUpDN.log");
        String liRt      =  (String)liability.getChildText("InterestRate");
        //general.errLog("liRt: "+liRt,"LiabSetUpDN.log");
        String liPmt     = (String)liability.getChildText("MonthlyPayment");
        //general.errLog("liPmt: "+liPmt,"LiabSetUpDN.log");

        String liLmt     = (String)liability.getChildText("OriginalAmount");
        if( liLmt == null || liLmt.trim().length() == 0 )
        {
          liLmt  = (String)liability.getChildText("CreditLimit");
        }

        //general.errLog("liLmt: "+liLmt,"LiabSetUpDN.log");

        String liVal     = (String)liability.getChildText("PresentBalance");
        if( liVal == null || liVal.trim().length() == 0 )
        {
          // credit card
          //
          liVal  = (String)liability.getChildText("CurrentBalance");

          // other liabilities
          //
          if( liVal == null || liVal.trim().length() == 0 )
          {
            liVal  = (String)liability.getChildText("Amount");
          }
        }

        //general.errLog("liVal: "+liVal,"LiabSetUpDN.log");

        String liAddr     = (String)liability.getChildText("Address");
        //general.errLog("liAddr: "+liAddr,"LiabSetUpDN.log");

        String liAddrTwo  = (String)liability.getChildText("AddressLineTwo");
        //general.errLog("liAddrTwo: "+liAddrTwo,"LiabSetUpDN.log");

        String liCity     = (String)liability.getChildText("City");
        //general.errLog("liCity: "+liCity,"LiabSetUpDN.log");

        String liStD      = (String)liability.getChildText("State");
        //general.errLog("liStD: "+liStD,"LiabSetUpDN.log");

        String liZip      = (String)liability.getChildText("Zip");
        //general.errLog("liZip: "+liZip,"LiabSetUpDN.log");

        String liZipPlus  = (String)liability.getChildText("ZipPlus");
        //general.errLog("liZipPlus: "+liZipPlus,"LiabSetUpDN.log");


        String liREOD      = (String)liability.getChildText("AssociatedProperty");
        //general.errLog("liREOD: "+liREOD,"LiabSetUpDN.log");

        String liRmPmt     = (String)liability.getChildText("RemainingPayments");
        //general.errLog("liRmPmt: "+liRmPmt,"LiabSetUpDN.log");

        String liPayOffC   = (String)liability.getChildText("PayingOff");
        //general.errLog("liPayOffC: "+liPayOffC,"LiabSetUpDN.log");

        String _NtWrthSelC   = (String)liability.getChildText("Selected");
        //general.errLog("SELECTED _NtWrthSelC: "+_NtWrthSelC,"LiabSetUpDN.log");

        String liLnPosD    = (String)liability.getChildText("LienPosition");
        String liPaidC     = (String)liability.getChildText("AlreadyPaid");
        String liModifyC   = (String)liability.getChildText("Modified");

        String liPurchC   = (String)liability.getChildText("UsedForPurchase");
        //general.errLog("liPurchC: "+liPurchC,"LiabSetUpDN.log");
        //general.errLog("translateYesNo(liPurchC): "+translateYesNo(liPurchC),"LiabSetUpDN.log");

        String liIndexWFE = (String)liability.getChildText("WfeIndex");
        //general.errLog("liIndexWFE: "+liIndexWFE,"LiabSetUpDN.log");

        // since we now edit we need to load the hash with the WFE fields that
        // specifically match each type of liability
        //
        HashMap liabilityHash = new HashMap();
        liabilityHash.put("_NtWrthTypD",    "Liability" );
        liabilityHash.put("_NtWrthSubTypD", subType );

        if( liIndexWFE != null && liIndexWFE.trim().length() > 0 )
        {
          liabilityHash.put("liIndexWFE", liIndexWFE);
        }

        if( _NtWrthSelC != null && _NtWrthSelC.trim().length() > 0 )
        {
          liabilityHash.put("_NtWrthSelC", _NtWrthSelC);
        }

        // assetHash.put("astName",   isValidString(astName)   ? astName   : CSFieldValues.EMPTY_STRING );
        //
        liabilityHash.put("liAction", liAction != null && liAction.trim().length() > 0 ? liAction : "EDIT" );
        liabilityHash.put("liSubNodeIndex", liSubNodeIndex != null && liSubNodeIndex.trim().length() > 0 ? liSubNodeIndex : CSFieldValues.EMPTY_STRING );

        if(isValidString(liTypD))
          liabilityHash.put("liTypD", liTypD);

        if( liTypD != null && liTypD.trim().equals("Job Related Expense") )
        {
          if(isValidString(liName))
            liabilityHash.put("liName", liName);

          if(isValidString(liVal))
            liabilityHash.put("liVal", liVal);
        }
        else if( liTypD != null && liTypD.trim().equals("Alimony Child Support") )
        {
          //liabilityHash.put("liName", isValidString(liName) ? liName : CSFieldValues.EMPTY_STRING );
          //liabilityHash.put("liVal",  isValidString(liVal)  ? liVal  : CSFieldValues.EMPTY_STRING );
          //
          if(isValidString(liName))
            liabilityHash.put("liName", liName);

          if(isValidString(liVal))
            liabilityHash.put("liVal", liVal);

          if(isValidString(liPmt))
            liabilityHash.put("liPmt", liPmt);
        }
        else if( liTypD != null &&
               ( liTypD.trim().equals("Credit Line") || liTypD.trim().equals("Installment") || liTypD.trim().equals("Mortgage") ||
                 liTypD.trim().equals("Open")        || liTypD.trim().equals("Revolving")   || liTypD.trim().equals("Unknown") ) )
        {
          //liabilityHash.put("liName",    isValidString(liName)    ? liName : CSFieldValues.EMPTY_STRING );
          //liabilityHash.put("liVal",     isValidString(liVal)     ? liVal  : CSFieldValues.EMPTY_STRING );
          //liabilityHash.put("liPmt",     isValidString(liPmt)     ? liPmt  : CSFieldValues.EMPTY_STRING );
          //
          if(isValidString(liName))
            liabilityHash.put("liName", liName);

          if(isValidString(liVal))
            liabilityHash.put("liVal", liVal);

          if(isValidString(liPmt))
            liabilityHash.put("liPmt", liPmt);

          if(isValidString(liAcctNum))
            liabilityHash.put("liAcctNum", liAcctNum);

          if(isValidString(liLmt))
            liabilityHash.put("liLmt", liLmt);

          liabilityHash.put("liPayOffC", isValidString(liPayOffC) ? translateYesNo(liPayOffC) : CSFieldValues.FALSE_STRING );

          if(isValidString(liLnPosD))
            liabilityHash.put("liLnPosD", liLnPosD);

          liabilityHash.put("liPaidC",   isValidString(liPaidC)   ? translateYesNo(liPaidC) : CSFieldValues.FALSE_STRING );

          if(isValidString(liREOD))
            liabilityHash.put("liREOD", liREOD);

          liabilityHash.put("liModifyC", isValidString(liModifyC) ? liModifyC  : CSFieldValues.FALSE_STRING );
          liabilityHash.put("liPurchC",  isValidString(liPurchC)  ? translateYesNo(liPurchC)  : CSFieldValues.FALSE_STRING );

          //general.errLog("1 isValidString(liPurchC): "+isValidString(liPurchC)+" - translateYesNo(liPurchC): "+translateYesNo(liPurchC),"LiabSetUpDN.log");
        }
        else
        {
          //liabilityHash.put("liName",    isValidString(liName)    ? liName    : CSFieldValues.EMPTY_STRING );
          //liabilityHash.put("liVal",     isValidString(liVal)     ? liVal : CSFieldValues.EMPTY_STRING );
          //liabilityHash.put("liPmt",     isValidString(liPmt)     ? liPmt : CSFieldValues.EMPTY_STRING );
          //liabilityHash.put("liAcctNum", isValidString(liAcctNum) ? liAcctNum : CSFieldValues.EMPTY_STRING );
          //liabilityHash.put("liLmt",     isValidString(liLmt)     ? liLmt : CSFieldValues.EMPTY_STRING );
          //
          if(isValidString(liName))
            liabilityHash.put("liName", liName);

          if(isValidString(liVal))
            liabilityHash.put("liVal", liVal);

          if(isValidString(liPmt))
            liabilityHash.put("liPmt", liPmt);

          if(isValidString(liAcctNum))
            liabilityHash.put("liAcctNum", liAcctNum);

          if(isValidString(liLmt))
            liabilityHash.put("liLmt", liLmt);

          if(isValidString(liDesc))
            liabilityHash.put("liDesc", liDesc);

          if(isValidString(liDt))
            liabilityHash.put("liDt", liDt);

          liabilityHash.put("liPlgD",    isValidString(liPlgD)    ? translateYesNo(liPlgD) : CSFieldValues.FALSE_STRING );
          liabilityHash.put("liSecD",    isValidString(liPlgD)    ? translateYesNo(liPlgD) : CSFieldValues.FALSE_STRING );

          if(isValidString(liRt))
            liabilityHash.put("liRt", liRt);

          if(isValidString(liAddr))
            liabilityHash.put("liAddr", liAddr);

          if(isValidString(liAddrTwo))
            liabilityHash.put("liAddrTwo", liAddrTwo);

          if(isValidString(liCity))
            liabilityHash.put("liCity", liCity);

          if(isValidString(liStD))
            liabilityHash.put("liStD", liStD);

          if(isValidString(liZip))
            liabilityHash.put("liZip", liZip);

          if(isValidString(liZipPlus))
            liabilityHash.put("liZipPlus", liZipPlus);

          if(isValidString(liREOD))
            liabilityHash.put("liREOD", liREOD);

          if(isValidString(liRmPmt))
            liabilityHash.put("liRmPmt", liRmPmt);

          if(isValidString(liLnPosD))
            liabilityHash.put("liLnPosD", liLnPosD);

          liabilityHash.put("liPayOffC", isValidString(liPayOffC) ? translateYesNo(liPayOffC) : CSFieldValues.FALSE_STRING );
          liabilityHash.put("liPaidC",   isValidString(liPaidC)   ? translateYesNo(liPaidC)   : CSFieldValues.FALSE_STRING );
          liabilityHash.put("liModifyC", isValidString(liModifyC) ? liModifyC  : CSFieldValues.FALSE_STRING );
          liabilityHash.put("liPurchC",  isValidString(liPurchC)  ? translateYesNo(liPurchC)  : CSFieldValues.FALSE_STRING );

          //general.errLog("2 isValidString(liPurchC): "+isValidString(liPurchC)+" - translateYesNo(liPurchC): "+translateYesNo(liPurchC),"LiabSetUpDN.log");
        }

        liabilityHash.put( "_NtWrthBwrM", getNodeBwrIndexes(liability) );

        // add hash to the list
        //
        //general.errLog("liabilityHash: "+liabilityHash,"LiabSetUpDN.log");

        liabilityList.add( liabilityHash );

      } // if( asset != null )

    } // for( int i=0, c=cashAssets.size(); i<c; i++ )

    //general.errLog("liabilityList: "+liabilityList,"LiabSetUpDN.log");
    //general.errLog("END processLiability( VectorX liabilityList, List liabilities, String subType )","LiabSetUpDN.log");

  } // public static void processNotesReceivableAsset( List assetList, List cashAssets )


  public static void processAssetLiabilityNetWorthData( String username, int branchId,
                                                        List astLiabList, SystemDataObject sdo,
                                                        DataNode bwrNode ) throws Exception
  {
    //errorLog("START processNetWorthDataHash(...)", AIU);
    //errorLog("processNetWorthDataHash()", AIU);
    //errorLog("astLiabList: "+astLiabList, AIU);

    for(int i=0,c=astLiabList.size(); i<c; i++ )
    {
      HashtableX astLiabData = (HashtableX)astLiabList.get(i);

      if( astLiabData != null && ! astLiabData.isEmpty() )
      {
        // astLiabData.put("_NtWrthTypD",    "Asset");
        // astLiabData.put("_NtWrthSubTypD", "Life Insurance Policies");

        String nwType = (String)astLiabData.get("_NtWrthTypD");
        //errorLog("nwType: "+nwType, AIU);

        String nwSubType = (String)astLiabData.get("_NtWrthSubTypD");
        //errorLog("nwSubType: "+nwSubType, AIU);

        DataNode nwNode = bwrNode.getFirstReference(nwType);
        //errorLog("nwNode: "+nwNode, AIU);

        if (nwNode == null)
        {
          // create new net worth node and add to bwr node since one doesn't exist
          //
          nwNode = DataEntrySupport.createNWNode(sdo, bwrNode, nwType, username);
        }

        xResponse res = DataEntrySupport.checkNWItemDuplication( nwNode, nwSubType,
                                                                 astLiabData, username );

        //errorLog("add res.errCode: "+res.errCode, AIU);

        if (res.errCode == 0 )
        {
            String nwSubTypeLabel = (String)ApplicationHouse.getListCodesCache().getListCodeLabel(
                                    nwType + " Sub Types", nwSubType, branchId);

            //errorLog("nwSubTypeLabel: "+nwSubTypeLabel, AIU);

            DataNode nwItemNode = sdo.createDataNode( username, nwSubTypeLabel );
            nwItemNode.setFieldData(username,NodeUtils.separateDataHash(nwType,astLiabData,false));
            nwNode.addReference(nwItemNode);

            HashtableX totalHash = new HashtableX();
            DataEntrySupport.updateTotals( bwrNode, nwSubType, totalHash );

            if( totalHash != null && ! totalHash.isEmpty() )
            {
              //errorLog("totalHash: "+totalHash, AIU);

              // atTtlLi
              String atTtlLi = (String)totalHash.get("atTtlLi");
              bwrNode.setFieldData( username, "atTtlLi", atTtlLi == null ? "0.00" : atTtlLi );

              // atLiSec
              String atLiSec = (String)totalHash.get("atLiSec");
              bwrNode.setFieldData( username, "atLiSec", atLiSec == null ? "0.00" : atLiSec );

              // atLiUnsec
              String atLiUnsec = (String)totalHash.get("atLiUnsec");
              bwrNode.setFieldData( username, "atLiUnsec", atLiUnsec == null ? "0.00" : atLiUnsec );

              // atTtlAst
              String atTtlAst = (String)totalHash.get("atTtlAst");
              bwrNode.setFieldData( username, "atTtlAst", atTtlAst == null ? "0.00" : atTtlAst );

              // atAstUnplg
              String atAstUnplg = (String)totalHash.get("atAstUnplg");
              bwrNode.setFieldData( username, "atAstUnplg", atAstUnplg == null ? "0.00" : atAstUnplg );

              // atAstPlg
              String atAstPlg = (String)totalHash.get("atAstPlg");
              bwrNode.setFieldData( username, "atAstPlg", atAstPlg == null ? "0.00" : atAstPlg );

              // atNtWrth
              String atNtWrth = (String)totalHash.get("atNtWrth");
              bwrNode.setFieldData( username, "atNtWrth", atNtWrth == null ? "0.00" : atNtWrth );
            }
        }
        else
        {
          // duplicate entry
        }

      } // if( astLiabData != null && ! astLiabData.isEmpty() )
    }
    //errorLog("END processNetWorthDataHash(...)", AIU);
  } // private void processNetWorthDataHash( HashtableX astData, SystemDataObject sdo, DataNode bwrNode )

  /**
   * Returns the borrower node for the given position
   *
   * @param sdo SystemDataObject
   * @param position int
   * @return DataNode
   */
  public static DataNode getBwrNodeFromSDO( SystemDataObject sdo, int position )
  {
    DataNode bwrDN = null;

    if( sdo != null )
    {
      DataNode appDN = sdo.getNodeData( NodeUtils.APP_DN_TYPE );
      bwrDN = appDN.getReference( NodeUtils.BWR_DN_TYPE, position );
    }

    return bwrDN;
  } // public static DataNode getPrimaryBwrNodeFromSDO( SystemDataObject sdo )


  /**
   * Returns the application refrence id
   *
   * @param sdo SystemDataObject
   * @return String
   */
  public static String getReferenceIdFromSDO( SystemDataObject sdo )
  {
    String refID = null;

    if( sdo != null )
    {
      DataNode appDN = sdo.getNodeData( NodeUtils.APP_DN_TYPE );
      if( appDN != null )
      {
        refID = (String)appDN.getFieldData(CSFieldValues.EMPTY_STRING,"anRefId");
      }
    }

    return refID;
  } // public static DataNode getReferenceIdFromSDO( SystemDataObject sdo )

  public static void setupBusinessSubNode( SystemDataObject sdo, HashtableX nodeHash,
                                           String nodeType, String username )
  throws Exception
  {
    //errorLog( "setupBusinessSubNode(...)", "SetupBusSubDN" );
    //errorLog( "sdo: "+sdo, "SetupBusSubDN" );
    //errorLog( "nodeHash: "+nodeHash, "SetupBusSubDN" );
    //errorLog( "nodeType: "+nodeType, "SetupBusSubDN" );
    //errorLog( "username: "+username, "SetupBusSubDN" );

    boolean isAdd = true;

    int nodePosition = 0;

    DataNode appDN = sdo.getNodeData(NodeUtils.APP_DN_TYPE);
    //errorLog( "appDN: "+appDN, "SetupBusSubDN" );

    if (appDN == null)
    {
      throw new Exception("Application Data Node value is NULL");
    }

    // Get business node
    //
    int busPOS = 0;

    DataNode busDN = appDN.getReference(NodeUtils.BUS_DN_TYPE, busPOS);
    //errorLog( "busDN: "+busDN, "SetupBusSubDN" );

    if (busDN == null)
    {
      throw new Exception("Business data not found.");
    }

    DataNode subDN = null;

    //errorLog( "isAdd: "+isAdd, "SetupBusSubDN" );

    if (isAdd)
    {
      subDN = sdo.createDataNode(username, nodeType);
      subDN.setFieldData(username, nodeHash);

      busDN.addReference(subDN);
    }
    else
    {
      subDN = busDN.getReference(nodeType, nodePosition);

      if (subDN == null)
      {
        throw new Exception("Save: Unable to locate selected item.");
      }

      subDN.setFieldData(username, nodeHash);
    }

    //VectorX nodeSummary = DataEntrySupport.buildSubNodeDescriptionsList(busDN, nodeType);
    //busDN.setFieldData(username, prefix + "L", nodeSummary);

  }   // opCodeSaveBusinessSubNode

  public static void setupAssetNode( SystemDataObject sdo, int bwrNodePosition,
                                     String username, HashtableX assetHash ) throws Exception
  {
  //general.errLog("START setupAssetNode(...)",AIU);

  boolean isAdd       = false;
  DataNode bwrNode    = null;
  DataNode nwNode     = null;
  DataNode nwItemNode = null;

  DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);
  //general.errLog("appNode loaded",AIU);

  if( appNode != null )
    {
    bwrNode = appNode.getReference(NodeUtils.BWR_DN_TYPE, bwrNodePosition);
    //general.errLog("bwrNode loaded",AIU);

    if( bwrNode != null && ! bwrNode.isDeleted() )
      {
      String nwType = (String)assetHash.get("_NtWrthTypD");
      //general.errLog("nwType: "+nwType, AIU);

      String nwSubType = (String)assetHash.get("_NtWrthSubTypD");
      //general.errLog("nwSubType: "+nwSubType, AIU);

      nwNode = bwrNode.getReference(nwType, 0); // only one node for Asset or Liability node
      //general.errLog("nwNode: "+nwNode, AIU);

      if( nwNode == null )
        {
          nwNode = sdo.createDataNode(username, nwType);
          nwNode.setSystemData("!container", "true");
          isAdd = true;
        }

      //general.errLog("nwNode loaded",AIU);

      // create net worth item node
      //
      // SECTION_NAME = Asset And Liability Sub Types
      //
      String nwSubTypeLabel = (String) listCodesCache.getListCodeLabel( SECTION_NAME, nwSubType );

      //general.errLog("nwSubTypeLabel: "+nwSubTypeLabel,AIU);

      nwItemNode = sdo.createDataNode(username, nwSubTypeLabel);
      nwItemNode.setFieldData(username, assetHash);

      if( nwItemNode != null )
        {
          if( nwNode != null )
          {
            nwNode.addReference(nwItemNode);

            if( isAdd )
            {
              bwrNode.addReference(nwNode);
            }

            try
            {
              updateTotalValues( nwSubTypeLabel, nwItemNode, nwSubType, nwNode, username, bwrNode );
            }
            catch( Exception e )
            {
              e.printStackTrace();
            }

            try
            {
              updateTotalNetWorth( username, bwrNode, nwNode );
            }
            catch( Exception e )
            {
              e.printStackTrace();
            }

          }
        }
      } // if( bwrNode != null && !bwrNode.isDeleted() )
    } // if( appNode != null )

  //general.errLog("END setupAssetNode(...)",AIU);
  } // setupAssetNode(...)

  public static void updateTotalValues( String nwSubTypeLabel,
                                        DataNode nwItemNode,
                                        String nwSubType,
                                        DataNode nwNode,
                                        String username,
                                        DataNode bwrNode )
 {
    //general.errLog("START updateTotalValues(...)",AIU);

    // get net worth sub type node
    //
    String secPlgTypD = null;
    //String nodeSecPlgTypD = null;
    String secPlgFieldName = null;

    // added or edited asset/liability item value
    //
    String nwField = null;
    String nwValueStr = null;
    //String nwValueOldStr = null;
    double nwValue = 0.0D;
    //double nwValueOld = 0.0D;

    // subtotal of certain type of pledged asset or secured liability
    //
    String nodeFieldNameSecSubTtl = null;
    String nodeFieldNameUnsecSubTtl = null;
    String secSubTtlValueStr = null;
    String unsecSubTtlValueStr = null;
    //String csFieldNameSecSubTtl = null;
    //String csFieldNameUnsecSubTtl = null;
    double secSubTtlValue = 0.0D;
    double unsecSubTtlValue = 0.0D;

    // subtotal value of certain type of asset or liability
    //
    //String csFieldNameSubTtl = null;
    //String subTtlValueStr = null;
    double subTtlValue = 0.0D;

    // total pledged/unpledged assets or secured/unsecured liabilities
    //
    String ttlSecValStr = null;
    String ttlUnsecValStr = null;
    String nodeFieldNameSecTtl = null;
    String nodeFieldNameUnsecTtl = null;
    String csFieldNameSecTtl = null;
    String csFieldNameUnsecTtl = null;
    double ttlSecVal = 0.0D;
    double ttlUnsecVal = 0.0D;

    // total assets or liabilities value
    //
    String ttlValueStr = null;
    String nodeFieldNameTtl = null;
    String csFieldNameTtl = null;
    double ttlValue = 0.0D;

    // DEFINITION OF VARIABLES based on net worth type (Asset or Liability)
    //
    if (nwSubType.startsWith(AST_SUB_TYPE_PREFIX)) {
      nwField = "astVal";
      nodeFieldNameTtl = CSFieldNames.FN_SYS_TTL_AST;
      csFieldNameTtl = CSFieldNames.FN_BWR_TTL_AST;
      //csFieldNameSubTtl = "_astTtlVal";

      nodeFieldNameSecTtl = CSFieldNames.FN_SYS_TTL_PLG;
      nodeFieldNameUnsecTtl = CSFieldNames.FN_SYS_TTL_UN_PLG;
      csFieldNameSecTtl = CSFieldNames.FN_BWR_AST_PLG;
      csFieldNameUnsecTtl = CSFieldNames.FN_BWR_AST_UNPLG;

      //csFieldNameSecSubTtl = "_astTtlPlg";
      //csFieldNameUnsecSubTtl = "_astTtlUnplg";
      nodeFieldNameSecSubTtl = "!" + nwSubType + "Plg";
      nodeFieldNameUnsecSubTtl = "!" + nwSubType + "Unplg";

      secPlgFieldName = "astPlgD";
      //secPlgTypD = (String) inFields.get(secPlgFieldName);
      secPlgTypD = (String) nwItemNode.getFieldData( username, secPlgFieldName);
    }
    else if (nwSubType.startsWith(LB_SUB_TYPE_PREFIX)) {
      nwField = "liVal";
      nodeFieldNameTtl = CSFieldNames.FN_SYS_TTL_LI;
      csFieldNameTtl = CSFieldNames.FN_BWR_TTL_LI;
      //csFieldNameSubTtl = "_liTtlVal";

      nodeFieldNameSecTtl = CSFieldNames.FN_SYS_TTL_SEC;
      nodeFieldNameUnsecTtl = CSFieldNames.FN_SYS_TTL_UNSEC;
      csFieldNameSecTtl = CSFieldNames.FN_BWR_LI_SEC;
      csFieldNameUnsecTtl = CSFieldNames.FN_BWR_LI_UNSEC;

      //csFieldNameSecSubTtl = "_liTtlSec";
      //csFieldNameUnsecSubTtl = "_liTtlUnsec";
      nodeFieldNameSecSubTtl = "!" + nwSubType + "Sec";
      nodeFieldNameUnsecSubTtl = "!" + nwSubType + "Unsec";

      secPlgFieldName = "liPlgD";
      //secPlgTypD = (String) inFields.get(secPlgFieldName);
      secPlgTypD = (String) nwItemNode.getFieldData( username, secPlgFieldName);
    }

//general.errLog("nwSubTypeLabel: "+nwSubTypeLabel,AIU);

    //if (nwItemNode != null && !nwItemNode.isDeleted())
    // {
    //   nodeSecPlgTypD = (String) nwItemNode.getFieldData(username, secPlgFieldName);
    //   //general.errLog("nodeSecPlgTypD: "+nodeSecPlgTypD,AIU);
    // }

    nwValueStr = (String) nwItemNode.getFieldData( username,  nwField );

//general.errLog("nwValueStr: "+nwValueStr,AIU);

    if (nwValueStr != null && nwValueStr.length() > 0) {
      nwValue = Double.parseDouble(nwValueStr);
    }

    // subtotal value of pledged asset or secured liability
    //
    secSubTtlValueStr = (String) nwNode.getSystemData(nodeFieldNameSecSubTtl);

//general.errLog("secSubTtlValueStr: "+secSubTtlValueStr,AIU);

    if (secSubTtlValueStr != null && secSubTtlValueStr.length() > 0) {
      secSubTtlValue = Double.parseDouble(secSubTtlValueStr);
    }

    unsecSubTtlValueStr = (String) nwNode.getSystemData(nodeFieldNameUnsecSubTtl);

//general.errLog("unsecSubTtlValueStr: "+unsecSubTtlValueStr,AIU);

    if (unsecSubTtlValueStr != null && unsecSubTtlValueStr.length() > 0) {
      unsecSubTtlValue = Double.parseDouble(unsecSubTtlValueStr);
    }

    // total value of pledged assets or secured liabilities
    //
    ttlSecValStr = (String) nwNode.getSystemData(nodeFieldNameSecTtl);

//general.errLog("ttlSecValStr: "+ttlSecValStr,AIU);

    if (ttlSecValStr != null && ttlSecValStr.length() > 0) {
      ttlSecVal = Double.parseDouble(ttlSecValStr);
    }

    ttlUnsecValStr = (String) nwNode.getSystemData(nodeFieldNameUnsecTtl);

//general.errLog("ttlUnsecValStr: "+ttlUnsecValStr,AIU);

    if (ttlUnsecValStr != null && ttlUnsecValStr.length() > 0) {
      ttlUnsecVal = Double.parseDouble(ttlUnsecValStr);
    }

    // total value of assets or liabilities
    //
    ttlValueStr = (String) nwNode.getSystemData(nodeFieldNameTtl);

//general.errLog("ttlValueStr: "+ttlValueStr,AIU);

    if (ttlValueStr != null && ttlValueStr.length() > 0) {
      ttlValue = Double.parseDouble(ttlValueStr);
    }


      // In this section we deal with 3 cases: save the new added NWitem, load the
      // NWitem form if the user click "EditNWitem", and reload the form when the
      // user delete the NWItem.
      //

//general.errLog("SAVE SECURED: "+(secPlgTypD != null && secPlgTypD.equals(CSFieldValues.TRUE_STRING)),AIU);

        // If the user save the added NWItem
        //
        if (secPlgTypD != null && secPlgTypD.equals(CSFieldValues.TRUE_STRING)) {


          secSubTtlValue += nwValue;

//general.errLog("SAVE secSubTtlValue: "+secSubTtlValue,AIU);

          ttlSecVal += nwValue;

//general.errLog("SAVE ttlSecVal: "+ttlSecVal,AIU);

          //outFieldsHash.put(csFieldNameSecSubTtl, String.valueOf(secSubTtlValue));

          // for populating the total values in vista "Owner_Principal_Net_Worth.sb"
          //
          // outFieldsHash.put(csFieldNameSecTtl, String.valueOf(ttlSecVal));
          //
          bwrNode.setFieldData( username, csFieldNameSecTtl, String.valueOf(ttlSecVal) );

          nwNode.setSystemData(nodeFieldNameSecSubTtl,
                               String.valueOf(secSubTtlValue));
          nwNode.setSystemData(nodeFieldNameSecTtl,
                               String.valueOf(ttlSecVal));
        }
        else {
          unsecSubTtlValue += nwValue;

//general.errLog("SAVE unsecSubTtlValue: "+unsecSubTtlValue,AIU);

          ttlUnsecVal += nwValue;

//general.errLog("SAVE ttlUnsecVal: "+ttlUnsecVal,AIU);

          //outFieldsHash.put(csFieldNameUnsecSubTtl, String.valueOf(unsecSubTtlValue));

          // for populating the total values in vista "Owner_Principal_Net_Worth.sb"
          //
          // outFieldsHash.put(csFieldNameUnsecTtl, String.valueOf(ttlUnsecVal));
          //
          bwrNode.setFieldData( username, csFieldNameUnsecTtl, String.valueOf(ttlUnsecVal) );

          nwNode.setSystemData(nodeFieldNameUnsecSubTtl,
                               String.valueOf(unsecSubTtlValue));
          nwNode.setSystemData(nodeFieldNameUnsecTtl,
                               String.valueOf(ttlUnsecVal));
        }

        subTtlValue = secSubTtlValue + unsecSubTtlValue;

//general.errLog("SAVE subTtlValue: "+subTtlValue,AIU);

        ttlValue += nwValue;

//general.errLog("SAVE ttlValue: "+ttlValue,AIU);

        //outFieldsHash.put(csFieldNameSubTtl, String.valueOf(subTtlValue));

        nwNode.setSystemData("!" + nwSubType,
                             String.valueOf(subTtlValue));
        nwNode.setSystemData(nodeFieldNameTtl,
                             String.valueOf(ttlValue));

        // for populating the total values in vista "Owner_Principal_Net_Worth.sb"
        //
        // outFieldsHash.put(csFieldNameTtl, String.valueOf(ttlValue));
        //
        bwrNode.setFieldData( username, csFieldNameTtl, String.valueOf(ttlValue) );

//general.errLog("END updateTotalValues(...)",AIU);

  } // updateTotalValues

  // updateTotalNetWorth
  //
  /**
   *   A method that updates the total value of net worth.
   *   @param   nwNode  a data node containg net worth data.
   *   @param   outFieldsHash  a hash table contains fields and field values.
   *   @return  none.
   *   @exception none
   */
  public static void updateTotalNetWorth( String username, DataNode bwrNode, DataNode nwNode) {
    String atTtlAstStr = null;
    String atTtlLiStr = null;

    double atTtlAst = 0.0D;
    double atTtlLi  = 0.0D;
    double atNtWrth = 0.0D;

    atTtlAstStr = (String) bwrNode.getFieldData( username, CSFieldNames.FN_BWR_TTL_AST );
    atTtlLiStr  = (String) bwrNode.getFieldData( username, CSFieldNames.FN_BWR_TTL_LI );

    if (atTtlAstStr != null && atTtlAstStr.length() > 0) {
      atTtlAst = Double.parseDouble(atTtlAstStr);
    }

    if (atTtlLiStr != null && atTtlLiStr.length() > 0) {
      atTtlLi = Double.parseDouble(atTtlLiStr);
    }

    atNtWrth = atTtlAst - atTtlLi;

    bwrNode.setFieldData( username, CSFieldNames.FN_BWR_NT_WRTH, String.valueOf(atNtWrth) );
    nwNode.setSystemData(CSFieldNames.FN_SYS_NT_WRTH, String.valueOf(atNtWrth));
  } // updateTotalNetWorth

  /**
   * Send an email notification to the customer. Called from PSECUBookingMonitor.
   * This method may be called from another cartridge. So it has been updated to
   * handle other customers besides PSECU. Parameters were added to handle PSECU
   * specifications. Do not send email for product # 44
   *
   * @return String
   */
  public static String sendEmailNotificationForPrelimDocs( SystemDataObject sdo )
  {
   //S1Log.getLogInstance().log("START sendEmailNotificationForPrelimDocs(sdo)",LOG_FILE);
   StringBuffer sb = new StringBuffer();

   DataNode appDN = sdo.getNodeData(NodeUtils.APP_DN_TYPE);

   String memberPrintOption = (String)appDN.getFieldData( CSFieldValues.EMPTY_STRING, "anPrnOptD" );
   //S1Log.getLogInstance().log("memberPrintOption: "+memberPrintOption,LOG_FILE);

   if( memberPrintOption != null && (memberPrintOption.trim().toLowerCase().equals("yes")||memberPrintOption.trim().toLowerCase().equals("true")))
   {
     String sdoId = (String)appDN.getFieldData( CSFieldValues.EMPTY_STRING, "anAppId" );
     String refId = (String)appDN.getFieldData( CSFieldValues.EMPTY_STRING, "anRefId" );

     boolean docsExist = false;

     try
     {
       docsExist = preliminaryDocsExist(refId);
     }
     catch( Exception e )
     {
       e.printStackTrace();
       sb.append(" Unable to determine if the Preliminary Document Set exists for this application. App Id: "+refId+" Error: "+e);
     }

     //S1Log.getLogInstance().log("if( docsExist ): "+( docsExist ),LOG_FILE);
     if( docsExist )
     {
       String CONFIG_DIR       = "config";
       String CONFIG_FILE_NAME = "xml2ms.ini";

       Configuration cfg = new Configuration();
       cfg.load( CONFIG_DIR + File.separator + CONFIG_FILE_NAME );

       //S1Log.getLogInstance().log("***** SEND PRINT EMAIL NOTIFICATION *****",LOG_FILE);
       String emailFlag = cfg.getSectionProperty("Settings", "webPrintEmailControlFlag");
       //S1Log.getLogInstance().log("emailFlag: "+emailFlag,LOG_FILE);

       boolean emailNotificationFlag = emailFlag != null && emailFlag.trim().toLowerCase().equals("true");
       //S1Log.getLogInstance().log("emailNotificationFlag: "+emailNotificationFlag,LOG_FILE);

       if( emailNotificationFlag )
       {
         String productID = null;

         String appTypeBusOrCon = (String)appDN.getSystemData("!type");
         //S1Log.getLogInstance().log("appTypeBusOrCon: "+appTypeBusOrCon,LOG_FILE);

         if( appTypeBusOrCon != null && appTypeBusOrCon.trim().equals(CSFieldValues.FV_SB_TYPE) )
         {
           // business application
           //
           // String productID = (String)appDN.getFieldData( CSFieldValues.EMPTY_STRING, CSFieldNames.FN_SBPRODUCT_ID );
           //
           productID = (String)appDN.getFieldData( CSFieldValues.EMPTY_STRING, CSFieldNames.FN_SBPRODUCT_ID );
           //S1Log.getLogInstance().log("SB productID: "+productID,LOG_FILE);
           //general.errLog("BUS productID: "+productID, "WebDocPrntChk.log");
         }
         else if( appTypeBusOrCon != null && appTypeBusOrCon.trim().equals(CSFieldValues.FV_CON_TYPE) )
         {
           // consumer application
           //
           // String productID = (String)appDN.getFieldData( CSFieldValues.EMPTY_STRING, CSFieldNames.FN_PRODUCT_ID );
           //
           productID = (String)appDN.getFieldData( CSFieldValues.EMPTY_STRING, CSFieldNames.FN_PRODUCT_ID );
           //S1Log.getLogInstance().log("CON: productID: "+productID,LOG_FILE);
           //general.errLog("CON productID: "+productID, "WebDocPrntChk.log");
         }

         // mailed to primary borrower only
         //
         DataNode bwrDN = appDN.getReference(NodeUtils.BWR_DN_TYPE, 0);

         String emailAddress = (String) bwrDN.getFieldData("", "atEmail");
         //S1Log.getLogInstance().log("emailAddress: " + emailAddress,LOG_FILE);

         // only send the email once, docs have already been printed
         //
         // String prlmDocPrinted = (String) appDN.getFieldData(CSFieldValues.EMPTY_STRING, "anPrlmDocPrntd");
         // //S1Log.getLogInstance().log("prlmDocPrinted: " + prlmDocPrinted,LOG_FILE);
         //
         // 5-27-08
         //
         // MAKE CALL TO NEW DATABASE TABLE xntWebPrintEmail
         // AND GET THE PRINT FLAGS FOR THE APPLICATION
         //
         boolean notificationEmailSent = false;

         try
         {
           notificationEmailSent = notificationEmailSent( refId, sdoId, "Preliminary" );
         }
         catch( Exception e )
         {
           e.printStackTrace();
         }

         //S1Log.getLogInstance().log("System Data Hash: " +appDN.getSystemData(),LOG_FILE);
         String prlmDocEmailSent = (String) appDN.getSystemData("!prlmDocEmailSent");
         //S1Log.getLogInstance().log("prlmDocEmailSent: " +prlmDocEmailSent,LOG_FILE);

         //
         // if (emailAddress != null && emailAddress.trim().length() > 0 &&
         //    (prlmDocPrinted == null || prlmDocPrinted.trim().equals(CSFieldValues.FALSE_STRING)))
         //
         // if (emailAddress != null && emailAddress.trim().length() > 0 &&
         //    (prlmDocPrinted == null || prlmDocPrinted.trim().equals(CSFieldValues.FALSE_STRING)))
         //
         // change app node flag to system flag
         //
         //
         // if (emailAddress != null && emailAddress.trim().length() > 0 )
         //
         // if (emailAddress != null && emailAddress.trim().length() > 0 &&
         //     (prlmDocEmailSent == null || prlmDocEmailSent.trim().equals(CSFieldValues.FALSE_STRING)))
         //
         //
         //S1Log.getLogInstance().log("if( ! notificationEmailSent ): " +( ! notificationEmailSent ),LOG_FILE);

         Date todaysDate = new Date();
         SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
         String emailDate = formatDateTime( todaysDate, dateFormat );

         // String customerName = System.getProperty("Customer");
         //
         String customerName = SystemProperties.getProperty( CSFieldNames.SYS_CUSTOMER );
         //S1Log.getLogInstance().log("customerName: " + customerName,LOG_FILE);

         // if( (! notificationEmailSent) &&
         //     (productID != null && (! productID.trim().equals("44")) ) &&
         //     (customerName != null && customerName.trim().toLowerCase().equals("psecu")) )
         //
         if( (! notificationEmailSent) )
         {
           //S1Log.getLogInstance().log("if( customerName != null && customerName.trim().toLowerCase().equals(psecu) ): " + ( customerName != null && customerName.trim().toLowerCase().equals("psecu") ),LOG_FILE);

           // PSECU SPEC - DO not send email for product # 44
           //
           if( customerName != null && customerName.trim().toLowerCase().equals("psecu") )
           {
             //S1Log.getLogInstance().log("if( productID != null && (! productID.trim().equals(44)) ): " + ( productID != null && (! productID.trim().equals("44")) ),LOG_FILE);

             if( productID != null && (! productID.trim().equals("44")) )
             {
               //S1Log.getLogInstance().log("if( emailAddress != null && emailAddress.trim().length() > 0 ): " + ( emailAddress != null && emailAddress.trim().length() > 0 ),LOG_FILE);

               if( emailAddress != null && emailAddress.trim().length() > 0 )
               {
                 try
                 {
                   //S1Log.getLogInstance().log("*** send email notification ***",LOG_FILE);

                   // send email notification that the documents are being generated
                   //
                   MailMessage mailObj = new MailMessage();

                   List recipients = new ArrayList();
                   recipients.add(emailAddress.trim());

                   if (recipients != null && !recipients.isEmpty())
                   {
                     mailObj.setRecipients(recipients);
                   }
                   else
                   {
                     throw new Exception("Invalid email recipients list. Email To: " + recipients);
                   }

                   // check for specific email settings by product
                   // if not use default settings
                   //
                   String sectionName = "Preliminary Doc Settings - "+productID;
                   //S1Log.getLogInstance().log("sectionName: " + sectionName,LOG_FILE);

                   //S1Log.getLogInstance().log("if( ! cfg.containsSection( sectionName ) ): " + ( ! cfg.containsSection( sectionName ) ),LOG_FILE);
                   if( ! cfg.containsSection( sectionName ) )
                   {
                     sectionName = "Preliminary Doc Settings";

                     if( ! cfg.containsSection( sectionName ) )
                     {
                       throw new Exception("Invalid configuration file section name. Section Name: "+sectionName);
                     }
                   }

                   String emailFrom = cfg.getSectionProperty(sectionName, "from");
                   //S1Log.getLogInstance().log("emailFrom: " + emailFrom,LOG_FILE);

                   if (emailFrom != null && emailFrom.trim().length() > 0)
                   {
                     mailObj.setFrom(emailFrom);
                   }
                   else
                   {
                     throw new Exception("Invalid email address for sender. Email From: " + emailFrom);
                   }

                   String emailSubject = cfg.getSectionProperty(sectionName, "subject");
                   //S1Log.getLogInstance().log("emailSubject: " + emailSubject,LOG_FILE);
                   if (emailSubject != null && emailSubject.trim().length() > 0)
                   {
                     mailObj.setSubject(emailSubject);
                   }
                   else
                   {
                     throw new Exception("Invalid email subject line. Subject Line: " + emailSubject);
                   }

                   String emailBody = cfg.getSectionProperty(sectionName, "body");
                   //S1Log.getLogInstance().log("emailBody: " + emailBody,LOG_FILE);
                   if (emailBody != null && emailBody.trim().length() > 0)
                   {
                     mailObj.setBody(emailBody);
                   }
                   else
                   {
                     throw new Exception("Invalid email body. Body Text: " + emailBody);
                   }

                   // add images
                   //
                   String tagName = cfg.getSectionProperty(sectionName, "tagName");
                   //S1Log.getLogInstance().log("tagName: " + tagName,LOG_FILE);

                   // tagName means images
                   //
                   if( tagName != null && tagName.trim().length() > 0 )
                   {
                     // seperate by ;
                     //
                     List tagList = new ArrayList();
                     List fileList = new ArrayList();

                     StringTokenizer tok = new StringTokenizer(tagName,";");
                     while( tok.hasMoreTokens() )
                     {
                       tagList.add(tok.nextToken());
                     }

                     String imageFile = cfg.getSectionProperty(sectionName, "imageFile");
                     //S1Log.getLogInstance().log("imageFile: " + imageFile,LOG_FILE);

                     // seperate by ;
                     //
                     tok = new StringTokenizer(imageFile, ";");
                     while (tok.hasMoreTokens())
                     {
                       fileList.add(tok.nextToken());
                     }

                     for (int i = 0, c = tagList.size(); i < c; ++i)
                     {
                       mailObj.addInlineImage((String)tagList.get(i), (String)fileList.get(i));
                     }

                   } // if( tagName != null && tagName.trim().length() > 0 )

                   //S1Log.getLogInstance().log("BEFORE SEND mailObj: " + mailObj,LOG_FILE);

                   mailObj.sendMessage();

                   //S1Log.getLogInstance().log("AFTER SEND  mailObj: " + mailObj,LOG_FILE);

                   // set email sent for prelin docs app node system data field
                   //
                   //                   !prlmDocEmailSent
                   appDN.setSystemData("!prlmDocEmailSent", CSFieldValues.TRUE_STRING);

                   // update database email message mailed successfully
                   // table should exist
                   //
                   String sql = null;
                   try
                   {
                     boolean insert = insertIntoWebPrintEmail( sdoId, refId, "Preliminary" );

                     if( insert )
                     {
                       sql = "INSERT INTO xntWebPrintEmail ( nAppId, nRefId, cDocSet, dtNotification, bEmailNotificationSent, cEmailAddress ) VALUES ( " + sdoId + ", " + refId + ", 'Preliminary', '" + emailDate + "', 't', '" + emailAddress + "' )";
                     }
                     else
                     {
                       sql = "UPDATE xntWebPrintEmail SET dtNotification = '" + emailDate +"', bEmailNotificationSent='t', cEmailAddress='" + emailAddress + "' WHERE nAppId= " + sdoId + " AND nRefId=" + refId + " AND cDocSet= 'Preliminary'";
                     }

                     //S1Log.getLogInstance().log("sql: " + sql, LOG_FILE);

                     HashMap hm = DbHelper.getInstance().executeUpdate( sql );
                     //S1Log.getLogInstance().log("HashMap hm = " + hm, LOG_FILE);
                   }
                   catch( Exception sqlE )
                   {
                     sqlE.printStackTrace();
                     String sqlMsg = "SQL Exception: sql: "+sql+" Error: "+sqlE.getMessage();
                     DBLogger.log( sqlMsg);
                     throw new Exception( sqlMsg );
                   }

                 }
                 catch (Exception e)
                 {
                   // do not throw error
                   //
                   e.printStackTrace();

                   String msg = "An error occurred while sending Preliminary Doc Set notification email to "+emailAddress+". Error: "+e.getMessage();
                   //AdminGUIManager.displayE(msg);
                   //S1Log.getLogInstance().log(msg,LOG_FILE);
                   sb.append(msg);

                   String sql = null;
                   try
                   {
                     boolean insert = AppImportUtils.insertIntoWebPrintEmail( sdoId, refId, "Preliminary" );

                     String dbErrorMsg = "AppImportUtils: "+emailDate+" - Error Msg: "+msg;

                     if( insert )
                     {
                       sql = "INSERT INTO xntWebPrintEmail ( nAppId, nRefId, cDocSet, dtNotificationError, bEmailNotificationSent, cEmailNotificationError, cEmailAddress ) VALUES ( " + sdoId + ", " + refId + ", 'Preliminary', '" + emailDate + "', 'f', '" + dbErrorMsg +"', '" + emailAddress + "' )";
                       //S1Log.getLogInstance().log( "sql: " + sql, LOG_FILE );
                     }
                     else
                     {
                       sql = "UPDATE xntWebPrintEmail SET dtNotificationError='" + emailDate + "', bEmailNotificationSent= 'f', cEmailNotificationError='" + dbErrorMsg + "', cEmailAddress='"+emailAddress+"' WHERE nAppId="+sdoId+" AND nRefId="+refId+" AND cDocSet='Preliminary'";
                       //S1Log.getLogInstance().log( "sql: " + sql, LOG_FILE );
                     }

                     HashMap hm = DbHelper.getInstance().executeUpdate( sql );
                     //S1Log.getLogInstance().log("HashMap hm = " + hm, LOG_FILE);
                   }
                   catch( Exception sqlE )
                   {
                     sqlE.printStackTrace();
                     DBLogger.log( "SQL Exception: sql: "+sql+" Error: "+sqlE.getMessage());
                   }

                 } // try/catch

               }
               else
               {
                 //String msg = "An error occurred while sending Preliminary Doc Set notification email to "+emailAddress+". Error: "+e;
                 //AdminGUIManager.displayE(msg);
                 //S1Log.getLogInstance().log(msg,LOG_FILE);
                 //
                 sb.append(" Invalid customer email address. Email Address: "+emailAddress);

                 // INVALID EMAIL ADDRESS
                 //
                 // update database email message mail error
                 // table should exist
                 //
                 String sql = null;
                 try
                 {
                   boolean insert = AppImportUtils.insertIntoWebPrintEmail( sdoId, refId, "Preliminary" );

                   String dbErrorMsg = "AppImportUtils: "+emailDate+" - Invalid email address. Email Address: "+emailAddress;

                   if( insert )
                   {
                     sql = "INSERT INTO xntWebPrintEmail ( nAppId, nRefId, cDocSet, dtNotificationError, bEmailNotificationSent, cEmailNotificationError ) VALUES ( " + sdoId + ", " + refId + ", 'Preliminary', '" + emailDate + "', 'f', '" + dbErrorMsg + "' )";
                     //S1Log.getLogInstance().log( "sql: " + sql, LOG_FILE );
                   }
                   else
                   {
                    sql = "UPDATE xntWebPrintEmail SET dtNotificationError = '"+emailDate+"', bEmailNotificationSent= 'f', cEmailNotificationError= '"+dbErrorMsg+"' WHERE nAppId= "+sdoId+" AND nRefId="+refId+" AND cDocSet= 'Preliminary'";
                    //S1Log.getLogInstance().log("sql: " + sql, LOG_FILE);
                   }

                   HashMap hm = DbHelper.getInstance().executeUpdate( sql );
                   //S1Log.getLogInstance().log("HashMap hm = " + hm, LOG_FILE);
                 }
                 catch( Exception sqlE )
                 {
                   sqlE.printStackTrace();
                   DBLogger.log( "SQL Exception: sql: "+sql+" Error: "+sqlE.getMessage());
                 }

               } // if / else ( emailAddress != null && emailAddress.trim().length() > 0 )

             } // if( productID != null && (! productID.trim().equals("44")) )

           }
           else
           {
            if( emailAddress != null && emailAddress.trim().length() > 0 )
            {
              try
              {
                //S1Log.getLogInstance().log("*** send email notification ***",LOG_FILE);

                // send email notification that the documents are being generated
                //
                MailMessage mailObj = new MailMessage();

                List recipients = new ArrayList();
                recipients.add(emailAddress.trim());

                if (recipients != null && !recipients.isEmpty())
                {
                  mailObj.setRecipients(recipients);
                }
                else
                {
                  throw new Exception("Invalid email recipients list. Email To: " + recipients);
                }

                // check for specific email settings by product
                // if not use default settings
                //
                String sectionName = "Preliminary Doc Settings - "+productID;
                //S1Log.getLogInstance().log("sectionName: " + sectionName,LOG_FILE);

                //S1Log.getLogInstance().log("if( ! cfg.containsSection( sectionName ) ): " + ( ! cfg.containsSection( sectionName ) ),LOG_FILE);
                if( ! cfg.containsSection( sectionName ) )
                {
                  sectionName = "Preliminary Doc Settings";

                  if( ! cfg.containsSection( sectionName ) )
                  {
                    throw new Exception("Invalid configuration file section name. Section Name: "+sectionName);
                  }
                }

                String emailFrom = cfg.getSectionProperty(sectionName, "from");
                //S1Log.getLogInstance().log("emailFrom: " + emailFrom,LOG_FILE);

                if (emailFrom != null && emailFrom.trim().length() > 0)
                {
                  mailObj.setFrom(emailFrom);
                }
                else
                {
                  throw new Exception("Invalid email address for sender. Email From: " + emailFrom);
                }

                String emailSubject = cfg.getSectionProperty(sectionName, "subject");
                //S1Log.getLogInstance().log("emailSubject: " + emailSubject,LOG_FILE);
                if (emailSubject != null && emailSubject.trim().length() > 0)
                {
                  mailObj.setSubject(emailSubject);
                }
                else
                {
                  throw new Exception("Invalid email subject line. Subject Line: " + emailSubject);
                }

                String emailBody = cfg.getSectionProperty(sectionName, "body");
                //S1Log.getLogInstance().log("emailBody: " + emailBody,LOG_FILE);
                if (emailBody != null && emailBody.trim().length() > 0)
                {
                  mailObj.setBody(emailBody);
                }
                else
                {
                  throw new Exception("Invalid email body. Body Text: " + emailBody);
                }

                // add images
                //
                String tagName = cfg.getSectionProperty(sectionName, "tagName");
                //S1Log.getLogInstance().log("tagName: " + tagName,LOG_FILE);

                // tagName means images
                //
                if( tagName != null && tagName.trim().length() > 0 )
                {
                  // seperate by ;
                  //
                  List tagList = new ArrayList();
                  List fileList = new ArrayList();

                  StringTokenizer tok = new StringTokenizer(tagName,";");
                  while( tok.hasMoreTokens() )
                  {
                    tagList.add(tok.nextToken());
                  }

                  String imageFile = cfg.getSectionProperty(sectionName, "imageFile");
                  //S1Log.getLogInstance().log("imageFile: " + imageFile,LOG_FILE);

                  // seperate by ;
                  //
                  tok = new StringTokenizer(imageFile, ";");
                  while (tok.hasMoreTokens())
                  {
                    fileList.add(tok.nextToken());
                  }

                  for (int i = 0, c = tagList.size(); i < c; ++i)
                  {
                    mailObj.addInlineImage((String)tagList.get(i), (String)fileList.get(i));
                  }

                } // if( tagName != null && tagName.trim().length() > 0 )

                //S1Log.getLogInstance().log("BEFORE SEND mailObj: " + mailObj,LOG_FILE);

                mailObj.sendMessage();

                //S1Log.getLogInstance().log("AFTER SEND  mailObj: " + mailObj,LOG_FILE);

                // set email sent for prelin docs app node system data field
                //
                //                   !prlmDocEmailSent
                appDN.setSystemData("!prlmDocEmailSent", CSFieldValues.TRUE_STRING);

                // update database email message mailed successfully
                // table should exist
                //
                String sql = null;
                try
                {
                  boolean insert = insertIntoWebPrintEmail( sdoId, refId, "Preliminary" );

                  if( insert )
                  {
                    sql = "INSERT INTO xntWebPrintEmail ( nAppId, nRefId, cDocSet, dtNotification, bEmailNotificationSent, cEmailAddress ) VALUES ( " + sdoId + ", " + refId + ", 'Preliminary', '" + emailDate + "', 't', '" + emailAddress + "' )";
                  }
                  else
                  {
                    sql = "UPDATE xntWebPrintEmail SET dtNotification = '" + emailDate +"', bEmailNotificationSent='t', cEmailAddress='" + emailAddress + "' WHERE nAppId= " + sdoId + " AND nRefId=" + refId + " AND cDocSet= 'Preliminary'";
                  }

                  //S1Log.getLogInstance().log("sql: " + sql, LOG_FILE);

                  HashMap hm = DbHelper.getInstance().executeUpdate( sql );
                  //S1Log.getLogInstance().log("HashMap hm = " + hm, LOG_FILE);
                }
                catch( Exception sqlE )
                {
                  sqlE.printStackTrace();
                  String sqlMsg = "SQL Exception: sql: "+sql+" Error: "+sqlE.getMessage();
                  DBLogger.log( sqlMsg);
                  throw new Exception( sqlMsg );
                }

              }
              catch (Exception e)
              {
                // do not throw error
                //
                e.printStackTrace();

                String msg = "An error occurred while sending Preliminary Doc Set notification email to "+emailAddress+". Error: "+e.getMessage();
                //AdminGUIManager.displayE(msg);
                //S1Log.getLogInstance().log(msg,LOG_FILE);
                sb.append(msg);

                String sql = null;
                try
                {
                  boolean insert = AppImportUtils.insertIntoWebPrintEmail( sdoId, refId, "Preliminary" );

                  String dbErrorMsg = "AppImportUtils: "+emailDate+" - Error Msg: "+msg;

                  if( insert )
                  {
                    sql = "INSERT INTO xntWebPrintEmail ( nAppId, nRefId, cDocSet, dtNotificationError, bEmailNotificationSent, cEmailNotificationError, cEmailAddress ) VALUES ( " + sdoId + ", " + refId + ", 'Preliminary', '" + emailDate + "', 'f', '" + dbErrorMsg +"', '" + emailAddress + "' )";
                    //S1Log.getLogInstance().log( "sql: " + sql, LOG_FILE );
                  }
                  else
                  {
                    sql = "UPDATE xntWebPrintEmail SET dtNotificationError='" + emailDate + "', bEmailNotificationSent= 'f', cEmailNotificationError='" + dbErrorMsg + "', cEmailAddress='"+emailAddress+"' WHERE nAppId="+sdoId+" AND nRefId="+refId+" AND cDocSet='Preliminary'";
                    //S1Log.getLogInstance().log( "sql: " + sql, LOG_FILE );
                  }

                  HashMap hm = DbHelper.getInstance().executeUpdate( sql );
                  //S1Log.getLogInstance().log("HashMap hm = " + hm, LOG_FILE);
                }
                catch( Exception sqlE )
                {
                  sqlE.printStackTrace();
                  DBLogger.log( "SQL Exception: sql: "+sql+" Error: "+sqlE.getMessage());
                }

              } // try/catch

            }
            else
            {
              //String msg = "An error occurred while sending Preliminary Doc Set notification email to "+emailAddress+". Error: "+e;
              //AdminGUIManager.displayE(msg);
               //S1Log.getLogInstance().log(msg,LOG_FILE);
              sb.append(" Invalid customer email address. Email Address: "+emailAddress);

              // INVALID EMAIL ADDRESS
              //
              // update database email message mail error
              // table should exist
              //
              String sql = null;
              try
              {
                boolean insert = AppImportUtils.insertIntoWebPrintEmail( sdoId, refId, "Preliminary" );

                String dbErrorMsg = "AppImportUtils: "+emailDate+" - Invalid email address. Email Address: "+emailAddress;

                if( insert )
                {
                  sql = "INSERT INTO xntWebPrintEmail ( nAppId, nRefId, cDocSet, dtNotificationError, bEmailNotificationSent, cEmailNotificationError ) VALUES ( " + sdoId + ", " + refId + ", 'Preliminary', '" + emailDate + "', 'f', '" + dbErrorMsg + "' )";
                  //S1Log.getLogInstance().log( "sql: " + sql, LOG_FILE );
                }
                else
                {
                 sql = "UPDATE xntWebPrintEmail SET dtNotificationError = '"+emailDate+"', bEmailNotificationSent= 'f', cEmailNotificationError= '"+dbErrorMsg+"' WHERE nAppId= "+sdoId+" AND nRefId="+refId+" AND cDocSet= 'Preliminary'";
                 //S1Log.getLogInstance().log("sql: " + sql, LOG_FILE);
                }

                HashMap hm = DbHelper.getInstance().executeUpdate( sql );
                //S1Log.getLogInstance().log("HashMap hm = " + hm, LOG_FILE);
              }
              catch( Exception sqlE )
              {
                sqlE.printStackTrace();
                DBLogger.log( "SQL Exception: sql: "+sql+" Error: "+sqlE.getMessage());
              }

            } // if / else ( emailAddress != null && emailAddress.trim().length() > 0 )

          } // if / else ( customerName != null && customerName.trim().toLowerCase().equals("psecu") )

         }
         else
         {
           //String msg = "An error occurred while sending Preliminary Doc Set notification email to "+emailAddress+". Error: "+e;
           //AdminGUIManager.displayE(msg);
            //S1Log.getLogInstance().log(msg,LOG_FILE);
           //
           sb.append(" Notification email has already been sent.");

         } // if ( ! notificationEmailSent )

       } // if ( emailNotificationFlag )

     } // if ( docsExist )
     else
     {
       sb.append(" Preliminary documents for this application do not exist.");
     }

   } // if( memberPrintOption != null && (memberPrintOption.trim().toLowerCase().equals("yes")||memberPrintOption.trim().toLowerCase().equals("true")))

   //S1Log.getLogInstance().log("System Data Hash: " +appDN.getSystemData(),LOG_FILE);
   //S1Log.getLogInstance().log("END sendEmailNotificationForPrelimDocs(sdo)",LOG_FILE);

   return sb.toString();
  }


 private static void createLogFile()
 {
   String fileName = "AppImportUtils.log";
   String dirPath  = FileManager.getLogPath() + File.separator;

   File dir = new File( dirPath );

   if (! dir.exists() )
   {
     dir.mkdirs();
   }

   dir = null;

   LOG_FILE = new DataFile( dirPath, fileName, false) ;
 }

 public static boolean preliminaryDocsExist( String refId ) throws Exception
   {
     //S1Log.getLogInstance().log("START preliminaryDocsExist( String refId )",LOG_FILE);

     boolean docsExist = false;

     String  EDOC_ARCH_PDF_PATH = null;
     String  CONFIG_FILE = "config" + File.separator + "DocPrep.ini";

     // From DocPrep.ini
     // EDOC_ARCH_PDF_PATH=D:\MS_Gor_4.0\data\DocPrep1\PDFs\
     //
     Configuration config = new Configuration();
     config.load( CONFIG_FILE );

     //S1Log.getLogInstance().log("if( config != null && ! config.isEmpty() ): "+( config != null && ! config.isEmpty() ),LOG_FILE);

     if( config != null && ! config.isEmpty() )
     {
       Map settings = config.getSectionProperties("Settings");

       if (settings != null)
       {
         EDOC_ARCH_PDF_PATH = (String) settings.get("EDOC_ARCH_PDF_PATH");
         //S1Log.getLogInstance().log("EDOC_ARCH_PDF_PATH: "+EDOC_ARCH_PDF_PATH,LOG_FILE);
       }
     }

     //S1Log.getLogInstance().log("if( EDOC_ARCH_PDF_PATH != null ... ): "+( EDOC_ARCH_PDF_PATH != null && EDOC_ARCH_PDF_PATH.trim().length() > 0 ),LOG_FILE);

     if( EDOC_ARCH_PDF_PATH != null && EDOC_ARCH_PDF_PATH.trim().length() > 0 )
     {
       //S1Log.getLogInstance().log("if( ! EDOC_ARCH_PDF_PATH.endsWith(\\) ): "+( ! EDOC_ARCH_PDF_PATH.endsWith("\\")),LOG_FILE);

       if( ! EDOC_ARCH_PDF_PATH.endsWith("\\") )
       {
         EDOC_ARCH_PDF_PATH = EDOC_ARCH_PDF_PATH + File.separator;
       }

       File archivePath = new File(EDOC_ARCH_PDF_PATH);

       //S1Log.getLogInstance().log("if( archivePath != null && ! archivePath.exists() ): "+( archivePath != null && ! archivePath.exists() ),LOG_FILE);

       if( archivePath != null && ! archivePath.exists() )
       {
         //S1Log.getLogInstance().log("The document archive directory does not exist. Archive Path: "+archivePath,LOG_FILE);
         throw new Exception("The document archive directory does not exist.");
       }

       // if the Stage_Preliminary.LOG exists the preliminary documents have
       // already been printed. Set boolean docsExist to 'true'
       //
       String logFilePath = EDOC_ARCH_PDF_PATH + refId + File.separator + "Stage_Preliminary.LOG";
       //S1Log.getLogInstance().log("logFilePath: "+logFilePath,LOG_FILE);

       if( logFilePath != null && logFilePath.trim().length() > 0 )
       {
         File prelimDocLog = new File( logFilePath );

         //S1Log.getLogInstance().log("if( prelimDocLog != null && prelimDocLog.exists() ): "+( prelimDocLog != null && prelimDocLog.exists() ),LOG_FILE);

         if( prelimDocLog != null && prelimDocLog.exists() )
         {
           docsExist = true;
           //S1Log.getLogInstance().log("docsExist: "+docsExist,LOG_FILE);
         }
       }
     }
     else
     {
       //S1Log.getLogInstance().log("Error loading the document file path from the configuration file. Path: "+EDOC_ARCH_PDF_PATH,LOG_FILE);
       throw new Exception("Error loading the document file path from the configuration file. Invalid File Path: "+EDOC_ARCH_PDF_PATH);
     }

     //S1Log.getLogInstance().log("END preliminaryDocsExist( String refId ) return docsExist: "+docsExist,LOG_FILE);

     return docsExist;
   }

   /**
    * this is the method used by XML2MetaSage to create a collateral node. the assumption is that
    * the collateral specification table in the product is set up correctly and the collateral type
    * in the collateral object matches the hard coded collateral type (clTypeFlag) in the xml parsing 
    * method used in the submit application validate classes in the xml2ms.jar
    * 
    * @param sdo SystemDataObject
    * @param appNode DataNode
    * @param collData HashtableX
    * @param prodID String
    */
   public static void setupCollateralNode( SystemDataObject sdo, DataNode appNode,
                                           HashtableX collData,  String productID,
                                           String username, boolean setPrimaryCollateralCode,
                                           boolean APP_TYPE_CONSUMER, boolean APP_TYPE_MORTGAGE )
   throws Exception
   {
     //S1Log.getLogInstance().log("111 setupCollateralNode(...)",LOG_FILE);//S1Log.getLogInstance().log("collData: "+collData,LOG_FILE);

     String collFlag = null;
     VectorX collOwnerList = null;

/*
      "clTypeFlag"
      vpSv.setCollateralType("clTypeFlag", "Savings", REQUIRED, "Savings Account");
      vpCd.setCollateralType("clTypeFlag", "Certificate of Deposit", REQUIRED, "Certificate of Deposit");
      vpOne.setCollateralType("clTypeFlag", clType, REQUIRED, "Collateral Type");
      vpTwo.setCollateralType("clTypeFlag", "Automobile", REQUIRED, "Automobile");
      vpSv.setCollateralType("clTypeFlag", "Savings", REQUIRED, "Savings Account");
      vpCd.setCollateralType("clTypeFlag", "Certificate of Deposit", REQUIRED, "Certificate of Deposit");
      vpOne.setCollateralType("clTypeFlag", clType, REQUIRED, "Collateral Type");
      // vpTwo.setCollateralType("clTypeFlag", clType, REQUIRED, "Collateral Type");
      vpTwo.setCollateralType("clTypeFlag", "Automobile", REQUIRED, "Automobile");


  */
     if( collData.containsKey("clTypeFlag") )
         {
         collFlag = (String)collData.remove("clTypeFlag"); // automobile
         }
     else if( collData.containsKey("phyTypeFlag") )
         {
         collFlag = (String)collData.remove("phyTypeFlag"); // real estate
         }
     else if( collData.containsKey("lwTypeFlag") )
         {
         collFlag = (String)collData.remove("lwTypeFlag"); // mobile home
         }

     //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("0 collFlag: "+collFlag,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);

     if( collFlag != null )
     {
     ////S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("0.1 prodID: "+prodID,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);

     // Fetch the product.
     //
     GenericProduct product = null;
     try
     {
       if( productID != null && productID.trim().length() > 0 )
       {
         if( APP_TYPE_CONSUMER )
         {
           product = CSDataCache.getProductManager().getProduct(productID);
         }
         else if( APP_TYPE_MORTGAGE )
         {
           // mgProd = CSDataCache.getMtgProductManager().getProduct(productID);
           // prod = mgProd;
           product = CSDataCache.getMtgProductManager().getProduct(productID);
         }

         if (product == null)
         {
           String err = "Unable to load product data for this application. The product object value is null.";
           throw new Exception(err);
         }
       }
       else
       {
         String err = "Invalid product identification number. The incoming product ID  ";
         if (productID != null)
         {
           err += "value is NULL.";
         }
         else
         {
           err += "field is empty.";
         }
         throw new Exception(err);
       }
     }
     catch (Exception e)
     {
       e.printStackTrace();
       String err = "An error occurred while loading the product Data. Processing is unable to continue. Product ID: " + productID + " Error: " + e;
       throw new Exception(err);
     }



     //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("0.2 product: "+product,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);

     if( product != null )
       {
       // add non paryt owners for ESL WFE
       //
       //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("if( collData != null && collData.contains(clOwnerList)): "+ ( collData != null && collData.containsKey("clOwnerList") ),LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);

       if( collData != null && collData.containsKey("clOwnerList") )
       {
         collOwnerList = (VectorX)collData.remove("clOwnerList");
         //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("0.1 collOwnerList: "+collOwnerList,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);
       }

       //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("1 INSIDE if (product != null)",LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);

       // get collateral specification table
       //
       String str = product.getCollatSumTbl();

       //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("2 Prd Collat Sum Tbl Str: "+str,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);

       if( str != null )
         {
         //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("3 INSIDE if (str != null)",LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);

         str = StringChanger.getObjectBody(str);

         TableTransaction tt = TableTransaction.stringToObject(str);

         //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("3.1 tt: "+tt,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);

         List recs = tt.getRecords();

         //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("3.2 recs required: "+recs,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);

         // no records means no collateral node to set up, there are not any accepatable
         // collateral specifications set up for this product move on...
         //
         if( recs != null && !recs.isEmpty() )
           {
           //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("4 INSIDE if (recs != null && ! recs.isEmpty())",LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);

           String collID   = null;
           String collType = null;
           String collCode = null;
           String primaryCollateralCode = null;

           // loop through records in the product's collateral summary table to find a
           // match for collateral description and then get the associated id number.
           // use the id to load the collateral object
           //
           // if multiple records and no match is found use the first record
           //
           //
           for( int i=0, c=recs.size(); i<c; i++ )
             {
             String temp = (String)recs.get(i); //  used to get first record

             //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("5 temp: "+temp,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);

             temp = StringChanger.getObjectBody( temp );

             TableRecord tr = TableRecord.stringToObject( temp );

             // column names from the product editor collateral summary table which are also table keys
             //
             // public static final String idLabel = "ID Number";
             //
             // need to get the id number and then load the collateral object
             //
             // set the default to the first acceptable collateral specification
             //
             if( i == 0 )
                 {
                 collID = tr.getField("ID Number");
                 //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("6 collID: "+collID,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);
                 }

             String tempCollID = tr.getField("ID Number");

             //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("6.1 tempCollID: "+tempCollID,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);

             if(tempCollID != null)
               {
               // load the collateral object
               //
               Collateral collateral = CSDataCache.getCollateralManager().getCollateral(tempCollID);

               if (collateral != null)
                 {
                  //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("7 if (collateral != null)",LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);

                 // set the default to the first acceptable collateral specification
                 //
                 if( i == 0 )
                     {
                     collType = collateral.getClTypD(); // Automobile, Boat, CD...
                     //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("7.1 collType: "+collType,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);
                     }

                 // if( setPrimaryCollateralCode )
                 //
                 // if( true )
                 //
                 if( collData == null || (collData != null && (!collData.containsKey("clCdD")) ) )
                 {
                   VectorX clCdM = collateral.getClCdM();
                    //S1Log.getLogInstance().log("clCdM: "+clCdM,LOG_FILE);

                   if( clCdM != null && ! clCdM.isEmpty() )
                     {
                       if( clCdM.size() == 1 )
                       {
                         primaryCollateralCode = (String) clCdM.firstElement();
                          //S1Log.getLogInstance().log("SIZE 1 SET primaryCollateralCode: " + primaryCollateralCode, LOG_FILE);
                       }
                       else
                       {
                         //S1Log.getLogInstance().log("SIZE NOT *1* FIND primaryCollateralCode: " + primaryCollateralCode, LOG_FILE);
                         // check list for matching "new/used" in order to make sure the collateral codes are in sink
                         // currently can select new auto for a used auto and visa versa
                         // if a match is not found do not set
                         //
                         int colLocId = collateral.getLocationID();

                         //S1Log.getLogInstance().log("colLocId: " + colLocId, LOG_FILE);
                         //S1Log.getLogInstance().log("if( collData != null && collData.containsKey(clNwUsdD) ): " + ( collData != null && collData.containsKey("clNwUsdD") ), LOG_FILE);

                         // clNwUsdD
                         //
                         String clNwUsdD = null;
                         if( collData != null && collData.containsKey("clNwUsdD") )
                         {
                           clNwUsdD = (String)collData.get("clNwUsdD");
                           //S1Log.getLogInstance().log("clNwUsdD: " + clNwUsdD, LOG_FILE);
                         }

                         //S1Log.getLogInstance().log("if( clNwUsdD != null && clNwUsdD.trim().length() > 0 &&  (clNwUsdD.trim().toLowerCase().equals(new) || clNwUsdD.trim().toLowerCase().equals(used))): " + ( clNwUsdD != null && clNwUsdD.trim().length() > 0 &&  (clNwUsdD.trim().toLowerCase().equals("new") || clNwUsdD.trim().toLowerCase().equals("used"))), LOG_FILE);
                         if( clNwUsdD != null && clNwUsdD.trim().length() > 0 &&  (clNwUsdD.trim().toLowerCase().equals("new") || clNwUsdD.trim().toLowerCase().equals("used")))
                         {
                           for( int ii=0, cc=clCdM.size(); ii<cc; ii++ )
                           {
                             String clCode = (String)clCdM.get(ii);
                             //S1Log.getLogInstance().log("clCode: " + clCode, LOG_FILE);

                             Map collateralTable = CSDataCache.getCodeTableManager().getDescTableForType( colLocId, "Collateral");
                             //S1Log.getLogInstance().log("collateralTable: " + collateralTable, LOG_FILE);
                             if( collateralTable != null && ! collateralTable.isEmpty() )
                             {
                               String description =  getLabelFromLabelValueTable( collateralTable, clCode );

                               //S1Log.getLogInstance().log("description: " + description, LOG_FILE); if( description != null ){//S1Log.getLogInstance().log("if( description != null && clNwUsdD != null && description.trim().toLowerCase().indexOf( clNwUsdD.trim().toLowerCase() ) != -1 ): " + ( description != null && clNwUsdD != null && description.trim().toLowerCase().indexOf( clNwUsdD.trim().toLowerCase() ) != -1 ), LOG_FILE);}

                               if( description != null && clNwUsdD != null && description.trim().toLowerCase().indexOf( clNwUsdD.trim().toLowerCase() ) != -1 )
                               {
                                 collCode = clCode;
                                 //S1Log.getLogInstance().log("SET collCode = clCode: " + clCode, LOG_FILE);

                                 primaryCollateralCode = clCode;
                                 //S1Log.getLogInstance().log("SET primaryCollateralCode = clCode: " + clCode, LOG_FILE);

                                 break;
                               }
                             }
                           } //  for( int ii=0, cc=clCdM.size(); ii<cc; ii++ )
                         }
                       }
                     }
                 }

                 String tempCollType = collateral.getClTypD();
                 //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("7.2 tempCollType: "+tempCollType,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);
                 //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("7.21 collFlag: "+collFlag,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);

                 // if collateral type automobile, real estate or mobile home
                 //
                 if( tempCollType != null && tempCollType.length() > 0 )
                   {
                   // String collFlag = collType
                   //
                   //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("7.22 if( collFlag.trim().equals( tempCollType.trim() ) ): "+( collFlag.trim().equals( tempCollType.trim() ) ),LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);


                   if( collFlag.trim().equals( tempCollType.trim() ) )
                     {
                     //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("8 collFlag = collDescFromSumTbl",LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);
                     //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("8.0 tempCollType: "+tempCollType,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);

                     collType = tempCollType;
                     collID   = tempCollID;

                     if( primaryCollateralCode != null )
                     {
                       collCode = primaryCollateralCode;
                     }

                     //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("collCode = primaryCollateralCode: "+primaryCollateralCode,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);
                     //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("8.1 collID = tempCollID: "+collID,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);
                     //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("8.2 collType = tempCollType: "+collType,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);

                     //
                     // break from loop just grab first one
                     //
                     break;
                     }

                   }

                 } // if (collateral != null)

               } // if (collID != null)

             } // for( int i=0; i<recs.size(); i++; )

           // now that you have the acceptable collateral type because it is in the
           // product specification table create the node
           //
           //
           //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("9 collType: "+collType,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);
           //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("9.1 collID: "+collID,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);

           DataNode collNode = appNode.getReference(NodeUtils.COLL_DN_TYPE, 0);

           if( collNode == null )
             {
             //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("10 if (collNode== null)",LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);

             // Create collateral container node.
             //
             collNode = sdo.createDataNode(username, NodeUtils.COLL_DN_TYPE);
             collNode.setSystemData("!container", "true");
             appNode.addReference(collNode);
             }  // if collNode == null

//
// START - Set up collateral owner list for gui display
//
           // create and add the collateral owner list to the collateral data map
           //
           VectorX bwrVec = appNode.getReferences( NodeUtils.BWR_DN_TYPE );

           //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("10.1 bwrVec: "+bwrVec,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);

           if( bwrVec != null && bwrVec.size() > 1 )
             {
             VectorX onrBwrList = new VectorX();
             //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("10.1.0 onrBwrList: "+onrBwrList,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);

             for( int i=0, b=bwrVec.size(); i<b; i++ )
               {
               DataNode onrBwrDN = (DataNode)bwrVec.get(i);
               //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("10.1.1 onrBwrDN: "+onrBwrDN,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);

               if( onrBwrDN != null && !onrBwrDN.isDeleted() )
                 {
                 int nodePosition = onrBwrDN.getIndex();

                 //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("10.2 nodePosition: "+nodePosition,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);

                 if( nodePosition >= 0 )
                   {
                   onrBwrList.addElement( String.valueOf( nodePosition ) );
                   }

                 }

               } // for( int i=1; i<bwrVec; i++ )

             //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("10.3 onrBwrList: "+onrBwrList,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);

             if( onrBwrList != null && !onrBwrList.isEmpty() )
               {
               collData.put("_OnrBwrList", onrBwrList);
               }
             } // if( bwrVec != null && bwrVec.size() > 1 )

//
// END - Set up collateral owner list for gui display
//
//
// START - Set up collateral owner node for auto or collateral owner and lien nodes for real estate
//

           //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("10.3.1 collID: "+collID,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);
           //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("10.3.2 collType: "+collType,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);
           //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("10.3.3 collCode: "+collCode,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);

           // add the collater data to the collateral node
           //
           if( collType != null && collID != null )
             {
             //String propLienListStr = (String)collData.remove("phyLienList");
             ////S1Log.getLogInstance().log("17 propLienListStr: "+propLienListStr,LOG_FILE);

             // add data to the collData hash before adding it to the coll data node
             //
             collData.put(CSFieldNames.FN_COLLATERAL_ID,   collID);
             collData.put(CSFieldNames.FN_COLLATERAL_DESC, collType);

             if( collCode != null && collCode.trim().length() > 0 )
             {
               collData.put("clCdD", collCode);
             }

             // load the data node
             //
             DataNode collSubNodeByType = sdo.createDataNode(username, collType);

             //
             // translate real estate field names in mobile home field names
             //

             //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("10.3.3 setFieldData: collData: "+collData,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);

             collSubNodeByType.setFieldData(username, collData);
             collSubNodeByType.setSystemData(CSFieldNames.FN_COLLATERAL_ID, collID);

             //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("11 collNode: "+collNode,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);

             DataNode bwrNode = appNode.getReference( NodeUtils.BWR_DN_TYPE, 0 );

             //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("11.1 collSubNodeByType: "+ collSubNodeByType,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);
             //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("12 bwrNode: "+bwrNode,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);

             if( bwrNode != null && ! bwrNode.isDeleted() )
               {
               HashtableX bwrHash = bwrNode.getFieldData(CSFieldValues.EMPTY_STRING);

               //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("13 bwrHash: "+bwrHash,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);

               if( bwrHash != null && !bwrHash.isEmpty() )
                 {
                 HashtableX onrHash = CSDataCollection.getOnrHT( bwrHash );

                 if( onrHash != null && !onrHash.isEmpty() )
                   {
                   //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("14 onrHash: "+onrHash,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);

                   onrHash.put("_onrBwrPOSHid", "0");

                   DataNode newOnrNode = sdo.createDataNode( username, NodeUtils.ONR_DN_TYPE );
                   if( newOnrNode != null )
                     {
                     // newOnrNode.setFieldData( username, onrNode.getFieldData( getName() ) );
                     //
                     newOnrNode.setDescription( NodeUtils.getNodeDescription( NodeUtils.ONR_DN_TYPE ) );
                     newOnrNode.setFieldData( username, onrHash );

                     //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("15 newOnrNode: "+ newOnrNode,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);

                     collSubNodeByType.addReference( newOnrNode );
                     //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("16 collNode: "+ collNode,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);
                     }

                   // add non party owners for ESL WFE
                   //
                   if( collOwnerList != null && ! collOwnerList.isEmpty() )
                     {
                       // update own node list
                       ////S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("16.NP 0 onrBwrListNP: "+ onrBwrListNP,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);

                       for( int vv=0,ww=collOwnerList.size(); vv<ww; vv++ )
                       {
                         HashtableX nonPrtyOwnrHt = (HashtableX)collOwnerList.get(vv);
                         //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("16.NP 0.9 nonPrtyOwnrHt: "+ nonPrtyOwnrHt,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);

                         if( nonPrtyOwnrHt != null && ! nonPrtyOwnrHt.isEmpty() )
                         {

                           nonPrtyOwnrHt.put( "anIdHid", appNode.getFieldData( username, "anAppId") );

                           DataNode onrNodeNP = sdo.createDataNode(username, NodeUtils.ONR_DN_TYPE);
                           onrNodeNP.setDescription(NodeUtils.getNodeDescription( NodeUtils.ONR_DN_TYPE ) );
                           onrNodeNP.setFieldData(username, nonPrtyOwnrHt);

                           //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("16.NP 1 onrNodeNP: "+ onrNodeNP,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);

                           if (onrNodeNP != null)
                           {
                             collSubNodeByType.addReference(onrNodeNP);

                             //S1Log.getLogInstance().log("", AIU);
                             //S1Log.getLogInstance().log("16.NP 2 collNode: " + collNode, AIU);
                             //S1Log.getLogInstance().log("", AIU);
                           }
                         }

                       } // for( int vv=0,ww=collOwnerList.size(); vv<ww; vv++ )

                     } // if( collOwnerList != null && ! collOwnerList.isEmpty() )

                   } // if( onrHash != null && !onrHash.isEmpty() )

                 } // if( bwrHash != null && !bwrHash.isEmpty() )

               } // if( bwrNode != null && !bwrNode.isDeleted() )

             // add the new node that contains the collateral data to the collater
             // node container
             //
             //collNode.addReference( collSubNodeByType );
             //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("17 add newNode to collNode: "+ collNode,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);

             //
             // add lien node - phyLienList
             //
             List propertyLienList = null;
             String propLienListStr = (String)collData.get("phyLienList");
             //S1Log.getLogInstance().log("17 propLienListStr: "+propLienListStr,LOG_FILE);

             if( propLienListStr != null && propLienListStr.length() > 0 )
                 {
                 propertyLienList = StringChanger.stringToVector( propLienListStr );

                 if( propertyLienList != null && !propertyLienList.isEmpty() )
                     {
                     for (int i=0; i<propertyLienList.size(); i++)
                       {
                       Object objLien = propertyLienList.get( i );

                       //S1Log.getLogInstance().log("objLien: "+objLien,LOG_FILE);
                       //S1Log.getLogInstance().log("CLASS objLien: "+objLien.getClass(),LOG_FILE);

                       HashtableX lienData = null;

                       if( objLien instanceof String )
                       {
                         lienData = StringChanger.stringToHashtableX( propertyLienList.get(i).toString() );
                       }
                       else if( objLien instanceof HashtableX )
                       {
                         lienData = (HashtableX)propertyLienList.get(i);
                       }

                       //S1Log.getLogInstance().log("18 lienData: "+lienData,LOG_FILE);

                       if( lienData != null && !lienData.isEmpty() )
                         {
                         DataNode newLnDN = sdo.createDataNode( username, "Lien" );
                         newLnDN.setFieldData( username, lienData );

                         //S1Log.getLogInstance().log("19 newLnDN: "+newLnDN,LOG_FILE);

                         collSubNodeByType.addReference( newLnDN );
                         }
                       }
                     }
                 }

             // calculate a temp LTV

             double tempLTV = calculateTempLTV(appNode, collData);
             //
             // add escrow node - phyEscrowList
             //

             List propertyEscrowList = null;
             String propEscrowStr = (String)collData.get("phyEscrowList");

             //S1Log.getLogInstance().log("20 propEscrowStr: "+propEscrowStr,LOG_FILE);

             if( propEscrowStr != null && propEscrowStr.trim().length() > 0  )
             {
               propertyEscrowList = StringChanger.stringToVector( propEscrowStr );
               //S1Log.getLogInstance().log("21 propertyEscrowList: "+propertyEscrowList,LOG_FILE);

               for (int x=0, y=propertyEscrowList.size(); x<y; x++)
               {
                 Object objEscrow = propertyEscrowList.get( x );

                 //S1Log.getLogInstance().log("objEscrow: "+objEscrow,LOG_FILE);
                 //S1Log.getLogInstance().log("CLASS objEscrow: "+objEscrow.getClass(),LOG_FILE);

                 HashtableX escrowData = null;

                 if( objEscrow instanceof String )
                 {
                   escrowData = StringChanger.stringToHashtableX( propertyEscrowList.get(x).toString() );
                 }
                 else if( objEscrow instanceof HashtableX )
                 {
                   escrowData = (HashtableX)propertyEscrowList.get(x);
                 }

                 //S1Log.getLogInstance().log("21 escrowData: "+escrowData,LOG_FILE);

                 if( escrowData != null && ! escrowData.isEmpty() )
                 {
                   DataNode newEscrowDN = sdo.createDataNode( username, "escrow" );

                   //S1Log.getLogInstance().log("escrowData: "+escrowData,LOG_FILE);

                   if (tempLTV > 80.0)
                   {
                     escrowData.put(CSFieldNames.FN_ESCROW_C, CSFieldValues.TRUE_STRING);
                   }

                   boolean isPurchase = MGUtils.isMortgagePurchaseTransaction(appNode);
                   //S1Log.getLogInstance().log("MGUtils.isMortgagePurchaseTransaction(appNode) - isPurchase: " + isPurchase, LOG_FILE);

                   calculateEscrowValuesForMtg(appNode, escrowData, collData, isPurchase);
                   //S1Log.getLogInstance().log("calculateEscrowValuesForMtg - escrowData: " + escrowData, LOG_FILE);
                   //}

                   newEscrowDN.setFieldData( username, escrowData );
                   newEscrowDN.setDescription(NodeUtils.getNodeDescription("escrow"));

                   //S1Log.getLogInstance().log("22 newEscrowDN: "+newEscrowDN,LOG_FILE);

                   collSubNodeByType.addReference( newEscrowDN );
                 }
               }
             } // if( propertyEscrowList != null && !propertyEscrowList.isEmpty() )

             // add the new node that contains the collateral data to the collater
             // node container
             //
             //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("23.1 collSubNodeByType: "+ collSubNodeByType,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);

             collNode.addReference( collSubNodeByType );

             if( setPrimaryCollateralCode )
               {
                 if (primaryCollateralCode != null && primaryCollateralCode.trim().length() > 0)
                 {
                   appNode.setFieldData(username, "anPrmClCdD", primaryCollateralCode);
                 }
                 else if( collData != null && collData.containsKey("clCdD") )
                 {
                   primaryCollateralCode = (String)collData.get("clCdD");

                   if( primaryCollateralCode != null && primaryCollateralCode.trim().length() > 0 )
                   {
                     appNode.setFieldData(username, "anPrmClCdD", primaryCollateralCode);
                   }
                 }
               }

             //S1Log.getLogInstance().log("",LOG_FILE);//S1Log.getLogInstance().log("20 add newNode to collNode: "+ collNode,LOG_FILE);//S1Log.getLogInstance().log("",LOG_FILE);

//
// END - Set up collateral owner and lien nodes for real estate
//

             } // if( collType != null && collID != null )

           } // if (recs != null && !recs.isEmpty())

         } // if( str != null )

       } // if (product != null)

     } // if( collFlag != null )

   } // setupCollateralNode(...)


   /**
    * Returns the data hash of formatted fields for the CUDL export to dealers
    *
    * @param sdo SystemDataObject
    * @return HashtableX
    */
   public static HashtableX loadAndFormatExportDataForCUDL( SystemDataObject sdo, String username, boolean fundedFlag )
   throws Exception
   {
     //S1Log.getLogInstance().log("START loadAndFormatExportDataForCUDL( SystemDataObject sdo, String username, boolean fundedFlag )",LOG_FILE);
     //S1Log.getLogInstance().log("username: "+username,LOG_FILE);
     //S1Log.getLogInstance().log("fundedFlag: "+fundedFlag,LOG_FILE);
     //S1Log.getLogInstance().log("if( sdo != null ): "+( sdo != null ),LOG_FILE);

     HashtableX ht = new HashtableX();

     if( sdo != null )
     {
       //S1Log.getLogInstance().log("START sdo: "+sdo.getObjectID(),LOG_FILE);

       DataNode appDN = sdo.getNodeData( NodeUtils.APP_DN_TYPE );

       //S1Log.getLogInstance().log("if( appDN != null ): "+( appDN != null ),LOG_FILE);

       if( appDN != null )
       {
         // application fields for export
         //
         String anAppId = (String)appDN.getFieldData(username,"anAppId");
         if( anAppId != null && anAppId.trim().length() > 0 )
         {
           ht.put( "anAppId", anAppId );
         }

         String anRefId = (String)appDN.getFieldData(username,"anRefId");
         if( anRefId != null && anRefId.trim().length() > 0 )
         {
           ht.put( "anRefId", anRefId );
         }

         String anLoanAmt = (String)appDN.getFieldData(username,"anLoanAmt");
         if( anLoanAmt != null && anLoanAmt.trim().length() > 0 )
         {
           ht.put( "anLoanAmt", anLoanAmt );
         }

         String anIntRate = (String)appDN.getFieldData(username,"anIntRate");
         if( anIntRate != null && anIntRate.trim().length() > 0 )
         {
           ht.put( "anIntRate", anIntRate );
         }

         String anNumPmt  = (String)appDN.getFieldData(username,"anNumPmt");
         String anPmtPrdD = (String)appDN.getFieldData(username,"anPmtPrdD");
         if( anNumPmt != null && anNumPmt.trim().length() > 0 )
         {
           if( anPmtPrdD != null && anPmtPrdD.trim().toLowerCase().equals("monthly") )
           {
             ht.put("anNumPmt", anNumPmt);
           }
           else
           {
             // translate to months
             //
             String termInMonths  = (String)appDN.getSystemData("!term");
             if( termInMonths != null && termInMonths.trim().length() > 0  )
             {
               ht.put("anNumPmt", termInMonths);
             }

           }
         }

         String anPmtAmt = (String)appDN.getFieldData(username,"anPmtAmt");
         if( anPmtAmt != null && anPmtAmt.trim().length() > 0 )
         {
           ht.put( "anPmtAmt", anPmtAmt );
         }

         String an1stPmtDt = (String)appDN.getFieldData(username,"an1stPmtDt");
         if( an1stPmtDt != null && an1stPmtDt.trim().length() > 0 )
         {
           ht.put( "an1stPmtDt", an1stPmtDt );
         }

         // status translation - application:!stat = 1000
         //
         String status = (String)appDN.getSystemData("!stat");

         //S1Log.getLogInstance().log("status: "+status,LOG_FILE);

         if( status == null && status.trim().length() == 0 )
         {
           if( status == null )
           {
             throw new Exception("Invalid application status. Status value is NULL.");
           }
           else if( status != null && status.trim().length() == 0 )
           {
             throw new Exception("Invalid application status. The application status has not been set.");
           }
         }

         // get stipulations
         //
         try
         {
           //S1Log.getLogInstance().log("if (status != null && status.trim().equals(4030)): " + (status != null && status.trim().equals("4030")), LOG_FILE);
           if (status != null && status.trim().equals("4030"))
           {
             DataNode decNode = DecisionUtils.getLastDecision(appDN);

             //S1Log.getLogInstance().log("decNode: " + decNode,LOG_FILE);
             //S1Log.getLogInstance().log("if( decNode != null ): " + (decNode != null),LOG_FILE);

             if (decNode != null)
             {
                List stipList = decNode.getReferences(NodeUtils.STIP_DN_TYPE);
                //S1Log.getLogInstance().log("stipList: " + stipList, LOG_FILE);

                if (stipList != null)
                {
                  DataNode stipDN = null;
                  String stip = null;
                  //VectorX stipComments = null;
                  int index = 1;

                  for (int i = 0, c = stipList.size(); i < c; ++i)
                  {
                    stipDN = (DataNode)stipList.get(i);
                    if (! stipDN.isDeleted())
                    {
                      stip = (String)stipDN.getFieldData(getName(), "stpD");
                      if (stip != null) ht.put("stip_" + index, stip);

                      // not using comments
                      //
                      //stipComments = (VectorX)stipDN.getFieldData(getName(), "stpA");
                      //if (stipComments != null)
                      //{
                      //  String str = ClientUtils.convertTextAreaToString(stipComments);
                      //  ht.put("stip_comment_" + index, str);
                      //}

                      ++index;
                    }
                  }
                }
             }
           }
         }
         catch (Exception e)
         {
             e.printStackTrace();
             //S1Log.getLogInstance().log("StipList Error: " + e, LOG_FILE);
         }

         // Translate current date/time into funded status using -03:00 in time.
         // 2008-03-03T15:43:38.667625-08:00
         // From LED RouteOne SimpleDateFormat dtFmt = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
         //
         // "yyyy-MM-dd'T'HH:mm:ss.SSSSSSSZ"
         //
         // SimpleDateFormat cudlDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss:SSSSSSZ");
         //
         Date todaysDate = new Date();
         SimpleDateFormat cudlDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSSSSSZ");
         String cudlDt = formatDateTime( todaysDate, cudlDateFormat );
         //S1Log.getLogInstance().log("cudlDt: "+cudlDt,LOG_FILE);

         int index = cudlDt.lastIndexOf("-");
         //S1Log.getLogInstance().log("index: "+index,LOG_FILE);

         if( index != -1 )
         {
           // timeB = new StringBuffer().append( cudlDt.substring(0,index) ).append("T").append( cudlDt.substring(index+1));
           //
           String cudlDtStrToLastDash = cudlDt.substring(0, index + 1);
           //S1Log.getLogInstance().log("0 cudlDtStrToLastDash: " + cudlDtStrToLastDash);

           String timeZone = cudlDt.substring(index + 1);
           //S1Log.getLogInstance().log("1 timeZone: " + timeZone);

           if (timeZone != null && timeZone.length() == 4)
           {
             //S1Log.getLogInstance().log("2 timeZone: " + timeZone);

             String tOne = timeZone.substring(0, 2);
             //S1Log.getLogInstance().log("tOne: " + tOne);

             String tTwo = timeZone.substring(2);
             //S1Log.getLogInstance().log("tTwo: " + tTwo);

             cudlDt = cudlDtStrToLastDash + tOne + ':' + tTwo;
             //S1Log.getLogInstance().log("3 cudlDt String: " + cudlDt);
           }
         }

         ht.put( "dot_net_date", cudlDt );

         // Current date
         //
         SimpleDateFormat contractDateFormat = new SimpleDateFormat("yyyy-MM-dd");
         String currentDt = formatDateTime( todaysDate, contractDateFormat );
         //S1Log.getLogInstance().log("currentDt: "+currentDt,LOG_FILE);
         ht.put( "current_date", currentDt );

         // get miscD0357
         //
         // SELECT cMisc, nMisc, fMisc FROM xntApMiscFields WHERE nAppId = 460 AND cMiscFieldId = 'miscD0355'
         //
         String sql = null;
         try
         {
           sql = "SELECT cMisc, nMisc, fMisc FROM xntApMiscFields WHERE nAppId = "+anAppId+" AND cMiscFieldId = 'miscD0357'";
           //S1Log.getLogInstance().log("sql;: " + sql, LOG_FILE);

           HashMap hm = DbHelper.getInstance().executeQuery(sql);
           //S1Log.getLogInstance().log("HashMap hm = " + hm, LOG_FILE);

           if (hm.containsKey(DbHelper.RESULT))
           {
             DbElements rs = (DbElements) hm.get(DbHelper.RESULT);

             if (rs != null && rs.next())
             {
               String cMisc = rs.getString("cMisc");
               //S1Log.getLogInstance().log("cMisc: " +cMisc,LOG_FILE);

               //String n = String.valueOf( rs.getInt("nMisc") );
               //S1Log.getLogInstance().log("n: " + n,LOG_FILE);


               //String f = String.valueOf( rs.getDouble("fMisc") );
               //S1Log.getLogInstance().log("f: " + f,LOG_FILE);

               if (cMisc != null && cMisc.trim().length() > 0)
               {
                 ht.put("miscD0357", cMisc);
               }

               //else if (n != null && n.trim().length() > 0)
               //{
               //  ht.put("miscD0357", n);
               //}
               //else if (f != null && f.trim().length() > 0)
               //{
               //  ht.put("miscD0357", f);
               //}

               else
               {
                 ht.put("miscD0357", CSFieldValues.EMPTY_STRING);
               }

             }
           }
         }
         catch( Exception sqlE )
         {
           sqlE.printStackTrace();
           DBLogger.log( "SQL Exception: sql: "+sql+" Error: "+sqlE.getMessage());
         }


       } // if( appDN != null )

       // collateral
       //
       // Field clNwUsdD must be translated if used=true, if new=false
       //
       if( fundedFlag )
       {
         VectorX collVec = appDN.getEffectiveReferences(NodeUtils.COLL_DN_TYPE);
         //S1Log.getLogInstance().log("collVec: " + collVec,LOG_FILE);

         if (collVec != null && ! collVec.isEmpty() )
         {
           boolean COL_NOT_FOUND = true; // break from both loops
           //S1Log.getLogInstance().log("COL_NOT_FOUND 1: " + COL_NOT_FOUND,LOG_FILE);

           for( int i=0, c=collVec.size(); i<c && COL_NOT_FOUND; i++ )
           {
             DataNode colNode = (DataNode)collVec.get(i);

             if( colNode != null && ! colNode.isDeleted() )
             {
               //S1Log.getLogInstance().log("nodeType: " + colNode.getDataType(),LOG_FILE);

               List dataTypeList = colNode.getReferenceDataTypes();

               if( dataTypeList != null && ! dataTypeList.isEmpty() )
               {
                 for(int x=0, y=dataTypeList.size(); x<y && COL_NOT_FOUND; x++ )
                 {
                   List nodeList = colNode.getEffectiveReferences( dataTypeList.get(x).toString() );

                   //S1Log.getLogInstance().log("nodeList: " + nodeList,LOG_FILE);

                   if ( nodeList != null && ! nodeList.isEmpty())
                   {
                     for (int g = 0, h = nodeList.size(); g<h && COL_NOT_FOUND; g++)
                     {
                       DataNode tempDN = (DataNode) nodeList.get(g);

                       if( tempDN != null && ! tempDN.isDeleted() )
                       {
                         HashtableX colHt = tempDN.getFieldData( CSFieldValues.EMPTY_STRING );

                         //S1Log.getLogInstance().log("colHt: " + colHt,LOG_FILE);

                         /*
                         <FundedVehicle>
                             <Make>[clVhMkD]</Make>
                             <Model>[clVhMdlD]</Model>
                             <Year>[clVhYrD]</Year>
                             <VIN>[clVhVIN]</VIN>
                         </FundedVehicle>
                         */

                         //S1Log.getLogInstance().log("if( colHt != null && (colHt.containsKey(clVhMkD) || colHt.containsKey(clVhMdlD) || colHt.containsKey(clVhYrD)) ): " + ( colHt != null && (colHt.containsKey("clVhMkD") || colHt.containsKey("clVhMdlD") || colHt.containsKey("clVhYrD")) ),LOG_FILE);

                         if( colHt != null && (colHt.containsKey("clVhMkD") || colHt.containsKey("clVhMdlD") || colHt.containsKey("clVhYrD")) )
                         {
                             // clCdD
                             //
                             String clCdD = (String)colHt.get("clCdD");
                             if( clCdD != null )
                             {
                               ht.put("clCdD", clCdD);
                             }
                             else
                             {
                               ht.put("clCdD", CSFieldValues.EMPTY_STRING);
                             }

                            // clVhMkD
                            //
                            String make = (String)colHt.get("clVhMkD");
                            if( make != null )
                            {
                              ht.put("clVhMkD", make);
                            }
                            else
                            {
                              ht.put("clVhMkD", CSFieldValues.EMPTY_STRING);
                            }

                            // clVhMdlD
                            //
                            String model = (String)colHt.get("clVhMdlD");
                            if( model != null )
                            {
                              ht.put("clVhMdlD", model);
                            }
                            else
                            {
                              ht.put("clVhMdlD", CSFieldValues.EMPTY_STRING);
                            }

                            // clVhYrD
                            //
                            String year = (String)colHt.get("clVhYrD");
                            if( year != null )
                            {
                              ht.put("clVhYrD", year);
                            }
                            else
                            {
                              ht.put("clVhYrD", CSFieldValues.EMPTY_STRING);
                            }

                            // clVhVIN
                            //
                            String vin = (String)colHt.get("clVhVIN");
                            if( vin != null )
                            {
                              ht.put("clVhVIN", vin);
                            }
                            else
                            {
                              ht.put("clVhVIN", CSFieldValues.EMPTY_STRING);
                            }

                            // clVhMi
                            //
                            String miles = (String)colHt.get("clVhMi");
                            if( miles != null )
                            {
                              ht.put("clVhMi", miles);
                            }
                            else
                            {
                              ht.put("clVhMi", CSFieldValues.EMPTY_STRING);
                            }

                            // clNwUsdD
                            //
                            String newUsed = (String)colHt.get("clNwUsdD");
                            if( newUsed != null && newUsed.trim().toLowerCase().equals("new") )
                            {
                              ht.put("clNwUsdD", "false");
                            }
                            else if( newUsed != null && newUsed.trim().toLowerCase().equals("used") )
                            {
                              ht.put("clNwUsdD", "true");
                            }
                            else
                            {
                              ht.put("clNwUsdD", CSFieldValues.EMPTY_STRING);
                            }

                            COL_NOT_FOUND = false;

                            //S1Log.getLogInstance().log("COL_NOT_FOUND 2: " + COL_NOT_FOUND,LOG_FILE);

                          } // if( colHt != null )
                        }
                      } // for (int g = 0, h = autoNodeList.size(); g < h; g++)
                    }
                  }
                }
             } // if( colNode != null )
           }
         } // if (collVec != null)
       }
     } // if( sdo != null )


     //S1Log.getLogInstance().log("loadAndFormatExportDataForCUDL: return ht: "+ht,LOG_FILE);
     //S1Log.getLogInstance().log("END loadAndFormatExportDataForCUDL( SystemDataObject sdo, String username, boolean fundedFlag )",LOG_FILE);

     return ht;
   } // public static DataNode getReferenceIdFromSDO( SystemDataObject sdo )

   public static String formatDateTime( Date date, SimpleDateFormat dateFormat)
   {
     synchronized (dateFormat)
     {
       return dateFormat.format(date);
     }
   }

   public static StringBuffer fillTemplateSB(String template, Map fields) throws Exception
   {
     FileTemplate ft = new FileTemplate();
     ft.addFilterChar('#');
     ft.load(template);
     ft.fill(fields);

     List list;
     StringBuffer sb = new StringBuffer();
     try
     {
        list = CmdEvaluator.evaluateList(ft.getLines());
    
        if (list != null && !list.isEmpty())
        {
          sb = new StringBuffer();
          for (int i = 0, c = list.size(); i < c; ++i)
          {
            sb.append((String) list.get(i));
            sb.append("\r\n");
          }
        }
     }
     catch (Exception e)
     {
       throw new Exception("Fill Template Exception: " + template + ": " + e.getMessage());
     }

    return sb;
  }

  public static List fillTemplate(String template, Map fields)
    throws IOException, Exception
  {
    FileTemplate ft = new FileTemplate();
    ft.addFilterChar('#');
    ft.load(template);
    ft.fill(fields);

    List list;

    try
    {
      list = CmdEvaluator.evaluateList(ft.getLines());
    }
    catch (Exception e)
    {
      throw new Exception("Template: " + template + ": " + e.getMessage());
    }

    return list;
  }

  // used for cudl logging and meridian link logging
  //
  public static void logUpdateXML(String baseLogFilename, String signedXML, boolean LOG, String CUDL_LOG_PATH)
  {
    logUpdateXML(baseLogFilename, signedXML, LOG, CUDL_LOG_PATH, ".xml" );
  }

  public static void logUpdateXML(String filename, String fileContent, boolean LOG, String LOG_PATH, String fileExtension)
   {
     //S1Log.getLogInstance().log("START logUpdateXML(String baseLogFilename, String signedXML, boolean LOG, String CUDL_LOG_PATH)",LOG_FILE);
     //S1Log.getLogInstance().log("baseLogFilename: "+baseLogFilename,LOG_FILE);
     //S1Log.getLogInstance().log("signedXML: "+signedXML,LOG_FILE);
     //S1Log.getLogInstance().log("LOG: "+LOG,LOG_FILE);
     //S1Log.getLogInstance().log("CUDL_LOG_PATH: "+CUDL_LOG_PATH,LOG_FILE);

     if (LOG)
     {

       FileWriter fw = null;

       try
       {
         StringBuffer logPathSb = new StringBuffer();
         StringBuffer sb = new StringBuffer();

         if( LOG_PATH.endsWith("\\") )
         {
          logPathSb.append(LOG_PATH);
          sb.append(LOG_PATH).append(filename).append(fileExtension);
         }
         else
         {
           logPathSb.append(LOG_PATH).append(File.separator);
           sb.append(LOG_PATH).append(File.separator).append(filename).append(fileExtension);
         }

         File logPath = new File( logPathSb.toString() );

         //S1Log.getLogInstance().log("cudlLogPath: " + cudlLogPath);

         if( ! logPath.exists() )
         {
           logPath.mkdirs();
         }

         //S1Log.getLogInstance().log("PATH: "+sb.toString(),LOG_FILE);

         fw = new FileWriter( sb.toString() );

         fw.write( fileContent );
       }
       catch (Exception e)
       {
         ExceptionLogger.logException(e);
       }
       finally
       {
         try
         {
           fw.close();
         }
         catch (Exception e)
         {
           e.printStackTrace();
         }
       }
     }

     //S1Log.getLogInstance().log("END logUpdateXML(String baseLogFilename, String signedXML, boolean LOG, String CUDL_LOG_PATH)",LOG_FILE);
   }

   public static boolean notificationEmailSent( String refId, String sdoId, String docSet ) throws Exception
     {
       //S1Log.getLogInstance().log("START preliminaryDocEmailSent( String refId, String sdoId )",LOG_FILE);
       //S1Log.getLogInstance().log("String refId: "+refId,LOG_FILE);
       //S1Log.getLogInstance().log("String sdoId: "+sdoId,LOG_FILE);

       boolean emailSent = false;

       //S1Log.getLogInstance().log("START CHECK WITH DATABASE",LOG_FILE);
       //S1Log.getLogInstance().log("START CHECK WITH DATABASE: emailSent: "+emailSent,LOG_FILE);
       //S1Log.getLogInstance().log("START CHECK WITH DATABASE",LOG_FILE);

       String sql = null;
       try
       {
         sql = "SELECT bEmailNotificationSent FROM xntWebPrintEmail WHERE nAppId = "+sdoId+" AND nRefId = "+refId+" AND cDocSet = '"+docSet+"'";
         //S1Log.getLogInstance().log("sql: " + sql, LOG_FILE);

         HashMap hm = DbHelper.getInstance().executeQuery(sql);

         //S1Log.getLogInstance().log("HashMap hm = " + hm, LOG_FILE);
         //S1Log.getLogInstance().log("if( hm.containsKey( DbHelper.RESULT ) ): "+( hm.containsKey( DbHelper.RESULT ) ), LOG_FILE);

         if( hm.containsKey( DbHelper.RESULT ) )
         {
           DbElements rs = (DbElements) hm.get(DbHelper.RESULT);

           if( rs != null && rs.next() )
           {
             String notificationFlag = rs.getString("bEmailNotificationSent");

             //S1Log.getLogInstance().log("notificationFlag: " +notificationFlag,LOG_FILE);
             //S1Log.getLogInstance().log("if( notificationFlag != null && notificationFlag.trim().equals(t) ): "+( notificationFlag != null && notificationFlag.trim().equals("t") ),LOG_FILE);

             if( notificationFlag != null && notificationFlag.trim().equals("t") )
             {
               emailSent = true;
             }

           } // if( rs != null && rs.next() )

         } // if( hm.containsKey( DbHelper.RESULT ) )

       }
       catch( Exception sqlE )
       {
         sqlE.printStackTrace();
         DBLogger.log( "SQL Exception: sql: "+sql+" Error: "+sqlE.getMessage());
       }

       //S1Log.getLogInstance().log("END CHECK WITH DATABASE",LOG_FILE);
       //S1Log.getLogInstance().log("END CHECK WITH DATABASE: emailSent: "+emailSent,LOG_FILE);
       //S1Log.getLogInstance().log("END CHECK WITH DATABASE",LOG_FILE);

       //S1Log.getLogInstance().log("END preliminaryDocsExist( String refId, String sdoId ) return docsExist: "+emailSent,LOG_FILE);

       return emailSent;
     }

     public static boolean insertIntoWebPrintEmail( String sdoId, String refId, String docSet ) throws Exception
     {
       //S1Log.getLogInstance().log("START insertIntoWebPrintEmail( String sdoId, String refId )", LOG_FILE);

       boolean insert = true;

       String sql = null;

       try
       {
         sql = "SELECT nAppId FROM xntWebPrintEmail WHERE nAppId = "+sdoId+" AND nRefId = "+refId+" AND cDocSet = '"+docSet+"'";
         //S1Log.getLogInstance().log("sql: " + sql, LOG_FILE);

         HashMap hm = DbHelper.getInstance().executeQuery(sql);

         //S1Log.getLogInstance().log("HashMap hm = " + hm, LOG_FILE);
         //S1Log.getLogInstance().log("if( hm.containsKey( DbHelper.RESULT ) ): "+( hm.containsKey( DbHelper.RESULT ) ), LOG_FILE);

         if( hm.containsKey( DbHelper.RESULT ) )
         {
           DbElements rs = (DbElements) hm.get(DbHelper.RESULT);

           if( rs != null && rs.next() )
           {
             String nAppId = String.valueOf( rs.getInt("nAppId") );

             //S1Log.getLogInstance().log("nAppId: " +nAppId,LOG_FILE);
             //S1Log.getLogInstance().log("if( nAppId != null && nAppId.trim().length() > 0  ): "+( nAppId != null && nAppId.trim().length() > 0  ),LOG_FILE);

             if( nAppId != null && nAppId.trim().length() > 0  )
             {
               insert = false;
             }

           } // if( rs != null && rs.next() )

         } // if( hm.containsKey( DbHelper.RESULT ) )

       }
       catch( Exception sqlE )
       {
         sqlE.printStackTrace();
         DBLogger.log( "SQL Exception: sql: "+sql+" Error: "+sqlE.getMessage());
       }

       //S1Log.getLogInstance().log("return insert: "+insert, LOG_FILE);
       //S1Log.getLogInstance().log("END insertIntoWebPrintEmail( String sdoId, String refId )", LOG_FILE);

       return insert;
     }


     /**
      * List element zero is the ssn and element one is the app reference id
      *
      * @param fName String
      * @param lName String
      * @param dob String
      * @return List
      */
     public static List getSsnWithDOB(String fName, String lName, String dob)
     {
       //S1Log.getLogInstance().log("getSSNandRefId(String fName, String lName, String dob)", LOG_FILE);

       List paramList = new ArrayList();

       String fNameSql = DBUtils.escapeSingleQuote( fName );
       //S1Log.getLogInstance().log("firstName: "+fName+" - firstNameSql: " + fNameSql, LOG_FILE);

       String lNameSql = DBUtils.escapeSingleQuote( lName );
       //S1Log.getLogInstance().log("lastName: "+lName+" - lastNameSql: " + lNameSql, LOG_FILE);

       // String sql = "SELECT app.nRefId, cust.cSSN "+
       //              "FROM xntCustomers cust WITH(NOLOCK), xntApplications app WITH(NOLOCK) "+
       //              "WHERE cust.cFName = '"+fName+"' AND cust.cLName = '"+lName+"' AND cust.dtBirth = '"+dob+"' AND app.nPrimCustId = cust.nCustId";

       StringBuffer sql = new StringBuffer().append("SELECT app.nRefId, cust.cSSN FROM xntCustomers cust WITH(NOLOCK), xntApplications app WITH(NOLOCK) WHERE cust.cFName = '").append( fNameSql ).append("' AND cust.cLName = '").append( lNameSql ).append("' AND cust.dtBirth = '").append( dob ).append("' AND app.nPrimCustId = cust.nCustId");

       //S1Log.getLogInstance().log("SQT STMT: "+sql.toString(), LOG_FILE);

       Statement stmt = null;

       try
       {
         Connection con = DBAccess.getConnection();
         stmt = con.createStatement();
         ResultSet rs = stmt.executeQuery( sql.toString() );

         String ssn   = null;
         String refId = null;

         //S1Log.getLogInstance().log("if ( rs.next() ): PROCESS", LOG_FILE);

         if ( rs.next() )
         {
           //S1Log.getLogInstance().log("INSIDE while ( rs.next() ): START", LOG_FILE);

           ssn = rs.getString( "cSSN" );
           //S1Log.getLogInstance().log("ssn: "+ssn, LOG_FILE);

           if( ssn != null && ssn.trim().length() > 0 )
            {
              paramList.add(ssn);
            }

           refId =  String.valueOf( rs.getInt( "nRefId" ) );
           //S1Log.getLogInstance().log("refId: "+refId, LOG_FILE);

           if( refId != null && refId.trim().length() > 0 )
            {
              paramList.add(refId);
            }

         } // End while (rs.next())

       } // End try
       catch ( SQLException e )
       {
         e.printStackTrace();
         DBLogger.log("Class: AppImportUtils.getSsnWithDOB() SQL: "+sql+"   SQLException thrown: "+e.getMessage());
       }
       catch ( Exception e )
       {
         e.printStackTrace();
       }

       finally
       {
         DBAccess.closeConnection( stmt );
       }

       return paramList;
     } // End getSsnWithDOB(String fName, String lName, String dob)

     public static List getSsnWithRefId(String fName, String lName, String refId)
     {
       //S1Log.getLogInstance().log("getSsnWithRefId(String fName, String lName, String dob)",LOG_FILE);

       List paramList = new ArrayList();

       String fNameSql = DBUtils.escapeSingleQuote( fName );
       //S1Log.getLogInstance().log("firstName: "+fName+" - firstNameSql: " + fNameSql, LOG_FILE);

       String lNameSql = DBUtils.escapeSingleQuote( lName );
       //S1Log.getLogInstance().log("lastName: "+lName+" - lastNameSql: " + lNameSql, LOG_FILE);

       // String sql = "SELECT cust.cSSN FROM xntCustomers cust WITH(NOLOCK), xntApplications app WITH(NOLOCK) "+
       //              "WHERE cust.cFName = '" + fName + "' AND cust.cLName = '" + lName + "' " +
       //              "AND app.nPrimCustId = cust.nCustId AND app.nRefId = " + refId;

       StringBuffer  sql = new StringBuffer().append("SELECT cust.cSSN FROM xntCustomers cust WITH(NOLOCK), xntApplications app WITH(NOLOCK) WHERE cust.cFName = '").append( fNameSql ).append("' AND cust.cLName = '").append( lNameSql ).append("' AND app.nPrimCustId = cust.nCustId AND app.nRefId = ").append( refId );

       //S1Log.getLogInstance().log("SQT STMT: " + sql.toString(), LOG_FILE);

       Statement stmt = null;

       try
       {
         Connection con = DBAccess.getConnection();
         stmt = con.createStatement();
         ResultSet rs = stmt.executeQuery( sql.toString() );

         String ssn = null;
         //String refId = null;

         //S1Log.getLogInstance().log("if ( rs.next() ): PROCESS",LOG_FILE);

         if (rs.next())
         {
           //S1Log.getLogInstance().log("INSIDE while ( rs.next() ): START",LOG_FILE);

           ssn = rs.getString("cSSN");
           //S1Log.getLogInstance().log("ssn: " + ssn,LOG_FILE);

           if (ssn != null && ssn.trim().length() > 0)
           {
             paramList.add(ssn);
           }
         } // End while (rs.next())

       } // End try
       catch (SQLException e)
       {
         e.printStackTrace();
         DBLogger.log("Class: AppImportUtils.getSsnWithRefId() SQL: " + sql + "   SQLException thrown: " + e.getMessage());
       }
       catch (Exception e)
       {
         e.printStackTrace();
       }

       finally
       {
         DBAccess.closeConnection(stmt);
       }

       return paramList;
     } // End getSsnWithRefId(String fName, String lName, String dob)

     public static String getSdoId( String lookupNumber, String refId )
     {
       //S1Log.getLogInstance().log("START String getSdoId( String lookupNumber )",LOG_FILE);

       // SELECT nAppId FROM xntApMiscFields WHERE cMiscFieldId = 'miscD0354' AND cMisc = '7315662281020'
       //
       //String sql = "SELECT nAppId FROM xntApMiscFields WHERE cMiscFieldId = 'miscD0354' AND cMisc = '"+lookupNumber+"'";
       /*
       String sql =
       "SELECT xntApplications.nAppId "+
       "FROM   xntApplications WITH(NOLOCK), xntCustomers WITH(NOLOCK) "+
       "WHERE  xntCustomers.cSSN = (SELECT cssn "+
       "                            FROM xntCustomers cust WITH(NOLOCK), xntApplications app WITH(NOLOCK)  "+
       "                            WHERE app.nAppId = (SELECT top 1 nAppId "+
       "                                                FROM xntApMiscFields WITH(NOLOCK) "+
       "                                                WHERE cMiscFieldId = 'miscD0354' AND cMisc = '"+lookupNumber+"') AND "+
       "                                                cust.nCustId = app.nPrimCustId) AND "+
       "            xntCustomers.nCustId = xntApplications.nPrimCustId AND "+
       "            xntApplications.nRefId = "+refId;

       NEW QUERY FROM CKD
       Select xntApplications.nAppId from xntApplications
       inner join xntApMiscFields on xntApplications.nAppId = xntApMiscFields.nAppId and
       cMiscFieldId = 'miscD0354' and cMisc = '7315662281020' and nRefId = 15854
       */

       StringBuffer sql = new StringBuffer();
       sql.append("SELECT xntApplications.nAppId FROM xntApplications ");
       sql.append("INNER JOIN xntApMiscFields ON xntApplications.nAppId = xntApMiscFields.nAppId ");
       sql.append("AND cMiscFieldId = 'miscD0354' AND cMisc = '");
       sql.append(lookupNumber);
       sql.append("' AND nRefId = ");
       sql.append(refId);

       //S1Log.getLogInstance().log("SQT STMT: "+sql,LOG_FILE);

       String sdoIdStr = null;
       Statement stmt  = null;

       try
       {
         Connection con = DBAccess.getConnection();
         stmt = con.createStatement();
         ResultSet rs = stmt.executeQuery( sql.toString() );

         int sdoId = -1;

         //S1Log.getLogInstance().log("if ( rs.next() ): PROCESS",LOG_FILE);

         if ( rs.next() )
         {
           //S1Log.getLogInstance().log("INSIDE if ( rs.next() ): START",LOG_FILE);
           sdoId = rs.getInt( "nAppId" );
           //S1Log.getLogInstance().log("sdoId: "+sdoId,LOG_FILE);

           if( sdoId > 0 )
           {
             sdoIdStr = String.valueOf( sdoId );
           }
           else
           {
             throw new Exception("Invalid system data object. SDO ID: "+sdoId);
           }
         }

       }
       catch ( SQLException e )
       {
         e.printStackTrace();
         DBLogger.log("AppImportUtils.getSdoId(lookupNumber, refId) SQL: "+sql+" SQLException thrown: "+e.getMessage());
       }
       catch ( Exception e )
       {
         e.printStackTrace();
         //S1Log.getLogInstance().log("AppImportUtils.getSdoId(lookupNumber, refId) SQL: "+sql+" Exception thrown: "+e.getMessage(),LOG_FILE);
       }

       finally
       {
         DBAccess.closeConnection( stmt );
       }

       //S1Log.getLogInstance().log("END return sdoIdStr: "+sdoIdStr,LOG_FILE);

       return sdoIdStr;
     } // End getSdoId(String fName, String lName, String dob)

     public static List getRefIdAndSSN( String lookupNumber )
     {
       //S1Log.getLogInstance().log("START String getSdoId( String lookupNumber )",LOG_FILE);

       // SELECT nAppId FROM xntApMiscFields WHERE cMiscFieldId = 'miscD0354' AND cMisc = '7315662281020'
       //
       // String sql = "SELECT nAppId FROM xntApMiscFields WHERE cMiscFieldId = 'miscD0354' AND cMisc = '"+lookupNumber+"'";
       //
       // String sql = "SELECT app.nRefId, cust.cSSN FROM xntCustomers cust WITH(NOLOCK), xntApplications app WITH(NOLOCK), xntApMiscFields misc WITH(NOLOCK) WHERE misc.cMiscFieldId = 'miscD0354' AND misc.cMisc = '"+lookupNumber+"'AND app.nAppId = misc.nAppId AND app.nPrimCustId = cust.nCustId";

       StringBuffer sql = new StringBuffer().append("SELECT app.nRefId, cust.cSSN FROM xntCustomers cust WITH(NOLOCK), xntApplications app WITH(NOLOCK), xntApMiscFields misc WITH(NOLOCK) WHERE misc.cMiscFieldId = 'miscD0354' AND misc.cMisc = '").append(lookupNumber).append("'AND app.nAppId = misc.nAppId AND app.nPrimCustId = cust.nCustId");
       //S1Log.getLogInstance().log("SQT STMT: "+sql,LOG_FILE);

       Statement stmt  = null;

       List list = new ArrayList();

       try
       {
         Connection con = DBAccess.getConnection();
         stmt = con.createStatement();
         ResultSet rs = stmt.executeQuery( sql.toString() );

         int refId = -1;
         String ssn = null;
         String sdoIdStr = null;

         //S1Log.getLogInstance().log("if ( rs.next() ): PROCESS",LOG_FILE);

         if ( rs.next() )
         {
           //S1Log.getLogInstance().log("INSIDE if ( rs.next() ): START",LOG_FILE);

           // cust.cSSN
           //
           ssn = rs.getString( "cSSN" );
           //S1Log.getLogInstance().log("ssn: "+ssn,LOG_FILE);

           if( ssn != null && ssn.trim().length() > 0 )
           {
             list.add( ssn );
           }
           else
           {
             list.add( CSFieldValues.EMPTY_STRING );
           }

           // app.nRefId
           //
           refId = rs.getInt( "nRefId" );
           //S1Log.getLogInstance().log("refId: "+refId,LOG_FILE);

           if( refId > 0 )
           {
             sdoIdStr = String.valueOf( refId );
             //S1Log.getLogInstance().log("sdoIdStr: "+sdoIdStr,LOG_FILE);

             if( sdoIdStr != null && sdoIdStr.trim().length() > 0 )
             {
               list.add( sdoIdStr );
             }
             else
             {
               list.add( CSFieldValues.EMPTY_STRING );
             }
           }
           else
           {
             throw new Exception("Invalid application ID returned from database. App ID: "+refId);
           }

         } // if ( rs.next() )

       }
       catch ( SQLException e )
       {
         e.printStackTrace();
         DBLogger.log("ApplicantStatusTable.getRefIdAndSSN(lookupNumber) SQL: "+sql+" SQLException thrown: "+e.getMessage());
       }
       catch ( Exception e )
       {
         e.printStackTrace();
         //S1Log.getLogInstance().log("AppImportUtils.getRefIdAndSSN(lookupNumber) SQL: "+sql+" Exception thrown: "+e.getMessage(),LOG_FILE);
       }

       finally
       {
         DBAccess.closeConnection( stmt );
       }

       //S1Log.getLogInstance().log("END return list: "+list,LOG_FILE);

       return list;
     } // End getSSNandRefId(String fName, String lName, String dob)

     public static List getSSN( String fName, String lName, String dob, String refId, boolean useDOB )
     {
       //log("getSSN(String fName, String lName, String dob)");

       List paramList = new ArrayList();

       StringBuffer sql = new StringBuffer();
       sql.append("SELECT cust.cSSN FROM xntCustomers cust WITH(NOLOCK), xntApplications app WITH(NOLOCK) ");
       sql.append("WHERE cust.cFName = '");
       sql.append(fName);
       sql.append("' AND cust.cLName = '");
       sql.append(lName);
       sql.append("' AND app.nPrimCustId = cust.nCustId ");

       if( useDOB )
       {
         sql.append("AND cust.dtBirth = '");
         sql.append(dob);
         sql.append("' ");
       }

       sql.append("AND app.nRefId = ");
       sql.append(refId);

       //log("SQT STMT: "+sql);

       Statement stmt = null;

       try
       {
         Connection con = DBAccess.getConnection();
         stmt = con.createStatement();
         ResultSet rs = stmt.executeQuery( sql.toString() );

         String ssn   = null;

         //log("if ( rs.next() ): PROCESS");
         if ( rs.next() )
         {
           //log("INSIDE while ( rs.next() ): START");

           ssn = rs.getString( "cSSN" );
           //log("ssn: "+ssn);

           if( ssn != null && ssn.trim().length() > 0 )
            {
              paramList.add(ssn);
            }

         } // End while (rs.next())

       } // End try
       catch ( SQLException e )
       {
         e.printStackTrace();
         DBLogger.log("Class: AppImportUtils.getSSN() SQL: "+sql+"   SQLException thrown: "+e.getMessage());
       }
       catch ( Exception e )
       {
         e.printStackTrace();
       }

       finally
       {
         DBAccess.closeConnection( stmt );
       }

       return paramList;
     } // End getSSN(String fName, String lName, String dob)


     public static String getRefId( String sdoId )
     {
       //S1Log.getLogInstance().log("START getRefId(String sdoId)",LOG_FILE);

       // select nRefId from xntapplications where nAppId = 543
       //
       String sql = "SELECT nRefId FROM xntApplications WHERE nAppId = "+sdoId;

       //S1Log.getLogInstance().log("SQT STMT: "+sql,LOG_FILE);

       String refId   = null;
       Statement stmt = null;

       try
       {
         Connection con = DBAccess.getConnection();
         stmt = con.createStatement();
         ResultSet rs = stmt.executeQuery( sql );

         //S1Log.getLogInstance().log("if ( rs.next() ): PROCESS",LOG_FILE);

         if ( rs.next() )
         {
           //S1Log.getLogInstance().log("INSIDE while ( rs.next() ): START",LOG_FILE);

           refId = String.valueOf( rs.getInt( "nRefId" ) );

           //S1Log.getLogInstance().log("refId: "+refId,LOG_FILE);
         } // End while (rs.next())

       } // End try
       catch ( SQLException e )
       {
         e.printStackTrace();
         DBLogger.log("Class: AppImportUtils.getRefId() SQL: "+sql+"   SQLException thrown: "+e.getMessage());
       }
       catch ( Exception e )
       {
         e.printStackTrace();
       }

       finally
       {
         DBAccess.closeConnection( stmt );
       }

       //S1Log.getLogInstance().log("END getRefId( String sdoId ): return refId: "+refId,LOG_FILE);

       return refId;
     } // End getRefId( String sdoId )

     public static void updateFeePoints(String username, String points, DataNode appNode)
     {
       List feeList = appNode.getReferences(NodeUtils.FEE_DN_TYPE);
       if (feeList != null)
       {
         String feePctType, feeBasis;
         DataNode feeNode;

         for (int i = 0, c = feeList.size(); i < c; ++i)
         {
           feeNode = (DataNode)feeList.get(i);

           feeBasis = (String)feeNode.getFieldData(CSFieldValues.EMPTY_STRING, CSFieldNames.FN_FEE_BASIS);
           if (feeBasis.equals("1"))
           {
             feePctType = (String)feeNode.getFieldData(CSFieldValues.EMPTY_STRING, CSFieldNames.FN_FEE_PCT_TYPE);
             if (feePctType.equals(CSFieldValues.FV_FEE_TYPE_POINTS_UPPER))
             {
               try
               {
                 HashtableX feeHash = feeNode.getFieldData(username);
                 FeeCalcs.recalculateFee(feeHash, appNode);
                 feeNode.setFieldData(username, feeHash);
               }
               catch (Exception e)
               {
               }

               feeNode.setFieldData(username, CSFieldNames.FN_FEE_PCT, points.trim());

               break;
             }
           }
         }
       }
     }

     public static HashtableX getFeeInformation(String branch, VectorX feesVec)
     throws SQLException
     {
       String feeCodes = null;
       HashtableX feeHash = new HashtableX();
       HashtableX thisFeeHash = null;

       for (int i = 0, c = feesVec.size(); i < c; ++i)
       {
         feeCodes = (String)feesVec.get(i);

         thisFeeHash = CSDataCache.getFeeTableManager().getTableForFee(feeCodes);

         if (thisFeeHash != null)
         {
           feeHash.put(feeCodes, thisFeeHash);
         }
       }

       return feeHash;
     }

     public static void setupDisbursementNodeDemoESL( SystemDataObject sdo, DataNode appNode, List disbNodesList, String username )
      {
        //S1Log.getLogInstance().log("START setupDisbursementNodeDemoESL(...)",LOG_FILE);

        if( disbNodesList != null && ! disbNodesList.isEmpty() )
        {
          double disbTtl = 0.0;
          double nonLoanDisbTtl = 0.0;
          double unsecDisbTtl = 0.0;

          // delete all disbursement nodes for edit
          //
          List disbNodesToDelete = appNode.getEffectiveReferences(NodeUtils.DISB_DN_TYPE);
          //S1Log.getLogInstance().log("if( disbNodesToDelete != null && ! disbNodesToDelete.isEmpty() ): "+( disbNodesToDelete != null && ! disbNodesToDelete.isEmpty() ),LOG_FILE);

          if( disbNodesToDelete != null && ! disbNodesToDelete.isEmpty() )
          {
            for(int a=0,b=disbNodesToDelete.size(); a<b; a++)
            {
              DataNode delNode = (DataNode)disbNodesToDelete.get(a);
              //S1Log.getLogInstance().log("if( delNode != null && ! delNode.isDeleted() ): "+( delNode != null && ! delNode.isDeleted() ),LOG_FILE);
              if( delNode != null && ! delNode.isDeleted() )
              {
                delNode.delete();
              }
            }
          }

          // get the disb node data hash
          //
          for( int i=0, c=disbNodesList.size(); i<c; i++ )
          {
            Object obj = disbNodesList.get(i);

            //errorLog("obj: "+obj,AIU);
            //errorLog("CLASS obj: "+obj.getClass(),AIU);

            HashtableX disbData = null;

            if( obj instanceof String )
            {
              disbData = StringChanger.stringToHashtableX( disbNodesList.get(i).toString() );
            }
            else if( obj instanceof HashtableX )
            {
              disbData = (HashtableX)disbNodesList.get(i);
            }

            if( disbData != null && ! disbData.isEmpty() )
            {
              // String type = (String)disbData.get("dsbTypD");
              //
              String type = (String)disbData.get(CSFieldNames.FN_DSB_TYPE_DDL);

              //S1Log.getLogInstance().log("1 type: "+type,LOG_FILE);

              String translation = translateDisbursementType( type );

              //S1Log.getLogInstance().log("2 translation: "+translation,LOG_FILE);

              disbData.put("dsbType", translation);

              //errorLog("",AIU);//errorLog("3 disbData: "+disbData,AIU);//errorLog("",AIU);

              String amount = (String)disbData.get(CSFieldNames.FN_DSB_AMT);
              {
                disbTtl += StringSupport.strToDouble(amount);
              }

              // public static final String FV_DSB_NONLOAN = "0";
              //
              if (type != null && type.trim().equals(CSFieldValues.FV_DSB_NONLOAN))
              {
                nonLoanDisbTtl += StringSupport.strToDouble( amount );
              }

              if (type != null && type.trim().equals(CSFieldValues.FV_DSB_TYPE_UNSEC_BWR))
              {
                unsecDisbTtl += StringSupport.strToDouble( amount );
              }

              DataNode  disbNode = sdo.createDataNode(username, NodeUtils.DISB_DN_TYPE);
              disbNode.setFieldData(username, disbData);
              appNode.addReference(disbNode);
            }
          } // for( int i=0, c=disbNodesList.size(); i<c; i++ )

          appNode.setFieldData( username, CSFieldNames.FN_DSB_TTL, String.valueOf( disbTtl ) );
          appNode.setFieldData( username, CSFieldNames.FN_DSB_NON_LOAN, String.valueOf( nonLoanDisbTtl ) );
          appNode.setFieldData( username, CSFieldNames.FN_DSB_UNSEC, String.valueOf( unsecDisbTtl ));

        }

        //S1Log.getLogInstance().log("END setupDisbursementNodeDemoESL(...)",LOG_FILE);

        //errorLog("",AIU);//errorLog("END setupDisbursementNode(...)",AIU);//errorLog("",AIU);
      } // setupDisbursementNodeDemoESL(...)


   // called from xml2ms.jar class file SubmitApplication. This method is specific to companies who use the
   // edit feature of the WFE...
   //
   public static void setupCollateralNodeDemoESL( SystemDataObject sdo, DataNode appNode,
                                                  HashtableX collData,  String prodID, String username,
                                                  boolean setPrimaryCollateralCode )
   {
     //S1Log.getLogInstance().log("START setupCollateralNodeDemoESL(...)",AIU);
     //S1Log.getLogInstance().log("collData: "+collData,AIU);
//
// DELETE ALL COLLATERAL
//
     String collFlag = null;
     //VectorX collOwnerList = null;

     if( collData.containsKey("clTypeFlag") )
         {
         collFlag = (String)collData.remove("clTypeFlag"); // automobile
         }
     else if( collData.containsKey("phyTypeFlag") )
         {
         collFlag = (String)collData.remove("phyTypeFlag"); // real estate
         }
     else if( collData.containsKey("lwTypeFlag") )
         {
         collFlag = (String)collData.remove("lwTypeFlag"); // mobile home
         }

     //S1Log.getLogInstance().log("0 collFlag: "+collFlag,AIU);

     if( collFlag != null )
     {
     //S1Log.getLogInstance().log("0.1 prodID: "+prodID,AIU);

     // Fetch the product.
     //
     Product product = CSDataCache.getProductManager().getProduct(prodID);

     //S1Log.getLogInstance().log("0.2 product: "+product,AIU);

     if( product != null )
       {
       //S1Log.getLogInstance().log("1 INSIDE if (product != null)",AIU);

       // get collateral specification table
       //
       String str = product.getCollatSumTbl();

       //S1Log.getLogInstance().log("2 Prd Collat Sum Tbl Str: "+str,AIU);

       if( str != null )
         {
         //S1Log.getLogInstance().log("3 INSIDE if (str != null)",AIU);

         str = StringChanger.getObjectBody(str);

         TableTransaction tt = TableTransaction.stringToObject(str);

         //S1Log.getLogInstance().log("3.1 tt: "+tt,AIU);

         List recs = tt.getRecords();

         //S1Log.getLogInstance().log("3.2 recs required: "+recs,AIU);

         // no records means no collateral node to set up, there are not any accepatable
         // collateral specifications set up for this product move on...
         //
         if( recs != null && !recs.isEmpty() )
           {
           //S1Log.getLogInstance().log("4 INSIDE if (recs != null && ! recs.isEmpty())",AIU);

           String collID   = null;
           String collType = null;
           String collCode = null;
           String primaryCollateralCode = null;

           // loop through records in the product's collateral summary table to find a
           // match for collateral description and then get the associated id number.
           // use the id to load the collateral object
           //
           // if multiple records and no match is found use the first record
           //
           //
           for( int i=0, c=recs.size(); i<c; i++ )
             {
             String temp = (String)recs.get(i); //  used to get first record

             //S1Log.getLogInstance().log("5 temp: "+temp,AIU);

             temp = StringChanger.getObjectBody( temp );

             TableRecord tr = TableRecord.stringToObject( temp );

             // column names from the product editor collateral summary table which are also table keys
             //
             // public static final String idLabel = "ID Number";
             //
             // need to get the id number and then load the collateral object
             //
             // set the default to the first acceptable collateral specification
             //
             if( i == 0 )
                 {
//
// SET DEFAULT COLL ID
//
                 collID = tr.getField("ID Number");
                 //S1Log.getLogInstance().log("6 collID: "+collID,AIU);
                 }

             String tempCollID = tr.getField("ID Number");

             //S1Log.getLogInstance().log("6.1 tempCollID: "+tempCollID,AIU);

             if(tempCollID != null)
               {
               // load the collateral object
               //
               Collateral collateral = CSDataCache.getCollateralManager().getCollateral(tempCollID);

               if (collateral != null)
                 {
                 //S1Log.getLogInstance().log("7 if (collateral != null)",AIU);

                 // set the default to the first acceptable collateral specification
                 //
                 if( i == 0 )
                     {
//
// SET DEFAULT COLL TYPE
//
                     collType = collateral.getClTypD();
                     //S1Log.getLogInstance().log("7.1 collType: "+collType,AIU);
                     }

                 // if( setPrimaryCollateralCode )
                 //
                 // if( true )
                 //
                 if( collData == null || (collData != null && (! collData.containsKey("clCdD")) ) )
                   {
                   VectorX clCdM = collateral.getClCdM();
                   //S1Log.getLogInstance().log("clCdM: "+clCdM,AIU);

                   //if( clCdM != null && ! clCdM.isEmpty() )
                   //  {
                   //  primaryCollateralCode = (String)clCdM.firstElement();
                   //  //S1Log.getLogInstance().log("primaryCollateralCode: "+primaryCollateralCode,AIU);
                   //  }

                   if( clCdM != null && ! clCdM.isEmpty() )
                     {
                       if( clCdM.size() == 1 )
                       {
                         primaryCollateralCode = (String) clCdM.firstElement();
                         //S1Log.getLogInstance().log("SIZE 1 SET primaryCollateralCode: " + primaryCollateralCode, LOG_FILE);
                       }
                       else
                       {
                         //S1Log.getLogInstance().log("SIZE NOT *1* FIND primaryCollateralCode: " + primaryCollateralCode, LOG_FILE);
                         // check list for matching "new/used" in order to make sure the collateral codes are in sink
                         // currently can select new auto for a used auto and visa versa
                         // if a match is not found do not set
                         //
                         int colLocId = collateral.getLocationID();

                         //S1Log.getLogInstance().log("colLocId: " + colLocId, LOG_FILE);
                         //S1Log.getLogInstance().log("if( collData != null && collData.containsKey(clNwUsdD) ): " + ( collData != null && collData.containsKey("clNwUsdD") ), LOG_FILE);

                         // clNwUsdD
                         //
                         String clNwUsdD = null;
                         if( collData != null && collData.containsKey("clNwUsdD") )
                         {
                           clNwUsdD = (String)collData.get("clNwUsdD");
                           //S1Log.getLogInstance().log("clNwUsdD: " + clNwUsdD, LOG_FILE);
                         }

                         //S1Log.getLogInstance().log("if( clNwUsdD != null && clNwUsdD.trim().length() > 0 &&  (clNwUsdD.trim().toLowerCase().equals(new) || clNwUsdD.trim().toLowerCase().equals(used))): " + ( clNwUsdD != null && clNwUsdD.trim().length() > 0 &&  (clNwUsdD.trim().toLowerCase().equals("new") || clNwUsdD.trim().toLowerCase().equals("used"))), LOG_FILE);
                         if( clNwUsdD != null && clNwUsdD.trim().length() > 0 &&  (clNwUsdD.trim().toLowerCase().equals("new") || clNwUsdD.trim().toLowerCase().equals("used")))
                         {
                           for( int ii=0, cc=clCdM.size(); ii<cc; ii++ )
                           {
                             String clCode = (String)clCdM.get(ii);
                             //S1Log.getLogInstance().log("clCode: " + clCode, LOG_FILE);

                             Map collateralTable = null;
                             try
                             {
                               collateralTable = CSDataCache.getCodeTableManager().getDescTableForType( colLocId, "Collateral");
                             }
                             catch( Exception e )
                             {
                               e.printStackTrace();
                             }

                             //S1Log.getLogInstance().log("collateralTable: " + collateralTable, LOG_FILE);
                             if( collateralTable != null && ! collateralTable.isEmpty() )
                             {
                               String description =  getLabelFromLabelValueTable( collateralTable, clCode );

                               //S1Log.getLogInstance().log("description: " + description, LOG_FILE); if( description != null ){S1Log.getLogInstance().log("if( description != null && clNwUsdD != null && description.trim().toLowerCase().indexOf( clNwUsdD.trim().toLowerCase() ) != -1 ): " + ( description != null && clNwUsdD != null && description.trim().toLowerCase().indexOf( clNwUsdD.trim().toLowerCase() ) != -1 ), LOG_FILE);}

                               if( description != null && clNwUsdD != null && description.trim().toLowerCase().indexOf( clNwUsdD.trim().toLowerCase() ) != -1 )
                               {
                                 collCode = clCode;
                                 //S1Log.getLogInstance().log("SET collCode = clCode: " + clCode, LOG_FILE);

                                 primaryCollateralCode = clCode;
                                 //S1Log.getLogInstance().log("SET primaryCollateralCode = clCode: " + clCode, LOG_FILE);

                                 break;
                               }
                             }
                           } //  for( int ii=0, cc=clCdM.size(); ii<cc; ii++ )
                         }
                       }
                     }
                   }

                 String tempCollType = collateral.getClTypD();

                 //S1Log.getLogInstance().log("7.2 tempCollType: "+tempCollType,AIU);
                 //S1Log.getLogInstance().log("7.21 collFlag: "+collFlag,AIU);

                 if( tempCollType != null && tempCollType.length() > 0 )
                   {
                   // String collFlag = collType
                   //
                   //S1Log.getLogInstance().log("7.22 if( collFlag.trim().equals( tempCollType.trim() ) ): "+( collFlag.trim().equals( tempCollType.trim() ) ),AIU);
//
// INCOMING COLLATERAL TYPE EQUALS VALID PRODUCT COLLATERAL TYPE ELSE USE DEFAULT
//
                   if( collFlag.trim().equals( tempCollType.trim() ) )
                     {
                     //S1Log.getLogInstance().log("8 collFlag = collDescFromSumTbl",AIU);
                     //S1Log.getLogInstance().log("8.0 tempCollType: "+tempCollType,AIU);

                     collType = tempCollType;
                     collID   = tempCollID;

                     if( primaryCollateralCode != null )
                     {
                       collCode = primaryCollateralCode;
                     }

                     //S1Log.getLogInstance().log("collCode = primaryCollateralCode: "+primaryCollateralCode,AIU);
                     //S1Log.getLogInstance().log("8.1 collID: "+collID,AIU);
                     //S1Log.getLogInstance().log("8.2 collType: "+collType,AIU);

                     //
                     // break from loop just grab first one
                     //
                     break;
                     }

                   }

                 } // if (collateral != null)

               } // if (collID != null)

             } // for( int i=0; i<recs.size(); i++; )

           // now that you have the acceptable collateral type because it is in the
           // product specification table create the node
           //
           //
           //S1Log.getLogInstance().log("9 collType: "+collType,AIU);
           //S1Log.getLogInstance().log("9.1 collID: "+collID,AIU);
//
// CHECK FOR EXISTING COLLATERAL.
//
           DataNode collNode = appNode.getReference(NodeUtils.COLL_DN_TYPE, 0);
           if( collNode == null )
             {
             //S1Log.getLogInstance().log("10 if (collNode== null)",AIU);

             // Create collateral container node.
             //
             collNode = sdo.createDataNode(username, NodeUtils.COLL_DN_TYPE);
             collNode.setSystemData("!container", "true");
             appNode.addReference(collNode);
             }  // if collNode == null
//
// START - Set up collateral owner list for gui display
//
           // create and add the collateral owner list to the collateral data map
           //
           VectorX bwrVec = appNode.getReferences( NodeUtils.BWR_DN_TYPE );

           //S1Log.getLogInstance().log("10.1 bwrVec: "+bwrVec,AIU);

           if( bwrVec != null && bwrVec.size() > 1 )
             {
             VectorX onrBwrList = new VectorX();
             //S1Log.getLogInstance().log("10.1.0 onrBwrList: "+onrBwrList,AIU);

             for( int i=0, b=bwrVec.size(); i<b; i++ )
               {
               DataNode onrBwrDN = (DataNode)bwrVec.get(i);
               //S1Log.getLogInstance().log("10.1.1 onrBwrDN: "+onrBwrDN,AIU);

               if( onrBwrDN != null && !onrBwrDN.isDeleted() )
                 {
                 int nodePosition = onrBwrDN.getIndex();

                 //S1Log.getLogInstance().log("10.2 nodePosition: "+nodePosition,AIU);

                 if( nodePosition >= 0 )
                   {
                   onrBwrList.addElement( CSFieldValues.EMPTY_STRING + nodePosition );
                   }
                 }
               } // for( int i=1; i<bwrVec; i++ )

             //S1Log.getLogInstance().log("10.3 onrBwrList: "+onrBwrList,AIU);

             if( onrBwrList != null && !onrBwrList.isEmpty() )
               {
               collData.put("_OnrBwrList", onrBwrList);
               }
             } // if( bwrVec != null && bwrVec.size() > 1 )
//
// END - Set up collateral owner list for gui display
//
//
// START - Set up collateral owner node for auto or collateral owner and lien nodes for real estate
//
           //S1Log.getLogInstance().log("10.3.1 collID: "+collID,AIU);
           //S1Log.getLogInstance().log("10.3.2 collType: "+collType,AIU);
           //S1Log.getLogInstance().log("10.3.3 collCode: "+collCode,AIU);

           // add the collater data to the collateral node
           //
           if( collType != null && collID != null )
             {
             String propLienListStr = (String)collData.remove("phyLienList");
             //S1Log.getLogInstance().log("17 propLienListStr: "+propLienListStr,AIU);

             // add data to the collData hash before adding it to the coll data node
             //
             collData.put(CSFieldNames.FN_COLLATERAL_ID,   collID);
             collData.put(CSFieldNames.FN_COLLATERAL_DESC, collType);

             if( collCode != null && collCode.trim().length() > 0 )
             {
               collData.put("clCdD", collCode);
             }
//
// ESLCNHG
//
             // load the data node
             //
             DataNode collSubNodeByType = collNode.getReference(collType,0);

             if (collSubNodeByType == null)
             {
               collSubNodeByType = sdo.createDataNode(username, collType);
             }
             else
             {
               // clean data table
               // clVhTtlVal = incoming value - clVhVal = 0.00
               //
               HashtableX clHt = collSubNodeByType.getFieldData( CSFieldValues.EMPTY_STRING );

               //S1Log.getLogInstance().log("1 clHt: "+clHt,AIU);
               //S1Log.getLogInstance().log("if( clHt != null && (clHt.containsKey( clVhTtlVal ) || clHt.containsKey( clVhVal )) ): "+( clHt != null && (clHt.containsKey( "clVhTtlVal" ) || clHt.containsKey( "clVhVal" )) ),AIU);

               if( clHt != null && (clHt.containsKey( "clVhTtlVal" ) || clHt.containsKey( "clVhVal" )) )
               {
                 if( clHt.containsKey( "clVhTtlVal" ) )
                 {
                   clHt.remove( "clVhTtlVal" );
                 }

                 if( clHt.containsKey( "clVhVal" ) )
                 {
                   clHt.remove( "clVhVal" );
                 }
               }

               //S1Log.getLogInstance().log("2 clHt: "+clHt,AIU);
               collSubNodeByType.setFieldData(username, clHt);
             }

             //
             // translate real estate field names in mobile home field names
             //

             //S1Log.getLogInstance().log("10.3.3 setFieldData: collData: "+collData,AIU);

             collSubNodeByType.setFieldData(username, collData);
             collSubNodeByType.setSystemData(CSFieldNames.FN_COLLATERAL_ID, collID);

             //S1Log.getLogInstance().log("11 collNode: "+collNode,AIU);

             DataNode bwrNode = appNode.getReference( NodeUtils.BWR_DN_TYPE, 0 );

             //S1Log.getLogInstance().log("11.1 collSubNodeByType: "+ collSubNodeByType,AIU);
             //S1Log.getLogInstance().log("12 bwrNode: "+bwrNode,AIU);

             if( bwrNode != null && ! bwrNode.isDeleted() )
               {
               HashtableX bwrHash = bwrNode.getFieldData(CSFieldValues.EMPTY_STRING);

               //S1Log.getLogInstance().log("13 bwrHash: "+bwrHash,AIU);

               if( bwrHash != null && !bwrHash.isEmpty() )
                 {
                 HashtableX onrHash = CSDataCollection.getOnrHT( bwrHash );

                 if( onrHash != null && !onrHash.isEmpty() )
                   {
                   //S1Log.getLogInstance().log("14 onrHash: "+onrHash,AIU);

                   onrHash.put("_onrBwrPOSHid", "0");

                   DataNode onrNode = new DataNode( NodeUtils.ONR_DN_TYPE );

                   onrNode.setDescription( NodeUtils.getNodeDescription( NodeUtils.ONR_DN_TYPE ) );
                   onrNode.setFieldData( username, onrHash );

                   DataNode newOnrNode = sdo.createDataNode( username, "Owner" );

                   if( newOnrNode != null )
                     {
                     newOnrNode.setFieldData( username, onrNode.getFieldData( getName() ) );

                     //S1Log.getLogInstance().log("15 newOnrNode: "+ newOnrNode,AIU);

                     collSubNodeByType.addReference( newOnrNode );

                     //S1Log.getLogInstance().log("16 collNode: "+ collNode,AIU);
                     }

                   } // if( onrHash != null && !onrHash.isEmpty() )

                 } // if( bwrHash != null && !bwrHash.isEmpty() )

               } // if( bwrNode != null && !bwrNode.isDeleted() )

             // add the new node that contains the collateral data to the collater
             // node container
             //
             //collNode.addReference( collSubNodeByType );
             //S1Log.getLogInstance().log("17 add newNode to collNode: "+ collNode,AIU);

             //
             // add lien node
             //

             // 12-18-01, ccl
             // Add the Lien nodes into collateral node.
             //
             //VectorX lienVec = (VectorX)tempLiens.get(appID);

             List propertyLienList = null;
             //String propLienListStr = (String)collData.get("phyLienList");
             //S1Log.getLogInstance().log("17 propLienListStr: "+propLienListStr,AIU);

             if( propLienListStr != null && propLienListStr.length() > 0 )
                 {
                 propertyLienList = StringChanger.stringToVector( propLienListStr );
                 }

             //S1Log.getLogInstance().log("17.1 propertyLienList: "+propertyLienList,AIU);
             //S1Log.getLogInstance().log("17.2 collSubNodeByType: "+ collSubNodeByType,AIU);

             if( propertyLienList != null && ! propertyLienList.isEmpty() )
                 {
                 for (int i=0; i<propertyLienList.size(); i++)
                   {
                   // DataNode lnDN = (DataNode)lienVec.elementAt(i);
                   //
                   // HashtableX lienData = (HashtableX)propertyLienList.get( i );
                   //
                   // HashtableX lienData =
                   // StringChanger.stringToHashtableX( propertyLienList.get(i).toString() );
                   //
                   Object objLien = propertyLienList.get( i );

                   //S1Log.getLogInstance().log("objLien: "+objLien,AIU);
                   //S1Log.getLogInstance().log("CLASS objLien: "+objLien.getClass(),AIU);

                   HashtableX lienData = null;

                   if( objLien instanceof String )
                   {
                     lienData = StringChanger.stringToHashtableX( propertyLienList.get(i).toString() );
                   }
                   else if( objLien instanceof HashtableX )
                   {
                     lienData = (HashtableX)propertyLienList.get(i);
                   }

                   //S1Log.getLogInstance().log("18 lienData: "+lienData,AIU);

                   if( lienData != null && ! lienData.isEmpty() )
                     {
                     DataNode newLnDN = sdo.createDataNode( username, "Lien" );
                     newLnDN.setFieldData( username, lienData );

                     //S1Log.getLogInstance().log("19 newLnDN: "+newLnDN,AIU);

                     collSubNodeByType.addReference( newLnDN );
                     }
                   }
                 }

             // add the new node that contains the collateral data to the collater
             // node container
             //
             //S1Log.getLogInstance().log("19.1 collSubNodeByType: "+ collSubNodeByType,AIU);

             collNode.addReference( collSubNodeByType );

             if( setPrimaryCollateralCode )
               {
                 if( primaryCollateralCode != null && primaryCollateralCode.trim().length() > 0 )
                 {
                   appNode.setFieldData(username, "anPrmClCdD", primaryCollateralCode);
                 }
                 else if( collData != null && collData.containsKey("clCdD") )
                 {
                   primaryCollateralCode = (String)collData.get("clCdD");
                   if( primaryCollateralCode != null && primaryCollateralCode.trim().length() > 0 )
                   {
                     appNode.setFieldData(username, "anPrmClCdD", primaryCollateralCode);
                   }

                 }

               }

             //S1Log.getLogInstance().log("20 add newNode to collNode: "+ collNode,AIU);

//
// START - Set up collateral owner and lien nodes for real estate
//

             } // if( collType != null && collID != null )

           } // if (recs != null && !recs.isEmpty())

         } // if( str != null )

       } // if (product != null)

     } // if( collFlag != null )

     //S1Log.getLogInstance().log("START setupCollateralNodeDemoESL(...)",AIU);

   } // setupCollateralNodeDemoESL(...)

   public static void setupDisbursementNodeDemoESL( SystemDataObject sdo, DataNode appNode, HashtableX disbData )
   {
     List disbNodesList = new ArrayList();
     disbNodesList.add(disbData);

     // setupDisbursementNode( sdo, appNode, disbData, CSFieldValues.EMPTY_STRING );
     //
     setupDisbursementNodeDemoESL( sdo, appNode, disbNodesList, CSFieldValues.EMPTY_STRING );
   } // setupDisbursementNode(...)

   /*
    application:Authorized User.0:auBllgCntct =
    application:Authorized User.0:auFName = Tammy
    application:Authorized User.0:auGenPlC = false
    application:Authorized User.0:auLName = Jones
    application:Authorized User.0:auMInit = R
    application:Authorized User.0:auPrmySgnr =
    application:Authorized User.0:auRel =
    application:Authorized User.0:isPropagate = false
    application:Authorized User.0:isVirtual = false
    application:Authorized User.0:isVirtualModified = false
    application:Authorized User.1:auBllgCntct =
    application:Authorized User.1:auFName = Franie
    application:Authorized User.1:auGenPlC = false
    application:Authorized User.1:auLName = Jones
    application:Authorized User.1:auMInit = P
    application:Authorized User.1:auPrmySgnr =
    application:Authorized User.1:auRel =
    application:Authorized User.1:isPropagate = false
    application:Authorized User.1:isVirtual = false
    application:Authorized User.1:isVirtualModified = false
    application:Authorized User_count = 2
   */
   public static void setupAuthorizedUserNode( SystemDataObject sdo, DataNode appNode,
                                               List userNodeList, String username )
   {
    //S1Log.getLogInstance().log("3 START setupAuthorizedUserNode(...)",LOG_FILE);

     if( userNodeList != null && ! userNodeList.isEmpty() )
     {
       // need to edit authorized users. delete current authorized users if nodes exist and create new ones.
       //
       VectorX auVec = appNode.getEffectiveReferences(NodeUtils.AUTH_USER_DN_TYPE);
       //S1Log.getLogInstance().log("auVec: "+auVec,LOG_FILE);

       if( auVec != null && ! auVec.isEmpty() )
       {
         for( int au=0, cu=userNodeList.size(); au<cu; au++ )
         {
           DataNode auDN = ( DataNode ) auVec.get( au );
           auDN.delete();
           //S1Log.getLogInstance().log("auDN.delete(): ",LOG_FILE);
         }
       }

       // get the disb node data hash
       //
       for( int i=0, c=userNodeList.size(); i<c; i++ )
       {
         Object obj = userNodeList.get(i);

        //S1Log.getLogInstance().log("obj.getClass(): "+obj.getClass(),LOG_FILE);

         HashtableX userData = null;

         if( obj instanceof String )
         {
           userData = StringChanger.stringToHashtableX( userNodeList.get(i).toString() );
           //S1Log.getLogInstance().log("1 userData: "+userData,LOG_FILE);
         }
         else if( obj instanceof HashtableX )
         {
           userData = (HashtableX)userNodeList.get(i);
           //S1Log.getLogInstance().log("2 userData: "+userData,LOG_FILE);
         }

         if( userData != null && ! userData.isEmpty() )
         {
           DataNode userNode = sdo.createDataNode(username, NodeUtils.AUTH_USER_DN_TYPE);
           //S1Log.getLogInstance().log("username: "+username,LOG_FILE);

           //S1Log.getLogInstance().log("3 userData: "+userData,LOG_FILE);
           CSUtil.defaultAuthorizedUserName(userData);           
           userNode.setFieldData(username, userData);
           appNode.addReference(userNode);
         }

       } // for( int i=0, c=userNodeList.size(); i<c; i++ )

       // set field symL for au multi select list box
       //
       // ("auSmyL", DataEntrySupport.buildSubNodeDescriptionsList(appNode, NodeUtils.AUTH_USER_DN_TYPE));

     } // if( userNodeList != null && ! userNodeList.isEmpty() )

    //S1Log.getLogInstance().log("3 END setupAuthorizedUserNode(...)",LOG_FILE);

   } // setupAuthorizedUserNode(...)

   public static void getProductInfo(SystemDataObject sdo, String username, HashtableX outFieldsHash)
   {
     // 5-10-2001
     // Get Product object.
     //
     DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);

     String type = (String) appNode.getSystemData(CSFieldNames.FN_APP_TYPE);
     boolean isConsumer = type == null || type.equals("c");
     boolean isMortgage = type != null && type.equals("m"); // 9-8-07, ccl

     String branch = (String) appNode.getFieldData(username,
                                                   CSFieldNames.FN_BRANCH_ID);
     int branchLoc = StringSupport.strToInt(branch);

     //String prodID = isConsumer ?
     String prodID = (isConsumer || isMortgage) ?
         (String) appNode.getFieldData(CSFieldValues.EMPTY_STRING,
                                       CSFieldNames.FN_PRODUCT_ID) :
         (String) appNode.getFieldData(CSFieldValues.EMPTY_STRING,
                                       CSFieldNames.FN_SBPRODUCT_ID);

     Product product = null;
     SBProduct sbProduct = null;
     MtgProduct mgProduct = null;
     String progID = (String) appNode.getFieldData(CSFieldValues.EMPTY_STRING,
                                                   "anProgTypeD");
     Program program = null;

     if (isConsumer) {
       product = CSDataCache.getProductManager().getProduct(prodID);
     }
     else if (isMortgage) {
       mgProduct = CSDataCache.getMtgProductManager().getProduct(prodID);
       if (progID == null)return;
       program = CSDataCache.getProgramManager().getProgram(progID);
     }
     else {
       sbProduct = CSDataCache.getSBProductManager().getProduct(prodID);
     }

     // Convert the Product object body to a hash table for accessing the stored
     // data.

     // Get some required field values
     //

     VectorX intAccrual = isConsumer ? product.getIntAccrual() :
         isMortgage ? program.getIntAccrual() : sbProduct.getPrdPSIntAccrM();

     VectorX intPmtTypes = isConsumer ? product.getPymtTypesSel() :
         isMortgage ? program.getPymtTypesSel() : sbProduct.getPrdPSPmtTypM();

     VectorX intPmtPrds = isConsumer ? product.getPymtPrdSel() :
         isMortgage ? program.getPymtPrdSel() : sbProduct.getPrdPSPmtPrdM();

     if (intAccrual == null) {
       intAccrual = new VectorX();
     }
     if (intPmtTypes == null) {
       intPmtTypes = new VectorX();
     }
     if (intPmtPrds == null) {
       intPmtPrds = new VectorX();
     }

     // 11-13-08, ccl
     //
     /*
     String thisQTLCd = (String) outFieldsHash.get("anQTLCdD");
     String thisIntAcr = (String) outFieldsHash.get(CSFieldNames.FN_INT_ACCRUAL);
     */

     String thisQTLCd = null;
     Object thisQTLCdObject = outFieldsHash.get("anQTLCdD");

     //general.errLog("DataEntrySupport: getProductInfo: thisQTLCd = " + thisQTLCd);

     if (thisQTLCdObject != null) {
       if (thisQTLCdObject instanceof String) {
         thisQTLCd = (String) thisQTLCdObject;
       }
       else {
         if (! ( (VectorX) thisQTLCdObject).isEmpty()) {
           thisQTLCd = (String) ( (VectorX) thisQTLCdObject).firstElement();
         }
         else {
           thisQTLCd = CSFieldValues.EMPTY_STRING;
         }
       }
     }

     String thisIntAcr = null;
     Object thisIntAcrObject = outFieldsHash.get(CSFieldNames.FN_INT_ACCRUAL);

     if (thisIntAcrObject != null) {
       if (thisIntAcrObject instanceof String) {
         thisIntAcr = (String) thisIntAcrObject;
       }
       else {
         if (! ( (VectorX) thisIntAcrObject).isEmpty()) {
           thisIntAcr = (String) ( (VectorX) thisIntAcrObject).firstElement();
         }
         else {
           thisIntAcr = CSFieldValues.EMPTY_STRING;
         }
       }
     }

     String thisPmtType = null;
     Object pmtTypeObject = outFieldsHash.get(CSFieldNames.FN_PMT_TYPE);
//general.errLog("DataEntrySupport: getProductInfo: pmtTypeObject = " + pmtTypeObject);
//general.errLog("DataEntrySupport: getProductInfo: pmtTypeObject 1 = " + pmtTypeObject.getClass());
     if (pmtTypeObject != null) {
       if (pmtTypeObject instanceof String) {
         thisPmtType = (String) pmtTypeObject;
       }
       else {
         //thisPmtType = (String) ( (VectorX) pmtTypeObject).firstElement();   // 12-4-06, ccl
         if (! ( (VectorX) pmtTypeObject).isEmpty()) {
           thisPmtType = (String) ( (VectorX) pmtTypeObject).firstElement();
         }
         else {
           thisPmtType = CSFieldValues.EMPTY_STRING;
         }
       }
     }

     // 11-13-08, ccl
     //
     /*
     String thisPmtPrd = (String) outFieldsHash.get(CSFieldNames.FN_PMT_PRD);

     String thisIntPmtPrd = (String) outFieldsHash.get(CSFieldNames.
         FN_INT_PMT_PRD);
     String thisIrrPmtPrd = (String) outFieldsHash.get(CSFieldNames.
         FN_IRR_PMT_PERIOD);
     */
     String thisPmtPrd = null;
     Object thisPmtPrdObject = outFieldsHash.get(CSFieldNames.FN_PMT_PRD);

     if (thisPmtPrdObject != null) {
       if (thisPmtPrdObject instanceof String) {
         thisPmtPrd = (String) thisPmtPrdObject;
       }
       else {
         if (! ( (VectorX) thisPmtPrdObject).isEmpty()) {
           thisPmtPrd = (String) ( (VectorX) thisPmtPrdObject).firstElement();
         }
         else {
           thisPmtPrd = CSFieldValues.EMPTY_STRING;
         }
       }
     }

     String thisIntPmtPrd = null;
     Object thisIntPmtPrdObject = outFieldsHash.get(CSFieldNames.FN_INT_PMT_PRD);

     if (thisIntPmtPrdObject != null) {
       if (thisIntPmtPrdObject instanceof String) {
         thisIntPmtPrd = (String) thisIntPmtPrdObject;
       }
       else {
         if (! ( (VectorX) thisIntPmtPrdObject).isEmpty()) {
           thisIntPmtPrd = (String) ( (VectorX) thisIntPmtPrdObject).firstElement();
         }
         else {
           thisIntPmtPrd = CSFieldValues.EMPTY_STRING;
         }
       }
     }

     String thisIrrPmtPrd = null;
     Object thisIrrPmtPrdObject = outFieldsHash.get(CSFieldNames.FN_IRR_PMT_PERIOD);

     if (thisIrrPmtPrdObject != null) {
       if (thisIrrPmtPrdObject instanceof String) {
         thisIrrPmtPrd = (String) thisIrrPmtPrdObject;
       }
       else {
         if (! ( (VectorX) thisIrrPmtPrdObject).isEmpty()) {
           thisIrrPmtPrd = (String) ( (VectorX) thisIrrPmtPrdObject).firstElement();
         }
         else {
           thisIrrPmtPrd = CSFieldValues.EMPTY_STRING;
         }
       }
     }

     outFieldsHash.put("anQTLCdD", DataEntrySupport.getRefreshedQTLCodes(branchLoc, thisQTLCd));
     outFieldsHash.put(CSFieldNames.FN_INT_ACCRUAL,
                       thisIntAcr == null ? intAccrual :
                       ClientUtils.markListSelection(thisIntAcr,
         (VectorX) intAccrual.clone()));

     outFieldsHash.put(CSFieldNames.FN_PMT_TYPE,
                       thisPmtType == null ? intPmtTypes :
                       ClientUtils.markListSelection(thisPmtType,
         (VectorX) intPmtTypes.clone()));

     outFieldsHash.put(CSFieldNames.FN_PMT_PRD, thisPmtPrd == null ? intPmtPrds :
                       ClientUtils.markListSelection(thisPmtPrd,
         (VectorX) intPmtPrds.clone()));

     outFieldsHash.put(CSFieldNames.FN_INT_PMT_PRD,
                       thisIntPmtPrd == null ? intPmtPrds :
                       ClientUtils.markListSelection(thisIntPmtPrd,
         (VectorX) intPmtPrds.clone()));

     outFieldsHash.put(CSFieldNames.FN_IRR_PMT_PERIOD,
                       thisIrrPmtPrd == null ? intPmtPrds :
                       ClientUtils.markListSelection(thisIrrPmtPrd,
         (VectorX) intPmtPrds.clone()));

     String calculation = SystemProperties.getProperty(CSFieldNames.
         SYS_CALCULATION);
     //boolean creditInsAvailable = isConsumer ? product.getPrdCInsC() :
     //    sbProduct.getPrdCInsC();
     boolean creditInsAvailable = isConsumer ? product.getPrdCInsC() :
         isMortgage ? program.getCInsC() : sbProduct.getPrdCInsC();

     if (creditInsAvailable &&
         (calculation == null || !calculation.equals(CSFieldValues.SYS_CALC_CUNA)))
     {
       String thisCINSType = null;
       Object cinsTypeObject = outFieldsHash.get(CSFieldNames.FN_CINS_TYPE);

       if (cinsTypeObject != null) {
         if (cinsTypeObject instanceof String) {
           thisCINSType = (String) cinsTypeObject;
         }
         else {
           if (! ( (VectorX) cinsTypeObject).isEmpty()) {
             thisCINSType = (String) ( (VectorX) cinsTypeObject).firstElement();
           }
           else {
             thisCINSType = CSFieldValues.EMPTY_STRING;
           }
         }
       }

       outFieldsHash.put(CSFieldNames.FN_CINS_TYPE,
                         DataEntrySupport.getRefreshedCreditLifeTypes(thisCINSType));

       String thisAHType = null;
       Object ahTypeObject = outFieldsHash.get(CSFieldNames.FN_CINS_AH_TYPE);

       if (ahTypeObject != null) {
         if (ahTypeObject instanceof String) {
           thisAHType = (String) ahTypeObject;
         }
         else {
           if (! ( (VectorX) ahTypeObject).isEmpty()) {
             thisAHType = (String) ( (VectorX) ahTypeObject).firstElement();
           }
           else {
             thisAHType = CSFieldValues.EMPTY_STRING;
           }
         }
       }

       outFieldsHash.put(CSFieldNames.FN_CINS_AH_TYPE,
                         DataEntrySupport.getRefreshedCreditLifeTypes(thisAHType));

       String thisCVRD1 = null;
       Object cvrd1Object = outFieldsHash.get(CSFieldNames.FN_CINS_CVRD_ONE);

       if (cvrd1Object != null) {
         if (cvrd1Object instanceof String) {
           thisCVRD1 = (String) cvrd1Object;
         }
         else {
           if (! ( (VectorX) cvrd1Object).isEmpty()) {
             thisCVRD1 = (String) ( (VectorX) cvrd1Object).firstElement();
           }
           else {
             thisCVRD1 = CSFieldValues.EMPTY_STRING;
           }
         }
       }

       String thisCVRD2 = null;
       Object cvrd2Object = outFieldsHash.get(CSFieldNames.FN_CINS_CVRD_TWO);

       if (cvrd2Object != null) {
         if (cvrd2Object instanceof String) {
           thisCVRD2 = (String) cvrd2Object;
         }
         else {
           if (! ( (VectorX) cvrd2Object).isEmpty()) {
             thisCVRD2 = (String) ( (VectorX) cvrd2Object).firstElement();
           }
           else {
             thisCVRD2 = CSFieldValues.EMPTY_STRING;
           }
         }
       }

       outFieldsHash.put(CSFieldNames.FN_CINS_CVRD_ONE,
                         DataEntrySupport.getRefreshedCreditLifeCoveredBorrowers(appNode, thisCVRD1, false));

       outFieldsHash.put(CSFieldNames.FN_CINS_CVRD_TWO,
                         DataEntrySupport.getRefreshedCreditLifeCoveredBorrowers(appNode, thisCVRD2, true));
     }

     if (appNode != null)
     {
       DataEntrySupport.createDefaultFeeNodes(sdo, appNode, username);
       DataEntrySupport.updateFeeTotals(appNode, username, outFieldsHash);

       //getInstance().log(" getProductDefaultInfo ");

       if (isConsumer) {
         // 9-8-07, ccl
         //getInstance().updateRateType(appNode, username, product, sdo,
         //                             outFieldsHash, isConsumer);
         updateRateType(appNode, username, product, sdo, outFieldsHash);
       }
       else if (isMortgage) {
         // default interest only
         outFieldsHash.put(CSFieldNames.FN_IS_INT_ONLY,
                           String.valueOf(program.getPgIntC()));
         outFieldsHash.put(CSFieldNames.FN_INT_ONLY_NUM_PMT,
                           String.valueOf(program.getPgInt()));

         // default amort term
         outFieldsHash.put(CSFieldNames.FN_AMORT_PRD,
                           String.valueOf(program.getpgAmortTerm()));
         outFieldsHash.put(CSFieldNames.FN_NUM_PMT,
                           String.valueOf(program.getPgTerm()));
         outFieldsHash.put(CSFieldNames.FN_NUM_INT_PMT,
                           String.valueOf(program.getPgInt()));

         String rtTypeR = program.getPgAmortR();

         if (rtTypeR != null) {
           if (rtTypeR.equals("0")) {
             outFieldsHash.put("anRtTypR", "Fixed");
           }
           else {
             outFieldsHash.put("anRtTypR", "Variable");
             if (program.getPgIdx() != null) {
               VectorX indexes = new VectorX();
               indexes.add(program.getPgIdx());
               outFieldsHash.put("anIdxD", IndexRate.getCodesDescriptions(indexes));
             }
           }
         }
       }
       else {
         //getInstance().updateRateType(appNode, username, sbProduct, sdo,
         //                             outFieldsHash, isConsumer);
         updateRateType(appNode, username, sbProduct, sdo, outFieldsHash);
       }

       // getInstance().log(" getProductInfo " + outFieldsHash.get("anRtTypD") + " " + outFieldsHash.get("anIdxD"));
     }

     // disclaimer
     //
     // Retrieve the disclaimer section name from the product and populate the
     // outfieldshash _DisclaimA field.   If no default in the product, do not
     // populate the field.
     //
     // String disclaimer = isConsumer ? product.getPrdDisclaimer() : sbProduct.getPrdDisclaimer();
     //
     //String disclaimer = isConsumer ? product.getPrdDisclaimer() : CSFieldValues.EMPTY_STRING;
     String disclaimer = isConsumer ? product.getPrdDisclaimer() :
         isMortgage ? mgProduct.getPrdDisclaimer() : CSFieldValues.EMPTY_STRING;

     if (disclaimer != null && disclaimer.trim().length() > 0) {
       Configuration cfg = new Configuration();
       cfg.load("config" + File.separator + "ListContents.ini");

       VectorX discList = cfg.getSectionElements(disclaimer.trim());
       if (discList != null && !discList.isEmpty()) {
         outFieldsHash.put("_DisclaimA", discList);
       }
     }

   } // getProductInfo(...)

   public static void getProductDefaultData( GenericProduct product, HashtableX appData, boolean APP_TYPE_CONSUMER, boolean APP_TYPE_MORTGAGE ) throws Exception
   {
     //S1Log.getLogInstance().log("START getProductDefaultData( GenericProduct product, HashtableX appData, boolean APP_TYPE_CONSUMER, boolean APP_TYPE_MORTGAGE )", LOG_FILE);

     if( appData != null && ! appData.isEmpty() )
     {
       String branchId = (String)appData.get(CSFieldNames.FN_BRANCH_ID);
       //S1Log.getLogInstance().log("branchId: "+branchId, LOG_FILE);

       int branch = StringSupport.strToInt(branchId);
       //S1Log.getLogInstance().log("branch: "+branch, LOG_FILE);

       String anCBD = null;
       String productID = null;
       String anGenPurD = null;
       String anLoanPur = null; // specific use fo proceeds
       String anProgTypeD = null;
       String anLoanPurCdD = null; // application loan type
       String isPrePaidInterest = null;
       String accruelIntCalcMeth = null;
       String firstInterestAccruel = null;

       //VectorX anGenPurM = new VectorX();
       VectorX anPrmClCdD = new VectorX();

       try
       {
         productID = (String) appData.get("anProdTypeD");
         //S1Log.getLogInstance().log("productID: " + productID, LOG_FILE);

         // need to get the int accruel for this product. if more than one use the first one
         // 2-24-03 needed for calculation purposes
         //
         VectorX intAccruelVec = product.getIntAccrual();
         //S1Log.getLogInstance().log("intAccruelVec: " + intAccruelVec, LOG_FILE);

         if (intAccruelVec != null && ! intAccruelVec.isEmpty())
         {
           accruelIntCalcMeth = (String) intAccruelVec.firstElement();
           //S1Log.getLogInstance().log("accruelInt: " + accruelIntCalcMeth, LOG_FILE);

           // accruel interest calculation method
           //
           if( accruelIntCalcMeth != null && accruelIntCalcMeth.length() > 0 )
           {
             // approved credit terms set anIntAccD to first value from the from product
             //
             if (!appData.containsKey(CSFieldNames.FN_INT_ACCRUAL))
             {
               appData.put(CSFieldNames.FN_INT_ACCRUAL, accruelIntCalcMeth);
             }
           }
         }

         VectorX intPmtVec = product.getPymtTypesSel();
         if( intPmtVec != null && ! intPmtVec.isEmpty() )
         {
           String intPmtType = (String) intPmtVec.firstElement();
           //S1Log.getLogInstance().log("intPmtType: " + intPmtType, LOG_FILE);

           // accruel interest calculation method
           //
           if( intPmtType != null && intPmtType.length() > 0 )
           {
             // approved credit terms set anIntAccD to first value from the from product
             //
             if (!appData.containsKey(CSFieldNames.FN_PMT_TYPE))
             {
               appData.put(CSFieldNames.FN_PMT_TYPE, intPmtType);
               CSUtil.translatePmtType( (String)appData.get( CSFieldNames.FN_PMT_TYPE ), appData );
             }
           }
         }

         VectorX intPmtPrdVec = product.getPymtPrdSel();
         if( intPmtPrdVec != null && ! intPmtPrdVec.isEmpty() )
         {
           String intPmtPrd = (String) intPmtPrdVec.firstElement();
           //S1Log.getLogInstance().log("intPmtPrd: " + intPmtPrd, LOG_FILE);

           // accruel interest calculation method
           //
           if( intPmtPrd != null && intPmtPrd.length() > 0 )
           {
             // approved credit terms set anIntAccD to first value from the from product
             //
             appData.put(CSFieldNames.FN_PMT_PRD, intPmtPrd);
           }
         }

         // product defaults
         //
         isPrePaidInterest = String.valueOf(product.getPrePaidIntC());
         if (isPrePaidInterest != null && isPrePaidInterest.trim().length() > 0  )
         {
           if (!appData.containsKey(CSFieldNames.FN_IS_PREPAID_INT))
           {
             appData.put(CSFieldNames.FN_IS_PREPAID_INT, isPrePaidInterest);
           }
         }

         firstInterestAccruel = product.getFirstIntAccrual();
         if (firstInterestAccruel != null)
         {
           if (!appData.containsKey(CSFieldNames.FN_1ST_INT_ACCRUAL))
           {
             appData.put(CSFieldNames.FN_1ST_INT_ACCRUAL, firstInterestAccruel);
           }
         }

         // ckd said get the credit bureau from the product 2-5-03
         //
         anCBD = product.getPrdDefCBD();

         //S1Log.getLogInstance().log("anCBD: " + anCBD, LOG_FILE);
         //S1Log.getLogInstance().log("appData.containsKey(anCBD): " + appData.containsKey("anCBD"), LOG_FILE);
         //S1Log.getLogInstance().log("creditBureau from product: " + anCBD, LOG_FILE);

         // check the product for the credit bureau account
         //
         //  throw new Exception( "The incoming Credit Bureau from the XML Import "+
         //  "does not match the Credit Bureau that has been set for this product "+
         //  "in the Product Editor. XML:"+xmlAnCBD+" Product Ed:"+anCBD );
         //
         if( appData.containsKey("anCBD") )
         {
           String xmlAnCBD = (String) appData.get("anCBD");
           //S1Log.getLogInstance().log("7 xmlAnCBD: " + xmlAnCBD, LOG_FILE);

           // compare xml imported anCBD to the Product's anCBD
           //
           if (!xmlAnCBD.equalsIgnoreCase(anCBD))
           {
             // use the bureau from the xml sheet
             //
             anCBD = xmlAnCBD;
           }

           if (anCBD != null)
           {
             appData.put(CSFieldNames.FN_CB, anCBD);
           }

         }

         if (anCBD != null && ! appData.containsKey(CSFieldNames.FN_CB) )
         {
           appData.put(CSFieldNames.FN_CB, anCBD);
         }

         // get application loan type getPrdLoanType
         //
         anLoanPurCdD = product.getPrdLoanType();
         //S1Log.getLogInstance().log("anLoanPurCdD: " + anLoanPurCdD, LOG_FILE);

         if (anLoanPurCdD != null)
         {
           appData.put(CSFieldNames.FN_LOAN_PUR_SELECTION, anLoanPurCdD);
         }

         // get the specific use of proceeds
         //
         anLoanPur = product.getPrdLoanPur();
         //S1Log.getLogInstance().log("specisic use fo proceeds from product: " + anLoanPur, LOG_FILE);

         if (!appData.containsKey(CSFieldNames.FN_LOAN_PURPOSE))
         {
           if (anLoanPur != null && anLoanPur.trim().length() > 0)
           {
             appData.put(CSFieldNames.FN_LOAN_PURPOSE, anLoanPur);
           }
         }

         // get default general purpose
         //
         anGenPurD = product.getPrdGenPurD();
         //S1Log.getLogInstance().log("specisic use fo proceeds from product: " + anLoanPur, LOG_FILE);

         String customer = SystemProperties.getProperty( CSFieldNames.SYS_CUSTOMER );
         if (customer == null) customer = CSFieldValues.EMPTY_STRING;

         //S1Log.getLogInstance().log("if( ! appData.containsKey( CSFieldNames.FN_PURPOSE_GEN ) ): " + (!appData.containsKey(CSFieldNames.FN_PURPOSE_GEN)), LOG_FILE);
         if( ! appData.containsKey(CSFieldNames.FN_PURPOSE_GEN) &&
             ! appData.containsKey(CSFieldNames.FN_PURPOSE_GEN_D ) )
         {
           // use product defaults
           //
           // product default general purpose
           if (anGenPurD != null && anGenPurD.trim().length() > 0)
           {
             if( customer.trim().toUpperCase().equals("VACU") ||
                 customer.trim().toUpperCase().equals("VIRGINIA") ||
                 APP_TYPE_MORTGAGE )
             {
               appData.put("anGenPurD", anGenPurD);
             }
             else
             {
               VectorX genPurVec = new VectorX();
               genPurVec.add(anGenPurD);
               appData.put("anGenPurM", genPurVec);
             }
           }
         }
         else
         {
           String genPurStr = (String) appData.remove(CSFieldNames.FN_PURPOSE_GEN);
           if (genPurStr != null && genPurStr.trim().length() > 0)
           {
             if( customer.trim().toUpperCase().equals("VACU") ||
                 customer.trim().toUpperCase().equals("VIRGINIA") ||
                 APP_TYPE_MORTGAGE )
             {
               appData.put("anGenPurD", genPurStr);
             }
             else
             {
               appData.put("anGenPurM", StringChanger.stringToVector(genPurStr));
             }
           }
         }

         // get collateral code for verification
         //
         anPrmClCdD = product.getUnsecuredCollatCodes();
         //S1Log.getLogInstance().log("collateral code vec from product: anPrmClCdD: " + anPrmClCdD, LOG_FILE);

         // add collateral code associated with product to application node
         //
         if( ! appData.containsKey("anPrmClCdD") )
         {
           if( anPrmClCdD != null && ! anPrmClCdD.isEmpty() )
           {
             Iterator it = anPrmClCdD.iterator();
             while( it.hasNext() )
             {
               String code = (String)it.next();
               if( code != null && code.trim().length() > 0 )
               {
                 appData.put("anPrmClCdD", code);
                 break;
               }
             }
           }
         }

         // public static void getRequiredTime(String prodId, HashtableX outFieldsHash)
         // public static void getRequiredTime(Product product, HashtableX outFieldsHash)
         //
         // Add to app node hash, ckd-ajd, 2-26-08
         //
         HashtableX prdHt = new HashtableX();
         //S1Log.getLogInstance().log("1 prdHt: " + prdHt, LOG_FILE);

         DataEntrySupport.getRequiredTime( product, prdHt );

         // CSGenUtils
         //
         //S1Log.getLogInstance().log("2 prdHt: " + prdHt, LOG_FILE);
         if( prdHt != null && ! prdHt.isEmpty() )
         {
           appData.putAll(prdHt);
         }

         String disclaimer = product.getPrdDisclaimer();

         if (disclaimer != null && disclaimer.trim().length() > 0)
         {
           VectorX discList = ApplicationHouse.getListContentCache().getListContents( disclaimer.trim() );
           if (discList != null && !discList.isEmpty())
           {
             appData.put("_DisclaimA", discList);
           }
         }

         if( APP_TYPE_CONSUMER )
         {
           String prdQTLCode = ((Product)product).getPrdQTLCode();
           appData.put("anQTLCdD", DataEntrySupport.getRefreshedQTLCodes(branch, prdQTLCode));

           String prdCollOff = ((Product)product).getDfltCollOfficer();
           appData.put("anColOffD", prdCollOff);
         }

         //S1Log.getLogInstance().log("if( ! appData.containsKey( CSFieldNames.FN_PROGRAM_ID ) && APP_TYPE_MORTGAGE ): " + ( ! appData.containsKey( CSFieldNames.FN_PROGRAM_ID ) && APP_TYPE_MORTGAGE ), LOG_FILE);
         //S1Log.getLogInstance().log("if( APP_TYPE_MORTGAGE ): " + ( APP_TYPE_MORTGAGE ), LOG_FILE);
         if( APP_TYPE_MORTGAGE )
         {
            // getCurrentPrograms
            //
            // Map prgMap = ((MtgProduct)getCurrentProduct()).getProgramsTable();
            //
            try
            {
              String prdQTLCode = ((MtgProduct)product).getPrdQTLCode();
              appData.put("anQTLCdD", DataEntrySupport.getRefreshedQTLCodes(branch, prdQTLCode));

              String prdCollOff = ((MtgProduct)product).getDfltCollOfficer();
              appData.put("anColOffD", prdCollOff);

              //S1Log.getLogInstance().log("if( ! appData.containsKey( CSFieldNames.FN_PROGRAM_ID ) ): " + ( ! appData.containsKey( CSFieldNames.FN_PROGRAM_ID ) ), LOG_FILE);
              if( ! appData.containsKey( CSFieldNames.FN_PROGRAM_ID ) )
              {
                Calendar cal = Calendar.getInstance();

                anProgTypeD = ((MtgProduct)product).getFirstCurrentProgramId( cal, false );
                //S1Log.getLogInstance().log("anProgTypeD: " + anProgTypeD, LOG_FILE);

                if( anProgTypeD != null && anProgTypeD.trim().length() > 0 )
                {
                  appData.put( CSFieldNames.FN_PROGRAM_ID, anProgTypeD );

                  Program program = CSDataCache.getProgramManager().getProgram( anProgTypeD );
                  if( program != null )
                  {
                    // default interest only
                    appData.put(CSFieldNames.FN_IS_INT_ONLY, String.valueOf(program.getPgIntC()));
                    appData.put(CSFieldNames.FN_INT_ONLY_NUM_PMT, String.valueOf(program.getPgInt()));

                    // default amort term
                    appData.put(CSFieldNames.FN_AMORT_PRD, String.valueOf(program.getpgAmortTerm()));
                    appData.put(CSFieldNames.FN_NUM_PMT, String.valueOf(program.getPgTerm()));
                    appData.put(CSFieldNames.FN_NUM_INT_PMT, String.valueOf(program.getPgInt()));

                    // doug add program init cap so this value can be added to the interest rate in order
                    // to determine the qualifying rate (anIntRateQual)
                    //
                    appData.put("anPgInitCap", String.valueOf( program.getPgInitCap() ));

                    VectorX intAccrualPrgVec = program.getIntAccrual();
                    if( intAccrualPrgVec != null && ! intAccrualPrgVec.isEmpty() )
                    {
                      String accruelIntCalcMethPrg = (String) intAccrualPrgVec.firstElement();
                      //S1Log.getLogInstance().log("accruelIntCalcMethPrg: " + accruelIntCalcMethPrg, LOG_FILE);

                      // accruel interest calculation method
                      //
                      if( accruelIntCalcMethPrg != null && accruelIntCalcMethPrg.length() > 0 )
                      {
                        // approved credit terms set anIntAccD to first value from the from product
                        //
                        appData.put(CSFieldNames.FN_INT_ACCRUAL, accruelIntCalcMethPrg);
                      }
                    }

                    VectorX intPmtTypeVec = program.getPymtTypesSel();
                    if( intPmtTypeVec != null && ! intPmtTypeVec.isEmpty() )
                    {
                      String intPmtTypePrg = (String) intPmtTypeVec.firstElement();
                      //S1Log.getLogInstance().log("intPmtTypePrg: " + intPmtTypePrg, LOG_FILE);

                      // accruel interest calculation method
                      //
                      if( intPmtTypePrg != null && intPmtTypePrg.length() > 0 )
                      {
                        // approved credit terms set anIntAccD to first value from the from product
                        //
                        appData.put(CSFieldNames.FN_PMT_TYPE, intPmtTypePrg);
                        CSUtil.translatePmtType( (String)appData.get( CSFieldNames.FN_PMT_TYPE ), appData );
                      }
                    }

                    VectorX intPmtPrdVecPrg = program.getPymtPrdSel();
                    if( intPmtPrdVecPrg != null && ! intPmtPrdVecPrg.isEmpty() )
                    {
                      String intPmtPrdPrg = (String) intPmtPrdVecPrg.firstElement();
                      //S1Log.getLogInstance().log("intPmtPrdPrg: " + intPmtPrdPrg, LOG_FILE);

                      // accruel interest calculation method
                      //
                      if( intPmtPrdPrg != null && intPmtPrdPrg.length() > 0 )
                      {
                        // approved credit terms set anIntAccD to first value from the from product
                        //
                        appData.put(CSFieldNames.FN_PMT_PRD, intPmtPrdPrg);
                      }
                    }

                    String rtTypeR = program.getPgAmortR();

                    if (rtTypeR != null)
                    {
                      if (rtTypeR.equals("0"))
                      {
                      //appData.put("anRtTypR", "Fixed");
                      appData.put(CSFieldNames.FN_RT_TYPE, "Fixed");

                      //amortization type
                      appData.put("anAmortTypD", "Fixed Rate");
                      }
                      else
                      {
                        //appData.put("anRtTypR", "Variable");
                        appData.put(CSFieldNames.FN_RT_TYPE, "Variable");

                        //amortization type
                        appData.put("anAmortTypD", "ARM");

                        if (program.getPgIdx() != null)
                        {
                          // do not do anymore
                          //
                          //VectorX indexes = new VectorX();
                          //indexes.add(program.getPgIdx());
                          //appData.put("anIdxD", IndexRate.getCodesDescriptions(indexes));

                          appData.put( "anIdxD", program.getPgIdx() );
                        }
                      }
                    }

                    // credit and disability insurance
                    //
                    try
                    {
                      String crdtLife = (String)appData.get("anCLifeInsD");
                      if( crdtLife != null && crdtLife.trim().length() > 0 && ! crdtLife.trim().toLowerCase().equals("none") )
                      {
                        if( program.getCInsC() )
                        {
                          VectorX vec = (VectorX) program.getCInsM();
                          if( vec != null && ! vec.isEmpty() )
                          {
                            // "anCLifeInsTypD"
                            //
                            String insPlan = (String)vec.firstElement();
                            if( insPlan != null && insPlan.trim().length() > 0 )
                            {
                              if( ! appData.containsKey(CSFieldNames.FN_CINS_TYPE) )
                              {
                                if( insPlan != null && insPlan.startsWith("*") )
                                {
                                  insPlan = StringSupport.removeEmbeddedString(insPlan, "*");
                                }

                                appData.put(CSFieldNames.FN_CINS_TYPE, insPlan);
                              }
                            }
                          }
                        }
                      }

                      String ahIns = (String)appData.get("anAHInsD");
                      if( ahIns != null && ahIns.trim().length() > 0  && ! ahIns.trim().toLowerCase().equals("none") )
                      {
                        if( program.getAHInsC() )
                        {
                          VectorX vec = (VectorX) program.getAHInsM();
                          if( vec != null && ! vec.isEmpty() )
                          {
                            // "anAHInsTypD"
                            //
                            String insPlan = (String)vec.firstElement();
                            if( insPlan != null && insPlan.trim().length() > 0 )
                            {
                              if( ! appData.containsKey(CSFieldNames.FN_CINS_AH_TYPE) )
                              {
                                if( insPlan != null && insPlan.startsWith("*") )
                                {
                                  insPlan = StringSupport.removeEmbeddedString(insPlan, "*");
                                }

                                appData.put(CSFieldNames.FN_CINS_AH_TYPE, insPlan);
                              }
                            }
                          }
                        }
                      }
                    }
                    catch( Exception eee )
                    {
                      eee.printStackTrace();
                      //S1Log.getLogInstance().log("An error occurred while processing the credit and disability insurance. Product Id: " + productID + " Program Id: "+anProgTypeD+" Error: "+eee.getMessage(), LOG_FILE);
                    }
                  }
                }
              }
              //else
              //{
              //
              //}
            }
            catch( Exception p )
            {
            p.printStackTrace();
            //S1Log.getLogInstance().log("An error occurred while loading the mortgage product program id for this product. Product Id: " + productID + " Error: "+p.getMessage(), LOG_FILE);
            }

         } // if( ( ! appData.containsKey( CSFieldNames.FN_PROGRAM_ID ) ) && APP_TYPE_MORTGAGE )

          // Add Provident Special Fields. Need to set up fee nodes.
          //
          try
          {
            VectorX dftFees = product.getDfltFeesSel();
            //S1Log.getLogInstance().log("dftFees: " + dftFees, LOG_FILE);

            //String branchId = (String)appData.get(CSFieldNames.FN_BRANCH_ID);

            if( dftFees != null && (!dftFees.isEmpty()) && branchId != null )
            {
              //S1Log.getLogInstance().log("fee branchId: " + branchId, LOG_FILE);

              HashtableX feesHash = AppImportUtils.getFeeInformation( branchId , dftFees);
              //S1Log.getLogInstance().log("feesHash: " + feesHash, LOG_FILE);

              if( feesHash != null && ! feesHash.isEmpty() )
              {
                appData.put("anDfltFeesHash", feesHash);
              }
            }
          }
          catch( Exception p )
          {
            p.printStackTrace();
            //S1Log.getLogInstance().log("An error occurred while creating the fee node. Product Id: " + productID + " Error: "+p.getMessage(), LOG_FILE);
          }

          // credit and disability insurance
          //
          try
          {
            String crdtLife = (String)appData.get("anCLifeInsD");
            if( crdtLife != null && crdtLife.trim().length() > 0 && ! crdtLife.trim().toLowerCase().equals("none") )
            {
              if( product.getPrdCInsC() )
              {
                VectorX vec = (VectorX) product.getPrdCInsM();
                if( vec != null && ! vec.isEmpty() )
                {
                  // "anCLifeInsTypD"
                  //
                  String insPlan = (String)vec.firstElement();
                  if( insPlan != null && insPlan.trim().length() > 0 )
                  {
                    if( ! appData.containsKey(CSFieldNames.FN_CINS_TYPE) )
                    {
                      if( insPlan != null && insPlan.startsWith("*") )
                      {
                        insPlan = StringSupport.removeEmbeddedString(insPlan, "*");
                      }

                      appData.put(CSFieldNames.FN_CINS_TYPE, insPlan);
                    }
                  }
                }
              }
            }

            String ahIns = (String)appData.get("anAHInsD");
            if( ahIns != null && ahIns.trim().length() > 0  && ! ahIns.trim().toLowerCase().equals("none") )
            {
              if( product.getPrdAHInsC() )
              {
                VectorX vec = (VectorX) product.getPrdAHInsM();
                if( vec != null && ! vec.isEmpty() )
                {
                  // "anAHInsTypD"
                  //
                  String insPlan = (String)vec.firstElement();
                  if( insPlan != null && insPlan.trim().length() > 0 )
                  {
                    if( ! appData.containsKey(CSFieldNames.FN_CINS_AH_TYPE) )
                    {
                      if( insPlan != null && insPlan.startsWith("*") )
                      {
                        insPlan = StringSupport.removeEmbeddedString(insPlan, "*");
                      }

                      appData.put(CSFieldNames.FN_CINS_AH_TYPE, insPlan);
                    }
                  }
                }
              }
            }
          }
          catch( Exception ee )
          {
            ee.printStackTrace();
            //S1Log.getLogInstance().log("An error occurred while processing the credit and disability insurance. Product Id: " + productID + " Error: "+ee.getMessage(), LOG_FILE);
          }

          // add recission date which will add disbursement date
          // also in overloaded mtg method below
          //
          boolean prdRcsnC = product.getPrdRcsnC();
          //S1Log.getLogInstance().log("CONSUMER prdRcsnC: "+prdRcsnC, LOG_FILE);
          if( prdRcsnC )
          {
            appData.put(CSFieldNames.FN_RCSN_C, CSFieldValues.TRUE_STRING);
            //S1Log.getLogInstance().log("SET TO prdRcsnC: "+prdRcsnC, LOG_FILE);

            String todaysDate = DateUtility.getTodaysDate("MDY", "/");
            //S1Log.getLogInstance().log("1 todaysDate: "+todaysDate, LOG_FILE);

            //S1Log.getLogInstance().log("if( appData.containsKey(\"anLoanDt\") ): " + ( appData.containsKey("anLoanDt") ), LOG_FILE);
            if( appData.containsKey("anLoanDt") )
            {
              String loanDate = (String)appData.get("anLoanDt");
              //S1Log.getLogInstance().log("loanDate: " + loanDate, LOG_FILE);
              if ( DateUtility.isValidSlashDate( loanDate ) )
                {
                  todaysDate = loanDate;
                  //S1Log.getLogInstance().log("2 todaysDate: " + todaysDate, LOG_FILE);
                }
            }
  
            // need to go to config file because method is now used by mutliple customers
            //String recDt = DateUtility.getSlashDateNumBusinessDaysAfter(todaysDate, 3, true);
            //
            boolean openSaturdays = DateUtility.openedForBusinessOnThisDay( "saturday" );
            //S1Log.getLogInstance().log("openSaturdays: "+openSaturdays, LOG_FILE);

            String recDt = DateUtility.getSlashDateNumBusinessDaysAfter(todaysDate, 3, openSaturdays);
            //S1Log.getLogInstance().log("recDt: "+recDt, LOG_FILE);

            if( recDt != null )
            {
              appData.put(CSFieldNames.FN_RECISSION_DT, recDt);

              //String disburseDt = DateUtility.getSlashDateNumBusinessDaysAfter(recDt, 1, false);
              String disburseDt = DateUtility.getSlashDateNumBusinessDaysAfter(recDt, 1, openSaturdays);
              //S1Log.getLogInstance().log("disburseDt: "+disburseDt, LOG_FILE);

              if( disburseDt != null )
              {
                appData.put(CSFieldNames.FN_DISBURSE_DATE, disburseDt);
              }
            }
          }
          else
          {
            appData.put(CSFieldNames.FN_RCSN_C, CSFieldValues.FALSE_STRING);
            //S1Log.getLogInstance().log("SET TO prdRcsnC: "+prdRcsnC, LOG_FILE);
          }

       }
       catch (Exception e)
       {
         e.printStackTrace();
         //S1Log.getLogInstance().log("An error occurred while loading the product information. Product ID: " + productID + "  Error: " + e, LOG_FILE);
       }

     }
     else
     {
       throw new Exception("Cannot load product data. Invalid application data table.");
     }

     //S1Log.getLogInstance().log("END getProductDefaultData( Map appData, String APP_TYPE )", LOG_FILE);
   }

   // overload for WFE edit
   //
   public static void getProductDefaultData( GenericProduct product, HashtableX appData, boolean APP_TYPE_CONSUMER, boolean APP_TYPE_MORTGAGE, boolean PROD_CHNGD_IN_EDIT, boolean PROG_CHNGD_IN_EDIT ) throws Exception
   {
     //S1Log.getLogInstance().log("START OVRLD getProductDefaultData( GenericProduct product, HashtableX appData, boolean APP_TYPE_CONSUMER, boolean APP_TYPE_MORTGAGE, boolean PROD_CHNGD_IN_EDIT, boolean PROG_CHNGD_IN_EDIT )", LOG_FILE);
     //S1Log.getLogInstance().log("appData: "+appData, LOG_FILE);

     if( appData != null && ! appData.isEmpty() )
     {
       String branchId = (String)appData.get(CSFieldNames.FN_BRANCH_ID);
       //S1Log.getLogInstance().log("STR branchId: "+branchId, LOG_FILE);

       int branch = StringSupport.strToInt(branchId);
       //S1Log.getLogInstance().log("INT branch: "+branch, LOG_FILE);

       String anCBD = null;
       String productID = null;
       String anGenPurD = null;
       String anLoanPur = null; // specific use fo proceeds
       String anProgTypeD = null;
       String anLoanPurCdD = null; // application loan type
       String isPrePaidInterest = null;
       String accruelIntCalcMeth = null;
       String firstInterestAccruel = null;

       VectorX anGenPurM = new VectorX();
       VectorX anPrmClCdD = new VectorX();

       try
       {
         productID = (String) appData.get("anProdTypeD");
         //S1Log.getLogInstance().log("productID: " + productID, LOG_FILE);

         // need to get the int accruel for this product. if more than one use the first one
         // 2-24-03 needed for calculation purposes
         //
         VectorX intAccruelVec = product.getIntAccrual();
         //S1Log.getLogInstance().log("intAccruelVec: " + intAccruelVec, LOG_FILE);

         if (intAccruelVec != null && ! intAccruelVec.isEmpty())
         {
           accruelIntCalcMeth = (String) intAccruelVec.firstElement();
           //S1Log.getLogInstance().log("accruelInt: " + accruelIntCalcMeth, LOG_FILE);

           // accruel interest calculation method
           //
           if( accruelIntCalcMeth != null && accruelIntCalcMeth.length() > 0 )
           {
             // approved credit terms set anIntAccD to first value from the from product
             //
             if( (!appData.containsKey(CSFieldNames.FN_INT_ACCRUAL)) || PROD_CHNGD_IN_EDIT )
             {
               appData.put(CSFieldNames.FN_INT_ACCRUAL, accruelIntCalcMeth);
             }
           }
         }

         VectorX intPmtVec = product.getPymtTypesSel();
         if( intPmtVec != null && ! intPmtVec.isEmpty() )
         {
           String intPmtType = (String) intPmtVec.firstElement();
           //S1Log.getLogInstance().log("intPmtType: " + intPmtType, LOG_FILE);

           // accruel interest calculation method
           //
           if( intPmtType != null && intPmtType.length() > 0 )
           {
             // approved credit terms set anIntAccD to first value from the from product
             //
             //S1Log.getLogInstance().log("if ( (!appData.containsKey(CSFieldNames.FN_PMT_TYPE)) || PROD_CHNGD_IN_EDIT ): " + ( (!appData.containsKey(CSFieldNames.FN_PMT_TYPE)) || PROD_CHNGD_IN_EDIT ), LOG_FILE);
             if ( (!appData.containsKey(CSFieldNames.FN_PMT_TYPE)) || PROD_CHNGD_IN_EDIT )
             {
               //S1Log.getLogInstance().log("appData.put(CSFieldNames.FN_PMT_TYPE, intPmtType): " + intPmtType, LOG_FILE);
               appData.put(CSFieldNames.FN_PMT_TYPE, intPmtType);
               CSUtil.translatePmtType( (String)appData.get( CSFieldNames.FN_PMT_TYPE ), appData );
             }
           }
         }

         VectorX intPmtPrdVec = product.getPymtPrdSel();
         if( intPmtPrdVec != null && ! intPmtPrdVec.isEmpty() )
         {
           String intPmtPrd = (String) intPmtPrdVec.firstElement();
           //S1Log.getLogInstance().log("intPmtPrd: " + intPmtPrd, LOG_FILE);

           // accruel interest calculation method
           //
           if( intPmtPrd != null && intPmtPrd.length() > 0 )
           {
             // approved credit terms set anIntAccD to first value from the from product
             //
             appData.put(CSFieldNames.FN_PMT_PRD, intPmtPrd);
           }
         }

         // product defaults
         //
         isPrePaidInterest = String.valueOf(product.getPrePaidIntC());
         if (isPrePaidInterest != null && isPrePaidInterest.trim().length() > 0  )
         {
           if ( (!appData.containsKey(CSFieldNames.FN_IS_PREPAID_INT)) || PROD_CHNGD_IN_EDIT )
           {
             appData.put(CSFieldNames.FN_IS_PREPAID_INT, isPrePaidInterest);
           }
         }

         firstInterestAccruel = product.getFirstIntAccrual();
         if (firstInterestAccruel != null)
         {
           if ( (!appData.containsKey(CSFieldNames.FN_1ST_INT_ACCRUAL)) || PROD_CHNGD_IN_EDIT )
           {
             appData.put(CSFieldNames.FN_1ST_INT_ACCRUAL, firstInterestAccruel);
           }
         }

         // ckd said get the credit bureau from the product 2-5-03
         //
         anCBD = product.getPrdDefCBD();

         //S1Log.getLogInstance().log("anCBD: " + anCBD, LOG_FILE);
         //S1Log.getLogInstance().log("appData.containsKey(anCBD): " + appData.containsKey("anCBD"), LOG_FILE);
         //S1Log.getLogInstance().log("creditBureau from product: " + anCBD, LOG_FILE);

         // check the product for the credit bureau account
         //
         //  throw new Exception( "The incoming Credit Bureau from the XML Import "+
         //  "does not match the Credit Bureau that has been set for this product "+
         //  "in the Product Editor. XML:"+xmlAnCBD+" Product Ed:"+anCBD );
         //
         if( appData.containsKey("anCBD") )
         {
           String xmlAnCBD = (String) appData.get("anCBD");
           //S1Log.getLogInstance().log("7 xmlAnCBD: " + xmlAnCBD, LOG_FILE);

           // compare xml imported anCBD to the Product's anCBD
           //
           if (!xmlAnCBD.equalsIgnoreCase(anCBD))
           {
             // use the bureau from the xml sheet
             //
             anCBD = xmlAnCBD;
           }

           if (anCBD != null)
           {
             appData.put(CSFieldNames.FN_CB, anCBD);
           }

         }

         if (anCBD != null && ( (!appData.containsKey(CSFieldNames.FN_CB)) || PROD_CHNGD_IN_EDIT ) )
         {
           appData.put(CSFieldNames.FN_CB, anCBD);
         }

         // get application loan type getPrdLoanType
         //
         anLoanPurCdD = product.getPrdLoanType();
         //S1Log.getLogInstance().log("anLoanPurCdD: " + anLoanPurCdD, LOG_FILE);

         if (anLoanPurCdD != null)
         {
           appData.put(CSFieldNames.FN_LOAN_PUR_SELECTION, anLoanPurCdD);
         }

         // get the specific use of proceeds
         //
         anLoanPur = product.getPrdLoanPur();
         //S1Log.getLogInstance().log("specisic use fo proceeds from product: " + anLoanPur, LOG_FILE);

         if ( (!appData.containsKey(CSFieldNames.FN_LOAN_PURPOSE)) || PROD_CHNGD_IN_EDIT )
         {
           if (anLoanPur != null && anLoanPur.trim().length() > 0)
           {
             appData.put(CSFieldNames.FN_LOAN_PURPOSE, anLoanPur);
           }
         }

         // get default general purpose
         //
         anGenPurD = product.getPrdGenPurD();
         //S1Log.getLogInstance().log("specisic use fo proceeds from product: " + anLoanPur, LOG_FILE);

         // get possible general purposes
         //
         anGenPurM = product.getPrdGenPurM();
         //S1Log.getLogInstance().log("gen purpose vec from product: " + anGenPurM, LOG_FILE);

         //S1Log.getLogInstance().log("if( ! appData.containsKey( CSFieldNames.FN_PURPOSE_GEN ) ): " + ((!appData.containsKey(CSFieldNames.FN_PURPOSE_GEN))|| PROD_CHNGD_IN_EDIT), LOG_FILE);
         if( (! appData.containsKey(CSFieldNames.FN_PURPOSE_GEN)) || PROD_CHNGD_IN_EDIT )
         {
           // use product defaults
           //
           // product default general purpose
           if (anGenPurD != null && anGenPurD.trim().length() > 0)
           {
             if( APP_TYPE_MORTGAGE )
             {
               appData.put("anGenPurD", anGenPurD);
             }
             else
             {
               VectorX genPurVec = new VectorX();
               genPurVec.add(anGenPurD);
               appData.put("anGenPurM", genPurVec);
             }
           }
           // possible product default general purposes
           else if (anGenPurM != null && !anGenPurM.isEmpty())
           {
             if( APP_TYPE_CONSUMER )
             {
               appData.put("anGenPurM", anGenPurM);
             }
           }
         }
         else
         {
           String genPurStr = (String) appData.remove(CSFieldNames.FN_PURPOSE_GEN);
           if (genPurStr != null && genPurStr.trim().length() > 0)
           {
             if( APP_TYPE_MORTGAGE )
             {
               appData.put("anGenPurD", genPurStr);
             }
             else
             {
               appData.put("anGenPurM", StringChanger.stringToVector(genPurStr));
             }
           }
         }

         // get collateral code for verification
         //
         anPrmClCdD = product.getUnsecuredCollatCodes();
         //S1Log.getLogInstance().log("collateral code vec from product: " + anGenPurM, LOG_FILE);

         // add collateral code associated with product to application node
         //
         if( (! appData.containsKey("anPrmClCdD")) || PROD_CHNGD_IN_EDIT )
         {
           if( anPrmClCdD != null && ! anPrmClCdD.isEmpty() )
           {
             Iterator it = anPrmClCdD.iterator();
             while( it.hasNext() )
             {
               String code = (String)it.next();
               if( code != null && code.trim().length() > 0 )
               {
                 appData.put("anPrmClCdD", code);
                 break;
               }
             }
           }
         }

         // public static void getRequiredTime(String prodId, HashtableX outFieldsHash)
         // public static void getRequiredTime(Product product, HashtableX outFieldsHash)
         //
         // Add to app node hash, ckd-ajd, 2-26-08
         //
         HashtableX prdHt = new HashtableX();
         //S1Log.getLogInstance().log("1 prdHt: " + prdHt, LOG_FILE);

         DataEntrySupport.getRequiredTime( product, prdHt );

         // CSGenUtils
         //
         //S1Log.getLogInstance().log("2 prdHt: " + prdHt, LOG_FILE);
         if( prdHt != null && ! prdHt.isEmpty() )
         {
           appData.putAll(prdHt);
         }

         String disclaimer = product.getPrdDisclaimer();

         if (disclaimer != null && disclaimer.trim().length() > 0)
         {
           VectorX discList = ApplicationHouse.getListContentCache().getListContents( disclaimer.trim() );
           if (discList != null && !discList.isEmpty())
           {
             appData.put("_DisclaimA", discList);
           }
         }

         if( APP_TYPE_CONSUMER )
         {
           String prdQTLCode = ((Product)product).getPrdQTLCode();
           appData.put("anQTLCdD", DataEntrySupport.getRefreshedQTLCodes(branch, prdQTLCode));

           String prdCollOff = ((Product)product).getDfltCollOfficer();
           appData.put("anColOffD", prdCollOff);
         }

         //S1Log.getLogInstance().log("if( ! appData.containsKey( CSFieldNames.FN_PROGRAM_ID ) && APP_TYPE_MORTGAGE ): " + ( ! appData.containsKey( CSFieldNames.FN_PROGRAM_ID ) && APP_TYPE_MORTGAGE ), LOG_FILE);
         //S1Log.getLogInstance().log("if( APP_TYPE_MORTGAGE ): " + ( APP_TYPE_MORTGAGE ), LOG_FILE);
         if( APP_TYPE_MORTGAGE )
         {
            // getCurrentPrograms
            //
            // Map prgMap = ((MtgProduct)getCurrentProduct()).getProgramsTable();
            //
            try
            {
              String prdQTLCode = ((MtgProduct)product).getPrdQTLCode();
              appData.put("anQTLCdD", DataEntrySupport.getRefreshedQTLCodes(branch, prdQTLCode));

              String prdCollOff = ((MtgProduct)product).getDfltCollOfficer();
              appData.put("anColOffD", prdCollOff);

              //S1Log.getLogInstance().log("iif( (! appData.containsKey( CSFieldNames.FN_PROGRAM_ID )) || (PROD_CHNGD_IN_EDIT && PROD_CHNGD_IN_EDIT) ): " + ( (! appData.containsKey( CSFieldNames.FN_PROGRAM_ID )) || (PROD_CHNGD_IN_EDIT && PROG_CHNGD_IN_EDIT) ), LOG_FILE);
              if( (! appData.containsKey( CSFieldNames.FN_PROGRAM_ID )) || (PROD_CHNGD_IN_EDIT && PROG_CHNGD_IN_EDIT) )
              {
                Calendar cal = Calendar.getInstance();

                anProgTypeD = ((MtgProduct)product).getFirstCurrentProgramId( cal, false );
                //S1Log.getLogInstance().log("anProgTypeD: " + anProgTypeD, LOG_FILE);

                if( anProgTypeD != null && anProgTypeD.trim().length() > 0 )
                {
                  appData.put( CSFieldNames.FN_PROGRAM_ID, anProgTypeD );

                  Program program = CSDataCache.getProgramManager().getProgram( anProgTypeD );
                  if( program != null )
                  {
                    // default interest only
                    appData.put(CSFieldNames.FN_IS_INT_ONLY, String.valueOf(program.getPgIntC()));
                    appData.put(CSFieldNames.FN_INT_ONLY_NUM_PMT, String.valueOf(program.getPgInt()));

                    // default term & amort term
                    //S1Log.getLogInstance().log(CSFieldNames.FN_AMORT_PRD+": " + program.getpgAmortTerm(), LOG_FILE);
                    //S1Log.getLogInstance().log(CSFieldNames.FN_NUM_PMT+": " + program.getPgTerm(), LOG_FILE);
                    //S1Log.getLogInstance().log(CSFieldNames.FN_NUM_INT_PMT+": " + program.getPgInt(), LOG_FILE);
                    //S1Log.getLogInstance().log("anPgInitCap: " + program.getPgInitCap(), LOG_FILE);

                    appData.put(CSFieldNames.FN_AMORT_PRD, String.valueOf(program.getpgAmortTerm()));
                    appData.put(CSFieldNames.FN_NUM_PMT, String.valueOf(program.getPgTerm()));
                    appData.put(CSFieldNames.FN_NUM_INT_PMT, String.valueOf(program.getPgInt()));

                    // doug add program init cap so this value can be added to the interest rate in order
                    // to determine the qualifying rate (anIntRateQual)
                    //
                    appData.put("anPgInitCap", String.valueOf( program.getPgInitCap() ));

                    VectorX intAccrualPrgVec = program.getIntAccrual();
                    if( intAccrualPrgVec != null && ! intAccrualPrgVec.isEmpty() )
                    {
                      String accruelIntCalcMethPrg = (String) intAccrualPrgVec.firstElement();
                      //S1Log.getLogInstance().log("accruelIntCalcMethPrg: " + accruelIntCalcMethPrg, LOG_FILE);

                      // accruel interest calculation method
                      //
                      if( accruelIntCalcMethPrg != null && accruelIntCalcMethPrg.length() > 0 )
                      {
                        // approved credit terms set anIntAccD to first value from the from product
                        //
                        appData.put(CSFieldNames.FN_INT_ACCRUAL, accruelIntCalcMethPrg);
                      }
                    }

                    VectorX intPmtTypeVec = program.getPymtTypesSel();
                    if( intPmtTypeVec != null && ! intPmtTypeVec.isEmpty() )
                    {
                      String intPmtTypePrg = (String) intPmtTypeVec.firstElement();
                      //S1Log.getLogInstance().log("intPmtTypePrg: " + intPmtTypePrg, LOG_FILE);

                      // accruel interest calculation method
                      //
                      if( intPmtTypePrg != null && intPmtTypePrg.length() > 0 )
                      {
                        // approved credit terms set anIntAccD to first value from the from product
                        //
                        appData.put(CSFieldNames.FN_PMT_TYPE, intPmtTypePrg);
                        CSUtil.translatePmtType( (String)appData.get( CSFieldNames.FN_PMT_TYPE ), appData );
                      }
                    }

                    VectorX intPmtPrdVecPrg = program.getPymtPrdSel();
                    if( intPmtPrdVecPrg != null && ! intPmtPrdVecPrg.isEmpty() )
                    {
                      String intPmtPrdPrg = (String) intPmtPrdVecPrg.firstElement();
                      //S1Log.getLogInstance().log("intPmtPrdPrg: " + intPmtPrdPrg, LOG_FILE);

                      // accruel interest calculation method
                      //
                      if( intPmtPrdPrg != null && intPmtPrdPrg.length() > 0 )
                      {
                        // approved credit terms set anIntAccD to first value from the from product
                        //
                        appData.put(CSFieldNames.FN_PMT_PRD, intPmtPrdPrg);
                      }
                    }

                    String rtTypeR = program.getPgAmortR();

                    if (rtTypeR != null)
                    {
                      if (rtTypeR.equals("0"))
                      {
                      //appData.put("anRtTypR", "Fixed");
                      appData.put(CSFieldNames.FN_RT_TYPE, "Fixed");

                      //amortization type
                      appData.put("anAmortTypD", "Fixed Rate");
                      }
                      else
                      {
                        //appData.put("anRtTypR", "Variable");
                        appData.put(CSFieldNames.FN_RT_TYPE, "Variable");

                        //amortization type
                        appData.put("anAmortTypD", "ARM");

                        if (program.getPgIdx() != null)
                        {
                          // do not do anymore
                          //
                          //VectorX indexes = new VectorX();
                          //indexes.add(program.getPgIdx());
                          //appData.put("anIdxD", IndexRate.getCodesDescriptions(indexes));

                          appData.put( "anIdxD", program.getPgIdx() );
                        }
                      }
                    }

                    // credit and disability insurance
                    //
                    try
                    {
                      String crdtLife = (String)appData.get("anCLifeInsD");
                      if( crdtLife != null && crdtLife.trim().length() > 0 && ! crdtLife.trim().toLowerCase().equals("none") )
                      {
                        if( program.getCInsC() )
                        {
                          VectorX vec = (VectorX) program.getCInsM();
                          if( vec != null && ! vec.isEmpty() )
                          {
                            // "anCLifeInsTypD"
                            //
                            String insPlan = (String)vec.firstElement();
                            if( insPlan != null && insPlan.trim().length() > 0 )
                            {
                              if( (! appData.containsKey(CSFieldNames.FN_CINS_TYPE)) || PROD_CHNGD_IN_EDIT)
                              {
                                if( insPlan != null && insPlan.startsWith("*") )
                                {
                                  insPlan = StringSupport.removeEmbeddedString(insPlan, "*");
                                }

                                appData.put(CSFieldNames.FN_CINS_TYPE, insPlan);
                              }
                            }
                          }
                        }
                      }

                      String ahIns = (String)appData.get("anAHInsD");
                      if( ahIns != null && ahIns.trim().length() > 0  && ! ahIns.trim().toLowerCase().equals("none") )
                      {
                        if( program.getAHInsC() )
                        {
                          VectorX vec = (VectorX) program.getAHInsM();
                          if( vec != null && ! vec.isEmpty() )
                          {
                            // "anAHInsTypD"
                            //
                            String insPlan = (String)vec.firstElement();
                            if( insPlan != null && insPlan.trim().length() > 0 )
                            {
                              if( (! appData.containsKey(CSFieldNames.FN_CINS_AH_TYPE)) || PROD_CHNGD_IN_EDIT )
                              {
                                if( insPlan != null && insPlan.startsWith("*") )
                                {
                                  insPlan = StringSupport.removeEmbeddedString(insPlan, "*");
                                }

                                appData.put(CSFieldNames.FN_CINS_AH_TYPE, insPlan);
                              }
                            }
                          }
                        }
                      }
                    }
                    catch( Exception eee )
                    {
                      eee.printStackTrace();
                      //S1Log.getLogInstance().log("An error occurred while processing the credit and disability insurance. Product Id: " + productID + " Program Id: "+anProgTypeD+" Error: "+eee.getMessage(), LOG_FILE);
                    }
                  }
                }
              }
              else
              {

              }
            }
            catch( Exception p )
            {
            p.printStackTrace();
            //S1Log.getLogInstance().log("An error occurred while loading the mortgage product program id for this product. Product Id: " + productID + " Error: "+p.getMessage(), LOG_FILE);
            }

         }

          // Add Provident Special Fields. Need to set up fee nodes.
          //
          try
          {
            VectorX dftFees = product.getDfltFeesSel();
            //S1Log.getLogInstance().log("dftFees: " + dftFees, LOG_FILE);

            //String branchId = (String)appData.get(CSFieldNames.FN_BRANCH_ID);

            if( dftFees != null && (!dftFees.isEmpty()) && branchId != null )
            {
              //S1Log.getLogInstance().log("fee branchId: " + branchId, LOG_FILE);

              HashtableX feesHash = AppImportUtils.getFeeInformation( branchId , dftFees);
              //S1Log.getLogInstance().log("feesHash: " + feesHash, LOG_FILE);

              if( feesHash != null && ! feesHash.isEmpty() )
              {
                appData.put("anDfltFeesHash", feesHash);
              }
            }
          }
          catch( Exception p )
          {
            p.printStackTrace();
            //S1Log.getLogInstance().log("An error occurred while creating the fee node. Product Id: " + productID + " Error: "+p.getMessage(), LOG_FILE);
          }

          // credit and disability insurance
          //
          try
          {
            String crdtLife = (String)appData.get("anCLifeInsD");
            if( crdtLife != null && crdtLife.trim().length() > 0 && ! crdtLife.trim().toLowerCase().equals("none") )
            {
              if( product.getPrdCInsC() )
              {
                VectorX vec = (VectorX) product.getPrdCInsM();
                if( vec != null && ! vec.isEmpty() )
                {
                  // "anCLifeInsTypD"
                  //
                  String insPlan = (String)vec.firstElement();
                  if( insPlan != null && insPlan.trim().length() > 0 )
                  {
                    if( (!appData.containsKey(CSFieldNames.FN_CINS_TYPE))  || PROD_CHNGD_IN_EDIT )
                    {
                      if( insPlan != null && insPlan.startsWith("*") )
                      {
                        insPlan = StringSupport.removeEmbeddedString(insPlan, "*");
                      }

                      appData.put(CSFieldNames.FN_CINS_TYPE, insPlan);
                    }
                  }
                }
              }
            }

            String ahIns = (String)appData.get("anAHInsD");
            if( ahIns != null && ahIns.trim().length() > 0  && ! ahIns.trim().toLowerCase().equals("none") )
            {
              if( product.getPrdAHInsC() )
              {
                VectorX vec = (VectorX) product.getPrdAHInsM();
                if( vec != null && ! vec.isEmpty() )
                {
                  // "anAHInsTypD"
                  //
                  String insPlan = (String)vec.firstElement();
                  if( insPlan != null && insPlan.trim().length() > 0 )
                  {
                    if( (!appData.containsKey(CSFieldNames.FN_CINS_AH_TYPE)) || PROD_CHNGD_IN_EDIT )
                    {
                      if( insPlan != null && insPlan.startsWith("*") )
                      {
                        insPlan = StringSupport.removeEmbeddedString(insPlan, "*");
                      }

                      appData.put(CSFieldNames.FN_CINS_AH_TYPE, insPlan);
                    }
                  }
                }
              }
            }
          }
          catch( Exception ee )
          {
            ee.printStackTrace();
            //S1Log.getLogInstance().log("An error occurred while processing the credit and disability insurance. Product Id: " + productID + " Error: "+ee.getMessage(), LOG_FILE);
          }

          // add recission date which will add disbursement date
          // also in consumer method above
          //
          boolean prdRcsnC = product.getPrdRcsnC();
          //S1Log.getLogInstance().log("MORTGAGE prdRcsnC: "+prdRcsnC, LOG_FILE);
          if( prdRcsnC )
          {
            appData.put(CSFieldNames.FN_RCSN_C, CSFieldValues.TRUE_STRING);
            //general.errLog("SET TO prdRcsnC: "+prdRcsnC, "RecissionDt.log");

            String todaysDate = DateUtility.getTodaysDate("MDY", "/");
            //general.errLog("todaysDate: "+todaysDate, "RecissionDt.log");

          //S1Log.getLogInstance().log("if( appData.containsKey(\"anLoanDt\") ): " + (appData.containsKey("anLoanDt")), LOG_FILE);
          if (appData.containsKey("anLoanDt"))
            {
              String loanDate = (String) appData.get("anLoanDt");
              if (DateUtility.isValidSlashDate(loanDate))
              {
                todaysDate = loanDate;
                //S1Log.getLogInstance().log("todaysDate: " + todaysDate, LOG_FILE);
              }
            }

            // need to go to config file because method is now used by mutliple customers
            //String recDt = DateUtility.getSlashDateNumBusinessDaysAfter(todaysDate, 3, true);
            //
            boolean openSaturdays = DateUtility.openedForBusinessOnThisDay( "saturday" );
            //S1Log.getLogInstance().log("openSaturdays: "+openSaturdays, LOG_FILE);

            String recDt = DateUtility.getSlashDateNumBusinessDaysAfter(todaysDate, 3, openSaturdays);
            //S1Log.getLogInstance().log("recDt: "+recDt, LOG_FILE);

            if( recDt != null )
            {
              appData.put(CSFieldNames.FN_RECISSION_DT, recDt);

              String disburseDt = DateUtility.getSlashDateNumBusinessDaysAfter(recDt, 1, openSaturdays);
              //S1Log.getLogInstance().log("disburseDt: "+disburseDt, LOG_FILE);

              if( disburseDt != null )
              {
                appData.put(CSFieldNames.FN_DISBURSE_DATE, disburseDt);
              }
            }
          }
          else
          {
            appData.put(CSFieldNames.FN_RCSN_C, CSFieldValues.FALSE_STRING);
            //S1Log.getLogInstance().log("SET TO prdRcsnC: "+prdRcsnC, LOG_FILE);
          }
       }
       catch (Exception e)
       {
         e.printStackTrace();
         //S1Log.getLogInstance().log("An error occurred while loading the product information. Product ID: " + productID + "  Error: " + e, LOG_FILE);
       }

     }
     else
     {
       throw new Exception("Cannot load product data. Invalid application data table.");
     }

     //S1Log.getLogInstance().log("END getProductDefaultData( Map appData, String APP_TYPE )", LOG_FILE);

   } // getProductDefaultData( GenericProduct product, HashtableX appData, boolean APP_TYPE_CONSUMER, boolean APP_TYPE_MORTGAGE, boolean PROD_CHNGD_IN_EDIT ) throws Exception


   public static void loadDateFields( HashtableX appData ) throws Exception
   {
     //S1Log.getLogInstance().log("START loadDateFields( Map appData, String APP_TYPE )", LOG_FILE);
     //S1Log.getLogInstance().log("Map appData: "+appData, LOG_FILE);

     if( appData != null && !appData.isEmpty() )
     {
       boolean processSinglePay = false;

       String anSubmitActionFlag = (String)appData.get("anSubmitActionFlag");
       //S1Log.getLogInstance().log("anSubmitActionFlag: "+(anSubmitActionFlag), LOG_FILE);

       // add the processing date
       //
       String processingDate = DateUtility.getTodaySlashDate();
       String processingTime = DateUtility.getTimeHourMinuteAMPM();

       if ( processingDate != null && processingDate.length() > 0 && processingTime != null && processingTime.length() > 0 )
       {
         //S1Log.getLogInstance().log( "if (!appData.containsKey(CSFieldNames.FN_APP_DT)): " + ( !appData.containsKey( CSFieldNames.FN_APP_DT ) && ( anSubmitActionFlag == null || ( anSubmitActionFlag != null && ( !anSubmitActionFlag.trim().equals( "edit" ) ) ) )), LOG_FILE );
         if ( !appData.containsKey( CSFieldNames.FN_APP_DT ) && ( anSubmitActionFlag == null || ( anSubmitActionFlag != null && ( !anSubmitActionFlag.trim().equals( "edit" ) ) ) ))
         {
           appData.put( CSFieldNames.FN_APP_DT, processingDate );
           //S1Log.getLogInstance().log( "SET CSFieldNames.FN_APP_DT: " + processingDate, LOG_FILE );
         }

         //S1Log.getLogInstance().log( "if (!appData.containsKey(CSFieldNames.FN_APP_TIME)): " +  ( !appData.containsKey( CSFieldNames.FN_APP_TIME ) && ( anSubmitActionFlag == null || ( anSubmitActionFlag != null && ( !anSubmitActionFlag.trim().equals( "edit" ) ) ) )), LOG_FILE );
         if ( !appData.containsKey( CSFieldNames.FN_APP_TIME ) && ( anSubmitActionFlag == null || ( anSubmitActionFlag != null && ( !anSubmitActionFlag.trim().equals( "edit" ) ) ) ))
         {
           appData.put( CSFieldNames.FN_APP_TIME, processingTime );
           //S1Log.getLogInstance().log( "SET CSFieldNames.FN_APP_TIME: " + processingDate, LOG_FILE );
         }

         //S1Log.getLogInstance().log( "if (!appData.containsKey(CSFieldNames.FN_LOAN_DT)): " +  ( !appData.containsKey( CSFieldNames.FN_LOAN_DT ) && ( anSubmitActionFlag == null || ( anSubmitActionFlag != null && ( !anSubmitActionFlag.trim().equals( "edit" ) ) ) )), LOG_FILE );
         if ( !appData.containsKey( CSFieldNames.FN_LOAN_DT ) && ( anSubmitActionFlag == null || ( anSubmitActionFlag != null && ( !anSubmitActionFlag.trim().equals( "edit" ) ) ) ))
         {
           appData.put( CSFieldNames.FN_LOAN_DT, processingDate );
           //S1Log.getLogInstance().log( "SET CSFieldNames.FN_LOAN_DT: " + processingDate, LOG_FILE );

           // if changed update single pay processing - dougo - 8-31-11
           //
           processSinglePay = true;
         }

         //S1Log.getLogInstance().log( "if (!appData.containsKey(CSFieldNames.FN_DISBURSE_DATE)): " + ( !appData.containsKey( CSFieldNames.FN_DISBURSE_DATE ) && ( anSubmitActionFlag == null || ( anSubmitActionFlag != null && ( !anSubmitActionFlag.trim().equals( "edit" ) ) ) )), LOG_FILE );
         if ( !appData.containsKey( CSFieldNames.FN_DISBURSE_DATE ) && ( anSubmitActionFlag == null || ( anSubmitActionFlag != null && ( !anSubmitActionFlag.trim().equals( "edit" ) ) ) ))
         {
           appData.put( CSFieldNames.FN_DISBURSE_DATE, processingDate );
           //S1Log.getLogInstance().log( "SET CSFieldNames.FN_DISBURSE_DATE: " + processingDate, LOG_FILE );

           // if changed update single pay processing - dougo - 8-31-11
           //
           processSinglePay = true;
         }

         // claculate due date for single pay loans
         //
         //S1Log.getLogInstance().log( "START SINGLE PAY PROCESSING", LOG_FILE );
         try
         {
           String numberOfPayments = ( String ) appData.get( "anNumPmt" );

           //S1Log.getLogInstance().log( "processSinglePay: " + processSinglePay, LOG_FILE );
           //S1Log.getLogInstance().log( "numberOfPayments: " + numberOfPayments, LOG_FILE );
           //S1Log.getLogInstance().log( "NUM PAY IS ONE: " + ( processSinglePay && ( numberOfPayments != null && numberOfPayments.trim().equals( "1" ) )), LOG_FILE );

           if( processSinglePay && ( numberOfPayments != null && numberOfPayments.trim().equals( "1" ) ) )
           {
             //S1Log.getLogInstance().log( "if (appData.containsKey(anTermInMonths)): " + ( appData.containsKey( "anTermInMonths" ) ), LOG_FILE );

             if ( appData.containsKey( "anTermInMonths" ) )
             {
               String termInMonths = ( String ) appData.get( "anTermInMonths" );
               //S1Log.getLogInstance().log( "termInMonths: " + termInMonths, LOG_FILE );

               if ( termInMonths != null && termInMonths.trim().length() > 0 )
               {
                 int numMonthsToRoll = Integer.parseInt( termInMonths );

                 //S1Log.getLogInstance().log( "DATE BEFORE ROLL: " + processingDate, LOG_FILE );

                 // String rollMonths(String indexDate, int months, boolean increment)
                 //
                 String dueDtTypeIndex = DateUtility.rollMonths( DateUtility.slashDateToIndexDate( processingDate ), numMonthsToRoll, true );

                 if ( dueDtTypeIndex != null && dueDtTypeIndex.trim().length() > 0 )
                 {
                   String processingDateRolled = DateUtility.indexDateToSlashDate( dueDtTypeIndex );
                   //S1Log.getLogInstance().log( "DATE AFTER ROLL: " + processingDateRolled, LOG_FILE );

                   // appData.put("anDueDt",       processingDateRolled);
                   // appData.put("anInt1stPmtDt", processingDateRolled);
                   //
                   appData.put( CSFieldNames.FN_DUE_DT, processingDateRolled );
                   appData.put( CSFieldNames.FN_1ST_PMT_DT, processingDateRolled );

                   // put the payment period into the interm payment period field
                   //
                   String payPeriod = ( String ) appData.get( "anPmtPrdD" );
                   //S1Log.getLogInstance().log( "payPeriod: " + payPeriod, LOG_FILE );

                   String pmtTyp = ( String ) appData.get( CSFieldNames.FN_PMT_TYPE );
                   //S1Log.getLogInstance().log( "pmtTyp: " + pmtTyp, LOG_FILE );

                   // String FV_SINGLE             = "Single Payment (P&I @ maturity)";
                   // String FV_SINGLE_INT         = "Single Payment (Principal with interim int only)";
                   //
                   //S1Log.getLogInstance().log( "if( payPeriod != null && payPeriod.trim().length() > 0 && pmtTyp != null && pmtTyp.trim().equals( CSFieldValues.FV_SINGLE_INT ) ): " +( payPeriod != null && payPeriod.trim().length() > 0 && pmtTyp != null && pmtTyp.trim().equals( CSFieldValues.FV_SINGLE_INT ) ), LOG_FILE );

                   if ( payPeriod != null && payPeriod.trim().length() > 0 && pmtTyp != null && pmtTyp.trim().equals( CSFieldValues.FV_SINGLE_INT ) )
                   {
                     appData.put( CSFieldNames.FN_INT_PMT_PRD, payPeriod );

                     String firstIntPayDt = getFirstInterestPaymentDateByPayPeriod( payPeriod, processingDate );
                     //S1Log.getLogInstance().log( "1st INT PAY DT DATE AFTER ROLL: " + DateUtility.indexDateToSlashDate( firstIntPayDt ), LOG_FILE );

                     appData.put( CSFieldNames.FN_1ST_INT_PMT_DT, DateUtility.indexDateToSlashDate( firstIntPayDt ) );
                   }
                   else
                   {
                     // FN_INT_PMT_PRD = "anIntPmtPrdD"
                     //
                     appData.put( CSFieldNames.FN_INT_PMT_PRD, CSFieldValues.FV_MATURITY );
                     appData.put( CSFieldNames.FN_1ST_INT_PMT_DT, processingDateRolled );
                   }

                   // default to at maturity CKD 2-20-08
                   //
                   appData.put( CSFieldNames.FN_PMT_PRD, CSFieldValues.FV_MATURITY );
                 }
               }
             }
           }
         }
         catch ( Exception nfe )
         {
           nfe.printStackTrace();
         }

       } // if ( processingDate != null && processingDate.length() > 0 && processingTime != null && processingTime.length() > 0 )


       // set pre-approved to false
       //
       //S1Log.getLogInstance().log("if ( !appData.containsKey( CSFieldNames.FN_PRE_APPROVED ) && ( anSubmitActionFlag == null || ( anSubmitActionFlag != null && ( !anSubmitActionFlag.trim().equals( edit ) ) ) )): "+( !appData.containsKey( CSFieldNames.FN_PRE_APPROVED ) && ( anSubmitActionFlag == null || ( anSubmitActionFlag != null && ( !anSubmitActionFlag.trim().equals( "edit" ) ) ) )), LOG_FILE);
       if ( !appData.containsKey( CSFieldNames.FN_PRE_APPROVED ) && ( anSubmitActionFlag == null || ( anSubmitActionFlag != null && ( !anSubmitActionFlag.trim().equals( "edit" ) ) ) ))
       {
         appData.put( CSFieldNames.FN_PRE_APPROVED, CSFieldValues.FALSE_STRING );
       }

       // need to set to Installment for calculation purposes 2-24-03 (prod.getPymtTypesSel())
       //
       //S1Log.getLogInstance().log("if ( !appData.containsKey( CSFieldNames.FN_PMT_TYPE ) && ( anSubmitActionFlag == null || ( anSubmitActionFlag != null && ( !anSubmitActionFlag.trim().equals( edit ) ) ) )): "+( !appData.containsKey( CSFieldNames.FN_PMT_TYPE ) && ( anSubmitActionFlag == null || ( anSubmitActionFlag != null && ( !anSubmitActionFlag.trim().equals( "edit" ) ) ) )), LOG_FILE);
       if ( !appData.containsKey( CSFieldNames.FN_PMT_TYPE ) && ( anSubmitActionFlag == null || ( anSubmitActionFlag != null && ( !anSubmitActionFlag.trim().equals( "edit" ) ) ) ))
       {
         appData.put( CSFieldNames.FN_PMT_TYPE, CSFieldValues.FV_INSTALLMENT );
         appData.put( CSFieldNames.FN_PMT_TYPE_RADIO, "0" );
       }
       else
       {
         String anPmtTypD = (String) appData.get( CSFieldNames.FN_PMT_TYPE );
         //S1Log.getLogInstance().log("anPmtTypD: "+anPmtTypD, LOG_FILE);

         if( anPmtTypD != null && anPmtTypD.trim().length() > 0 )
         {
           CSUtil.translatePmtType( anPmtTypD, appData );
         }
       }

     } // if (appData != null && !appData.isEmpty())

     //S1Log.getLogInstance().log("END loadDateFields( Map appData, String APP_TYPE )", LOG_FILE);

   }

   // MTG APPS CANNOT BE EDITED OR SO IM TOLD
   //
   public static void loadMortgageDateFieldsPSECU( HashtableX appData ) throws Exception
   {
     //S1Log.getLogInstance().log("START loadMortgageDateFieldsPSECU( Map appData, String APP_TYPE )", LOG_FILE);

     if (appData != null && !appData.isEmpty())
      {
      // add the processing date
      
      String processingDate = DateUtility.getTodaySlashDate();
      String processingTime = DateUtility.getTimeHourMinuteAMPM();
      //
      if (processingDate != null && processingDate.length() > 0 && processingTime != null && processingTime.length() > 0)
        {                 
          if (!appData.containsKey(CSFieldNames.FN_APP_DT))
          {
          appData.put(CSFieldNames.FN_APP_DT, processingDate);
          }
          
          if (!appData.containsKey(CSFieldNames.FN_APP_TIME))
          {
          appData.put(CSFieldNames.FN_APP_TIME, processingTime);
          }
          
          // add recission date dougo  4-12-12
          boolean openSaturdays = DateUtility.openedForBusinessOnThisDay("saturday");
          //S1Log.getLogInstance().log("openSaturdays: " + openSaturdays, LOG_FILE);
          
          String processingDatePlus45 = DateUtility.getSlashDateNumBusinessDaysAfter(processingDate, 45, openSaturdays);
          //S1Log.getLogInstance().log("processingDatePlus45: " + processingDatePlus45, LOG_FILE);
          
          String isRcsnStr = (String) appData.get(CSFieldNames.FN_RCSN_C);
          //S1Log.getLogInstance().log("isRcsnStr: " + isRcsnStr, LOG_FILE);
          
          boolean isRCSN = isRcsnStr != null && isRcsnStr.trim().equals(CSFieldValues.TRUE_STRING);
          //S1Log.getLogInstance().log("isRCSN: " + isRCSN, LOG_FILE);
          
          //S1Log.getLogInstance().log("if (!appData.containsKey(CSFieldNames.FN_LOAN_DT)): " + (!appData.containsKey(CSFieldNames.FN_LOAN_DT)), LOG_FILE);
          if (!appData.containsKey(CSFieldNames.FN_LOAN_DT))
          {
            appData.put(CSFieldNames.FN_LOAN_DT, processingDatePlus45);
            
            if( isRCSN )
            {
              String recDt = DateUtility.getSlashDateNumBusinessDaysAfter(processingDatePlus45, 3, openSaturdays);
              //S1Log.getLogInstance().log("recDt: " + recDt, LOG_FILE);
              
              if (recDt != null)
              {
                appData.put(CSFieldNames.FN_RECISSION_DT, recDt);
              
                String disburseDt = DateUtility.getSlashDateNumBusinessDaysAfter(recDt, 1, openSaturdays);
                //S1Log.getLogInstance().log("disburseDt: " + disburseDt, LOG_FILE);
              
                if (disburseDt != null)
                {
                  appData.put(CSFieldNames.FN_DISBURSE_DATE, disburseDt);
                }
              }
            }
          }
          
          //S1Log.getLogInstance().log("if( (!appData.containsKey(CSFieldNames.FN_DISBURSE_DATE)) && (!isRCSN) ): " + ( (!appData.containsKey(CSFieldNames.FN_DISBURSE_DATE)) && (!isRCSN) ), LOG_FILE);
          if( (!appData.containsKey(CSFieldNames.FN_DISBURSE_DATE)) && (!isRCSN) )
          {
          appData.put(CSFieldNames.FN_DISBURSE_DATE, processingDatePlus45);
          }
          
          //S1Log.getLogInstance().log("if (!appData.containsKey(CSFieldNames.FN_1ST_PMT_DT)): "+(!appData.containsKey(CSFieldNames.FN_1ST_PMT_DT)), LOG_FILE);
          //S1Log.getLogInstance().log("CSFieldNames.FN_1ST_PMT_DT: "+appData.get(CSFieldNames.FN_1ST_PMT_DT), LOG_FILE);
          
          if (!appData.containsKey(CSFieldNames.FN_1ST_PMT_DT))
          {
          Date date = DateUtility.assignSlashDateToJavaDate(processingDatePlus45);
          
          if (date != null)
          {
          Calendar cal = Calendar.getInstance();
          cal.setTime(date);
          
          //S1Log.getLogInstance().log("1 cal: "+cal, LOG_FILE);
          //S1Log.getLogInstance().log("1 date: "+cal.getTime(), LOG_FILE);
          
          if (cal.get(cal.DAY_OF_MONTH) != 1)
          {
          cal.add(Calendar.MONTH, 1);
          
          //S1Log.getLogInstance().log("2 cal: " + cal, LOG_FILE);
          //S1Log.getLogInstance().log("2 date: " + cal.getTime(), LOG_FILE);
          
          cal.set(cal.DAY_OF_MONTH, 1);
          
          //S1Log.getLogInstance().log("3 cal: " + cal, LOG_FILE);
          //S1Log.getLogInstance().log("3 date: " + cal.getTime(), LOG_FILE);
          
          date = cal.getTime();
          //S1Log.getLogInstance().log("4 date: " + cal.getTime(), LOG_FILE);
          }
          
          //S1Log.getLogInstance().log("PUT : FN_1ST_PMT_DT: "+DateUtility.assignJavaDateToSlashDate(date), LOG_FILE);
          
          appData.put(CSFieldNames.FN_1ST_PMT_DT, DateUtility.assignJavaDateToSlashDate(date));
          }
          }
          else
          {
          //S1Log.getLogInstance().log("FN_1ST_PMT_DT: "+appData.get(CSFieldNames.FN_1ST_PMT_DT), LOG_FILE);
          }
          
          if (!appData.containsKey(CSFieldNames.FN_PRE_APPROVED))
          {
          appData.put(CSFieldNames.FN_PRE_APPROVED, CSFieldValues.FALSE_STRING);
          }        
        }
      }

     //S1Log.getLogInstance().log("END loadMortgageDateFieldsPSECU( Map appData, String APP_TYPE )", LOG_FILE);
   }

   public static String getFirstInterestPaymentDateByPayPeriod( String period, String processingDate )
   {
     String firstIntPayDt = null;

     if (period.equals(CSFieldValues.FV_MONTH))
     {
       //numPmtsPerYear = 12;
       firstIntPayDt = DateUtility.rollMonths(DateUtility.slashDateToIndexDate(processingDate), 1, true);
     }
     else if (period.equals(CSFieldValues.FV_BIWEEK))
     {
       //numPmtsPerYear = 26;
       firstIntPayDt = DateUtility.rollDays(DateUtility.slashDateToIndexDate(processingDate), 14, true);
     }
     else if (period.equals(CSFieldValues.FV_SEMIMONTH))
     {
       //numPmtsPerYear = 24;
       firstIntPayDt = DateUtility.rollDays(DateUtility.slashDateToIndexDate(processingDate), 15, true);
     }
     else if (period.equals(CSFieldValues.FV_QUARTER))
     {
       //numPmtsPerYear = 4;
       firstIntPayDt = DateUtility.rollMonths(DateUtility.slashDateToIndexDate(processingDate), 3, true);
     }
     else if (period.equals(CSFieldValues.FV_SEMIANNUAL))
     {
       //numPmtsPerYear = 2;
       firstIntPayDt = DateUtility.rollMonths(DateUtility.slashDateToIndexDate(processingDate), 6, true);
     }
     else if (period.equals(CSFieldValues.FV_ANNUAL))
     {
       //numPmtsPerYear = 1;
       firstIntPayDt = DateUtility.rollMonths(DateUtility.slashDateToIndexDate(processingDate), 12, true);
     }
     else if (period.equals(CSFieldValues.FV_WEEK))
     {
       //numPmtsPerYear = 52;
       firstIntPayDt = DateUtility.rollDays(DateUtility.slashDateToIndexDate(processingDate), 7, true);
     }

     return firstIntPayDt;
   }


   public static void updateRateType( DataNode appNode,
                                      String userName,
                                      GenericProduct product,
                                      SystemDataObject sdo,
                                      HashtableX outFieldsHash )
   {
     StringBuffer buf = new StringBuffer();
     VectorX pricingTypes = new VectorX();
     VectorX indexes = new VectorX();

     // we want to check and see if any pricing table
     // fixed or variable are valid for this dates...

     Calendar compareDate = null;
     try
     {
       compareDate = CSUtil.getInstance().getApplicationPricingDateTime(appNode);

       //S1Log.getLogInstance().log(buf.append("CompareDate - DataEntrySupport:updateRateType").append(compareDate).toString());

       buf.delete(0, buf.length());

       ProductPricing pp = product.getCurrentProductPricing(product.getFixedPricingTable(), compareDate);

       //S1Log.getLogInstance().log(buf.append("pp ").append(pp).toString());

       buf.delete(0, buf.length());
       if (pp != null)
       {
         pricingTypes.add(buf.append(ProductPricing.FIXED_PRICING).append(ClientUtils.TOKEN).append(ProductPricing.FIXED_PRICING).toString());

         buf.delete(0, buf.length());

         //S1Log.getLogInstance().log(buf.append("Added prcing type ").append(pricingTypes).toString());

         buf.delete(0, buf.length());
       }
       pp = product.getCurrentProductPricing(product.getVarPricingTable(),compareDate);

       String defaultIndex = null;
       if (pp != null)
       {
         defaultIndex = pp.getPricingDefaultIndex();
       }
       //S1Log.getLogInstance().log(buf.append("pp 2 ").append(pp).toString());
       buf.delete(0, buf.length());

       if (pp != null)
       {
         pricingTypes.add(buf.append(ProductPricing.VAR_PRICING).append(ClientUtils.TOKEN).append(ProductPricing.VAR_PRICING).toString());

         buf.delete(0, buf.length());

         //S1Log.getLogInstance().log(buf.append("Added prcing type 2 ").append(pricingTypes).toString());

         buf.delete(0, buf.length());

         // get the indexes ...
         indexes = product.getIndexesGivenPricingTableIds(pp.getTableIDs());

         //S1Log.getLogInstance().log(buf.append("Added indexes ").append(indexes).toString());

         buf.delete(0, buf.length());
       }

       if (pricingTypes != null && pricingTypes.size() == 2)
       {
         pricingTypes.insertElementAt(buf.append(CSFieldValues.EMPTY_STRING).append(ClientUtils.TOKEN).append(CSFieldValues.EMPTY_STRING).toString(),0);
         buf.delete(0, buf.length());

         //S1Log.getLogInstance().log(buf.append("Added prcingTyopes 3 ").append(pricingTypes).toString());

         buf.delete(0, buf.length());
       }
       //
       //  This I am not sure as to how it is already being populated
       // in outfields hash.  anRtTypD , anIdxD
       // going with what cristin told me 08/31/2005...
       //
       // Persnally I would have prefered getting it from DataNode..
       // raj - 08/31/2005

       String anRtTypeDTmp = (String) outFieldsHash.get("anRtTypD");
       String anIdxDTmp = (String) outFieldsHash.get("anIdxD");

       if (anRtTypeDTmp != null && anRtTypeDTmp.trim().length() > 0)
       {
         outFieldsHash.put("anRtTypD",
                           ClientUtils.markListSelection(anRtTypeDTmp,pricingTypes));
       }
       else
       {
         outFieldsHash.put("anRtTypD", pricingTypes);
       }

       if (anIdxDTmp != null && anIdxDTmp.trim().length() > 0)
       {
         outFieldsHash.put("anIdxD",
                           ClientUtils.markListSelection(anIdxDTmp,IndexRate.getCodesDescriptions(indexes)));
       }
       else
       {
         if (defaultIndex == null || defaultIndex.trim().length() > 0)
         {
           outFieldsHash.put("anIdxD", IndexRate.getCodesDescriptions(indexes));
         }
         else
         {
           outFieldsHash.put("anIdxD",
                             ClientUtils.markListSelection(defaultIndex,IndexRate.getCodesDescriptions(indexes)));
         }
         //S1Log.getLogInstance().log(buf.append(" index desc ").append(" anIdxDTmp ").append(anIdxDTmp).append("  defaulrIndex ").append(defaultIndex).append("  ").append(IndexRate.getCodesDescriptions(indexes)).toString());

         buf.delete(0, buf.length());
       }

     }
     catch (Exception e)
     {
       //S1Log.getLogInstance().log(e);
     }

   }

   public static void setSystemDataFields( boolean APP_TYPE_CONSUMER,
                                           boolean APP_TYPE_MORTGAGE,
                                           boolean SET_APP_STAT_TO_INCOMPLETE,
                                           boolean BORROWER_HAS_CREDIT_REPORT,
                                           SystemDataObject sdo, DataNode appNode )
   {
     // remove customer name and add WFE to signify Web Front End in
     // order to intiiate notification processing for decision
     // changes,  2-22-08, ajd
     //
     // set app origination in system data - public static final String FN_APP_ORIG = "!orig";
     //
     appNode.setSystemData( CSFieldNames.FN_APP_ORIG, "WFE" );

     if( APP_TYPE_CONSUMER )
     {
       appNode.setSystemData( CSFieldNames.FN_APP_TYPE, "c" );
       //S1Log.getLogInstance().log("7/25.1  SetSystemData: Consumer: c", LOG_FILE);
     }
     else if( APP_TYPE_MORTGAGE )
     {
       appNode.setSystemData( CSFieldNames.FN_APP_TYPE, "m" );
       //S1Log.getLogInstance().log("7/25.1  SetSystemData: Mortgage: m", LOG_FILE);
     }

     // set system data for the app node and sdo and set the application status
     //
     if (SET_APP_STAT_TO_INCOMPLETE)
     {
       appNode.setSystemData(CSStatusCodes.SDO_STATUS, CSStatusCodes.SC_INCOMPLETE_APP);
       sdo.setSystemData(CSStatusCodes.APP_CAN_CONTINUE, CSFieldValues.FALSE_STRING);
       sdo.addToAuditLog("APP STATUS SET TO INCOMPLETE", "PRIMARY-APP AND CO-APP SSN IDENTICAL");
       //S1Log.getLogInstance().log("19/25 Status Set: Incomplete - Cannot Continue", LOG_FILE);
     }
     else
     {
       appNode.setSystemData(CSStatusCodes.SDO_STATUS, CSStatusCodes.SC_APP_ENTERED);
       sdo.setSystemData(CSStatusCodes.APP_CAN_CONTINUE, CSFieldValues.TRUE_STRING);
       //S1Log.getLogInstance().log("19/25 Status Set: App Entered - Can Continue", LOG_FILE);
     }

     // if BORROWER_HAS_CREDIT_REPORT set system data flag to true else do nothing
     // this field is required by Credit Bureau for processing if a credit report
     // exists, LED
     //
     if (BORROWER_HAS_CREDIT_REPORT)
     {
       appNode.setSystemData("!xmlrpt", CSFieldValues.TRUE_STRING);
     }

     appNode.setSystemData("!prlmDocPrntd",     CSFieldValues.FALSE_STRING);
     appNode.setSystemData("!dcsnDocPrntd",     CSFieldValues.FALSE_STRING);
     appNode.setSystemData("!clsgDocPrntd",     CSFieldValues.FALSE_STRING);
     appNode.setSystemData("!prlmDocEmailSent", CSFieldValues.FALSE_STRING);
     appNode.setSystemData("!dcsnDocEmailSent", CSFieldValues.FALSE_STRING);
     appNode.setSystemData("!clsgDocEmailSent", CSFieldValues.FALSE_STRING);

   } //    public static void  setSystemDataFields( boolean SET_APP_STAT_TO_INCOMPLETE,

 public static void setFirstPaymentDate( String DATA_ENTRY_USER, HashtableX appData, DataNode appNode )
 throws Exception
 {
   // determine the first payment date required
   //
   HashtableX payHash = new HashtableX();

   if (appData != null && appNode != null)
   {
     //S1Log.getLogInstance().log("if ( ! appData.containsKey(CSFieldNames.FN_1ST_PMT_DT) ): "+( ! appData.containsKey(CSFieldNames.FN_1ST_PMT_DT) ), LOG_FILE);

     if ( ! appData.containsKey(CSFieldNames.FN_1ST_PMT_DT) )
     {
       //S1Log.getLogInstance().log("CSUtil.defaultFirstPaymentDate", LOG_FILE);
       payHash = CSUtil.defaultFirstPaymentDate(appData, appNode);

       //S1Log.getLogInstance().log("payHash: " + payHash, LOG_FILE);

       if (payHash != null && !payHash.isEmpty())
       {
         String firstPayDt = (String) payHash.get(CSFieldNames.FN_1ST_PMT_DT);

         //S1Log.getLogInstance().log("firstPayDt: " + firstPayDt, LOG_FILE);

         if (firstPayDt != null && firstPayDt.length() > 0)
         {
           if (DateUtility.isValidSlashDate(firstPayDt))
           {
             // put in appData hash for maturity date calc
             //
             appData.put(CSFieldNames.FN_1ST_PMT_DT, firstPayDt);
             appNode.setFieldData(DATA_ENTRY_USER, CSFieldNames.FN_1ST_PMT_DT, firstPayDt);
           }
         } // if( firstPayDt != null && firstPayDt.length() > 0 )
       }
       else
       {
         String msg = CSFieldValues.EMPTY_STRING;

         if (payHash == null)
         {
           msg = "is NULL.";
         }
         else
         {
           msg = "is empty.";
         }

         throw new Exception("Could not calculate the first payment date. The payment hash data table that was generated for this application " + msg);
       }
     }
     else
     {
       String firstPayDt = (String) appData.get(CSFieldNames.FN_1ST_PMT_DT);

       //S1Log.getLogInstance().log("2 firstPayDt: "+firstPayDt, LOG_FILE);

       if (firstPayDt != null && firstPayDt.length() > 0)
       {
         if (DateUtility.isValidSlashDate(firstPayDt))
         {
           // put in appData hash for maturity date calc
           //
           // appData.put( CSFieldNames.FN_1ST_PMT_DT, firstPayDt );
           //
           appNode.setFieldData(DATA_ENTRY_USER, CSFieldNames.FN_1ST_PMT_DT, firstPayDt);
         }
       }
     } //  if( ! appData.containsKey( CSFieldNames.FN_1ST_PMT_DT ) ) / else
   } // if( appData != null && appNode != null )
 } //  public static void setFirstPaymentDate( HashtableX appData, DataNode appNode)

 public static void setLoanMaturityDate(String DATA_ENTRY_USER, HashtableX appData, DataNode appNode)
 throws Exception
 {
   if( appData != null && ! appData.containsKey(CSFieldNames.FN_DUE_DT) )
   {
     String maturityDate = CSUtil.calcLoanMaturityDate(appData);

     //S1Log.getLogInstance().log("maturityDate: " + maturityDate, LOG_FILE);

     if (maturityDate != null && maturityDate.length() > 0)
     {
       if (DateUtility.isValidSlashDate(maturityDate))
       {
         appNode.setFieldData(DATA_ENTRY_USER, CSFieldNames.FN_DUE_DT, maturityDate);
       }
     }
   }
 } //  public static void setLoanMaturityDate(...)

 public static void setRateType( String DATA_ENTRY_USER, HashtableX appData,
                                 SystemDataObject sdo, DataNode appNode)
 throws Exception
 {
   if( appData != null && ! appData.containsKey(CSFieldNames.FN_RT_TYPE) )
   {
     //log("BEFORE: DataEntrySupport.getProductDefaultInfo( sdo, DATA_ENTRY_USER, rateTypeHash )", LOG_FILE);

     HashtableX rateTypeHash = new HashtableX();

     DataEntrySupport.getProductDefaultInfo( sdo, DATA_ENTRY_USER, rateTypeHash );

     //log("AFTER: DataEntrySupport.getProductDefaultInfo( sdo, DATA_ENTRY_USER, rateTypeHash )", LOG_FILE);

     //log("rateTypeHash: " + rateTypeHash, LOG_FILE);
     if( rateTypeHash != null )
     {
       VectorX rateTypeList = (VectorX)rateTypeHash.get(CSFieldNames.FN_RT_TYPE);
       //log("rateTypeList: " + rateTypeList, LOG_FILE);

       //log("if( rateTypeList != null && ! rateTypeList.isEmpty() ): " + ( rateTypeList != null && ! rateTypeList.isEmpty() ), LOG_FILE);
       if( rateTypeList != null && ! rateTypeList.isEmpty() )
       {
         // String rateTypeStr = ( String ) rateTypeHash.get( CSFieldNames.FN_RT_TYPE );
         //
         // [Fixed@Fixed]
         //
         String rateTypeStr = ( String ) rateTypeList.firstElement();
         //log( "rateTypeStr: " + rateTypeStr, LOG_FILE );

         //log( "if ( rateTypeStr == null || rateTypeStr.trim().length() == 0 ): " + ( rateTypeStr == null || rateTypeStr.trim().length() == 0 ), LOG_FILE );
         //log( "if ( rateTypeStr == null || rateTypeStr.length() == 0 ): " + ( rateTypeStr == null || rateTypeStr.length() == 0 ), LOG_FILE );

         if ( rateTypeStr == null || rateTypeStr.trim().length() == 0 )
         {
           // int indexS = rateTypeStr.indexOf( ClientUtils.TOKEN );
           // //log( "indexS: " + indexS, LOG_FILE );
           //
           appNode.setFieldData( DATA_ENTRY_USER, CSFieldNames.FN_RT_TYPE, "Fixed" );
           //log( "SET TO FIXED 1: appNode.setFieldData(DATA_ENTRY_USER, CSFieldNames.FN_RT_TYPE, Fixed)", LOG_FILE  );
         }
         else
         {
           // [@, Fixed@Fixed, Variable@Variable]
           //
           int index = rateTypeStr.indexOf( ClientUtils.TOKEN );
           //log( "index: " + index, LOG_FILE );
           if( index != -1 )
           {
             rateTypeStr = rateTypeStr.substring(0,index);

             if( rateTypeStr != null && rateTypeStr.trim().equals("Fixed") )
             {
               appNode.setFieldData( DATA_ENTRY_USER, CSFieldNames.FN_RT_TYPE, "Fixed" );
               //log( "SET TO FIXED 3: appNode.setFieldData(DATA_ENTRY_USER, CSFieldNames.FN_RT_TYPE, Fixed)", LOG_FILE  );
             }
             else if( rateTypeStr != null && rateTypeStr.trim().equals("Variable") )
             {
               appNode.setFieldData( DATA_ENTRY_USER, CSFieldNames.FN_RT_TYPE, "Variable" );
               //log( "SET TO VARIABLE 4: appNode.setFieldData(DATA_ENTRY_USER, CSFieldNames.FN_RT_TYPE, Fixed)", LOG_FILE  );
             }
             else
             {
               appNode.setFieldData( DATA_ENTRY_USER, CSFieldNames.FN_RT_TYPE, "Fixed" );
               //log( "SET TO FIXED 5: appNode.setFieldData(DATA_ENTRY_USER, CSFieldNames.FN_RT_TYPE, Fixed)", LOG_FILE  );
             }
           }
           else
           {
             appNode.setFieldData( DATA_ENTRY_USER, CSFieldNames.FN_RT_TYPE, "Fixed" );
             //log( "SET TO FIXED 2: appNode.setFieldData(DATA_ENTRY_USER, CSFieldNames.FN_RT_TYPE, Fixed)", LOG_FILE  );
           }
         }
       }
     }
   }
 } // public static void setRateType(...)


 public static void updateDownPayment( String DATA_ENTRY_USER, DataNode appNode)
 throws Exception
 {
   try
   {
     //S1Log.getLogInstance().log("START - Process Down Payment for Collateral Node", LOG_FILE);

     HashtableX instHash = new HashtableX();
     HashtableX emptyHash = new HashtableX();

     DataEntrySupport.updateDownPaymentInfo(appNode, emptyHash, instHash);

     String multiPurch = (String)emptyHash.get(CSFieldNames.FN_MULT_PURCHASE);
     //S1Log.getLogInstance().log("multiPurch: "+multiPurch, LOG_FILE);

     if( multiPurch != null && multiPurch.trim().equals(CSFieldValues.TRUE_STRING))
         appNode.setFieldData(DATA_ENTRY_USER, CSFieldNames.FN_MULT_PURCHASE, CSFieldValues.TRUE_STRING);
     else
       appNode.setFieldData(DATA_ENTRY_USER, CSFieldNames.FN_MULT_PURCHASE, CSFieldValues.FALSE_STRING);

     String ttlDwnPmt  = (String)emptyHash.get(CSFieldNames.FN_DOWN_PAYMENT);
     //S1Log.getLogInstance().log("ttlDwnPmt: "+ttlDwnPmt, LOG_FILE);

     if( ttlDwnPmt != null && ttlDwnPmt.trim().length() > 0 )
     {
       appNode.setFieldData(DATA_ENTRY_USER, CSFieldNames.FN_DOWN_PAYMENT, ttlDwnPmt);
     }

     //S1Log.getLogInstance().log("END - Process Down Payment for Collateral Node", LOG_FILE);
   }
   catch ( Exception e )
   {
     e.printStackTrace();
     //S1Log.getLogInstance().log("Error processing down payment: "+e, LOG_FILE);
     throw new Exception("Error processing down payment: "+e);
   }

 } //  public static void updateDownPayment( String DATA_ENTRY_USER, DataNode appNode)

 public static void defaultCreditInsurance( HashtableX appData, HashtableX bwr0Data )
 throws Exception
 {
   if( bwr0Data.containsKey("atStD") )
   {
     String state = (String) bwr0Data.get("atStD");
     //S1Log.getLogInstance().log("INSURANCE: state: " + state, LOG_FILE);

     if( state != null && state.trim().length() > 0 )
     {
       String customerName = SystemProperties.getProperty( CSFieldNames.SYS_CUSTOMER );
       //S1Log.getLogInstance().log("customerName: " + customerName,LOG_FILE);

       // Use NY to dtermine rates no matter what. ny rates apply to all states.
       // Do not stop app processing if the applicants state is not NY. Default
       // state to NY for now until better solution is presented. Doug O 2-16-11
       //
       if( customerName != null && customerName.trim().toLowerCase().equals("esl") )
       {
         state = "NY";
       }

       try
       {
         PmtCalcs.defaultCreditInsurancePlan(state, appData);
       }
       catch( Exception e )
       {
         e.printStackTrace();
         //S1Log.getLogInstance().log("CREDIT INSURANCE: error: " + e, LOG_FILE);
       }

       try
       {
         PmtCalcs.defaultDisabilityPlan(state, appData);
       }
       catch( Exception e )
       {
         e.printStackTrace();
         //S1Log.getLogInstance().log("DISABILITY INSURANCE: error: " + e, LOG_FILE);
       }
     }
   } // if( bwr0Data.containsKey("atStD") )

 } //  public static void defaultCreditInsurance( HashtableX appData, HashtableX bwr0Data )

 public static void defaultCreditBureauField( HashtableX appData, HashtableX bwr0Data )
 throws Exception
 {
   //S1Log.getLogInstance().log("START defaultCreditBureauField( HashtableX appData, HashtableX bwr0Data )", LOG_FILE);

   //S1Log.getLogInstance().log("appData: " + appData, LOG_FILE);
   //S1Log.getLogInstance().log("bwr0Data: " + bwr0Data, LOG_FILE);

   //S1Log.getLogInstance().log("if (bwr0Data.containsKey(atDlrScore)): " + (bwr0Data.containsKey("atDlrScore")), LOG_FILE);
   if( bwr0Data != null && bwr0Data.containsKey("atDlrScore") )
   {
     String dlrScore_0 = ( String ) bwr0Data.get( "atDlrScore" );
     //S1Log.getLogInstance().log("dlrScore_0: " + dlrScore_0, LOG_FILE);

     if ( dlrScore_0 != null )
     {
       appData.put( CSFieldNames.FN_CB, "None" );
       //S1Log.getLogInstance().log("DLR SET: " + CSFieldNames.FN_CB + ": None", LOG_FILE);
     }
   }

   // PVP processing for VACU
   //
   // CSFieldNames.FN_BWR_BNK_SCORE
   // CSFieldNames.FN_BWR_RSK_SCORE
   //
   if( appData != null && appData.containsKey("anPvpFlag") )
   {
     String pvpFlag = ( String ) appData.get( "anPvpFlag" );
     //S1Log.getLogInstance().log("pvpFlag: " + pvpFlag, LOG_FILE);

     //S1Log.getLogInstance().log("Pif( pvpFlag != null && pvpFlag.trim().equals(CSFieldValues.TRUE_STRING) ): " + ( pvpFlag != null && pvpFlag.trim().equals(CSFieldValues.TRUE_STRING) ), LOG_FILE);
     if( pvpFlag != null && pvpFlag.trim().equals(CSFieldValues.TRUE_STRING) )
     {
       appData.put( CSFieldNames.FN_CB, "None" );
       //S1Log.getLogInstance().log("PVP SET: " + CSFieldNames.FN_CB + ": None", LOG_FILE);
     }

   }

   //S1Log.getLogInstance().log("END defaultCreditBureauField( HashtableX appData, HashtableX bwr0Data )", LOG_FILE);

 } //  public static void defaultCreditBureauField( HashtableX appData, HashtableX bwr0Data )

 public static void updateDealerScoresForPrimaryBwr( HashtableX bwr0Data, DataNode appNode )
 throws Exception
 {
   String dlrScore_0 = (String)bwr0Data.get("atDlrScore");
   //S1Log.getLogInstance().log("dlrScore_0: "+dlrScore_0, LOG_FILE);
   if (dlrScore_0 != null)
   {
     DataNode bwr0 = appNode.getReference(NodeUtils.BWR_DN_TYPE, 0);
     //S1Log.getLogInstance().log("bwr0: "+bwr0, LOG_FILE);

     bwr0.setSystemData("!rskScore", dlrScore_0);
     bwr0.setSystemData("!appScore", dlrScore_0);
     appNode.setSystemData("!appScore", dlrScore_0);
   }

 } //  public static void updateDealerScoresForBwr( HashtableX bwr0Data, DataNode appNode )

 // check for credit report, default to US Citizen if field not present,
 // set mailing address check boxes( mailing addr and same as mailing addr )
 // check our employee, default to zero if not present, set driver license data
 //
 public static boolean setBwrFieldData( HashtableX bwrData, boolean BORROWER_HAS_CREDIT_REPORT )
 throws Exception
 {
  return setBwrFieldData( bwrData, BORROWER_HAS_CREDIT_REPORT, false );
 }


 public static boolean setBwrFieldData( HashtableX bwrData, boolean BORROWER_HAS_CREDIT_REPORT, boolean IS_EDIT )
 throws Exception
 {
   if( bwrData.containsKey("atCrdRpt") )
   {
     String crdRptStrCheck = (String) bwrData.get("atCrdRpt");

     if (crdRptStrCheck != null && crdRptStrCheck.trim().length() > 0)
     {
       BORROWER_HAS_CREDIT_REPORT = true;
     }
   }

   // default to US Citizen, ajd, 10-21-05
   //
   if( ! bwrData.containsKey("atCitizenD") )
   {
     bwrData.put("atCitizenD", "US Citizen");
   }

   //S1Log.getLogInstance().log("9.1 if( bwr0Data.containsKey(atMailAddr) ): " + (bwrData.containsKey("atMailAddr")), LOG_FILE);
   //S1Log.getLogInstance().log("9.2 if( bwr0Data.get(atMailAddr) ): " + bwrData.get("atMailAddr"), LOG_FILE);

   if( bwrData.containsKey(CSFieldNames.FN_BWR_MAIL_ADDR) )
   {
     bwrData.put(CSFieldNames.FN_BWR_SAME_AS_MAIL, CSFieldValues.FALSE_STRING);
   }
   else
   {
     if( ! bwrData.containsKey(CSFieldNames.FN_BWR_SAME_AS_MAIL) )
     {
       bwrData.put(CSFieldNames.FN_BWR_SAME_AS_MAIL, CSFieldValues.TRUE_STRING);
     }
   }

   // atOurEmpD set to zero. field needs to be filled
   //
   if( (! IS_EDIT) && (! bwrData.containsKey("atOurEmpD") ) )
   {
     bwrData.put("atOurEmpD", "0");
   }

   // set drivers license fields
   //
   try
   {
     updateDriversLicenseData(bwrData);
   }
   catch (Exception e)
   {
     e.printStackTrace();

     String err = "Unable to update driver license data. Error: " + e;

     //S1Log.getLogInstance().log( err, LOG_FILE );

     throw new Exception(err);
   }

   return BORROWER_HAS_CREDIT_REPORT;
 } //  public static void setBorrowerFieldData( HashtableX bwr0Data, boolean BORROWER_HAS_CREDIT_REPORT )

 //  AppImportUtils.setupAppNodeSubNodes( sdo, appData, DATA_ENTRY_USER );
 //
 public static void setupAppNodeSubNodes( SystemDataObject sdo, HashtableX appData, String DATA_ENTRY_USER )
 throws Exception
 {
   DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);
   String anRefId = (String) appNode.getFieldData(CSFieldValues.EMPTY_STRING, "anRefId");

   try
   {
     if (appData.containsKey(CSFieldNames.FN_GEN_CMNTS))
     {
       VectorX anGenVec = StringChanger.stringToVector(appData.remove(CSFieldNames.FN_GEN_CMNTS).toString());
       if (anGenVec != null && !anGenVec.isEmpty())
       {
         appData.put(CSFieldNames.FN_CMNT_TYPE, "General");
         appData.put(CSFieldNames.FN_CMNT, anGenVec);

         AppImportUtils.setupCommentsNode(sdo, appNode, appData, DATA_ENTRY_USER);
         //S1Log.getLogInstance().log("8/25 AppImportUtils.setupCommentsNode - General", LOG_FILE);
       }
     }
   }
   catch (Exception e)
   {
     e.printStackTrace();

     String err = "An error occurred while processing the General Comments for this application. Application ID: " + anRefId + "  Error: " + e;

     throw new Exception(err);
     //vp.addInformationalErrorMsg(err);
   }

   try
   {
     // CSFieldNames.FN_REV_CMNTS = "anReviewCmtsA"
     //
     if (appData.containsKey(CSFieldNames.FN_REV_CMNTS))
     {
       VectorX anRevVec = StringChanger.stringToVector(appData.remove(CSFieldNames.FN_REV_CMNTS).toString());
       if (anRevVec != null && !anRevVec.isEmpty())
       {
         appData.put(CSFieldNames.FN_CMNT_TYPE, CSFieldValues.FV_REVIEW);
         appData.put(CSFieldNames.FN_CMNT, anRevVec);
         AppImportUtils.setupCommentsNode(sdo, appNode, appData, DATA_ENTRY_USER);
         //S1Log.getLogInstance().log("9/25 AppImportUtils.setupCommentsNode - Review", LOG_FILE);
       }
     }
   }
   catch (Exception e)
   {
     e.printStackTrace();

     String err = "An error occurred while processing the Review Comments for this application. Application ID: " + anRefId + "  Error: " + e;

     throw new Exception( err );
     //vp.addInformationalErrorMsg(err);
   }

   // process disbursements into disbursement nodes
   //
   try
   {
     // get "anDisbNode"
     //
     //S1Log.getLogInstance().log("if( appData.containsKey(anDisbNode) ): " + (appData.containsKey("anDisbNode")), LOG_FILE);
     //S1Log.getLogInstance().log("10/25 AppImportUtils.setupDisbursementNode: " + (appData.containsKey("anDisbNode")), LOG_FILE);

     if (appData.containsKey("anDisbNode"))
     {
       List anDisbList = StringChanger.stringToVector(appData.remove("anDisbNode").toString());
       //S1Log.getLogInstance().log("anDisbList: " + anDisbList, LOG_FILE);

       if (anDisbList != null && !anDisbList.isEmpty())
       {
         AppImportUtils.setupDisbursementNode(sdo, appNode, anDisbList, DATA_ENTRY_USER);
       }
     }
   }
   catch (Exception e)
   {
     e.printStackTrace();

     String err = "An error occurred while processing the Disbursements for this application. Application ID: " + anRefId + "  Error: " + e;

     throw new Exception( err );
     //vp.addInformationalErrorMsg(err);
   }

    // process account opening bank secrecy questions and answers into the bank secrecy node
    //
    try
    {
      DepUtils.saveBankSecrecyData( DATA_ENTRY_USER, sdo, appData, appNode );
    }
    catch( Exception e )
    {
      e.printStackTrace();
      String err = "An error occurred while processing the Bank Secrecy Questions for this Account Opening application. Application ID: " + anRefId + "  Error: " + e;
      throw new Exception( err );
    }

  } //  public static void setupAppNodeSubNodes( SystemDataObject sdo, HashtableX appData, String DATA_ENTRY_USER )

 public static GenericProduct getGenericProduct( HashtableX appData, boolean APP_TYPE_CONSUMER, boolean APP_TYPE_MORTGAGE ) throws Exception
 {
   //S1Log.getLogInstance().log("START getGenericProduct( Map appData, String APP_TYPE )", LOG_FILE);

   GenericProduct product = null;

   if( appData != null && ! appData.isEmpty() )
   {
     // String productID = (String) appData.get("anProdTypeD");
     //
     String productID = (String) appData.get(CSFieldNames.FN_PRODUCT_ID);
     //S1Log.getLogInstance().log("productID: " + productID, LOG_FILE);

     if( productID != null && productID.trim().length() > 0 )
     {
       if( APP_TYPE_CONSUMER )
       {
         product = CSDataCache.getProductManager().getProduct(productID);
       }
       else if( APP_TYPE_MORTGAGE )
       {
         product = CSDataCache.getMtgProductManager().getProduct(productID);
       }

       if (product == null)
       {
         String err = "The product object value is null.";
         throw new Exception(err);
       }
     }
     else
     {

       String err = "Invalid product identification number. The ";

       if (productID != null)
       {
         err += "value is NULL.";
       }
       else
       {
         err += "field is empty.";
       }
       throw new Exception(err);
     }

   }
   else
   {
     throw new Exception("Cannot load product data. Invalid application data table.");
   }

   //S1Log.getLogInstance().log("END getGenericProduct( Map appData, String APP_TYPE )", LOG_FILE);

   return product;
 } //  public static GenericProduct getGenericProduct( HashtableX appData, boolean APP_TYPE_CONSUMER, boolean APP_TYPE_MORTGAGE ) throws Exception

 // WEB_APP = AppImportUtils.isWebApp(appData, WEB_APP);
 //
 public static boolean isWebApp( HashtableX appData, boolean WEB_APP )
 throws Exception
 {
   //S1Log.getLogInstance().log("if ( appData.containsKey(anWebAppC) ): " + (appData.containsKey("anWebAppC")), LOG_FILE);
   if (appData.containsKey("anWebAppC") && appData.containsKey("anDencryptedId"))
   {
     String webAppStr = (String) appData.get("anWebAppC");
     //S1Log.getLogInstance().log("webAppStr: " + webAppStr, LOG_FILE);

     if (webAppStr != null && webAppStr.trim().equals("true"))
     {
       WEB_APP = true;
       //S1Log.getLogInstance().log("1 WEB_APP: " + WEB_APP, LOG_FILE);
     }
   }

   return WEB_APP;
 }

 // SET_APP_STAT_TO_INCOMPLETE = AppImportUtils.setAppStatusToIncomplete( bwr0Data, bwr1Data, SET_APP_STAT_TO_INCOMPLETE );
 //
 // check the second borrowers social security number. if the borrowers
 // social security number does not match that of the primary borrowers
 // assign a new customer id number.
 //
 public static boolean setAppStatusToIncomplete( HashtableX bwr0Data, HashtableX bwr1Data, boolean SET_APP_STAT_TO_INCOMPLETE ) throws Exception
 {
   String primaryAppSS = (String) bwr0Data.get(CSFieldNames.FN_SSN);
   //S1Log.getLogInstance().log("primaryAppSS: " + primaryAppSS, LOG_FILE);

   if (primaryAppSS != null && primaryAppSS.length() > 0)
   {
     String coAppSS = (String) bwr1Data.get(CSFieldNames.FN_SSN);
     //S1Log.getLogInstance().log("coAppSS: " + coAppSS, LOG_FILE);

     if (coAppSS != null && coAppSS.length() > 0)
     {
       primaryAppSS = primaryAppSS.trim();
       coAppSS = coAppSS.trim();

       if (primaryAppSS.equals(coAppSS))
       {
         SET_APP_STAT_TO_INCOMPLETE = true;
       }
     }
   }

   return SET_APP_STAT_TO_INCOMPLETE;
 }

 // AppImportUtils.updateBwrSystemData(bwr1Data, appNode);
 //
 public static void updateDealerScoresForCoAppBwr( HashtableX bwr1Data, DataNode appNode )
 throws Exception
 {
   String dlrScore_1 = (String)bwr1Data.get("atDlrScore");
   //S1Log.getLogInstance().log("dlrScore_1: "+dlrScore_1, LOG_FILE);
   if (dlrScore_1 != null)
   {
     DataNode bwr1 = appNode.getReference(NodeUtils.BWR_DN_TYPE, 1);
     //S1Log.getLogInstance().log("bwr1: "+bwr1, LOG_FILE);
     if (bwr1 != null) bwr1.setSystemData("!rskScore", dlrScore_1);
     if (bwr1 != null) bwr1.setSystemData("!appScore", dlrScore_1);
   }
 }

 //     AppImportUtils.updateDataBaseTablesForPSECU(WEB_APP, appData);
 //
 public static void updateDataBaseTablesForPSECU( boolean WEB_APP, HashtableX appData)
 throws Exception
 {
   //S1Log.getLogInstance().log("START updateDataBaseTablesForPSECU( boolean WEB_APP, HashtableX appData)", LOG_FILE);
   if(WEB_APP)
   {
     try
     {
       String dencryptedId = (String)appData.get("anDencryptedId");

       //S1Log.getLogInstance().log("dencryptedId: "+dencryptedId, LOG_FILE);
       //S1Log.getLogInstance().log("if( dencryptedId != null && dencryptedId.trim().length() > 0 )"+( dencryptedId != null && dencryptedId.trim().length() > 0 ), LOG_FILE);

       if (dencryptedId != null && dencryptedId.trim().length() > 0)
       {
         //S1Log.getLogInstance().log("BEFORE DELETE dencryptedId: "+dencryptedId, LOG_FILE);
         deleteMemberData();
         //S1Log.getLogInstance().log("AFTER DELETE", LOG_FILE);
       }
     }
     catch (Exception delete)
     {
       delete.printStackTrace();
       //S1Log.getLogInstance().log("Error deleting web app data. Error: "+delete, LOG_FILE);
     }
   } // if(WEB_APP)

   // PSECU AccountInfoPost Data that is in the database
   //
   try
   {
       //S1Log.getLogInstance().log("BEFORE DELETE LOG MORTGAGE ERROR", LOG_FILE);
       deleteLogMortgageErrorData();
       //S1Log.getLogInstance().log("AFTER DELETE LOG MORTGAGE ERROR", LOG_FILE);
   }
   catch (Exception deleteLME)
   {
     deleteLME.printStackTrace();
     //S1Log.getLogInstance().log("Error deleting log mortgage error data. Error: "+deleteLME, LOG_FILE);
   }

   //S1Log.getLogInstance().log("END updateDataBaseTablesForPSECU( boolean WEB_APP, HashtableX appData)", LOG_FILE);

 } //  public static void updateDataBaseTablesForPSECU( boolean WEB_APP, HashtableX appData)

 /* 6-29-10
  Andy said in an email I forwarded to you:
  Let�s take the destroying of the token and info in the db to 3 days and see if that helps the other errors.
  Just hardcode it.
  Alisa
 */
 public static void deleteMemberData() throws Exception
 {
   //S1Log.getLogInstance().log("START deleteMemberData()", LOG_FILE);

   Calendar cal = Calendar.getInstance();
   cal.setTime(new Date());

   //
   // cal.add(Calendar.MINUTE, -30);
   //

   cal.add(Calendar.HOUR, -72);

   Date newDate = cal.getTime();
   SimpleDateFormat insertDttmFmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
   String dateStr = insertDttmFmt.format(newDate);

   String select = "SELECT tokenId FROM xntWebApplicant WHERE createDt < '"+dateStr+"'";
   //S1Log.getLogInstance().log("select: "+select, LOG_FILE);

   String deleteSql = null;

   VectorX tokenVec = new VectorX();

   Statement stmt   = null;
   try
     {
       Connection con = DBAccess.getConnection();
       stmt = con.createStatement();

       ResultSet rs = stmt.executeQuery(select);

       while( rs.next() )
       {
         String tokId = String.valueOf( rs.getInt("tokenId") );
         if( tokId != null && tokId.trim().length() > 0 )
         {
           tokenVec.add(tokId);
         }
       }

       //S1Log.getLogInstance().log("tokenVec: "+tokenVec, LOG_FILE);

       if( tokenVec != null && ! tokenVec.isEmpty() )
       {
         for( int i=0, c=tokenVec.size(); i<c; i++ )
         {
           String tokenId = (String)tokenVec.get(i);

           if( tokenId != null && tokenId.trim().length() > 0 )
           {
             deleteSql = "DELETE FROM xntWebApplicant WHERE tokenId = '" + tokenId + "' " +
                         "DELETE FROM xntWebCoApp     WHERE tokenId = '" + tokenId + "' " +
                         "DELETE FROM xntWebSigLoan   WHERE tokenId = '" + tokenId + "'";

             //S1Log.getLogInstance().log("deleteSql: "+deleteSql, LOG_FILE);

             stmt = con.createStatement();
             stmt.executeUpdate(deleteSql);
           }
         }
       }

     } // End try
   catch ( SQLException e )
     {
       e.printStackTrace();
       DBLogger.log("MemberLookup - Delete Error - SQL: "+deleteSql+" SQLException thrown: "+e);
     }
   catch ( Exception e )
     {
       e.printStackTrace();
       throw new Exception("MemberLookup - Delete Error - Exception thrown: "+e);
     }

   finally
   {
     DBAccess.closeConnection( stmt );
   }

   //S1Log.getLogInstance().log("End deleteMemberData()", LOG_FILE);

 } // private void deleteMemberData( String tokenId )

 public static void deleteLogMortgageErrorData() throws Exception
 {
   //S1Log.getLogInstance().log("START deleteLogMortgageErrorData()");

   Calendar cal = Calendar.getInstance();
   cal.setTime(new Date());
   cal.add(Calendar.DATE, -90);
   Date newDate = cal.getTime();
   SimpleDateFormat insertDttmFmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
   String dateStr = insertDttmFmt.format(newDate);

   String deleteSql = "DELETE xntWebMortgageErrors WHERE errorDate < '"+dateStr+"'";
   //S1Log.getLogInstance().log("deleteSql: "+deleteSql);

   Statement stmt   = null;
   try
     {
       Connection con = DBAccess.getConnection();
       stmt = con.createStatement();
       stmt.executeUpdate(deleteSql);
     }
   catch ( SQLException e )
     {
       e.printStackTrace();
       DBLogger.log("Web Mortgage Errors - Delete Error - SQL: "+deleteSql+" SQLException thrown: "+e);
     }
   catch ( Exception e )
     {
       e.printStackTrace();
       throw new Exception("Web Mortgage Errors - Delete Error - Exception thrown: "+e);
     }

   finally
   {
     DBAccess.closeConnection( stmt );
   }

   //S1Log.getLogInstance().log("END deleteLogMortgageErrorData()");

 } // deleteLogMortgageErrorrData()

 public static void editDisbursementNode( SystemDataObject sdo, DataNode appNode, List disbNodesList, String username )
  {
    //S1Log.getLogInstance().log("START setupDisbursementNodeDemoESL(...)",LOG_FILE);

    if( disbNodesList != null && ! disbNodesList.isEmpty() )
    {
      double disbTtl = 0.0;
      double nonLoanDisbTtl = 0.0;
      double unsecDisbTtl = 0.0;

      // delete all disbursement nodes for edit
      //
      List disbNodesToDelete = appNode.getEffectiveReferences(NodeUtils.DISB_DN_TYPE);
      //S1Log.getLogInstance().log("if( disbNodesToDelete != null && ! disbNodesToDelete.isEmpty() ): "+( disbNodesToDelete != null && ! disbNodesToDelete.isEmpty() ),LOG_FILE);

      if( disbNodesToDelete != null && ! disbNodesToDelete.isEmpty() )
      {
        for(int a=0,b=disbNodesToDelete.size(); a<b; a++)
        {
          DataNode delNode = (DataNode)disbNodesToDelete.get(a);
          //S1Log.getLogInstance().log("if( delNode != null && ! delNode.isDeleted() ): "+( delNode != null && ! delNode.isDeleted() ),LOG_FILE);
          if( delNode != null && ! delNode.isDeleted() )
          {
            delNode.delete();
          }
        }
      }

      // get the disb node data hash
      //
      for( int i=0, c=disbNodesList.size(); i<c; i++ )
      {
        Object obj = disbNodesList.get(i);

        //errorLog("obj: "+obj,AIU);
        //errorLog("CLASS obj: "+obj.getClass(),AIU);

        HashtableX disbData = null;

        if( obj instanceof String )
        {
          disbData = StringChanger.stringToHashtableX( disbNodesList.get(i).toString() );
        }
        else if( obj instanceof HashtableX )
        {
          disbData = (HashtableX)disbNodesList.get(i);
        }

        if( disbData != null && ! disbData.isEmpty() )
        {
          // String type = (String)disbData.get("dsbTypD");
          //
          String type = (String)disbData.get(CSFieldNames.FN_DSB_TYPE_DDL);

          //S1Log.getLogInstance().log("1 type: "+type,LOG_FILE);

          String translation = translateDisbursementType( type );

          //S1Log.getLogInstance().log("2 translation: "+translation,LOG_FILE);

          disbData.put("dsbType", translation);

          //errorLog("",AIU);//errorLog("3 disbData: "+disbData,AIU);//errorLog("",AIU);

          String amount = (String)disbData.get(CSFieldNames.FN_DSB_AMT);
          {
            disbTtl += StringSupport.strToDouble(amount);
          }

          // public static final String FV_DSB_NONLOAN = "0";
          //
          if (type != null && type.trim().equals(CSFieldValues.FV_DSB_NONLOAN))
          {
            nonLoanDisbTtl += StringSupport.strToDouble( amount );
          }

          if (type != null && type.trim().equals(CSFieldValues.FV_DSB_TYPE_UNSEC_BWR))
          {
            unsecDisbTtl += StringSupport.strToDouble( amount );
          }

          DataNode  disbNode = sdo.createDataNode(username, NodeUtils.DISB_DN_TYPE);
          disbNode.setFieldData(username, disbData);
          appNode.addReference(disbNode);
        }
      } // for( int i=0, c=disbNodesList.size(); i<c; i++ )

      appNode.setFieldData( username, CSFieldNames.FN_DSB_TTL, String.valueOf( disbTtl ) );
      appNode.setFieldData( username, CSFieldNames.FN_DSB_NON_LOAN, String.valueOf( nonLoanDisbTtl ) );
      appNode.setFieldData( username, CSFieldNames.FN_DSB_UNSEC, String.valueOf( unsecDisbTtl ));

    }

    //S1Log.getLogInstance().log("END setupDisbursementNodeDemoESL(...)",LOG_FILE);

    //errorLog("",AIU);//errorLog("END setupDisbursementNode(...)",AIU);//errorLog("",AIU);
  } // editDisbursementNode(...)

  public static void processApplicationTradeLines( SystemDataObject sdo, VectorX tradeList, String username )
  {
    //S1Log.getLogInstance().log("START processApplicationTradeLines(...)", LOG_FILE);

    //S1Log.getLogInstance().log("if( sdo != null ): "+( sdo != null ), LOG_FILE);
    if( sdo != null )
    {
      DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);

      if( appNode != null && ! appNode.isDeleted() )
      {
        StringTokenizer tok = null;

        char xChar = 'x', aChar = 'a', dChar = 'd';

        String tradeKey = null, selected = null, colonStr = ":", bwrS = null, rptS = null, trdS = null;

        for(int j=0,k=tradeList.size(); j<k; j++)
        {
          tradeKey = null;
          DataNode bwrNode = null;
          DataNode trdNode = null;

          //int rpt = 0;
          //int trd = 0;
          //int crd = 0;
          int bwr = 0;

          HashtableX trdData = null;

          Object obj = tradeList.get(j);
          //S1Log.getLogInstance().log("obj.getClass(): "+obj.getClass(), LOG_FILE);

          if( obj instanceof String )
          {
            trdData = StringChanger.stringToHashtable( (String) tradeList.get(j) );
          }
          else
          {
            trdData = (HashtableX) tradeList.get(j);
          }

          //S1Log.getLogInstance().log("trdData: "+trdData, LOG_FILE);

  //             - <Trade>

  //                 <Type />
  //                 <AccountNumber />
  //                 <Payment>112</Payment>
  //                 <LastActDate />
  //                 <Creditor>Child Support</Creditor>
  //                 <Balance>4357</Balance>
  //                 <TradeKey>4357</TradeKey>
  //                 <PO>P</PO>

  //               </Trade>


          String creditor = (String) trdData.get("Creditor");
          //S1Log.getLogInstance().log("creditor: "+creditor, LOG_FILE);

          String payment  = (String) trdData.get("Payment");
          //S1Log.getLogInstance().log("payment: "+payment, LOG_FILE);

          String balance  = (String) trdData.get("Balance");
          //S1Log.getLogInstance().log("balance: "+balance, LOG_FILE);

          String type     = (String) trdData.get("Type");
          //S1Log.getLogInstance().log("type: "+type, LOG_FILE);

          String payoff   = (String) trdData.get("PO");
          //S1Log.getLogInstance().log("payoff: "+payoff, LOG_FILE);

          boolean isPayoff = payoff != null && payoff.trim().equals("P");
          //S1Log.getLogInstance().log("isPayoff: "+isPayoff, LOG_FILE);

          tradeKey = (String)trdData.get("TradeKey");
          //S1Log.getLogInstance().log("tradeKey: "+tradeKey, LOG_FILE);

          selected = (String)trdData.get("Selected");
          //S1Log.getLogInstance().log("selected: "+selected, LOG_FILE);

          tok = new StringTokenizer(tradeKey, colonStr);

          if (tok.countTokens() == 3)
          {
            trdNode = getTradeNodeFromCode(appNode, tradeKey);

            //S1Log.getLogInstance().log("if( trdNode != null && trdNode.isDeleted() ): "+( trdNode != null && trdNode.isDeleted() ), LOG_FILE);

            if( trdNode != null && ! trdNode.isDeleted() )
            {
              //S1Log.getLogInstance().log("trdNode.getIndex(): "+trdNode.getIndex(), LOG_FILE);
              //S1Log.getLogInstance().log("trdNode.getNodeName(): "+trdNode.getNodeName(), LOG_FILE);
              //S1Log.getLogInstance().log("trdNode.getDataType(): "+trdNode.getDataType(), LOG_FILE);
              //S1Log.getLogInstance().log("trdNode.getFieldData(): "+trdNode.getFieldData(""), LOG_FILE);

              HashtableX origTrdHash = trdNode.getFieldData(CSFieldValues.EMPTY_STRING);
              //S1Log.getLogInstance().log("origTrdHash: "+origTrdHash, LOG_FILE);

              bwrS = tok.nextToken();
              //S1Log.getLogInstance().log("bwrS: "+bwrS, LOG_FILE);

              rptS = tok.nextToken();
              //S1Log.getLogInstance().log("rptS: "+rptS, LOG_FILE);

              trdS = tok.nextToken();

              //S1Log.getLogInstance().log("trdS: "+trdS, LOG_FILE);
              //S1Log.getLogInstance().log("bwrS.charAt(0): "+bwrS.charAt(0), LOG_FILE);
              //S1Log.getLogInstance().log("if (bwrS.charAt(0) == xChar): "+(bwrS.charAt(0) == xChar), LOG_FILE);

              if (bwrS.charAt(0) == xChar)
              {
              // This loan estimated payment trade.
              // selectOrUnselectEstPmtTrade(appNode, isSelect);
              //
              // Cannot set payoff on this. CKD
              //
              //S1Log.getLogInstance().log("***** continue X CHAR *****", LOG_FILE);
              continue;
              }
              else if (bwrS.charAt(0) == aChar)
              {
              //S1Log.getLogInstance().log("***** A CHAR PROCESS *****", LOG_FILE);
              // application trade.
              bwr = StringSupport.strToInt(rptS);
              bwrNode = getBwrReference(appNode, bwr);

              //S1Log.getLogInstance().log("1 bwrNode.getDataType(): "+bwrNode.getDataType(), LOG_FILE);
              //S1Log.getLogInstance().log("1 bwrNode.getIndex(): "+bwrNode.getIndex()+" - bwr: "+bwr, LOG_FILE);
              //S1Log.getLogInstance().log("1 bwrNode.getNodeName(): "+bwrNode.getNodeName()+" - bwr: "+bwr, LOG_FILE);

              //trdNode = getAppTradeNode(appNode, bwr, crd);
              }
              else if (bwrS.charAt(0) == dChar)
              {
              // fall through for now, cannot add trade
              //
              // added trade.
              //
              //trd = StringSupport.strToInt(trdS);
              //
              //S1Log.getLogInstance().log("***** continue D CHAR *****", LOG_FILE);
              continue;
              }
              else
              {
              //S1Log.getLogInstance().log("***** CREEDIT REPORT TRADE PROCESS *****", LOG_FILE);
              // credit report trade.
              //rpt = StringSupport.strToInt(rptS);
              //trd = StringSupport.strToInt(trdS);

              bwr = StringSupport.strToInt(rptS);
              bwrNode = getBwrReference(appNode, bwr);

              //S1Log.getLogInstance().log("2 bwrNode.getDataType(): "+bwrNode.getDataType(), LOG_FILE);
              //S1Log.getLogInstance().log("2 bwrNode.getIndex(): "+bwrNode.getIndex()+" - bwr: "+bwr, LOG_FILE);
              //S1Log.getLogInstance().log("2 bwrNode.getNodeName(): "+bwrNode.getNodeName()+" - bwr: "+bwr, LOG_FILE);

              //trdNode = getTradeNode(appNode, bwr, crd);
              }

              //S1Log.getLogInstance().log("if (bwrS.charAt(0) == 'a'): "+(bwrS.charAt(0) == 'a'), LOG_FILE);

              if (bwrS.charAt(0) == 'a')
              {
                //S1Log.getLogInstance().log("1 APP NODE/BWR NODE/TRD NODE UPDATE: ", LOG_FILE);
                //S1Log.getLogInstance().log("1 trdNode.getNodeName(): "+trdNode.getNodeName(), LOG_FILE);

                // App trade. Bwr trade node.
                //
                // trdNode.setFieldData(username, CSFieldNames.FN_CRDTR_SEL,  CSFieldValues.TRUE_STRING);
                //
                trdNode.setFieldData(username, CSFieldNames.FN_CRDTR_SEL, selected != null ? selected : CSFieldValues.EMPTY_STRING);

                trdNode.setFieldData(username, CSFieldNames.FN_CRDTR_NAME, creditor);

                if( payment != null && payment.trim().length() > 0 )
                {
                  trdNode.setFieldData(username, CSFieldNames.FN_CRDTR_PMT, payment);
                }

                trdNode.setFieldData(username, CSFieldNames.FN_CRDTR_BAL,  balance);

                //S1Log.getLogInstance().log("11 trdNode.getFieldData(): "+trdNode.getFieldData(""), LOG_FILE);
                //S1Log.getLogInstance().log("1 if (trdNode.getIndex() == 0): "+(trdNode.getIndex() == 0), LOG_FILE);

                if (trdNode.getIndex() == 0)
                {
                  // bwrNode.setFieldData(username, "atCrdtrHouseSelC", CSFieldValues.TRUE_STRING);
                  //
                  bwrNode.setFieldData(username, "atCrdtrHouseSelC", selected != null ? selected : CSFieldValues.FALSE_STRING);
                  bwrNode.setFieldData(username, CSFieldNames.FN_CRDTR_HOUSE,     creditor);

                  if( payment != null && payment.trim().length() > 0 )
                  {
                    bwrNode.setFieldData(username, CSFieldNames.FN_CRDTR_HOUSE_PMT, payment);
                  }

                  bwrNode.setFieldData(username, CSFieldNames.FN_CRDTR_HOUSE_BAL, balance);
                }
                else
                {
                  int index = trdNode.getIndex();

                  //S1Log.getLogInstance().log("1 trdNode.getIndex(): index: "+index, LOG_FILE);
                  //S1Log.getLogInstance().log("1 update field: atCrdtr" + index + "PayOffC", LOG_FILE);

                  // if combined node the index is not used.
                  //S1Log.getLogInstance().log("1 bwrNode.getDataType(): "+bwrNode.getDataType(), LOG_FILE);

                  //bwrNode.setFieldData(username, "atCrdtr" + index + "SelC", CSFieldValues.TRUE_STRING);

                  bwrNode.setFieldData(username, "atCrdtr" + index + "Name", creditor);

                  //S1Log.getLogInstance().log("if( payment != null && payment.trim().length() > 0 ): " + ( payment != null && payment.trim().length() > 0 ), LOG_FILE);
                  if( payment != null && payment.trim().length() > 0 )
                  {
                    bwrNode.setFieldData(username, "atCrdtr" + index + "Pmt", payment);
                  }

                  //S1Log.getLogInstance().log("if (balance != null): " + (balance != null), LOG_FILE);
                  if (balance != null)
                  {
                    bwrNode.setFieldData(username, "atCrdtr" + index + "Bal", balance);
                  }
                }

                //S1Log.getLogInstance().log("1 if (isPayoff): "+(isPayoff), LOG_FILE);
                if( isPayoff )
                {
                  // public static final String FN_CRDTR_SEL = "atCrdtrSel";
                  // public static final String FN_CRDTR_PAYOFF = "atCrdtrPayOff";
                  //
                  trdNode.setFieldData(username, CSFieldNames.FN_CRDTR_PAYOFF, CSFieldValues.TRUE_STRING);
                  trdNode.setFieldData(username, CSFieldNames.FN_CRDTR_SEL, CSFieldValues.FALSE_STRING);

                  //S1Log.getLogInstance().log("111 trdNode.getFieldData(): "+trdNode.getFieldData(""), LOG_FILE);
                  //S1Log.getLogInstance().log("111 if (trdNode.getIndex() == 0): "+(trdNode.getIndex() == 0), LOG_FILE);

                  if (trdNode.getIndex() == 0)
                  {
                    bwrNode.setFieldData(username, "atCrdtrHouseSelC",    CSFieldValues.FALSE_STRING);
                    bwrNode.setFieldData(username, "atCrdtrHousePayOffC", CSFieldValues.TRUE_STRING);
                  }
                  else
                  {
                    int index = trdNode.getIndex();

                    //S1Log.getLogInstance().log("111 index: "+index, LOG_FILE);
                    //S1Log.getLogInstance().log("111 update field to true: atCrdtr" + index + "PayOffC", LOG_FILE);

                    bwrNode.setFieldData(username, "atCrdtr" + index + "SelC",    CSFieldValues.FALSE_STRING);
                    bwrNode.setFieldData(username, "atCrdtr" + index + "PayOffC", CSFieldValues.TRUE_STRING);
                  }

                  //S1Log.getLogInstance().log("1111 trdNode.getFieldData(): "+trdNode.getFieldData(""), LOG_FILE);
                  //S1Log.getLogInstance().log("1111 bwrNode.getFieldData(): "+bwrNode.getFieldData(""), LOG_FILE);

                } // END if (isPayoff)
                else
                {
                    // atCrdtrHousePayOffC - bwr house trade
                    // atCrdtrPayOff    - bwr/app trade
                    // cbTrPayoff       - rpt trade

                    //public static final String FN_CRDTR_SEL = "atCrdtrSel";
                    //public static final String FN_CRDTR_PAYOFF = "atCrdtrPayOff";
                    //
                    trdNode.setFieldData(username, CSFieldNames.FN_CRDTR_PAYOFF, CSFieldValues.FALSE_STRING);

                    // trdNode.setFieldData(username, CSFieldNames.FN_CRDTR_SEL, CSFieldValues.TRUE_STRING);
                    //
                    String crdPO = null;
                    //S1Log.getLogInstance().log("if( origTrdHash.containsKey( CSFieldNames.FN_CRDTR_PAYOFF ) ): "+( origTrdHash.containsKey( CSFieldNames.FN_CRDTR_PAYOFF ) ), LOG_FILE);
                    if( origTrdHash.containsKey( CSFieldNames.FN_CRDTR_PAYOFF ) )
                    {
                      crdPO = (String)origTrdHash.get( CSFieldNames.FN_CRDTR_PAYOFF );
                      //S1Log.getLogInstance().log("crdPO: "+crdPO, LOG_FILE);
                    }

                    //S1Log.getLogInstance().log("if( crdPO != null && crdPO.trim().equals( CSFieldValues.TRUE_STRING ) ): "+( crdPO != null && crdPO.trim().equals( CSFieldValues.TRUE_STRING ) ), LOG_FILE);
                    if( crdPO != null && crdPO.trim().equals( CSFieldValues.TRUE_STRING ) )
                    {
                      trdNode.setFieldData(username, CSFieldNames.FN_CRDTR_SEL, CSFieldValues.TRUE_STRING);
                    }
                    else
                    {
                      trdNode.setFieldData(username, CSFieldNames.FN_CRDTR_SEL, selected != null ? selected : CSFieldValues.EMPTY_STRING);
                    }

                    //S1Log.getLogInstance().log("2 if (trdNode.getIndex() == 0): "+(trdNode.getIndex() == 0), LOG_FILE);

                    if (trdNode.getIndex() == 0)
                    {
                      String crdHsPO = null;
                      //S1Log.getLogInstance().log("if( origTrdHash.containsKey( atCrdtrHousePayOffC ) ): "+( origTrdHash.containsKey( "atCrdtrHousePayOffC" ) ), LOG_FILE);
                      if( origTrdHash.containsKey( "atCrdtrHousePayOffC" ) )
                      {
                        crdHsPO = (String)origTrdHash.get( "atCrdtrHousePayOffC" );
                        //S1Log.getLogInstance().log("crdHsPO: "+crdHsPO, LOG_FILE);
                      }

                      //S1Log.getLogInstance().log("if( crdHsPO != null && crdHsPO.trim().equals( CSFieldValues.TRUE_STRING ) ): "+( crdHsPO != null && crdHsPO.trim().equals( CSFieldValues.TRUE_STRING ) ), LOG_FILE);
                      if( crdHsPO != null && crdHsPO.trim().equals( CSFieldValues.TRUE_STRING ) )
                      {
                        trdNode.setFieldData(username, "atCrdtrHouseSelC", CSFieldValues.TRUE_STRING);
                      }
                      else
                      {
                        bwrNode.setFieldData(username, "atCrdtrHouseSelC",    selected != null ? selected : CSFieldValues.FALSE_STRING);
                      }

                      bwrNode.setFieldData(username, "atCrdtrHousePayOffC", CSFieldValues.FALSE_STRING);
                    }
                    else
                    {
                      int index = trdNode.getIndex();

                      //S1Log.getLogInstance().log("2 index: "+index, LOG_FILE);
                      //S1Log.getLogInstance().log("2 update field: "+"atCrdtr" + index + "PayOffC", LOG_FILE);

                      // bwrNode.setFieldData(username, "atCrdtr" + index + "SelC",    selected != null ? selected : CSFieldValues.TRUE_STRING);
                      //
                      String selectedStr = "atCrdtr" + index + "SelC";
                      String payOffStr = "atCrdtr" + index + "PayOffC";

                      String crdInxPO = null;
                      //S1Log.getLogInstance().log("if( origTrdHash.containsKey( payOffStr ) ): "+( origTrdHash.containsKey( payOffStr ) ), LOG_FILE);
                      if( origTrdHash.containsKey( payOffStr ) )
                      {
                        crdInxPO = (String)origTrdHash.get( payOffStr );
                        //S1Log.getLogInstance().log("crdInxPO: "+crdInxPO, LOG_FILE);
                      }

                      //S1Log.getLogInstance().log("if( crdInxPO != null && crdInxPO.trim().equals( CSFieldValues.TRUE_STRING ) ): "+( crdInxPO != null && crdInxPO.trim().equals( CSFieldValues.TRUE_STRING ) ), LOG_FILE);
                      if( crdInxPO != null && crdInxPO.trim().equals( CSFieldValues.TRUE_STRING ) )
                      {
                        trdNode.setFieldData(username, selectedStr, CSFieldValues.TRUE_STRING);
                      }
                      else
                      {
                        bwrNode.setFieldData(username, selectedStr, selected != null ? selected : CSFieldValues.TRUE_STRING);
                      }

                      // bwrNode.setFieldData(username, "atCrdtr" + index + "PayOffC", CSFieldValues.FALSE_STRING);
                      //
                      bwrNode.setFieldData(username, payOffStr, CSFieldValues.FALSE_STRING);
                    }
                } // END else( is Not Payoff )
              }
              else
              {
                //S1Log.getLogInstance().log("2 REPORT TRADE NODE UPDATE: ", LOG_FILE);
                //S1Log.getLogInstance().log("2 trdNode.getNodeName(): "+trdNode.getNodeName(), LOG_FILE);

                // public static final String FN_CB_TR_CRDT = "cbTrCrdt";
                //
                // trdNode.setSystemData(CSFieldNames.FN_SELECTED_TRADE, CSFieldValues.TRUE_STRING);
                //
                trdNode.setFieldData(username, CSFieldNames.FN_CB_TR_CRDT, creditor);

                if( payment != null && payment.trim().length() > 0 )
                {
                  trdNode.setFieldData(username, CSFieldNames.FN_CB_TR_PMT, payment);
                }

                trdNode.setFieldData(username, CSFieldNames.FN_CB_TR_BAL, balance);

                //S1Log.getLogInstance().log("2 if (isPayoff): "+(isPayoff), LOG_FILE);

                if (isPayoff)
                {
                  trdNode.setFieldData(username, CSFieldNames.FN_CB_TR_PAYOFF, CSFieldValues.TRUE_STRING);
                  trdNode.setSystemData(CSFieldNames.FN_SELECTED_TRADE, CSFieldValues.FALSE_STRING);
                }
                else
                {
                  // trdNode.setSystemData(CSFieldNames.FN_SELECTED_TRADE, CSFieldValues.TRUE_STRING);
                  //
                  String crdRptPO = null;
                  //S1Log.getLogInstance().log("if( origTrdHash.containsKey( CSFieldNames.FN_CB_TR_PAYOFF ) ): "+( origTrdHash.containsKey( CSFieldNames.FN_CB_TR_PAYOFF ) ), LOG_FILE);
                  if( origTrdHash.containsKey( CSFieldNames.FN_CB_TR_PAYOFF ) )
                  {
                    crdRptPO = (String)origTrdHash.get( CSFieldNames.FN_CB_TR_PAYOFF );
                    //S1Log.getLogInstance().log("crdRptPO: "+crdRptPO, LOG_FILE);
                  }

                  //S1Log.getLogInstance().log("if( crdRptPO != null && crdRptPO.trim().equals( CSFieldValues.TRUE_STRING ) ): "+( crdRptPO != null && crdRptPO.trim().equals( CSFieldValues.TRUE_STRING ) ), LOG_FILE);
                  if( crdRptPO != null && crdRptPO.trim().equals( CSFieldValues.TRUE_STRING ) )
                  {
                    trdNode.setSystemData(CSFieldNames.FN_SELECTED_TRADE, CSFieldValues.TRUE_STRING );
                  }
                  else
                  {
                    trdNode.setSystemData(CSFieldNames.FN_SELECTED_TRADE,  selected != null ? selected : CSFieldValues.TRUE_STRING);
                  }

                  trdNode.setFieldData(username, CSFieldNames.FN_CB_TR_PAYOFF, CSFieldValues.FALSE_STRING);
                }
              }
            } // if( trdNode != null && trdNode.isDeleted() )
          } // if (tok.countTokens() == 3)
        } // for(int j=0,k=tradeList.size(); j<k; j++)
      } // if( appNode != null && ! appNode.isDeleted() )
    } // if( sdo != null )

    //S1Log.getLogInstance().log("END processApplicationTradeLines(...)", LOG_FILE);

  } // processApplicationTradeLines( SystemDataObject sdo, String username )


  // called from getBwrReference gets bwrs and conmbined bwrs for for processing
  //
  public static VectorX getBwrReferences(DataNode appNode)
  {
    //S1Log.getLogInstance().log("START public static VectorX getBwrReferences(DataNode appNode)", LOG_FILE);
    VectorX allBwrs = new VectorX();

    VectorX borrowers = appNode.getEffectiveReferences(NodeUtils.BWR_DN_TYPE);
    //S1Log.getLogInstance().log("borrowers.size(): "+borrowers.size(), LOG_FILE);

    VectorX cmbBwrs = appNode.getEffectiveReferences(NodeUtils.CMB_BWR_DN_TYPE);
    //S1Log.getLogInstance().log("cmbBwrs.size(): "+cmbBwrs.size(), LOG_FILE);

    if (borrowers != null)
    {
      allBwrs.addAll(borrowers);
    }

    if (cmbBwrs != null)
    {
      allBwrs.addAll(cmbBwrs);
    }

    //S1Log.getLogInstance().log("END public static VectorX getBwrReferences(DataNode appNode)", LOG_FILE);
    return allBwrs;
  }

  public static DataNode getBwrReference(DataNode appNode, int bwrIndex)
  {
    //S1Log.getLogInstance().log("START getBwrReference(DataNode appNode, int bwrIndex)", LOG_FILE);
    //S1Log.getLogInstance().log("int bwrIndex: "+bwrIndex, LOG_FILE);
    
    // get bwrs and combined bwrs
    //
    VectorX borrowers = getBwrReferences(appNode);

    DataNode bwrNode = null;

    if (borrowers != null)
    {
      try
      {
        bwrNode = (DataNode) borrowers.get(bwrIndex);
      }
      catch( ArrayIndexOutOfBoundsException ee )
      {
        ee.printStackTrace();
        //AdminGUIManager.displayE("AppImportUtils: Borrower index not valid: " + bwrIndex);
      }
      catch( Exception e )
      {
          e.printStackTrace();
      }
    }

    //S1Log.getLogInstance().log("END getBwrReference(DataNode appNode, int bwrIndex)", LOG_FILE);

    return bwrNode;
  }

  public static DataNode getAppTradeNode(DataNode appNode, int bwrNum, int crdNum)
  {
    DataNode trdNode = null;
    DataNode bwrNode = getBwrReference(appNode, bwrNum);

    if (bwrNode != null && ! bwrNode.isDeleted())
      trdNode = bwrNode.getReference(NodeUtils.BWR_TR_DN_TYPE, crdNum);

    return trdNode;
  }


  public static DataNode getTradeNodeFromCode(DataNode appNode, String tradeCode)
  {
    StringTokenizer tok = new StringTokenizer(tradeCode, ":");

    DataNode trdNode = null;

    if (tok.countTokens() == 3) {
      String bwrS = tok.nextToken();
      String rptS = tok.nextToken();
      String trdS = tok.nextToken();

      if (bwrS.charAt(0) == 'a')
      {
        // Creditor trades from application.
        int bwr = StringSupport.strToInt(rptS);
        int crd = StringSupport.strToInt(trdS);

        trdNode = getAppTradeNode(appNode, bwr, crd);
      }
      else if (bwrS.charAt(0) == 'x')
      {
        // Estimated payment node.
        trdNode = appNode.getReference(NodeUtils.EP_DN_TYPE, 0);
      }
      else if (bwrS.charAt(0) == 'd')
      {
        // Added trade.
        //int bwr = StringSupport.strToInt(rptS);
        //int trd = StringSupport.strToInt(trdS);
        //trdNode = getAddedTradeNode(appNode, bwr, trd);
      }
      else
      {
        // Credit report trade.
        int bwr = StringSupport.strToInt(bwrS);
        int rpt = StringSupport.strToInt(rptS);
        int trd = StringSupport.strToInt(trdS);

        trdNode = getTradeNode(appNode, bwr, rpt, trd);
      }
    }

    return trdNode;
  }

  public static DataNode getTradeNode(DataNode appNode, int bwrNum, int rptNum, int trdNum)
  {
    DataNode trdNode = null;
    DataNode bwrNode = getBwrReference(appNode, bwrNum);
    if (bwrNode != null)
    {
      DataNode rptNode = bwrNode.getReference(NodeUtils.RPRT_DN_TYPE, rptNum);

      if (rptNode != null) {
        trdNode = rptNode.getReference(NodeUtils.TR_DN_TYPE, trdNum);
      }
    }

    return trdNode;
  }

  public static VectorX getNonPartyOwners( VectorX ownrVec )
  {
    VectorX nonPrtyVec = new VectorX();

    for( int i=0,c=ownrVec.size(); i<c; i++ )
    {
      DataNode ownNode = (DataNode)ownrVec.get(i);

      if( ownNode != null && ! ownNode.isDeleted() )
      {
        String ownrRadio = (String)ownNode.getFieldData( CSFieldValues.EMPTY_STRING, "OnrIsR" );

        if( ownrRadio != null && ownrRadio.trim().equals("1") )
        {
          nonPrtyVec.add( ownNode );
        }
      }
    }

    return nonPrtyVec;
  }

  public static VectorX deleteAllNonPartyOwners( VectorX ownrVec )
  {
    VectorX nonPrtyVec = new VectorX();

    for( int i=0,c=ownrVec.size(); i<c; i++ )
    {
      DataNode ownNode = (DataNode)ownrVec.get(i);

      if( ownNode != null && ! ownNode.isDeleted() )
      {
        String ownrRadio = (String)ownNode.getFieldData( CSFieldValues.EMPTY_STRING, "OnrIsR" );

        if( ownrRadio != null && ownrRadio.trim().equals("1") )
        {
          ownNode.delete();
        }
      }
    }

    return nonPrtyVec;
  }

  public static String getDataEntryUser( String CONFIG_DIR, String CONFIG_FILE_NAME, String CONFIG_EXT )
  {
    String dataEntryUser = null;

    try
    {
      Configuration cfgDEU = new Configuration();
      cfgDEU.load(CONFIG_DIR + CONFIG_FILE_NAME + CONFIG_EXT);
      dataEntryUser = cfgDEU.getSectionProperty("Settings", "username");
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }

    if (dataEntryUser == null || dataEntryUser.trim().length() == 0)
    {
      dataEntryUser = getName();
    }

    return dataEntryUser;
  }

  public static String getBwrIndexFromSDO( SystemDataObject sdo, String ssn )
  {
    //S1Log.getLogInstance().log("START getBwrIndexFromSDO( SystemDataObject sdo, String ssn )", LOG_FILE);
    //S1Log.getLogInstance().log("String ssn: "+ssn, LOG_FILE);

    String bwrIndex = null;

    //S1Log.getLogInstance().log("if( sdo != null ): "+( sdo != null ), LOG_FILE);
    if( sdo != null )
    {
      DataNode appDN = sdo.getNodeData( NodeUtils.APP_DN_TYPE );
      VectorX bwrVec = appDN.getEffectiveReferences( NodeUtils.BWR_DN_TYPE );

      if( bwrVec != null && ! bwrVec.isEmpty() )
      {
        for( int i=0, c=bwrVec.size(); i<c; i++ )
        {
          DataNode bwrDN = (DataNode)bwrVec.get(i);

          ////S1Log.getLogInstance().log(i+" bwrDN: "+bwrDN, LOG_FILE);

          if( bwrDN != null )
          {
            // application:borrower.0:atSSN = 109-42-6190
            //
            HashtableX bwrHt = bwrDN.getFieldData(CSFieldValues.EMPTY_STRING);
            //S1Log.getLogInstance().log("bwrHt: "+bwrHt, LOG_FILE);

            String bwrSSN = (String)bwrHt.get(CSFieldNames.FN_SSN);
            //S1Log.getLogInstance().log("bwrSSN: "+bwrSSN, LOG_FILE);

            //S1Log.getLogInstance().log("if( bwrSSN != null && bwrSSN.trim().equals(ssn) ): "+( bwrSSN != null && bwrSSN.trim().equals(ssn) ), LOG_FILE);
            if( bwrSSN != null && bwrSSN.trim().equals(ssn) )
            {
              bwrIndex = String.valueOf( bwrDN.getIndex() );
              //S1Log.getLogInstance().log("bwrIndex: "+bwrIndex, LOG_FILE);
            }
          }
        }
      }
    }

    //S1Log.getLogInstance().log("return bwrIndex: "+bwrIndex, LOG_FILE);
    //S1Log.getLogInstance().log("END getBwrIndexFromSDO( SystemDataObject sdo, String ssn )", LOG_FILE);

    return bwrIndex;
  } // public static DataNode getPrimaryBwrNodeFromSDO( SystemDataObject sdo )

  public static VectorX getTradesForBwr(DataNode appNode, int bwrNum)
  {
    //S1Log.getLogInstance().log("START getTradesForBwr(DataNode appNode, int bwrNum): ", LOG_FILE);

    VectorX trades = null;
    DataNode bwrNode = getBwrReference(appNode, bwrNum);

    //S1Log.getLogInstance().log("if( bwrNode != null && ! bwrNode.isDeleted() ): "+( bwrNode != null && ! bwrNode.isDeleted() ), LOG_FILE);
    if( bwrNode != null && ! bwrNode.isDeleted() )
    {
      DataNode rptNode = bwrNode.getFirstReference(NodeUtils.RPRT_DN_TYPE);
      //S1Log.getLogInstance().log("rptNode: "+rptNode, LOG_FILE);

      if( rptNode != null && ! rptNode.isDeleted() )
      {
        // trdNode = rptNode.getReference(NodeUtils.TR_DN_TYPE);
        //
        trades = rptNode.getEffectiveReferences(NodeUtils.TR_DN_TYPE);
      }
    }

    //S1Log.getLogInstance().log("return trades: "+trades, LOG_FILE);
    //S1Log.getLogInstance().log("END getTradesForBwr(DataNode appNode, int bwrNum): ", LOG_FILE);
    return trades;
  }

  public static VectorX getLiabilitiesForBwr(DataNode appNode, int bwrNum)
  {
    //S1Log.getLogInstance().log("START getLiabilitiesForBwr(DataNode appNode, int bwrNum): ", LOG_FILE);

    VectorX liabilities = null;
    DataNode bwrNode = getBwrReference(appNode, bwrNum);

    // //S1Log.getLogInstance().log("bwrNode: "+bwrNode, LOG_FILE);
    //
    //S1Log.getLogInstance().log("if( bwrNode != null && ! bwrNode.isDeleted() ): "+( bwrNode != null && ! bwrNode.isDeleted() ), LOG_FILE);

    if( bwrNode != null && ! bwrNode.isDeleted() )
    {
      DataNode laibNode = bwrNode.getFirstReference(NodeUtils.LB_DN_TYPE);

      if( laibNode != null && ! laibNode.isDeleted() )
      {
        liabilities = laibNode.getEffectiveReferences(NodeUtils.LB_DN_TYPE);
      }
    }

    //S1Log.getLogInstance().log("return liabilities: "+liabilities, LOG_FILE);
    //S1Log.getLogInstance().log("END getLiabilitiesForBwr(DataNode appNode, int bwrNum): ", LOG_FILE);

    return liabilities;
  }


  public static DataNode getLienDataNodeByPositionWFE(DataNode colNode, String lnPosD)
  {
    //S1Log.getLogInstance().log("START getLienDataNodeByPositionWFE: ", LOG_FILE);

    DataNode returnDataNode = null;

    VectorX liens = colNode.getEffectiveReferences(NodeUtils.LIEN_DN_TYPE);

    //S1Log.getLogInstance().log("liens: "+liens, LOG_FILE);

    if( liens != null && ! liens.isEmpty() )
    {
      for(int i=0,c=liens.size(); i<c; i++ )
      {
        DataNode lienDN = (DataNode)liens.get(i);

        String position = (String)lienDN.getFieldData(CSFieldValues.EMPTY_STRING, "lnPosD");

        if( position != null && lnPosD != null && position.trim().equals( lnPosD.trim() ) )
        {
          returnDataNode = lienDN;
        }
      }
    }

    //S1Log.getLogInstance().log("END getLienDataNodeByPositionWFE: ", LOG_FILE);

    return returnDataNode;
  }

  // AppImportUtils.clienLienNodesForWFE( colDN, collLienList );
  //
  public static void cleanLienNodesForWFE(DataNode colNode, VectorX collLienList)
  {
    //S1Log.getLogInstance().log("START cleanLienNodesForWFE: ", LOG_FILE);

    VectorX liens = colNode.getEffectiveReferences(NodeUtils.LIEN_DN_TYPE);

    //S1Log.getLogInstance().log("liens: "+liens, LOG_FILE);
    if(liens!=null)S1Log.getLogInstance().log("liens.size(): "+liens.size(), LOG_FILE);

    VectorX positionList = new VectorX();

    if( collLienList != null && ! collLienList.isEmpty() )
    {
      //S1Log.getLogInstance().log("collLienList.size(): "+collLienList.size(), LOG_FILE);
      for( int p=0,q=collLienList.size(); p<q; p++ )
      {
        HashtableX lienDataMap = StringChanger.stringToHashtable( (String)collLienList.get(p) );
        //S1Log.getLogInstance().log("lienDataMap: " + lienDataMap, LOG_FILE);

        if( lienDataMap != null && ! lienDataMap.isEmpty() )
        {
          String lnPosD = (String)lienDataMap.get("lnPosD");
          //S1Log.getLogInstance().log("lnPosD: " + lnPosD, LOG_FILE);

          if( lnPosD != null && lnPosD.trim().length() > 0 )
          {
            positionList.add(lnPosD.trim());
          }
        }
      }

      //S1Log.getLogInstance().log("positionList: "+positionList, LOG_FILE);

      if( positionList != null && ! positionList.isEmpty() )
      {
        if( liens != null && ! liens.isEmpty() )
        {
          for(int ii=0,cc=liens.size(); ii<cc; ii++ )
          {
            DataNode lienDN = (DataNode)liens.get(ii);

            String position = (String)lienDN.getFieldData(CSFieldValues.EMPTY_STRING, "lnPosD");

            //S1Log.getLogInstance().log("position: " + position, LOG_FILE);
            //S1Log.getLogInstance().log("if( ! positionList.contains( position ) ): " + ( ! positionList.contains( position ) ), LOG_FILE);

            if( ! positionList.contains( position ) )
            {
              lienDN.delete();
              //S1Log.getLogInstance().log("DELETE LIEN NODE: ", LOG_FILE);
            }
          }
        }
      }
    }
    else
    {
      // delete all liens if any exist
      //
      if( liens != null && ! liens.isEmpty() )
      {
        //S1Log.getLogInstance().log("DELETE ALL LIENS", LOG_FILE);
        for(int i=0,c=liens.size(); i<c; i++ )
        {
          DataNode lienDN = (DataNode)liens.get(i);
          if( lienDN != null && ! lienDN.isDeleted() )
          {
            lienDN.delete();
          }
        }
      }

    }

    //S1Log.getLogInstance().log("END cleanLienNodesForWFE: ", LOG_FILE);
  }

  // AppImportUtils.setupApplicationAssetNode(sdo, DATA_ENTRY_USER, appAssetList, branchId);
  //
  // public static void setupApplicationAssetNode( SystemDataObject sdo, String username, List assetList, String branchId ) throws Exception
  //
  /*
   // asset fields
   application:Asset.0:Cash, Savings and CD's.0:!bwrIndex = 0
   application:Asset.0:Cash, Savings and CD's.0:_NtWrthBwrM = 0
   application:Asset.0:Cash, Savings and CD's.0:_NtWrthSelC = true
   application:Asset.0:Cash, Savings and CD's.0:_NtWrthSubTypD = AstCash
   application:Asset.0:Cash, Savings and CD's.0:_NtWrthTypD = Asset
   application:Asset.0:Cash, Savings and CD's.0:astAcctNum = 24213234
   application:Asset.0:Cash, Savings and CD's.0:astAddr = HSBC Building
   application:Asset.0:Cash, Savings and CD's.0:astAddrTwo = Suite 456
   application:Asset.0:Cash, Savings and CD's.0:astCity = Erie
   application:Asset.0:Cash, Savings and CD's.0:astName = HSBC
   application:Asset.0:Cash, Savings and CD's.0:astStD = PA
   application:Asset.0:Cash, Savings and CD's.0:astStatementDt = 08/28/2009
   application:Asset.0:Cash, Savings and CD's.0:astTypD = Cash
   application:Asset.0:Cash, Savings and CD's.0:astVal = 50000.00
   application:Asset.0:Cash, Savings and CD's.0:astZip = 16509

   // asset bwr fields
   application:Asset.0:Cash, Savings and CD's.0:atAstPlg = 0.0
   application:Asset.0:Cash, Savings and CD's.0:atAstUnplg = 0.0
   application:Asset.0:Cash, Savings and CD's.0:atLiSec = 0.0
   application:Asset.0:Cash, Savings and CD's.0:atLiUnsec = 0.0
   application:Asset.0:Cash, Savings and CD's.0:atNtRntlInc = 0.0
   application:Asset.0:Cash, Savings and CD's.0:atNtRntlIncPrdD = Monthly
   application:Asset.0:Cash, Savings and CD's.0:atNtWrth = 0.0
   application:Asset.0:Cash, Savings and CD's.0:atTtlAst = 0.0
   application:Asset.0:Cash, Savings and CD's.0:atTtlLi = 0.0

   application:Asset.0:Cash, Savings and CD's.0:isPropagate = false
   application:Asset.0:Cash, Savings and CD's.0:isVirtual = false
   application:Asset.0:Cash, Savings and CD's.0:isVirtualModified = false

  */

  // update of the original method below with more credisphere functionality
  //public static void setupApplicationAssetOrLiabilityNode( SystemDataObject sdo, String username, List assetList, int branchId, boolean IS_SUBMIT ) throws Exception

  public static void setupApplicationAssetOrLiabilityNode( SystemDataObject sdo, String username, List assetList, int branchId ) throws Exception
  {
    setupApplicationAssetOrLiabilityNode( sdo, username, assetList, branchId, CSFieldValues.FALSE_STRING );
  }

  public static void setupApplicationAssetOrLiabilityNode( SystemDataObject sdo, String username, List assetList, int branchId, String clearAssetsFlag ) throws Exception
  {
    //general.errLog("START setupApplicationAssetOrLiabilityNode(...)","AstLiabSetUpDN.log");
    //general.errLog("assetList: "+assetList,"AstLiabSetUpDN.log");
    //general.errLog("branchId: "+branchId,"AstLiabSetUpDN.log");
    //general.errLog("clearAssetsFlag: "+clearAssetsFlag,"AstLiabSetUpDN.log");

    DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);
    //general.errLog("appNode loaded","AstLiabSetUpDN.log");

    boolean firstRun = true;
    boolean firstRunLien = true;

    boolean CLEAR_ASSETS_FLAG = clearAssetsFlag != null && clearAssetsFlag.trim().toLowerCase().equals( CSFieldValues.TRUE_STRING );
    //general.errLog("CLEAR_ASSETS_FLAG: "+CLEAR_ASSETS_FLAG,"AstLiabSetUpDN.log");

    boolean ADD_ACTION_FLAG = false; // override all actions and add assets
    //general.errLog("ADD_ACTION_FLAG: "+ADD_ACTION_FLAG,"AstLiabSetUpDN.log");

    VectorX bwrsEffctRefrnces = appNode.getEffectiveReferences( NodeUtils.BWR_DN_TYPE );
    //general.errLog("bwrsEffctRefrnces: "+bwrsEffctRefrnces.size(),"AstLiabSetUpDN.log");

    for (int i = 0, c = assetList.size(); i < c; i++)
    {
      //general.errLog("START LOOPING: "+i,"AstLiabSetUpDN.log");

      HashtableX assetLiabilityHash = StringChanger.stringToHashtable(assetList.get(i).toString());
      //general.errLog("assetHash: "+assetLiabilityHash,"AstLiabSetUpDN.log");

      //  Update copmbined housing expense vista fields in the application node
      //
      //  <CurrentResidence>true</CurrentResidence>
      //  if true set corresponding ins and tax fields in application node
      //
      //general.errLog("if( assetLiabilityHash != null && assetLiabilityHash.containsKey(CurrentResidence) ): "+( assetLiabilityHash != null && assetLiabilityHash.containsKey("astCurrResC") ),"AstLiabSetUpDN.log");

      if( assetLiabilityHash != null && assetLiabilityHash.containsKey("astCurrResC") )
      {
        String isCurrRes = (String)assetLiabilityHash.get("astCurrResC");
        //general.errLog("isCurrRes: "+isCurrRes,"AstLiabSetUpDN.log");

        if( isValidString( isCurrRes ) && isCurrRes.trim().equals( CSFieldValues.TRUE_STRING ) )
        {
          /*
          assetHash.put("astMtgIns",  isValidString(astMtgIns) ? astMtgIns  : CSFieldValues.EMPTY_STRING );
          assetHash.put("astIns",     isValidString(astIns)    ? astIns     : CSFieldValues.EMPTY_STRING );
          assetHash.put("astSchTax",  isValidString(astSchTax) ? astSchTax  : CSFieldValues.EMPTY_STRING );
          assetHash.put("astPropTax", isValidString(astPropTax)? astPropTax : CSFieldValues.EMPTY_STRING );
          assetHash.put("astHOA",     isValidString(astHOA)    ? astCurrResC: CSFieldValues.EMPTY_STRING );
          */
          String val = (String)assetLiabilityHash.get("astMtgIns");
          //general.errLog("astMtgIns: "+val,"AstLiabSetUpDN.log");
          if( isValidString( val ) )
          {
            appNode.setFieldData(CSFieldValues.EMPTY_STRING, "anMtgInsAmt", val);
          }

          val = (String)assetLiabilityHash.get("astIns");
          //general.errLog("astIns: "+val,"AstLiabSetUpDN.log");
          if( isValidString( val ) )
          {
            appNode.setFieldData(CSFieldValues.EMPTY_STRING, "anHzInsAmt", val);
          }

          double reTaxAmt = 0.00;
          //general.errLog("1 reTaxAmt: "+reTaxAmt,"AstLiabSetUpDN.log");

          val = (String)assetLiabilityHash.get("astSchTax");
          //general.errLog("astSchTax: "+val,"AstLiabSetUpDN.log");
          if( isValidString( val ) )
          {
            reTaxAmt += StringSupport.strToDouble( val );
            //general.errLog("2 schTax reTaxAmt: "+reTaxAmt,"AstLiabSetUpDN.log");
          }

          val = (String)assetLiabilityHash.get("astPropTax");
          //general.errLog("astPropTax: "+val,"AstLiabSetUpDN.log");
          if( isValidString( val ) )
          {
            reTaxAmt += StringSupport.strToDouble( val );
            //general.errLog("2 schTax + propTax = anRETxAmt: reTaxAmt: "+reTaxAmt,"AstLiabSetUpDN.log");

            // appNode.setFieldData(CSFieldValues.EMPTY_STRING, "anRETxAmt", val);
            //
            appNode.setFieldData(CSFieldValues.EMPTY_STRING, "anRETxAmt", String.valueOf( FinCalcs.round( reTaxAmt, 2 )));
          }

          val = (String)assetLiabilityHash.get("astHOA");
          //general.errLog("astHOA: "+val,"AstLiabSetUpDN.log");
          if( isValidString( val ) )
          {
            appNode.setFieldData(CSFieldValues.EMPTY_STRING, "anHOAAmt", val);
          }

          // MonthlyPayments
          //
          val = (String)assetLiabilityHash.get("astPmt");
          //general.errLog("astPmt: "+val,"AstLiabSetUpDN.log");
          if( isValidString( val ) )
          {
            appNode.setFieldData(CSFieldValues.EMPTY_STRING, "an1stMtgAmt", val);
          }
        }
      }

      // boolean isAdd = false;
      //
      DataNode nwNode = null;
      DataNode nwItemNode = null;

      if (appNode != null)
      {
        // sent in parameters
        //
        //String branchID = (String)appNode.getFieldData(username, CSFieldNames.FN_BRANCH_ID);
        //int branch = StringSupport.strToInt(branchID);

        String action = null;
        if( assetLiabilityHash.containsKey("astAction"))
        {
          action = (String) assetLiabilityHash.get("astAction");
        }
        else if( assetLiabilityHash.containsKey("liAction"))
        {
          action = (String) assetLiabilityHash.get("liAction");
        }

        //general.errLog("action: "+action, "AstLiabSetUpDN.log");

        String nwItemIndex = null;
        if( assetLiabilityHash.containsKey("astSubNodeIndex"))
        {
          nwItemIndex = (String) assetLiabilityHash.get("astSubNodeIndex");
        }
        else if( assetLiabilityHash.containsKey("liSubNodeIndex"))
        {
          nwItemIndex = (String) assetLiabilityHash.get("liSubNodeIndex");
        }

        //general.errLog("nwItemIndex: "+nwItemIndex, "AstLiabSetUpDN.log");

        VectorX sharedBy = (VectorX)assetLiabilityHash.get("_NtWrthBwrM");

        if( bwrsEffctRefrnces != null && ! bwrsEffctRefrnces.isEmpty() )
        {
          sharedBy = createAssetLiabilityOwnerVec(bwrsEffctRefrnces, sharedBy);
        }
        //general.errLog("sharedBy: "+sharedBy,"AstLiabSetUpDN.log");

        String nwType = (String) assetLiabilityHash.get("_NtWrthTypD");
        //general.errLog("nwType: "+nwType, "AstLiabSetUpDN.log");

        String nwSubType = (String) assetLiabilityHash.get("_NtWrthSubTypD");
        //general.errLog("nwSubType: "+nwSubType, "AstLiabSetUpDN.log");

        String nwSubTypeLabel = ApplicationHouse.getListCodesCache().getListCodeLabel( nwType + " Sub Types", nwSubType, branchId );
        //general.errLog("nwSubTypeLabel: "+nwSubTypeLabel,"AstLiabSetUpDN.log");

        nwNode = appNode.getReference(nwType, 0); // only one node for Asset or Liability node
        //general.errLog("nwNode: "+nwNode, "AstLiabSetUpDN.log");

        // delete current asset node. intiial submit for WFE. have to do because
        // we do not have node indexes and the asset could have been edited
        // during the WFE submit process.
        // nwType: Asset
        //
        //general.errLog("firstRun: "+firstRun, "AstLiabSetUpDN.log");
        //general.errLog("loop: "+i, "AstLiabSetUpDN.log");
        //general.errLog("ADD_ACTION_FLAG: "+ADD_ACTION_FLAG, "AstLiabSetUpDN.log");
        //general.errLog("if (CLEAR_ASSETS_FLAG...): "+( CLEAR_ASSETS_FLAG && firstRun && i == 0 && nwType != null && nwType.trim().equals( "Asset" ) && nwNode != null  ), "AstLiabSetUpDN.log");

        // if( CLEAR_ASSETS_FLAG && firstRun && i == 0 && nwType != null && nwType.trim().equals( "Asset" ) && nwNode != null  )
        //
        if( CLEAR_ASSETS_FLAG && firstRun && i == 0 && nwNode != null && ! nwNode.isDeleted() )
        {
          //general.errLog("DELETE ASSET NODE: loop = "+i+" type = "+nwType, "AstLiabSetUpDN.log");

          List refDataTypes = nwNode.getReferenceDataTypes();
          //general.errLog("refDataTypes: "+refDataTypes, "AstLiabSetUpDN.log");

          if (refDataTypes != null && !refDataTypes.isEmpty())
          {
            for (int x = 0, y = refDataTypes.size(); x < y; x++)
            {
              String refDataType = (String) refDataTypes.get(x);
              boolean refRmvd = nwNode.removeReferences(refDataType);
              //general.errLog("REMOVE REFERENCES: refRmvd: "+refRmvd+" refDataType: "+refDataType, "AstLiabSetUpDN.log");
            }
          }

          firstRun = false;
          ADD_ACTION_FLAG = true; // override all actions and add assets
          CLEAR_ASSETS_FLAG = false; // reset to false

          //general.errLog("SET firstRun: "+firstRun, "AstLiabSetUpDN.log");
          //general.errLog("SET ADD_ACTION_FLAG: "+ADD_ACTION_FLAG, "AstLiabSetUpDN.log");

        } // if( CLEAR_ASSETS_FLAG && firstRun && i == 0 && nwNode != null && ! nwNode.isDeleted() )


        //boolean showSelected = false;

        // if( IS_SUBMIT )
        //
        if( ADD_ACTION_FLAG || action != null && action.trim().toLowerCase().equals("add") )
        {
          assetLiabilityHash.put("_NtWrthSelC", "true");
          //showSelected = true;
        }

        //general.errLog("if( nwNode == null ): "+( nwNode == null ), "AstLiabSetUpDN.log");
        //general.errLog("if( nwNode != null && nwNode.isDeleted() ): "+( nwNode != null && nwNode.isDeleted() ), "AstLiabSetUpDN.log");
        //general.errLog("if( nwNode == null || nwNode.isDeleted() ): "+( nwNode == null || nwNode.isDeleted() ), "AstLiabSetUpDN.log");

        if( nwNode == null )
        {
          nwNode = sdo.createDataNode(username, nwType);
          nwNode.setSystemData("!container", "true");
          appNode.addReference(nwNode);

          //general.errLog("ADDED SUB NODE "+nwType+" TO APP NODE loop = "+i, "AstLiabSetUpDN.log");
        }

        //general.errLog("nwNode loaded","AstLiabSetUpDN.log");

        if( ADD_ACTION_FLAG || action != null && action.trim().toLowerCase().equals("add") )
        {
          xResponse xres = DataEntrySupport.checkNWItemDuplication(nwNode, nwSubType, assetLiabilityHash, username);
          //general.errLog("if (xres.errCode != 0): "+(xres.errCode != 0),"AstLiabSetUpDN.log");
          if (xres.errCode != 0)
            {

              // throw exception here, duplicate asset or liability
              //
              // DO NOT THROW KEEP ROLLING
              //
              //String dupError = (String)xres.param.firstElement();
              //general.errLog("DUPLICATE ASSET-LIAB NODE ERROR: dupError: "+dupError,"AstLiabSetUpDN.log");

              continue;
            }

          nwItemNode = sdo.createDataNode(username, nwSubTypeLabel);

          if (sharedBy == null || sharedBy.isEmpty())
          {
             nwItemNode.removeSystemData("!bwrIndex");
          }
          else
          {
            nwItemNode.setSystemData("!bwrIndex", sharedBy);
          }

          nwNode.addReference(nwItemNode);

          //general.errLog("CREATE nwItemNode - type: "+nwSubTypeLabel,"AstLiabSetUpDN.log");
        }
        else
        {
          //general.errLog("LOAD EXISTING NODE - type: "+nwSubTypeLabel,"AstLiabSetUpDN.log");

//
// node index for item is -1 but the action is EDIT
//
//
//

          if(nwItemIndex != null )
          {
            int nwIndex = StringSupport.changeStringToInt(nwItemIndex);
            //general.errLog("LOAD EXISTING NODE - int nwItemIndex: "+nwIndex,"AstLiabSetUpDN.log");

            if( nwIndex >= 0 )
            {
              nwItemNode = nwNode.getReference(nwSubTypeLabel, nwIndex);
              //general.errLog("EXISTING NODE LOADED - node ht: "+nwItemNode.getFieldData(""),"AstLiabSetUpDN.log");
            }
            else
            {
              //general.errLog("UNABLE TO LOCATE ASSET-LIAB NODE INDEX: "+nwIndex,"AstLiabSetUpDN.log");

              // continue;
              // throw exception here, invalid sub node index ???
              //

              // steve is adding a WFE index for any liability that does not have
              // a index associated with it. Loop through liabilities and find match
              // and then load liability node
              //
              String liIndexWFE = (String)assetLiabilityHash.get( "liIndexWFE" );
              //general.errLog("liIndexWFE: "+liIndexWFE,"AstLiabSetUpDN.log");

              if( liIndexWFE != null && liIndexWFE.trim().length() > 0 )
              {
                String liTypD = (String)assetLiabilityHash.get( "liTypD" );
                //general.errLog("liTypD: "+liTypD,"AstLiabSetUpDN.log");

                if( liTypD != null && liTypD.trim().length() > 0 )
                {
                  //general.errLog("liTypD: "+liTypD+"  nwSubTypeLabel: "+nwSubTypeLabel,"AstLiabSetUpDN.log");
                  VectorX nwVec = nwNode.getEffectiveReferences( nwSubTypeLabel );
                  //general.errLog("nwVec: "+nwVec,"AstLiabSetUpDN.log");

                  if( nwVec != null && ! nwVec.isEmpty() )
                  {
                    boolean notFound = true;
                    for(int ff=0,gg=nwVec.size(); ff<gg; ff++ )
                    {
                      nwItemNode = (DataNode)nwVec.get(ff);

                      if( nwItemNode != null && ! nwItemNode.isDeleted() )
                      {
                        String tempLiIndexWFE = (String)nwItemNode.getFieldData( CSFieldValues.EMPTY_STRING, "liIndexWFE");

                        //general.errLog("liIndexWFE: "+liIndexWFE,"AstLiabSetUpDN.log");
                        //general.errLog("tempLiIndexWFE: "+tempLiIndexWFE,"AstLiabSetUpDN.log");
                        //general.errLog("if( tempLiIndexWFE != null && tempLiIndexWFE.trim().equals( liIndexWFE.trim() ) ): "+( tempLiIndexWFE != null && tempLiIndexWFE.trim().equals( liIndexWFE.trim() ) ),"AstLiabSetUpDN.log");

                        if( tempLiIndexWFE != null && tempLiIndexWFE.trim().equals( liIndexWFE.trim() ) )
                        {
                          //general.errLog("***** BREAK *****","AstLiabSetUpDN.log");
                          notFound = false;
                          break;
                        }
                      }
                    }

                    //general.errLog("if( notFound ): "+( notFound ),"AstLiabSetUpDN.log");
                    if( notFound )
                    {
                      nwItemNode = null;
                    }
                  }
                }
              }
              else
              {
                continue;
              }
            }
          }
        } // if( ADD_ACTION_FLAG || action != null && action.trim().toLowerCase().equals("add") )

        if( action != null && action.trim().toLowerCase().equals("delete") )
        {
          if( nwItemNode != null )
          {
            nwItemNode.delete();
            //general.errLog("SUB NODE DELETED", "AstLiabSetUpDN.log");
          }
          else
          {
            //general.errLog("DELETE ERROR - SUB NODE NOT DELETED - SUB NODE VALUE NULL", "AstLiabSetUpDN.log");
          }
        } // if( action != null && action.trim().toLowerCase().equals("delete") )

       try
       {
         // create net worth item node
         //
         //general.errLog("nwItemNode.setFieldData(username, "+username+" assetLiabilityHash): "+assetLiabilityHash,"AstLiabSetUpDN.log");
         //general.errLog("nwItemNode.setSystemData(!bwrIndex, sharedBy): "+sharedBy,"AstLiabSetUpDN.log");

         if(  nwItemNode != null )
         {
           HashtableX updtdFldData = nwItemNode.getFieldData( CSFieldValues.EMPTY_STRING );

           //general.errLog("1 updtdFldData: "+updtdFldData,"AstLiabSetUpDN.log");
           //general.errLog("PUT ALL assetLiabilityHash: "+assetLiabilityHash,"AstLiabSetUpDN.log");

           updtdFldData.putAll( assetLiabilityHash );

           //general.errLog("2 updtdFldData: "+updtdFldData,"AstLiabSetUpDN.log");

           // change the liREOD to the corresponding collateral index
           // liREOD=123 MAIN ST
           //
           //general.errLog("if( assetLiabilityHash.containsKey(liREOD) ): "+( assetLiabilityHash.containsKey("liREOD") ),"AstLiabSetUpDN.log");
           if( assetLiabilityHash.containsKey("liREOD") )
           {
             String liReod = (String)assetLiabilityHash.get("liREOD");
             //general.errLog("liReod: "+liReod,"AstLiabSetUpDN.log");

             String indexLiREOD = getAssociatedPropertyIndexRE(appNode, liReod);
             //general.errLog("indexLiREOD: "+indexLiREOD,"AstLiabSetUpDN.log");

             if( indexLiREOD != null && indexLiREOD.trim().length() > 0 )
             {
               updtdFldData.put("liREOD", indexLiREOD);

               // check for refi first
               //
               String isRefiStr = (String)appNode.getFieldData( CSFieldValues.EMPTY_STRING, "anGETransTypD");
               //general.errLog("isRefiStr: "+isRefiStr,"AstLiabSetUpDN.log");

               //general.errLog("if( isRefiStr != null && MGUtils.isMortgageRefinanceTransaction( isRefiStr ) ): "+( isRefiStr != null && MGUtils.isMortgageRefinanceTransaction( isRefiStr ) ),"AstLiabSetUpDN.log");

               if( isRefiStr != null && MGUtils.isMortgageRefinanceTransaction( isRefiStr ) )
               {
                 String liTypD = (String)assetLiabilityHash.get("liTypD");
                 //general.errLog("liTypD: "+liTypD,"AstLiabSetUpDN.log");

                 String liPayOffC = (String)assetLiabilityHash.get("liPayOffC");
                 //general.errLog("liPayOffC: "+liPayOffC,"AstLiabSetUpDN.log");


                 //general.errLog("SET UP LIEN NODE FOR LIAB: "+( (liTypD != null && liTypD.trim().toLowerCase().equals("mortgage")) && (liPayOffC != null && liPayOffC.trim().equals(CSFieldValues.FALSE_STRING)) ),"AstLiabSetUpDN.log");

                 /*
                 #1____________
                  If:
                  -liability type=mortgage AND
                  -Associated Property=Property being financed AND
                  -tradeline is not marked to pay off

                  Then:
                  -import each tradeline into the lien summary vista with the balance as the
                  amount of lien, payment as payment, account name as lien name, type=first
                  or second

                  This will allow the ltv�s to calculate properly on refinances.

                  #2____________
                  If:
                  -liability type=mortgage AND
                  -Associated Property=Property being financed

                  Then:
                  -sum all tradeline payments with the above criteria and import into the
                  Present First Mortgage (P&I) field in the Combined Housing Expense Summary
                  vista
                 */
                 if( (liTypD != null && liTypD.trim().toLowerCase().equals("mortgage") ) )
                 {
                   //general.errLog("if( firstRunLien ): "+( firstRunLien ),"AstLiabSetUpDN.log");
                   if( firstRunLien )
                   {
                       // remove wfe liens no matter what.
                       try
                       {
                         removeLiensForWfE( appNode );
                       }
                       catch( Exception lns )
                       {
                         lns.printStackTrace();
                         //general.errLog("remove lien error: " + lns, "AstLiabSetUpDN.log");
                       }

                       firstRunLien = false;
                   }


                   // create lien node
                   //
                   // sdo.getNodeData()
                   //
                   //general.errLog("LOAD ASSET NODE: index = "+indexLiREOD,"AstLiabSetUpDN.log");

                   DataNode assetNode = appNode.getFirstReference( NodeUtils.AST_DN_TYPE );
                   //general.errLog("assetNode: "+assetNode,"AstLiabSetUpDN.log");

                   // "Real Estate Properties"
                   DataNode assocAssetNode = assetNode.getReference( NodeUtils.AST_RE_DN_TYPE, Integer.parseInt( indexLiREOD ) );
                   //general.errLog("assocAssetNode: "+assocAssetNode,"AstLiabSetUpDN.log");

                   HashtableX astHT = assocAssetNode.getFieldData( CSFieldValues.EMPTY_STRING );
                   //general.errLog("astHT: "+astHT,"AstLiabSetUpDN.log");

                   String astSubPropC = (String)astHT.get("astSubPropC");
                   //general.errLog("astSubPropC: "+astSubPropC,"AstLiabSetUpDN.log");

                   if( astSubPropC != null && astSubPropC.trim().equals(CSFieldValues.TRUE_STRING) )
                   {
                     HashtableX lienHash = new HashtableX();

                     // if marked payoff set lien refinancing radio to 1 / yes
                     //
                     lienHash.put("lnRefiR", "0");
                     lienHash.put("lnCredTypD", "Loan");

                     String lienLimit = (String)assetLiabilityHash.get("liLmt");
                     //general.errLog("lienLimit: "+lienLimit,"AstLiabSetUpDN.log");
                     if( isValidString(lienLimit) ) lienHash.put("lnOrigAmt", lienLimit);

                     String lienAcctNum = (String)assetLiabilityHash.get("liAcctNum");
                     //general.errLog("lienAcctNum: "+lienAcctNum,"AstLiabSetUpDN.log");
                     if( isValidString(lienAcctNum) ) lienHash.put("lnAcctNo", lienAcctNum);


                     String lienBalance = (String)assetLiabilityHash.get("liVal");
                     if( isValidString(lienBalance) )lienHash.put("lnBal", lienBalance);

                     // double sumOfPmts = 0.00;
                     //
                     String lienPayment = (String)assetLiabilityHash.get("liPmt");
                     //general.errLog("lienPayment: "+lienPayment,"AstLiabSetUpDN.log");

                     if( isValidString(lienPayment) )
                     {
                       lienHash.put("lnPmt", lienPayment);
                     }

                     String lienAccountName = (String)assetLiabilityHash.get("liName");
                     //general.errLog("lienAccountName: "+lienAccountName,"AstLiabSetUpDN.log");
                     if( isValidString(lienAccountName) )lienHash.put("lnPrior", lienAccountName);

                     String lienType = (String)assetLiabilityHash.get("liLnPosD");
                     //general.errLog("lienType: "+lienType,"AstLiabSetUpDN.log");

                     if( isValidString(lienType) )lienHash.put("lnPosD", lienType);

                     // general.errLog("if (liPayOffC != null && liPayOffC.trim().equals(CSFieldValues.FALSE_STRING)): "+ (liPayOffC != null && liPayOffC.trim().equals(CSFieldValues.FALSE_STRING)),"AstLiabSetUpDN.log");
                     // if (liPayOffC != null && liPayOffC.trim().equals(CSFieldValues.FALSE_STRING))
                     //
                     //  ADD: if is selected (_NtWrthSelC = true) and if paid is false (liPaidC = false)
                     //
                     String liPaidCStr = (String)assetLiabilityHash.get("liPaidC");
                     //general.errLog("liPaidCStr: "+liPaidCStr,"AstLiabSetUpDN.log");

                     boolean liPaidC = (liPaidCStr == null || (liPaidCStr != null && liPaidCStr.trim().equals( CSFieldValues.FALSE_STRING )));
                     //general.errLog("liPaidC: "+liPaidC,"AstLiabSetUpDN.log");

                     String isSelectedStr = (String)assetLiabilityHash.get("_NtWrthSelC");
                     //general.errLog("isSelectedStr: "+isSelectedStr,"AstLiabSetUpDN.log");

                     boolean _NtWrthSelC = (isSelectedStr != null && isSelectedStr.trim().equals( CSFieldValues.TRUE_STRING ));
                     //general.errLog("_NtWrthSelC: "+_NtWrthSelC,"AstLiabSetUpDN.log");

                     //general.errLog("if( liPayOffC != null && liPayOffC.trim().equals(CSFieldValues.FALSE_STRING) && liPaidC && _NtWrthSelC ): "+( liPayOffC != null && liPayOffC.trim().equals(CSFieldValues.FALSE_STRING) && liPaidC && _NtWrthSelC ),"AstLiabSetUpDN.log");

                     // if (liPayOffC != null && liPayOffC.trim().equals(CSFieldValues.FALSE_STRING))
                     //
                     if( liPayOffC != null && liPayOffC.trim().equals(CSFieldValues.FALSE_STRING) && liPaidC && _NtWrthSelC )
                     {
                       DataNode lienNode = sdo.createDataNode( username, NodeUtils.LIEN_DN_TYPE );
                       lienNode.setFieldData(username, lienHash);
                       lienNode.setSystemData("!isWfeLien", "true");
                       //general.errLog("lienNode: "+lienNode,"AstLiabSetUpDN.log");

                       // appNode.addReference(nwNode);
                       // application:collateral.0:Real Estate.0:Lien.0:!lnLTV = 11.11
                       //
                       DataNode colDN = appNode.getFirstReference( NodeUtils.COLL_DN_TYPE );

                       //general.errLog("if( colDN != null && ! colDN.isDeleted() ): "+( colDN != null && ! colDN.isDeleted() ),"AstLiabSetUpDN.log");
                       if( colDN != null && ! colDN.isDeleted() )
                       {
                         //general.errLog("colDN: " + colDN.getFieldData(""), "AstLiabSetUpDN.log");
                         //general.errLog("colDN.getIndex(): " + colDN.getIndex(), "AstLiabSetUpDN.log");

                         DataNode reColDN = colDN.getFirstReference(NodeUtils.RE_DN_TYPE);

                         //general.errLog("reColDN: " + reColDN.getFieldData(""), "AstLiabSetUpDN.log");
                         //general.errLog("reColDN.getIndex(): " + reColDN.getIndex(),"AstLiabSetUpDN.log");

                         // check to make sure RE
                         //
                         reColDN.addReference(lienNode);
                         reColDN.setFieldData(CSFieldValues.EMPTY_STRING, "phyXstgLienC", CSFieldValues.TRUE_STRING);

                         //general.errLog("reColDN: " + reColDN, "AstLiabSetUpDN.log");
                       }
                     }
                   }
                 }
               } // if( isRefi )
             }
             else
             {
               updtdFldData.remove("liREOD");
             }
           }

           nwItemNode.setFieldData(username, updtdFldData);
           if (sharedBy == null || sharedBy.isEmpty())
           {
             nwItemNode.removeSystemData("!bwrIndex");
           }
           else
           {
             nwItemNode.setSystemData("!bwrIndex", sharedBy);
           }

           //general.errLog("SUB NODE SET","AstLiabSetUpDN.log");
           //general.errLog("nwItemNode: "+nwItemNode,"AstLiabSetUpDN.log");
         } // if(  nwItemNode != null )

       }
       catch( Exception o )
       {
         o.printStackTrace();
         //general.errLog("ERROR: SET SUB NODE DATA: "+o.getMessage(),"AstLiabSetUpDN.log");
       }

      } // if( appNode != null )

      //general.errLog("END LOOPING: "+i,"AstLiabSetUpDN.log");
    } // for (int i = 0, c = assetList.size(); i < c; i++)

    //general.errLog("END setupApplicationAssetOrLiabilityNode((...)","AstLiabSetUpDN.log");

  } // setupApplicationAssetOrLiabilityNode((...)

  public static void updateApplicationTotalValues( String nwSubTypeLabel,
                                        DataNode nwItemNode,
                                        String nwSubType,
                                        DataNode nwNode,
                                        String username,
                                        DataNode bwrNode )
 {

    //general.errLog("START updateTotalValues(...)",AIU);

    // get net worth sub type node
    //
    String secPlgTypD = null;
    //String nodeSecPlgTypD = null;
    String secPlgFieldName = null;

    // added or edited asset/liability item value
    //
    String nwField = null;
    String nwValueStr = null;
    //String nwValueOldStr = null;
    double nwValue = 0.0D;
    //double nwValueOld = 0.0D;

    // subtotal of certain type of pledged asset or secured liability
    //
    String nodeFieldNameSecSubTtl = null;
    String nodeFieldNameUnsecSubTtl = null;
    String secSubTtlValueStr = null;
    String unsecSubTtlValueStr = null;
    //String csFieldNameSecSubTtl = null;
    //String csFieldNameUnsecSubTtl = null;
    double secSubTtlValue = 0.0D;
    double unsecSubTtlValue = 0.0D;

    // subtotal value of certain type of asset or liability
    //
    //String csFieldNameSubTtl = null;
    //String subTtlValueStr = null;
    double subTtlValue = 0.0D;

    // total pledged/unpledged assets or secured/unsecured liabilities
    //
    String ttlSecValStr = null;
    String ttlUnsecValStr = null;
    String nodeFieldNameSecTtl = null;
    String nodeFieldNameUnsecTtl = null;
    String csFieldNameSecTtl = null;
    String csFieldNameUnsecTtl = null;
    double ttlSecVal = 0.0D;
    double ttlUnsecVal = 0.0D;

    // total assets or liabilities value
    //
    String ttlValueStr = null;
    String nodeFieldNameTtl = null;
    String csFieldNameTtl = null;
    double ttlValue = 0.0D;

    // DEFINITION OF VARIABLES based on net worth type (Asset or Liability)
    //
    if (nwSubType.startsWith(AST_SUB_TYPE_PREFIX)) {
      nwField = "astVal";
      nodeFieldNameTtl = CSFieldNames.FN_SYS_TTL_AST;
      csFieldNameTtl = CSFieldNames.FN_BWR_TTL_AST;
      //csFieldNameSubTtl = "_astTtlVal";

      nodeFieldNameSecTtl = CSFieldNames.FN_SYS_TTL_PLG;
      nodeFieldNameUnsecTtl = CSFieldNames.FN_SYS_TTL_UN_PLG;
      csFieldNameSecTtl = CSFieldNames.FN_BWR_AST_PLG;
      csFieldNameUnsecTtl = CSFieldNames.FN_BWR_AST_UNPLG;

      //csFieldNameSecSubTtl = "_astTtlPlg";
      //csFieldNameUnsecSubTtl = "_astTtlUnplg";
      nodeFieldNameSecSubTtl = "!" + nwSubType + "Plg";
      nodeFieldNameUnsecSubTtl = "!" + nwSubType + "Unplg";

      secPlgFieldName = "astPlgD";
      //secPlgTypD = (String) inFields.get(secPlgFieldName);
      secPlgTypD = (String) nwItemNode.getFieldData( username, secPlgFieldName);
    }
    else if (nwSubType.startsWith(LB_SUB_TYPE_PREFIX)) {
      nwField = "liVal";
      nodeFieldNameTtl = CSFieldNames.FN_SYS_TTL_LI;
      csFieldNameTtl = CSFieldNames.FN_BWR_TTL_LI;
      //csFieldNameSubTtl = "_liTtlVal";

      nodeFieldNameSecTtl = CSFieldNames.FN_SYS_TTL_SEC;
      nodeFieldNameUnsecTtl = CSFieldNames.FN_SYS_TTL_UNSEC;
      csFieldNameSecTtl = CSFieldNames.FN_BWR_LI_SEC;
      csFieldNameUnsecTtl = CSFieldNames.FN_BWR_LI_UNSEC;

      //csFieldNameSecSubTtl = "_liTtlSec";
      //csFieldNameUnsecSubTtl = "_liTtlUnsec";
      nodeFieldNameSecSubTtl = "!" + nwSubType + "Sec";
      nodeFieldNameUnsecSubTtl = "!" + nwSubType + "Unsec";

      secPlgFieldName = "liPlgD";
      //secPlgTypD = (String) inFields.get(secPlgFieldName);
      secPlgTypD = (String) nwItemNode.getFieldData( username, secPlgFieldName);
    }

//general.errLog("nwSubTypeLabel: "+nwSubTypeLabel,AIU);

    if (nwItemNode != null && !nwItemNode.isDeleted())
    {

      //nwValueOldStr = (String) nwItemNode.getFieldData(username, nwField);
      //general.errLog("nwValueOldStr: "+nwValueOldStr);
      //if (nwValueOldStr != null && nwValueOldStr.length() > 0) { nwValueOld = Double.parseDouble(nwValueOldStr); }

      //nodeSecPlgTypD = (String) nwItemNode.getFieldData(username, secPlgFieldName);

//general.errLog("nodeSecPlgTypD: "+nodeSecPlgTypD,AIU);

    }

    nwValueStr = (String) nwItemNode.getFieldData( username,  nwField );

//general.errLog("nwValueStr: "+nwValueStr,AIU);

    if (nwValueStr != null && nwValueStr.length() > 0) {
      nwValue = Double.parseDouble(nwValueStr);
    }

    // subtotal value of pledged asset or secured liability
    //
    secSubTtlValueStr = (String) nwNode.getSystemData(nodeFieldNameSecSubTtl);

//general.errLog("secSubTtlValueStr: "+secSubTtlValueStr,AIU);

    if (secSubTtlValueStr != null && secSubTtlValueStr.length() > 0) {
      secSubTtlValue = Double.parseDouble(secSubTtlValueStr);
    }

    unsecSubTtlValueStr = (String) nwNode.getSystemData(nodeFieldNameUnsecSubTtl);

//general.errLog("unsecSubTtlValueStr: "+unsecSubTtlValueStr,AIU);

    if (unsecSubTtlValueStr != null && unsecSubTtlValueStr.length() > 0) {
      unsecSubTtlValue = Double.parseDouble(unsecSubTtlValueStr);
    }

    // total value of pledged assets or secured liabilities
    //
    ttlSecValStr = (String) nwNode.getSystemData(nodeFieldNameSecTtl);

//general.errLog("ttlSecValStr: "+ttlSecValStr,AIU);

    if (ttlSecValStr != null && ttlSecValStr.length() > 0) {
      ttlSecVal = Double.parseDouble(ttlSecValStr);
    }

    ttlUnsecValStr = (String) nwNode.getSystemData(nodeFieldNameUnsecTtl);

//general.errLog("ttlUnsecValStr: "+ttlUnsecValStr,AIU);

    if (ttlUnsecValStr != null && ttlUnsecValStr.length() > 0) {
      ttlUnsecVal = Double.parseDouble(ttlUnsecValStr);
    }

    // total value of assets or liabilities
    //
    ttlValueStr = (String) nwNode.getSystemData(nodeFieldNameTtl);

//general.errLog("ttlValueStr: "+ttlValueStr,AIU);

    if (ttlValueStr != null && ttlValueStr.length() > 0) {
      ttlValue = Double.parseDouble(ttlValueStr);
    }


      // In this section we deal with 3 cases: save the new added NWitem, load the
      // NWitem form if the user click "EditNWitem", and reload the form when the
      // user delete the NWItem.
      //

//general.errLog("SAVE SECURED: "+(secPlgTypD != null && secPlgTypD.equals(CSFieldValues.TRUE_STRING)),AIU);

        // If the user save the added NWItem
        //
        if (secPlgTypD != null && secPlgTypD.equals(CSFieldValues.TRUE_STRING)) {


          secSubTtlValue += nwValue;

//general.errLog("SAVE secSubTtlValue: "+secSubTtlValue,AIU);

          ttlSecVal += nwValue;

//general.errLog("SAVE ttlSecVal: "+ttlSecVal,AIU);

          //outFieldsHash.put(csFieldNameSecSubTtl, String.valueOf(secSubTtlValue));

          // for populating the total values in vista "Owner_Principal_Net_Worth.sb"
          //
          // outFieldsHash.put(csFieldNameSecTtl, String.valueOf(ttlSecVal));
          //
          bwrNode.setFieldData( username, csFieldNameSecTtl, String.valueOf(ttlSecVal) );

          nwNode.setSystemData(nodeFieldNameSecSubTtl,
                               String.valueOf(secSubTtlValue));
          nwNode.setSystemData(nodeFieldNameSecTtl,
                               String.valueOf(ttlSecVal));
        }
        else {
          unsecSubTtlValue += nwValue;

//general.errLog("SAVE unsecSubTtlValue: "+unsecSubTtlValue,AIU);

          ttlUnsecVal += nwValue;

//general.errLog("SAVE ttlUnsecVal: "+ttlUnsecVal,AIU);

          //outFieldsHash.put(csFieldNameUnsecSubTtl, String.valueOf(unsecSubTtlValue));

          // for populating the total values in vista "Owner_Principal_Net_Worth.sb"
          //
          // outFieldsHash.put(csFieldNameUnsecTtl, String.valueOf(ttlUnsecVal));
          //
          bwrNode.setFieldData( username, csFieldNameUnsecTtl, String.valueOf(ttlUnsecVal) );

          nwNode.setSystemData(nodeFieldNameUnsecSubTtl,
                               String.valueOf(unsecSubTtlValue));
          nwNode.setSystemData(nodeFieldNameUnsecTtl,
                               String.valueOf(ttlUnsecVal));
        }

        subTtlValue = secSubTtlValue + unsecSubTtlValue;

//general.errLog("SAVE subTtlValue: "+subTtlValue,AIU);

        ttlValue += nwValue;

//general.errLog("SAVE ttlValue: "+ttlValue,AIU);

        //outFieldsHash.put(csFieldNameSubTtl, String.valueOf(subTtlValue));

        nwNode.setSystemData("!" + nwSubType,
                             String.valueOf(subTtlValue));
        nwNode.setSystemData(nodeFieldNameTtl,
                             String.valueOf(ttlValue));

        // for populating the total values in vista "Owner_Principal_Net_Worth.sb"
        //
        // outFieldsHash.put(csFieldNameTtl, String.valueOf(ttlValue));
        //
        bwrNode.setFieldData( username, csFieldNameTtl, String.valueOf(ttlValue) );

//general.errLog("END updateTotalValues(...)",AIU);

  } // updateTotalValues

  // updateTotalNetWorth
  //
  /**
   *   A method that updates the total value of net worth.
   *   @param   nwNode  a data node containg net worth data.
   *   @param   outFieldsHash  a hash table contains fields and field values.
   *   @return  none.
   *   @exception none
   */
  public static void updateApplicationTotalNetWorth( String username, DataNode bwrNode, DataNode nwNode) {
    String atTtlAstStr = null;
    String atTtlLiStr = null;

    double atTtlAst = 0.0D;
    double atTtlLi  = 0.0D;
    double atNtWrth = 0.0D;

    atTtlAstStr = (String) bwrNode.getFieldData( username, CSFieldNames.FN_BWR_TTL_AST );
    atTtlLiStr  = (String) bwrNode.getFieldData( username, CSFieldNames.FN_BWR_TTL_LI );

    if (atTtlAstStr != null && atTtlAstStr.length() > 0) {
      atTtlAst = Double.parseDouble(atTtlAstStr);
    }

    if (atTtlLiStr != null && atTtlLiStr.length() > 0) {
      atTtlLi = Double.parseDouble(atTtlLiStr);
    }

    atNtWrth = atTtlAst - atTtlLi;

    bwrNode.setFieldData( username, CSFieldNames.FN_BWR_NT_WRTH, String.valueOf(atNtWrth) );
    nwNode.setSystemData(CSFieldNames.FN_SYS_NT_WRTH, String.valueOf(atNtWrth));
  } // updateTotalNetWorth

  // AppImportUtils.setupBwrPrvAEmpNode(sdo, 0, DATA_ENTRY_USER, atPrvEmpHash);
  //
  public static void setupBwrPrvEmpNode( SystemDataObject sdo, int bwrNodePosition, String username, HashtableX prvEmpHash )
  throws Exception
  {
    //general.errLog("START setupBwrPrvEmpNode( SystemDataObject sdo, int bwrNodePosition, String username, HashtableX prvEmpHash )","PrvEmpNode.log");
    //general.errLog("int bwrNodePosition: "+bwrNodePosition,"PrvEmpNode.log");
    //general.errLog("String username: "+username,"PrvEmpNode.log");
    //general.errLog("HashtableX prvEmpHash: "+prvEmpHash,"PrvEmpNode.log");

    // NodeUtils.BWR_PRV_EMP_DN_TYPE
    //
    int bwrSubNodePosition = -1;
    boolean isAdd       = false;
    DataNode bwrNode    = null;
    DataNode bwrSubNode = null;

    String action = (String) prvEmpHash.get("atPrvEmpAction");
    //general.errLog("action: "+action,"PrvEmpNode.log");

    DataNode appDN = sdo.getNodeData(NodeUtils.APP_DN_TYPE);

    if (appDN != null)
    {
      bwrNode = appDN.getReference(NodeUtils.BWR_DN_TYPE, bwrNodePosition);

      if( bwrNode != null && ! bwrNode.isDeleted() )
      {
        VectorX prvEmpVec = bwrNode.getEffectiveReferences( NodeUtils.BWR_PRV_EMP_DN_TYPE );

        //general.errLog("prvEmpVec: "+prvEmpVec ,"PrvEmpNode.log");
        if( prvEmpVec != null && ! prvEmpVec.isEmpty() )
        {
          //general.errLog("prvEmpVec.size(): "+prvEmpVec.size() ,"PrvEmpNode.log");

          String bwrSubNodePosStr = (String) prvEmpHash.get("atPrvEmpIndex");

          if( bwrSubNodePosStr != null && bwrSubNodePosStr.trim().length() > 0 )
          {
            bwrSubNodePosition = StringSupport.changeStringToInt(bwrSubNodePosStr);
            //general.errLog("bwrSubNodePosition: " + bwrSubNodePosition, "PrvEmpNode.log");
          }
          else
          {
            if (prvEmpVec.size() == 1)
            {
              bwrSubNode = (DataNode)prvEmpVec.firstElement();
            }
          }
        }
        else
        {
          // is add
          //
          isAdd = true;
        }

        //general.errLog("if (isAdd): "+(isAdd),"PrvEmpNode.log");

        if (isAdd)
        {
          bwrSubNode = sdo.createDataNode(username, NodeUtils.BWR_PRV_EMP_DN_TYPE);
          bwrSubNode.setFieldData(username, prvEmpHash);
          bwrNode.addReference(bwrSubNode);
        }
        else
        {
          if( bwrSubNode == null )
          {
            bwrSubNode = bwrNode.getReference( NodeUtils.BWR_PRV_EMP_DN_TYPE, bwrSubNodePosition );
            //general.errLog( "bwrSubNode: " + bwrSubNode, "PrvEmpNode.log" );
          }

          if( bwrSubNode == null )
          {
            throw new Exception("Unable to update borrowers previous employment node: Unable to locate selected node.");
          }

          if( action != null && action.trim().toLowerCase().equals("delete"))
          {
            //general.errLog("DELETE NODE: ","PrvEmpNode.log");
            bwrSubNode.delete();
          }
          else
          {
            //general.errLog("UPDATE NODE: prvEmpHash: "+prvEmpHash,"PrvEmpNode.log");
            bwrSubNode.setFieldData(username, prvEmpHash);
          }
        }
      }
    }

    //general.errLog("End setupBwrPrvEmpNode( SystemDataObject sdo, int bwrNodePosition, String username, HashtableX prvEmpHash )","PrvEmpNode.log");
  }


  public static void setupBwrAddEmpNode( SystemDataObject sdo, int bwrNodePosition, String username, VectorX addEmpList )
      throws Exception
  {
    //general.errLog("START setupBwrAddEmpNode( SystemDataObject sdo, int bwrNodePosition, String username, HashtableX prvEmpHash )","AddEmpNode.log");
    //general.errLog("int bwrNodePosition: "+bwrNodePosition,"AddEmpNode.log");
    //general.errLog("String username: "+username,"AddEmpNode.log");
    //general.errLog("VectorX addEmpList: "+addEmpList,"AddEmpNode.log");

    //boolean isAdd = false;

    boolean CLEAR_EMP_FLAG =  false;
    boolean ADD_EMP_FLAG   =  false;

    for( int i=0,c=addEmpList.size(); i<c; i++ )
    {
      HashtableX addEmpHash = (HashtableX)addEmpList.get(i);
      //general.errLog("HashtableX addEmpHash: " + addEmpHash, "AddEmpNode.log");

      int bwrSubNodePosition = -1;
      DataNode bwrNode = null;
      DataNode bwrSubNode = null;

      String action = (String) addEmpHash.get("atAddEmpAction");
      //general.errLog("action: "+action,"AddEmpNode.log");

      // Steve - do not want to add edit to action field, if action is blank skip, cannot be edited,
      //
      //general.errLog("if( action == null || action.trim().length() == 0 ) - SKIP UPDATE OF DATA: "+( action == null || action.trim().length() == 0 ),"AddEmpNode.log");
      if( action == null || action.trim().length() == 0 )
      {
        continue;
      }

      if( i == 0 )
      {
        String clrDataFlagStr = (String) addEmpHash.get("atAddEmpClearNodeData");
        //general.errLog("clrDataFlagStr: " + clrDataFlagStr, "AddEmpNode.log");

        CLEAR_EMP_FLAG = clrDataFlagStr != null && clrDataFlagStr.trim().equals(CSFieldValues.TRUE_STRING);
        //general.errLog("CLEAR_EMP_FLAG: " + CLEAR_EMP_FLAG, "AddEmpNode.log");
      }

      DataNode appDN = sdo.getNodeData(NodeUtils.APP_DN_TYPE);

      if (appDN != null)
      {
        bwrNode = appDN.getReference(NodeUtils.BWR_DN_TYPE, bwrNodePosition);

        if( bwrNode != null && ! bwrNode.isDeleted() )
        {

          //general.errLog("if( CLEAR_EMP_FLAG && i == 0 ): "+( CLEAR_EMP_FLAG && i == 0 ), "AddEmpNode.log");
          if( CLEAR_EMP_FLAG && i == 0 )
          {
            VectorX addEmpVec = bwrNode.getEffectiveReferences(NodeUtils.BWR_ADD_EMP_DN_TYPE);
            //general.errLog("CLEAR addEmpVec: " + addEmpVec, "AddEmpNode.log");

            if( addEmpVec != null && ! addEmpVec.isEmpty() )
            {
              boolean refRmvd = bwrNode.removeReferences( NodeUtils.BWR_ADD_EMP_DN_TYPE );
              //general.errLog("REMOVE REFERENCES: refRmvd: "+refRmvd+" refDataType: "+NodeUtils.BWR_ADD_EMP_DN_TYPE, "AddEmpNode.log");

              ADD_EMP_FLAG = refRmvd;
              //general.errLog("ADD_EMP_FLAG: "+ADD_EMP_FLAG, "AddEmpNode.log");
            }
            else
            {
              ADD_EMP_FLAG = true;
            }
          }

          VectorX addEmpVec = bwrNode.getEffectiveReferences(NodeUtils.BWR_ADD_EMP_DN_TYPE);

          //general.errLog("addEmpVec: " + addEmpVec, "AddEmpNode.log");
          //general.errLog("if( addEmpVec != null && ! addEmpVec.isEmpty() && ( is Edit or Delete ) ): " + ( addEmpVec != null && ! addEmpVec.isEmpty() && action != null && action.trim().length() > 0 && ( action.trim().toLowerCase().equals("edit") || action.trim().toLowerCase().equals("delete") ) ) , "AddEmpNode.log");

          if( addEmpVec != null && ! addEmpVec.isEmpty() &&
              ( action != null && action.trim().length() > 0 &&
                ( action.trim().toLowerCase().equals("edit") || action.trim().toLowerCase().equals("delete") ) ) )
          {
            String bwrSubNodePosStr = (String)addEmpHash.get("atAddEmpIndex");
            //general.errLog("bwrSubNodePosStr: " + bwrSubNodePosStr, "AddEmpNode.log");
            bwrSubNodePosition = StringSupport.changeStringToInt(bwrSubNodePosStr);
          }

          //general.errLog("if ( ADD_EMP_FLAG || ...action.equals(add))): " + ( ADD_EMP_FLAG || (action != null && action.trim().length() > 0 && action.trim().toLowerCase().equals("add") ) ), "AddEmpNode.log");

          if ( ADD_EMP_FLAG || (action != null && action.trim().length() > 0 && action.trim().toLowerCase().equals("add") ) )
          {
            bwrSubNode = sdo.createDataNode(username, NodeUtils.BWR_ADD_EMP_DN_TYPE);
            bwrSubNode.setFieldData(username, addEmpHash);
            bwrNode.addReference(bwrSubNode);
          }
          else
          {
            bwrSubNode = bwrNode.getReference(NodeUtils.BWR_ADD_EMP_DN_TYPE, bwrSubNodePosition);
            //general.errLog("bwrSubNode: " + bwrSubNode, "AddEmpNode.log");

            if (bwrSubNode == null)
            {
              throw new Exception("Unable to update borrowers additional employment node: Unable to locate selected node.");
            }

            if( action != null && action.trim().toLowerCase().equals("delete"))
            {
              //general.errLog("DELETE NODE: ", "AddEmpNode.log");
              bwrSubNode.delete();
            }
            else
            {
              //general.errLog("UPDATE NODE: bwrSubNodePosition: "+bwrSubNodePosition+" - addEmpHash: "+addEmpHash, "AddEmpNode.log");
              bwrSubNode.setFieldData(username, addEmpHash);
            }
          }
        }
      }
    }

    //general.errLog("End setupBwrAddEmpNode( SystemDataObject sdo, int bwrNodePosition, String username, HashtableX prvEmpHash )","AddEmpNode.log");
  }

  public static void setupBwrPrvAddrNode( SystemDataObject sdo, int bwrNodePosition, String username, HashtableX prvAddrHash )
      throws Exception
  {
    //general.errLog("START setupBwrPrvAddrNode( SystemDataObject sdo, int bwrNodePosition, String username, HashtableX prvEmpHash )","PrvAddrNode.log");
    //general.errLog("int bwrNodePosition: "+bwrNodePosition,"PrvAddrNode.log");
    //general.errLog("String username: "+username,"PrvAddrNode.log");
    //general.errLog("HashtableX prvEmpHash: "+prvAddrHash,"PrvAddrNode.log");

    // NodeUtils.BWR_PRV_EMP_DN_TYPE
    //
    int bwrSubNodePosition = -1;
    boolean isAdd       = false;
    DataNode bwrNode    = null;
    DataNode bwrSubNode = null;

    String action = (String) prvAddrHash.get("atPrvAddrAction");
    //general.errLog("action: "+action,"PrvAddrNode.log");

    DataNode appDN = sdo.getNodeData(NodeUtils.APP_DN_TYPE);

    if (appDN != null)
    {
      bwrNode = appDN.getReference(NodeUtils.BWR_DN_TYPE, bwrNodePosition);

      if( bwrNode != null && ! bwrNode.isDeleted() )
      {
        VectorX prvEmpVec = bwrNode.getEffectiveReferences( NodeUtils.BWR_PRV_ADD_DN_TYPE );
        //general.errLog("prvEmpVec: "+prvEmpVec,"PrvAddrNode.log");

        if( prvEmpVec != null && ! prvEmpVec.isEmpty() )
        {
          String bwrSubNodePosStr = (String) prvAddrHash.get("atPrvAddrIndex");
          bwrSubNodePosition = StringSupport.changeStringToInt( bwrSubNodePosStr );
          //general.errLog("bwrSubNodePosition: "+bwrSubNodePosition,"PrvAddrNode.log");
        }
        else
        {
          // is add
          //
          isAdd = true;

          //String startDate = (String) prvAddrHash.get("atPrvAddrStDt");
          //String endDate   = (String) prvAddrHash.get("atPrvAddrEndDt");
          //if (startDate != null && endDate != null)
          //{
            //if( DateUtility.beforeWithSlashDate(startDate, endDate) )
            //{
              // date processing error
              //
            //}
          //}
        }

        //general.errLog("if (isAdd): "+(isAdd),"PrvAddrNode.log");

        if (isAdd)
        {
          bwrSubNode = sdo.createDataNode(username, NodeUtils.BWR_PRV_ADD_DN_TYPE);
          bwrSubNode.setFieldData(username, prvAddrHash);
          bwrNode.addReference(bwrSubNode);
        }
        else
        {
          bwrSubNode = bwrNode.getReference(NodeUtils.BWR_PRV_ADD_DN_TYPE, bwrSubNodePosition);
          //general.errLog("bwrSubNode: "+bwrSubNode,"PrvAddrNode.log");

          if( bwrSubNode == null )
          {
            throw new Exception("Unable to update borrowers previous address node: Unable to locate selected node.");
          }

          if( action != null && action.trim().toLowerCase().equals("delete"))
          {
            //general.errLog("DELETE NODE: ","PrvAddrNode.log");
            bwrSubNode.delete();
          }
          else
          {
            //general.errLog("UPDATE NODE: prvAddrHash: "+prvAddrHash,"PrvAddrNode.log");
            bwrSubNode.setFieldData(username, prvAddrHash);
          }
        }
      }
    }

    //general.errLog("End setupBwrPrvAddrNode( SystemDataObject sdo, int bwrNodePosition, String username, HashtableX prvEmpHash )","PrvAddrNode.log");
  }


  // String liREOD = getAssociatedPropertyIndexRE(sdo, liReod);
  public static String getAssociatedPropertyIndexRE( DataNode appNode, String liReod )
  {
    //general.errLog("START getAssociatedPropertyIndexRE( DataNode appNode, String liReod )","GetAssocProp.log");
    //general.errLog("liReod: "+liReod,"GetAssocProp.log");

    String indexStr = null;
    DataNode assetNode = appNode.getFirstReference(NodeUtils.AST_DN_TYPE);

    if (assetNode != null)
    {

      VectorX reColList = assetNode.getEffectiveReferences(NodeUtils.AST_RE_DN_TYPE);
      //general.errLog("reColList: " + reColList, "GetAssocProp.log");

      if (reColList != null && !reColList.isEmpty())
      {
        for (int i = 0, c = reColList.size(); i < c; i++)
        {
          // phyAddr
          DataNode colDN = (DataNode) reColList.get(i);
          //general.errLog("col fld data: " + colDN.getFieldData(""), "GetAssocProp.log");

          String colLiREOD = (String) colDN.getFieldData(CSFieldValues.EMPTY_STRING, "astAddr");
          //general.errLog("colLiREOD: " + colLiREOD, "GetAssocProp.log");

          //general.errLog("if( colLiREOD != null && colLiREOD.trim().toLowerCase().equals( liReod.trim().toLowerCase() ) ): " + (colLiREOD != null && colLiREOD.trim().toLowerCase().equals(liReod.trim().toLowerCase())), "GetAssocProp.log");
          if (colLiREOD != null && colLiREOD.trim().toLowerCase().equals(liReod.trim().toLowerCase()))
          {
            int index = colDN.getIndex();
            //general.errLog("index: " + index, "GetAssocProp.log");

            indexStr = String.valueOf(index);
            break;
          }
        }
      }
    }
    //general.errLog("return indexStr: "+indexStr,"GetAssocProp.log");
    //general.errLog("END getAssociatedPropertyIndexRE( DataNode appNode, String liReod )","GetAssocProp.log");

    return indexStr;
  }

  public static void getProgramDefaultData( GenericProduct product, HashtableX appData, DataNode appDN  ) throws Exception
  {
    //S1Log.getLogInstance().log("START getProgramDefaultData( Map appData, String APP_TYPE )", LOG_FILE);

    if( appData != null && ! appData.isEmpty() )
    {
      String branchId = (String)appData.get(CSFieldNames.FN_BRANCH_ID);
      //S1Log.getLogInstance().log("branchId: "+branchId, LOG_FILE);

      int branch = StringSupport.strToInt(branchId);
      //S1Log.getLogInstance().log("branch: "+branch, LOG_FILE);

      String productID   = null;
      String anProgTypeD = null;

      productID = (String) appData.get("anProdTypeD");
      //S1Log.getLogInstance().log("productID: " + productID, LOG_FILE);

      try
      {
       String prdQTLCode = ((MtgProduct)product).getPrdQTLCode();
       appData.put("anQTLCdD", DataEntrySupport.getRefreshedQTLCodes(branch, prdQTLCode));

       String prdCollOff = ((MtgProduct)product).getDfltCollOfficer();
       appData.put("anColOffD", prdCollOff);

       //S1Log.getLogInstance().log("if( ! appData.containsKey( CSFieldNames.FN_PROGRAM_ID ) ): " + ( ! appData.containsKey( CSFieldNames.FN_PROGRAM_ID ) ), LOG_FILE);
       if( appData.containsKey( CSFieldNames.FN_PROGRAM_ID ) )
       {
         anProgTypeD = (String)appData.get( CSFieldNames.FN_PROGRAM_ID );
         //S1Log.getLogInstance().log("anProgTypeD: " + anProgTypeD, LOG_FILE);

         if( anProgTypeD != null && anProgTypeD.trim().length() > 0 )
         {
           Program program = CSDataCache.getProgramManager().getProgram( anProgTypeD );
           if( program != null )
           {
             // default interest only
             appData.put(CSFieldNames.FN_IS_INT_ONLY, String.valueOf(program.getPgIntC()));
             appData.put(CSFieldNames.FN_INT_ONLY_NUM_PMT, String.valueOf(program.getPgInt()));

             // default term & amort term
             //S1Log.getLogInstance().log(CSFieldNames.FN_AMORT_PRD+": " + program.getpgAmortTerm(), LOG_FILE);
             //S1Log.getLogInstance().log(CSFieldNames.FN_NUM_PMT+": " + program.getPgTerm(), LOG_FILE);
             //S1Log.getLogInstance().log(CSFieldNames.FN_NUM_INT_PMT+": " + program.getPgInt(), LOG_FILE);

             appData.put(CSFieldNames.FN_AMORT_PRD, String.valueOf(program.getpgAmortTerm()));
             appData.put(CSFieldNames.FN_NUM_PMT, String.valueOf(program.getPgTerm()));
             appData.put(CSFieldNames.FN_NUM_INT_PMT, String.valueOf(program.getPgInt()));

             // doug add program init cap so this value can be added to the interest rate in order
             // to determine the qualifying rate (anIntRateQual)
             //
             appData.put("anPgInitCap", String.valueOf( program.getPgInitCap() ));

             VectorX intAccrualPrgVec = program.getIntAccrual();
             if( intAccrualPrgVec != null && ! intAccrualPrgVec.isEmpty() )
             {
               String accruelIntCalcMethPrg = (String) intAccrualPrgVec.firstElement();
               //S1Log.getLogInstance().log("accruelIntCalcMethPrg: " + accruelIntCalcMethPrg, LOG_FILE);

               // accruel interest calculation method
               //
               if( accruelIntCalcMethPrg != null && accruelIntCalcMethPrg.length() > 0 )
               {
                 // approved credit terms set anIntAccD to first value from the from product
                 //
                 appData.put(CSFieldNames.FN_INT_ACCRUAL, accruelIntCalcMethPrg);
               }
             }

             VectorX intPmtTypeVec = program.getPymtTypesSel();
             if( intPmtTypeVec != null && ! intPmtTypeVec.isEmpty() )
             {
               String intPmtTypePrg = (String) intPmtTypeVec.firstElement();
               //S1Log.getLogInstance().log("intPmtTypePrg: " + intPmtTypePrg, LOG_FILE);

               // accruel interest calculation method
               //
               if( intPmtTypePrg != null && intPmtTypePrg.length() > 0 )
               {
                 // approved credit terms set anIntAccD to first value from the from product
                 //
                 appData.put(CSFieldNames.FN_PMT_TYPE, intPmtTypePrg);
                 CSUtil.translatePmtType( (String)appData.get( CSFieldNames.FN_PMT_TYPE ), appData );
               }
             }

             VectorX intPmtPrdVecPrg = program.getPymtPrdSel();
             if( intPmtPrdVecPrg != null && ! intPmtPrdVecPrg.isEmpty() )
             {
               String intPmtPrdPrg = (String) intPmtPrdVecPrg.firstElement();
               //S1Log.getLogInstance().log("intPmtPrdPrg: " + intPmtPrdPrg, LOG_FILE);

               // accruel interest calculation method
               //
               if( intPmtPrdPrg != null && intPmtPrdPrg.length() > 0 )
               {
                 // approved credit terms set anIntAccD to first value from the from product
                 //
                 appData.put(CSFieldNames.FN_PMT_PRD, intPmtPrdPrg);
               }
             }

             String rtTypeR = program.getPgAmortR();

             if (rtTypeR != null)
             {
               if (rtTypeR.equals("0"))
               {
               //appData.put("anRtTypR", "Fixed");
               appData.put(CSFieldNames.FN_RT_TYPE, "Fixed");

               //amortization type
               appData.put("anAmortTypD", "Fixed Rate");
               }
               else
               {
                 //appData.put("anRtTypR", "Variable");
                 appData.put(CSFieldNames.FN_RT_TYPE, "Variable");

                 //amortization type
                 appData.put("anAmortTypD", "ARM");

                 if (program.getPgIdx() != null)
                 {
                   appData.put( "anIdxD", program.getPgIdx() );
                 }
               }
             }

             // credit and disability insurance
             //
             try
             {
               String crdtLife = (String)appData.get("anCLifeInsD");
               if( crdtLife != null && crdtLife.trim().length() > 0 && ! crdtLife.trim().toLowerCase().equals("none") )
               {
                 if( program.getCInsC() )
                 {
                   VectorX vec = (VectorX) program.getCInsM();
                   if( vec != null && ! vec.isEmpty() )
                   {
                     // "anCLifeInsTypD"
                     //
                     String insPlan = (String)vec.firstElement();
                     if( insPlan != null && insPlan.trim().length() > 0 )
                     {
                       if( insPlan != null && insPlan.startsWith("*") )
                       {
                         insPlan = StringSupport.removeEmbeddedString(insPlan, "*");
                       }

                       appData.put(CSFieldNames.FN_CINS_TYPE, insPlan);
                     }
                   }
                 }
               }

               String ahIns = (String)appData.get("anAHInsD");
               if( ahIns != null && ahIns.trim().length() > 0  && ! ahIns.trim().toLowerCase().equals("none") )
               {
                 if( program.getAHInsC() )
                 {
                   VectorX vec = (VectorX) program.getAHInsM();
                   if( vec != null && ! vec.isEmpty() )
                   {
                     // "anAHInsTypD"
                     //
                     String insPlan = (String)vec.firstElement();
                     if( insPlan != null && insPlan.trim().length() > 0 )
                     {
                        if( insPlan != null && insPlan.startsWith("*") )
                        {
                          insPlan = StringSupport.removeEmbeddedString(insPlan, "*");
                        }

                        appData.put(CSFieldNames.FN_CINS_AH_TYPE, insPlan);
                     }
                   }
                 }
               }
             }
             catch( Exception eee )
             {
               eee.printStackTrace();
               //S1Log.getLogInstance().log("An error occurred while processing the credit and disability insurance. Product Id: " + productID + " Program Id: "+anProgTypeD+" Error: "+eee.getMessage(), LOG_FILE);
             }

             try
             {
               DataNode mtgInsDN = MGUtils.getMortgageInsuranceNode( appDN );
               String escMIPmtPlansD = (String)mtgInsDN.getFieldData(CSFieldValues.EMPTY_STRING, CSFieldNames.FN_ESCROW_MI_PMT_PLANS_D);
               //S1Log.getLogInstance().log("escMIPmtPlansD: "+escMIPmtPlansD, LOG_FILE);

               String prgMIPD = program.getDefMIPD();
               //S1Log.getLogInstance().log("prgMIPD: "+prgMIPD, LOG_FILE);
               if( prgMIPD != null && prgMIPD.trim().length() > 0 )
               {
                 mtgInsDN.setFieldData(CSFieldValues.EMPTY_STRING, CSFieldNames.FN_ESCROW_MI_PMT_PLANS_D, prgMIPD);
               }
             }
             catch( Exception u )
             {
               u.printStackTrace();
               //S1Log.getLogInstance().log("An error occurred while updating the Mtg Ins Payment Plan: Program Id: "+anProgTypeD+" Error: "+u.getMessage(), LOG_FILE);
             }
           }
         }
       }
      }
      catch( Exception p )
      {
        p.printStackTrace();
        //S1Log.getLogInstance().log("An error occurred while loading the mortgage product program id for this product. Product Id: " + productID + " Error: "+p.getMessage(), LOG_FILE);
      }
    }
    else
    {
      throw new Exception("Cannot load product data. Invalid application data table.");
    }

    //S1Log.getLogInstance().log("END getProgramDefaultData( Map appData, String APP_TYPE )", LOG_FILE);
  } // getProductDefaultData( GenericProduct product, HashtableX appData, boolean APP_TYPE_CONSUMER, boolean APP_TYPE_MORTGAGE, boolean PROD_CHNGD_IN_EDIT ) throws Exception

  public static double[] getLienPayOffAmtAndLienTtlPurchPayOff( DataNode appNode )
  throws Exception
  {
    //S1Log.getLogInstance().log("START getLienPayOffAmtAndLienTtlPurchPayOff(...)", LOG_FILE);

    double lienPOAmt = 0.00;
    double lienTttlPurchPO = 0.00;
    double payOffCount = 0.0;
    double payOffPurchaseCount = 0.0;

    DataNode liabNode = appNode.getFirstReference( NodeUtils.LB_DN_TYPE );
    if( liabNode != null && ! liabNode.isDeleted() )
    {
      List liabList = liabNode.getEffectiveReferences( NodeUtils.LB_DN_TYPE );
      if(liabList != null && ! liabList.isEmpty() )
      {
        for (int i=0,c=liabList.size(); i<c; i++)
        {
          DataNode lbDN = (DataNode)liabList.get(i);

          // application:Liability.0:Liability.0:liTypD = Mortgage
          //
          String liTypD = (String)lbDN.getFieldData(CSFieldValues.EMPTY_STRING, "liTypD");
          String liPayOffC = (String)lbDN.getFieldData(CSFieldValues.EMPTY_STRING, "liPayOffC");

          if( liTypD != null && liPayOffC != null && liTypD.trim().equals("Mortgage") && liPayOffC.trim().equals("true") )
          {
            String liVal = (String)lbDN.getFieldData(CSFieldValues.EMPTY_STRING, "liVal");
            if( liVal != null && liVal.trim().length() > 0 )
            {
              double liValDbl = StringSupport.strToDouble( liVal );

              lienPOAmt += liValDbl;
              payOffCount += 1.0;

              String liPurchC = (String)lbDN.getFieldData(CSFieldValues.EMPTY_STRING, "liPurchC");
              if( liPurchC != null && liPurchC.trim().equals("true") )
              {
                lienTttlPurchPO += liValDbl;

                payOffPurchaseCount += 1.0;
              }
            }
          }
        }
      }
    }

    //S1Log.getLogInstance().log("lienPOAmt: "+lienPOAmt, LOG_FILE);
    //S1Log.getLogInstance().log("lienTttlPurchPO: "+lienTttlPurchPO, LOG_FILE);
    //S1Log.getLogInstance().log("END getLienPayOffAmtAndLienTtlPurchPayOff(...)", LOG_FILE);

    return new double[] { lienPOAmt, lienTttlPurchPO, payOffCount, payOffPurchaseCount };
  }


  public static String updateMtgTransactionType( double[] lienAmounts, DataNode appNode ) throws Exception
  {
    //general.errLog("START updateMtgTransactionType(...)", "UpdateMtgTransTyp.log");

    String anGETransTypD = "23";
    //general.errLog("Default - anGETransTypD: "+anGETransTypD, "UpdateMtgTransTyp.log");

    double lienPOAmt = lienAmounts[0];
    //general.errLog("lienPOAmt: "+lienPOAmt, "UpdateMtgTransTyp.log");

    double lienTttlPurchPO = lienAmounts[1];
    //general.errLog("lienTttlPurchPO: "+lienTttlPurchPO, "UpdateMtgTransTyp.log");

    double payOffCount = lienAmounts[2], payOffPurchaseCount = lienAmounts[3];
    //general.errLog("payOffCount: "+payOffCount, "UpdateMtgTransTyp.log");
    //general.errLog("payOffPurchaseCount: "+payOffPurchaseCount, "UpdateMtgTransTyp.log");

    String anLoanAmt = (String)appNode.getFieldData( CSFieldValues.EMPTY_STRING, CSFieldNames.FN_LOAN_AMT);
    //general.errLog("anLoanAmt: "+anLoanAmt, "UpdateMtgTransTyp.log");

    double anLoanAmtDbl = 0.00;

    if( anLoanAmt != null && anLoanAmt.trim().length() > 0 )
    {
      anLoanAmtDbl = StringSupport.strToDouble( anLoanAmt );
    }

    // ONLY USE LOAN AMOUNT - CKD - 6-7-10
    //
    //String anOldReq = (String)appNode.getFieldData( CSFieldValues.EMPTY_STRING, "anOldReq");
    //general.errLog("anOldReq: "+anOldReq, "UpdateMtgTransTyp.log");
    //double anOldReqDbl = 0.00;
    //if( anOldReq != null && anOldReq.trim().length() > 0 )
    //{
    //  anOldReqDbl = StringSupport.strToDouble( anOldReq );
    //}

    String tempWfeClsCst = (String)appNode.removeSystemData("!wfeClsCst");
    //general.errLog("tempWfeClsCst: "+tempWfeClsCst, "UpdateMtgTransTyp.log");

    String anTtlCostAmt = (String)appNode.getFieldData( CSFieldValues.EMPTY_STRING, "anTtlCostAmt");
    //general.errLog("anTtlCostAmt: "+anTtlCostAmt, "UpdateMtgTransTyp.log");

    double anTtlCostAmtDbl = 0.00;

    if( tempWfeClsCst != null && tempWfeClsCst.trim().length() > 0 )
    {
      // subtract lien payoff
      //
      anTtlCostAmtDbl = StringSupport.strToDouble( tempWfeClsCst );
    }
    else if( anTtlCostAmt != null && anTtlCostAmt.trim().length() > 0 )
    {
      anTtlCostAmtDbl = ( StringSupport.strToDouble( anTtlCostAmt ) - lienPOAmt );
    }

    /*
     [FNMA Transactions]
     !!_BLANK=!!_BLANK
     10=Purchase
     20=Refinance - No Cash Out
     21=Refinance - Home Improvement
     22=Refinance - Cash Out Debt Consolidation
     23=Refinance - Cash Out Limited
     24=Refinance - Cash Out Other
     30=Construction Only
     31=Construction to Permanent
     40=Other
    */

    //general.errLog("if( (payOffCount > 1) && (payOffCount != payOffPurchaseCount) ): "+( (payOffCount > 1) && (payOffCount != payOffPurchaseCount) ), "UpdateMtgTransTyp.log");
    //general.errLog("else if( anLoanAmtDbl > 100000.00 ): "+( anLoanAmtDbl > 100000.00 ), "UpdateMtgTransTyp.log");
    //general.errLog("else if( (anOldReqDbl - lienPOAmt) > (anOldReqDbl * .02) ): "+( (anOldReqDbl - lienPOAmt) > (anOldReqDbl * .02) ), "UpdateMtgTransTyp.log");
    //general.errLog("else if( (anLoanAmtDbl - lienPOAmt) > (anLoanAmtDbl * .02) ): "+( (anLoanAmtDbl - lienPOAmt) > (anLoanAmtDbl * .02) ), "UpdateMtgTransTyp.log");

    if( (payOffCount > 1) && (payOffCount != payOffPurchaseCount) )
    {
      // cash out refi ???
      //
      anGETransTypD = "24";
    }
    else if( anLoanAmtDbl > 100000.00 )
    {
      // if( ((anOldReqDbl - lienPOAmt) - anTtlCostAmtDbl) > 2000.00 )
      //
      if( ((anLoanAmtDbl - lienPOAmt) - anTtlCostAmtDbl) > 2000.00 )
      {
        // cash our refi ???
        //
        anGETransTypD = "24";
      }
    }
    // else if( ((anOldReqDbl - lienPOAmt) - anTtlCostAmtDbl) > (anOldReqDbl * .02) )
    //
    else if( ((anLoanAmtDbl - lienPOAmt) - anTtlCostAmtDbl) > (anLoanAmtDbl * .02) )
    {
      // cash our refi ???
      //
      anGETransTypD = "24";
    }

    //general.errLog("return anGETransTypD: "+anGETransTypD, "UpdateMtgTransTyp.log");
    //general.errLog("END updateMtgTransactionType(...)", "UpdateMtgTransTyp.log");

    return anGETransTypD;
  } //  public static void updateMtgTransactionType( ... )

  public static void calculateEscrowValuesForMtg( DataNode appNode, HashtableX escrowData, HashtableX collData, boolean isPurchase  )
  {
    general.errLog("START calculateEscrowValuesForMtg(...)","CalcEscNode.log");
    general.errLog("escrowData: "+escrowData,"CalcEscNode.log");
    general.errLog("collData: "+collData,"CalcEscNode.log");
    general.errLog("isPurchase: "+isPurchase,"CalcEscNode.log");

    String loanFirstPmtDt = (String)appNode.getFieldData( CSFieldValues.EMPTY_STRING, CSFieldNames.FN_1ST_PMT_DT);
    general.errLog("loanFirstPmtDt: "+loanFirstPmtDt,"CalcEscNode.log");

    //String disbPmtDt = (String)appNode.getFieldData( CSFieldValues.EMPTY_STRING, CSFieldNames.FN_DISBURSE_DATE);
    //general.errLog("disbPmtDt: "+disbPmtDt,"CalcEscNode.log");

    String reEstVal = (String)collData.get("phyValEst");
    general.errLog("1 reEstVal: "+reEstVal,"CalcEscNode.log");

    if( reEstVal == null || reEstVal.trim().length() == 0 )
    {
      reEstVal = (String) collData.get("phyValAprsl");
      general.errLog("2 reEstVal: " + reEstVal, "CalcEscNode.log");

      if( reEstVal == null || reEstVal.trim().length() == 0 )
      {
        reEstVal = (String)collData.get("phyPrchPrc");
        general.errLog("3 reEstVal: "+reEstVal,"CalcEscNode.log");
      }
    }

    String state = (String)collData.get("phyStD");
    String county = (String)collData.get("phyCntyD");
    
    general.errLog("state: "+state,"CalcEscNode.log");
    general.errLog("county: "+county,"CalcEscNode.log");
    general.errLog("4 reEstVal: "+reEstVal,"CalcEscNode.log");

    double propValue = StringSupport.strToDouble( reEstVal );
    general.errLog( "reEstVal to dbl = propValue "+propValue,"CalcEscNode.log" );

    if( isValidString( loanFirstPmtDt ) )
    {
      String currYr = String.valueOf( DateUtility.extractYearFromSlashDate( loanFirstPmtDt ) );
      general.errLog( "currYr: "+currYr,"CalcEscNode.log" );

      String currYrPlusOne = String.valueOf( StringSupport.strToInt(currYr) + 1 );
      general.errLog( "currYrPlusOne: "+currYrPlusOne,"CalcEscNode.log" );

      String propTaxDay = DBQueries.getStateOrCountyTaxMonthDay(state, county);
      general.errLog( "propTaxDay:"+propTaxDay,"CalcEscNode.log" );

// added check for empty string       
      if (propTaxDay == null || propTaxDay.trim().length() == 0)
      {
        propTaxDay = "03/01";
      }

      String escDisDtPrpTx  = propTaxDay + "/" +currYr;
      String escDisDtPrpTxPlusOne  = propTaxDay + "/" + currYrPlusOne;

      general.errLog( "escDisDtPrpTx: "+escDisDtPrpTx,"CalcEscNode.log" );
      general.errLog( "escDisDtPrpTxPlusOne: "+escDisDtPrpTxPlusOne,"CalcEscNode.log" );

      // same date for now
      //
      // String escDisDtSchTx  = "08/01/"+currYr;
      // String escDisDtHazIns = "08/01/"+currYr;
      //

      String schTaxDay = DBQueries.getStateOrCountySchoolTaxMonthDay(state, county);
      general.errLog( "schTaxDay:"+schTaxDay,"CalcEscNode.log" );

// added check for empty string       
      if (schTaxDay == null || schTaxDay.trim().length() == 0)
      {
        schTaxDay = "08/01";
      }
      String escDisDtSchTx  = schTaxDay + "/" +currYr;
      String escDisDtSchTxPlusOne  = schTaxDay + "/" +currYrPlusOne;


      String hzInsDay = DBQueries.getStateOrCountyInsMonthDay(state, county);
      general.errLog( "hzInsDay: "+hzInsDay,"CalcEscNode.log" );
      
// added check for empty string       
      if (hzInsDay == null || hzInsDay.trim().length() == 0)
      {
        hzInsDay = "08/01";
      }
      String escDisDtHazIns  = hzInsDay + "/" +currYr;
      String escDisDtHazInsPlusOne  = hzInsDay + "/" +currYrPlusOne;

      general.errLog( "escDisDtHazIns: "+escDisDtHazIns,"CalcEscNode.log" );
      general.errLog( "escDisDtHazInsPlusOne: "+escDisDtHazInsPlusOne,"CalcEscNode.log" );

      if( ! escrowData.containsKey("esc1stPmtDt") )
      {
        escrowData.put( "esc1stPmtDt", loanFirstPmtDt );
      }

      Date lnFrstPmtDt = DateUtility.assignSlashDateToJavaDate(loanFirstPmtDt);
      general.errLog( "lnFrstPmtDt: "+lnFrstPmtDt,"CalcEscNode.log" );

      String estimateEscInsAndTax = (String)escrowData.get("escEstInsAmt");
      general.errLog( "estimateEscInsAndTax: "+estimateEscInsAndTax,"CalcEscNode.log" );

      boolean estTaxAndInsAmts = ( estimateEscInsAndTax != null && estimateEscInsAndTax.trim().toLowerCase().equals("yes") );
      general.errLog( "estTaxAndInsAmts: "+estTaxAndInsAmts,"CalcEscNode.log" );

      BusinessConfig bc = null;

      String branchId = (String)appNode.getFieldData(CSFieldValues.EMPTY_STRING,
                                                     CSFieldNames.FN_BRANCH_ID);

      if (branchId == null)
      {
        bc = BusinessConfig.getBusinessConfig();
      }
      else
      {
        bc = BusinessConfig.getBusinessConfig(StringSupport.strToInt(branchId));
      }

      int numResrvMos = bc.getMGCalcEscMths();
      String resrvMos = null;

      String escType  = (String)escrowData.get("escTypD");

      if( escType != null && escType.trim().toLowerCase().equals("property taxes") )
      {
        Date pTxDt = DateUtility.assignSlashDateToJavaDate(escDisDtPrpTx);
        general.errLog( "pTxDt: "+pTxDt,"CalcEscNode.log" );

        if( lnFrstPmtDt.before(pTxDt) )
        {
            resrvMos = String.valueOf(numResrvMos +  (11 - DateUtility.diffMonthsUsingSlashDates( loanFirstPmtDt, escDisDtPrpTx )) );
            general.errLog( "1 PROPERTY resrvMos: "+resrvMos,"CalcEscNode.log" );

            //if( ! escrowData.containsKey("escNoRsvMths") )
            //{
            //  escrowData.put( "escNoRsvMths", String.valueOf( resrvMos ) );
            //  escrowData.put( "escMths", String.valueOf( resrvMos ) );
            //}

            escrowData.put( "escDt", escDisDtPrpTx );
        }
        else
        {
          resrvMos = String.valueOf( (numResrvMos +  11 - DateUtility.diffMonthsUsingSlashDates( loanFirstPmtDt, escDisDtPrpTxPlusOne )) );
          general.errLog( "2 PROPERTY resrvMos: "+resrvMos,"CalcEscNode.log" );

          escrowData.put( "escDt", escDisDtPrpTxPlusOne );
        }

        // ckd 3-23-10, move from above and remove if, brilliant...
        //
        escrowData.put( "escNoRsvMths", String.valueOf(numResrvMos));
        escrowData.put( "escMths", String.valueOf( resrvMos ) );

        general.errLog( "if( estTaxAndInsAmts ): "+( estTaxAndInsAmts ),"CalcEscNode.log" );
        if( estTaxAndInsAmts )
        {
          double propTax = MGCalcEstimator.getPropertyTaxesMonthlyCharge(
                                           propValue, state, county);

          if( propTax > 0 )
          {
            escrowData.put( "escMonPmt", String.valueOf( FinCalcs.round( propTax, 2 ) ) );

            double annualPropTax = FinCalcs.round( (propTax * 12), 2);
            general.errLog("annualPropTax: " + annualPropTax,"CalcEscNode.log");

            escrowData.put( "escAmt", String.valueOf( annualPropTax ) );

            // reserve settlement value = escDueAmt
            //
            double resrvMosDbl = StringSupport.strToDouble( resrvMos );

            if( resrvMosDbl > 0 )
            {
              double escDueAmt = FinCalcs.round( (propTax * resrvMosDbl), 2);
              general.errLog("PROPERTY settlement escDueAmt: " + escDueAmt,"CalcEscNode.log");

              escrowData.put("escDueAmt", String.valueOf(escDueAmt));
            }
          }
        }
        else
        {
          // need to get the value for the escMonPmt
          // escrowData: {escEstInsAmt=No, escAmt=1001, escC=true, escPmtPrdD=1, escTypD=Hazard Insurance}
          //
          String escAmtStr = (String) escrowData.get("escAmt");
          if( escAmtStr != null && escAmtStr.trim().length() > 0 )
          {
            double escAmtDbl = StringSupport.strToDouble(escAmtStr);
            double escMonPmt = FinCalcs.round( (escAmtDbl/12), 2);

            // escrowData.put("escMonPmt", String.valueOf(FinCalcs.round( (escAmtDbl/12), 2)));
            //
            escrowData.put("escMonPmt", String.valueOf(escMonPmt));

            // add ckd 2-25-10
            //
            double resrvMosDbl = StringSupport.strToDouble( resrvMos );

            if( resrvMosDbl > 0 && escAmtDbl > 0 )
            {
              // double escDueAmt = FinCalcs.round( (escAmtDbl * resrvMosDbl), 2);
              //
              double escDueAmt = FinCalcs.round( (escMonPmt * resrvMosDbl), 2);
              general.errLog("PROPERTY settlement escDueAmt: " + escDueAmt,"CalcEscNode.log");

              escrowData.put("escDueAmt", String.valueOf(escDueAmt));
            }
          }
        }
      }
      else if( escType != null && escType.trim().toLowerCase().equals("county taxes") )
      {
        Date pTxDt = DateUtility.assignSlashDateToJavaDate(escDisDtPrpTx);
        general.errLog( "pTxDt: "+pTxDt,"CalcEscNode.log" );

        if( lnFrstPmtDt.before(pTxDt) )
        {
            resrvMos = String.valueOf( (11 - DateUtility.diffMonthsUsingSlashDates( loanFirstPmtDt, escDisDtPrpTx )) );
            general.errLog( "1 PROPERTY resrvMos: "+resrvMos,"CalcEscNode.log" );

            //if( ! escrowData.containsKey("escNoRsvMths") )
            //{
            //  escrowData.put( "escNoRsvMths", String.valueOf( resrvMos ) );
            //  escrowData.put( "escMths", String.valueOf( resrvMos ) );
            //}

            escrowData.put( "escDt", escDisDtPrpTx );
        }
        else
        {
          resrvMos = String.valueOf(numResrvMos + (11 - DateUtility.diffMonthsUsingSlashDates( loanFirstPmtDt, escDisDtPrpTxPlusOne )) );
          general.errLog( "2 PROPERTY resrvMos: "+resrvMos,"CalcEscNode.log" );

          escrowData.put( "escDt", escDisDtPrpTxPlusOne );
        }

        // ckd 3-23-10, move from above and remove if, brilliant...
        //
        escrowData.put( "escNoRsvMths", String.valueOf(numResrvMos));
        escrowData.put( "escMths", String.valueOf( resrvMos ) );

        general.errLog( "if( estTaxAndInsAmts ): "+( estTaxAndInsAmts ),"CalcEscNode.log" );
        if( estTaxAndInsAmts )
        {
          double propTax = MGCalcEstimator.getPropertyTaxesMonthlyCharge(
                                            propValue, state, county);

          if( propTax > 0 )
          {
            escrowData.put( "escMonPmt", String.valueOf( FinCalcs.round( propTax, 2 ) ) );

            double annualPropTax = FinCalcs.round( (propTax * 12), 2);
            general.errLog("annualPropTax: " + annualPropTax,"CalcEscNode.log");

            escrowData.put( "escAmt", String.valueOf( annualPropTax ) );

            // reserve settlement value = escDueAmt
            //
            double resrvMosDbl = StringSupport.strToDouble( resrvMos );

            if( resrvMosDbl > 0 )
            {
              double escDueAmt = FinCalcs.round( (propTax * resrvMosDbl), 2);
              general.errLog("PROPERTY settlement escDueAmt: " + escDueAmt,"CalcEscNode.log");

              escrowData.put("escDueAmt", String.valueOf(escDueAmt));
            }
          }
        }
        else
        {
          // need to get the value for the escMonPmt
          // escrowData: {escEstInsAmt=No, escAmt=1001, escC=true, escPmtPrdD=1, escTypD=Hazard Insurance}
          //
          String escAmtStr = (String) escrowData.get("escAmt");
          if( escAmtStr != null && escAmtStr.trim().length() > 0 )
          {
            double escAmtDbl = StringSupport.strToDouble(escAmtStr);
            double escMonPmt = FinCalcs.round( (escAmtDbl/12), 2);

            // escrowData.put("escMonPmt", String.valueOf(FinCalcs.round( (escAmtDbl/12), 2)));
            //
            escrowData.put("escMonPmt", String.valueOf(escMonPmt));

            // add ckd 2-25-10
            //
            double resrvMosDbl = StringSupport.strToDouble( resrvMos );

            if( resrvMosDbl > 0 && escAmtDbl > 0 )
            {
              // double escDueAmt = FinCalcs.round( ((escAmtDbl/12) * resrvMosDbl), 2);
              //
              double escDueAmt = FinCalcs.round( (escMonPmt * resrvMosDbl), 2);
              general.errLog("PROPERTY settlement escDueAmt: " + escDueAmt,"CalcEscNode.log");

              escrowData.put("escDueAmt", String.valueOf(escDueAmt));
            }
          }
        }
      }
      else if( escType != null && escType.trim().toLowerCase().equals("school taxes") )
      {
        Date schlTxHazInsDt = DateUtility.assignSlashDateToJavaDate(escDisDtSchTx);
        general.errLog( "schlTxHazInsDt: "+schlTxHazInsDt,"CalcEscNode.log" );

        if( lnFrstPmtDt.before(schlTxHazInsDt) )
        {
          resrvMos = String.valueOf(numResrvMos +   (11 - DateUtility.diffMonthsUsingSlashDates(loanFirstPmtDt,escDisDtSchTx)) );
          general.errLog( "1 SCHOOL resrvMos: "+resrvMos,"CalcEscNode.log" );

          //if( ! escrowData.containsKey("escNoRsvMths") )
          //{
          //  escrowData.put( "escNoRsvMths", String.valueOf( resrvMos ) );
          //  escrowData.put( "escMths", String.valueOf( resrvMos ) );
          //}

          escrowData.put( "esc1stPmtDt", loanFirstPmtDt );
          escrowData.put( "escDt", escDisDtSchTx );
        }
        else
        {
          resrvMos = String.valueOf(numResrvMos +   (11 - DateUtility.diffMonthsUsingSlashDates( loanFirstPmtDt, escDisDtSchTxPlusOne )) );
          general.errLog( "2 SCHOOL resrvMos: "+resrvMos,"CalcEscNode.log" );

          escrowData.put( "escDt", escDisDtSchTxPlusOne );
        }

        // ckd 3-23-10, move from above and remove if, brilliant...
        //
        escrowData.put( "escNoRsvMths", String.valueOf(numResrvMos));
        escrowData.put( "escMths", String.valueOf( resrvMos ) );

        general.errLog( "if( estTaxAndInsAmts ): "+( estTaxAndInsAmts ),"CalcEscNode.log" );
        if( estTaxAndInsAmts )
        {
          double schlTax = MGCalcEstimator.getSchoolTaxesMonthlyCharge(
                                            propValue, state, county);
          if( schlTax > 0 )
          {
            escrowData.put( "escMonPmt", String.valueOf( FinCalcs.round( schlTax, 2 ) ) );

            double annualSchlTax = FinCalcs.round( (schlTax * 12), 2 );
            general.errLog( "annualSchlTax: "+annualSchlTax,"CalcEscNode.log" );

            escrowData.put( "escAmt", String.valueOf( annualSchlTax ) );

            // reserve settlement value = escDueAmt
            //
            double resrvMosDbl = StringSupport.strToDouble( resrvMos );

            if( resrvMosDbl > 0 )
            {
              double escDueAmt = FinCalcs.round( (schlTax * resrvMosDbl), 2);
              general.errLog("SCHOOL settlement escDueAmt: " + escDueAmt,"CalcEscNode.log");

              escrowData.put("escDueAmt", String.valueOf(escDueAmt));
            }
          }
        }
        else
        {
          // need to get the value for the escMonPmt
          // escrowData: {escEstInsAmt=No, escAmt=1001, escC=true, escPmtPrdD=1, escTypD=Hazard Insurance}
          //
          String escAmtStr = (String) escrowData.get("escAmt");
          if( escAmtStr != null && escAmtStr.trim().length() > 0 )
          {
            double escAmtDbl = StringSupport.strToDouble(escAmtStr);
            double escMonPmt = FinCalcs.round( (escAmtDbl/12), 2);

            // escrowData.put("escMonPmt", String.valueOf(FinCalcs.round( (escAmtDbl/12), 2)));
            //
            escrowData.put("escMonPmt", String.valueOf(escMonPmt));

            // add ckd 2-25-10
            //
            double resrvMosDbl = StringSupport.strToDouble( resrvMos );

            if( resrvMosDbl > 0 && escAmtDbl > 0 )
            {
              // double escDueAmt = FinCalcs.round( (escAmtDbl * resrvMosDbl), 2);
              //
              double escDueAmt = FinCalcs.round( (escMonPmt * resrvMosDbl), 2);
              general.errLog("PROPERTY settlement escDueAmt: " + escDueAmt,"CalcEscNode.log");

              escrowData.put("escDueAmt", String.valueOf((escDueAmt)));
            }
          }
        }
      }
      else if( escType != null && escType.trim().toLowerCase().equals("hazard insurance") )
      {
        general.errLog( "loanFirstPmtDt: "+loanFirstPmtDt,"CalcEscNode.log" );

        // going to run to the table and get the dates method given a first pmt date whether refinace
        // or purchase return the proper date. If refi roll 5 months. If purchase roll 11
        //
        //int monthsToBeCollected = 0;
        if( isPurchase )
        {
          //monthsToBeCollected = 2;
          escDisDtHazIns = DateUtility.getSlashDateNumMonthsAfter(loanFirstPmtDt, 11);
        }
        else
        {
          //monthsToBeCollected = 8;
          escDisDtHazIns = DateUtility.getSlashDateNumMonthsAfter(loanFirstPmtDt, 5);
        }

        general.errLog( "escDisDtHazIns: "+escDisDtHazIns,"CalcEscNode.log" );
        //general.errLog( "monthsToBeCollected: "+monthsToBeCollected,"CalcEscNode.log" );

        Date schlTxHazInsDt = DateUtility.assignSlashDateToJavaDate(escDisDtHazIns);
        general.errLog( "schlTxHazInsDt: "+schlTxHazInsDt,"CalcEscNode.log" );

        if( lnFrstPmtDt.before(schlTxHazInsDt) )
        {
          // just use the Refi months to be collected and purchase months to be collected
          //
          resrvMos = String.valueOf(numResrvMos +   (11 - DateUtility.diffMonthsUsingSlashDates(loanFirstPmtDt,escDisDtHazIns)) );
          //
          // resrvMos = String.valueOf( (monthsToBeCollected - DateUtility.diffMonthsUsingSlashDates(loanFirstPmtDt,escDisDtSchTxHazIns)) );
          //
          general.errLog( "3 PROPERTY resrvMos: "+resrvMos,"CalcEscNode.log" );
          general.errLog( "3 PROPERTY escDisDtHazIns: "+escDisDtHazIns,"CalcEscNode.log" );

          //if( ! escrowData.containsKey("escNoRsvMths") )
          //{
          //  escrowData.put( "escNoRsvMths", String.valueOf( resrvMos ) );
          //  escrowData.put( "escMths", String.valueOf( resrvMos ) );
          //}

          escrowData.put( "esc1stPmtDt", loanFirstPmtDt );
          escrowData.put( "escDt", escDisDtHazIns );
        }
        else
        {
          resrvMos = String.valueOf(numResrvMos +   (11 - DateUtility.diffMonthsUsingSlashDates( loanFirstPmtDt, escDisDtHazInsPlusOne )) );
          //
          // resrvMos = String.valueOf( (monthsToBeCollected - DateUtility.diffMonthsUsingSlashDates( loanFirstPmtDt, escDisDtSchTxHazInsPlusOne )) );
          //
          general.errLog( "3 PROPERTY resrvMos: "+resrvMos,"CalcEscNode.log" );
          general.errLog( "3 PROPERTY escDisDtHazInsPlusOne: "+escDisDtHazInsPlusOne,"CalcEscNode.log" );

          escrowData.put( "escDt", escDisDtHazInsPlusOne );
        }

        // ckd 3-23-10, move from above and remove if, brilliant...
        //
        escrowData.put( "escNoRsvMths", String.valueOf(numResrvMos));
        escrowData.put( "escMths", String.valueOf( resrvMos ) );

        general.errLog( "if( estTaxAndInsAmts ): "+( estTaxAndInsAmts ),"CalcEscNode.log" );
        if( estTaxAndInsAmts )
        {
          double hzrdIns = MGCalcEstimator.getHazardInsuranceMonthlyCharge(
                                            propValue, state, county);
          if( hzrdIns > 0 )
          {
            escrowData.put( "escMonPmt", String.valueOf( FinCalcs.round( hzrdIns, 2 ) ) );
          }

          double annualHzrdTax = FinCalcs.round( (hzrdIns * 12), 2 );
          general.errLog( "annualHzrdTax: "+annualHzrdTax,"CalcEscNode.log" );

          escrowData.put( "escAmt", String.valueOf( annualHzrdTax ) );

          // reserve settlement value = escDueAmt
          //
          double resrvMosDbl = StringSupport.strToDouble( resrvMos );

          if( resrvMosDbl > 0 )
          {
            double escDueAmt = FinCalcs.round( (hzrdIns * resrvMosDbl), 2);
            general.errLog("HAZARD settlement escDueAmt: " + escDueAmt,"CalcEscNode.log");

            escrowData.put("escDueAmt", String.valueOf(escDueAmt));
          }

        }
        else
        {
          // need to get the value for the escMonPmt
          // escrowData: {escEstInsAmt=No, escAmt=1001, escC=true, escPmtPrdD=1, escTypD=Hazard Insurance}
          //
          String escAmtStr = (String) escrowData.get("escAmt");
          if( escAmtStr != null && escAmtStr.trim().length() > 0 )
          {
            double escAmtDbl = StringSupport.strToDouble(escAmtStr);
            double escMonPmt = FinCalcs.round( (escAmtDbl/12), 2);

            // escrowData.put("escMonPmt", String.valueOf(FinCalcs.round( (escAmtDbl/12), 2)));
            //
             escrowData.put("escMonPmt", String.valueOf(escMonPmt));

            // add ckd 2-25-10
            //
            double resrvMosDbl = StringSupport.strToDouble( resrvMos );

            if( resrvMosDbl > 0 && escAmtDbl > 0 )
            {
              // double escDueAmt = FinCalcs.round( ((escAmtDbl/12) * resrvMosDbl), 2);
              //
              double escDueAmt = FinCalcs.round( (escMonPmt * resrvMosDbl), 2);
              general.errLog("PROPERTY settlement escDueAmt: " + escDueAmt,"CalcEscNode.log");

              escrowData.put("escDueAmt", String.valueOf(escDueAmt));
            }
          }
        }
      }
    } // if( isValidString( firstPmtDt ) )

    general.errLog("End calculateEscrowValuesForMtg(...)","CalcEscNode.log");
  }

  public static void removeLiensForWfE( DataNode appNode )
  {
    //general.errLog("START removeLiensForWfE( DataNode appNode ): ", "AstLiabSetUpDN.log");

    DataNode collateralNode = (DataNode) appNode.getFirstReference(NodeUtils.COLL_DN_TYPE);
    //general.errLog("if( collateralNode != null && ! collateralNode.isDeleted() ): " + (collateralNode != null && !collateralNode.isDeleted()), "AstLiabSetUpDN.log");

    if (collateralNode != null && !collateralNode.isDeleted())
    {
      // List collNodesList = collNodesList.addAll(collateralNode.getEffectiveReferences( NodeUtils.RE_DN_TYPE ));
      //
      List collNodesList = collateralNode.getEffectiveReferences(NodeUtils.RE_DN_TYPE);

      //general.errLog("if (collNodesList != null && !collNodesList.isEmpty()): " + (collNodesList != null && !collNodesList.isEmpty()), "AstLiabSetUpDN.log");
      if( collNodesList != null && !collNodesList.isEmpty() )
      {
        for (int x = 0, y = collNodesList.size(); x < y; x++)
        {
          DataNode colDN = (DataNode) collNodesList.get(x);
          //HashtableX clHT = colDN.getFieldData(CSFieldValues.EMPTY_STRING);
          //general.errLog("REMOVE LIENS clHT: " + clHT, "AstLiabSetUpDN.log");

          if (colDN != null && !colDN.isDeleted())
          {
            VectorX liens = colDN.getEffectiveReferences(NodeUtils.LIEN_DN_TYPE);
            //general.errLog("liens: " + liens, "AstLiabSetUpDN.log");

            for (int o = 0, p = liens.size(); o < p; o++)
            {
              DataNode lnDN = (DataNode) liens.get(o);
              HashtableX lnSysHT = lnDN.getSystemData();
              //general.errLog("liens: lnSysHT: " + lnSysHT, "AstLiabSetUpDN.log");

              String isWfeLien = (String) lnDN.getSystemData("!isWfeLien");
              //general.errLog("liens: if (isWfeLien != null && isWfeLien.trim().equals(CSFieldValues.TRUE_STRING)): " + (isWfeLien != null && isWfeLien.trim().equals(CSFieldValues.TRUE_STRING)), "AstLiabSetUpDN.log");
              if (isWfeLien != null && isWfeLien.trim().equals(CSFieldValues.TRUE_STRING))
              {
                lnDN.delete();
              }
            }
          }
        }
      }
    }

    //general.errLog("END removeLiensForWfE( DataNode appNode ): ", "AstLiabSetUpDN.log");

  } // public static void removeLiensForWfE( DataNode appNode )

  // acceptPAO
  //
  public static String acceptPAO( String username,  String paoProdId,
                                  String paoSSN, HashtableX inFieldsHash,
                                  boolean isSSN, SystemDataObject sdo  )
  throws Exception
  {
    //general.errLog("START  acceptPAO(...)", "PAO.log");

    HashtableX bwrHT = NodeUtils.extractDataHash(NodeUtils.BWR_DN_TYPE, inFieldsHash);   // 6-7-2010, CKD
    //general.errLog("bwrHT: "+bwrHT, "PAO.log");
    try
    {
      // updateAppAndBwrNode(sdo, paoProdId, paoSSN, username);   // 5-11-2010, ccl,   6-7-2010, CKD
      //
      paoProdId = updateAppAndBwrNode(sdo, paoProdId, paoSSN, username, isSSN, bwrHT);
    }
    catch (SQLException e)
    {
      e.printStackTrace();
      DBLogger.log("Accept Pre-approval offer error: " + e);
      throw new Exception("Accept Pre-approval offer error: " + e);
    }

    String newAppId = SDOUtils.getAppIDFromSDO(sdo, username);
    //general.errLog("newAppId: "+newAppId, "PAO.log");

    if (newAppId == null)
    {
      throw new Exception("Unable to obtain application id.");
    }

    // Save the new paoSDO data
    //
    try
    {
      SDOUtils.saveSDO(username, sdo, CSStatusCodes.SDO_UNLOCK);
      //general.errLog("SDOUtils.saveSDO(username, sdo, CSStatusCodes.SDO_UNLOCK)","PAO.log");
    }
    catch (SQLException e)
    {
      e.printStackTrace();
      throw new Exception("Unable to save application: " + newAppId +". Database error: " + e);
    }

    DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);

    String newRefId = (String) appNode.getFieldData(username, CSFieldNames.FN_APP_REF_ID);

    try
    {
      // accepted cross sell sdo in database is set to null. there shuld be no
      // need to load from the db table. can load from credisphere sdo directory
      //
      //DBQueries.updatePAO_DBTable(username, paoProdId, paoSSN,  false, true, newAppId, newRefId);

      //general.errLog("username: "+username,"PAO.log");
      //general.errLog("paoProdId: "+paoProdId,"PAO.log");
      //general.errLog("newAppId: "+newAppId,"PAO.log");
      //general.errLog("newRefId: "+newRefId,"PAO.log");
      //general.errLog("isSSN: "+isSSN,"PAO.log");
      DBQueries.updatePAO_DBTable(username, paoProdId, paoSSN,  false, true, newAppId, newRefId, isSSN);

      //general.errLog("DBQueries.updateAppXSellDBTable * EXECUTED *","PAO.log");
    }
    catch (SQLException e)
    {
      e.printStackTrace();
      DBLogger.log("FROM XML IMPORT: Update Pre-approval offer Table error: " + e);
      throw new Exception("FROM XML IMPORT: Update Pre-approval offer Table error: " + e);
    }

    //general.errLog("return newAppId: "+newAppId, "PAO.log");
    //general.errLog("END  acceptPAO(...)", "PAO.log");

    return newAppId;
  } // acceptPAO

  // updateAppAndBwrNode
  //
  // updateAppAndBwrNode
  //
  private static String getPAOData(String paoProdId,
                                          String paoSSN, boolean isSSN,
                                          HashtableX bwrFields,
                                          HashtableX appFields ) throws Exception, SQLException
  {
    //general.errLog("START updateAppAndBwrNode(...)", "AcceptPOA.log");

    boolean found = false;
    String acceptedProductId = null;
    Statement stmt = null;
    StringBuffer selectStmt = new StringBuffer();

    if (isSSN)
    {
      selectStmt.append("SELECT * FROM xntPreApprovalOffers WHERE nProdId='");
      selectStmt.append(paoProdId).append("' AND cSSN='").append(paoSSN).
          append("' AND (dtExpire is NULL or dtExpire > getDate())");
      selectStmt.append(" UNION SELECT * FROM xntPreApprovalOffers WHERE nProdId!=");
            selectStmt.append(paoProdId).append(" AND cSSN='").append(paoSSN).
          append("' AND (dtExpire is NULL or dtExpire > getDate())");
    }
    else
    {
      selectStmt.append("SELECT * FROM xntPreApprovalOffers WHERE nProdId=");
      selectStmt.append(paoProdId).append(" AND cCif='").append(paoSSN).
          append("' AND (dtExpire is NULL or dtExpire > getDate())");
      selectStmt.append(" UNION SELECT * FROM xntPreApprovalOffers WHERE nProdId != '");
      selectStmt.append(paoProdId).append(" AND cCif='").append(paoSSN).
          append("' AND (dtExpire is NULL or dtExpire > getDate())");

    }

    try
    {
      Connection con = DBConnPool.getConnection();
      stmt = con.createStatement();
      ResultSet rs = stmt.executeQuery(selectStmt.toString());

      String str = null;

      while (rs.next() && !found)
      {
        acceptedProductId = String.valueOf(rs.getInt("nProdId"));

        found = acceptedProductId == paoProdId ||
                CSUtil.isPAOProductEquivalent(paoProdId, acceptedProductId);

        if (found)
        {
          // get borrower's information
          //
          str = rs.getString("bAccept");
          if (str != null && str.equals("a")) {
            // already accepted skip other collection
            appFields.put("bAccept", str);
            found = false;
            continue;
          }
          else {
            appFields.remove("bAccept");
          }

          str = rs.getString("cFName");
          if (str != null) bwrFields.put(CSFieldNames.FN_F_NAME, str.trim());

          str = rs.getString("cLName");
          if (str != null) bwrFields.put(CSFieldNames.FN_L_NAME, str.trim());

          str = rs.getString("cSSN");
          if (str != null) bwrFields.put(CSFieldNames.FN_SSN, str.trim());

          str = rs.getString("cCif");
          if (str != null) bwrFields.put(CSFieldNames.FN_BWR_CIF, str.trim());

          // split the address and put them into eaxh individual field
          //
          str = rs.getString("cAddr");
          if (str != null) {
            AppImportUtils.parseAddressLine(str, bwrFields, true);
          }

          str = rs.getString("cAddrTwo");
          if (str != null) bwrFields.put(CSFieldNames.FN_BWR_ADDR_TWO, str.trim());

          str = rs.getString("cCity");
          if (str != null) bwrFields.put(CSFieldNames.FN_BWR_CITY, str.trim());

          str = rs.getString("cSt");
          if (str != null) bwrFields.put(CSFieldNames.FN_BWR_STATE, str.trim());

          str = rs.getString("cZip");
          if (str != null) bwrFields.put(CSFieldNames.FN_BWR_ZIP, str.trim());

          // get score for creating report node
          //
          str = rs.getString("cRiskScore");
          if (str != null) {
            bwrFields.put(CSFieldNames.FN_BWR_RSK_SCORE, str.trim());
          }

          str = rs.getString("cBnkScore");
          if (str != null) {
            bwrFields.put(CSFieldNames.FN_BWR_BNK_SCORE, str.trim());
          }

          // get application data
          //

          appFields.put(CSFieldNames.FN_PRODUCT_ID, paoProdId); // anProdTypeD
          appFields.put(CSFieldNames.FN_INT_RATE,
                        String.valueOf(rs.getDouble("fIntRate"))); // anIntRate
          appFields.put(CSFieldNames.FN_NUM_PMT, String.valueOf(rs.getInt("nNumPmt"))); // anNumPmt
          appFields.put(CSFieldNames.FN_AMT_APPROVED,
                        String.valueOf(rs.getDouble("mAmtApv"))); // anAmtApv
          appFields.put(CSFieldNames.FN_LOAN_AMT, String.valueOf(rs.getDouble("mAmtApv"))); // anLoanAmt
          appFields.put(CSFieldNames.FN_NW_REQ, String.valueOf(rs.getDouble("mAmtApv"))); // anLoanAmt
          appFields.put(CSFieldNames.FN_AMT_REQ, String.valueOf(rs.getDouble("mAmtApv"))); // anLoanAmt

          str = rs.getString("bAccept");
          if (str != null) {
            appFields.put("bAccept", str);
          }
        }
      }  // while
    }
    catch (SQLException e)
    {
      e.printStackTrace();

      String errorMsg = "CSUtil.updateAppAndBwrNode(...) - SQLException thrown: " + e.getMessage();

      DBErrorLogger.log(errorMsg);

      throw e;
    }
    finally
    {
      DBConnPool.closeConnection(stmt);
    }

    return acceptedProductId;

  }   // getPAOData




  private static String updateAppAndBwrNode( SystemDataObject sdo, String paoProdId,
                                           String paoSSN, String username, boolean isSSN,
                                           HashtableX bwrFields )
  throws Exception, SQLException
  {
    //general.errLog("START updateAppAndBwrNode(...): ", "PAO.log");
    String acceptedProductId = null;

    try
    {
      HashtableX bwrPAOFields = new HashtableX();
      HashtableX appPAOFields = new HashtableX();

      acceptedProductId = getPAOData(paoProdId, paoSSN, isSSN,
                                       bwrPAOFields, appPAOFields);

      if (acceptedProductId == null)
      {
        throw new Exception ("Preapproval offer not found for this borrower.");
      }

      String accepted = (String) appPAOFields.get("bAccept");
      if (accepted != null && accepted.equals("a"))
      {
        throw new Exception ("Preapproval offer already accepted for this borrower and product.");
      }

      HashtableX bwrHT = null;
      HashtableX appHT = null;

      DataNode appNode = sdo.getNodeData(NodeUtils.APP_DN_TYPE);

      // create decision node
      //
      DataNode dcsnNode = sdo.createDataNode(username, NodeUtils.DCSN_DN_TYPE);

      String todaysDate = DateUtility.getTodaysDate("MDY", "/");
      String todaysTime = DateUtility.getTimeHourMinuteAMPM();

      dcsnNode.setFieldData(username, CSFieldNames.FN_DCSN, CSFieldValues.FV_DCSN_APRV);  // dcDcsn = "Approve"
      dcsnNode.setFieldData(username, CSFieldNames.FN_DCSN_PARTY, "Preapproval");  // dcDcsnPty = "Preapproval"
      dcsnNode.setFieldData(username, CSFieldNames.FN_DCSN_DATE, todaysDate + " " + todaysTime);  // dcDcsnDt

      appNode.addReference(dcsnNode);

      // set the flag and status
      //
      appNode.setSystemData("!pao_sdo", "t");

      // don't do CKD
      //
      // appNode.setSystemData(CSStatusCodes.SDO_STATUS, CSStatusCodes.SC_INCOMPLETE_PREAPV);
      //
      appNode.setSystemData(CSStatusCodes.APP_DECISION, CSStatusCodes.APP_DECISION_APPROVE);   // !dcsn = 'a'

      // 8-31-2010, ccl
      // set !review and !finrvw to be false
      //
      appNode.setSystemData(CSStatusCodes.APP_NEEDS_REVIEW, CSFieldValues.FALSE_STRING);
      appNode.setSystemData(CSStatusCodes.APP_NEEDS_FINAL_RVW, CSFieldValues.FALSE_STRING);

      appHT = appNode.getFieldData(username);
      //general.errLog("appHT: "+appHT, "PAO.log");

      if (appHT == null)
        {
          appHT = new HashtableX();
        }
        else
        {
          appHT.remove("anDfltFeesHash");
        }

      DataNode bwrNode = appNode.getReference(NodeUtils.BWR_DN_TYPE, 0);
      bwrHT = bwrNode.getFieldData(username);
      //general.errLog("bwrHT: "+bwrHT, "PAO.log");

      if (bwrHT == null) bwrHT = new HashtableX();


        // 6-7-2010, ccl
        //
        boolean isMortgage = CSUtil.isMortgageApplication(appNode);
        DataEntrySupport.defaultPaymentInfo(appHT, isMortgage, appNode);

        // vp.parseDouble("anAmtReq", amtReqStr, REQUIRED, "Amount Requested");
        // appHT.put(CSFieldNames.FN_AMT_APPROVED, String.valueOf(rs.getDouble("mAmtApv")));  // anAmtApv
        //
        String str = (String)appNode.getFieldData( username, CSFieldNames.FN_AMT_REQ );
        double reqAmt = StringSupport.strToDouble(str);

        str = (String)appPAOFields.get(CSFieldNames.FN_AMT_APPROVED);
        double paoApvAmt = StringSupport.strToDouble(str);

        if (reqAmt == 0.0)
        {
          appNode.setFieldData(username, CSFieldNames.FN_AMT_REQ, String.valueOf(paoApvAmt));
          appNode.setFieldData(username, CSFieldNames.FN_LOAN_AMT, String.valueOf(paoApvAmt));
          appNode.setFieldData(username, CSFieldNames.FN_AMT_APPROVED, String.valueOf(paoApvAmt));
        }
        else if (reqAmt <= paoApvAmt)
        {
          appNode.setFieldData(username, CSFieldNames.FN_AMT_APPROVED, String.valueOf(paoApvAmt));
        }
        else
        {
          throw new Exception("Amount requested is greater than preapproval offer amount of $" + paoApvAmt + ".");
        }

        str = (String)appNode.getFieldData(username, CSFieldNames.FN_NUM_PMT);
        int numPmt = StringSupport.strToInt(str);

        str = (String)appPAOFields.get(CSFieldNames.FN_NUM_PMT);
        int paoNumPmt = StringSupport.strToInt(str);

        if (numPmt == 0)
        {
          if (paoNumPmt > 0)
          {
            appNode.setFieldData(username, CSFieldNames.FN_NUM_PMT, String.valueOf(paoNumPmt));
          }
        }
        else if (numPmt > paoNumPmt && paoNumPmt > 0)
        {
          throw new Exception("Term requested is greater than preapproval offer term of " + paoNumPmt + " months.");
        }

        str = (String)appNode.getFieldData(username, CSFieldNames.FN_INT_RATE_REQ);
        double rate = StringSupport.strToDouble(str);

        str = (String)appPAOFields.get(CSFieldNames.FN_INT_RATE);
        double paoRate = StringSupport.strToDouble(str);

        if (rate == 0.0)
        {
          if (paoRate > 0.0)
          {
            appNode.setFieldData(username, CSFieldNames.FN_INT_RATE, String.valueOf(paoRate));
          }
        }
        else if (rate != paoRate && paoNumPmt > 0.0)
        {
          throw new Exception("Rate requested does not equal preapproval offer rate of " + paoRate + ".");
        }


        // appHT.put(CSFieldNames.FN_PRE_APPROVED, CSFieldValues.TRUE_STRING);
        appNode.setFieldData( username, CSFieldNames.FN_PRE_APPROVED, CSFieldValues.TRUE_STRING );

        // DataEntrySupport.createDefaultFeeNodes(sdo, appNode, username);

        str = (String)bwrPAOFields.get(CSFieldNames.FN_BWR_RSK_SCORE);
        if (str != null && !bwrHT.containsKey(CSFieldNames.FN_BWR_RSK_SCORE))
        {
          bwrHT.put(CSFieldNames.FN_BWR_RSK_SCORE, str.trim());
          appNode.setSystemData(CSFieldNames.FN_APP_SCORE, str.trim());
          bwrNode.setSystemData(CSFieldNames.FN_APP_SCORE, str.trim());
        }

        str = (String)bwrPAOFields.get(CSFieldNames.FN_BWR_BNK_SCORE);
        if (str != null && !bwrHT.containsKey(CSFieldNames.FN_BWR_BNK_SCORE))
        {
          bwrHT.put(CSFieldNames.FN_BWR_BNK_SCORE, str.trim());
        }

        //
        if (!bwrHT.isEmpty())
        {
          DataCollection.createReportNode(sdo, appNode, bwrNode, bwrHT, username);

          DataNode rptNode = bwrNode.getFirstReference(NodeUtils.RPRT_DN_TYPE);
          if (rptNode != null)
          {
            rptNode.removeSystemData("!de");
            str = (String)bwrNode.getSystemData(CSFieldNames.FN_BWR_CB_SCORE);
            if (str != null) appNode.setSystemData(CSFieldNames.FN_APP_SCORE,
                                                   str);
          }
        }

      //}  // while
    }
    catch (Exception e)
    {
      e.printStackTrace();

      //String errorMsg = "AppImportUtils.updateAppAndBwrNode(...) - Exception thrown: " + e.getMessage();
      //general.errLog(" errorMsg: "+ errorMsg, "PAO.log");

      throw e;
    }

    //general.errLog("END updateAppAndBwrNode(...): ", "PAO.log");

    return acceptedProductId;

  } // updateAppAndBwrNode

  public static String translateValidDirection( String strSuffix )
  {
    //S1Log.getLogInstance().log("START translateValidDirection( String strSuffix )", LOG_FILE);
    //S1Log.getLogInstance().log("strSuffix: "+strSuffix, LOG_FILE);

    String transSuffix = null;

    if( strSuffix != null )
    {
      String suffix = strSuffix.trim();

      if( suffix.toUpperCase().equals("NORTH") )
            {
            transSuffix = "N";
            }

      else if( suffix.toUpperCase().equals("NORTHEAST") )
           {
           transSuffix = "NE";
           }

      else if( suffix.toUpperCase().equals("NORTHWEST") )
           {
           transSuffix = "NW";
           }

      else if( suffix.toUpperCase().equals("SOUTH") )
           {
           transSuffix = "S";
           }

      else if( suffix.toUpperCase().equals("SOUTHEAST") )
           {
           transSuffix = "SE";
           }

      else if( suffix.toUpperCase().equals("SOUTHWEST") )
           {
           transSuffix = "SW";
           }

      else if( suffix.toUpperCase().equals("EAST") )
           {
           transSuffix = "E";
           }

      else if( suffix.toUpperCase().equals("WEST") )
           {
           transSuffix = "W";
           }

      else
           {
           transSuffix = suffix;
           }
    } // End if( suffix != null )

    //S1Log.getLogInstance().log("return transSuffix:"+transSuffix, LOG_FILE);
    //S1Log.getLogInstance().log("END translateValidDirection( String strSuffix )", LOG_FILE);

    return transSuffix;

  } // isValidDirection( String strSuffix )

  public static boolean reprintDecisionDocsForPSECU(String PDF_DIR_PATH, String appID, String sdoID, String docSet) throws Exception
  {
    //S1Log.getLogInstance().log("START reprintDecisionDocsForPSECU(String EDOC_ARCH_PDF_PATH, String appID, String docSet)",LOG_FILE);
    //S1Log.getLogInstance().log("EDOC_ARCH_PDF_PATH: "+PDF_DIR_PATH,LOG_FILE);
    //S1Log.getLogInstance().log("appID: "+appID,LOG_FILE);
    //S1Log.getLogInstance().log("sdoID: "+appID,LOG_FILE);
    //S1Log.getLogInstance().log("docSet: "+docSet,LOG_FILE);

    String filename = "Stage_" +docSet+".LOG";
    //S1Log.getLogInstance().log("filename: "+filename,LOG_FILE);

    String docSetInitial = EDocArchSupport.getPrintStageInitial( docSet );
    //S1Log.getLogInstance().log("docSetInitial: "+docSetInitial,LOG_FILE);

    boolean reprint = false;

    try
      {
      //S1Log.getLogInstance().log("if( PDF_DIR_PATH.endsWith(\\) ): "+( PDF_DIR_PATH.endsWith("\\") ),LOG_FILE);

      File mf = null;

      if( PDF_DIR_PATH.endsWith("\\") )
      {
        // mf = new File( PDF_DIR_PATH + appID + File.separator + filename );
        //
        PDF_DIR_PATH =  PDF_DIR_PATH + appID + File.separator;
        //S1Log.getLogInstance().log("1 mf path: "+(PDF_DIR_PATH),LOG_FILE);
      }
      else
      {
        // mf = new File( PDF_DIR_PATH + File.separator + appID + File.separator + filename );
        //
        PDF_DIR_PATH =  PDF_DIR_PATH + File.separator + appID + File.separator;
        //S1Log.getLogInstance().log("2 mf path: "+(PDF_DIR_PATH),LOG_FILE);
      }

      mf = new File( PDF_DIR_PATH + filename );

      //S1Log.getLogInstance().log("if( mf != null && mf.exists() ): "+( mf != null && mf.exists() ),LOG_FILE);
      if( mf != null && mf.exists() )
          {
          if( mf.isFile() )
              {
                try
                {
                  // pdfFileName = readFile(mf);
                  //
                  String fileLineDt = readFirstFileLineAndGetDate(mf);
                  //S1Log.getLogInstance().log("fileLineDt: "+fileLineDt,LOG_FILE);

                  if( fileLineDt != null && fileLineDt.length() > 0 )
                  {
                    Date lastPrintDt = DateUtility.assignSlashDateToJavaDate( fileLineDt );
                    //S1Log.getLogInstance().log("lastPrintDt: "+lastPrintDt,LOG_FILE);

                    Timestamp ts = DBQueries.getLastModifiedDate( sdoID );
                    //S1Log.getLogInstance().log("ts: "+ts,LOG_FILE);

                    reprint = ts.after( lastPrintDt );
                    //S1Log.getLogInstance().log("reprint: "+reprint,LOG_FILE);
                  } // if( fileLines != null && ! fileLines.isEmpty() )
                  else
                  {
                    throw new Exception("No file names were returned from the document set log file.");
                  }
                }
                catch (SQLException e)
                {
                  e.printStackTrace();
                  throw new Exception("Unable to retrieve last modified date from database. SQL Error: "+e);
                }
                catch (Exception e)
                {
                  e.printStackTrace();
                  throw new Exception("Unable to read the document set log file. Error: "+e);
                }
              }
          else
              {
              // is not a file
              //
              throw new Exception("Invalid file format.");
              }
          }
      else
          {
          // file doesn't exist error
          //
          // throw new Exception(filename+" log file currently does not exist.");
          
          // if files do not exist disclosure docs have never been rpinted for this application so reprint docs
          //
          reprint = true;
          }
      }
    catch( Exception e )
      {
      e.printStackTrace();

      String errMsg = "Cannot load the requested log file.  "+ e.getMessage() +" FILE PATH: "+ PDF_DIR_PATH + filename;

      throw new Exception(errMsg);
      }

      //S1Log.getLogInstance().log("return reprint: "+reprint,LOG_FILE);
      //S1Log.getLogInstance().log("START reprintDecisionDocsForPSECU(String EDOC_ARCH_PDF_PATH, String appID, String docSet)",LOG_FILE);

      return reprint;
  } //  private XCSResponse createStageSummaryTable( String appID, String docSet )

  public static String readFirstFileLineAndGetDate(File file) throws Exception
  {
    //S1Log.getLogInstance().log("START readFirstFileLineAndGetDate(File file)",LOG_FILE);

    String date = null;
    String slashDate = null;
    RandomAccessFile raf = null;
    try
    {
      raf = new RandomAccessFile(file, "r");

      String line = null;

      line = raf.readLine();

      //S1Log.getLogInstance().log("line: "+line,LOG_FILE);
      //S1Log.getLogInstance().log("line length: "+line.length(),LOG_FILE);

      if (line != null && line.trim().length() > 17)
      {
          // 20070802|163721|xml|P|Portfolio.PDF xuca.PDF ConsumerApplication.BRG
          //
          int index = line.indexOf('|');
          //S1Log.getLogInstance().log("index: "+index,LOG_FILE);

          date = line.substring(0,index);
          //S1Log.getLogInstance().log("date: "+date,LOG_FILE);

          // slash date
          //
          if( date != null && date.trim().length() == 8 )
          {
            // fix error 0/01/201
            String yr = date.substring(0,4);
            //S1Log.getLogInstance().log("yr: "+yr,LOG_FILE);

            String mon = date.substring(4,6);
            //S1Log.getLogInstance().log("mon: "+mon,LOG_FILE);

            String day = date.substring(6);
            //S1Log.getLogInstance().log("day: "+day,LOG_FILE);

            slashDate = mon + "/" + day + "/" + yr;
            //S1Log.getLogInstance().log("slashDate: "+slashDate,LOG_FILE);
          }
      }

    } // try
    catch (Exception e)
    {
      e.printStackTrace();

      String errMsg = "An error occurred while reading the file data: Error: " +e.getMessage();
      throw new Exception(errMsg);
    } // try/catch

    finally
    {
      try
      {
        raf.close();
      }
      catch (IOException e)
      {
        e.printStackTrace();

        String errMsg = "Unable to close the file after processing: Error: " + e.getMessage();
        throw new Exception(errMsg);
      }
    } // finally

    //S1Log.getLogInstance().log("date: "+date,LOG_FILE);
    //S1Log.getLogInstance().log("return slashDate: "+slashDate,LOG_FILE);
    //S1Log.getLogInstance().log("END readFirstFileLineAndGetDate(File file)",LOG_FILE);

    return slashDate;
  } //  private List readFile(File file)

  public static String getLabelFromLabelValueTable( Map table, String value )
  {
    String label = null;

    Iterator it = table.keySet().iterator();
    String tempValue = null;

    while (it.hasNext())
    {
      label = (String)it.next();
      tempValue = (String)table.get( label );
      if( tempValue != null && tempValue.trim().equals( value ) )
      {
        break;
      }
    }

    return label;
  }

  // need to check for valid index for co-app for xml asset and liabilities.
  // currently causing app import to failure. Get effective referneces. Check
  // for first on greater than zero. Add to vector and return it. XML apps can
  // only have two borrowers for now. 2-04-11
  //
  public static VectorX createAssetLiabilityOwnerVec( VectorX bwrsEffctRefrnces, VectorX sharedBy )
  {
    //general.errLog("START createAssetLiabilityOwnerVec( VectorX bwrsEffctRefrnces )","AstLiabShareByVec.log");
    //general.errLog("bwrsEffctRefrnces.size(): "+bwrsEffctRefrnces.size(),"AstLiabShareByVec.log");

    //general.errLog("0 sharedBy: "+sharedBy,"AstLiabShareByVec.log");

    if( bwrsEffctRefrnces != null && ! bwrsEffctRefrnces.isEmpty() )
    {
      sharedBy = new VectorX();
      //general.errLog("1 sharedBy: "+sharedBy,"AstLiabShareByVec.log");

      for( int i=0, c=bwrsEffctRefrnces.size(); i<c; i++ )
      {
        DataNode bwrDN = (DataNode)bwrsEffctRefrnces.get(i);

        int index = bwrDN.getIndex();
        //general.errLog("indexNumber: "+index, "AstLiabShareByVec.log");

        if( index == 0 )
        {
          sharedBy.add( String.valueOf( index ) );
          //general.errLog("2 sharedBy: "+sharedBy,"AstLiabShareByVec.log");
        }
        else if( index > 0 )
        {
          sharedBy.add( String.valueOf( index ) );
          //general.errLog("3 sharedBy: "+sharedBy,"AstLiabShareByVec.log");
          break;
        }
      } // for( int i=0, c=bwrsEffctRefrnces.size(); i<c; i++ )

      //general.errLog("4 sharedBy: "+sharedBy,"AstLiabShareByVec.log");

    } // if( bwrsEffctRefrnces != null && ! bwrsEffctRefrnces.isEmpty() )


    //general.errLog("return sharedBy: "+sharedBy,"AstLiabShareByVec.log");
    //general.errLog("END createAssetLiabilityOwnerVec( VectorX bwrsEffctRefrnces )","AstLiabShareByVec.log");

    return sharedBy;
  }


  private static double calculateTempLTV (DataNode appNode, HashtableX collData)
  {
    double LTV = 999.99;

    String loan = (String)appNode.getFieldData(CSFieldValues.EMPTY_STRING,
                                               CSFieldNames.FN_LOAN_AMT);
    String eValue = (String)collData.get(CSFieldNames.FN_PHY_EST_VAL);

    double value = StringSupport.strToDouble(eValue);

    if (value > 0.0)
    {
      LTV = StringSupport.strToDouble(loan) * 100.0 / value;
    }

    return LTV;
  }

  public static void setSysFieldsForBwrRetirementIncome( HashtableX bwr0Data, DataNode appNode )
  throws Exception
  {
    String atPenRetInc = (String)bwr0Data.get("atPenRetInc");
    String atSsnDisInc = (String)bwr0Data.get("atSsnDisInc");

    if( (atPenRetInc != null && atPenRetInc.trim().length() > 0) || (atSsnDisInc != null && atSsnDisInc.trim().length() > 0) )
    {
      DataNode bwr0 = appNode.getReference(NodeUtils.BWR_DN_TYPE, 0);
      if(atPenRetInc != null && atPenRetInc.trim().length() > 0){bwr0.setSystemData("!penRetInc", atPenRetInc);}
      if(atSsnDisInc != null && atSsnDisInc.trim().length() > 0){bwr0.setSystemData("!ssnDisInc", atSsnDisInc);}
    }

  } //  public static void updateDealerScoresForBwr( HashtableX bwr0Data, DataNode appNode )

  // led - do in this class now and will activate same method in db queries after account opening is completed
  // and checked into ver 2011
  //
  public static String getMemberLookUpNumber(String nAppId)
    throws SQLException
  {
    String sql = "SELECT cMisc FROM xntApMiscFields WHERE nAppId = " + nAppId + " AND cMiscFieldId = 'miscD0354'";
    //String sql = "SELECT cMisc FROM xntApMiscFields WHERE nAppId = " + nAppId + " AND cMiscFieldId = 'miscD0315'";

    Statement stmt = null;
    String memberLookUpNumber = null;
    try
    {
      Connection con = DBAccess.getConnection();
      stmt = con.createStatement();
      ResultSet rs = stmt.executeQuery(sql);

      if (rs.next())
      {
        memberLookUpNumber = rs.getString("cMisc");
      }
    }
    catch (SQLException e)
    {
      DBLogger.log("Executing " + sql + ": " + e);
      throw e;
    }
    finally
    {
      DBAccess.closeConnection(stmt);
    }

    return memberLookUpNumber;
  }

  public static void setupDepositAccountProductNodes( SystemDataObject sdo, HashtableX appData, String DATA_ENTRY_USER )
    throws Exception
  {
    //S1Log.getLogInstance().log("START setupDepositAccountProductNodes(...)",LOG_FILE);

    DataNode appNode = sdo.getNodeData( NodeUtils.APP_DN_TYPE );
    VectorX depAcctPrds = StringChanger.stringToVector( (String) appData.get( "anPrdRequestList" ) );
    //S1Log.getLogInstance().log( "depAcctPrds: "+depAcctPrds, LOG_FILE );

    try
    {
      if( depAcctPrds != null && ! depAcctPrds.isEmpty() )
      {
        
        //S1Log.getLogInstance().log( "depAcctPrds.size(): " + depAcctPrds.size(), LOG_FILE );
        for( int i=0, c=depAcctPrds.size(); i<c; i++ )
        {
          HashtableX ht = (HashtableX)depAcctPrds.get( i );
          //S1Log.getLogInstance().log( "depAcct ht: " + ht, LOG_FILE );
          if( ht != null && ! ht.isEmpty() )
          {
            VectorX secOwnerList = ( VectorX ) ht.get( "daAcctOwnerList" );
            //S1Log.getLogInstance().log( "secOwnerList: " + secOwnerList, LOG_FILE );
            if( secOwnerList != null && !secOwnerList.isEmpty() )
            {
              VectorX aahVec = new VectorX();
              HashtableX aahHash = new HashtableX();

              for(int aa=0, bb=secOwnerList.size(); aa<bb; aa++)
              {

                HashtableX secOwnHT = (HashtableX)secOwnerList.get( aa );
                //S1Log.getLogInstance().log( "coApplicantDescList secOwnHT: " + secOwnHT, LOG_FILE );
                if( secOwnHT != null && ! secOwnHT.isEmpty() )
                {
                  String ssn = (String)secOwnHT.get( "ssn" );
                  //S1Log.getLogInstance().log( "coApplicantDescList ssn: " + ssn, LOG_FILE );

                  String acctTitle = (String)secOwnHT.get( "title" );
                  //S1Log.getLogInstance().log( "coApplicantDescList acctTitle: " + acctTitle, LOG_FILE );
                  if( ssn != null && ssn.trim().length() > 0 )
                  {
                    String bwrIndex = getBwrIndexFromSDO(sdo, ssn);
                    //S1Log.getLogInstance().log( "coApplicantDescList bwrIndex: " + bwrIndex, LOG_FILE );
                    
                    if( bwrIndex != null && StringSupport.strToInt( bwrIndex ) > 0 )
                    {
                      aahVec.add( bwrIndex );

                      if( acctTitle != null && acctTitle.trim().length() > 0 )
                      {
                        aahHash.put( bwrIndex, acctTitle);
                      }                      
                    }
                  }
                }                
              } // for(int aa=0, bb=coApplicantDescList.size(); aa<bb; aa++)

              // set joint account fields REMOVED FROM CODE 10-24
              //
              // ht.put( "daJtC", CSFieldValues.TRUE_STRING );

              if( aahVec != null && ! aahVec.isEmpty() )
              {
                ht.put( "daWfePartiesM", aahVec );
              }

              if( aahHash != null && ! aahHash.isEmpty() )
              {
                ht.put( "daWfeTitleMap", aahHash );
              }
            }

            DepUtils.saveProductRequestData( DATA_ENTRY_USER, -1, sdo, ht );
            //S1Log.getLogInstance().log( "DepUtils.saveProductRequestData ht: " + ht, LOG_FILE );
          }
        }
      }
    }
    catch( Exception e )
    {
      e.printStackTrace();

      String refID = ( String ) appNode.getFieldData( CSFieldValues.EMPTY_STRING, "anRefId" );

      String err = "An error occurred while processing the account deposit products. Application ID: " + refID + "  Error: " + e;

      throw new Exception( err );
      //vp.addInformationalErrorMsg(err);
    }

    //S1Log.getLogInstance().log( "END setupDepositAccountProductNodes(...)", LOG_FILE );

  } //  public static void setupDepositAccountProductNodes( SystemDataObject sdo, HashtableX appData, String DATA_ENTRY_USER )


  public static void processApplicationDataAccountOpening( Map inHash, Map appData, Map bwr0Data, List coAppDataVec )
  {
    //S1Log.getLogInstance().log( "START processApplicationDataAccountOpening(...)", LOG_FILE );

    int numberOfApplicants = -1;
    String numOfAppStr = (String)inHash.get( "anNumberOfApplicants" );
    //S1Log.getLogInstance().log( "numOfAppStr: "+numOfAppStr, LOG_FILE );
    if( numOfAppStr != null && numOfAppStr.trim().length() > 0 )
    {
      numberOfApplicants = Integer.parseInt( numOfAppStr );
    }

    //S1Log.getLogInstance().log( "numberOfApplicants: " + numberOfApplicants, LOG_FILE );

    String fieldVal  = null;
    String fieldName = null;

    Iterator it = inHash.keySet().iterator();

    while( it.hasNext() )
    {
      fieldName = ( String ) it.next();

      Object obj = inHash.get( fieldName );

      if( obj instanceof String )
      {
        fieldVal = ( String ) inHash.get( fieldName );
      }
      else if( obj instanceof VectorX )
      {
        fieldVal = ( ( VectorX ) inHash.get( fieldName ) ).toString();
      }
      else if( obj instanceof HashtableX )
      {
        fieldVal = ( ( HashtableX ) inHash.get( fieldName ) ).toString();
      }
      else
      {
        continue;
      }

      // application data, add bank secrecy fields(bsBkSc)
      //
      if( fieldName.startsWith( "an" ) || fieldName.startsWith( "www" ) || fieldName.startsWith( "hm" ) || fieldName.startsWith( "bsBkSc" ))
      {
        appData.put( fieldName, fieldVal );
      }

      // applicant / borrower data
      //
      else if( fieldName.startsWith( "at" ) )
      {
        // We need to remove the index from the end of the field name.  We
        // will not need this when building the data node structure.
        //
        if( fieldName.endsWith( "_0" ) )
        {
          bwr0Data.put( fieldName.substring( 0, fieldName.length() - 2 ), fieldVal );
        }
      }
      
    } // while (it.hasNext())

    // load co app bwr vec for multiple co apps
    //
    if( numberOfApplicants > 1 )
    {
      getCoApplicantsData( inHash, coAppDataVec, numberOfApplicants );
    }

    //S1Log.getLogInstance().log( "END processApplicationDataAccountOpening(...)", LOG_FILE );

  } // public static void processApplicationDataAccountOpening(...)

  public static void getCoApplicantsData(Map inHash, List coAppDataVec, int numberOfApplicants) 
  {
    //S1Log.getLogInstance().log( "START getCoApplicantsData(...)", LOG_FILE );

    for(int i=1, c = numberOfApplicants; i<c; i++)
    {
      HashtableX coAppHash = new HashtableX();
        
      String startsWithStr = "at";
      String endsWithStr = "_"+i;
  
      //S1Log.getLogInstance().log("endsWithStr: "+endsWithStr, LOG_FILE );

      String key   = null;
      String value = null;

      Iterator it = inHash.keySet().iterator();
      while( it.hasNext() )
      {
        key = (String)it.next();
        //S1Log.getLogInstance().log( "key: " + key, LOG_FILE );
          
        Object obj = inHash.get( key );
  
        if( obj != null && obj instanceof String )
        {
          value = ( String ) inHash.get( key );
        }
        else if( obj != null && obj instanceof VectorX )
        {
          value = ( ( VectorX ) inHash.get( key ) ).toString(); // need to string everything
        }
        else if( obj != null && obj instanceof HashtableX )
        {
          value = ( ( HashtableX ) inHash.get( key ) ).toString();
        }
        else
        {
          // all other instrances are not valid
          continue;
        }

        if( key != null && key.startsWith( startsWithStr ) && key.endsWith( endsWithStr ) )
        {
            coAppHash.put( key.substring( 0, key.length() - 2 ), value );
            //S1Log.getLogInstance().log( "PUT coAppHash: "+coAppHash, LOG_FILE );
        }            
      }
      
      //S1Log.getLogInstance().log( "coAppHash: "+coAppHash, LOG_FILE );
      if(coAppHash != null && ! coAppHash.isEmpty() )
      {
          coAppDataVec.add( coAppHash );
          //S1Log.getLogInstance().log( "coAppVec.add - coAppHash: "+coAppHash, LOG_FILE );
      }
      
      //S1Log.getLogInstance().log( "coAppVec: "+coAppDataVec, LOG_FILE );        
    } // for loop
    
    // for testing only
    //for( int o=0,p=coAppDataVec.size(); o<p; o++)
    //{
    //    HashtableX ht = (HashtableX)coAppDataVec.get(o);
    //    //S1Log.getLogInstance().log( o+" ht: "+ht, LOG_FILE );
    //}

    //S1Log.getLogInstance().log( "END getCoApplicantsData(...)", LOG_FILE );
  }

} // End public class AppImportUtils ***************************************************************
