var pagesConfig = {
    "appHistory.aspx": {
        "leftMenu": "navsub01"
    },
    "appInfo.aspx": {
        "leftMenu": "navsub00",
        "step": "Personal_Information"
    },
    "appInfo_coApp.aspx": {
        "leftMenu": "navsub00",
        "step": "Personal_Information"
    },
    "appStatus.aspx": {
        "leftMenu": "navsub01"
    },
    "contact.aspx": {
        "leftMenu": "navsub01"
    },
    "docUpload.aspx": {
        "leftMenu": "navsub01"
    },
    "instructions.aspx": {
        "leftMenu": "navsub00",
        "step": "Loan_Information"
    },
    "interestRate.aspx": {
        "leftMenu": "navsub00",
        "step": "Loan_Information"
    },
    "loanInfo.aspx": {
        "leftMenu": "navsub00",
        "step": "Loan_Information"
    },
    "loanType.aspx": {
        "leftMenu": "navsub00"
    },
    "mortgageAdditionalLoanInformation.aspx": {
        "leftMenu": "navsub00"
    },
    "mortgageAppInfo.aspx": {
        "leftMenu": "navsub00",
        "step": "Personal_Information"
    },
    "mortgageApply.aspx": {
        "leftMenu": "navsub00"
    },
    "mortgageClosingCostDetails.aspx": {
        "leftMenu": "navsub02"
    },
    "mortgageCoAppInfo.aspx": {
        "leftMenu": "navsub00",
        "step": "Personal_Information"
    },
    "mortgageConsultant.aspx": {
        "leftMenu": "navsub02"
    },
    "mortgageConsultantResults.aspx": {
        "leftMenu": "navsub02"
    },
    "mortgageConsultantType.aspx": {
        "leftMenu": "navsub02"
    },
    "mortgageDisclosures.aspx": {
        "leftMenu": "navsub00",
        "step": "Loan_Information"
    },
    "mortgageFee.aspx": {
        "leftMenu": "navsub00"
    },
    "mortgageLiabilities.aspx": {
        "leftMenu": "navsub00",
        "step": "Loan_Information"
    },
    "mortgageProcessing.aspx": {
        "leftMenu": "navsub00",
        "step": "Complete_Application"
    },
    "mortgageProductSelection.aspx": {
        "leftMenu": "navsub00",
        "step": "Complete_Application"
    },
    "mortgagePropertyInfo.aspx": {
        "leftMenu": "navsub00"
    },
    "mortgagePropertyTransType.aspx": {
        "leftMenu": "navsub00",
        "step": "Loan_Information"
    },
    "mortgageRateBlackout.aspx": {
        "leftMenu": "navsub01"
    },
    "mortgageRateLockConfirm.aspx": {
        "leftMenu": "navsub01"
    },
    "mortgageRateLockReq.aspx": {
        "leftMenu": "navsub01"
    },
    "mortgageRateLocked.aspx": {
        "leftMenu": "navsub01"
    },
    "mortgageStatus.aspx": {
        "leftMenu": "navsub01"
    },
    "mortgageSummary.aspx": {
        "leftMenu": "navsub00",
        "step": "Complete_Application"
    },
    "offers.aspx": {
        "leftMenu": "navsubSpecialOffer"
    },
    "processing.aspx": {
        "leftMenu": "navsub00",
        "step": "Complete_Application"
    },
    "rolloverDetails.aspx": {
        "leftMenu": "navsubSpecialOffer"
    },
    "success.aspx": {
        "leftMenu": "navsub01"
    },
    "summary.aspx": {
        "leftMenu": "navsub00",
        "step": "Complete_Application"
    },
    "upload.aspx": {
        "leftMenu": "navsub01"
    }
}